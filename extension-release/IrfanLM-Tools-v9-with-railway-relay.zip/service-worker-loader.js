import './assets/chunk-5e2e563c.js';
import './assets/bulk-tools-bg.js';
import './assets/nlm-lovable-bridge-bg.js';
