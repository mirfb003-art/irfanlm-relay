// ─────────────────────────────────────────────────────────────────────────
// Lovable Bridge (custom addon) — content script / postMessage dispatcher
//
// Runs only on the allowed Lovable app origins (see manifest content_scripts
// match list). Gives the web app a way to pair with the extension WITHOUT
// needing to know the extension ID up front:
//
//   window.postMessage(
//     { __nlmBridgeRequest: true, requestId, type: "PING" | "GET_AUTH_PAYLOAD"
//                                        | "EXECUTE_RPC" | "FETCH_STUDIO_ARTIFACT",
//       payload: { ... } },
//     window.location.origin
//   );
//
//   window.addEventListener("message", (e) => {
//     if (e.data?.__nlmBridgeResponse && e.data.requestId === requestId) { ... }
//   });
//
// This is a convenience layer on top of chrome.runtime.sendMessage(EXTENSION_ID, ...),
// which the web app can still use directly once it knows the extension ID
// (see manifest "externally_connectable"). The postMessage path is mainly
// useful for the very first handshake / "is the extension installed" check.
// ─────────────────────────────────────────────────────────────────────────

(() => {
  "use strict";

  const RESPONSE_MARKER = "__nlmBridgeResponse";
  const REQUEST_MARKER = "__nlmBridgeRequest";

  // Announce presence as soon as this script runs, so the page can detect
  // "extension is installed" without firing a request first.
  function announceReady() {
    window.postMessage(
      {
        [RESPONSE_MARKER]: true,
        type: "EXTENSION_READY",
        version: chrome.runtime.getManifest().version,
      },
      window.location.origin
    );
  }

  window.addEventListener("message", (event) => {
    // Only trust same-window, same-origin messages — never relay anything
    // received from an iframe or a different origin into the extension.
    if (event.source !== window) return;
    if (event.origin !== window.location.origin) return;

    const data = event.data;
    if (!data || data[REQUEST_MARKER] !== true) return;

    const { requestId, type, payload } = data;

    chrome.runtime
      .sendMessage({
        __nlmBridgeRelay: true,
        pageOrigin: window.location.origin,
        type,
        payload,
      })
      .then((result) => {
        window.postMessage({ [RESPONSE_MARKER]: true, requestId, ...result }, window.location.origin);
      })
      .catch((err) => {
        window.postMessage(
          { [RESPONSE_MARKER]: true, requestId, ok: false, error: err?.message || String(err) },
          window.location.origin
        );
      });
  });

  announceReady();
})();
