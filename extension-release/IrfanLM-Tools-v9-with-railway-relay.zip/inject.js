try {
  var YTUONG_NLM_PAYLOAD = {}

  // SNlM0e: token
  if (window?.WIZ_global_data?.SNlM0e) {
    YTUONG_NLM_PAYLOAD.token = window?.WIZ_global_data?.SNlM0e
  }

  // qwAQke: app
  if (window?.WIZ_global_data?.qwAQke) {
    YTUONG_NLM_PAYLOAD.app = window?.WIZ_global_data?.qwAQke
  }

  // cfb2h: bl
  if (window?.WIZ_global_data?.cfb2h) {
    YTUONG_NLM_PAYLOAD.bl = window?.WIZ_global_data?.cfb2h
  }

  // FdrFJe: f.sid
  if (window?.WIZ_global_data?.FdrFJe) {
    YTUONG_NLM_PAYLOAD.fsid = window?.WIZ_global_data?.FdrFJe
  }

  // oPEP7c: email
  if (window?.WIZ_global_data?.oPEP7c) {
    YTUONG_NLM_PAYLOAD.email = window?.WIZ_global_data?.oPEP7c
  }

  // Extract authuser from URL
  var urlParams = new URLSearchParams(window.location.search)
  YTUONG_NLM_PAYLOAD.authuser = parseInt(urlParams.get('authuser') || '0', 10) || 0

  window.localStorage.setItem('YT_NLM', JSON.stringify(YTUONG_NLM_PAYLOAD))
} catch (e) {
  console.error('[NLM Tools] Failed to extract auth data:', e)
}
