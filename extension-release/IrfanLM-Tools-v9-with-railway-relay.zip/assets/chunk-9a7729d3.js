import { j as e, r as v, k as V, u as z, M as B, X as Y, U as _, J as E, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as T, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { g as q } from "./chunk-378f9272.js";
import { f as Q, i as X, z as H, Q as J, w as U, h as G, __tla as __tla_2 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_3 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let xe;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  const Z = {
    url: "Same URL",
    youtube_id: "Same YouTube video",
    title: "Similar titles",
    content: "Similar content"
  };
  function ee({ group: s, selection: h, onUpdateSelection: g, keepPreference: i }) {
    var _a;
    const [x, C] = v.useState(false), l = Z[s.matchType] || "Similar", I = Math.round(s.similarity * 100), j = (a) => {
      g(s.id, {
        keepSourceId: a,
        action: "delete"
      });
    }, b = () => {
      g(s.id, {
        action: "skip",
        keepSourceId: null
      });
    }, o = (h == null ? void 0 : h.action) === "skip";
    return e.jsxs("div", {
      className: `border border-gray-200 rounded-lg overflow-hidden ${o ? "opacity-60" : ""}`,
      children: [
        e.jsxs("div", {
          className: "w-full flex items-center justify-between p-2.5 bg-gray-50",
          children: [
            e.jsxs("button", {
              onClick: () => C(!x),
              className: "flex items-center gap-2 min-w-0 flex-1 text-left hover:bg-gray-100 -m-1 p-1 rounded",
              children: [
                x ? e.jsx(Q, {
                  className: "w-4 h-4 text-gray-400 flex-shrink-0"
                }) : e.jsx(V, {
                  className: "w-4 h-4 text-gray-400 flex-shrink-0"
                }),
                e.jsx("span", {
                  className: "text-xs font-medium text-gray-900 truncate",
                  children: ((_a = s.sources[0]) == null ? void 0 : _a.title) || "Untitled"
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2 flex-shrink-0 ml-2",
              children: [
                e.jsxs("span", {
                  className: "text-xs text-gray-500",
                  children: [
                    I,
                    "%"
                  ]
                }),
                e.jsx("span", {
                  className: "text-xs text-gray-400",
                  children: "\u2022"
                }),
                e.jsxs("span", {
                  className: "text-xs text-gray-500",
                  children: [
                    s.sources.length,
                    " sources"
                  ]
                }),
                e.jsx("button", {
                  onClick: (a) => {
                    a.stopPropagation(), b();
                  },
                  className: `text-xs px-2 py-0.5 rounded ml-2 ${o ? "bg-gray-200 text-gray-600" : "text-gray-500 hover:bg-gray-100 hover:text-gray-700"}`,
                  children: o ? "Skipped" : "Skip"
                })
              ]
            })
          ]
        }),
        x && e.jsxs("div", {
          className: "p-3 space-y-2 border-t border-gray-200",
          children: [
            e.jsx("div", {
              className: "mb-2",
              children: e.jsx("span", {
                className: "text-xs text-gray-500",
                children: l
              })
            }),
            s.sources.map((a, S) => {
              const n = !o && (h == null ? void 0 : h.keepSourceId) === a.id, p = S === 0, r = S === s.sources.length - 1;
              return e.jsxs("label", {
                className: `flex items-start gap-2 p-2 rounded-md cursor-pointer ${n ? "bg-green-50 border border-green-200" : "hover:bg-gray-50"} ${o ? "opacity-50" : ""}`,
                children: [
                  e.jsx("input", {
                    type: "radio",
                    name: `group-${s.id}`,
                    checked: n,
                    onChange: () => j(a.id),
                    disabled: o,
                    className: "mt-0.5 h-3.5 w-3.5 border-gray-300 text-green-600 focus:ring-green-500"
                  }),
                  e.jsxs("div", {
                    className: "flex-1 min-w-0",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                          e.jsx("span", {
                            className: `text-xs font-medium ${n ? "text-green-700" : "text-gray-900"}`,
                            children: n ? "Keep" : "Remove"
                          }),
                          e.jsx("span", {
                            className: "text-xs text-gray-900 truncate",
                            children: a.title
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2 mt-0.5",
                        children: [
                          e.jsx("span", {
                            className: "text-xs text-gray-400",
                            children: new Date(a.createdAt).toLocaleDateString()
                          }),
                          p && e.jsx("span", {
                            className: `text-xs px-1 rounded ${i === "oldest" ? "text-green-600 bg-green-50 dark:text-green-400 dark:bg-green-900/30" : "text-gray-400 bg-gray-100 dark:text-slate-500 dark:bg-slate-700"}`,
                            children: "oldest"
                          }),
                          r && s.sources.length > 1 && e.jsx("span", {
                            className: `text-xs px-1 rounded ${i === "newest" ? "text-green-600 bg-green-50 dark:text-green-400 dark:bg-green-900/30" : "text-gray-400 bg-gray-100 dark:text-slate-500 dark:bg-slate-700"}`,
                            children: "newest"
                          }),
                          a.url && e.jsx("span", {
                            className: "text-xs text-gray-400 truncate max-w-[150px]",
                            children: q(a.url)
                          })
                        ]
                      })
                    ]
                  })
                ]
              }, a.id);
            })
          ]
        })
      ]
    });
  }
  function te({ groups: s, selectedGroups: h, onUpdateSelection: g, keepPreference: i }) {
    return !s || s.length === 0 ? e.jsx("div", {
      className: "text-center py-4",
      children: e.jsx("p", {
        className: "text-xs text-gray-500",
        children: "No duplicate groups found"
      })
    }) : e.jsx("div", {
      className: "space-y-2 max-h-64 overflow-y-auto",
      children: s.map((x) => e.jsx(ee, {
        group: x,
        selection: h[x.id],
        onUpdateSelection: g,
        keepPreference: i
      }, x.id))
    });
  }
  const t = {
    OPTIONS: "options",
    SCANNING: "scanning",
    REVIEW: "review",
    CONFIRM: "confirm",
    SUCCESS: "success"
  };
  xe = function({ isOpen: s, onClose: h, notebook: g, sources: i = [], onSuccess: x }) {
    const [C, l] = z(), { duplicateScan: I } = C, { isScanning: j, progress: b, scanOptions: o, duplicateGroups: a, selectedGroups: S, isExecuting: n, executionResults: p } = I, [r, m] = v.useState(t.OPTIONS), [k, w] = v.useState("fast"), [D, O] = v.useState("oldest");
    v.useEffect(() => {
      s && i.length > 0 && (m(t.OPTIONS), w("fast"), O("oldest"), l.resetDuplicateScan());
    }, [
      s
    ]);
    const F = (d) => {
      O(d), a.forEach((c) => {
        const f = c.sources, y = d === "newest" ? f[f.length - 1].id : f[0].id;
        l.updateGroupSelection(c.id, {
          action: "delete",
          keepSourceId: y
        });
      });
    }, M = async (d = k) => {
      l.setScanOptions({
        matchMode: d
      }), m(t.SCANNING);
      try {
        (await l.scanForDuplicates(i, g.id)).length === 0 ? m(t.SUCCESS) : m(t.REVIEW);
      } catch (c) {
        E.error(`Scan failed: ${c.message}`), h();
      }
    }, P = () => {
      M(k);
    }, A = () => {
      w("deep"), M("deep");
    }, R = () => {
      m(t.CONFIRM);
    }, L = async () => {
      try {
        const d = await l.executeDuplicateDeletion(g.id);
        if (d.deleted > 0) {
          const c = new Set(N.keptSources.map((y) => y.id)), f = a.flatMap((y) => y.sources.map((W) => W.id)).filter((y) => !c.has(y));
          f.length > 0 && await l.bulkRemoveFromFolder(g.id, f), m(t.SUCCESS), x == null ? void 0 : x(), _(() => l.isLicensed());
        } else
          d.failed > 0 && E.error(`Failed to delete ${d.failed} sources`);
      } catch (d) {
        E.error(`Deletion failed: ${d.message}`);
      }
    }, u = () => {
      j || n || (l.resetDuplicateScan(), h());
    }, N = l.getDeletionSummary(), K = b.total > 0 ? Math.round(b.current / b.total * 100) : 0, $ = a.reduce((d, c) => d + c.sources.length - 1, 0);
    return e.jsxs(X, {
      open: s,
      onClose: u,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(H, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(J, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(B, {
                        className: "w-4 h-4"
                      }),
                      r === t.OPTIONS && "Find Duplicates",
                      r === t.SCANNING && "Find Duplicates",
                      r === t.REVIEW && `Found ${a.length} Duplicate Groups`,
                      r === t.CONFIRM && "Confirm Cleanup",
                      r === t.SUCCESS && "Cleanup Complete"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: u,
                    disabled: j || n,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(Y, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: [
                  r === t.OPTIONS && e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      e.jsx("p", {
                        className: "text-xs text-gray-600 dark:text-slate-400",
                        children: "Choose how to detect duplicates:"
                      }),
                      e.jsxs("label", {
                        className: `flex items-start gap-3 p-3 rounded-lg border cursor-pointer ${k === "fast" ? "border-gray-900 dark:border-slate-400 bg-gray-50 dark:bg-slate-900" : "border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
                        children: [
                          e.jsx("input", {
                            type: "radio",
                            name: "scanMode",
                            value: "fast",
                            checked: k === "fast",
                            onChange: () => w("fast"),
                            className: "mt-0.5 h-3.5 w-3.5 border-gray-300 text-gray-900 focus:ring-gray-900"
                          }),
                          e.jsxs("div", {
                            children: [
                              e.jsx("div", {
                                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                                children: "Fast Scan"
                              }),
                              e.jsx("p", {
                                className: "text-xs text-gray-500 dark:text-slate-400 mt-0.5",
                                children: "Match by URL and similar titles"
                              }),
                              e.jsx("p", {
                                className: "text-xs text-gray-400 dark:text-slate-500 mt-0.5",
                                children: "Instant results, no API calls"
                              })
                            ]
                          })
                        ]
                      }),
                      e.jsxs("label", {
                        className: `flex items-start gap-3 p-3 rounded-lg border cursor-pointer ${k === "deep" ? "border-gray-900 dark:border-slate-400 bg-gray-50 dark:bg-slate-900" : "border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
                        children: [
                          e.jsx("input", {
                            type: "radio",
                            name: "scanMode",
                            value: "deep",
                            checked: k === "deep",
                            onChange: () => w("deep"),
                            className: "mt-0.5 h-3.5 w-3.5 border-gray-300 text-gray-900 focus:ring-gray-900"
                          }),
                          e.jsxs("div", {
                            children: [
                              e.jsx("div", {
                                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                                children: "Deep Scan"
                              }),
                              e.jsx("p", {
                                className: "text-xs text-gray-500 dark:text-slate-400 mt-0.5",
                                children: "Also compare source content"
                              }),
                              e.jsx("p", {
                                className: "text-xs text-gray-400 dark:text-slate-500 mt-0.5",
                                children: "Slower - fetches all source content"
                              })
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  r === t.SCANNING && e.jsx("div", {
                    className: "space-y-4",
                    children: e.jsxs("div", {
                      className: "flex flex-col items-center py-6",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-2 mb-4",
                          children: [
                            e.jsx(T, {
                              size: "sm"
                            }),
                            e.jsxs("span", {
                              className: "text-sm font-medium text-gray-700 dark:text-slate-300",
                              children: [
                                "Scanning ",
                                i.length,
                                " sources..."
                              ]
                            })
                          ]
                        }),
                        e.jsxs("div", {
                          className: "w-full max-w-xs",
                          children: [
                            e.jsx("div", {
                              className: "w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2",
                              children: e.jsx("div", {
                                className: "bg-gray-900 h-2 rounded-full transition-all duration-300",
                                style: {
                                  width: `${K}%`
                                }
                              })
                            }),
                            e.jsx("p", {
                              className: "text-xs text-gray-500 dark:text-slate-400 mt-2 text-center",
                              children: b.message || (o.matchMode === "deep" ? "Fetching and comparing content" : "Comparing titles and URLs")
                            })
                          ]
                        })
                      ]
                    })
                  }),
                  r === t.REVIEW && a.length > 0 && e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      e.jsxs("div", {
                        className: "bg-gray-50 dark:bg-slate-900 p-4 rounded-lg border border-gray-200 dark:border-slate-700 text-center",
                        children: [
                          e.jsx("span", {
                            className: "inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-slate-300 mb-2",
                            children: o.matchMode === "deep" ? "Deep Scan" : "Fast Scan"
                          }),
                          e.jsxs("p", {
                            className: "text-sm font-medium text-gray-900 dark:text-slate-100 mb-1",
                            children: [
                              $ + a.length,
                              " sources can be cleaned up"
                            ]
                          }),
                          e.jsxs("p", {
                            className: "text-xs text-gray-500 dark:text-slate-400 mb-3",
                            children: [
                              "Keep ",
                              a.length,
                              " originals, remove ",
                              $,
                              " duplicates"
                            ]
                          }),
                          e.jsx("button", {
                            onClick: R,
                            className: "px-4 py-2 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200",
                            children: "Clean Up Duplicates"
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "border-t border-gray-200 dark:border-slate-700 pt-3",
                        children: [
                          e.jsx("p", {
                            className: "text-xs text-gray-600 dark:text-slate-400 mb-2",
                            children: "Default keep preference:"
                          }),
                          e.jsxs("div", {
                            className: "flex rounded-md border border-gray-200 dark:border-slate-700 p-0.5 bg-gray-50 dark:bg-slate-900 mb-3",
                            children: [
                              e.jsx("button", {
                                onClick: () => F("oldest"),
                                className: `flex-1 px-3 py-1.5 text-xs font-medium rounded ${D === "oldest" ? "bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-100 shadow-sm" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"}`,
                                children: "Keep Oldest"
                              }),
                              e.jsx("button", {
                                onClick: () => F("newest"),
                                className: `flex-1 px-3 py-1.5 text-xs font-medium rounded ${D === "newest" ? "bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-100 shadow-sm" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"}`,
                                children: "Keep Newest"
                              })
                            ]
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx("p", {
                            className: "text-xs text-gray-500 dark:text-slate-400 mb-3",
                            children: "Or review individually:"
                          }),
                          e.jsx(te, {
                            groups: a,
                            selectedGroups: S,
                            keepPreference: D,
                            onUpdateSelection: (d, c) => l.updateGroupSelection(d, c)
                          })
                        ]
                      })
                    ]
                  }),
                  r === t.CONFIRM && e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      e.jsxs("div", {
                        className: "bg-amber-50 dark:bg-amber-950 p-4 rounded-lg border border-amber-200 dark:border-amber-800",
                        children: [
                          e.jsx("p", {
                            className: "text-sm font-medium text-amber-800 dark:text-amber-200 mb-2",
                            children: "This will permanently delete:"
                          }),
                          e.jsxs("p", {
                            className: "text-2xl font-bold text-amber-900 dark:text-amber-100",
                            children: [
                              N.toDelete,
                              " duplicates"
                            ]
                          }),
                          e.jsx("p", {
                            className: "text-xs text-amber-700 dark:text-amber-300 mt-2",
                            children: "This action cannot be undone. Deleted sources cannot be restored."
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsxs("p", {
                            className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-2",
                            children: [
                              "The following ",
                              N.toKeep,
                              " sources will be kept:"
                            ]
                          }),
                          e.jsx("div", {
                            className: "max-h-32 overflow-y-auto space-y-1 bg-gray-50 dark:bg-slate-900 p-2 rounded-md border border-gray-200 dark:border-slate-700",
                            children: N.keptSources.map((d) => e.jsxs("div", {
                              className: "text-xs text-gray-600 dark:text-slate-400 truncate",
                              children: [
                                "\u2022 ",
                                d.title || "Untitled"
                              ]
                            }, d.id))
                          })
                        ]
                      }),
                      e.jsx("div", {
                        className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                        children: e.jsxs("p", {
                          className: "text-xs text-blue-700 dark:text-blue-300",
                          children: [
                            e.jsx("span", {
                              className: "font-medium",
                              children: "Tip:"
                            }),
                            " Export a backup first if you're unsure. Use the Backup/Restore button on the notebook page."
                          ]
                        })
                      }),
                      n && e.jsxs("div", {
                        className: "flex items-center gap-2 p-3 bg-gray-50 dark:bg-slate-900 rounded-lg border border-gray-200 dark:border-slate-700",
                        children: [
                          e.jsx(T, {
                            size: "sm"
                          }),
                          e.jsx("span", {
                            className: "text-xs text-gray-700 dark:text-slate-300",
                            children: b.message
                          })
                        ]
                      })
                    ]
                  }),
                  r === t.SUCCESS && e.jsx("div", {
                    className: "py-8 text-center",
                    children: p.deleted > 0 ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx("div", {
                          className: "w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4",
                          children: e.jsx(U, {
                            className: "w-6 h-6 text-green-600 dark:text-green-400"
                          })
                        }),
                        e.jsx("p", {
                          className: "text-sm font-medium text-gray-900 dark:text-slate-100 mb-1",
                          children: "Successfully cleaned up!"
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-gray-500 dark:text-slate-400 mb-4",
                          children: [
                            p.deleted,
                            " duplicates removed",
                            p.failed > 0 && `, ${p.failed} failed`
                          ]
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-gray-400 dark:text-slate-500",
                          children: [
                            "Your notebook now has ",
                            i.length - p.deleted,
                            " unique sources"
                          ]
                        })
                      ]
                    }) : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx("div", {
                          className: "w-12 h-12 bg-gray-100 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4",
                          children: e.jsx(U, {
                            className: "w-6 h-6 text-gray-600 dark:text-slate-400"
                          })
                        }),
                        e.jsx("p", {
                          className: "text-sm font-medium text-gray-900 dark:text-slate-100 mb-1",
                          children: "No duplicates found"
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-gray-500 dark:text-slate-400 mb-4",
                          children: [
                            "All ",
                            i.length,
                            " sources in this notebook appear to be unique."
                          ]
                        }),
                        o.matchMode === "fast" && e.jsxs("div", {
                          className: "border-t border-gray-200 dark:border-slate-700 pt-4 mt-4",
                          children: [
                            e.jsx("p", {
                              className: "text-xs text-gray-500 dark:text-slate-400 mb-2",
                              children: "Want to check content similarity too?"
                            }),
                            e.jsx("button", {
                              onClick: A,
                              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                              children: "Enable Deep Scan"
                            })
                          ]
                        })
                      ]
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-between",
                children: [
                  e.jsx("div", {
                    children: r === t.CONFIRM && !n && e.jsx("button", {
                      onClick: () => m(t.REVIEW),
                      className: "px-3 py-1.5 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50",
                      children: "Back"
                    })
                  }),
                  e.jsxs("div", {
                    className: "flex gap-2",
                    children: [
                      r === t.OPTIONS && e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("button", {
                            onClick: u,
                            className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                            children: "Cancel"
                          }),
                          e.jsx("button", {
                            onClick: P,
                            className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200",
                            children: "Start Scan"
                          })
                        ]
                      }),
                      r === t.SCANNING && e.jsx("button", {
                        onClick: u,
                        disabled: j,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50",
                        children: "Cancel"
                      }),
                      r === t.REVIEW && e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("button", {
                            onClick: () => m(t.OPTIONS),
                            className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                            children: "\u2190 Scan Again"
                          }),
                          e.jsx("button", {
                            onClick: u,
                            className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                            children: "Skip All"
                          }),
                          e.jsxs("button", {
                            onClick: R,
                            disabled: N.toDelete === 0,
                            className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 disabled:opacity-50 flex items-center gap-1.5",
                            children: [
                              e.jsx(G, {
                                className: "w-3.5 h-3.5"
                              }),
                              "Clean Up Selected"
                            ]
                          })
                        ]
                      }),
                      r === t.CONFIRM && e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("button", {
                            onClick: u,
                            disabled: n,
                            className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
                            children: "Cancel"
                          }),
                          e.jsxs("button", {
                            onClick: L,
                            disabled: n,
                            className: "px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 flex items-center gap-1.5",
                            children: [
                              e.jsx(G, {
                                className: "w-3.5 h-3.5"
                              }),
                              n ? "Deleting..." : `Delete ${N.toDelete} Duplicates`
                            ]
                          })
                        ]
                      }),
                      r === t.SUCCESS && e.jsx("button", {
                        onClick: u,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200",
                        children: "Done"
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  xe as default
};
