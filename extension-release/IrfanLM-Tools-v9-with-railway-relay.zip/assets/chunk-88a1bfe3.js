import { u as P, r as c, j as e, U as E, W as $, Z as z, _ as Z, J as B, a0 as O, X, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { S as h, y as w, B as H, ag as W, G as D, J as G, w as V, M as J, P as R, O as Q, V as Y, U as q, a4 as U, W as _, X as K, ah as ee, l as M, ai as se, aj as te, i as ae, z as re, Q as le, a3 as ne, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { P as ie, F as de, __tla as __tla_2 } from "./chunk-602992a9.js";
import { A as oe, __tla as __tla_3 } from "./chunk-5a4465c9.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let Se;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  let ce, xe, ue, me, be, ge, he;
  ce = ({ notebook: l, onSuccess: x }) => {
    const [n, s] = P(), { isAdding: a, addSuccess: t, error: u, progressMessage: r, progressPercent: o } = n.notebookActions, [m, i] = c.useState(""), d = async () => {
      if (!(!m.trim() || !(l == null ? void 0 : l.id)))
        try {
          await s.addTextContentToNotebook(m.trim(), l.id) && (i(""), setTimeout(() => {
            x == null ? void 0 : x();
          }, 1500));
        } catch (b) {
          console.error("Failed to add to notebook:", b);
        }
    }, p = m.trim();
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1",
              children: "Content"
            }),
            e.jsx("textarea", {
              value: m,
              onChange: (b) => i(b.target.value),
              placeholder: "Paste your content here...",
              disabled: a || t,
              rows: 10,
              className: "w-full px-3 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-100 focus:border-neutral-900 dark:focus:border-slate-400 disabled:opacity-50 disabled:bg-neutral-50 dark:disabled:bg-slate-900 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 placeholder-neutral-400 dark:placeholder-slate-500 resize-none"
            }),
            m && e.jsxs("p", {
              className: "text-xs text-neutral-500 dark:text-neutral-400 mt-1",
              children: [
                m.length,
                " characters"
              ]
            })
          ]
        }),
        a && r && e.jsx(h, {
          type: "progress",
          message: r,
          progress: o
        }),
        t && e.jsx(h, {
          type: "success",
          message: "Added to notebook"
        }),
        u && e.jsx(h, {
          type: "error",
          message: u
        }),
        e.jsx(w, {
          onClick: d,
          disabled: !p || a || t || !(l == null ? void 0 : l.id),
          isLoading: a,
          isSuccess: t,
          loadingText: "Adding...",
          successText: "Added",
          children: "Add to notebook"
        })
      ]
    });
  };
  xe = ({ notebook: l, onSuccess: x }) => {
    const [n, s] = P(), { isExtracting: a, links: t, error: u } = n.linksExtractor, { isAdding: r, addSuccess: o, error: m, progressMessage: i, progressPercent: d, failedLinks: p, totalLinks: b } = n.batchNotebookActions, [v, y] = c.useState(""), [k, f] = c.useState(""), [g, j] = c.useState("");
    c.useEffect(() => {
      t.length > 0 && y(t.join(`
`));
    }, [
      t
    ]);
    const F = (N) => {
      s.setLinks(N);
    }, L = (N) => {
      y(N.join(`
`)), s.setLinks(N);
    }, A = async () => {
      const N = g.trim();
      if (N) {
        try {
          new URL(N);
        } catch {
          s.setLinks([]), y("");
          return;
        }
        try {
          await s.extractFromSitemap(N);
        } catch (I) {
          console.error("Failed to extract sitemap:", I);
        }
      }
    }, C = async () => {
      const N = v.split(`
`).filter((I) => I.trim());
      if (!(N.length === 0 || !(l == null ? void 0 : l.id)))
        try {
          await s.addLinksToNotebook(N, l.id) && setTimeout(() => {
            y(""), j(""), f(""), s.setLinks([]), x == null ? void 0 : x(), E(() => s.isLicensed());
          }, 1500);
        } catch (I) {
          console.error("Failed to add to notebook:", I);
        }
    }, T = k === "" ? t : H(t, k), S = k === "" ? v : T.join(`
`);
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300",
              children: "Extract from Sitemap"
            }),
            e.jsxs("div", {
              className: "flex gap-2",
              children: [
                e.jsx("input", {
                  type: "url",
                  value: g,
                  onChange: (N) => j(N.target.value),
                  placeholder: "https://example.com/sitemap.xml",
                  disabled: a || r,
                  className: "flex-1 px-3 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-100 focus:border-neutral-900 dark:focus:border-slate-400 disabled:opacity-50 disabled:bg-neutral-50 dark:disabled:bg-slate-900 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 placeholder-neutral-400 dark:placeholder-slate-500"
                }),
                e.jsxs("button", {
                  onClick: A,
                  disabled: !g.trim() || a || r,
                  className: "px-3 py-2 text-xs font-medium text-white bg-neutral-900 rounded-md hover:bg-neutral-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5",
                  children: [
                    e.jsx(W, {
                      className: "w-3.5 h-3.5"
                    }),
                    "Extract"
                  ]
                })
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "relative",
          children: [
            e.jsx("div", {
              className: "absolute inset-0 flex items-center",
              children: e.jsx("div", {
                className: "w-full border-t border-neutral-200 dark:border-slate-600"
              })
            }),
            e.jsx("div", {
              className: "relative flex justify-center",
              children: e.jsx("span", {
                className: "px-2 text-xs text-neutral-500 dark:text-neutral-400 bg-white dark:bg-slate-900",
                children: "or paste links directly"
              })
            })
          ]
        }),
        u && e.jsx(h, {
          type: "error",
          message: u
        }),
        e.jsxs("div", {
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between mb-1",
              children: [
                e.jsx("label", {
                  className: "text-xs font-medium text-neutral-700 dark:text-neutral-300",
                  children: "Links"
                }),
                t.length > 0 && e.jsx("span", {
                  className: "px-1.5 py-0.5 bg-neutral-100 dark:bg-slate-700 rounded text-xs font-medium text-neutral-700 dark:text-neutral-300",
                  children: k === "" ? t.length : T.length
                })
              ]
            }),
            t.length > 0 && !a && e.jsx(D, {
              links: t,
              linkFilter: k,
              setLinkFilter: f,
              onApplyFilter: L,
              disabled: r
            }),
            e.jsx(G, {
              links: t,
              linksText: S,
              setLinksText: y,
              onLinksChange: F,
              disabled: r || k !== "" || o || a,
              placeholder: a ? "Extracting links..." : "Paste URLs here (one per line)",
              rows: 8,
              showTools: t.length > 0 && !a
            })
          ]
        }),
        a && e.jsx(h, {
          type: "progress",
          message: "Extracting links from sitemap..."
        }),
        r && i && e.jsx(h, {
          type: "progress",
          message: i,
          progress: d
        }),
        o && e.jsx("div", {
          className: "px-2.5 py-2 bg-green-50 dark:bg-green-950 rounded-md border border-green-200 dark:border-green-800",
          children: e.jsxs("div", {
            className: "flex items-start gap-2",
            children: [
              e.jsx(V, {
                className: "w-4 h-4 text-green-600 flex-shrink-0"
              }),
              e.jsxs("div", {
                className: "flex-1 min-w-0",
                children: [
                  e.jsx("p", {
                    className: "text-xs font-medium text-green-900 dark:text-green-100",
                    children: "Links added"
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-green-700 dark:text-green-300 mt-0.5",
                    children: [
                      b - ((p == null ? void 0 : p.length) || 0),
                      " of ",
                      b,
                      " links processed",
                      (p == null ? void 0 : p.length) > 0 && ` \xB7 ${p.length} failed`
                    ]
                  })
                ]
              })
            ]
          })
        }),
        m && e.jsx(h, {
          type: "error",
          message: m
        }),
        !o && t.length > 0 && !a && e.jsxs(w, {
          onClick: C,
          disabled: r || !(l == null ? void 0 : l.id),
          isLoading: r,
          isSuccess: o,
          loadingText: "Adding links...",
          successText: "Added",
          children: [
            "Add ",
            t.length,
            " ",
            t.length === 1 ? "link" : "links",
            " to notebook"
          ]
        })
      ]
    });
  };
  ue = ({ notebook: l, onSuccess: x }) => {
    const [n, s] = P(), [a, t] = c.useState(""), { isParsing: u, parseError: r, videos: o, playlistInfo: m } = n.playlistImport, { isAdding: i, addSuccess: d, error: p, progressMessage: b, progressPercent: v, failedLinks: y, totalLinks: k } = n.batchNotebookActions, { selectedVideoIds: f, addToExistingNotebook: g } = J();
    c.useEffect(() => () => {
      s.resetPlaylistImport();
    }, []), c.useEffect(() => {
      if (d) {
        const T = setTimeout(() => {
          t(""), s.resetPlaylistImport(), x == null ? void 0 : x(), E(() => s.isLicensed());
        }, 1500);
        return () => clearTimeout(T);
      }
    }, [
      d,
      x
    ]);
    const j = async () => {
      const T = a.trim();
      !T || !$(T) || await s.parsePlaylist(T);
    }, F = async () => {
      (l == null ? void 0 : l.id) && await g(l.id);
    }, L = $(a), A = L && !u, C = f.length > 0;
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300",
              children: "YouTube Playlist URL"
            }),
            e.jsxs("div", {
              className: "relative",
              children: [
                e.jsx("input", {
                  type: "url",
                  value: a,
                  onChange: (T) => t(T.target.value),
                  placeholder: "https://www.youtube.com/playlist?list=...",
                  disabled: u || i,
                  className: "w-full pl-8 pr-3 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-100 focus:border-neutral-900 dark:focus:border-slate-400 disabled:opacity-50 disabled:bg-neutral-50 dark:disabled:bg-slate-900 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 placeholder-neutral-400 dark:placeholder-slate-500"
                }),
                e.jsx(R, {
                  className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-red-500"
                })
              ]
            }),
            a && !L && e.jsx("p", {
              className: "text-xs text-amber-600",
              children: "Enter a valid YouTube playlist URL"
            }),
            !o.length && e.jsx(w, {
              onClick: j,
              disabled: !A,
              isLoading: u,
              loadingText: "Parsing...",
              icon: R,
              children: "Parse Playlist"
            })
          ]
        }),
        r && e.jsx(h, {
          type: "error",
          message: r
        }),
        m && o.length > 0 && e.jsxs(e.Fragment, {
          children: [
            e.jsx(Q, {}),
            e.jsx(Y, {})
          ]
        }),
        i && b && e.jsx(h, {
          type: "progress",
          message: b,
          progress: v
        }),
        d && e.jsx(ie, {
          actionType: "existing",
          totalLinks: k,
          failedLinks: y
        }),
        p && e.jsx(h, {
          type: "error",
          message: p
        }),
        !d && C && e.jsxs(w, {
          onClick: F,
          disabled: i || !(l == null ? void 0 : l.id),
          isLoading: i,
          isSuccess: d,
          loadingText: "Adding videos...",
          successText: "Added",
          children: [
            "Add ",
            f.length,
            " ",
            f.length === 1 ? "video" : "videos",
            " to notebook"
          ]
        })
      ]
    });
  };
  me = ({ notebook: l, onSuccess: x }) => {
    const [n, s] = P(), [a, t] = c.useState(""), { isParsing: u, parseError: r, articles: o, feedInfo: m } = n.rssImport, { isAdding: i, addSuccess: d, error: p, progressMessage: b, progressPercent: v, failedLinks: y, totalLinks: k } = n.batchNotebookActions, { selectedArticleIds: f, addToExistingNotebook: g } = q();
    c.useEffect(() => () => {
      s.resetRSSImport();
    }, []), c.useEffect(() => {
      if (d) {
        const S = setTimeout(() => {
          t(""), s.resetRSSImport(), x == null ? void 0 : x(), E(() => s.isLicensed());
        }, 1500);
        return () => clearTimeout(S);
      }
    }, [
      d,
      x
    ]);
    const j = async () => {
      const S = z(a.trim());
      !S || !Z(S) || await s.parseFeed(S);
    }, F = async () => {
      (l == null ? void 0 : l.id) && await g(l.id);
    }, L = z(a), A = Z(L), C = A && !u, T = f.length > 0;
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300",
              children: "RSS/Atom Feed URL"
            }),
            e.jsxs("div", {
              className: "relative",
              children: [
                e.jsx("input", {
                  type: "url",
                  value: a,
                  onChange: (S) => t(S.target.value),
                  placeholder: "https://example.com/feed.xml",
                  disabled: u || i,
                  className: "w-full pl-8 pr-3 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-100 focus:border-neutral-900 dark:focus:border-slate-400 disabled:opacity-50 disabled:bg-neutral-50 dark:disabled:bg-slate-900 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 placeholder-neutral-400 dark:placeholder-slate-500"
                }),
                e.jsx(U, {
                  className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-500"
                })
              ]
            }),
            a && !A && e.jsx("p", {
              className: "text-xs text-amber-600",
              children: "Enter a valid feed URL"
            }),
            !o.length && e.jsx(w, {
              onClick: j,
              disabled: !C,
              isLoading: u,
              loadingText: "Parsing...",
              icon: U,
              children: "Parse Feed"
            })
          ]
        }),
        r && e.jsx(h, {
          type: "error",
          message: r
        }),
        m && o.length > 0 && e.jsxs(e.Fragment, {
          children: [
            e.jsx(_, {}),
            e.jsx(K, {})
          ]
        }),
        i && b && e.jsx(h, {
          type: "progress",
          message: b,
          progress: v
        }),
        d && e.jsx(de, {
          actionType: "existing",
          totalLinks: k,
          failedLinks: y
        }),
        p && e.jsx(h, {
          type: "error",
          message: p
        }),
        !d && T && e.jsxs(w, {
          onClick: F,
          disabled: i || !(l == null ? void 0 : l.id),
          isLoading: i,
          isSuccess: d,
          loadingText: "Adding articles...",
          successText: "Added",
          children: [
            "Add ",
            f.length,
            " ",
            f.length === 1 ? "article" : "articles",
            " ",
            "to notebook"
          ]
        })
      ]
    });
  };
  be = ({ actionType: l, totalLinks: x, failedLinks: n }) => {
    const s = (n == null ? void 0 : n.length) || 0, a = x - s, t = l === "new" ? "Notebook created" : "Tabs added";
    return e.jsx("div", {
      className: "px-2.5 py-2 bg-green-50 dark:bg-green-950 rounded-md border border-green-200 dark:border-green-800",
      children: e.jsxs("div", {
        className: "flex items-start gap-2",
        children: [
          e.jsx(V, {
            className: "w-4 h-4 text-green-600 flex-shrink-0"
          }),
          e.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              e.jsx("p", {
                className: "text-xs font-medium text-green-900 dark:text-green-100",
                children: t
              }),
              e.jsxs("p", {
                className: "text-xs text-green-700 dark:text-green-300 mt-0.5",
                children: [
                  a,
                  " of ",
                  x,
                  " tabs imported",
                  s > 0 && ` \xB7 ${s} failed`
                ]
              })
            ]
          })
        ]
      })
    });
  };
  ge = ({ notebook: l, onSuccess: x }) => {
    const [n, s] = P(), { isFetching: a, fetchError: t, tabs: u } = n.openTabsImport, { isAdding: r, addSuccess: o, error: m, progressMessage: i, progressPercent: d, failedLinks: p, totalLinks: b } = n.batchNotebookActions, { selectedTabIds: v, addToExistingNotebook: y } = ee();
    c.useEffect(() => (s.fetchOpenTabs(), () => {
      s.resetOpenTabsImport();
    }), []), c.useEffect(() => {
      if (o) {
        const j = setTimeout(() => {
          s.resetOpenTabsImport(), x == null ? void 0 : x(), E(() => s.isLicensed());
        }, 1500);
        return () => clearTimeout(j);
      }
    }, [
      o,
      x
    ]);
    const k = async () => {
      await s.fetchOpenTabs();
    }, f = async () => {
      (l == null ? void 0 : l.id) && await y(l.id);
    }, g = v.length > 0;
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        u.length === 0 && !a && e.jsxs("div", {
          className: "text-center py-4",
          children: [
            e.jsx(M, {
              className: "w-8 h-8 text-neutral-400 mx-auto mb-2"
            }),
            e.jsx("p", {
              className: "text-xs text-neutral-600 dark:text-neutral-400 mb-3",
              children: "Import pages from your currently open browser tabs"
            }),
            e.jsx(w, {
              onClick: k,
              disabled: a,
              isLoading: a,
              loadingText: "Fetching...",
              icon: M,
              children: "Fetch Open Tabs"
            })
          ]
        }),
        a && e.jsx("div", {
          className: "text-center py-4",
          children: e.jsx("p", {
            className: "text-xs text-neutral-600 dark:text-neutral-400",
            children: "Fetching open tabs..."
          })
        }),
        t && e.jsx(h, {
          type: "error",
          message: t
        }),
        u.length > 0 && e.jsxs(e.Fragment, {
          children: [
            e.jsx("div", {
              className: "flex items-center justify-between",
              children: e.jsx(se, {})
            }),
            e.jsx(te, {}),
            e.jsx("button", {
              onClick: k,
              disabled: a || r,
              className: "text-xs text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-200 underline disabled:opacity-50",
              children: "Refresh tabs"
            })
          ]
        }),
        r && i && e.jsx(h, {
          type: "progress",
          message: i,
          progress: d
        }),
        o && e.jsx(be, {
          actionType: "existing",
          totalLinks: b,
          failedLinks: p
        }),
        m && e.jsx(h, {
          type: "error",
          message: m
        }),
        !o && g && e.jsxs(w, {
          onClick: f,
          disabled: r || !(l == null ? void 0 : l.id),
          isLoading: r,
          isSuccess: o,
          loadingText: "Adding tabs...",
          successText: "Added",
          children: [
            "Add ",
            v.length,
            " ",
            v.length === 1 ? "tab" : "tabs",
            " to notebook"
          ]
        })
      ]
    });
  };
  he = ({ notebook: l, onSuccess: x }) => {
    const [, n] = P(), [s, a] = c.useState(null), [t, u] = c.useState(false), [r, o] = c.useState(false), [m, i] = c.useState(null), [d, p] = c.useState({
      current: 0,
      total: 0
    }), b = c.useRef(null), v = (g) => {
      var _a;
      const j = (_a = g.target.files) == null ? void 0 : _a[0];
      if (j) {
        if (!j.name.endsWith(".zip")) {
          B.error("Please select a ZIP file");
          return;
        }
        a(j), i(null), o(false);
      }
    }, y = async () => {
      if (!(!s || !(l == null ? void 0 : l.id)))
        try {
          u(true), i(null), p({
            current: 0,
            total: 0
          });
          const g = await n.importNotebookSourcesFromZip(l.id, s, (j) => {
            p(j);
          });
          g.success > 0 ? (await n.fetchNotebookLMProjects(), o(true), B.success(`Imported ${g.success} sources${g.failed > 0 ? `, ${g.failed} failed` : ""}`), setTimeout(() => {
            x == null ? void 0 : x(), E(() => n.isLicensed());
          }, 1500)) : i("No sources were imported. Make sure the ZIP contains .md files.");
        } catch (g) {
          console.error("Failed to import from ZIP:", g), i(g.message || "Failed to import sources");
        } finally {
          u(false);
        }
    }, k = () => {
      a(null), i(null), o(false), p({
        current: 0,
        total: 0
      }), b.current && (b.current.value = "");
    }, f = d.total > 0 ? d.current / d.total * 100 : 0;
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsx("p", {
          className: "text-xs text-neutral-500 dark:text-neutral-400",
          children: "Import sources from a ZIP file containing Markdown (.md) files."
        }),
        e.jsxs("div", {
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1",
              children: "Select ZIP File"
            }),
            e.jsx("input", {
              ref: b,
              type: "file",
              accept: ".zip",
              onChange: v,
              disabled: t || r,
              className: "block w-full text-xs text-neutral-500 dark:text-neutral-400 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-medium file:bg-neutral-100 file:text-neutral-700 file:dark:bg-slate-700 file:dark:text-neutral-300 hover:file:bg-neutral-200 disabled:opacity-50"
            })
          ]
        }),
        s && !r && e.jsxs("div", {
          className: "bg-neutral-50 dark:bg-slate-800 p-3 rounded-lg border border-neutral-200 dark:border-slate-600",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2 text-xs",
              children: [
                e.jsx("span", {
                  className: "text-green-600",
                  children: "\u2713"
                }),
                e.jsx("span", {
                  className: "font-medium text-neutral-700 dark:text-neutral-300",
                  children: s.name
                })
              ]
            }),
            e.jsx("p", {
              className: "text-xs text-amber-600 mt-1",
              children: "Note: .md files will be imported as text sources"
            })
          ]
        }),
        t && d.total > 0 && e.jsx(h, {
          type: "progress",
          message: `Importing ${d.current} / ${d.total} sources...`,
          progress: f
        }),
        r && e.jsx(h, {
          type: "success",
          message: "Sources imported successfully"
        }),
        m && e.jsx(h, {
          type: "error",
          message: m
        }),
        e.jsxs("div", {
          className: "flex gap-2",
          children: [
            s && !t && !r && e.jsx("button", {
              onClick: k,
              className: "px-3 py-1.5 text-xs font-medium text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-neutral-300 dark:border-slate-600 rounded-md hover:bg-neutral-50 dark:hover:bg-slate-700",
              children: "Reset"
            }),
            e.jsx(w, {
              onClick: y,
              disabled: !s || t || r || !(l == null ? void 0 : l.id),
              isLoading: t,
              isSuccess: r,
              loadingText: "Importing...",
              successText: "Imported",
              className: "flex-1",
              children: "Import ZIP"
            })
          ]
        })
      ]
    });
  };
  Se = ({ isOpen: l, onClose: x, notebook: n }) => {
    const [s, a] = c.useState("text"), t = () => {
      a("text"), x();
    };
    return e.jsxs(ae, {
      open: l,
      onClose: t,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/30",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex items-center justify-center p-4",
          children: e.jsxs(re, {
            className: "w-full max-w-lg bg-white dark:bg-slate-800 rounded-lg shadow-xl dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between px-4 py-3 border-b border-neutral-200 dark:border-slate-700",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsx(O, {
                        className: "w-4 h-4 text-neutral-700 dark:text-slate-300"
                      }),
                      e.jsx(le, {
                        className: "text-sm font-semibold text-neutral-900 dark:text-slate-100",
                        children: "Add Source"
                      })
                    ]
                  }),
                  e.jsx("button", {
                    onClick: t,
                    className: "p-1 rounded hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-700 dark:hover:text-slate-300",
                    children: e.jsx(X, {
                      className: "w-4 h-4"
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex border-b border-neutral-200 dark:border-slate-700",
                children: [
                  e.jsx("button", {
                    onClick: () => a("text"),
                    className: `flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${s === "text" ? "text-neutral-900 dark:text-slate-100 border-b-2 border-neutral-900 dark:border-slate-100 bg-neutral-50 dark:bg-slate-900" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-800"}`,
                    children: e.jsxs("div", {
                      className: "flex items-center justify-center gap-1.5",
                      children: [
                        e.jsx(O, {
                          className: "w-3.5 h-3.5"
                        }),
                        e.jsx("span", {
                          children: "Text"
                        })
                      ]
                    })
                  }),
                  e.jsx("button", {
                    onClick: () => a("links"),
                    className: `flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${s === "links" ? "text-neutral-900 dark:text-slate-100 border-b-2 border-neutral-900 dark:border-slate-100 bg-neutral-50 dark:bg-slate-900" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-800"}`,
                    children: e.jsxs("div", {
                      className: "flex items-center justify-center gap-1.5",
                      children: [
                        e.jsx(ne, {
                          className: "w-3.5 h-3.5"
                        }),
                        e.jsx("span", {
                          children: "Links"
                        })
                      ]
                    })
                  }),
                  e.jsx("button", {
                    onClick: () => a("playlist"),
                    className: `flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${s === "playlist" ? "text-neutral-900 dark:text-slate-100 border-b-2 border-neutral-900 dark:border-slate-100 bg-neutral-50 dark:bg-slate-900" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-800"}`,
                    children: e.jsxs("div", {
                      className: "flex items-center justify-center gap-1.5",
                      children: [
                        e.jsx(R, {
                          className: "w-3.5 h-3.5 text-red-500"
                        }),
                        e.jsx("span", {
                          children: "Playlist"
                        })
                      ]
                    })
                  }),
                  e.jsx("button", {
                    onClick: () => a("rss"),
                    className: `flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${s === "rss" ? "text-neutral-900 dark:text-slate-100 border-b-2 border-neutral-900 dark:border-slate-100 bg-neutral-50 dark:bg-slate-900" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-800"}`,
                    children: e.jsxs("div", {
                      className: "flex items-center justify-center gap-1.5",
                      children: [
                        e.jsx(U, {
                          className: "w-3.5 h-3.5 text-orange-500"
                        }),
                        e.jsx("span", {
                          children: "RSS"
                        })
                      ]
                    })
                  }),
                  e.jsx("button", {
                    onClick: () => a("tabs"),
                    className: `flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${s === "tabs" ? "text-neutral-900 dark:text-slate-100 border-b-2 border-neutral-900 dark:border-slate-100 bg-neutral-50 dark:bg-slate-900" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-800"}`,
                    children: e.jsxs("div", {
                      className: "flex items-center justify-center gap-1.5",
                      children: [
                        e.jsx(M, {
                          className: "w-3.5 h-3.5 text-blue-500"
                        }),
                        e.jsx("span", {
                          children: "Tabs"
                        })
                      ]
                    })
                  }),
                  e.jsx("button", {
                    onClick: () => a("zip"),
                    className: `flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${s === "zip" ? "text-neutral-900 dark:text-slate-100 border-b-2 border-neutral-900 dark:border-slate-100 bg-neutral-50 dark:bg-slate-900" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-800"}`,
                    children: e.jsxs("div", {
                      className: "flex items-center justify-center gap-1.5",
                      children: [
                        e.jsx(oe, {
                          className: "w-3.5 h-3.5 text-purple-500"
                        }),
                        e.jsx("span", {
                          children: "ZIP"
                        })
                      ]
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "p-4 max-h-[calc(100vh-16rem)] overflow-y-auto",
                children: [
                  s === "text" && e.jsx(ce, {
                    notebook: n,
                    onSuccess: t
                  }),
                  s === "links" && e.jsx(xe, {
                    notebook: n,
                    onSuccess: t
                  }),
                  s === "playlist" && e.jsx(ue, {
                    notebook: n,
                    onSuccess: t
                  }),
                  s === "rss" && e.jsx(me, {
                    notebook: n,
                    onSuccess: t
                  }),
                  s === "tabs" && e.jsx(ge, {
                    notebook: n,
                    onSuccess: t
                  }),
                  s === "zip" && e.jsx(he, {
                    notebook: n,
                    onSuccess: t
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  Se as default
};
