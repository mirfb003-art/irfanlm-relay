import { j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { b as t, d as s, k as r, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let x;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  x = function() {
    return e.jsxs(t, {
      children: [
        e.jsx(s, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "NotebookLM Config"
          })
        }),
        e.jsxs("div", {
          className: "flex flex-col space-y-4",
          children: [
            e.jsx(r, {}),
            e.jsx("div", {
              className: "bg-white rounded-lg border border-gray-200 shadow-sm",
              children: e.jsxs("div", {
                className: "p-3",
                children: [
                  e.jsx("h2", {
                    className: "font-medium text-gray-900 dark:text-slate-100 mb-3",
                    children: "How to Configure NotebookLM"
                  }),
                  e.jsxs("div", {
                    className: "space-y-3",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-start gap-2",
                        children: [
                          e.jsx("span", {
                            className: "flex-shrink-0 w-4 h-4 bg-blue-100 text-blue-600 rounded-full text-xs flex items-center justify-center",
                            children: "1"
                          }),
                          e.jsxs("div", {
                            className: "text-xs text-gray-600",
                            children: [
                              e.jsx("strong", {
                                children: "Open NotebookLM:"
                              }),
                              " Click the button above or visit",
                              " ",
                              e.jsx("a", {
                                href: "https://notebooklm.google.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-blue-600 hover:underline",
                                children: "notebooklm.google.com"
                              })
                            ]
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-start gap-2",
                        children: [
                          e.jsx("span", {
                            className: "flex-shrink-0 w-4 h-4 bg-blue-100 text-blue-600 rounded-full text-xs flex items-center justify-center",
                            children: "2"
                          }),
                          e.jsxs("div", {
                            className: "text-xs text-gray-600",
                            children: [
                              e.jsx("strong", {
                                children: "Sign in:"
                              }),
                              " Use your Google account and create at least one project"
                            ]
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-start gap-2",
                        children: [
                          e.jsx("span", {
                            className: "flex-shrink-0 w-4 h-4 bg-blue-100 text-blue-600 rounded-full text-xs flex items-center justify-center",
                            children: "3"
                          }),
                          e.jsxs("div", {
                            className: "text-xs text-gray-600",
                            children: [
                              e.jsx("strong", {
                                children: "Connect:"
                              }),
                              ' Come back here and click "Refresh" - your account will auto-connect'
                            ]
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-start gap-2",
                        children: [
                          e.jsx("span", {
                            className: "flex-shrink-0 w-4 h-4 bg-blue-100 text-blue-600 rounded-full text-xs flex items-center justify-center",
                            children: "4"
                          }),
                          e.jsxs("div", {
                            className: "text-xs text-gray-600",
                            children: [
                              e.jsx("strong", {
                                children: "Select Project:"
                              }),
                              " Choose your active project from the dropdown"
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "mt-3 pt-3 border-t border-gray-100",
                    children: [
                      e.jsx("h3", {
                        className: "text-xs text-gray-700 mb-2",
                        children: "Multiple Accounts"
                      }),
                      e.jsxs("div", {
                        className: "text-xs text-gray-500 space-y-1",
                        children: [
                          e.jsx("div", {
                            children: '\u2022 To add another account, click the switch icon next to your email, then "Add Account"'
                          }),
                          e.jsx("div", {
                            children: "\u2022 Sign into NotebookLM with the other Google account on the opened tab - it will auto-connect"
                          }),
                          e.jsx("div", {
                            children: "\u2022 Switch between accounts using the account switcher in the sidebar"
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "mt-3 pt-3 border-t border-gray-100",
                    children: [
                      e.jsx("h3", {
                        className: "text-xs text-gray-700 mb-2",
                        children: "Troubleshooting"
                      }),
                      e.jsxs("div", {
                        className: "text-xs text-gray-500 space-y-1",
                        children: [
                          e.jsx("div", {
                            children: "\u2022 Not connecting? Make sure you're logged into NotebookLM in this browser"
                          }),
                          e.jsx("div", {
                            children: "\u2022 No projects? Create one in NotebookLM first, then refresh"
                          }),
                          e.jsx("div", {
                            children: "\u2022 Account not detected? Visit notebooklm.google.com with the correct account first"
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            })
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  x as default
};
