import { j as t, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { b as r, d as o, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { B as e, __tla as __tla_2 } from "./chunk-5518d26c.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
import { __tla as __tla_3 } from "./chunk-de7ca15a.js";
import { __tla as __tla_4 } from "./chunk-5a4465c9.js";
import { __tla as __tla_5 } from "./chunk-57988b21.js";
import { __tla as __tla_6 } from "./chunk-234b1720.js";
let d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })()
]).then(async () => {
  d = function() {
    return t.jsxs(r, {
      children: [
        t.jsx(o, {
          titleTemplate: "%s",
          children: t.jsx("title", {
            children: "Backup & Restore"
          })
        }),
        t.jsx(e, {})
      ]
    });
  };
});
export {
  __tla,
  d as default
};
