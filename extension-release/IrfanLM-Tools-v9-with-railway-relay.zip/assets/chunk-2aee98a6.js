import { r as i, j as e, J as w, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { f as S, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let T;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  function F({ title: a, titleId: t, ...c }, l) {
    return i.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: l,
      "aria-labelledby": t
    }, c), a ? i.createElement("title", {
      id: t
    }, a) : null, i.createElement("path", {
      fillRule: "evenodd",
      d: "M9.47 6.47a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 1 1-1.06 1.06L10 8.06l-3.72 3.72a.75.75 0 0 1-1.06-1.06l4.25-4.25Z",
      clipRule: "evenodd"
    }));
  }
  const R = i.forwardRef(F), E = R, f = (a) => /^-?\d[\d,]*\.?\d*%?$/.test(String(a ?? "").trim());
  function D(a, t) {
    const c = (d) => {
      const n = String(d ?? "");
      return n.includes(",") || n.includes('"') || n.includes(`
`) ? `"${n.replace(/"/g, '""')}"` : n;
    }, l = [];
    a.length > 0 && l.push(a.map(c).join(","));
    for (const d of t)
      l.push(d.map(c).join(","));
    navigator.clipboard.writeText(l.join(`
`)).then(() => w.success("Copied as CSV")).catch(() => w.error("Failed to copy"));
  }
  T = function({ content: a }) {
    const [t, c] = i.useState(null), [l, d] = i.useState("asc"), [n, v] = i.useState("");
    if (!a)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "No table data available."
      });
    const { headers: u = [], rows: r = [] } = a;
    if (u.length === 0 && r.length === 0)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "Could not parse table structure."
      });
    const y = u.length || (r[0] ? r[0].length : 0), j = (s) => {
      t === s ? l === "asc" ? d("desc") : (c(null), d("asc")) : (c(s), d("asc"));
    }, h = i.useMemo(() => {
      const s = n.toLowerCase(), o = s ? r.filter((x) => x.some((g) => String(g).toLowerCase().includes(s))) : r;
      return t === null ? o : [
        ...o
      ].sort((x, g) => {
        const m = x[t], b = g[t], N = f(m), C = f(b);
        let p;
        return N && C ? p = parseFloat(String(m).replace(/[,%]/g, "")) - parseFloat(String(b).replace(/[,%]/g, "")) : p = String(m ?? "").localeCompare(String(b ?? "")), l === "asc" ? p : -p;
      });
    }, [
      r,
      n,
      t,
      l
    ]), k = h.length !== r.length;
    return e.jsxs("div", {
      className: "space-y-2",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("input", {
              type: "text",
              value: n,
              onChange: (s) => v(s.target.value),
              placeholder: "Filter...",
              className: "w-full px-2 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
            }),
            e.jsx("button", {
              onClick: () => D(u, r),
              className: "px-2 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-50 dark:hover:bg-slate-700 whitespace-nowrap",
              children: "Copy as CSV"
            })
          ]
        }),
        k && e.jsxs("p", {
          className: "text-[10px] text-gray-400 dark:text-slate-500",
          children: [
            "Showing ",
            h.length,
            " of ",
            r.length,
            " rows"
          ]
        }),
        e.jsx("div", {
          className: "overflow-x-auto border border-gray-200 dark:border-slate-700 rounded",
          children: e.jsx("div", {
            className: "max-h-[60vh] overflow-y-auto",
            children: e.jsxs("table", {
              className: "min-w-full divide-y divide-gray-200 dark:divide-slate-700",
              children: [
                u.length > 0 && e.jsx("thead", {
                  className: "bg-gray-50 dark:bg-slate-900 sticky top-0 z-10 shadow-[0_1px_0_0_rgb(229,231,235)]",
                  children: e.jsx("tr", {
                    children: u.map((s, o) => e.jsx("th", {
                      onClick: () => j(o),
                      className: "px-3 py-2 text-left text-xs font-bold text-gray-700 dark:text-slate-300 whitespace-nowrap cursor-pointer select-none",
                      children: e.jsxs("span", {
                        className: "inline-flex items-center gap-0.5",
                        children: [
                          s,
                          t === o && (l === "asc" ? e.jsx(E, {
                            className: "w-3 h-3"
                          }) : e.jsx(S, {
                            className: "w-3 h-3"
                          }))
                        ]
                      })
                    }, o))
                  })
                }),
                e.jsx("tbody", {
                  className: "divide-y divide-gray-100 dark:divide-slate-800 bg-white dark:bg-slate-800",
                  children: h.map((s, o) => e.jsx("tr", {
                    className: "even:bg-gray-50 dark:even:bg-slate-900/50 hover:bg-blue-50/50 dark:hover:bg-slate-700/50",
                    children: s.map((x, g) => e.jsx("td", {
                      title: String(x),
                      className: `px-3 py-1.5 text-xs text-gray-700 dark:text-slate-300 max-w-[200px] truncate${f(x) ? " text-right tabular-nums" : ""}`,
                      children: x
                    }, g))
                  }, o))
                })
              ]
            })
          })
        }),
        e.jsxs("p", {
          className: "text-[10px] text-gray-400 dark:text-slate-500",
          children: [
            r.length,
            " ",
            r.length === 1 ? "row" : "rows",
            ", ",
            y,
            " ",
            y === 1 ? "column" : "columns"
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  T as default
};
