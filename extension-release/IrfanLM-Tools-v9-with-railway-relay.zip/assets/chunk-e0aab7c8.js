import { j as De, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { c as tn, g as or } from "./chunk-725317a4.js";
let yf;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function wi(e, t) {
    const n = t || {};
    return (e[e.length - 1] === "" ? [
      ...e,
      ""
    ] : e).join((n.padRight ? " " : "") + "," + (n.padLeft === false ? "" : " ")).trim();
  }
  const Si = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, Ci = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, Ei = {};
  function ft(e, t) {
    return ((t || Ei).jsx ? Ci : Si).test(e);
  }
  const Ii = /[ \t\n\f\r]/g;
  function Ai(e) {
    return typeof e == "object" ? e.type === "text" ? ht(e.value) : false : ht(e);
  }
  function ht(e) {
    return e.replace(Ii, "") === "";
  }
  class We {
    constructor(t, n, r) {
      this.normal = n, this.property = t, r && (this.space = r);
    }
  }
  We.prototype.normal = {};
  We.prototype.property = {};
  We.prototype.space = void 0;
  function ar(e, t) {
    const n = {}, r = {};
    for (const i of e)
      Object.assign(n, i.property), Object.assign(r, i.normal);
    return new We(n, r, t);
  }
  function vn(e) {
    return e.toLowerCase();
  }
  class ee {
    constructor(t, n) {
      this.attribute = n, this.property = t;
    }
  }
  ee.prototype.attribute = "";
  ee.prototype.booleanish = false;
  ee.prototype.boolean = false;
  ee.prototype.commaOrSpaceSeparated = false;
  ee.prototype.commaSeparated = false;
  ee.prototype.defined = false;
  ee.prototype.mustUseProperty = false;
  ee.prototype.number = false;
  ee.prototype.overloadedBoolean = false;
  ee.prototype.property = "";
  ee.prototype.spaceSeparated = false;
  ee.prototype.space = void 0;
  let Ti = 0;
  const D = Ie(), W = Ie(), zn = Ie(), S = Ie(), V = Ie(), Le = Ie(), te = Ie();
  function Ie() {
    return 2 ** ++Ti;
  }
  const Dn = Object.freeze(Object.defineProperty({
    __proto__: null,
    boolean: D,
    booleanish: W,
    commaOrSpaceSeparated: te,
    commaSeparated: Le,
    number: S,
    overloadedBoolean: zn,
    spaceSeparated: V
  }, Symbol.toStringTag, {
    value: "Module"
  })), mn = Object.keys(Dn);
  class Hn extends ee {
    constructor(t, n, r, i) {
      let o = -1;
      if (super(t, n), pt(this, "space", i), typeof r == "number")
        for (; ++o < mn.length; ) {
          const l = mn[o];
          pt(this, mn[o], (r & Dn[l]) === Dn[l]);
        }
    }
  }
  Hn.prototype.defined = true;
  function pt(e, t, n) {
    n && (e[t] = n);
  }
  function Re(e) {
    const t = {}, n = {};
    for (const [r, i] of Object.entries(e.properties)) {
      const o = new Hn(r, e.transform(e.attributes || {}, r), i, e.space);
      e.mustUseProperty && e.mustUseProperty.includes(r) && (o.mustUseProperty = true), t[r] = o, n[vn(r)] = r, n[vn(o.attribute)] = r;
    }
    return new We(t, n, e.space);
  }
  const ur = Re({
    properties: {
      ariaActiveDescendant: null,
      ariaAtomic: W,
      ariaAutoComplete: null,
      ariaBusy: W,
      ariaChecked: W,
      ariaColCount: S,
      ariaColIndex: S,
      ariaColSpan: S,
      ariaControls: V,
      ariaCurrent: null,
      ariaDescribedBy: V,
      ariaDetails: null,
      ariaDisabled: W,
      ariaDropEffect: V,
      ariaErrorMessage: null,
      ariaExpanded: W,
      ariaFlowTo: V,
      ariaGrabbed: W,
      ariaHasPopup: null,
      ariaHidden: W,
      ariaInvalid: null,
      ariaKeyShortcuts: null,
      ariaLabel: null,
      ariaLabelledBy: V,
      ariaLevel: S,
      ariaLive: null,
      ariaModal: W,
      ariaMultiLine: W,
      ariaMultiSelectable: W,
      ariaOrientation: null,
      ariaOwns: V,
      ariaPlaceholder: null,
      ariaPosInSet: S,
      ariaPressed: W,
      ariaReadOnly: W,
      ariaRelevant: null,
      ariaRequired: W,
      ariaRoleDescription: V,
      ariaRowCount: S,
      ariaRowIndex: S,
      ariaRowSpan: S,
      ariaSelected: W,
      ariaSetSize: S,
      ariaSort: null,
      ariaValueMax: S,
      ariaValueMin: S,
      ariaValueNow: S,
      ariaValueText: null,
      role: null
    },
    transform(e, t) {
      return t === "role" ? t : "aria-" + t.slice(4).toLowerCase();
    }
  });
  function sr(e, t) {
    return t in e ? e[t] : t;
  }
  function cr(e, t) {
    return sr(e, t.toLowerCase());
  }
  const Pi = Re({
    attributes: {
      acceptcharset: "accept-charset",
      classname: "class",
      htmlfor: "for",
      httpequiv: "http-equiv"
    },
    mustUseProperty: [
      "checked",
      "multiple",
      "muted",
      "selected"
    ],
    properties: {
      abbr: null,
      accept: Le,
      acceptCharset: V,
      accessKey: V,
      action: null,
      allow: null,
      allowFullScreen: D,
      allowPaymentRequest: D,
      allowUserMedia: D,
      alt: null,
      as: null,
      async: D,
      autoCapitalize: null,
      autoComplete: V,
      autoFocus: D,
      autoPlay: D,
      blocking: V,
      capture: null,
      charSet: null,
      checked: D,
      cite: null,
      className: V,
      cols: S,
      colSpan: null,
      content: null,
      contentEditable: W,
      controls: D,
      controlsList: V,
      coords: S | Le,
      crossOrigin: null,
      data: null,
      dateTime: null,
      decoding: null,
      default: D,
      defer: D,
      dir: null,
      dirName: null,
      disabled: D,
      download: zn,
      draggable: W,
      encType: null,
      enterKeyHint: null,
      fetchPriority: null,
      form: null,
      formAction: null,
      formEncType: null,
      formMethod: null,
      formNoValidate: D,
      formTarget: null,
      headers: V,
      height: S,
      hidden: zn,
      high: S,
      href: null,
      hrefLang: null,
      htmlFor: V,
      httpEquiv: V,
      id: null,
      imageSizes: null,
      imageSrcSet: null,
      inert: D,
      inputMode: null,
      integrity: null,
      is: null,
      isMap: D,
      itemId: null,
      itemProp: V,
      itemRef: V,
      itemScope: D,
      itemType: V,
      kind: null,
      label: null,
      lang: null,
      language: null,
      list: null,
      loading: null,
      loop: D,
      low: S,
      manifest: null,
      max: null,
      maxLength: S,
      media: null,
      method: null,
      min: null,
      minLength: S,
      multiple: D,
      muted: D,
      name: null,
      nonce: null,
      noModule: D,
      noValidate: D,
      onAbort: null,
      onAfterPrint: null,
      onAuxClick: null,
      onBeforeMatch: null,
      onBeforePrint: null,
      onBeforeToggle: null,
      onBeforeUnload: null,
      onBlur: null,
      onCancel: null,
      onCanPlay: null,
      onCanPlayThrough: null,
      onChange: null,
      onClick: null,
      onClose: null,
      onContextLost: null,
      onContextMenu: null,
      onContextRestored: null,
      onCopy: null,
      onCueChange: null,
      onCut: null,
      onDblClick: null,
      onDrag: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragExit: null,
      onDragLeave: null,
      onDragOver: null,
      onDragStart: null,
      onDrop: null,
      onDurationChange: null,
      onEmptied: null,
      onEnded: null,
      onError: null,
      onFocus: null,
      onFormData: null,
      onHashChange: null,
      onInput: null,
      onInvalid: null,
      onKeyDown: null,
      onKeyPress: null,
      onKeyUp: null,
      onLanguageChange: null,
      onLoad: null,
      onLoadedData: null,
      onLoadedMetadata: null,
      onLoadEnd: null,
      onLoadStart: null,
      onMessage: null,
      onMessageError: null,
      onMouseDown: null,
      onMouseEnter: null,
      onMouseLeave: null,
      onMouseMove: null,
      onMouseOut: null,
      onMouseOver: null,
      onMouseUp: null,
      onOffline: null,
      onOnline: null,
      onPageHide: null,
      onPageShow: null,
      onPaste: null,
      onPause: null,
      onPlay: null,
      onPlaying: null,
      onPopState: null,
      onProgress: null,
      onRateChange: null,
      onRejectionHandled: null,
      onReset: null,
      onResize: null,
      onScroll: null,
      onScrollEnd: null,
      onSecurityPolicyViolation: null,
      onSeeked: null,
      onSeeking: null,
      onSelect: null,
      onSlotChange: null,
      onStalled: null,
      onStorage: null,
      onSubmit: null,
      onSuspend: null,
      onTimeUpdate: null,
      onToggle: null,
      onUnhandledRejection: null,
      onUnload: null,
      onVolumeChange: null,
      onWaiting: null,
      onWheel: null,
      open: D,
      optimum: S,
      pattern: null,
      ping: V,
      placeholder: null,
      playsInline: D,
      popover: null,
      popoverTarget: null,
      popoverTargetAction: null,
      poster: null,
      preload: null,
      readOnly: D,
      referrerPolicy: null,
      rel: V,
      required: D,
      reversed: D,
      rows: S,
      rowSpan: S,
      sandbox: V,
      scope: null,
      scoped: D,
      seamless: D,
      selected: D,
      shadowRootClonable: D,
      shadowRootDelegatesFocus: D,
      shadowRootMode: null,
      shape: null,
      size: S,
      sizes: null,
      slot: null,
      span: S,
      spellCheck: W,
      src: null,
      srcDoc: null,
      srcLang: null,
      srcSet: null,
      start: S,
      step: null,
      style: null,
      tabIndex: S,
      target: null,
      title: null,
      translate: null,
      type: null,
      typeMustMatch: D,
      useMap: null,
      value: W,
      width: S,
      wrap: null,
      writingSuggestions: null,
      align: null,
      aLink: null,
      archive: V,
      axis: null,
      background: null,
      bgColor: null,
      border: S,
      borderColor: null,
      bottomMargin: S,
      cellPadding: null,
      cellSpacing: null,
      char: null,
      charOff: null,
      classId: null,
      clear: null,
      code: null,
      codeBase: null,
      codeType: null,
      color: null,
      compact: D,
      declare: D,
      event: null,
      face: null,
      frame: null,
      frameBorder: null,
      hSpace: S,
      leftMargin: S,
      link: null,
      longDesc: null,
      lowSrc: null,
      marginHeight: S,
      marginWidth: S,
      noResize: D,
      noHref: D,
      noShade: D,
      noWrap: D,
      object: null,
      profile: null,
      prompt: null,
      rev: null,
      rightMargin: S,
      rules: null,
      scheme: null,
      scrolling: W,
      standby: null,
      summary: null,
      text: null,
      topMargin: S,
      valueType: null,
      version: null,
      vAlign: null,
      vLink: null,
      vSpace: S,
      allowTransparency: null,
      autoCorrect: null,
      autoSave: null,
      disablePictureInPicture: D,
      disableRemotePlayback: D,
      prefix: null,
      property: null,
      results: S,
      security: null,
      unselectable: null
    },
    space: "html",
    transform: cr
  }), vi = Re({
    attributes: {
      accentHeight: "accent-height",
      alignmentBaseline: "alignment-baseline",
      arabicForm: "arabic-form",
      baselineShift: "baseline-shift",
      capHeight: "cap-height",
      className: "class",
      clipPath: "clip-path",
      clipRule: "clip-rule",
      colorInterpolation: "color-interpolation",
      colorInterpolationFilters: "color-interpolation-filters",
      colorProfile: "color-profile",
      colorRendering: "color-rendering",
      crossOrigin: "crossorigin",
      dataType: "datatype",
      dominantBaseline: "dominant-baseline",
      enableBackground: "enable-background",
      fillOpacity: "fill-opacity",
      fillRule: "fill-rule",
      floodColor: "flood-color",
      floodOpacity: "flood-opacity",
      fontFamily: "font-family",
      fontSize: "font-size",
      fontSizeAdjust: "font-size-adjust",
      fontStretch: "font-stretch",
      fontStyle: "font-style",
      fontVariant: "font-variant",
      fontWeight: "font-weight",
      glyphName: "glyph-name",
      glyphOrientationHorizontal: "glyph-orientation-horizontal",
      glyphOrientationVertical: "glyph-orientation-vertical",
      hrefLang: "hreflang",
      horizAdvX: "horiz-adv-x",
      horizOriginX: "horiz-origin-x",
      horizOriginY: "horiz-origin-y",
      imageRendering: "image-rendering",
      letterSpacing: "letter-spacing",
      lightingColor: "lighting-color",
      markerEnd: "marker-end",
      markerMid: "marker-mid",
      markerStart: "marker-start",
      navDown: "nav-down",
      navDownLeft: "nav-down-left",
      navDownRight: "nav-down-right",
      navLeft: "nav-left",
      navNext: "nav-next",
      navPrev: "nav-prev",
      navRight: "nav-right",
      navUp: "nav-up",
      navUpLeft: "nav-up-left",
      navUpRight: "nav-up-right",
      onAbort: "onabort",
      onActivate: "onactivate",
      onAfterPrint: "onafterprint",
      onBeforePrint: "onbeforeprint",
      onBegin: "onbegin",
      onCancel: "oncancel",
      onCanPlay: "oncanplay",
      onCanPlayThrough: "oncanplaythrough",
      onChange: "onchange",
      onClick: "onclick",
      onClose: "onclose",
      onCopy: "oncopy",
      onCueChange: "oncuechange",
      onCut: "oncut",
      onDblClick: "ondblclick",
      onDrag: "ondrag",
      onDragEnd: "ondragend",
      onDragEnter: "ondragenter",
      onDragExit: "ondragexit",
      onDragLeave: "ondragleave",
      onDragOver: "ondragover",
      onDragStart: "ondragstart",
      onDrop: "ondrop",
      onDurationChange: "ondurationchange",
      onEmptied: "onemptied",
      onEnd: "onend",
      onEnded: "onended",
      onError: "onerror",
      onFocus: "onfocus",
      onFocusIn: "onfocusin",
      onFocusOut: "onfocusout",
      onHashChange: "onhashchange",
      onInput: "oninput",
      onInvalid: "oninvalid",
      onKeyDown: "onkeydown",
      onKeyPress: "onkeypress",
      onKeyUp: "onkeyup",
      onLoad: "onload",
      onLoadedData: "onloadeddata",
      onLoadedMetadata: "onloadedmetadata",
      onLoadStart: "onloadstart",
      onMessage: "onmessage",
      onMouseDown: "onmousedown",
      onMouseEnter: "onmouseenter",
      onMouseLeave: "onmouseleave",
      onMouseMove: "onmousemove",
      onMouseOut: "onmouseout",
      onMouseOver: "onmouseover",
      onMouseUp: "onmouseup",
      onMouseWheel: "onmousewheel",
      onOffline: "onoffline",
      onOnline: "ononline",
      onPageHide: "onpagehide",
      onPageShow: "onpageshow",
      onPaste: "onpaste",
      onPause: "onpause",
      onPlay: "onplay",
      onPlaying: "onplaying",
      onPopState: "onpopstate",
      onProgress: "onprogress",
      onRateChange: "onratechange",
      onRepeat: "onrepeat",
      onReset: "onreset",
      onResize: "onresize",
      onScroll: "onscroll",
      onSeeked: "onseeked",
      onSeeking: "onseeking",
      onSelect: "onselect",
      onShow: "onshow",
      onStalled: "onstalled",
      onStorage: "onstorage",
      onSubmit: "onsubmit",
      onSuspend: "onsuspend",
      onTimeUpdate: "ontimeupdate",
      onToggle: "ontoggle",
      onUnload: "onunload",
      onVolumeChange: "onvolumechange",
      onWaiting: "onwaiting",
      onZoom: "onzoom",
      overlinePosition: "overline-position",
      overlineThickness: "overline-thickness",
      paintOrder: "paint-order",
      panose1: "panose-1",
      pointerEvents: "pointer-events",
      referrerPolicy: "referrerpolicy",
      renderingIntent: "rendering-intent",
      shapeRendering: "shape-rendering",
      stopColor: "stop-color",
      stopOpacity: "stop-opacity",
      strikethroughPosition: "strikethrough-position",
      strikethroughThickness: "strikethrough-thickness",
      strokeDashArray: "stroke-dasharray",
      strokeDashOffset: "stroke-dashoffset",
      strokeLineCap: "stroke-linecap",
      strokeLineJoin: "stroke-linejoin",
      strokeMiterLimit: "stroke-miterlimit",
      strokeOpacity: "stroke-opacity",
      strokeWidth: "stroke-width",
      tabIndex: "tabindex",
      textAnchor: "text-anchor",
      textDecoration: "text-decoration",
      textRendering: "text-rendering",
      transformOrigin: "transform-origin",
      typeOf: "typeof",
      underlinePosition: "underline-position",
      underlineThickness: "underline-thickness",
      unicodeBidi: "unicode-bidi",
      unicodeRange: "unicode-range",
      unitsPerEm: "units-per-em",
      vAlphabetic: "v-alphabetic",
      vHanging: "v-hanging",
      vIdeographic: "v-ideographic",
      vMathematical: "v-mathematical",
      vectorEffect: "vector-effect",
      vertAdvY: "vert-adv-y",
      vertOriginX: "vert-origin-x",
      vertOriginY: "vert-origin-y",
      wordSpacing: "word-spacing",
      writingMode: "writing-mode",
      xHeight: "x-height",
      playbackOrder: "playbackorder",
      timelineBegin: "timelinebegin"
    },
    properties: {
      about: te,
      accentHeight: S,
      accumulate: null,
      additive: null,
      alignmentBaseline: null,
      alphabetic: S,
      amplitude: S,
      arabicForm: null,
      ascent: S,
      attributeName: null,
      attributeType: null,
      azimuth: S,
      bandwidth: null,
      baselineShift: null,
      baseFrequency: null,
      baseProfile: null,
      bbox: null,
      begin: null,
      bias: S,
      by: null,
      calcMode: null,
      capHeight: S,
      className: V,
      clip: null,
      clipPath: null,
      clipPathUnits: null,
      clipRule: null,
      color: null,
      colorInterpolation: null,
      colorInterpolationFilters: null,
      colorProfile: null,
      colorRendering: null,
      content: null,
      contentScriptType: null,
      contentStyleType: null,
      crossOrigin: null,
      cursor: null,
      cx: null,
      cy: null,
      d: null,
      dataType: null,
      defaultAction: null,
      descent: S,
      diffuseConstant: S,
      direction: null,
      display: null,
      dur: null,
      divisor: S,
      dominantBaseline: null,
      download: D,
      dx: null,
      dy: null,
      edgeMode: null,
      editable: null,
      elevation: S,
      enableBackground: null,
      end: null,
      event: null,
      exponent: S,
      externalResourcesRequired: null,
      fill: null,
      fillOpacity: S,
      fillRule: null,
      filter: null,
      filterRes: null,
      filterUnits: null,
      floodColor: null,
      floodOpacity: null,
      focusable: null,
      focusHighlight: null,
      fontFamily: null,
      fontSize: null,
      fontSizeAdjust: null,
      fontStretch: null,
      fontStyle: null,
      fontVariant: null,
      fontWeight: null,
      format: null,
      fr: null,
      from: null,
      fx: null,
      fy: null,
      g1: Le,
      g2: Le,
      glyphName: Le,
      glyphOrientationHorizontal: null,
      glyphOrientationVertical: null,
      glyphRef: null,
      gradientTransform: null,
      gradientUnits: null,
      handler: null,
      hanging: S,
      hatchContentUnits: null,
      hatchUnits: null,
      height: null,
      href: null,
      hrefLang: null,
      horizAdvX: S,
      horizOriginX: S,
      horizOriginY: S,
      id: null,
      ideographic: S,
      imageRendering: null,
      initialVisibility: null,
      in: null,
      in2: null,
      intercept: S,
      k: S,
      k1: S,
      k2: S,
      k3: S,
      k4: S,
      kernelMatrix: te,
      kernelUnitLength: null,
      keyPoints: null,
      keySplines: null,
      keyTimes: null,
      kerning: null,
      lang: null,
      lengthAdjust: null,
      letterSpacing: null,
      lightingColor: null,
      limitingConeAngle: S,
      local: null,
      markerEnd: null,
      markerMid: null,
      markerStart: null,
      markerHeight: null,
      markerUnits: null,
      markerWidth: null,
      mask: null,
      maskContentUnits: null,
      maskUnits: null,
      mathematical: null,
      max: null,
      media: null,
      mediaCharacterEncoding: null,
      mediaContentEncodings: null,
      mediaSize: S,
      mediaTime: null,
      method: null,
      min: null,
      mode: null,
      name: null,
      navDown: null,
      navDownLeft: null,
      navDownRight: null,
      navLeft: null,
      navNext: null,
      navPrev: null,
      navRight: null,
      navUp: null,
      navUpLeft: null,
      navUpRight: null,
      numOctaves: null,
      observer: null,
      offset: null,
      onAbort: null,
      onActivate: null,
      onAfterPrint: null,
      onBeforePrint: null,
      onBegin: null,
      onCancel: null,
      onCanPlay: null,
      onCanPlayThrough: null,
      onChange: null,
      onClick: null,
      onClose: null,
      onCopy: null,
      onCueChange: null,
      onCut: null,
      onDblClick: null,
      onDrag: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragExit: null,
      onDragLeave: null,
      onDragOver: null,
      onDragStart: null,
      onDrop: null,
      onDurationChange: null,
      onEmptied: null,
      onEnd: null,
      onEnded: null,
      onError: null,
      onFocus: null,
      onFocusIn: null,
      onFocusOut: null,
      onHashChange: null,
      onInput: null,
      onInvalid: null,
      onKeyDown: null,
      onKeyPress: null,
      onKeyUp: null,
      onLoad: null,
      onLoadedData: null,
      onLoadedMetadata: null,
      onLoadStart: null,
      onMessage: null,
      onMouseDown: null,
      onMouseEnter: null,
      onMouseLeave: null,
      onMouseMove: null,
      onMouseOut: null,
      onMouseOver: null,
      onMouseUp: null,
      onMouseWheel: null,
      onOffline: null,
      onOnline: null,
      onPageHide: null,
      onPageShow: null,
      onPaste: null,
      onPause: null,
      onPlay: null,
      onPlaying: null,
      onPopState: null,
      onProgress: null,
      onRateChange: null,
      onRepeat: null,
      onReset: null,
      onResize: null,
      onScroll: null,
      onSeeked: null,
      onSeeking: null,
      onSelect: null,
      onShow: null,
      onStalled: null,
      onStorage: null,
      onSubmit: null,
      onSuspend: null,
      onTimeUpdate: null,
      onToggle: null,
      onUnload: null,
      onVolumeChange: null,
      onWaiting: null,
      onZoom: null,
      opacity: null,
      operator: null,
      order: null,
      orient: null,
      orientation: null,
      origin: null,
      overflow: null,
      overlay: null,
      overlinePosition: S,
      overlineThickness: S,
      paintOrder: null,
      panose1: null,
      path: null,
      pathLength: S,
      patternContentUnits: null,
      patternTransform: null,
      patternUnits: null,
      phase: null,
      ping: V,
      pitch: null,
      playbackOrder: null,
      pointerEvents: null,
      points: null,
      pointsAtX: S,
      pointsAtY: S,
      pointsAtZ: S,
      preserveAlpha: null,
      preserveAspectRatio: null,
      primitiveUnits: null,
      propagate: null,
      property: te,
      r: null,
      radius: null,
      referrerPolicy: null,
      refX: null,
      refY: null,
      rel: te,
      rev: te,
      renderingIntent: null,
      repeatCount: null,
      repeatDur: null,
      requiredExtensions: te,
      requiredFeatures: te,
      requiredFonts: te,
      requiredFormats: te,
      resource: null,
      restart: null,
      result: null,
      rotate: null,
      rx: null,
      ry: null,
      scale: null,
      seed: null,
      shapeRendering: null,
      side: null,
      slope: null,
      snapshotTime: null,
      specularConstant: S,
      specularExponent: S,
      spreadMethod: null,
      spacing: null,
      startOffset: null,
      stdDeviation: null,
      stemh: null,
      stemv: null,
      stitchTiles: null,
      stopColor: null,
      stopOpacity: null,
      strikethroughPosition: S,
      strikethroughThickness: S,
      string: null,
      stroke: null,
      strokeDashArray: te,
      strokeDashOffset: null,
      strokeLineCap: null,
      strokeLineJoin: null,
      strokeMiterLimit: S,
      strokeOpacity: S,
      strokeWidth: null,
      style: null,
      surfaceScale: S,
      syncBehavior: null,
      syncBehaviorDefault: null,
      syncMaster: null,
      syncTolerance: null,
      syncToleranceDefault: null,
      systemLanguage: te,
      tabIndex: S,
      tableValues: null,
      target: null,
      targetX: S,
      targetY: S,
      textAnchor: null,
      textDecoration: null,
      textRendering: null,
      textLength: null,
      timelineBegin: null,
      title: null,
      transformBehavior: null,
      type: null,
      typeOf: te,
      to: null,
      transform: null,
      transformOrigin: null,
      u1: null,
      u2: null,
      underlinePosition: S,
      underlineThickness: S,
      unicode: null,
      unicodeBidi: null,
      unicodeRange: null,
      unitsPerEm: S,
      values: null,
      vAlphabetic: S,
      vMathematical: S,
      vectorEffect: null,
      vHanging: S,
      vIdeographic: S,
      version: null,
      vertAdvY: S,
      vertOriginX: S,
      vertOriginY: S,
      viewBox: null,
      viewTarget: null,
      visibility: null,
      width: null,
      widths: null,
      wordSpacing: null,
      writingMode: null,
      x: null,
      x1: null,
      x2: null,
      xChannelSelector: null,
      xHeight: S,
      y: null,
      y1: null,
      y2: null,
      yChannelSelector: null,
      z: null,
      zoomAndPan: null
    },
    space: "svg",
    transform: sr
  }), fr = Re({
    properties: {
      xLinkActuate: null,
      xLinkArcRole: null,
      xLinkHref: null,
      xLinkRole: null,
      xLinkShow: null,
      xLinkTitle: null,
      xLinkType: null
    },
    space: "xlink",
    transform(e, t) {
      return "xlink:" + t.slice(5).toLowerCase();
    }
  }), hr = Re({
    attributes: {
      xmlnsxlink: "xmlns:xlink"
    },
    properties: {
      xmlnsXLink: null,
      xmlns: null
    },
    space: "xmlns",
    transform: cr
  }), pr = Re({
    properties: {
      xmlBase: null,
      xmlLang: null,
      xmlSpace: null
    },
    space: "xml",
    transform(e, t) {
      return "xml:" + t.slice(3).toLowerCase();
    }
  }), zi = {
    classId: "classID",
    dataType: "datatype",
    itemId: "itemID",
    strokeDashArray: "strokeDasharray",
    strokeDashOffset: "strokeDashoffset",
    strokeLineCap: "strokeLinecap",
    strokeLineJoin: "strokeLinejoin",
    strokeMiterLimit: "strokeMiterlimit",
    typeOf: "typeof",
    xLinkActuate: "xlinkActuate",
    xLinkArcRole: "xlinkArcrole",
    xLinkHref: "xlinkHref",
    xLinkRole: "xlinkRole",
    xLinkShow: "xlinkShow",
    xLinkTitle: "xlinkTitle",
    xLinkType: "xlinkType",
    xmlnsXLink: "xmlnsXlink"
  }, Di = /[A-Z]/g, mt = /-[a-z]/g, Li = /^data[-\w.:]+$/i;
  function Fi(e, t) {
    const n = vn(t);
    let r = t, i = ee;
    if (n in e.normal)
      return e.property[e.normal[n]];
    if (n.length > 4 && n.slice(0, 4) === "data" && Li.test(t)) {
      if (t.charAt(4) === "-") {
        const o = t.slice(5).replace(mt, _i);
        r = "data" + o.charAt(0).toUpperCase() + o.slice(1);
      } else {
        const o = t.slice(4);
        if (!mt.test(o)) {
          let l = o.replace(Di, Ri);
          l.charAt(0) !== "-" && (l = "-" + l), t = "data" + l;
        }
      }
      i = Hn;
    }
    return new i(r, t);
  }
  function Ri(e) {
    return "-" + e.toLowerCase();
  }
  function _i(e) {
    return e.charAt(1).toUpperCase();
  }
  const Oi = ar([
    ur,
    Pi,
    fr,
    hr,
    pr
  ], "html"), Un = ar([
    ur,
    vi,
    fr,
    hr,
    pr
  ], "svg");
  function Mi(e) {
    return e.join(" ").trim();
  }
  var Vn = {}, gt = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g, Ni = /\n/g, Bi = /^\s*/, ji = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/, Hi = /^:\s*/, Ui = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/, Vi = /^[;\s]*/, $i = /^\s+|\s+$/g, qi = `
`, dt = "/", yt = "*", Ce = "", Wi = "comment", Yi = "declaration";
  function Xi(e, t) {
    if (typeof e != "string")
      throw new TypeError("First argument must be a string");
    if (!e)
      return [];
    t = t || {};
    var n = 1, r = 1;
    function i(d) {
      var x = d.match(Ni);
      x && (n += x.length);
      var C = d.lastIndexOf(qi);
      r = ~C ? d.length - C : r + d.length;
    }
    function o() {
      var d = {
        line: n,
        column: r
      };
      return function(x) {
        return x.position = new l(d), s(), x;
      };
    }
    function l(d) {
      this.start = d, this.end = {
        line: n,
        column: r
      }, this.source = t.source;
    }
    l.prototype.content = e;
    function a(d) {
      var x = new Error(t.source + ":" + n + ":" + r + ": " + d);
      if (x.reason = d, x.filename = t.source, x.line = n, x.column = r, x.source = e, !t.silent)
        throw x;
    }
    function u(d) {
      var x = d.exec(e);
      if (x) {
        var C = x[0];
        return i(C), e = e.slice(C.length), x;
      }
    }
    function s() {
      u(Bi);
    }
    function f(d) {
      var x;
      for (d = d || []; x = c(); )
        x !== false && d.push(x);
      return d;
    }
    function c() {
      var d = o();
      if (!(dt != e.charAt(0) || yt != e.charAt(1))) {
        for (var x = 2; Ce != e.charAt(x) && (yt != e.charAt(x) || dt != e.charAt(x + 1)); )
          ++x;
        if (x += 2, Ce === e.charAt(x - 1))
          return a("End of comment missing");
        var C = e.slice(2, x - 2);
        return r += 2, i(C), e = e.slice(x), r += 2, d({
          type: Wi,
          comment: C
        });
      }
    }
    function p() {
      var d = o(), x = u(ji);
      if (x) {
        if (c(), !u(Hi))
          return a("property missing ':'");
        var C = u(Ui), y = d({
          type: Yi,
          property: kt(x[0].replace(gt, Ce)),
          value: C ? kt(C[0].replace(gt, Ce)) : Ce
        });
        return u(Vi), y;
      }
    }
    function h() {
      var d = [];
      f(d);
      for (var x; x = p(); )
        x !== false && (d.push(x), f(d));
      return d;
    }
    return s(), h();
  }
  function kt(e) {
    return e ? e.replace($i, Ce) : Ce;
  }
  var Qi = Xi, Gi = tn && tn.__importDefault || function(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  };
  Object.defineProperty(Vn, "__esModule", {
    value: true
  });
  Vn.default = Ji;
  const Ki = Gi(Qi);
  function Ji(e, t) {
    let n = null;
    if (!e || typeof e != "string")
      return n;
    const r = (0, Ki.default)(e), i = typeof t == "function";
    return r.forEach((o) => {
      if (o.type !== "declaration")
        return;
      const { property: l, value: a } = o;
      i ? t(l, a, o) : a && (n = n || {}, n[l] = a);
    }), n;
  }
  var un = {};
  Object.defineProperty(un, "__esModule", {
    value: true
  });
  un.camelCase = void 0;
  var Zi = /^--[a-zA-Z0-9_-]+$/, el = /-([a-z])/g, nl = /^[^-]+$/, tl = /^-(webkit|moz|ms|o|khtml)-/, rl = /^-(ms)-/, il = function(e) {
    return !e || nl.test(e) || Zi.test(e);
  }, ll = function(e, t) {
    return t.toUpperCase();
  }, xt = function(e, t) {
    return "".concat(t, "-");
  }, ol = function(e, t) {
    return t === void 0 && (t = {}), il(e) ? e : (e = e.toLowerCase(), t.reactCompat ? e = e.replace(rl, xt) : e = e.replace(tl, xt), e.replace(el, ll));
  };
  un.camelCase = ol;
  var al = tn && tn.__importDefault || function(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }, ul = al(Vn), sl = un;
  function Ln(e, t) {
    var n = {};
    return !e || typeof e != "string" || (0, ul.default)(e, function(r, i) {
      r && i && (n[(0, sl.camelCase)(r, t)] = i);
    }), n;
  }
  Ln.default = Ln;
  var cl = Ln;
  const fl = or(cl), mr = gr("end"), $n = gr("start");
  function gr(e) {
    return t;
    function t(n) {
      const r = n && n.position && n.position[e] || {};
      if (typeof r.line == "number" && r.line > 0 && typeof r.column == "number" && r.column > 0)
        return {
          line: r.line,
          column: r.column,
          offset: typeof r.offset == "number" && r.offset > -1 ? r.offset : void 0
        };
    }
  }
  function hl(e) {
    const t = $n(e), n = mr(e);
    if (t && n)
      return {
        start: t,
        end: n
      };
  }
  function He(e) {
    return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? bt(e.position) : "start" in e || "end" in e ? bt(e) : "line" in e || "column" in e ? Fn(e) : "";
  }
  function Fn(e) {
    return wt(e && e.line) + ":" + wt(e && e.column);
  }
  function bt(e) {
    return Fn(e && e.start) + "-" + Fn(e && e.end);
  }
  function wt(e) {
    return e && typeof e == "number" ? e : 1;
  }
  class K extends Error {
    constructor(t, n, r) {
      super(), typeof n == "string" && (r = n, n = void 0);
      let i = "", o = {}, l = false;
      if (n && ("line" in n && "column" in n ? o = {
        place: n
      } : "start" in n && "end" in n ? o = {
        place: n
      } : "type" in n ? o = {
        ancestors: [
          n
        ],
        place: n.position
      } : o = {
        ...n
      }), typeof t == "string" ? i = t : !o.cause && t && (l = true, i = t.message, o.cause = t), !o.ruleId && !o.source && typeof r == "string") {
        const u = r.indexOf(":");
        u === -1 ? o.ruleId = r : (o.source = r.slice(0, u), o.ruleId = r.slice(u + 1));
      }
      if (!o.place && o.ancestors && o.ancestors) {
        const u = o.ancestors[o.ancestors.length - 1];
        u && (o.place = u.position);
      }
      const a = o.place && "start" in o.place ? o.place.start : o.place;
      this.ancestors = o.ancestors || void 0, this.cause = o.cause || void 0, this.column = a ? a.column : void 0, this.fatal = void 0, this.file = "", this.message = i, this.line = a ? a.line : void 0, this.name = He(o.place) || "1:1", this.place = o.place || void 0, this.reason = this.message, this.ruleId = o.ruleId || void 0, this.source = o.source || void 0, this.stack = l && o.cause && typeof o.cause.stack == "string" ? o.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
    }
  }
  K.prototype.file = "";
  K.prototype.name = "";
  K.prototype.reason = "";
  K.prototype.message = "";
  K.prototype.stack = "";
  K.prototype.column = void 0;
  K.prototype.line = void 0;
  K.prototype.ancestors = void 0;
  K.prototype.cause = void 0;
  K.prototype.fatal = void 0;
  K.prototype.place = void 0;
  K.prototype.ruleId = void 0;
  K.prototype.source = void 0;
  const qn = {}.hasOwnProperty, pl = /* @__PURE__ */ new Map(), ml = /[A-Z]/g, gl = /* @__PURE__ */ new Set([
    "table",
    "tbody",
    "thead",
    "tfoot",
    "tr"
  ]), dl = /* @__PURE__ */ new Set([
    "td",
    "th"
  ]), dr = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
  function yl(e, t) {
    if (!t || t.Fragment === void 0)
      throw new TypeError("Expected `Fragment` in options");
    const n = t.filePath || void 0;
    let r;
    if (t.development) {
      if (typeof t.jsxDEV != "function")
        throw new TypeError("Expected `jsxDEV` in options when `development: true`");
      r = Il(n, t.jsxDEV);
    } else {
      if (typeof t.jsx != "function")
        throw new TypeError("Expected `jsx` in production options");
      if (typeof t.jsxs != "function")
        throw new TypeError("Expected `jsxs` in production options");
      r = El(n, t.jsx, t.jsxs);
    }
    const i = {
      Fragment: t.Fragment,
      ancestors: [],
      components: t.components || {},
      create: r,
      elementAttributeNameCase: t.elementAttributeNameCase || "react",
      evaluater: t.createEvaluater ? t.createEvaluater() : void 0,
      filePath: n,
      ignoreInvalidStyle: t.ignoreInvalidStyle || false,
      passKeys: t.passKeys !== false,
      passNode: t.passNode || false,
      schema: t.space === "svg" ? Un : Oi,
      stylePropertyNameCase: t.stylePropertyNameCase || "dom",
      tableCellAlignToStyle: t.tableCellAlignToStyle !== false
    }, o = yr(i, e, void 0);
    return o && typeof o != "string" ? o : i.create(e, i.Fragment, {
      children: o || void 0
    }, void 0);
  }
  function yr(e, t, n) {
    if (t.type === "element")
      return kl(e, t, n);
    if (t.type === "mdxFlowExpression" || t.type === "mdxTextExpression")
      return xl(e, t);
    if (t.type === "mdxJsxFlowElement" || t.type === "mdxJsxTextElement")
      return wl(e, t, n);
    if (t.type === "mdxjsEsm")
      return bl(e, t);
    if (t.type === "root")
      return Sl(e, t, n);
    if (t.type === "text")
      return Cl(e, t);
  }
  function kl(e, t, n) {
    const r = e.schema;
    let i = r;
    t.tagName.toLowerCase() === "svg" && r.space === "html" && (i = Un, e.schema = i), e.ancestors.push(t);
    const o = xr(e, t.tagName, false), l = Al(e, t);
    let a = Yn(e, t);
    return gl.has(t.tagName) && (a = a.filter(function(u) {
      return typeof u == "string" ? !Ai(u) : true;
    })), kr(e, l, o, t), Wn(l, a), e.ancestors.pop(), e.schema = r, e.create(t, o, l, n);
  }
  function xl(e, t) {
    if (t.data && t.data.estree && e.evaluater) {
      const r = t.data.estree.body[0];
      return r.type, e.evaluater.evaluateExpression(r.expression);
    }
    $e(e, t.position);
  }
  function bl(e, t) {
    if (t.data && t.data.estree && e.evaluater)
      return e.evaluater.evaluateProgram(t.data.estree);
    $e(e, t.position);
  }
  function wl(e, t, n) {
    const r = e.schema;
    let i = r;
    t.name === "svg" && r.space === "html" && (i = Un, e.schema = i), e.ancestors.push(t);
    const o = t.name === null ? e.Fragment : xr(e, t.name, true), l = Tl(e, t), a = Yn(e, t);
    return kr(e, l, o, t), Wn(l, a), e.ancestors.pop(), e.schema = r, e.create(t, o, l, n);
  }
  function Sl(e, t, n) {
    const r = {};
    return Wn(r, Yn(e, t)), e.create(t, e.Fragment, r, n);
  }
  function Cl(e, t) {
    return t.value;
  }
  function kr(e, t, n, r) {
    typeof n != "string" && n !== e.Fragment && e.passNode && (t.node = r);
  }
  function Wn(e, t) {
    if (t.length > 0) {
      const n = t.length > 1 ? t : t[0];
      n && (e.children = n);
    }
  }
  function El(e, t, n) {
    return r;
    function r(i, o, l, a) {
      const s = Array.isArray(l.children) ? n : t;
      return a ? s(o, l, a) : s(o, l);
    }
  }
  function Il(e, t) {
    return n;
    function n(r, i, o, l) {
      const a = Array.isArray(o.children), u = $n(r);
      return t(i, o, l, a, {
        columnNumber: u ? u.column - 1 : void 0,
        fileName: e,
        lineNumber: u ? u.line : void 0
      }, void 0);
    }
  }
  function Al(e, t) {
    const n = {};
    let r, i;
    for (i in t.properties)
      if (i !== "children" && qn.call(t.properties, i)) {
        const o = Pl(e, i, t.properties[i]);
        if (o) {
          const [l, a] = o;
          e.tableCellAlignToStyle && l === "align" && typeof a == "string" && dl.has(t.tagName) ? r = a : n[l] = a;
        }
      }
    if (r) {
      const o = n.style || (n.style = {});
      o[e.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = r;
    }
    return n;
  }
  function Tl(e, t) {
    const n = {};
    for (const r of t.attributes)
      if (r.type === "mdxJsxExpressionAttribute")
        if (r.data && r.data.estree && e.evaluater) {
          const o = r.data.estree.body[0];
          o.type;
          const l = o.expression;
          l.type;
          const a = l.properties[0];
          a.type, Object.assign(n, e.evaluater.evaluateExpression(a.argument));
        } else
          $e(e, t.position);
      else {
        const i = r.name;
        let o;
        if (r.value && typeof r.value == "object")
          if (r.value.data && r.value.data.estree && e.evaluater) {
            const a = r.value.data.estree.body[0];
            a.type, o = e.evaluater.evaluateExpression(a.expression);
          } else
            $e(e, t.position);
        else
          o = r.value === null ? true : r.value;
        n[i] = o;
      }
    return n;
  }
  function Yn(e, t) {
    const n = [];
    let r = -1;
    const i = e.passKeys ? /* @__PURE__ */ new Map() : pl;
    for (; ++r < t.children.length; ) {
      const o = t.children[r];
      let l;
      if (e.passKeys) {
        const u = o.type === "element" ? o.tagName : o.type === "mdxJsxFlowElement" || o.type === "mdxJsxTextElement" ? o.name : void 0;
        if (u) {
          const s = i.get(u) || 0;
          l = u + "-" + s, i.set(u, s + 1);
        }
      }
      const a = yr(e, o, l);
      a !== void 0 && n.push(a);
    }
    return n;
  }
  function Pl(e, t, n) {
    const r = Fi(e.schema, t);
    if (!(n == null || typeof n == "number" && Number.isNaN(n))) {
      if (Array.isArray(n) && (n = r.commaSeparated ? wi(n) : Mi(n)), r.property === "style") {
        let i = typeof n == "object" ? n : vl(e, String(n));
        return e.stylePropertyNameCase === "css" && (i = zl(i)), [
          "style",
          i
        ];
      }
      return [
        e.elementAttributeNameCase === "react" && r.space ? zi[r.property] || r.property : r.attribute,
        n
      ];
    }
  }
  function vl(e, t) {
    try {
      return fl(t, {
        reactCompat: true
      });
    } catch (n) {
      if (e.ignoreInvalidStyle)
        return {};
      const r = n, i = new K("Cannot parse `style` attribute", {
        ancestors: e.ancestors,
        cause: r,
        ruleId: "style",
        source: "hast-util-to-jsx-runtime"
      });
      throw i.file = e.filePath || void 0, i.url = dr + "#cannot-parse-style-attribute", i;
    }
  }
  function xr(e, t, n) {
    let r;
    if (!n)
      r = {
        type: "Literal",
        value: t
      };
    else if (t.includes(".")) {
      const i = t.split(".");
      let o = -1, l;
      for (; ++o < i.length; ) {
        const a = ft(i[o]) ? {
          type: "Identifier",
          name: i[o]
        } : {
          type: "Literal",
          value: i[o]
        };
        l = l ? {
          type: "MemberExpression",
          object: l,
          property: a,
          computed: !!(o && a.type === "Literal"),
          optional: false
        } : a;
      }
      r = l;
    } else
      r = ft(t) && !/^[a-z]/.test(t) ? {
        type: "Identifier",
        name: t
      } : {
        type: "Literal",
        value: t
      };
    if (r.type === "Literal") {
      const i = r.value;
      return qn.call(e.components, i) ? e.components[i] : i;
    }
    if (e.evaluater)
      return e.evaluater.evaluateExpression(r);
    $e(e);
  }
  function $e(e, t) {
    const n = new K("Cannot handle MDX estrees without `createEvaluater`", {
      ancestors: e.ancestors,
      place: t,
      ruleId: "mdx-estree",
      source: "hast-util-to-jsx-runtime"
    });
    throw n.file = e.filePath || void 0, n.url = dr + "#cannot-handle-mdx-estrees-without-createevaluater", n;
  }
  function zl(e) {
    const t = {};
    let n;
    for (n in e)
      qn.call(e, n) && (t[Dl(n)] = e[n]);
    return t;
  }
  function Dl(e) {
    let t = e.replace(ml, Ll);
    return t.slice(0, 3) === "ms-" && (t = "-" + t), t;
  }
  function Ll(e) {
    return "-" + e.toLowerCase();
  }
  const gn = {
    action: [
      "form"
    ],
    cite: [
      "blockquote",
      "del",
      "ins",
      "q"
    ],
    data: [
      "object"
    ],
    formAction: [
      "button",
      "input"
    ],
    href: [
      "a",
      "area",
      "base",
      "link"
    ],
    icon: [
      "menuitem"
    ],
    itemId: null,
    manifest: [
      "html"
    ],
    ping: [
      "a",
      "area"
    ],
    poster: [
      "video"
    ],
    src: [
      "audio",
      "embed",
      "iframe",
      "img",
      "input",
      "script",
      "source",
      "track",
      "video"
    ]
  }, Fl = {};
  function Xn(e, t) {
    const n = t || Fl, r = typeof n.includeImageAlt == "boolean" ? n.includeImageAlt : true, i = typeof n.includeHtml == "boolean" ? n.includeHtml : true;
    return br(e, r, i);
  }
  function br(e, t, n) {
    if (Rl(e)) {
      if ("value" in e)
        return e.type === "html" && !n ? "" : e.value;
      if (t && "alt" in e && e.alt)
        return e.alt;
      if ("children" in e)
        return St(e.children, t, n);
    }
    return Array.isArray(e) ? St(e, t, n) : "";
  }
  function St(e, t, n) {
    const r = [];
    let i = -1;
    for (; ++i < e.length; )
      r[i] = br(e[i], t, n);
    return r.join("");
  }
  function Rl(e) {
    return !!(e && typeof e == "object");
  }
  const Ct = document.createElement("i");
  function Qn(e) {
    const t = "&" + e + ";";
    Ct.innerHTML = t;
    const n = Ct.textContent;
    return n.charCodeAt(n.length - 1) === 59 && e !== "semi" || n === t ? false : n;
  }
  function re(e, t, n, r) {
    const i = e.length;
    let o = 0, l;
    if (t < 0 ? t = -t > i ? 0 : i + t : t = t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4)
      l = Array.from(r), l.unshift(t, n), e.splice(...l);
    else
      for (n && e.splice(t, n); o < r.length; )
        l = r.slice(o, o + 1e4), l.unshift(t, 0), e.splice(...l), o += 1e4, t += 1e4;
  }
  function ie(e, t) {
    return e.length > 0 ? (re(e, e.length, 0, t), e) : t;
  }
  const Et = {}.hasOwnProperty;
  function wr(e) {
    const t = {};
    let n = -1;
    for (; ++n < e.length; )
      _l(t, e[n]);
    return t;
  }
  function _l(e, t) {
    let n;
    for (n in t) {
      const i = (Et.call(e, n) ? e[n] : void 0) || (e[n] = {}), o = t[n];
      let l;
      if (o)
        for (l in o) {
          Et.call(i, l) || (i[l] = []);
          const a = o[l];
          Ol(i[l], Array.isArray(a) ? a : a ? [
            a
          ] : []);
        }
    }
  }
  function Ol(e, t) {
    let n = -1;
    const r = [];
    for (; ++n < t.length; )
      (t[n].add === "after" ? e : r).push(t[n]);
    re(e, 0, 0, r);
  }
  function Sr(e, t) {
    const n = Number.parseInt(e, t);
    return n < 9 || n === 11 || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (n & 65535) === 65535 || (n & 65535) === 65534 || n > 1114111 ? "\uFFFD" : String.fromCodePoint(n);
  }
  function se(e) {
    return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
  }
  const J = xe(/[A-Za-z]/), G = xe(/[\dA-Za-z]/), Ml = xe(/[#-'*+\--9=?A-Z^-~]/);
  function rn(e) {
    return e !== null && (e < 32 || e === 127);
  }
  const Rn = xe(/\d/), Nl = xe(/[\dA-Fa-f]/), Bl = xe(/[!-/:-@[-`{-~]/);
  function v(e) {
    return e !== null && e < -2;
  }
  function U(e) {
    return e !== null && (e < 0 || e === 32);
  }
  function R(e) {
    return e === -2 || e === -1 || e === 32;
  }
  const sn = xe(/\p{P}|\p{S}/u), Ee = xe(/\s/);
  function xe(e) {
    return t;
    function t(n) {
      return n !== null && n > -1 && e.test(String.fromCharCode(n));
    }
  }
  function _e(e) {
    const t = [];
    let n = -1, r = 0, i = 0;
    for (; ++n < e.length; ) {
      const o = e.charCodeAt(n);
      let l = "";
      if (o === 37 && G(e.charCodeAt(n + 1)) && G(e.charCodeAt(n + 2)))
        i = 2;
      else if (o < 128)
        /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(o)) || (l = String.fromCharCode(o));
      else if (o > 55295 && o < 57344) {
        const a = e.charCodeAt(n + 1);
        o < 56320 && a > 56319 && a < 57344 ? (l = String.fromCharCode(o, a), i = 1) : l = "\uFFFD";
      } else
        l = String.fromCharCode(o);
      l && (t.push(e.slice(r, n), encodeURIComponent(l)), r = n + i + 1, l = ""), i && (n += i, i = 0);
    }
    return t.join("") + e.slice(r);
  }
  function O(e, t, n, r) {
    const i = r ? r - 1 : Number.POSITIVE_INFINITY;
    let o = 0;
    return l;
    function l(u) {
      return R(u) ? (e.enter(n), a(u)) : t(u);
    }
    function a(u) {
      return R(u) && o++ < i ? (e.consume(u), a) : (e.exit(n), t(u));
    }
  }
  const jl = {
    tokenize: Hl
  };
  function Hl(e) {
    const t = e.attempt(this.parser.constructs.contentInitial, r, i);
    let n;
    return t;
    function r(a) {
      if (a === null) {
        e.consume(a);
        return;
      }
      return e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), O(e, t, "linePrefix");
    }
    function i(a) {
      return e.enter("paragraph"), o(a);
    }
    function o(a) {
      const u = e.enter("chunkText", {
        contentType: "text",
        previous: n
      });
      return n && (n.next = u), n = u, l(a);
    }
    function l(a) {
      if (a === null) {
        e.exit("chunkText"), e.exit("paragraph"), e.consume(a);
        return;
      }
      return v(a) ? (e.consume(a), e.exit("chunkText"), o) : (e.consume(a), l);
    }
  }
  const Ul = {
    tokenize: Vl
  }, It = {
    tokenize: $l
  };
  function Vl(e) {
    const t = this, n = [];
    let r = 0, i, o, l;
    return a;
    function a(E) {
      if (r < n.length) {
        const L = n[r];
        return t.containerState = L[1], e.attempt(L[0].continuation, u, s)(E);
      }
      return s(E);
    }
    function u(E) {
      if (r++, t.containerState._closeFlow) {
        t.containerState._closeFlow = void 0, i && A();
        const L = t.events.length;
        let F = L, w;
        for (; F--; )
          if (t.events[F][0] === "exit" && t.events[F][1].type === "chunkFlow") {
            w = t.events[F][1].end;
            break;
          }
        y(r);
        let M = L;
        for (; M < t.events.length; )
          t.events[M][1].end = {
            ...w
          }, M++;
        return re(t.events, F + 1, 0, t.events.slice(L)), t.events.length = M, s(E);
      }
      return a(E);
    }
    function s(E) {
      if (r === n.length) {
        if (!i)
          return p(E);
        if (i.currentConstruct && i.currentConstruct.concrete)
          return d(E);
        t.interrupt = !!(i.currentConstruct && !i._gfmTableDynamicInterruptHack);
      }
      return t.containerState = {}, e.check(It, f, c)(E);
    }
    function f(E) {
      return i && A(), y(r), p(E);
    }
    function c(E) {
      return t.parser.lazy[t.now().line] = r !== n.length, l = t.now().offset, d(E);
    }
    function p(E) {
      return t.containerState = {}, e.attempt(It, h, d)(E);
    }
    function h(E) {
      return r++, n.push([
        t.currentConstruct,
        t.containerState
      ]), p(E);
    }
    function d(E) {
      if (E === null) {
        i && A(), y(0), e.consume(E);
        return;
      }
      return i = i || t.parser.flow(t.now()), e.enter("chunkFlow", {
        _tokenizer: i,
        contentType: "flow",
        previous: o
      }), x(E);
    }
    function x(E) {
      if (E === null) {
        C(e.exit("chunkFlow"), true), y(0), e.consume(E);
        return;
      }
      return v(E) ? (e.consume(E), C(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, a) : (e.consume(E), x);
    }
    function C(E, L) {
      const F = t.sliceStream(E);
      if (L && F.push(null), E.previous = o, o && (o.next = E), o = E, i.defineSkip(E.start), i.write(F), t.parser.lazy[E.start.line]) {
        let w = i.events.length;
        for (; w--; )
          if (i.events[w][1].start.offset < l && (!i.events[w][1].end || i.events[w][1].end.offset > l))
            return;
        const M = t.events.length;
        let $ = M, B, k;
        for (; $--; )
          if (t.events[$][0] === "exit" && t.events[$][1].type === "chunkFlow") {
            if (B) {
              k = t.events[$][1].end;
              break;
            }
            B = true;
          }
        for (y(r), w = M; w < t.events.length; )
          t.events[w][1].end = {
            ...k
          }, w++;
        re(t.events, $ + 1, 0, t.events.slice(M)), t.events.length = w;
      }
    }
    function y(E) {
      let L = n.length;
      for (; L-- > E; ) {
        const F = n[L];
        t.containerState = F[1], F[0].exit.call(t, e);
      }
      n.length = E;
    }
    function A() {
      i.write([
        null
      ]), o = void 0, i = void 0, t.containerState._closeFlow = void 0;
    }
  }
  function $l(e, t, n) {
    return O(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
  }
  function Fe(e) {
    if (e === null || U(e) || Ee(e))
      return 1;
    if (sn(e))
      return 2;
  }
  function cn(e, t, n) {
    const r = [];
    let i = -1;
    for (; ++i < e.length; ) {
      const o = e[i].resolveAll;
      o && !r.includes(o) && (t = o(t, n), r.push(o));
    }
    return t;
  }
  const _n = {
    name: "attention",
    resolveAll: ql,
    tokenize: Wl
  };
  function ql(e, t) {
    let n = -1, r, i, o, l, a, u, s, f;
    for (; ++n < e.length; )
      if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
        for (r = n; r--; )
          if (e[r][0] === "exit" && e[r][1].type === "attentionSequence" && e[r][1]._open && t.sliceSerialize(e[r][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
            if ((e[r][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[r][1].end.offset - e[r][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3))
              continue;
            u = e[r][1].end.offset - e[r][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1;
            const c = {
              ...e[r][1].end
            }, p = {
              ...e[n][1].start
            };
            At(c, -u), At(p, u), l = {
              type: u > 1 ? "strongSequence" : "emphasisSequence",
              start: c,
              end: {
                ...e[r][1].end
              }
            }, a = {
              type: u > 1 ? "strongSequence" : "emphasisSequence",
              start: {
                ...e[n][1].start
              },
              end: p
            }, o = {
              type: u > 1 ? "strongText" : "emphasisText",
              start: {
                ...e[r][1].end
              },
              end: {
                ...e[n][1].start
              }
            }, i = {
              type: u > 1 ? "strong" : "emphasis",
              start: {
                ...l.start
              },
              end: {
                ...a.end
              }
            }, e[r][1].end = {
              ...l.start
            }, e[n][1].start = {
              ...a.end
            }, s = [], e[r][1].end.offset - e[r][1].start.offset && (s = ie(s, [
              [
                "enter",
                e[r][1],
                t
              ],
              [
                "exit",
                e[r][1],
                t
              ]
            ])), s = ie(s, [
              [
                "enter",
                i,
                t
              ],
              [
                "enter",
                l,
                t
              ],
              [
                "exit",
                l,
                t
              ],
              [
                "enter",
                o,
                t
              ]
            ]), s = ie(s, cn(t.parser.constructs.insideSpan.null, e.slice(r + 1, n), t)), s = ie(s, [
              [
                "exit",
                o,
                t
              ],
              [
                "enter",
                a,
                t
              ],
              [
                "exit",
                a,
                t
              ],
              [
                "exit",
                i,
                t
              ]
            ]), e[n][1].end.offset - e[n][1].start.offset ? (f = 2, s = ie(s, [
              [
                "enter",
                e[n][1],
                t
              ],
              [
                "exit",
                e[n][1],
                t
              ]
            ])) : f = 0, re(e, r - 1, n - r + 3, s), n = r + s.length - f - 2;
            break;
          }
      }
    for (n = -1; ++n < e.length; )
      e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
    return e;
  }
  function Wl(e, t) {
    const n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = Fe(r);
    let o;
    return l;
    function l(u) {
      return o = u, e.enter("attentionSequence"), a(u);
    }
    function a(u) {
      if (u === o)
        return e.consume(u), a;
      const s = e.exit("attentionSequence"), f = Fe(u), c = !f || f === 2 && i || n.includes(u), p = !i || i === 2 && f || n.includes(r);
      return s._open = !!(o === 42 ? c : c && (i || !p)), s._close = !!(o === 42 ? p : p && (f || !c)), t(u);
    }
  }
  function At(e, t) {
    e.column += t, e.offset += t, e._bufferIndex += t;
  }
  const Yl = {
    name: "autolink",
    tokenize: Xl
  };
  function Xl(e, t, n) {
    let r = 0;
    return i;
    function i(h) {
      return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(h), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), o;
    }
    function o(h) {
      return J(h) ? (e.consume(h), l) : h === 64 ? n(h) : s(h);
    }
    function l(h) {
      return h === 43 || h === 45 || h === 46 || G(h) ? (r = 1, a(h)) : s(h);
    }
    function a(h) {
      return h === 58 ? (e.consume(h), r = 0, u) : (h === 43 || h === 45 || h === 46 || G(h)) && r++ < 32 ? (e.consume(h), a) : (r = 0, s(h));
    }
    function u(h) {
      return h === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(h), e.exit("autolinkMarker"), e.exit("autolink"), t) : h === null || h === 32 || h === 60 || rn(h) ? n(h) : (e.consume(h), u);
    }
    function s(h) {
      return h === 64 ? (e.consume(h), f) : Ml(h) ? (e.consume(h), s) : n(h);
    }
    function f(h) {
      return G(h) ? c(h) : n(h);
    }
    function c(h) {
      return h === 46 ? (e.consume(h), r = 0, f) : h === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(h), e.exit("autolinkMarker"), e.exit("autolink"), t) : p(h);
    }
    function p(h) {
      if ((h === 45 || G(h)) && r++ < 63) {
        const d = h === 45 ? p : c;
        return e.consume(h), d;
      }
      return n(h);
    }
  }
  const Ye = {
    partial: true,
    tokenize: Ql
  };
  function Ql(e, t, n) {
    return r;
    function r(o) {
      return R(o) ? O(e, i, "linePrefix")(o) : i(o);
    }
    function i(o) {
      return o === null || v(o) ? t(o) : n(o);
    }
  }
  const Cr = {
    continuation: {
      tokenize: Kl
    },
    exit: Jl,
    name: "blockQuote",
    tokenize: Gl
  };
  function Gl(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      if (l === 62) {
        const a = r.containerState;
        return a.open || (e.enter("blockQuote", {
          _container: true
        }), a.open = true), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(l), e.exit("blockQuoteMarker"), o;
      }
      return n(l);
    }
    function o(l) {
      return R(l) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(l), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(l));
    }
  }
  function Kl(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return R(l) ? O(e, o, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(l) : o(l);
    }
    function o(l) {
      return e.attempt(Cr, t, n)(l);
    }
  }
  function Jl(e) {
    e.exit("blockQuote");
  }
  const Er = {
    name: "characterEscape",
    tokenize: Zl
  };
  function Zl(e, t, n) {
    return r;
    function r(o) {
      return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(o), e.exit("escapeMarker"), i;
    }
    function i(o) {
      return Bl(o) ? (e.enter("characterEscapeValue"), e.consume(o), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(o);
    }
  }
  const Ir = {
    name: "characterReference",
    tokenize: eo
  };
  function eo(e, t, n) {
    const r = this;
    let i = 0, o, l;
    return a;
    function a(c) {
      return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(c), e.exit("characterReferenceMarker"), u;
    }
    function u(c) {
      return c === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(c), e.exit("characterReferenceMarkerNumeric"), s) : (e.enter("characterReferenceValue"), o = 31, l = G, f(c));
    }
    function s(c) {
      return c === 88 || c === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(c), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), o = 6, l = Nl, f) : (e.enter("characterReferenceValue"), o = 7, l = Rn, f(c));
    }
    function f(c) {
      if (c === 59 && i) {
        const p = e.exit("characterReferenceValue");
        return l === G && !Qn(r.sliceSerialize(p)) ? n(c) : (e.enter("characterReferenceMarker"), e.consume(c), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
      }
      return l(c) && i++ < o ? (e.consume(c), f) : n(c);
    }
  }
  const Tt = {
    partial: true,
    tokenize: to
  }, Pt = {
    concrete: true,
    name: "codeFenced",
    tokenize: no
  };
  function no(e, t, n) {
    const r = this, i = {
      partial: true,
      tokenize: F
    };
    let o = 0, l = 0, a;
    return u;
    function u(w) {
      return s(w);
    }
    function s(w) {
      const M = r.events[r.events.length - 1];
      return o = M && M[1].type === "linePrefix" ? M[2].sliceSerialize(M[1], true).length : 0, a = w, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), f(w);
    }
    function f(w) {
      return w === a ? (l++, e.consume(w), f) : l < 3 ? n(w) : (e.exit("codeFencedFenceSequence"), R(w) ? O(e, c, "whitespace")(w) : c(w));
    }
    function c(w) {
      return w === null || v(w) ? (e.exit("codeFencedFence"), r.interrupt ? t(w) : e.check(Tt, x, L)(w)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", {
        contentType: "string"
      }), p(w));
    }
    function p(w) {
      return w === null || v(w) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), c(w)) : R(w) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), O(e, h, "whitespace")(w)) : w === 96 && w === a ? n(w) : (e.consume(w), p);
    }
    function h(w) {
      return w === null || v(w) ? c(w) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", {
        contentType: "string"
      }), d(w));
    }
    function d(w) {
      return w === null || v(w) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), c(w)) : w === 96 && w === a ? n(w) : (e.consume(w), d);
    }
    function x(w) {
      return e.attempt(i, L, C)(w);
    }
    function C(w) {
      return e.enter("lineEnding"), e.consume(w), e.exit("lineEnding"), y;
    }
    function y(w) {
      return o > 0 && R(w) ? O(e, A, "linePrefix", o + 1)(w) : A(w);
    }
    function A(w) {
      return w === null || v(w) ? e.check(Tt, x, L)(w) : (e.enter("codeFlowValue"), E(w));
    }
    function E(w) {
      return w === null || v(w) ? (e.exit("codeFlowValue"), A(w)) : (e.consume(w), E);
    }
    function L(w) {
      return e.exit("codeFenced"), t(w);
    }
    function F(w, M, $) {
      let B = 0;
      return k;
      function k(N) {
        return w.enter("lineEnding"), w.consume(N), w.exit("lineEnding"), T;
      }
      function T(N) {
        return w.enter("codeFencedFence"), R(N) ? O(w, P, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(N) : P(N);
      }
      function P(N) {
        return N === a ? (w.enter("codeFencedFenceSequence"), j(N)) : $(N);
      }
      function j(N) {
        return N === a ? (B++, w.consume(N), j) : B >= l ? (w.exit("codeFencedFenceSequence"), R(N) ? O(w, q, "whitespace")(N) : q(N)) : $(N);
      }
      function q(N) {
        return N === null || v(N) ? (w.exit("codeFencedFence"), M(N)) : $(N);
      }
    }
  }
  function to(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return l === null ? n(l) : (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), o);
    }
    function o(l) {
      return r.parser.lazy[r.now().line] ? n(l) : t(l);
    }
  }
  const dn = {
    name: "codeIndented",
    tokenize: io
  }, ro = {
    partial: true,
    tokenize: lo
  };
  function io(e, t, n) {
    const r = this;
    return i;
    function i(s) {
      return e.enter("codeIndented"), O(e, o, "linePrefix", 4 + 1)(s);
    }
    function o(s) {
      const f = r.events[r.events.length - 1];
      return f && f[1].type === "linePrefix" && f[2].sliceSerialize(f[1], true).length >= 4 ? l(s) : n(s);
    }
    function l(s) {
      return s === null ? u(s) : v(s) ? e.attempt(ro, l, u)(s) : (e.enter("codeFlowValue"), a(s));
    }
    function a(s) {
      return s === null || v(s) ? (e.exit("codeFlowValue"), l(s)) : (e.consume(s), a);
    }
    function u(s) {
      return e.exit("codeIndented"), t(s);
    }
  }
  function lo(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return r.parser.lazy[r.now().line] ? n(l) : v(l) ? (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), i) : O(e, o, "linePrefix", 4 + 1)(l);
    }
    function o(l) {
      const a = r.events[r.events.length - 1];
      return a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], true).length >= 4 ? t(l) : v(l) ? i(l) : n(l);
    }
  }
  const oo = {
    name: "codeText",
    previous: uo,
    resolve: ao,
    tokenize: so
  };
  function ao(e) {
    let t = e.length - 4, n = 3, r, i;
    if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
      for (r = n; ++r < t; )
        if (e[r][1].type === "codeTextData") {
          e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
          break;
        }
    }
    for (r = n - 1, t++; ++r <= t; )
      i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
    return e;
  }
  function uo(e) {
    return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
  }
  function so(e, t, n) {
    let r = 0, i, o;
    return l;
    function l(c) {
      return e.enter("codeText"), e.enter("codeTextSequence"), a(c);
    }
    function a(c) {
      return c === 96 ? (e.consume(c), r++, a) : (e.exit("codeTextSequence"), u(c));
    }
    function u(c) {
      return c === null ? n(c) : c === 32 ? (e.enter("space"), e.consume(c), e.exit("space"), u) : c === 96 ? (o = e.enter("codeTextSequence"), i = 0, f(c)) : v(c) ? (e.enter("lineEnding"), e.consume(c), e.exit("lineEnding"), u) : (e.enter("codeTextData"), s(c));
    }
    function s(c) {
      return c === null || c === 32 || c === 96 || v(c) ? (e.exit("codeTextData"), u(c)) : (e.consume(c), s);
    }
    function f(c) {
      return c === 96 ? (e.consume(c), i++, f) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(c)) : (o.type = "codeTextData", s(c));
    }
  }
  class co {
    constructor(t) {
      this.left = t ? [
        ...t
      ] : [], this.right = [];
    }
    get(t) {
      if (t < 0 || t >= this.left.length + this.right.length)
        throw new RangeError("Cannot access index `" + t + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
      return t < this.left.length ? this.left[t] : this.right[this.right.length - t + this.left.length - 1];
    }
    get length() {
      return this.left.length + this.right.length;
    }
    shift() {
      return this.setCursor(0), this.right.pop();
    }
    slice(t, n) {
      const r = n ?? Number.POSITIVE_INFINITY;
      return r < this.left.length ? this.left.slice(t, r) : t > this.left.length ? this.right.slice(this.right.length - r + this.left.length, this.right.length - t + this.left.length).reverse() : this.left.slice(t).concat(this.right.slice(this.right.length - r + this.left.length).reverse());
    }
    splice(t, n, r) {
      const i = n || 0;
      this.setCursor(Math.trunc(t));
      const o = this.right.splice(this.right.length - i, Number.POSITIVE_INFINITY);
      return r && Be(this.left, r), o.reverse();
    }
    pop() {
      return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
    }
    push(t) {
      this.setCursor(Number.POSITIVE_INFINITY), this.left.push(t);
    }
    pushMany(t) {
      this.setCursor(Number.POSITIVE_INFINITY), Be(this.left, t);
    }
    unshift(t) {
      this.setCursor(0), this.right.push(t);
    }
    unshiftMany(t) {
      this.setCursor(0), Be(this.right, t.reverse());
    }
    setCursor(t) {
      if (!(t === this.left.length || t > this.left.length && this.right.length === 0 || t < 0 && this.left.length === 0))
        if (t < this.left.length) {
          const n = this.left.splice(t, Number.POSITIVE_INFINITY);
          Be(this.right, n.reverse());
        } else {
          const n = this.right.splice(this.left.length + this.right.length - t, Number.POSITIVE_INFINITY);
          Be(this.left, n.reverse());
        }
    }
  }
  function Be(e, t) {
    let n = 0;
    if (t.length < 1e4)
      e.push(...t);
    else
      for (; n < t.length; )
        e.push(...t.slice(n, n + 1e4)), n += 1e4;
  }
  function Ar(e) {
    const t = {};
    let n = -1, r, i, o, l, a, u, s;
    const f = new co(e);
    for (; ++n < f.length; ) {
      for (; n in t; )
        n = t[n];
      if (r = f.get(n), n && r[1].type === "chunkFlow" && f.get(n - 1)[1].type === "listItemPrefix" && (u = r[1]._tokenizer.events, o = 0, o < u.length && u[o][1].type === "lineEndingBlank" && (o += 2), o < u.length && u[o][1].type === "content"))
        for (; ++o < u.length && u[o][1].type !== "content"; )
          u[o][1].type === "chunkText" && (u[o][1]._isInFirstContentOfListItem = true, o++);
      if (r[0] === "enter")
        r[1].contentType && (Object.assign(t, fo(f, n)), n = t[n], s = true);
      else if (r[1]._container) {
        for (o = n, i = void 0; o--; )
          if (l = f.get(o), l[1].type === "lineEnding" || l[1].type === "lineEndingBlank")
            l[0] === "enter" && (i && (f.get(i)[1].type = "lineEndingBlank"), l[1].type = "lineEnding", i = o);
          else if (!(l[1].type === "linePrefix" || l[1].type === "listItemIndent"))
            break;
        i && (r[1].end = {
          ...f.get(i)[1].start
        }, a = f.slice(i, n), a.unshift(r), f.splice(i, n - i + 1, a));
      }
    }
    return re(e, 0, Number.POSITIVE_INFINITY, f.slice(0)), !s;
  }
  function fo(e, t) {
    const n = e.get(t)[1], r = e.get(t)[2];
    let i = t - 1;
    const o = [];
    let l = n._tokenizer;
    l || (l = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (l._contentTypeTextTrailing = true));
    const a = l.events, u = [], s = {};
    let f, c, p = -1, h = n, d = 0, x = 0;
    const C = [
      x
    ];
    for (; h; ) {
      for (; e.get(++i)[1] !== h; )
        ;
      o.push(i), h._tokenizer || (f = r.sliceStream(h), h.next || f.push(null), c && l.defineSkip(h.start), h._isInFirstContentOfListItem && (l._gfmTasklistFirstContentOfListItem = true), l.write(f), h._isInFirstContentOfListItem && (l._gfmTasklistFirstContentOfListItem = void 0)), c = h, h = h.next;
    }
    for (h = n; ++p < a.length; )
      a[p][0] === "exit" && a[p - 1][0] === "enter" && a[p][1].type === a[p - 1][1].type && a[p][1].start.line !== a[p][1].end.line && (x = p + 1, C.push(x), h._tokenizer = void 0, h.previous = void 0, h = h.next);
    for (l.events = [], h ? (h._tokenizer = void 0, h.previous = void 0) : C.pop(), p = C.length; p--; ) {
      const y = a.slice(C[p], C[p + 1]), A = o.pop();
      u.push([
        A,
        A + y.length - 1
      ]), e.splice(A, 2, y);
    }
    for (u.reverse(), p = -1; ++p < u.length; )
      s[d + u[p][0]] = d + u[p][1], d += u[p][1] - u[p][0] - 1;
    return s;
  }
  const ho = {
    resolve: mo,
    tokenize: go
  }, po = {
    partial: true,
    tokenize: yo
  };
  function mo(e) {
    return Ar(e), e;
  }
  function go(e, t) {
    let n;
    return r;
    function r(a) {
      return e.enter("content"), n = e.enter("chunkContent", {
        contentType: "content"
      }), i(a);
    }
    function i(a) {
      return a === null ? o(a) : v(a) ? e.check(po, l, o)(a) : (e.consume(a), i);
    }
    function o(a) {
      return e.exit("chunkContent"), e.exit("content"), t(a);
    }
    function l(a) {
      return e.consume(a), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
        contentType: "content",
        previous: n
      }), n = n.next, i;
    }
  }
  function yo(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), O(e, o, "linePrefix");
    }
    function o(l) {
      if (l === null || v(l))
        return n(l);
      const a = r.events[r.events.length - 1];
      return !r.parser.constructs.disable.null.includes("codeIndented") && a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], true).length >= 4 ? t(l) : e.interrupt(r.parser.constructs.flow, n, t)(l);
    }
  }
  function Tr(e, t, n, r, i, o, l, a, u) {
    const s = u || Number.POSITIVE_INFINITY;
    let f = 0;
    return c;
    function c(y) {
      return y === 60 ? (e.enter(r), e.enter(i), e.enter(o), e.consume(y), e.exit(o), p) : y === null || y === 32 || y === 41 || rn(y) ? n(y) : (e.enter(r), e.enter(l), e.enter(a), e.enter("chunkString", {
        contentType: "string"
      }), x(y));
    }
    function p(y) {
      return y === 62 ? (e.enter(o), e.consume(y), e.exit(o), e.exit(i), e.exit(r), t) : (e.enter(a), e.enter("chunkString", {
        contentType: "string"
      }), h(y));
    }
    function h(y) {
      return y === 62 ? (e.exit("chunkString"), e.exit(a), p(y)) : y === null || y === 60 || v(y) ? n(y) : (e.consume(y), y === 92 ? d : h);
    }
    function d(y) {
      return y === 60 || y === 62 || y === 92 ? (e.consume(y), h) : h(y);
    }
    function x(y) {
      return !f && (y === null || y === 41 || U(y)) ? (e.exit("chunkString"), e.exit(a), e.exit(l), e.exit(r), t(y)) : f < s && y === 40 ? (e.consume(y), f++, x) : y === 41 ? (e.consume(y), f--, x) : y === null || y === 32 || y === 40 || rn(y) ? n(y) : (e.consume(y), y === 92 ? C : x);
    }
    function C(y) {
      return y === 40 || y === 41 || y === 92 ? (e.consume(y), x) : x(y);
    }
  }
  function Pr(e, t, n, r, i, o) {
    const l = this;
    let a = 0, u;
    return s;
    function s(h) {
      return e.enter(r), e.enter(i), e.consume(h), e.exit(i), e.enter(o), f;
    }
    function f(h) {
      return a > 999 || h === null || h === 91 || h === 93 && !u || h === 94 && !a && "_hiddenFootnoteSupport" in l.parser.constructs ? n(h) : h === 93 ? (e.exit(o), e.enter(i), e.consume(h), e.exit(i), e.exit(r), t) : v(h) ? (e.enter("lineEnding"), e.consume(h), e.exit("lineEnding"), f) : (e.enter("chunkString", {
        contentType: "string"
      }), c(h));
    }
    function c(h) {
      return h === null || h === 91 || h === 93 || v(h) || a++ > 999 ? (e.exit("chunkString"), f(h)) : (e.consume(h), u || (u = !R(h)), h === 92 ? p : c);
    }
    function p(h) {
      return h === 91 || h === 92 || h === 93 ? (e.consume(h), a++, c) : c(h);
    }
  }
  function vr(e, t, n, r, i, o) {
    let l;
    return a;
    function a(p) {
      return p === 34 || p === 39 || p === 40 ? (e.enter(r), e.enter(i), e.consume(p), e.exit(i), l = p === 40 ? 41 : p, u) : n(p);
    }
    function u(p) {
      return p === l ? (e.enter(i), e.consume(p), e.exit(i), e.exit(r), t) : (e.enter(o), s(p));
    }
    function s(p) {
      return p === l ? (e.exit(o), u(l)) : p === null ? n(p) : v(p) ? (e.enter("lineEnding"), e.consume(p), e.exit("lineEnding"), O(e, s, "linePrefix")) : (e.enter("chunkString", {
        contentType: "string"
      }), f(p));
    }
    function f(p) {
      return p === l || p === null || v(p) ? (e.exit("chunkString"), s(p)) : (e.consume(p), p === 92 ? c : f);
    }
    function c(p) {
      return p === l || p === 92 ? (e.consume(p), f) : f(p);
    }
  }
  function Ue(e, t) {
    let n;
    return r;
    function r(i) {
      return v(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = true, r) : R(i) ? O(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
    }
  }
  const ko = {
    name: "definition",
    tokenize: bo
  }, xo = {
    partial: true,
    tokenize: wo
  };
  function bo(e, t, n) {
    const r = this;
    let i;
    return o;
    function o(h) {
      return e.enter("definition"), l(h);
    }
    function l(h) {
      return Pr.call(r, e, a, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(h);
    }
    function a(h) {
      return i = se(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), h === 58 ? (e.enter("definitionMarker"), e.consume(h), e.exit("definitionMarker"), u) : n(h);
    }
    function u(h) {
      return U(h) ? Ue(e, s)(h) : s(h);
    }
    function s(h) {
      return Tr(e, f, n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(h);
    }
    function f(h) {
      return e.attempt(xo, c, c)(h);
    }
    function c(h) {
      return R(h) ? O(e, p, "whitespace")(h) : p(h);
    }
    function p(h) {
      return h === null || v(h) ? (e.exit("definition"), r.parser.defined.push(i), t(h)) : n(h);
    }
  }
  function wo(e, t, n) {
    return r;
    function r(a) {
      return U(a) ? Ue(e, i)(a) : n(a);
    }
    function i(a) {
      return vr(e, o, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(a);
    }
    function o(a) {
      return R(a) ? O(e, l, "whitespace")(a) : l(a);
    }
    function l(a) {
      return a === null || v(a) ? t(a) : n(a);
    }
  }
  const So = {
    name: "hardBreakEscape",
    tokenize: Co
  };
  function Co(e, t, n) {
    return r;
    function r(o) {
      return e.enter("hardBreakEscape"), e.consume(o), i;
    }
    function i(o) {
      return v(o) ? (e.exit("hardBreakEscape"), t(o)) : n(o);
    }
  }
  const Eo = {
    name: "headingAtx",
    resolve: Io,
    tokenize: Ao
  };
  function Io(e, t) {
    let n = e.length - 2, r = 3, i, o;
    return e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r && (i = {
      type: "atxHeadingText",
      start: e[r][1].start,
      end: e[n][1].end
    }, o = {
      type: "chunkText",
      start: e[r][1].start,
      end: e[n][1].end,
      contentType: "text"
    }, re(e, r, n - r + 1, [
      [
        "enter",
        i,
        t
      ],
      [
        "enter",
        o,
        t
      ],
      [
        "exit",
        o,
        t
      ],
      [
        "exit",
        i,
        t
      ]
    ])), e;
  }
  function Ao(e, t, n) {
    let r = 0;
    return i;
    function i(f) {
      return e.enter("atxHeading"), o(f);
    }
    function o(f) {
      return e.enter("atxHeadingSequence"), l(f);
    }
    function l(f) {
      return f === 35 && r++ < 6 ? (e.consume(f), l) : f === null || U(f) ? (e.exit("atxHeadingSequence"), a(f)) : n(f);
    }
    function a(f) {
      return f === 35 ? (e.enter("atxHeadingSequence"), u(f)) : f === null || v(f) ? (e.exit("atxHeading"), t(f)) : R(f) ? O(e, a, "whitespace")(f) : (e.enter("atxHeadingText"), s(f));
    }
    function u(f) {
      return f === 35 ? (e.consume(f), u) : (e.exit("atxHeadingSequence"), a(f));
    }
    function s(f) {
      return f === null || f === 35 || U(f) ? (e.exit("atxHeadingText"), a(f)) : (e.consume(f), s);
    }
  }
  const To = [
    "address",
    "article",
    "aside",
    "base",
    "basefont",
    "blockquote",
    "body",
    "caption",
    "center",
    "col",
    "colgroup",
    "dd",
    "details",
    "dialog",
    "dir",
    "div",
    "dl",
    "dt",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "frame",
    "frameset",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hr",
    "html",
    "iframe",
    "legend",
    "li",
    "link",
    "main",
    "menu",
    "menuitem",
    "nav",
    "noframes",
    "ol",
    "optgroup",
    "option",
    "p",
    "param",
    "search",
    "section",
    "summary",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "title",
    "tr",
    "track",
    "ul"
  ], vt = [
    "pre",
    "script",
    "style",
    "textarea"
  ], Po = {
    concrete: true,
    name: "htmlFlow",
    resolveTo: Do,
    tokenize: Lo
  }, vo = {
    partial: true,
    tokenize: Ro
  }, zo = {
    partial: true,
    tokenize: Fo
  };
  function Do(e) {
    let t = e.length;
    for (; t-- && !(e[t][0] === "enter" && e[t][1].type === "htmlFlow"); )
      ;
    return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
  }
  function Lo(e, t, n) {
    const r = this;
    let i, o, l, a, u;
    return s;
    function s(g) {
      return f(g);
    }
    function f(g) {
      return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(g), c;
    }
    function c(g) {
      return g === 33 ? (e.consume(g), p) : g === 47 ? (e.consume(g), o = true, x) : g === 63 ? (e.consume(g), i = 3, r.interrupt ? t : m) : J(g) ? (e.consume(g), l = String.fromCharCode(g), C) : n(g);
    }
    function p(g) {
      return g === 45 ? (e.consume(g), i = 2, h) : g === 91 ? (e.consume(g), i = 5, a = 0, d) : J(g) ? (e.consume(g), i = 4, r.interrupt ? t : m) : n(g);
    }
    function h(g) {
      return g === 45 ? (e.consume(g), r.interrupt ? t : m) : n(g);
    }
    function d(g) {
      const ae = "CDATA[";
      return g === ae.charCodeAt(a++) ? (e.consume(g), a === ae.length ? r.interrupt ? t : P : d) : n(g);
    }
    function x(g) {
      return J(g) ? (e.consume(g), l = String.fromCharCode(g), C) : n(g);
    }
    function C(g) {
      if (g === null || g === 47 || g === 62 || U(g)) {
        const ae = g === 47, be = l.toLowerCase();
        return !ae && !o && vt.includes(be) ? (i = 1, r.interrupt ? t(g) : P(g)) : To.includes(l.toLowerCase()) ? (i = 6, ae ? (e.consume(g), y) : r.interrupt ? t(g) : P(g)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(g) : o ? A(g) : E(g));
      }
      return g === 45 || G(g) ? (e.consume(g), l += String.fromCharCode(g), C) : n(g);
    }
    function y(g) {
      return g === 62 ? (e.consume(g), r.interrupt ? t : P) : n(g);
    }
    function A(g) {
      return R(g) ? (e.consume(g), A) : k(g);
    }
    function E(g) {
      return g === 47 ? (e.consume(g), k) : g === 58 || g === 95 || J(g) ? (e.consume(g), L) : R(g) ? (e.consume(g), E) : k(g);
    }
    function L(g) {
      return g === 45 || g === 46 || g === 58 || g === 95 || G(g) ? (e.consume(g), L) : F(g);
    }
    function F(g) {
      return g === 61 ? (e.consume(g), w) : R(g) ? (e.consume(g), F) : E(g);
    }
    function w(g) {
      return g === null || g === 60 || g === 61 || g === 62 || g === 96 ? n(g) : g === 34 || g === 39 ? (e.consume(g), u = g, M) : R(g) ? (e.consume(g), w) : $(g);
    }
    function M(g) {
      return g === u ? (e.consume(g), u = null, B) : g === null || v(g) ? n(g) : (e.consume(g), M);
    }
    function $(g) {
      return g === null || g === 34 || g === 39 || g === 47 || g === 60 || g === 61 || g === 62 || g === 96 || U(g) ? F(g) : (e.consume(g), $);
    }
    function B(g) {
      return g === 47 || g === 62 || R(g) ? E(g) : n(g);
    }
    function k(g) {
      return g === 62 ? (e.consume(g), T) : n(g);
    }
    function T(g) {
      return g === null || v(g) ? P(g) : R(g) ? (e.consume(g), T) : n(g);
    }
    function P(g) {
      return g === 45 && i === 2 ? (e.consume(g), Q) : g === 60 && i === 1 ? (e.consume(g), Y) : g === 62 && i === 4 ? (e.consume(g), oe) : g === 63 && i === 3 ? (e.consume(g), m) : g === 93 && i === 5 ? (e.consume(g), he) : v(g) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(vo, pe, j)(g)) : g === null || v(g) ? (e.exit("htmlFlowData"), j(g)) : (e.consume(g), P);
    }
    function j(g) {
      return e.check(zo, q, pe)(g);
    }
    function q(g) {
      return e.enter("lineEnding"), e.consume(g), e.exit("lineEnding"), N;
    }
    function N(g) {
      return g === null || v(g) ? j(g) : (e.enter("htmlFlowData"), P(g));
    }
    function Q(g) {
      return g === 45 ? (e.consume(g), m) : P(g);
    }
    function Y(g) {
      return g === 47 ? (e.consume(g), l = "", le) : P(g);
    }
    function le(g) {
      if (g === 62) {
        const ae = l.toLowerCase();
        return vt.includes(ae) ? (e.consume(g), oe) : P(g);
      }
      return J(g) && l.length < 8 ? (e.consume(g), l += String.fromCharCode(g), le) : P(g);
    }
    function he(g) {
      return g === 93 ? (e.consume(g), m) : P(g);
    }
    function m(g) {
      return g === 62 ? (e.consume(g), oe) : g === 45 && i === 2 ? (e.consume(g), m) : P(g);
    }
    function oe(g) {
      return g === null || v(g) ? (e.exit("htmlFlowData"), pe(g)) : (e.consume(g), oe);
    }
    function pe(g) {
      return e.exit("htmlFlow"), t(g);
    }
  }
  function Fo(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return v(l) ? (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), o) : n(l);
    }
    function o(l) {
      return r.parser.lazy[r.now().line] ? n(l) : t(l);
    }
  }
  function Ro(e, t, n) {
    return r;
    function r(i) {
      return e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), e.attempt(Ye, t, n);
    }
  }
  const _o = {
    name: "htmlText",
    tokenize: Oo
  };
  function Oo(e, t, n) {
    const r = this;
    let i, o, l;
    return a;
    function a(m) {
      return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(m), u;
    }
    function u(m) {
      return m === 33 ? (e.consume(m), s) : m === 47 ? (e.consume(m), F) : m === 63 ? (e.consume(m), E) : J(m) ? (e.consume(m), $) : n(m);
    }
    function s(m) {
      return m === 45 ? (e.consume(m), f) : m === 91 ? (e.consume(m), o = 0, d) : J(m) ? (e.consume(m), A) : n(m);
    }
    function f(m) {
      return m === 45 ? (e.consume(m), h) : n(m);
    }
    function c(m) {
      return m === null ? n(m) : m === 45 ? (e.consume(m), p) : v(m) ? (l = c, Y(m)) : (e.consume(m), c);
    }
    function p(m) {
      return m === 45 ? (e.consume(m), h) : c(m);
    }
    function h(m) {
      return m === 62 ? Q(m) : m === 45 ? p(m) : c(m);
    }
    function d(m) {
      const oe = "CDATA[";
      return m === oe.charCodeAt(o++) ? (e.consume(m), o === oe.length ? x : d) : n(m);
    }
    function x(m) {
      return m === null ? n(m) : m === 93 ? (e.consume(m), C) : v(m) ? (l = x, Y(m)) : (e.consume(m), x);
    }
    function C(m) {
      return m === 93 ? (e.consume(m), y) : x(m);
    }
    function y(m) {
      return m === 62 ? Q(m) : m === 93 ? (e.consume(m), y) : x(m);
    }
    function A(m) {
      return m === null || m === 62 ? Q(m) : v(m) ? (l = A, Y(m)) : (e.consume(m), A);
    }
    function E(m) {
      return m === null ? n(m) : m === 63 ? (e.consume(m), L) : v(m) ? (l = E, Y(m)) : (e.consume(m), E);
    }
    function L(m) {
      return m === 62 ? Q(m) : E(m);
    }
    function F(m) {
      return J(m) ? (e.consume(m), w) : n(m);
    }
    function w(m) {
      return m === 45 || G(m) ? (e.consume(m), w) : M(m);
    }
    function M(m) {
      return v(m) ? (l = M, Y(m)) : R(m) ? (e.consume(m), M) : Q(m);
    }
    function $(m) {
      return m === 45 || G(m) ? (e.consume(m), $) : m === 47 || m === 62 || U(m) ? B(m) : n(m);
    }
    function B(m) {
      return m === 47 ? (e.consume(m), Q) : m === 58 || m === 95 || J(m) ? (e.consume(m), k) : v(m) ? (l = B, Y(m)) : R(m) ? (e.consume(m), B) : Q(m);
    }
    function k(m) {
      return m === 45 || m === 46 || m === 58 || m === 95 || G(m) ? (e.consume(m), k) : T(m);
    }
    function T(m) {
      return m === 61 ? (e.consume(m), P) : v(m) ? (l = T, Y(m)) : R(m) ? (e.consume(m), T) : B(m);
    }
    function P(m) {
      return m === null || m === 60 || m === 61 || m === 62 || m === 96 ? n(m) : m === 34 || m === 39 ? (e.consume(m), i = m, j) : v(m) ? (l = P, Y(m)) : R(m) ? (e.consume(m), P) : (e.consume(m), q);
    }
    function j(m) {
      return m === i ? (e.consume(m), i = void 0, N) : m === null ? n(m) : v(m) ? (l = j, Y(m)) : (e.consume(m), j);
    }
    function q(m) {
      return m === null || m === 34 || m === 39 || m === 60 || m === 61 || m === 96 ? n(m) : m === 47 || m === 62 || U(m) ? B(m) : (e.consume(m), q);
    }
    function N(m) {
      return m === 47 || m === 62 || U(m) ? B(m) : n(m);
    }
    function Q(m) {
      return m === 62 ? (e.consume(m), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(m);
    }
    function Y(m) {
      return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(m), e.exit("lineEnding"), le;
    }
    function le(m) {
      return R(m) ? O(e, he, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(m) : he(m);
    }
    function he(m) {
      return e.enter("htmlTextData"), l(m);
    }
  }
  const Gn = {
    name: "labelEnd",
    resolveAll: jo,
    resolveTo: Ho,
    tokenize: Uo
  }, Mo = {
    tokenize: Vo
  }, No = {
    tokenize: $o
  }, Bo = {
    tokenize: qo
  };
  function jo(e) {
    let t = -1;
    const n = [];
    for (; ++t < e.length; ) {
      const r = e[t][1];
      if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
        const i = r.type === "labelImage" ? 4 : 2;
        r.type = "data", t += i;
      }
    }
    return e.length !== n.length && re(e, 0, e.length, n), e;
  }
  function Ho(e, t) {
    let n = e.length, r = 0, i, o, l, a;
    for (; n--; )
      if (i = e[n][1], o) {
        if (i.type === "link" || i.type === "labelLink" && i._inactive)
          break;
        e[n][0] === "enter" && i.type === "labelLink" && (i._inactive = true);
      } else if (l) {
        if (e[n][0] === "enter" && (i.type === "labelImage" || i.type === "labelLink") && !i._balanced && (o = n, i.type !== "labelLink")) {
          r = 2;
          break;
        }
      } else
        i.type === "labelEnd" && (l = n);
    const u = {
      type: e[o][1].type === "labelLink" ? "link" : "image",
      start: {
        ...e[o][1].start
      },
      end: {
        ...e[e.length - 1][1].end
      }
    }, s = {
      type: "label",
      start: {
        ...e[o][1].start
      },
      end: {
        ...e[l][1].end
      }
    }, f = {
      type: "labelText",
      start: {
        ...e[o + r + 2][1].end
      },
      end: {
        ...e[l - 2][1].start
      }
    };
    return a = [
      [
        "enter",
        u,
        t
      ],
      [
        "enter",
        s,
        t
      ]
    ], a = ie(a, e.slice(o + 1, o + r + 3)), a = ie(a, [
      [
        "enter",
        f,
        t
      ]
    ]), a = ie(a, cn(t.parser.constructs.insideSpan.null, e.slice(o + r + 4, l - 3), t)), a = ie(a, [
      [
        "exit",
        f,
        t
      ],
      e[l - 2],
      e[l - 1],
      [
        "exit",
        s,
        t
      ]
    ]), a = ie(a, e.slice(l + 1)), a = ie(a, [
      [
        "exit",
        u,
        t
      ]
    ]), re(e, o, e.length, a), e;
  }
  function Uo(e, t, n) {
    const r = this;
    let i = r.events.length, o, l;
    for (; i--; )
      if ((r.events[i][1].type === "labelImage" || r.events[i][1].type === "labelLink") && !r.events[i][1]._balanced) {
        o = r.events[i][1];
        break;
      }
    return a;
    function a(p) {
      return o ? o._inactive ? c(p) : (l = r.parser.defined.includes(se(r.sliceSerialize({
        start: o.end,
        end: r.now()
      }))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(p), e.exit("labelMarker"), e.exit("labelEnd"), u) : n(p);
    }
    function u(p) {
      return p === 40 ? e.attempt(Mo, f, l ? f : c)(p) : p === 91 ? e.attempt(No, f, l ? s : c)(p) : l ? f(p) : c(p);
    }
    function s(p) {
      return e.attempt(Bo, f, c)(p);
    }
    function f(p) {
      return t(p);
    }
    function c(p) {
      return o._balanced = true, n(p);
    }
  }
  function Vo(e, t, n) {
    return r;
    function r(c) {
      return e.enter("resource"), e.enter("resourceMarker"), e.consume(c), e.exit("resourceMarker"), i;
    }
    function i(c) {
      return U(c) ? Ue(e, o)(c) : o(c);
    }
    function o(c) {
      return c === 41 ? f(c) : Tr(e, l, a, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(c);
    }
    function l(c) {
      return U(c) ? Ue(e, u)(c) : f(c);
    }
    function a(c) {
      return n(c);
    }
    function u(c) {
      return c === 34 || c === 39 || c === 40 ? vr(e, s, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(c) : f(c);
    }
    function s(c) {
      return U(c) ? Ue(e, f)(c) : f(c);
    }
    function f(c) {
      return c === 41 ? (e.enter("resourceMarker"), e.consume(c), e.exit("resourceMarker"), e.exit("resource"), t) : n(c);
    }
  }
  function $o(e, t, n) {
    const r = this;
    return i;
    function i(a) {
      return Pr.call(r, e, o, l, "reference", "referenceMarker", "referenceString")(a);
    }
    function o(a) {
      return r.parser.defined.includes(se(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(a) : n(a);
    }
    function l(a) {
      return n(a);
    }
  }
  function qo(e, t, n) {
    return r;
    function r(o) {
      return e.enter("reference"), e.enter("referenceMarker"), e.consume(o), e.exit("referenceMarker"), i;
    }
    function i(o) {
      return o === 93 ? (e.enter("referenceMarker"), e.consume(o), e.exit("referenceMarker"), e.exit("reference"), t) : n(o);
    }
  }
  const Wo = {
    name: "labelStartImage",
    resolveAll: Gn.resolveAll,
    tokenize: Yo
  };
  function Yo(e, t, n) {
    const r = this;
    return i;
    function i(a) {
      return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(a), e.exit("labelImageMarker"), o;
    }
    function o(a) {
      return a === 91 ? (e.enter("labelMarker"), e.consume(a), e.exit("labelMarker"), e.exit("labelImage"), l) : n(a);
    }
    function l(a) {
      return a === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(a) : t(a);
    }
  }
  const Xo = {
    name: "labelStartLink",
    resolveAll: Gn.resolveAll,
    tokenize: Qo
  };
  function Qo(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return e.enter("labelLink"), e.enter("labelMarker"), e.consume(l), e.exit("labelMarker"), e.exit("labelLink"), o;
    }
    function o(l) {
      return l === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(l) : t(l);
    }
  }
  const yn = {
    name: "lineEnding",
    tokenize: Go
  };
  function Go(e, t) {
    return n;
    function n(r) {
      return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), O(e, t, "linePrefix");
    }
  }
  const en = {
    name: "thematicBreak",
    tokenize: Ko
  };
  function Ko(e, t, n) {
    let r = 0, i;
    return o;
    function o(s) {
      return e.enter("thematicBreak"), l(s);
    }
    function l(s) {
      return i = s, a(s);
    }
    function a(s) {
      return s === i ? (e.enter("thematicBreakSequence"), u(s)) : r >= 3 && (s === null || v(s)) ? (e.exit("thematicBreak"), t(s)) : n(s);
    }
    function u(s) {
      return s === i ? (e.consume(s), r++, u) : (e.exit("thematicBreakSequence"), R(s) ? O(e, a, "whitespace")(s) : a(s));
    }
  }
  const Z = {
    continuation: {
      tokenize: na
    },
    exit: ra,
    name: "list",
    tokenize: ea
  }, Jo = {
    partial: true,
    tokenize: ia
  }, Zo = {
    partial: true,
    tokenize: ta
  };
  function ea(e, t, n) {
    const r = this, i = r.events[r.events.length - 1];
    let o = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], true).length : 0, l = 0;
    return a;
    function a(h) {
      const d = r.containerState.type || (h === 42 || h === 43 || h === 45 ? "listUnordered" : "listOrdered");
      if (d === "listUnordered" ? !r.containerState.marker || h === r.containerState.marker : Rn(h)) {
        if (r.containerState.type || (r.containerState.type = d, e.enter(d, {
          _container: true
        })), d === "listUnordered")
          return e.enter("listItemPrefix"), h === 42 || h === 45 ? e.check(en, n, s)(h) : s(h);
        if (!r.interrupt || h === 49)
          return e.enter("listItemPrefix"), e.enter("listItemValue"), u(h);
      }
      return n(h);
    }
    function u(h) {
      return Rn(h) && ++l < 10 ? (e.consume(h), u) : (!r.interrupt || l < 2) && (r.containerState.marker ? h === r.containerState.marker : h === 41 || h === 46) ? (e.exit("listItemValue"), s(h)) : n(h);
    }
    function s(h) {
      return e.enter("listItemMarker"), e.consume(h), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || h, e.check(Ye, r.interrupt ? n : f, e.attempt(Jo, p, c));
    }
    function f(h) {
      return r.containerState.initialBlankLine = true, o++, p(h);
    }
    function c(h) {
      return R(h) ? (e.enter("listItemPrefixWhitespace"), e.consume(h), e.exit("listItemPrefixWhitespace"), p) : n(h);
    }
    function p(h) {
      return r.containerState.size = o + r.sliceSerialize(e.exit("listItemPrefix"), true).length, t(h);
    }
  }
  function na(e, t, n) {
    const r = this;
    return r.containerState._closeFlow = void 0, e.check(Ye, i, o);
    function i(a) {
      return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, O(e, t, "listItemIndent", r.containerState.size + 1)(a);
    }
    function o(a) {
      return r.containerState.furtherBlankLines || !R(a) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, l(a)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(Zo, t, l)(a));
    }
    function l(a) {
      return r.containerState._closeFlow = true, r.interrupt = void 0, O(e, e.attempt(Z, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(a);
    }
  }
  function ta(e, t, n) {
    const r = this;
    return O(e, i, "listItemIndent", r.containerState.size + 1);
    function i(o) {
      const l = r.events[r.events.length - 1];
      return l && l[1].type === "listItemIndent" && l[2].sliceSerialize(l[1], true).length === r.containerState.size ? t(o) : n(o);
    }
  }
  function ra(e) {
    e.exit(this.containerState.type);
  }
  function ia(e, t, n) {
    const r = this;
    return O(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4 + 1);
    function i(o) {
      const l = r.events[r.events.length - 1];
      return !R(o) && l && l[1].type === "listItemPrefixWhitespace" ? t(o) : n(o);
    }
  }
  const zt = {
    name: "setextUnderline",
    resolveTo: la,
    tokenize: oa
  };
  function la(e, t) {
    let n = e.length, r, i, o;
    for (; n--; )
      if (e[n][0] === "enter") {
        if (e[n][1].type === "content") {
          r = n;
          break;
        }
        e[n][1].type === "paragraph" && (i = n);
      } else
        e[n][1].type === "content" && e.splice(n, 1), !o && e[n][1].type === "definition" && (o = n);
    const l = {
      type: "setextHeading",
      start: {
        ...e[r][1].start
      },
      end: {
        ...e[e.length - 1][1].end
      }
    };
    return e[i][1].type = "setextHeadingText", o ? (e.splice(i, 0, [
      "enter",
      l,
      t
    ]), e.splice(o + 1, 0, [
      "exit",
      e[r][1],
      t
    ]), e[r][1].end = {
      ...e[o][1].end
    }) : e[r][1] = l, e.push([
      "exit",
      l,
      t
    ]), e;
  }
  function oa(e, t, n) {
    const r = this;
    let i;
    return o;
    function o(s) {
      let f = r.events.length, c;
      for (; f--; )
        if (r.events[f][1].type !== "lineEnding" && r.events[f][1].type !== "linePrefix" && r.events[f][1].type !== "content") {
          c = r.events[f][1].type === "paragraph";
          break;
        }
      return !r.parser.lazy[r.now().line] && (r.interrupt || c) ? (e.enter("setextHeadingLine"), i = s, l(s)) : n(s);
    }
    function l(s) {
      return e.enter("setextHeadingLineSequence"), a(s);
    }
    function a(s) {
      return s === i ? (e.consume(s), a) : (e.exit("setextHeadingLineSequence"), R(s) ? O(e, u, "lineSuffix")(s) : u(s));
    }
    function u(s) {
      return s === null || v(s) ? (e.exit("setextHeadingLine"), t(s)) : n(s);
    }
  }
  const aa = {
    tokenize: ua
  };
  function ua(e) {
    const t = this, n = e.attempt(Ye, r, e.attempt(this.parser.constructs.flowInitial, i, O(e, e.attempt(this.parser.constructs.flow, i, e.attempt(ho, i)), "linePrefix")));
    return n;
    function r(o) {
      if (o === null) {
        e.consume(o);
        return;
      }
      return e.enter("lineEndingBlank"), e.consume(o), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
    }
    function i(o) {
      if (o === null) {
        e.consume(o);
        return;
      }
      return e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), t.currentConstruct = void 0, n;
    }
  }
  const sa = {
    resolveAll: Dr()
  }, ca = zr("string"), fa = zr("text");
  function zr(e) {
    return {
      resolveAll: Dr(e === "text" ? ha : void 0),
      tokenize: t
    };
    function t(n) {
      const r = this, i = this.parser.constructs[e], o = n.attempt(i, l, a);
      return l;
      function l(f) {
        return s(f) ? o(f) : a(f);
      }
      function a(f) {
        if (f === null) {
          n.consume(f);
          return;
        }
        return n.enter("data"), n.consume(f), u;
      }
      function u(f) {
        return s(f) ? (n.exit("data"), o(f)) : (n.consume(f), u);
      }
      function s(f) {
        if (f === null)
          return true;
        const c = i[f];
        let p = -1;
        if (c)
          for (; ++p < c.length; ) {
            const h = c[p];
            if (!h.previous || h.previous.call(r, r.previous))
              return true;
          }
        return false;
      }
    }
  }
  function Dr(e) {
    return t;
    function t(n, r) {
      let i = -1, o;
      for (; ++i <= n.length; )
        o === void 0 ? n[i] && n[i][1].type === "data" && (o = i, i++) : (!n[i] || n[i][1].type !== "data") && (i !== o + 2 && (n[o][1].end = n[i - 1][1].end, n.splice(o + 2, i - o - 2), i = o + 2), o = void 0);
      return e ? e(n, r) : n;
    }
  }
  function ha(e, t) {
    let n = 0;
    for (; ++n <= e.length; )
      if ((n === e.length || e[n][1].type === "lineEnding") && e[n - 1][1].type === "data") {
        const r = e[n - 1][1], i = t.sliceStream(r);
        let o = i.length, l = -1, a = 0, u;
        for (; o--; ) {
          const s = i[o];
          if (typeof s == "string") {
            for (l = s.length; s.charCodeAt(l - 1) === 32; )
              a++, l--;
            if (l)
              break;
            l = -1;
          } else if (s === -2)
            u = true, a++;
          else if (s !== -1) {
            o++;
            break;
          }
        }
        if (t._contentTypeTextTrailing && n === e.length && (a = 0), a) {
          const s = {
            type: n === e.length || u || a < 2 ? "lineSuffix" : "hardBreakTrailing",
            start: {
              _bufferIndex: o ? l : r.start._bufferIndex + l,
              _index: r.start._index + o,
              line: r.end.line,
              column: r.end.column - a,
              offset: r.end.offset - a
            },
            end: {
              ...r.end
            }
          };
          r.end = {
            ...s.start
          }, r.start.offset === r.end.offset ? Object.assign(r, s) : (e.splice(n, 0, [
            "enter",
            s,
            t
          ], [
            "exit",
            s,
            t
          ]), n += 2);
        }
        n++;
      }
    return e;
  }
  const pa = {
    42: Z,
    43: Z,
    45: Z,
    48: Z,
    49: Z,
    50: Z,
    51: Z,
    52: Z,
    53: Z,
    54: Z,
    55: Z,
    56: Z,
    57: Z,
    62: Cr
  }, ma = {
    91: ko
  }, ga = {
    [-2]: dn,
    [-1]: dn,
    32: dn
  }, da = {
    35: Eo,
    42: en,
    45: [
      zt,
      en
    ],
    60: Po,
    61: zt,
    95: en,
    96: Pt,
    126: Pt
  }, ya = {
    38: Ir,
    92: Er
  }, ka = {
    [-5]: yn,
    [-4]: yn,
    [-3]: yn,
    33: Wo,
    38: Ir,
    42: _n,
    60: [
      Yl,
      _o
    ],
    91: Xo,
    92: [
      So,
      Er
    ],
    93: Gn,
    95: _n,
    96: oo
  }, xa = {
    null: [
      _n,
      sa
    ]
  }, ba = {
    null: [
      42,
      95
    ]
  }, wa = {
    null: []
  }, Sa = Object.freeze(Object.defineProperty({
    __proto__: null,
    attentionMarkers: ba,
    contentInitial: ma,
    disable: wa,
    document: pa,
    flow: da,
    flowInitial: ga,
    insideSpan: xa,
    string: ya,
    text: ka
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  function Ca(e, t, n) {
    let r = {
      _bufferIndex: -1,
      _index: 0,
      line: n && n.line || 1,
      column: n && n.column || 1,
      offset: n && n.offset || 0
    };
    const i = {}, o = [];
    let l = [], a = [];
    const u = {
      attempt: M(F),
      check: M(w),
      consume: A,
      enter: E,
      exit: L,
      interrupt: M(w, {
        interrupt: true
      })
    }, s = {
      code: null,
      containerState: {},
      defineSkip: x,
      events: [],
      now: d,
      parser: e,
      previous: null,
      sliceSerialize: p,
      sliceStream: h,
      write: c
    };
    let f = t.tokenize.call(s, u);
    return t.resolveAll && o.push(t), s;
    function c(T) {
      return l = ie(l, T), C(), l[l.length - 1] !== null ? [] : ($(t, 0), s.events = cn(o, s.events, s), s.events);
    }
    function p(T, P) {
      return Ia(h(T), P);
    }
    function h(T) {
      return Ea(l, T);
    }
    function d() {
      const { _bufferIndex: T, _index: P, line: j, column: q, offset: N } = r;
      return {
        _bufferIndex: T,
        _index: P,
        line: j,
        column: q,
        offset: N
      };
    }
    function x(T) {
      i[T.line] = T.column, k();
    }
    function C() {
      let T;
      for (; r._index < l.length; ) {
        const P = l[r._index];
        if (typeof P == "string")
          for (T = r._index, r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === T && r._bufferIndex < P.length; )
            y(P.charCodeAt(r._bufferIndex));
        else
          y(P);
      }
    }
    function y(T) {
      f = f(T);
    }
    function A(T) {
      v(T) ? (r.line++, r.column = 1, r.offset += T === -3 ? 2 : 1, k()) : T !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === l[r._index].length && (r._bufferIndex = -1, r._index++)), s.previous = T;
    }
    function E(T, P) {
      const j = P || {};
      return j.type = T, j.start = d(), s.events.push([
        "enter",
        j,
        s
      ]), a.push(j), j;
    }
    function L(T) {
      const P = a.pop();
      return P.end = d(), s.events.push([
        "exit",
        P,
        s
      ]), P;
    }
    function F(T, P) {
      $(T, P.from);
    }
    function w(T, P) {
      P.restore();
    }
    function M(T, P) {
      return j;
      function j(q, N, Q) {
        let Y, le, he, m;
        return Array.isArray(q) ? pe(q) : "tokenize" in q ? pe([
          q
        ]) : oe(q);
        function oe(X) {
          return Oe;
          function Oe(ye) {
            const Ae = ye !== null && X[ye], Te = ye !== null && X.null, Qe = [
              ...Array.isArray(Ae) ? Ae : Ae ? [
                Ae
              ] : [],
              ...Array.isArray(Te) ? Te : Te ? [
                Te
              ] : []
            ];
            return pe(Qe)(ye);
          }
        }
        function pe(X) {
          return Y = X, le = 0, X.length === 0 ? Q : g(X[le]);
        }
        function g(X) {
          return Oe;
          function Oe(ye) {
            return m = B(), he = X, X.partial || (s.currentConstruct = X), X.name && s.parser.constructs.disable.null.includes(X.name) ? be() : X.tokenize.call(P ? Object.assign(Object.create(s), P) : s, u, ae, be)(ye);
          }
        }
        function ae(X) {
          return T(he, m), N;
        }
        function be(X) {
          return m.restore(), ++le < Y.length ? g(Y[le]) : Q;
        }
      }
    }
    function $(T, P) {
      T.resolveAll && !o.includes(T) && o.push(T), T.resolve && re(s.events, P, s.events.length - P, T.resolve(s.events.slice(P), s)), T.resolveTo && (s.events = T.resolveTo(s.events, s));
    }
    function B() {
      const T = d(), P = s.previous, j = s.currentConstruct, q = s.events.length, N = Array.from(a);
      return {
        from: q,
        restore: Q
      };
      function Q() {
        r = T, s.previous = P, s.currentConstruct = j, s.events.length = q, a = N, k();
      }
    }
    function k() {
      r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
    }
  }
  function Ea(e, t) {
    const n = t.start._index, r = t.start._bufferIndex, i = t.end._index, o = t.end._bufferIndex;
    let l;
    if (n === i)
      l = [
        e[n].slice(r, o)
      ];
    else {
      if (l = e.slice(n, i), r > -1) {
        const a = l[0];
        typeof a == "string" ? l[0] = a.slice(r) : l.shift();
      }
      o > 0 && l.push(e[i].slice(0, o));
    }
    return l;
  }
  function Ia(e, t) {
    let n = -1;
    const r = [];
    let i;
    for (; ++n < e.length; ) {
      const o = e[n];
      let l;
      if (typeof o == "string")
        l = o;
      else
        switch (o) {
          case -5: {
            l = "\r";
            break;
          }
          case -4: {
            l = `
`;
            break;
          }
          case -3: {
            l = `\r
`;
            break;
          }
          case -2: {
            l = t ? " " : "	";
            break;
          }
          case -1: {
            if (!t && i)
              continue;
            l = " ";
            break;
          }
          default:
            l = String.fromCharCode(o);
        }
      i = o === -2, r.push(l);
    }
    return r.join("");
  }
  function Aa(e) {
    const r = {
      constructs: wr([
        Sa,
        ...(e || {}).extensions || []
      ]),
      content: i(jl),
      defined: [],
      document: i(Ul),
      flow: i(aa),
      lazy: {},
      string: i(ca),
      text: i(fa)
    };
    return r;
    function i(o) {
      return l;
      function l(a) {
        return Ca(r, o, a);
      }
    }
  }
  function Ta(e) {
    for (; !Ar(e); )
      ;
    return e;
  }
  const Dt = /[\0\t\n\r]/g;
  function Pa() {
    let e = 1, t = "", n = true, r;
    return i;
    function i(o, l, a) {
      const u = [];
      let s, f, c, p, h;
      for (o = t + (typeof o == "string" ? o.toString() : new TextDecoder(l || void 0).decode(o)), c = 0, t = "", n && (o.charCodeAt(0) === 65279 && c++, n = void 0); c < o.length; ) {
        if (Dt.lastIndex = c, s = Dt.exec(o), p = s && s.index !== void 0 ? s.index : o.length, h = o.charCodeAt(p), !s) {
          t = o.slice(c);
          break;
        }
        if (h === 10 && c === p && r)
          u.push(-3), r = void 0;
        else
          switch (r && (u.push(-5), r = void 0), c < p && (u.push(o.slice(c, p)), e += p - c), h) {
            case 0: {
              u.push(65533), e++;
              break;
            }
            case 9: {
              for (f = Math.ceil(e / 4) * 4, u.push(-2); e++ < f; )
                u.push(-1);
              break;
            }
            case 10: {
              u.push(-4), e = 1;
              break;
            }
            default:
              r = true, e = 1;
          }
        c = p + 1;
      }
      return a && (r && u.push(-5), t && u.push(t), u.push(null)), u;
    }
  }
  const va = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
  function za(e) {
    return e.replace(va, Da);
  }
  function Da(e, t, n) {
    if (t)
      return t;
    if (n.charCodeAt(0) === 35) {
      const i = n.charCodeAt(1), o = i === 120 || i === 88;
      return Sr(n.slice(o ? 2 : 1), o ? 16 : 10);
    }
    return Qn(n) || e;
  }
  const Lr = {}.hasOwnProperty;
  function La(e, t, n) {
    return t && typeof t == "object" && (n = t, t = void 0), Fa(n)(Ta(Aa(n).document().write(Pa()(e, t, true))));
  }
  function Fa(e) {
    const t = {
      transforms: [],
      canContainEols: [
        "emphasis",
        "fragment",
        "heading",
        "paragraph",
        "strong"
      ],
      enter: {
        autolink: o(st),
        autolinkProtocol: B,
        autolinkEmail: B,
        atxHeading: o(ot),
        blockQuote: o(Te),
        characterEscape: B,
        characterReference: B,
        codeFenced: o(Qe),
        codeFencedFenceInfo: l,
        codeFencedFenceMeta: l,
        codeIndented: o(Qe, l),
        codeText: o(hi, l),
        codeTextData: B,
        data: B,
        codeFlowValue: B,
        definition: o(pi),
        definitionDestinationString: l,
        definitionLabelString: l,
        definitionTitleString: l,
        emphasis: o(mi),
        hardBreakEscape: o(at),
        hardBreakTrailing: o(at),
        htmlFlow: o(ut, l),
        htmlFlowData: B,
        htmlText: o(ut, l),
        htmlTextData: B,
        image: o(gi),
        label: l,
        link: o(st),
        listItem: o(di),
        listItemValue: p,
        listOrdered: o(ct, c),
        listUnordered: o(ct),
        paragraph: o(yi),
        reference: g,
        referenceString: l,
        resourceDestinationString: l,
        resourceTitleString: l,
        setextHeading: o(ot),
        strong: o(ki),
        thematicBreak: o(bi)
      },
      exit: {
        atxHeading: u(),
        atxHeadingSequence: F,
        autolink: u(),
        autolinkEmail: Ae,
        autolinkProtocol: ye,
        blockQuote: u(),
        characterEscapeValue: k,
        characterReferenceMarkerHexadecimal: be,
        characterReferenceMarkerNumeric: be,
        characterReferenceValue: X,
        characterReference: Oe,
        codeFenced: u(C),
        codeFencedFence: x,
        codeFencedFenceInfo: h,
        codeFencedFenceMeta: d,
        codeFlowValue: k,
        codeIndented: u(y),
        codeText: u(N),
        codeTextData: k,
        data: k,
        definition: u(),
        definitionDestinationString: L,
        definitionLabelString: A,
        definitionTitleString: E,
        emphasis: u(),
        hardBreakEscape: u(P),
        hardBreakTrailing: u(P),
        htmlFlow: u(j),
        htmlFlowData: k,
        htmlText: u(q),
        htmlTextData: k,
        image: u(Y),
        label: he,
        labelText: le,
        lineEnding: T,
        link: u(Q),
        listItem: u(),
        listOrdered: u(),
        listUnordered: u(),
        paragraph: u(),
        referenceString: ae,
        resourceDestinationString: m,
        resourceTitleString: oe,
        resource: pe,
        setextHeading: u($),
        setextHeadingLineSequence: M,
        setextHeadingText: w,
        strong: u(),
        thematicBreak: u()
      }
    };
    Fr(t, (e || {}).mdastExtensions || []);
    const n = {};
    return r;
    function r(b) {
      let I = {
        type: "root",
        children: []
      };
      const z = {
        stack: [
          I
        ],
        tokenStack: [],
        config: t,
        enter: a,
        exit: s,
        buffer: l,
        resume: f,
        data: n
      }, _ = [];
      let H = -1;
      for (; ++H < b.length; )
        if (b[H][1].type === "listOrdered" || b[H][1].type === "listUnordered")
          if (b[H][0] === "enter")
            _.push(H);
          else {
            const ue = _.pop();
            H = i(b, ue, H);
          }
      for (H = -1; ++H < b.length; ) {
        const ue = t[b[H][0]];
        Lr.call(ue, b[H][1].type) && ue[b[H][1].type].call(Object.assign({
          sliceSerialize: b[H][2].sliceSerialize
        }, z), b[H][1]);
      }
      if (z.tokenStack.length > 0) {
        const ue = z.tokenStack[z.tokenStack.length - 1];
        (ue[1] || Lt).call(z, void 0, ue[0]);
      }
      for (I.position = {
        start: ke(b.length > 0 ? b[0][1].start : {
          line: 1,
          column: 1,
          offset: 0
        }),
        end: ke(b.length > 0 ? b[b.length - 2][1].end : {
          line: 1,
          column: 1,
          offset: 0
        })
      }, H = -1; ++H < t.transforms.length; )
        I = t.transforms[H](I) || I;
      return I;
    }
    function i(b, I, z) {
      let _ = I - 1, H = -1, ue = false, we, me, Me, Ne;
      for (; ++_ <= z; ) {
        const ne = b[_];
        switch (ne[1].type) {
          case "listUnordered":
          case "listOrdered":
          case "blockQuote": {
            ne[0] === "enter" ? H++ : H--, Ne = void 0;
            break;
          }
          case "lineEndingBlank": {
            ne[0] === "enter" && (we && !Ne && !H && !Me && (Me = _), Ne = void 0);
            break;
          }
          case "linePrefix":
          case "listItemValue":
          case "listItemMarker":
          case "listItemPrefix":
          case "listItemPrefixWhitespace":
            break;
          default:
            Ne = void 0;
        }
        if (!H && ne[0] === "enter" && ne[1].type === "listItemPrefix" || H === -1 && ne[0] === "exit" && (ne[1].type === "listUnordered" || ne[1].type === "listOrdered")) {
          if (we) {
            let Pe = _;
            for (me = void 0; Pe--; ) {
              const ge = b[Pe];
              if (ge[1].type === "lineEnding" || ge[1].type === "lineEndingBlank") {
                if (ge[0] === "exit")
                  continue;
                me && (b[me][1].type = "lineEndingBlank", ue = true), ge[1].type = "lineEnding", me = Pe;
              } else if (!(ge[1].type === "linePrefix" || ge[1].type === "blockQuotePrefix" || ge[1].type === "blockQuotePrefixWhitespace" || ge[1].type === "blockQuoteMarker" || ge[1].type === "listItemIndent"))
                break;
            }
            Me && (!me || Me < me) && (we._spread = true), we.end = Object.assign({}, me ? b[me][1].start : ne[1].end), b.splice(me || _, 0, [
              "exit",
              we,
              ne[2]
            ]), _++, z++;
          }
          if (ne[1].type === "listItemPrefix") {
            const Pe = {
              type: "listItem",
              _spread: false,
              start: Object.assign({}, ne[1].start),
              end: void 0
            };
            we = Pe, b.splice(_, 0, [
              "enter",
              Pe,
              ne[2]
            ]), _++, z++, Me = void 0, Ne = true;
          }
        }
      }
      return b[I][1]._spread = ue, z;
    }
    function o(b, I) {
      return z;
      function z(_) {
        a.call(this, b(_), _), I && I.call(this, _);
      }
    }
    function l() {
      this.stack.push({
        type: "fragment",
        children: []
      });
    }
    function a(b, I, z) {
      this.stack[this.stack.length - 1].children.push(b), this.stack.push(b), this.tokenStack.push([
        I,
        z || void 0
      ]), b.position = {
        start: ke(I.start),
        end: void 0
      };
    }
    function u(b) {
      return I;
      function I(z) {
        b && b.call(this, z), s.call(this, z);
      }
    }
    function s(b, I) {
      const z = this.stack.pop(), _ = this.tokenStack.pop();
      if (_)
        _[0].type !== b.type && (I ? I.call(this, b, _[0]) : (_[1] || Lt).call(this, b, _[0]));
      else
        throw new Error("Cannot close `" + b.type + "` (" + He({
          start: b.start,
          end: b.end
        }) + "): it\u2019s not open");
      z.position.end = ke(b.end);
    }
    function f() {
      return Xn(this.stack.pop());
    }
    function c() {
      this.data.expectingFirstListItemValue = true;
    }
    function p(b) {
      if (this.data.expectingFirstListItemValue) {
        const I = this.stack[this.stack.length - 2];
        I.start = Number.parseInt(this.sliceSerialize(b), 10), this.data.expectingFirstListItemValue = void 0;
      }
    }
    function h() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.lang = b;
    }
    function d() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.meta = b;
    }
    function x() {
      this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = true);
    }
    function C() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.value = b.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
    }
    function y() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.value = b.replace(/(\r?\n|\r)$/g, "");
    }
    function A(b) {
      const I = this.resume(), z = this.stack[this.stack.length - 1];
      z.label = I, z.identifier = se(this.sliceSerialize(b)).toLowerCase();
    }
    function E() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.title = b;
    }
    function L() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.url = b;
    }
    function F(b) {
      const I = this.stack[this.stack.length - 1];
      if (!I.depth) {
        const z = this.sliceSerialize(b).length;
        I.depth = z;
      }
    }
    function w() {
      this.data.setextHeadingSlurpLineEnding = true;
    }
    function M(b) {
      const I = this.stack[this.stack.length - 1];
      I.depth = this.sliceSerialize(b).codePointAt(0) === 61 ? 1 : 2;
    }
    function $() {
      this.data.setextHeadingSlurpLineEnding = void 0;
    }
    function B(b) {
      const z = this.stack[this.stack.length - 1].children;
      let _ = z[z.length - 1];
      (!_ || _.type !== "text") && (_ = xi(), _.position = {
        start: ke(b.start),
        end: void 0
      }, z.push(_)), this.stack.push(_);
    }
    function k(b) {
      const I = this.stack.pop();
      I.value += this.sliceSerialize(b), I.position.end = ke(b.end);
    }
    function T(b) {
      const I = this.stack[this.stack.length - 1];
      if (this.data.atHardBreak) {
        const z = I.children[I.children.length - 1];
        z.position.end = ke(b.end), this.data.atHardBreak = void 0;
        return;
      }
      !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(I.type) && (B.call(this, b), k.call(this, b));
    }
    function P() {
      this.data.atHardBreak = true;
    }
    function j() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.value = b;
    }
    function q() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.value = b;
    }
    function N() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.value = b;
    }
    function Q() {
      const b = this.stack[this.stack.length - 1];
      if (this.data.inReference) {
        const I = this.data.referenceType || "shortcut";
        b.type += "Reference", b.referenceType = I, delete b.url, delete b.title;
      } else
        delete b.identifier, delete b.label;
      this.data.referenceType = void 0;
    }
    function Y() {
      const b = this.stack[this.stack.length - 1];
      if (this.data.inReference) {
        const I = this.data.referenceType || "shortcut";
        b.type += "Reference", b.referenceType = I, delete b.url, delete b.title;
      } else
        delete b.identifier, delete b.label;
      this.data.referenceType = void 0;
    }
    function le(b) {
      const I = this.sliceSerialize(b), z = this.stack[this.stack.length - 2];
      z.label = za(I), z.identifier = se(I).toLowerCase();
    }
    function he() {
      const b = this.stack[this.stack.length - 1], I = this.resume(), z = this.stack[this.stack.length - 1];
      if (this.data.inReference = true, z.type === "link") {
        const _ = b.children;
        z.children = _;
      } else
        z.alt = I;
    }
    function m() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.url = b;
    }
    function oe() {
      const b = this.resume(), I = this.stack[this.stack.length - 1];
      I.title = b;
    }
    function pe() {
      this.data.inReference = void 0;
    }
    function g() {
      this.data.referenceType = "collapsed";
    }
    function ae(b) {
      const I = this.resume(), z = this.stack[this.stack.length - 1];
      z.label = I, z.identifier = se(this.sliceSerialize(b)).toLowerCase(), this.data.referenceType = "full";
    }
    function be(b) {
      this.data.characterReferenceType = b.type;
    }
    function X(b) {
      const I = this.sliceSerialize(b), z = this.data.characterReferenceType;
      let _;
      z ? (_ = Sr(I, z === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : _ = Qn(I);
      const H = this.stack[this.stack.length - 1];
      H.value += _;
    }
    function Oe(b) {
      const I = this.stack.pop();
      I.position.end = ke(b.end);
    }
    function ye(b) {
      k.call(this, b);
      const I = this.stack[this.stack.length - 1];
      I.url = this.sliceSerialize(b);
    }
    function Ae(b) {
      k.call(this, b);
      const I = this.stack[this.stack.length - 1];
      I.url = "mailto:" + this.sliceSerialize(b);
    }
    function Te() {
      return {
        type: "blockquote",
        children: []
      };
    }
    function Qe() {
      return {
        type: "code",
        lang: null,
        meta: null,
        value: ""
      };
    }
    function hi() {
      return {
        type: "inlineCode",
        value: ""
      };
    }
    function pi() {
      return {
        type: "definition",
        identifier: "",
        label: null,
        title: null,
        url: ""
      };
    }
    function mi() {
      return {
        type: "emphasis",
        children: []
      };
    }
    function ot() {
      return {
        type: "heading",
        depth: 0,
        children: []
      };
    }
    function at() {
      return {
        type: "break"
      };
    }
    function ut() {
      return {
        type: "html",
        value: ""
      };
    }
    function gi() {
      return {
        type: "image",
        title: null,
        url: "",
        alt: null
      };
    }
    function st() {
      return {
        type: "link",
        title: null,
        url: "",
        children: []
      };
    }
    function ct(b) {
      return {
        type: "list",
        ordered: b.type === "listOrdered",
        start: null,
        spread: b._spread,
        children: []
      };
    }
    function di(b) {
      return {
        type: "listItem",
        spread: b._spread,
        checked: null,
        children: []
      };
    }
    function yi() {
      return {
        type: "paragraph",
        children: []
      };
    }
    function ki() {
      return {
        type: "strong",
        children: []
      };
    }
    function xi() {
      return {
        type: "text",
        value: ""
      };
    }
    function bi() {
      return {
        type: "thematicBreak"
      };
    }
  }
  function ke(e) {
    return {
      line: e.line,
      column: e.column,
      offset: e.offset
    };
  }
  function Fr(e, t) {
    let n = -1;
    for (; ++n < t.length; ) {
      const r = t[n];
      Array.isArray(r) ? Fr(e, r) : Ra(e, r);
    }
  }
  function Ra(e, t) {
    let n;
    for (n in t)
      if (Lr.call(t, n))
        switch (n) {
          case "canContainEols": {
            const r = t[n];
            r && e[n].push(...r);
            break;
          }
          case "transforms": {
            const r = t[n];
            r && e[n].push(...r);
            break;
          }
          case "enter":
          case "exit": {
            const r = t[n];
            r && Object.assign(e[n], r);
            break;
          }
        }
  }
  function Lt(e, t) {
    throw e ? new Error("Cannot close `" + e.type + "` (" + He({
      start: e.start,
      end: e.end
    }) + "): a different token (`" + t.type + "`, " + He({
      start: t.start,
      end: t.end
    }) + ") is open") : new Error("Cannot close document, a token (`" + t.type + "`, " + He({
      start: t.start,
      end: t.end
    }) + ") is still open");
  }
  function _a(e) {
    const t = this;
    t.parser = n;
    function n(r) {
      return La(r, {
        ...t.data("settings"),
        ...e,
        extensions: t.data("micromarkExtensions") || [],
        mdastExtensions: t.data("fromMarkdownExtensions") || []
      });
    }
  }
  function Oa(e, t) {
    const n = {
      type: "element",
      tagName: "blockquote",
      properties: {},
      children: e.wrap(e.all(t), true)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function Ma(e, t) {
    const n = {
      type: "element",
      tagName: "br",
      properties: {},
      children: []
    };
    return e.patch(t, n), [
      e.applyData(t, n),
      {
        type: "text",
        value: `
`
      }
    ];
  }
  function Na(e, t) {
    const n = t.value ? t.value + `
` : "", r = {}, i = t.lang ? t.lang.split(/\s+/) : [];
    i.length > 0 && (r.className = [
      "language-" + i[0]
    ]);
    let o = {
      type: "element",
      tagName: "code",
      properties: r,
      children: [
        {
          type: "text",
          value: n
        }
      ]
    };
    return t.meta && (o.data = {
      meta: t.meta
    }), e.patch(t, o), o = e.applyData(t, o), o = {
      type: "element",
      tagName: "pre",
      properties: {},
      children: [
        o
      ]
    }, e.patch(t, o), o;
  }
  function Ba(e, t) {
    const n = {
      type: "element",
      tagName: "del",
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function ja(e, t) {
    const n = {
      type: "element",
      tagName: "em",
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function Ha(e, t) {
    const n = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", r = String(t.identifier).toUpperCase(), i = _e(r.toLowerCase()), o = e.footnoteOrder.indexOf(r);
    let l, a = e.footnoteCounts.get(r);
    a === void 0 ? (a = 0, e.footnoteOrder.push(r), l = e.footnoteOrder.length) : l = o + 1, a += 1, e.footnoteCounts.set(r, a);
    const u = {
      type: "element",
      tagName: "a",
      properties: {
        href: "#" + n + "fn-" + i,
        id: n + "fnref-" + i + (a > 1 ? "-" + a : ""),
        dataFootnoteRef: true,
        ariaDescribedBy: [
          "footnote-label"
        ]
      },
      children: [
        {
          type: "text",
          value: String(l)
        }
      ]
    };
    e.patch(t, u);
    const s = {
      type: "element",
      tagName: "sup",
      properties: {},
      children: [
        u
      ]
    };
    return e.patch(t, s), e.applyData(t, s);
  }
  function Ua(e, t) {
    const n = {
      type: "element",
      tagName: "h" + t.depth,
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function Va(e, t) {
    if (e.options.allowDangerousHtml) {
      const n = {
        type: "raw",
        value: t.value
      };
      return e.patch(t, n), e.applyData(t, n);
    }
  }
  function Rr(e, t) {
    const n = t.referenceType;
    let r = "]";
    if (n === "collapsed" ? r += "[]" : n === "full" && (r += "[" + (t.label || t.identifier) + "]"), t.type === "imageReference")
      return [
        {
          type: "text",
          value: "![" + t.alt + r
        }
      ];
    const i = e.all(t), o = i[0];
    o && o.type === "text" ? o.value = "[" + o.value : i.unshift({
      type: "text",
      value: "["
    });
    const l = i[i.length - 1];
    return l && l.type === "text" ? l.value += r : i.push({
      type: "text",
      value: r
    }), i;
  }
  function $a(e, t) {
    const n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
    if (!r)
      return Rr(e, t);
    const i = {
      src: _e(r.url || ""),
      alt: t.alt
    };
    r.title !== null && r.title !== void 0 && (i.title = r.title);
    const o = {
      type: "element",
      tagName: "img",
      properties: i,
      children: []
    };
    return e.patch(t, o), e.applyData(t, o);
  }
  function qa(e, t) {
    const n = {
      src: _e(t.url)
    };
    t.alt !== null && t.alt !== void 0 && (n.alt = t.alt), t.title !== null && t.title !== void 0 && (n.title = t.title);
    const r = {
      type: "element",
      tagName: "img",
      properties: n,
      children: []
    };
    return e.patch(t, r), e.applyData(t, r);
  }
  function Wa(e, t) {
    const n = {
      type: "text",
      value: t.value.replace(/\r?\n|\r/g, " ")
    };
    e.patch(t, n);
    const r = {
      type: "element",
      tagName: "code",
      properties: {},
      children: [
        n
      ]
    };
    return e.patch(t, r), e.applyData(t, r);
  }
  function Ya(e, t) {
    const n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
    if (!r)
      return Rr(e, t);
    const i = {
      href: _e(r.url || "")
    };
    r.title !== null && r.title !== void 0 && (i.title = r.title);
    const o = {
      type: "element",
      tagName: "a",
      properties: i,
      children: e.all(t)
    };
    return e.patch(t, o), e.applyData(t, o);
  }
  function Xa(e, t) {
    const n = {
      href: _e(t.url)
    };
    t.title !== null && t.title !== void 0 && (n.title = t.title);
    const r = {
      type: "element",
      tagName: "a",
      properties: n,
      children: e.all(t)
    };
    return e.patch(t, r), e.applyData(t, r);
  }
  function Qa(e, t, n) {
    const r = e.all(t), i = n ? Ga(n) : _r(t), o = {}, l = [];
    if (typeof t.checked == "boolean") {
      const f = r[0];
      let c;
      f && f.type === "element" && f.tagName === "p" ? c = f : (c = {
        type: "element",
        tagName: "p",
        properties: {},
        children: []
      }, r.unshift(c)), c.children.length > 0 && c.children.unshift({
        type: "text",
        value: " "
      }), c.children.unshift({
        type: "element",
        tagName: "input",
        properties: {
          type: "checkbox",
          checked: t.checked,
          disabled: true
        },
        children: []
      }), o.className = [
        "task-list-item"
      ];
    }
    let a = -1;
    for (; ++a < r.length; ) {
      const f = r[a];
      (i || a !== 0 || f.type !== "element" || f.tagName !== "p") && l.push({
        type: "text",
        value: `
`
      }), f.type === "element" && f.tagName === "p" && !i ? l.push(...f.children) : l.push(f);
    }
    const u = r[r.length - 1];
    u && (i || u.type !== "element" || u.tagName !== "p") && l.push({
      type: "text",
      value: `
`
    });
    const s = {
      type: "element",
      tagName: "li",
      properties: o,
      children: l
    };
    return e.patch(t, s), e.applyData(t, s);
  }
  function Ga(e) {
    let t = false;
    if (e.type === "list") {
      t = e.spread || false;
      const n = e.children;
      let r = -1;
      for (; !t && ++r < n.length; )
        t = _r(n[r]);
    }
    return t;
  }
  function _r(e) {
    const t = e.spread;
    return t ?? e.children.length > 1;
  }
  function Ka(e, t) {
    const n = {}, r = e.all(t);
    let i = -1;
    for (typeof t.start == "number" && t.start !== 1 && (n.start = t.start); ++i < r.length; ) {
      const l = r[i];
      if (l.type === "element" && l.tagName === "li" && l.properties && Array.isArray(l.properties.className) && l.properties.className.includes("task-list-item")) {
        n.className = [
          "contains-task-list"
        ];
        break;
      }
    }
    const o = {
      type: "element",
      tagName: t.ordered ? "ol" : "ul",
      properties: n,
      children: e.wrap(r, true)
    };
    return e.patch(t, o), e.applyData(t, o);
  }
  function Ja(e, t) {
    const n = {
      type: "element",
      tagName: "p",
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function Za(e, t) {
    const n = {
      type: "root",
      children: e.wrap(e.all(t))
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function eu(e, t) {
    const n = {
      type: "element",
      tagName: "strong",
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function nu(e, t) {
    const n = e.all(t), r = n.shift(), i = [];
    if (r) {
      const l = {
        type: "element",
        tagName: "thead",
        properties: {},
        children: e.wrap([
          r
        ], true)
      };
      e.patch(t.children[0], l), i.push(l);
    }
    if (n.length > 0) {
      const l = {
        type: "element",
        tagName: "tbody",
        properties: {},
        children: e.wrap(n, true)
      }, a = $n(t.children[1]), u = mr(t.children[t.children.length - 1]);
      a && u && (l.position = {
        start: a,
        end: u
      }), i.push(l);
    }
    const o = {
      type: "element",
      tagName: "table",
      properties: {},
      children: e.wrap(i, true)
    };
    return e.patch(t, o), e.applyData(t, o);
  }
  function tu(e, t, n) {
    const r = n ? n.children : void 0, o = (r ? r.indexOf(t) : 1) === 0 ? "th" : "td", l = n && n.type === "table" ? n.align : void 0, a = l ? l.length : t.children.length;
    let u = -1;
    const s = [];
    for (; ++u < a; ) {
      const c = t.children[u], p = {}, h = l ? l[u] : void 0;
      h && (p.align = h);
      let d = {
        type: "element",
        tagName: o,
        properties: p,
        children: []
      };
      c && (d.children = e.all(c), e.patch(c, d), d = e.applyData(c, d)), s.push(d);
    }
    const f = {
      type: "element",
      tagName: "tr",
      properties: {},
      children: e.wrap(s, true)
    };
    return e.patch(t, f), e.applyData(t, f);
  }
  function ru(e, t) {
    const n = {
      type: "element",
      tagName: "td",
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  const Ft = 9, Rt = 32;
  function iu(e) {
    const t = String(e), n = /\r?\n|\r/g;
    let r = n.exec(t), i = 0;
    const o = [];
    for (; r; )
      o.push(_t(t.slice(i, r.index), i > 0, true), r[0]), i = r.index + r[0].length, r = n.exec(t);
    return o.push(_t(t.slice(i), i > 0, false)), o.join("");
  }
  function _t(e, t, n) {
    let r = 0, i = e.length;
    if (t) {
      let o = e.codePointAt(r);
      for (; o === Ft || o === Rt; )
        r++, o = e.codePointAt(r);
    }
    if (n) {
      let o = e.codePointAt(i - 1);
      for (; o === Ft || o === Rt; )
        i--, o = e.codePointAt(i - 1);
    }
    return i > r ? e.slice(r, i) : "";
  }
  function lu(e, t) {
    const n = {
      type: "text",
      value: iu(String(t.value))
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  function ou(e, t) {
    const n = {
      type: "element",
      tagName: "hr",
      properties: {},
      children: []
    };
    return e.patch(t, n), e.applyData(t, n);
  }
  const au = {
    blockquote: Oa,
    break: Ma,
    code: Na,
    delete: Ba,
    emphasis: ja,
    footnoteReference: Ha,
    heading: Ua,
    html: Va,
    imageReference: $a,
    image: qa,
    inlineCode: Wa,
    linkReference: Ya,
    link: Xa,
    listItem: Qa,
    list: Ka,
    paragraph: Ja,
    root: Za,
    strong: eu,
    table: nu,
    tableCell: ru,
    tableRow: tu,
    text: lu,
    thematicBreak: ou,
    toml: Ge,
    yaml: Ge,
    definition: Ge,
    footnoteDefinition: Ge
  };
  function Ge() {
  }
  const Or = -1, fn = 0, Ve = 1, ln = 2, Kn = 3, Jn = 4, Zn = 5, et = 6, Mr = 7, Nr = 8, Ot = typeof self == "object" ? self : globalThis, uu = (e, t) => {
    const n = (i, o) => (e.set(o, i), i), r = (i) => {
      if (e.has(i))
        return e.get(i);
      const [o, l] = t[i];
      switch (o) {
        case fn:
        case Or:
          return n(l, i);
        case Ve: {
          const a = n([], i);
          for (const u of l)
            a.push(r(u));
          return a;
        }
        case ln: {
          const a = n({}, i);
          for (const [u, s] of l)
            a[r(u)] = r(s);
          return a;
        }
        case Kn:
          return n(new Date(l), i);
        case Jn: {
          const { source: a, flags: u } = l;
          return n(new RegExp(a, u), i);
        }
        case Zn: {
          const a = n(/* @__PURE__ */ new Map(), i);
          for (const [u, s] of l)
            a.set(r(u), r(s));
          return a;
        }
        case et: {
          const a = n(/* @__PURE__ */ new Set(), i);
          for (const u of l)
            a.add(r(u));
          return a;
        }
        case Mr: {
          const { name: a, message: u } = l;
          return n(new Ot[a](u), i);
        }
        case Nr:
          return n(BigInt(l), i);
        case "BigInt":
          return n(Object(BigInt(l)), i);
        case "ArrayBuffer":
          return n(new Uint8Array(l).buffer, l);
        case "DataView": {
          const { buffer: a } = new Uint8Array(l);
          return n(new DataView(a), l);
        }
      }
      return n(new Ot[o](l), i);
    };
    return r;
  }, Mt = (e) => uu(/* @__PURE__ */ new Map(), e)(0), ve = "", { toString: su } = {}, { keys: cu } = Object, je = (e) => {
    const t = typeof e;
    if (t !== "object" || !e)
      return [
        fn,
        t
      ];
    const n = su.call(e).slice(8, -1);
    switch (n) {
      case "Array":
        return [
          Ve,
          ve
        ];
      case "Object":
        return [
          ln,
          ve
        ];
      case "Date":
        return [
          Kn,
          ve
        ];
      case "RegExp":
        return [
          Jn,
          ve
        ];
      case "Map":
        return [
          Zn,
          ve
        ];
      case "Set":
        return [
          et,
          ve
        ];
      case "DataView":
        return [
          Ve,
          n
        ];
    }
    return n.includes("Array") ? [
      Ve,
      n
    ] : n.includes("Error") ? [
      Mr,
      n
    ] : [
      ln,
      n
    ];
  }, Ke = ([e, t]) => e === fn && (t === "function" || t === "symbol"), fu = (e, t, n, r) => {
    const i = (l, a) => {
      const u = r.push(l) - 1;
      return n.set(a, u), u;
    }, o = (l) => {
      if (n.has(l))
        return n.get(l);
      let [a, u] = je(l);
      switch (a) {
        case fn: {
          let f = l;
          switch (u) {
            case "bigint":
              a = Nr, f = l.toString();
              break;
            case "function":
            case "symbol":
              if (e)
                throw new TypeError("unable to serialize " + u);
              f = null;
              break;
            case "undefined":
              return i([
                Or
              ], l);
          }
          return i([
            a,
            f
          ], l);
        }
        case Ve: {
          if (u) {
            let p = l;
            return u === "DataView" ? p = new Uint8Array(l.buffer) : u === "ArrayBuffer" && (p = new Uint8Array(l)), i([
              u,
              [
                ...p
              ]
            ], l);
          }
          const f = [], c = i([
            a,
            f
          ], l);
          for (const p of l)
            f.push(o(p));
          return c;
        }
        case ln: {
          if (u)
            switch (u) {
              case "BigInt":
                return i([
                  u,
                  l.toString()
                ], l);
              case "Boolean":
              case "Number":
              case "String":
                return i([
                  u,
                  l.valueOf()
                ], l);
            }
          if (t && "toJSON" in l)
            return o(l.toJSON());
          const f = [], c = i([
            a,
            f
          ], l);
          for (const p of cu(l))
            (e || !Ke(je(l[p]))) && f.push([
              o(p),
              o(l[p])
            ]);
          return c;
        }
        case Kn:
          return i([
            a,
            l.toISOString()
          ], l);
        case Jn: {
          const { source: f, flags: c } = l;
          return i([
            a,
            {
              source: f,
              flags: c
            }
          ], l);
        }
        case Zn: {
          const f = [], c = i([
            a,
            f
          ], l);
          for (const [p, h] of l)
            (e || !(Ke(je(p)) || Ke(je(h)))) && f.push([
              o(p),
              o(h)
            ]);
          return c;
        }
        case et: {
          const f = [], c = i([
            a,
            f
          ], l);
          for (const p of l)
            (e || !Ke(je(p))) && f.push(o(p));
          return c;
        }
      }
      const { message: s } = l;
      return i([
        a,
        {
          name: u,
          message: s
        }
      ], l);
    };
    return o;
  }, Nt = (e, { json: t, lossy: n } = {}) => {
    const r = [];
    return fu(!(t || n), !!t, /* @__PURE__ */ new Map(), r)(e), r;
  }, on = typeof structuredClone == "function" ? (e, t) => t && ("json" in t || "lossy" in t) ? Mt(Nt(e, t)) : structuredClone(e) : (e, t) => Mt(Nt(e, t));
  function hu(e, t) {
    const n = [
      {
        type: "text",
        value: "\u21A9"
      }
    ];
    return t > 1 && n.push({
      type: "element",
      tagName: "sup",
      properties: {},
      children: [
        {
          type: "text",
          value: String(t)
        }
      ]
    }), n;
  }
  function pu(e, t) {
    return "Back to reference " + (e + 1) + (t > 1 ? "-" + t : "");
  }
  function mu(e) {
    const t = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", n = e.options.footnoteBackContent || hu, r = e.options.footnoteBackLabel || pu, i = e.options.footnoteLabel || "Footnotes", o = e.options.footnoteLabelTagName || "h2", l = e.options.footnoteLabelProperties || {
      className: [
        "sr-only"
      ]
    }, a = [];
    let u = -1;
    for (; ++u < e.footnoteOrder.length; ) {
      const s = e.footnoteById.get(e.footnoteOrder[u]);
      if (!s)
        continue;
      const f = e.all(s), c = String(s.identifier).toUpperCase(), p = _e(c.toLowerCase());
      let h = 0;
      const d = [], x = e.footnoteCounts.get(c);
      for (; x !== void 0 && ++h <= x; ) {
        d.length > 0 && d.push({
          type: "text",
          value: " "
        });
        let A = typeof n == "string" ? n : n(u, h);
        typeof A == "string" && (A = {
          type: "text",
          value: A
        }), d.push({
          type: "element",
          tagName: "a",
          properties: {
            href: "#" + t + "fnref-" + p + (h > 1 ? "-" + h : ""),
            dataFootnoteBackref: "",
            ariaLabel: typeof r == "string" ? r : r(u, h),
            className: [
              "data-footnote-backref"
            ]
          },
          children: Array.isArray(A) ? A : [
            A
          ]
        });
      }
      const C = f[f.length - 1];
      if (C && C.type === "element" && C.tagName === "p") {
        const A = C.children[C.children.length - 1];
        A && A.type === "text" ? A.value += " " : C.children.push({
          type: "text",
          value: " "
        }), C.children.push(...d);
      } else
        f.push(...d);
      const y = {
        type: "element",
        tagName: "li",
        properties: {
          id: t + "fn-" + p
        },
        children: e.wrap(f, true)
      };
      e.patch(s, y), a.push(y);
    }
    if (a.length !== 0)
      return {
        type: "element",
        tagName: "section",
        properties: {
          dataFootnotes: true,
          className: [
            "footnotes"
          ]
        },
        children: [
          {
            type: "element",
            tagName: o,
            properties: {
              ...on(l),
              id: "footnote-label"
            },
            children: [
              {
                type: "text",
                value: i
              }
            ]
          },
          {
            type: "text",
            value: `
`
          },
          {
            type: "element",
            tagName: "ol",
            properties: {},
            children: e.wrap(a, true)
          },
          {
            type: "text",
            value: `
`
          }
        ]
      };
  }
  const hn = function(e) {
    if (e == null)
      return ku;
    if (typeof e == "function")
      return pn(e);
    if (typeof e == "object")
      return Array.isArray(e) ? gu(e) : du(e);
    if (typeof e == "string")
      return yu(e);
    throw new Error("Expected function, string, or object as test");
  };
  function gu(e) {
    const t = [];
    let n = -1;
    for (; ++n < e.length; )
      t[n] = hn(e[n]);
    return pn(r);
    function r(...i) {
      let o = -1;
      for (; ++o < t.length; )
        if (t[o].apply(this, i))
          return true;
      return false;
    }
  }
  function du(e) {
    const t = e;
    return pn(n);
    function n(r) {
      const i = r;
      let o;
      for (o in e)
        if (i[o] !== t[o])
          return false;
      return true;
    }
  }
  function yu(e) {
    return pn(t);
    function t(n) {
      return n && n.type === e;
    }
  }
  function pn(e) {
    return t;
    function t(n, r, i) {
      return !!(xu(n) && e.call(this, n, typeof r == "number" ? r : void 0, i || void 0));
    }
  }
  function ku() {
    return true;
  }
  function xu(e) {
    return e !== null && typeof e == "object" && "type" in e;
  }
  const Br = [], bu = true, On = false, wu = "skip";
  function jr(e, t, n, r) {
    let i;
    typeof t == "function" && typeof n != "function" ? (r = n, n = t) : i = t;
    const o = hn(i), l = r ? -1 : 1;
    a(e, void 0, [])();
    function a(u, s, f) {
      const c = u && typeof u == "object" ? u : {};
      if (typeof c.type == "string") {
        const h = typeof c.tagName == "string" ? c.tagName : typeof c.name == "string" ? c.name : void 0;
        Object.defineProperty(p, "name", {
          value: "node (" + (u.type + (h ? "<" + h + ">" : "")) + ")"
        });
      }
      return p;
      function p() {
        let h = Br, d, x, C;
        if ((!t || o(u, s, f[f.length - 1] || void 0)) && (h = Su(n(u, f)), h[0] === On))
          return h;
        if ("children" in u && u.children) {
          const y = u;
          if (y.children && h[0] !== wu)
            for (x = (r ? y.children.length : -1) + l, C = f.concat(y); x > -1 && x < y.children.length; ) {
              const A = y.children[x];
              if (d = a(A, x, C)(), d[0] === On)
                return d;
              x = typeof d[1] == "number" ? d[1] : x + l;
            }
        }
        return h;
      }
    }
  }
  function Su(e) {
    return Array.isArray(e) ? e : typeof e == "number" ? [
      bu,
      e
    ] : e == null ? Br : [
      e
    ];
  }
  function nt(e, t, n, r) {
    let i, o, l;
    typeof t == "function" && typeof n != "function" ? (o = void 0, l = t, i = n) : (o = t, l = n, i = r), jr(e, o, a, i);
    function a(u, s) {
      const f = s[s.length - 1], c = f ? f.children.indexOf(u) : void 0;
      return l(u, c, f);
    }
  }
  const Mn = {}.hasOwnProperty, Cu = {};
  function Eu(e, t) {
    const n = t || Cu, r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), l = {
      ...au,
      ...n.handlers
    }, a = {
      all: s,
      applyData: Au,
      definitionById: r,
      footnoteById: i,
      footnoteCounts: o,
      footnoteOrder: [],
      handlers: l,
      one: u,
      options: n,
      patch: Iu,
      wrap: Pu
    };
    return nt(e, function(f) {
      if (f.type === "definition" || f.type === "footnoteDefinition") {
        const c = f.type === "definition" ? r : i, p = String(f.identifier).toUpperCase();
        c.has(p) || c.set(p, f);
      }
    }), a;
    function u(f, c) {
      const p = f.type, h = a.handlers[p];
      if (Mn.call(a.handlers, p) && h)
        return h(a, f, c);
      if (a.options.passThrough && a.options.passThrough.includes(p)) {
        if ("children" in f) {
          const { children: x, ...C } = f, y = on(C);
          return y.children = a.all(f), y;
        }
        return on(f);
      }
      return (a.options.unknownHandler || Tu)(a, f, c);
    }
    function s(f) {
      const c = [];
      if ("children" in f) {
        const p = f.children;
        let h = -1;
        for (; ++h < p.length; ) {
          const d = a.one(p[h], f);
          if (d) {
            if (h && p[h - 1].type === "break" && (!Array.isArray(d) && d.type === "text" && (d.value = Bt(d.value)), !Array.isArray(d) && d.type === "element")) {
              const x = d.children[0];
              x && x.type === "text" && (x.value = Bt(x.value));
            }
            Array.isArray(d) ? c.push(...d) : c.push(d);
          }
        }
      }
      return c;
    }
  }
  function Iu(e, t) {
    e.position && (t.position = hl(e));
  }
  function Au(e, t) {
    let n = t;
    if (e && e.data) {
      const r = e.data.hName, i = e.data.hChildren, o = e.data.hProperties;
      if (typeof r == "string")
        if (n.type === "element")
          n.tagName = r;
        else {
          const l = "children" in n ? n.children : [
            n
          ];
          n = {
            type: "element",
            tagName: r,
            properties: {},
            children: l
          };
        }
      n.type === "element" && o && Object.assign(n.properties, on(o)), "children" in n && n.children && i !== null && i !== void 0 && (n.children = i);
    }
    return n;
  }
  function Tu(e, t) {
    const n = t.data || {}, r = "value" in t && !(Mn.call(n, "hProperties") || Mn.call(n, "hChildren")) ? {
      type: "text",
      value: t.value
    } : {
      type: "element",
      tagName: "div",
      properties: {},
      children: e.all(t)
    };
    return e.patch(t, r), e.applyData(t, r);
  }
  function Pu(e, t) {
    const n = [];
    let r = -1;
    for (t && n.push({
      type: "text",
      value: `
`
    }); ++r < e.length; )
      r && n.push({
        type: "text",
        value: `
`
      }), n.push(e[r]);
    return t && e.length > 0 && n.push({
      type: "text",
      value: `
`
    }), n;
  }
  function Bt(e) {
    let t = 0, n = e.charCodeAt(t);
    for (; n === 9 || n === 32; )
      t++, n = e.charCodeAt(t);
    return e.slice(t);
  }
  function jt(e, t) {
    const n = Eu(e, t), r = n.one(e, void 0), i = mu(n), o = Array.isArray(r) ? {
      type: "root",
      children: r
    } : r || {
      type: "root",
      children: []
    };
    return i && o.children.push({
      type: "text",
      value: `
`
    }, i), o;
  }
  function vu(e, t) {
    return e && "run" in e ? async function(n, r) {
      const i = jt(n, {
        file: r,
        ...t
      });
      await e.run(i, r);
    } : function(n, r) {
      return jt(n, {
        file: r,
        ...e || t
      });
    };
  }
  function Ht(e) {
    if (e)
      throw e;
  }
  var nn = Object.prototype.hasOwnProperty, Hr = Object.prototype.toString, Ut = Object.defineProperty, Vt = Object.getOwnPropertyDescriptor, $t = function(t) {
    return typeof Array.isArray == "function" ? Array.isArray(t) : Hr.call(t) === "[object Array]";
  }, qt = function(t) {
    if (!t || Hr.call(t) !== "[object Object]")
      return false;
    var n = nn.call(t, "constructor"), r = t.constructor && t.constructor.prototype && nn.call(t.constructor.prototype, "isPrototypeOf");
    if (t.constructor && !n && !r)
      return false;
    var i;
    for (i in t)
      ;
    return typeof i > "u" || nn.call(t, i);
  }, Wt = function(t, n) {
    Ut && n.name === "__proto__" ? Ut(t, n.name, {
      enumerable: true,
      configurable: true,
      value: n.newValue,
      writable: true
    }) : t[n.name] = n.newValue;
  }, Yt = function(t, n) {
    if (n === "__proto__")
      if (nn.call(t, n)) {
        if (Vt)
          return Vt(t, n).value;
      } else
        return;
    return t[n];
  }, zu = function e() {
    var t, n, r, i, o, l, a = arguments[0], u = 1, s = arguments.length, f = false;
    for (typeof a == "boolean" && (f = a, a = arguments[1] || {}, u = 2), (a == null || typeof a != "object" && typeof a != "function") && (a = {}); u < s; ++u)
      if (t = arguments[u], t != null)
        for (n in t)
          r = Yt(a, n), i = Yt(t, n), a !== i && (f && i && (qt(i) || (o = $t(i))) ? (o ? (o = false, l = r && $t(r) ? r : []) : l = r && qt(r) ? r : {}, Wt(a, {
            name: n,
            newValue: e(f, l, i)
          })) : typeof i < "u" && Wt(a, {
            name: n,
            newValue: i
          }));
    return a;
  };
  const kn = or(zu);
  function Nn(e) {
    if (typeof e != "object" || e === null)
      return false;
    const t = Object.getPrototypeOf(e);
    return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
  }
  function Du() {
    const e = [], t = {
      run: n,
      use: r
    };
    return t;
    function n(...i) {
      let o = -1;
      const l = i.pop();
      if (typeof l != "function")
        throw new TypeError("Expected function as last argument, not " + l);
      a(null, ...i);
      function a(u, ...s) {
        const f = e[++o];
        let c = -1;
        if (u) {
          l(u);
          return;
        }
        for (; ++c < i.length; )
          (s[c] === null || s[c] === void 0) && (s[c] = i[c]);
        i = s, f ? Lu(f, a)(...s) : l(null, ...s);
      }
    }
    function r(i) {
      if (typeof i != "function")
        throw new TypeError("Expected `middelware` to be a function, not " + i);
      return e.push(i), t;
    }
  }
  function Lu(e, t) {
    let n;
    return r;
    function r(...l) {
      const a = e.length > l.length;
      let u;
      a && l.push(i);
      try {
        u = e.apply(this, l);
      } catch (s) {
        const f = s;
        if (a && n)
          throw f;
        return i(f);
      }
      a || (u && u.then && typeof u.then == "function" ? u.then(o, i) : u instanceof Error ? i(u) : o(u));
    }
    function i(l, ...a) {
      n || (n = true, t(l, ...a));
    }
    function o(l) {
      i(null, l);
    }
  }
  const ce = {
    basename: Fu,
    dirname: Ru,
    extname: _u,
    join: Ou,
    sep: "/"
  };
  function Fu(e, t) {
    if (t !== void 0 && typeof t != "string")
      throw new TypeError('"ext" argument must be a string');
    Xe(e);
    let n = 0, r = -1, i = e.length, o;
    if (t === void 0 || t.length === 0 || t.length > e.length) {
      for (; i--; )
        if (e.codePointAt(i) === 47) {
          if (o) {
            n = i + 1;
            break;
          }
        } else
          r < 0 && (o = true, r = i + 1);
      return r < 0 ? "" : e.slice(n, r);
    }
    if (t === e)
      return "";
    let l = -1, a = t.length - 1;
    for (; i--; )
      if (e.codePointAt(i) === 47) {
        if (o) {
          n = i + 1;
          break;
        }
      } else
        l < 0 && (o = true, l = i + 1), a > -1 && (e.codePointAt(i) === t.codePointAt(a--) ? a < 0 && (r = i) : (a = -1, r = l));
    return n === r ? r = l : r < 0 && (r = e.length), e.slice(n, r);
  }
  function Ru(e) {
    if (Xe(e), e.length === 0)
      return ".";
    let t = -1, n = e.length, r;
    for (; --n; )
      if (e.codePointAt(n) === 47) {
        if (r) {
          t = n;
          break;
        }
      } else
        r || (r = true);
    return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
  }
  function _u(e) {
    Xe(e);
    let t = e.length, n = -1, r = 0, i = -1, o = 0, l;
    for (; t--; ) {
      const a = e.codePointAt(t);
      if (a === 47) {
        if (l) {
          r = t + 1;
          break;
        }
        continue;
      }
      n < 0 && (l = true, n = t + 1), a === 46 ? i < 0 ? i = t : o !== 1 && (o = 1) : i > -1 && (o = -1);
    }
    return i < 0 || n < 0 || o === 0 || o === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
  }
  function Ou(...e) {
    let t = -1, n;
    for (; ++t < e.length; )
      Xe(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
    return n === void 0 ? "." : Mu(n);
  }
  function Mu(e) {
    Xe(e);
    const t = e.codePointAt(0) === 47;
    let n = Nu(e, !t);
    return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
  }
  function Nu(e, t) {
    let n = "", r = 0, i = -1, o = 0, l = -1, a, u;
    for (; ++l <= e.length; ) {
      if (l < e.length)
        a = e.codePointAt(l);
      else {
        if (a === 47)
          break;
        a = 47;
      }
      if (a === 47) {
        if (!(i === l - 1 || o === 1))
          if (i !== l - 1 && o === 2) {
            if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
              if (n.length > 2) {
                if (u = n.lastIndexOf("/"), u !== n.length - 1) {
                  u < 0 ? (n = "", r = 0) : (n = n.slice(0, u), r = n.length - 1 - n.lastIndexOf("/")), i = l, o = 0;
                  continue;
                }
              } else if (n.length > 0) {
                n = "", r = 0, i = l, o = 0;
                continue;
              }
            }
            t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
          } else
            n.length > 0 ? n += "/" + e.slice(i + 1, l) : n = e.slice(i + 1, l), r = l - i - 1;
        i = l, o = 0;
      } else
        a === 46 && o > -1 ? o++ : o = -1;
    }
    return n;
  }
  function Xe(e) {
    if (typeof e != "string")
      throw new TypeError("Path must be a string. Received " + JSON.stringify(e));
  }
  const Bu = {
    cwd: ju
  };
  function ju() {
    return "/";
  }
  function Bn(e) {
    return !!(e !== null && typeof e == "object" && "href" in e && e.href && "protocol" in e && e.protocol && e.auth === void 0);
  }
  function Hu(e) {
    if (typeof e == "string")
      e = new URL(e);
    else if (!Bn(e)) {
      const t = new TypeError('The "path" argument must be of type string or an instance of URL. Received `' + e + "`");
      throw t.code = "ERR_INVALID_ARG_TYPE", t;
    }
    if (e.protocol !== "file:") {
      const t = new TypeError("The URL must be of scheme file");
      throw t.code = "ERR_INVALID_URL_SCHEME", t;
    }
    return Uu(e);
  }
  function Uu(e) {
    if (e.hostname !== "") {
      const r = new TypeError('File URL host must be "localhost" or empty on darwin');
      throw r.code = "ERR_INVALID_FILE_URL_HOST", r;
    }
    const t = e.pathname;
    let n = -1;
    for (; ++n < t.length; )
      if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
        const r = t.codePointAt(n + 2);
        if (r === 70 || r === 102) {
          const i = new TypeError("File URL path must not include encoded / characters");
          throw i.code = "ERR_INVALID_FILE_URL_PATH", i;
        }
      }
    return decodeURIComponent(t);
  }
  const xn = [
    "history",
    "path",
    "basename",
    "stem",
    "extname",
    "dirname"
  ];
  class Ur {
    constructor(t) {
      let n;
      t ? Bn(t) ? n = {
        path: t
      } : typeof t == "string" || Vu(t) ? n = {
        value: t
      } : n = t : n = {}, this.cwd = "cwd" in n ? "" : Bu.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
      let r = -1;
      for (; ++r < xn.length; ) {
        const o = xn[r];
        o in n && n[o] !== void 0 && n[o] !== null && (this[o] = o === "history" ? [
          ...n[o]
        ] : n[o]);
      }
      let i;
      for (i in n)
        xn.includes(i) || (this[i] = n[i]);
    }
    get basename() {
      return typeof this.path == "string" ? ce.basename(this.path) : void 0;
    }
    set basename(t) {
      wn(t, "basename"), bn(t, "basename"), this.path = ce.join(this.dirname || "", t);
    }
    get dirname() {
      return typeof this.path == "string" ? ce.dirname(this.path) : void 0;
    }
    set dirname(t) {
      Xt(this.basename, "dirname"), this.path = ce.join(t || "", this.basename);
    }
    get extname() {
      return typeof this.path == "string" ? ce.extname(this.path) : void 0;
    }
    set extname(t) {
      if (bn(t, "extname"), Xt(this.dirname, "extname"), t) {
        if (t.codePointAt(0) !== 46)
          throw new Error("`extname` must start with `.`");
        if (t.includes(".", 1))
          throw new Error("`extname` cannot contain multiple dots");
      }
      this.path = ce.join(this.dirname, this.stem + (t || ""));
    }
    get path() {
      return this.history[this.history.length - 1];
    }
    set path(t) {
      Bn(t) && (t = Hu(t)), wn(t, "path"), this.path !== t && this.history.push(t);
    }
    get stem() {
      return typeof this.path == "string" ? ce.basename(this.path, this.extname) : void 0;
    }
    set stem(t) {
      wn(t, "stem"), bn(t, "stem"), this.path = ce.join(this.dirname || "", t + (this.extname || ""));
    }
    fail(t, n, r) {
      const i = this.message(t, n, r);
      throw i.fatal = true, i;
    }
    info(t, n, r) {
      const i = this.message(t, n, r);
      return i.fatal = void 0, i;
    }
    message(t, n, r) {
      const i = new K(t, n, r);
      return this.path && (i.name = this.path + ":" + i.name, i.file = this.path), i.fatal = false, this.messages.push(i), i;
    }
    toString(t) {
      return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(t || void 0).decode(this.value);
    }
  }
  function bn(e, t) {
    if (e && e.includes(ce.sep))
      throw new Error("`" + t + "` cannot be a path: did not expect `" + ce.sep + "`");
  }
  function wn(e, t) {
    if (!e)
      throw new Error("`" + t + "` cannot be empty");
  }
  function Xt(e, t) {
    if (!e)
      throw new Error("Setting `" + t + "` requires `path` to be set too");
  }
  function Vu(e) {
    return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
  }
  const $u = function(e) {
    const r = this.constructor.prototype, i = r[e], o = function() {
      return i.apply(o, arguments);
    };
    return Object.setPrototypeOf(o, r), o;
  }, qu = {}.hasOwnProperty;
  class tt extends $u {
    constructor() {
      super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = Du();
    }
    copy() {
      const t = new tt();
      let n = -1;
      for (; ++n < this.attachers.length; ) {
        const r = this.attachers[n];
        t.use(...r);
      }
      return t.data(kn(true, {}, this.namespace)), t;
    }
    data(t, n) {
      return typeof t == "string" ? arguments.length === 2 ? (En("data", this.frozen), this.namespace[t] = n, this) : qu.call(this.namespace, t) && this.namespace[t] || void 0 : t ? (En("data", this.frozen), this.namespace = t, this) : this.namespace;
    }
    freeze() {
      if (this.frozen)
        return this;
      const t = this;
      for (; ++this.freezeIndex < this.attachers.length; ) {
        const [n, ...r] = this.attachers[this.freezeIndex];
        if (r[0] === false)
          continue;
        r[0] === true && (r[0] = void 0);
        const i = n.call(t, ...r);
        typeof i == "function" && this.transformers.use(i);
      }
      return this.frozen = true, this.freezeIndex = Number.POSITIVE_INFINITY, this;
    }
    parse(t) {
      this.freeze();
      const n = Je(t), r = this.parser || this.Parser;
      return Sn("parse", r), r(String(n), n);
    }
    process(t, n) {
      const r = this;
      return this.freeze(), Sn("process", this.parser || this.Parser), Cn("process", this.compiler || this.Compiler), n ? i(void 0, n) : new Promise(i);
      function i(o, l) {
        const a = Je(t), u = r.parse(a);
        r.run(u, a, function(f, c, p) {
          if (f || !c || !p)
            return s(f);
          const h = c, d = r.stringify(h, p);
          Xu(d) ? p.value = d : p.result = d, s(f, p);
        });
        function s(f, c) {
          f || !c ? l(f) : o ? o(c) : n(void 0, c);
        }
      }
    }
    processSync(t) {
      let n = false, r;
      return this.freeze(), Sn("processSync", this.parser || this.Parser), Cn("processSync", this.compiler || this.Compiler), this.process(t, i), Gt("processSync", "process", n), r;
      function i(o, l) {
        n = true, Ht(o), r = l;
      }
    }
    run(t, n, r) {
      Qt(t), this.freeze();
      const i = this.transformers;
      return !r && typeof n == "function" && (r = n, n = void 0), r ? o(void 0, r) : new Promise(o);
      function o(l, a) {
        const u = Je(n);
        i.run(t, u, s);
        function s(f, c, p) {
          const h = c || t;
          f ? a(f) : l ? l(h) : r(void 0, h, p);
        }
      }
    }
    runSync(t, n) {
      let r = false, i;
      return this.run(t, n, o), Gt("runSync", "run", r), i;
      function o(l, a) {
        Ht(l), i = a, r = true;
      }
    }
    stringify(t, n) {
      this.freeze();
      const r = Je(n), i = this.compiler || this.Compiler;
      return Cn("stringify", i), Qt(t), i(t, r);
    }
    use(t, ...n) {
      const r = this.attachers, i = this.namespace;
      if (En("use", this.frozen), t != null)
        if (typeof t == "function")
          u(t, n);
        else if (typeof t == "object")
          Array.isArray(t) ? a(t) : l(t);
        else
          throw new TypeError("Expected usable value, not `" + t + "`");
      return this;
      function o(s) {
        if (typeof s == "function")
          u(s, []);
        else if (typeof s == "object")
          if (Array.isArray(s)) {
            const [f, ...c] = s;
            u(f, c);
          } else
            l(s);
        else
          throw new TypeError("Expected usable value, not `" + s + "`");
      }
      function l(s) {
        if (!("plugins" in s) && !("settings" in s))
          throw new Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
        a(s.plugins), s.settings && (i.settings = kn(true, i.settings, s.settings));
      }
      function a(s) {
        let f = -1;
        if (s != null)
          if (Array.isArray(s))
            for (; ++f < s.length; ) {
              const c = s[f];
              o(c);
            }
          else
            throw new TypeError("Expected a list of plugins, not `" + s + "`");
      }
      function u(s, f) {
        let c = -1, p = -1;
        for (; ++c < r.length; )
          if (r[c][0] === s) {
            p = c;
            break;
          }
        if (p === -1)
          r.push([
            s,
            ...f
          ]);
        else if (f.length > 0) {
          let [h, ...d] = f;
          const x = r[p][1];
          Nn(x) && Nn(h) && (h = kn(true, x, h)), r[p] = [
            s,
            h,
            ...d
          ];
        }
      }
    }
  }
  const Wu = new tt().freeze();
  function Sn(e, t) {
    if (typeof t != "function")
      throw new TypeError("Cannot `" + e + "` without `parser`");
  }
  function Cn(e, t) {
    if (typeof t != "function")
      throw new TypeError("Cannot `" + e + "` without `compiler`");
  }
  function En(e, t) {
    if (t)
      throw new Error("Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.");
  }
  function Qt(e) {
    if (!Nn(e) || typeof e.type != "string")
      throw new TypeError("Expected node, got `" + e + "`");
  }
  function Gt(e, t, n) {
    if (!n)
      throw new Error("`" + e + "` finished async. Use `" + t + "` instead");
  }
  function Je(e) {
    return Yu(e) ? e : new Ur(e);
  }
  function Yu(e) {
    return !!(e && typeof e == "object" && "message" in e && "messages" in e);
  }
  function Xu(e) {
    return typeof e == "string" || Qu(e);
  }
  function Qu(e) {
    return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
  }
  const Gu = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md", Kt = [], Jt = {
    allowDangerousHtml: true
  }, Ku = /^(https?|ircs?|mailto|xmpp)$/i, Ju = [
    {
      from: "astPlugins",
      id: "remove-buggy-html-in-markdown-parser"
    },
    {
      from: "allowDangerousHtml",
      id: "remove-buggy-html-in-markdown-parser"
    },
    {
      from: "allowNode",
      id: "replace-allownode-allowedtypes-and-disallowedtypes",
      to: "allowElement"
    },
    {
      from: "allowedTypes",
      id: "replace-allownode-allowedtypes-and-disallowedtypes",
      to: "allowedElements"
    },
    {
      from: "className",
      id: "remove-classname"
    },
    {
      from: "disallowedTypes",
      id: "replace-allownode-allowedtypes-and-disallowedtypes",
      to: "disallowedElements"
    },
    {
      from: "escapeHtml",
      id: "remove-buggy-html-in-markdown-parser"
    },
    {
      from: "includeElementIndex",
      id: "#remove-includeelementindex"
    },
    {
      from: "includeNodeIndex",
      id: "change-includenodeindex-to-includeelementindex"
    },
    {
      from: "linkTarget",
      id: "remove-linktarget"
    },
    {
      from: "plugins",
      id: "change-plugins-to-remarkplugins",
      to: "remarkPlugins"
    },
    {
      from: "rawSourcePos",
      id: "#remove-rawsourcepos"
    },
    {
      from: "renderers",
      id: "change-renderers-to-components",
      to: "components"
    },
    {
      from: "source",
      id: "change-source-to-children",
      to: "children"
    },
    {
      from: "sourcePos",
      id: "#remove-sourcepos"
    },
    {
      from: "transformImageUri",
      id: "#add-urltransform",
      to: "urlTransform"
    },
    {
      from: "transformLinkUri",
      id: "#add-urltransform",
      to: "urlTransform"
    }
  ];
  function Zu(e) {
    const t = es(e), n = ns(e);
    return ts(t.runSync(t.parse(n), n), e);
  }
  function es(e) {
    const t = e.rehypePlugins || Kt, n = e.remarkPlugins || Kt, r = e.remarkRehypeOptions ? {
      ...e.remarkRehypeOptions,
      ...Jt
    } : Jt;
    return Wu().use(_a).use(n).use(vu, r).use(t);
  }
  function ns(e) {
    const t = e.children || "", n = new Ur();
    return typeof t == "string" && (n.value = t), n;
  }
  function ts(e, t) {
    const n = t.allowedElements, r = t.allowElement, i = t.components, o = t.disallowedElements, l = t.skipHtml, a = t.unwrapDisallowed, u = t.urlTransform || rs;
    for (const f of Ju)
      Object.hasOwn(t, f.from) && ("" + f.from + (f.to ? "use `" + f.to + "` instead" : "remove it") + Gu + f.id, void 0);
    return nt(e, s), yl(e, {
      Fragment: De.Fragment,
      components: i,
      ignoreInvalidStyle: true,
      jsx: De.jsx,
      jsxs: De.jsxs,
      passKeys: true,
      passNode: true
    });
    function s(f, c, p) {
      if (f.type === "raw" && p && typeof c == "number")
        return l ? p.children.splice(c, 1) : p.children[c] = {
          type: "text",
          value: f.value
        }, c;
      if (f.type === "element") {
        let h;
        for (h in gn)
          if (Object.hasOwn(gn, h) && Object.hasOwn(f.properties, h)) {
            const d = f.properties[h], x = gn[h];
            (x === null || x.includes(f.tagName)) && (f.properties[h] = u(String(d || ""), h, f));
          }
      }
      if (f.type === "element") {
        let h = n ? !n.includes(f.tagName) : o ? o.includes(f.tagName) : false;
        if (!h && r && typeof c == "number" && (h = !r(f, c, p)), h && p && typeof c == "number")
          return a && f.children ? p.children.splice(c, 1, ...f.children) : p.children.splice(c, 1), c;
      }
    }
  }
  function rs(e) {
    const t = e.indexOf(":"), n = e.indexOf("?"), r = e.indexOf("#"), i = e.indexOf("/");
    return t === -1 || i !== -1 && t > i || n !== -1 && t > n || r !== -1 && t > r || Ku.test(e.slice(0, t)) ? e : "";
  }
  function Zt(e, t) {
    const n = String(e);
    if (typeof t != "string")
      throw new TypeError("Expected character");
    let r = 0, i = n.indexOf(t);
    for (; i !== -1; )
      r++, i = n.indexOf(t, i + t.length);
    return r;
  }
  function is(e) {
    if (typeof e != "string")
      throw new TypeError("Expected a string");
    return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
  }
  function ls(e, t, n) {
    const i = hn((n || {}).ignore || []), o = os(t);
    let l = -1;
    for (; ++l < o.length; )
      jr(e, "text", a);
    function a(s, f) {
      let c = -1, p;
      for (; ++c < f.length; ) {
        const h = f[c], d = p ? p.children : void 0;
        if (i(h, d ? d.indexOf(h) : void 0, p))
          return;
        p = h;
      }
      if (p)
        return u(s, f);
    }
    function u(s, f) {
      const c = f[f.length - 1], p = o[l][0], h = o[l][1];
      let d = 0;
      const C = c.children.indexOf(s);
      let y = false, A = [];
      p.lastIndex = 0;
      let E = p.exec(s.value);
      for (; E; ) {
        const L = E.index, F = {
          index: E.index,
          input: E.input,
          stack: [
            ...f,
            s
          ]
        };
        let w = h(...E, F);
        if (typeof w == "string" && (w = w.length > 0 ? {
          type: "text",
          value: w
        } : void 0), w === false ? p.lastIndex = L + 1 : (d !== L && A.push({
          type: "text",
          value: s.value.slice(d, L)
        }), Array.isArray(w) ? A.push(...w) : w && A.push(w), d = L + E[0].length, y = true), !p.global)
          break;
        E = p.exec(s.value);
      }
      return y ? (d < s.value.length && A.push({
        type: "text",
        value: s.value.slice(d)
      }), c.children.splice(C, 1, ...A)) : A = [
        s
      ], C + A.length;
    }
  }
  function os(e) {
    const t = [];
    if (!Array.isArray(e))
      throw new TypeError("Expected find and replace tuple or list of tuples");
    const n = !e[0] || Array.isArray(e[0]) ? e : [
      e
    ];
    let r = -1;
    for (; ++r < n.length; ) {
      const i = n[r];
      t.push([
        as(i[0]),
        us(i[1])
      ]);
    }
    return t;
  }
  function as(e) {
    return typeof e == "string" ? new RegExp(is(e), "g") : e;
  }
  function us(e) {
    return typeof e == "function" ? e : function() {
      return e;
    };
  }
  const In = "phrasing", An = [
    "autolink",
    "link",
    "image",
    "label"
  ];
  function ss() {
    return {
      transforms: [
        ds
      ],
      enter: {
        literalAutolink: fs,
        literalAutolinkEmail: Tn,
        literalAutolinkHttp: Tn,
        literalAutolinkWww: Tn
      },
      exit: {
        literalAutolink: gs,
        literalAutolinkEmail: ms,
        literalAutolinkHttp: hs,
        literalAutolinkWww: ps
      }
    };
  }
  function cs() {
    return {
      unsafe: [
        {
          character: "@",
          before: "[+\\-.\\w]",
          after: "[\\-.\\w]",
          inConstruct: In,
          notInConstruct: An
        },
        {
          character: ".",
          before: "[Ww]",
          after: "[\\-.\\w]",
          inConstruct: In,
          notInConstruct: An
        },
        {
          character: ":",
          before: "[ps]",
          after: "\\/",
          inConstruct: In,
          notInConstruct: An
        }
      ]
    };
  }
  function fs(e) {
    this.enter({
      type: "link",
      title: null,
      url: "",
      children: []
    }, e);
  }
  function Tn(e) {
    this.config.enter.autolinkProtocol.call(this, e);
  }
  function hs(e) {
    this.config.exit.autolinkProtocol.call(this, e);
  }
  function ps(e) {
    this.config.exit.data.call(this, e);
    const t = this.stack[this.stack.length - 1];
    t.type, t.url = "http://" + this.sliceSerialize(e);
  }
  function ms(e) {
    this.config.exit.autolinkEmail.call(this, e);
  }
  function gs(e) {
    this.exit(e);
  }
  function ds(e) {
    ls(e, [
      [
        /(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi,
        ys
      ],
      [
        new RegExp("(?<=^|\\s|\\p{P}|\\p{S})([-.\\w+]+)@([-\\w]+(?:\\.[-\\w]+)+)", "gu"),
        ks
      ]
    ], {
      ignore: [
        "link",
        "linkReference"
      ]
    });
  }
  function ys(e, t, n, r, i) {
    let o = "";
    if (!Vr(i) || (/^w/i.test(t) && (n = t + n, t = "", o = "http://"), !xs(n)))
      return false;
    const l = bs(n + r);
    if (!l[0])
      return false;
    const a = {
      type: "link",
      title: null,
      url: o + t + l[0],
      children: [
        {
          type: "text",
          value: t + l[0]
        }
      ]
    };
    return l[1] ? [
      a,
      {
        type: "text",
        value: l[1]
      }
    ] : a;
  }
  function ks(e, t, n, r) {
    return !Vr(r, true) || /[-\d_]$/.test(n) ? false : {
      type: "link",
      title: null,
      url: "mailto:" + t + "@" + n,
      children: [
        {
          type: "text",
          value: t + "@" + n
        }
      ]
    };
  }
  function xs(e) {
    const t = e.split(".");
    return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[a-zA-Z\d]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[a-zA-Z\d]/.test(t[t.length - 2])));
  }
  function bs(e) {
    const t = /[!"&'),.:;<>?\]}]+$/.exec(e);
    if (!t)
      return [
        e,
        void 0
      ];
    e = e.slice(0, t.index);
    let n = t[0], r = n.indexOf(")");
    const i = Zt(e, "(");
    let o = Zt(e, ")");
    for (; r !== -1 && i > o; )
      e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), o++;
    return [
      e,
      n
    ];
  }
  function Vr(e, t) {
    const n = e.input.charCodeAt(e.index - 1);
    return (e.index === 0 || Ee(n) || sn(n)) && (!t || n !== 47);
  }
  $r.peek = vs;
  function ws() {
    this.buffer();
  }
  function Ss(e) {
    this.enter({
      type: "footnoteReference",
      identifier: "",
      label: ""
    }, e);
  }
  function Cs() {
    this.buffer();
  }
  function Es(e) {
    this.enter({
      type: "footnoteDefinition",
      identifier: "",
      label: "",
      children: []
    }, e);
  }
  function Is(e) {
    const t = this.resume(), n = this.stack[this.stack.length - 1];
    n.type, n.identifier = se(this.sliceSerialize(e)).toLowerCase(), n.label = t;
  }
  function As(e) {
    this.exit(e);
  }
  function Ts(e) {
    const t = this.resume(), n = this.stack[this.stack.length - 1];
    n.type, n.identifier = se(this.sliceSerialize(e)).toLowerCase(), n.label = t;
  }
  function Ps(e) {
    this.exit(e);
  }
  function vs() {
    return "[";
  }
  function $r(e, t, n, r) {
    const i = n.createTracker(r);
    let o = i.move("[^");
    const l = n.enter("footnoteReference"), a = n.enter("reference");
    return o += i.move(n.safe(n.associationId(e), {
      after: "]",
      before: o
    })), a(), l(), o += i.move("]"), o;
  }
  function zs() {
    return {
      enter: {
        gfmFootnoteCallString: ws,
        gfmFootnoteCall: Ss,
        gfmFootnoteDefinitionLabelString: Cs,
        gfmFootnoteDefinition: Es
      },
      exit: {
        gfmFootnoteCallString: Is,
        gfmFootnoteCall: As,
        gfmFootnoteDefinitionLabelString: Ts,
        gfmFootnoteDefinition: Ps
      }
    };
  }
  function Ds(e) {
    let t = false;
    return e && e.firstLineBlank && (t = true), {
      handlers: {
        footnoteDefinition: n,
        footnoteReference: $r
      },
      unsafe: [
        {
          character: "[",
          inConstruct: [
            "label",
            "phrasing",
            "reference"
          ]
        }
      ]
    };
    function n(r, i, o, l) {
      const a = o.createTracker(l);
      let u = a.move("[^");
      const s = o.enter("footnoteDefinition"), f = o.enter("label");
      return u += a.move(o.safe(o.associationId(r), {
        before: u,
        after: "]"
      })), f(), u += a.move("]:"), r.children && r.children.length > 0 && (a.shift(4), u += a.move((t ? `
` : " ") + o.indentLines(o.containerFlow(r, a.current()), t ? qr : Ls))), s(), u;
    }
  }
  function Ls(e, t, n) {
    return t === 0 ? e : qr(e, t, n);
  }
  function qr(e, t, n) {
    return (n ? "" : "    ") + e;
  }
  const Fs = [
    "autolink",
    "destinationLiteral",
    "destinationRaw",
    "reference",
    "titleQuote",
    "titleApostrophe"
  ];
  Wr.peek = Ns;
  function Rs() {
    return {
      canContainEols: [
        "delete"
      ],
      enter: {
        strikethrough: Os
      },
      exit: {
        strikethrough: Ms
      }
    };
  }
  function _s() {
    return {
      unsafe: [
        {
          character: "~",
          inConstruct: "phrasing",
          notInConstruct: Fs
        }
      ],
      handlers: {
        delete: Wr
      }
    };
  }
  function Os(e) {
    this.enter({
      type: "delete",
      children: []
    }, e);
  }
  function Ms(e) {
    this.exit(e);
  }
  function Wr(e, t, n, r) {
    const i = n.createTracker(r), o = n.enter("strikethrough");
    let l = i.move("~~");
    return l += n.containerPhrasing(e, {
      ...i.current(),
      before: l,
      after: "~"
    }), l += i.move("~~"), o(), l;
  }
  function Ns() {
    return "~";
  }
  function Bs(e) {
    return e.length;
  }
  function js(e, t) {
    const n = t || {}, r = (n.align || []).concat(), i = n.stringLength || Bs, o = [], l = [], a = [], u = [];
    let s = 0, f = -1;
    for (; ++f < e.length; ) {
      const x = [], C = [];
      let y = -1;
      for (e[f].length > s && (s = e[f].length); ++y < e[f].length; ) {
        const A = Hs(e[f][y]);
        if (n.alignDelimiters !== false) {
          const E = i(A);
          C[y] = E, (u[y] === void 0 || E > u[y]) && (u[y] = E);
        }
        x.push(A);
      }
      l[f] = x, a[f] = C;
    }
    let c = -1;
    if (typeof r == "object" && "length" in r)
      for (; ++c < s; )
        o[c] = er(r[c]);
    else {
      const x = er(r);
      for (; ++c < s; )
        o[c] = x;
    }
    c = -1;
    const p = [], h = [];
    for (; ++c < s; ) {
      const x = o[c];
      let C = "", y = "";
      x === 99 ? (C = ":", y = ":") : x === 108 ? C = ":" : x === 114 && (y = ":");
      let A = n.alignDelimiters === false ? 1 : Math.max(1, u[c] - C.length - y.length);
      const E = C + "-".repeat(A) + y;
      n.alignDelimiters !== false && (A = C.length + A + y.length, A > u[c] && (u[c] = A), h[c] = A), p[c] = E;
    }
    l.splice(1, 0, p), a.splice(1, 0, h), f = -1;
    const d = [];
    for (; ++f < l.length; ) {
      const x = l[f], C = a[f];
      c = -1;
      const y = [];
      for (; ++c < s; ) {
        const A = x[c] || "";
        let E = "", L = "";
        if (n.alignDelimiters !== false) {
          const F = u[c] - (C[c] || 0), w = o[c];
          w === 114 ? E = " ".repeat(F) : w === 99 ? F % 2 ? (E = " ".repeat(F / 2 + 0.5), L = " ".repeat(F / 2 - 0.5)) : (E = " ".repeat(F / 2), L = E) : L = " ".repeat(F);
        }
        n.delimiterStart !== false && !c && y.push("|"), n.padding !== false && !(n.alignDelimiters === false && A === "") && (n.delimiterStart !== false || c) && y.push(" "), n.alignDelimiters !== false && y.push(E), y.push(A), n.alignDelimiters !== false && y.push(L), n.padding !== false && y.push(" "), (n.delimiterEnd !== false || c !== s - 1) && y.push("|");
      }
      d.push(n.delimiterEnd === false ? y.join("").replace(/ +$/, "") : y.join(""));
    }
    return d.join(`
`);
  }
  function Hs(e) {
    return e == null ? "" : String(e);
  }
  function er(e) {
    const t = typeof e == "string" ? e.codePointAt(0) : 0;
    return t === 67 || t === 99 ? 99 : t === 76 || t === 108 ? 108 : t === 82 || t === 114 ? 114 : 0;
  }
  function Us(e, t, n, r) {
    const i = n.enter("blockquote"), o = n.createTracker(r);
    o.move("> "), o.shift(2);
    const l = n.indentLines(n.containerFlow(e, o.current()), Vs);
    return i(), l;
  }
  function Vs(e, t, n) {
    return ">" + (n ? "" : " ") + e;
  }
  function $s(e, t) {
    return nr(e, t.inConstruct, true) && !nr(e, t.notInConstruct, false);
  }
  function nr(e, t, n) {
    if (typeof t == "string" && (t = [
      t
    ]), !t || t.length === 0)
      return n;
    let r = -1;
    for (; ++r < t.length; )
      if (e.includes(t[r]))
        return true;
    return false;
  }
  function tr(e, t, n, r) {
    let i = -1;
    for (; ++i < n.unsafe.length; )
      if (n.unsafe[i].character === `
` && $s(n.stack, n.unsafe[i]))
        return /[ \t]/.test(r.before) ? "" : " ";
    return `\\
`;
  }
  function qs(e, t) {
    const n = String(e);
    let r = n.indexOf(t), i = r, o = 0, l = 0;
    if (typeof t != "string")
      throw new TypeError("Expected substring");
    for (; r !== -1; )
      r === i ? ++o > l && (l = o) : o = 1, i = r + t.length, r = n.indexOf(t, i);
    return l;
  }
  function Ws(e, t) {
    return !!(t.options.fences === false && e.value && !e.lang && /[^ \r\n]/.test(e.value) && !/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(e.value));
  }
  function Ys(e) {
    const t = e.options.fence || "`";
    if (t !== "`" && t !== "~")
      throw new Error("Cannot serialize code with `" + t + "` for `options.fence`, expected `` ` `` or `~`");
    return t;
  }
  function Xs(e, t, n, r) {
    const i = Ys(n), o = e.value || "", l = i === "`" ? "GraveAccent" : "Tilde";
    if (Ws(e, n)) {
      const c = n.enter("codeIndented"), p = n.indentLines(o, Qs);
      return c(), p;
    }
    const a = n.createTracker(r), u = i.repeat(Math.max(qs(o, i) + 1, 3)), s = n.enter("codeFenced");
    let f = a.move(u);
    if (e.lang) {
      const c = n.enter(`codeFencedLang${l}`);
      f += a.move(n.safe(e.lang, {
        before: f,
        after: " ",
        encode: [
          "`"
        ],
        ...a.current()
      })), c();
    }
    if (e.lang && e.meta) {
      const c = n.enter(`codeFencedMeta${l}`);
      f += a.move(" "), f += a.move(n.safe(e.meta, {
        before: f,
        after: `
`,
        encode: [
          "`"
        ],
        ...a.current()
      })), c();
    }
    return f += a.move(`
`), o && (f += a.move(o + `
`)), f += a.move(u), s(), f;
  }
  function Qs(e, t, n) {
    return (n ? "" : "    ") + e;
  }
  function rt(e) {
    const t = e.options.quote || '"';
    if (t !== '"' && t !== "'")
      throw new Error("Cannot serialize title with `" + t + "` for `options.quote`, expected `\"`, or `'`");
    return t;
  }
  function Gs(e, t, n, r) {
    const i = rt(n), o = i === '"' ? "Quote" : "Apostrophe", l = n.enter("definition");
    let a = n.enter("label");
    const u = n.createTracker(r);
    let s = u.move("[");
    return s += u.move(n.safe(n.associationId(e), {
      before: s,
      after: "]",
      ...u.current()
    })), s += u.move("]: "), a(), !e.url || /[\0- \u007F]/.test(e.url) ? (a = n.enter("destinationLiteral"), s += u.move("<"), s += u.move(n.safe(e.url, {
      before: s,
      after: ">",
      ...u.current()
    })), s += u.move(">")) : (a = n.enter("destinationRaw"), s += u.move(n.safe(e.url, {
      before: s,
      after: e.title ? " " : `
`,
      ...u.current()
    }))), a(), e.title && (a = n.enter(`title${o}`), s += u.move(" " + i), s += u.move(n.safe(e.title, {
      before: s,
      after: i,
      ...u.current()
    })), s += u.move(i), a()), l(), s;
  }
  function Ks(e) {
    const t = e.options.emphasis || "*";
    if (t !== "*" && t !== "_")
      throw new Error("Cannot serialize emphasis with `" + t + "` for `options.emphasis`, expected `*`, or `_`");
    return t;
  }
  function qe(e) {
    return "&#x" + e.toString(16).toUpperCase() + ";";
  }
  function an(e, t, n) {
    const r = Fe(e), i = Fe(t);
    return r === void 0 ? i === void 0 ? n === "_" ? {
      inside: true,
      outside: true
    } : {
      inside: false,
      outside: false
    } : i === 1 ? {
      inside: true,
      outside: true
    } : {
      inside: false,
      outside: true
    } : r === 1 ? i === void 0 ? {
      inside: false,
      outside: false
    } : i === 1 ? {
      inside: true,
      outside: true
    } : {
      inside: false,
      outside: false
    } : i === void 0 ? {
      inside: false,
      outside: false
    } : i === 1 ? {
      inside: true,
      outside: false
    } : {
      inside: false,
      outside: false
    };
  }
  Yr.peek = Js;
  function Yr(e, t, n, r) {
    const i = Ks(n), o = n.enter("emphasis"), l = n.createTracker(r), a = l.move(i);
    let u = l.move(n.containerPhrasing(e, {
      after: i,
      before: a,
      ...l.current()
    }));
    const s = u.charCodeAt(0), f = an(r.before.charCodeAt(r.before.length - 1), s, i);
    f.inside && (u = qe(s) + u.slice(1));
    const c = u.charCodeAt(u.length - 1), p = an(r.after.charCodeAt(0), c, i);
    p.inside && (u = u.slice(0, -1) + qe(c));
    const h = l.move(i);
    return o(), n.attentionEncodeSurroundingInfo = {
      after: p.outside,
      before: f.outside
    }, a + u + h;
  }
  function Js(e, t, n) {
    return n.options.emphasis || "*";
  }
  function Zs(e, t) {
    let n = false;
    return nt(e, function(r) {
      if ("value" in r && /\r?\n|\r/.test(r.value) || r.type === "break")
        return n = true, On;
    }), !!((!e.depth || e.depth < 3) && Xn(e) && (t.options.setext || n));
  }
  function ec(e, t, n, r) {
    const i = Math.max(Math.min(6, e.depth || 1), 1), o = n.createTracker(r);
    if (Zs(e, n)) {
      const f = n.enter("headingSetext"), c = n.enter("phrasing"), p = n.containerPhrasing(e, {
        ...o.current(),
        before: `
`,
        after: `
`
      });
      return c(), f(), p + `
` + (i === 1 ? "=" : "-").repeat(p.length - (Math.max(p.lastIndexOf("\r"), p.lastIndexOf(`
`)) + 1));
    }
    const l = "#".repeat(i), a = n.enter("headingAtx"), u = n.enter("phrasing");
    o.move(l + " ");
    let s = n.containerPhrasing(e, {
      before: "# ",
      after: `
`,
      ...o.current()
    });
    return /^[\t ]/.test(s) && (s = qe(s.charCodeAt(0)) + s.slice(1)), s = s ? l + " " + s : l, n.options.closeAtx && (s += " " + l), u(), a(), s;
  }
  Xr.peek = nc;
  function Xr(e) {
    return e.value || "";
  }
  function nc() {
    return "<";
  }
  Qr.peek = tc;
  function Qr(e, t, n, r) {
    const i = rt(n), o = i === '"' ? "Quote" : "Apostrophe", l = n.enter("image");
    let a = n.enter("label");
    const u = n.createTracker(r);
    let s = u.move("![");
    return s += u.move(n.safe(e.alt, {
      before: s,
      after: "]",
      ...u.current()
    })), s += u.move("]("), a(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (a = n.enter("destinationLiteral"), s += u.move("<"), s += u.move(n.safe(e.url, {
      before: s,
      after: ">",
      ...u.current()
    })), s += u.move(">")) : (a = n.enter("destinationRaw"), s += u.move(n.safe(e.url, {
      before: s,
      after: e.title ? " " : ")",
      ...u.current()
    }))), a(), e.title && (a = n.enter(`title${o}`), s += u.move(" " + i), s += u.move(n.safe(e.title, {
      before: s,
      after: i,
      ...u.current()
    })), s += u.move(i), a()), s += u.move(")"), l(), s;
  }
  function tc() {
    return "!";
  }
  Gr.peek = rc;
  function Gr(e, t, n, r) {
    const i = e.referenceType, o = n.enter("imageReference");
    let l = n.enter("label");
    const a = n.createTracker(r);
    let u = a.move("![");
    const s = n.safe(e.alt, {
      before: u,
      after: "]",
      ...a.current()
    });
    u += a.move(s + "]["), l();
    const f = n.stack;
    n.stack = [], l = n.enter("reference");
    const c = n.safe(n.associationId(e), {
      before: u,
      after: "]",
      ...a.current()
    });
    return l(), n.stack = f, o(), i === "full" || !s || s !== c ? u += a.move(c + "]") : i === "shortcut" ? u = u.slice(0, -1) : u += a.move("]"), u;
  }
  function rc() {
    return "!";
  }
  Kr.peek = ic;
  function Kr(e, t, n) {
    let r = e.value || "", i = "`", o = -1;
    for (; new RegExp("(^|[^`])" + i + "([^`]|$)").test(r); )
      i += "`";
    for (/[^ \r\n]/.test(r) && (/^[ \r\n]/.test(r) && /[ \r\n]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++o < n.unsafe.length; ) {
      const l = n.unsafe[o], a = n.compilePattern(l);
      let u;
      if (l.atBreak)
        for (; u = a.exec(r); ) {
          let s = u.index;
          r.charCodeAt(s) === 10 && r.charCodeAt(s - 1) === 13 && s--, r = r.slice(0, s) + " " + r.slice(u.index + 1);
        }
    }
    return i + r + i;
  }
  function ic() {
    return "`";
  }
  function Jr(e, t) {
    const n = Xn(e);
    return !!(!t.options.resourceLink && e.url && !e.title && e.children && e.children.length === 1 && e.children[0].type === "text" && (n === e.url || "mailto:" + n === e.url) && /^[a-z][a-z+.-]+:/i.test(e.url) && !/[\0- <>\u007F]/.test(e.url));
  }
  Zr.peek = lc;
  function Zr(e, t, n, r) {
    const i = rt(n), o = i === '"' ? "Quote" : "Apostrophe", l = n.createTracker(r);
    let a, u;
    if (Jr(e, n)) {
      const f = n.stack;
      n.stack = [], a = n.enter("autolink");
      let c = l.move("<");
      return c += l.move(n.containerPhrasing(e, {
        before: c,
        after: ">",
        ...l.current()
      })), c += l.move(">"), a(), n.stack = f, c;
    }
    a = n.enter("link"), u = n.enter("label");
    let s = l.move("[");
    return s += l.move(n.containerPhrasing(e, {
      before: s,
      after: "](",
      ...l.current()
    })), s += l.move("]("), u(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (u = n.enter("destinationLiteral"), s += l.move("<"), s += l.move(n.safe(e.url, {
      before: s,
      after: ">",
      ...l.current()
    })), s += l.move(">")) : (u = n.enter("destinationRaw"), s += l.move(n.safe(e.url, {
      before: s,
      after: e.title ? " " : ")",
      ...l.current()
    }))), u(), e.title && (u = n.enter(`title${o}`), s += l.move(" " + i), s += l.move(n.safe(e.title, {
      before: s,
      after: i,
      ...l.current()
    })), s += l.move(i), u()), s += l.move(")"), a(), s;
  }
  function lc(e, t, n) {
    return Jr(e, n) ? "<" : "[";
  }
  ei.peek = oc;
  function ei(e, t, n, r) {
    const i = e.referenceType, o = n.enter("linkReference");
    let l = n.enter("label");
    const a = n.createTracker(r);
    let u = a.move("[");
    const s = n.containerPhrasing(e, {
      before: u,
      after: "]",
      ...a.current()
    });
    u += a.move(s + "]["), l();
    const f = n.stack;
    n.stack = [], l = n.enter("reference");
    const c = n.safe(n.associationId(e), {
      before: u,
      after: "]",
      ...a.current()
    });
    return l(), n.stack = f, o(), i === "full" || !s || s !== c ? u += a.move(c + "]") : i === "shortcut" ? u = u.slice(0, -1) : u += a.move("]"), u;
  }
  function oc() {
    return "[";
  }
  function it(e) {
    const t = e.options.bullet || "*";
    if (t !== "*" && t !== "+" && t !== "-")
      throw new Error("Cannot serialize items with `" + t + "` for `options.bullet`, expected `*`, `+`, or `-`");
    return t;
  }
  function ac(e) {
    const t = it(e), n = e.options.bulletOther;
    if (!n)
      return t === "*" ? "-" : "*";
    if (n !== "*" && n !== "+" && n !== "-")
      throw new Error("Cannot serialize items with `" + n + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
    if (n === t)
      throw new Error("Expected `bullet` (`" + t + "`) and `bulletOther` (`" + n + "`) to be different");
    return n;
  }
  function uc(e) {
    const t = e.options.bulletOrdered || ".";
    if (t !== "." && t !== ")")
      throw new Error("Cannot serialize items with `" + t + "` for `options.bulletOrdered`, expected `.` or `)`");
    return t;
  }
  function ni(e) {
    const t = e.options.rule || "*";
    if (t !== "*" && t !== "-" && t !== "_")
      throw new Error("Cannot serialize rules with `" + t + "` for `options.rule`, expected `*`, `-`, or `_`");
    return t;
  }
  function sc(e, t, n, r) {
    const i = n.enter("list"), o = n.bulletCurrent;
    let l = e.ordered ? uc(n) : it(n);
    const a = e.ordered ? l === "." ? ")" : "." : ac(n);
    let u = t && n.bulletLastUsed ? l === n.bulletLastUsed : false;
    if (!e.ordered) {
      const f = e.children ? e.children[0] : void 0;
      if ((l === "*" || l === "-") && f && (!f.children || !f.children[0]) && n.stack[n.stack.length - 1] === "list" && n.stack[n.stack.length - 2] === "listItem" && n.stack[n.stack.length - 3] === "list" && n.stack[n.stack.length - 4] === "listItem" && n.indexStack[n.indexStack.length - 1] === 0 && n.indexStack[n.indexStack.length - 2] === 0 && n.indexStack[n.indexStack.length - 3] === 0 && (u = true), ni(n) === l && f) {
        let c = -1;
        for (; ++c < e.children.length; ) {
          const p = e.children[c];
          if (p && p.type === "listItem" && p.children && p.children[0] && p.children[0].type === "thematicBreak") {
            u = true;
            break;
          }
        }
      }
    }
    u && (l = a), n.bulletCurrent = l;
    const s = n.containerFlow(e, r);
    return n.bulletLastUsed = l, n.bulletCurrent = o, i(), s;
  }
  function cc(e) {
    const t = e.options.listItemIndent || "one";
    if (t !== "tab" && t !== "one" && t !== "mixed")
      throw new Error("Cannot serialize items with `" + t + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
    return t;
  }
  function fc(e, t, n, r) {
    const i = cc(n);
    let o = n.bulletCurrent || it(n);
    t && t.type === "list" && t.ordered && (o = (typeof t.start == "number" && t.start > -1 ? t.start : 1) + (n.options.incrementListMarker === false ? 0 : t.children.indexOf(e)) + o);
    let l = o.length + 1;
    (i === "tab" || i === "mixed" && (t && t.type === "list" && t.spread || e.spread)) && (l = Math.ceil(l / 4) * 4);
    const a = n.createTracker(r);
    a.move(o + " ".repeat(l - o.length)), a.shift(l);
    const u = n.enter("listItem"), s = n.indentLines(n.containerFlow(e, a.current()), f);
    return u(), s;
    function f(c, p, h) {
      return p ? (h ? "" : " ".repeat(l)) + c : (h ? o : o + " ".repeat(l - o.length)) + c;
    }
  }
  function hc(e, t, n, r) {
    const i = n.enter("paragraph"), o = n.enter("phrasing"), l = n.containerPhrasing(e, r);
    return o(), i(), l;
  }
  const pc = hn([
    "break",
    "delete",
    "emphasis",
    "footnote",
    "footnoteReference",
    "image",
    "imageReference",
    "inlineCode",
    "inlineMath",
    "link",
    "linkReference",
    "mdxJsxTextElement",
    "mdxTextExpression",
    "strong",
    "text",
    "textDirective"
  ]);
  function mc(e, t, n, r) {
    return (e.children.some(function(l) {
      return pc(l);
    }) ? n.containerPhrasing : n.containerFlow).call(n, e, r);
  }
  function gc(e) {
    const t = e.options.strong || "*";
    if (t !== "*" && t !== "_")
      throw new Error("Cannot serialize strong with `" + t + "` for `options.strong`, expected `*`, or `_`");
    return t;
  }
  ti.peek = dc;
  function ti(e, t, n, r) {
    const i = gc(n), o = n.enter("strong"), l = n.createTracker(r), a = l.move(i + i);
    let u = l.move(n.containerPhrasing(e, {
      after: i,
      before: a,
      ...l.current()
    }));
    const s = u.charCodeAt(0), f = an(r.before.charCodeAt(r.before.length - 1), s, i);
    f.inside && (u = qe(s) + u.slice(1));
    const c = u.charCodeAt(u.length - 1), p = an(r.after.charCodeAt(0), c, i);
    p.inside && (u = u.slice(0, -1) + qe(c));
    const h = l.move(i + i);
    return o(), n.attentionEncodeSurroundingInfo = {
      after: p.outside,
      before: f.outside
    }, a + u + h;
  }
  function dc(e, t, n) {
    return n.options.strong || "*";
  }
  function yc(e, t, n, r) {
    return n.safe(e.value, r);
  }
  function kc(e) {
    const t = e.options.ruleRepetition || 3;
    if (t < 3)
      throw new Error("Cannot serialize rules with repetition `" + t + "` for `options.ruleRepetition`, expected `3` or more");
    return t;
  }
  function xc(e, t, n) {
    const r = (ni(n) + (n.options.ruleSpaces ? " " : "")).repeat(kc(n));
    return n.options.ruleSpaces ? r.slice(0, -1) : r;
  }
  const ri = {
    blockquote: Us,
    break: tr,
    code: Xs,
    definition: Gs,
    emphasis: Yr,
    hardBreak: tr,
    heading: ec,
    html: Xr,
    image: Qr,
    imageReference: Gr,
    inlineCode: Kr,
    link: Zr,
    linkReference: ei,
    list: sc,
    listItem: fc,
    paragraph: hc,
    root: mc,
    strong: ti,
    text: yc,
    thematicBreak: xc
  };
  function bc() {
    return {
      enter: {
        table: wc,
        tableData: rr,
        tableHeader: rr,
        tableRow: Cc
      },
      exit: {
        codeText: Ec,
        table: Sc,
        tableData: Pn,
        tableHeader: Pn,
        tableRow: Pn
      }
    };
  }
  function wc(e) {
    const t = e._align;
    this.enter({
      type: "table",
      align: t.map(function(n) {
        return n === "none" ? null : n;
      }),
      children: []
    }, e), this.data.inTable = true;
  }
  function Sc(e) {
    this.exit(e), this.data.inTable = void 0;
  }
  function Cc(e) {
    this.enter({
      type: "tableRow",
      children: []
    }, e);
  }
  function Pn(e) {
    this.exit(e);
  }
  function rr(e) {
    this.enter({
      type: "tableCell",
      children: []
    }, e);
  }
  function Ec(e) {
    let t = this.resume();
    this.data.inTable && (t = t.replace(/\\([\\|])/g, Ic));
    const n = this.stack[this.stack.length - 1];
    n.type, n.value = t, this.exit(e);
  }
  function Ic(e, t) {
    return t === "|" ? t : e;
  }
  function Ac(e) {
    const t = e || {}, n = t.tableCellPadding, r = t.tablePipeAlign, i = t.stringLength, o = n ? " " : "|";
    return {
      unsafe: [
        {
          character: "\r",
          inConstruct: "tableCell"
        },
        {
          character: `
`,
          inConstruct: "tableCell"
        },
        {
          atBreak: true,
          character: "|",
          after: "[	 :-]"
        },
        {
          character: "|",
          inConstruct: "tableCell"
        },
        {
          atBreak: true,
          character: ":",
          after: "-"
        },
        {
          atBreak: true,
          character: "-",
          after: "[:|-]"
        }
      ],
      handlers: {
        inlineCode: p,
        table: l,
        tableCell: u,
        tableRow: a
      }
    };
    function l(h, d, x, C) {
      return s(f(h, x, C), h.align);
    }
    function a(h, d, x, C) {
      const y = c(h, x, C), A = s([
        y
      ]);
      return A.slice(0, A.indexOf(`
`));
    }
    function u(h, d, x, C) {
      const y = x.enter("tableCell"), A = x.enter("phrasing"), E = x.containerPhrasing(h, {
        ...C,
        before: o,
        after: o
      });
      return A(), y(), E;
    }
    function s(h, d) {
      return js(h, {
        align: d,
        alignDelimiters: r,
        padding: n,
        stringLength: i
      });
    }
    function f(h, d, x) {
      const C = h.children;
      let y = -1;
      const A = [], E = d.enter("table");
      for (; ++y < C.length; )
        A[y] = c(C[y], d, x);
      return E(), A;
    }
    function c(h, d, x) {
      const C = h.children;
      let y = -1;
      const A = [], E = d.enter("tableRow");
      for (; ++y < C.length; )
        A[y] = u(C[y], h, d, x);
      return E(), A;
    }
    function p(h, d, x) {
      let C = ri.inlineCode(h, d, x);
      return x.stack.includes("tableCell") && (C = C.replace(/\|/g, "\\$&")), C;
    }
  }
  function Tc() {
    return {
      exit: {
        taskListCheckValueChecked: ir,
        taskListCheckValueUnchecked: ir,
        paragraph: vc
      }
    };
  }
  function Pc() {
    return {
      unsafe: [
        {
          atBreak: true,
          character: "-",
          after: "[:|-]"
        }
      ],
      handlers: {
        listItem: zc
      }
    };
  }
  function ir(e) {
    const t = this.stack[this.stack.length - 2];
    t.type, t.checked = e.type === "taskListCheckValueChecked";
  }
  function vc(e) {
    const t = this.stack[this.stack.length - 2];
    if (t && t.type === "listItem" && typeof t.checked == "boolean") {
      const n = this.stack[this.stack.length - 1];
      n.type;
      const r = n.children[0];
      if (r && r.type === "text") {
        const i = t.children;
        let o = -1, l;
        for (; ++o < i.length; ) {
          const a = i[o];
          if (a.type === "paragraph") {
            l = a;
            break;
          }
        }
        l === n && (r.value = r.value.slice(1), r.value.length === 0 ? n.children.shift() : n.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, n.position.start = Object.assign({}, r.position.start)));
      }
    }
    this.exit(e);
  }
  function zc(e, t, n, r) {
    const i = e.children[0], o = typeof e.checked == "boolean" && i && i.type === "paragraph", l = "[" + (e.checked ? "x" : " ") + "] ", a = n.createTracker(r);
    o && a.move(l);
    let u = ri.listItem(e, t, n, {
      ...r,
      ...a.current()
    });
    return o && (u = u.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, s)), u;
    function s(f) {
      return f + l;
    }
  }
  function Dc() {
    return [
      ss(),
      zs(),
      Rs(),
      bc(),
      Tc()
    ];
  }
  function Lc(e) {
    return {
      extensions: [
        cs(),
        Ds(e),
        _s(),
        Ac(e),
        Pc()
      ]
    };
  }
  const Fc = {
    tokenize: Bc,
    partial: true
  }, ii = {
    tokenize: jc,
    partial: true
  }, li = {
    tokenize: Hc,
    partial: true
  }, oi = {
    tokenize: Uc,
    partial: true
  }, Rc = {
    tokenize: Vc,
    partial: true
  }, ai = {
    name: "wwwAutolink",
    tokenize: Mc,
    previous: si
  }, ui = {
    name: "protocolAutolink",
    tokenize: Nc,
    previous: ci
  }, de = {
    name: "emailAutolink",
    tokenize: Oc,
    previous: fi
  }, fe = {};
  function _c() {
    return {
      text: fe
    };
  }
  let Se = 48;
  for (; Se < 123; )
    fe[Se] = de, Se++, Se === 58 ? Se = 65 : Se === 91 && (Se = 97);
  fe[43] = de;
  fe[45] = de;
  fe[46] = de;
  fe[95] = de;
  fe[72] = [
    de,
    ui
  ];
  fe[104] = [
    de,
    ui
  ];
  fe[87] = [
    de,
    ai
  ];
  fe[119] = [
    de,
    ai
  ];
  function Oc(e, t, n) {
    const r = this;
    let i, o;
    return l;
    function l(c) {
      return !jn(c) || !fi.call(r, r.previous) || lt(r.events) ? n(c) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), a(c));
    }
    function a(c) {
      return jn(c) ? (e.consume(c), a) : c === 64 ? (e.consume(c), u) : n(c);
    }
    function u(c) {
      return c === 46 ? e.check(Rc, f, s)(c) : c === 45 || c === 95 || G(c) ? (o = true, e.consume(c), u) : f(c);
    }
    function s(c) {
      return e.consume(c), i = true, u;
    }
    function f(c) {
      return o && i && J(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(c)) : n(c);
    }
  }
  function Mc(e, t, n) {
    const r = this;
    return i;
    function i(l) {
      return l !== 87 && l !== 119 || !si.call(r, r.previous) || lt(r.events) ? n(l) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(Fc, e.attempt(ii, e.attempt(li, o), n), n)(l));
    }
    function o(l) {
      return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(l);
    }
  }
  function Nc(e, t, n) {
    const r = this;
    let i = "", o = false;
    return l;
    function l(c) {
      return (c === 72 || c === 104) && ci.call(r, r.previous) && !lt(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(c), e.consume(c), a) : n(c);
    }
    function a(c) {
      if (J(c) && i.length < 5)
        return i += String.fromCodePoint(c), e.consume(c), a;
      if (c === 58) {
        const p = i.toLowerCase();
        if (p === "http" || p === "https")
          return e.consume(c), u;
      }
      return n(c);
    }
    function u(c) {
      return c === 47 ? (e.consume(c), o ? s : (o = true, u)) : n(c);
    }
    function s(c) {
      return c === null || rn(c) || U(c) || Ee(c) || sn(c) ? n(c) : e.attempt(ii, e.attempt(li, f), n)(c);
    }
    function f(c) {
      return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(c);
    }
  }
  function Bc(e, t, n) {
    let r = 0;
    return i;
    function i(l) {
      return (l === 87 || l === 119) && r < 3 ? (r++, e.consume(l), i) : l === 46 && r === 3 ? (e.consume(l), o) : n(l);
    }
    function o(l) {
      return l === null ? n(l) : t(l);
    }
  }
  function jc(e, t, n) {
    let r, i, o;
    return l;
    function l(s) {
      return s === 46 || s === 95 ? e.check(oi, u, a)(s) : s === null || U(s) || Ee(s) || s !== 45 && sn(s) ? u(s) : (o = true, e.consume(s), l);
    }
    function a(s) {
      return s === 95 ? r = true : (i = r, r = void 0), e.consume(s), l;
    }
    function u(s) {
      return i || r || !o ? n(s) : t(s);
    }
  }
  function Hc(e, t) {
    let n = 0, r = 0;
    return i;
    function i(l) {
      return l === 40 ? (n++, e.consume(l), i) : l === 41 && r < n ? o(l) : l === 33 || l === 34 || l === 38 || l === 39 || l === 41 || l === 42 || l === 44 || l === 46 || l === 58 || l === 59 || l === 60 || l === 63 || l === 93 || l === 95 || l === 126 ? e.check(oi, t, o)(l) : l === null || U(l) || Ee(l) ? t(l) : (e.consume(l), i);
    }
    function o(l) {
      return l === 41 && r++, e.consume(l), i;
    }
  }
  function Uc(e, t, n) {
    return r;
    function r(a) {
      return a === 33 || a === 34 || a === 39 || a === 41 || a === 42 || a === 44 || a === 46 || a === 58 || a === 59 || a === 63 || a === 95 || a === 126 ? (e.consume(a), r) : a === 38 ? (e.consume(a), o) : a === 93 ? (e.consume(a), i) : a === 60 || a === null || U(a) || Ee(a) ? t(a) : n(a);
    }
    function i(a) {
      return a === null || a === 40 || a === 91 || U(a) || Ee(a) ? t(a) : r(a);
    }
    function o(a) {
      return J(a) ? l(a) : n(a);
    }
    function l(a) {
      return a === 59 ? (e.consume(a), r) : J(a) ? (e.consume(a), l) : n(a);
    }
  }
  function Vc(e, t, n) {
    return r;
    function r(o) {
      return e.consume(o), i;
    }
    function i(o) {
      return G(o) ? n(o) : t(o);
    }
  }
  function si(e) {
    return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || U(e);
  }
  function ci(e) {
    return !J(e);
  }
  function fi(e) {
    return !(e === 47 || jn(e));
  }
  function jn(e) {
    return e === 43 || e === 45 || e === 46 || e === 95 || G(e);
  }
  function lt(e) {
    let t = e.length, n = false;
    for (; t--; ) {
      const r = e[t][1];
      if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
        n = true;
        break;
      }
      if (r._gfmAutolinkLiteralWalkedInto) {
        n = false;
        break;
      }
    }
    return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = true), n;
  }
  const $c = {
    tokenize: Jc,
    partial: true
  };
  function qc() {
    return {
      document: {
        91: {
          name: "gfmFootnoteDefinition",
          tokenize: Qc,
          continuation: {
            tokenize: Gc
          },
          exit: Kc
        }
      },
      text: {
        91: {
          name: "gfmFootnoteCall",
          tokenize: Xc
        },
        93: {
          name: "gfmPotentialFootnoteCall",
          add: "after",
          tokenize: Wc,
          resolveTo: Yc
        }
      }
    };
  }
  function Wc(e, t, n) {
    const r = this;
    let i = r.events.length;
    const o = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
    let l;
    for (; i--; ) {
      const u = r.events[i][1];
      if (u.type === "labelImage") {
        l = u;
        break;
      }
      if (u.type === "gfmFootnoteCall" || u.type === "labelLink" || u.type === "label" || u.type === "image" || u.type === "link")
        break;
    }
    return a;
    function a(u) {
      if (!l || !l._balanced)
        return n(u);
      const s = se(r.sliceSerialize({
        start: l.end,
        end: r.now()
      }));
      return s.codePointAt(0) !== 94 || !o.includes(s.slice(1)) ? n(u) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(u), e.exit("gfmFootnoteCallLabelMarker"), t(u));
    }
  }
  function Yc(e, t) {
    let n = e.length;
    for (; n--; )
      if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
        e[n][1];
        break;
      }
    e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
    const r = {
      type: "gfmFootnoteCall",
      start: Object.assign({}, e[n + 3][1].start),
      end: Object.assign({}, e[e.length - 1][1].end)
    }, i = {
      type: "gfmFootnoteCallMarker",
      start: Object.assign({}, e[n + 3][1].end),
      end: Object.assign({}, e[n + 3][1].end)
    };
    i.end.column++, i.end.offset++, i.end._bufferIndex++;
    const o = {
      type: "gfmFootnoteCallString",
      start: Object.assign({}, i.end),
      end: Object.assign({}, e[e.length - 1][1].start)
    }, l = {
      type: "chunkString",
      contentType: "string",
      start: Object.assign({}, o.start),
      end: Object.assign({}, o.end)
    }, a = [
      e[n + 1],
      e[n + 2],
      [
        "enter",
        r,
        t
      ],
      e[n + 3],
      e[n + 4],
      [
        "enter",
        i,
        t
      ],
      [
        "exit",
        i,
        t
      ],
      [
        "enter",
        o,
        t
      ],
      [
        "enter",
        l,
        t
      ],
      [
        "exit",
        l,
        t
      ],
      [
        "exit",
        o,
        t
      ],
      e[e.length - 2],
      e[e.length - 1],
      [
        "exit",
        r,
        t
      ]
    ];
    return e.splice(n, e.length - n + 1, ...a), e;
  }
  function Xc(e, t, n) {
    const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
    let o = 0, l;
    return a;
    function a(c) {
      return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(c), e.exit("gfmFootnoteCallLabelMarker"), u;
    }
    function u(c) {
      return c !== 94 ? n(c) : (e.enter("gfmFootnoteCallMarker"), e.consume(c), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", s);
    }
    function s(c) {
      if (o > 999 || c === 93 && !l || c === null || c === 91 || U(c))
        return n(c);
      if (c === 93) {
        e.exit("chunkString");
        const p = e.exit("gfmFootnoteCallString");
        return i.includes(se(r.sliceSerialize(p))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(c), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(c);
      }
      return U(c) || (l = true), o++, e.consume(c), c === 92 ? f : s;
    }
    function f(c) {
      return c === 91 || c === 92 || c === 93 ? (e.consume(c), o++, s) : s(c);
    }
  }
  function Qc(e, t, n) {
    const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
    let o, l = 0, a;
    return u;
    function u(d) {
      return e.enter("gfmFootnoteDefinition")._container = true, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(d), e.exit("gfmFootnoteDefinitionLabelMarker"), s;
    }
    function s(d) {
      return d === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(d), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", f) : n(d);
    }
    function f(d) {
      if (l > 999 || d === 93 && !a || d === null || d === 91 || U(d))
        return n(d);
      if (d === 93) {
        e.exit("chunkString");
        const x = e.exit("gfmFootnoteDefinitionLabelString");
        return o = se(r.sliceSerialize(x)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(d), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), p;
      }
      return U(d) || (a = true), l++, e.consume(d), d === 92 ? c : f;
    }
    function c(d) {
      return d === 91 || d === 92 || d === 93 ? (e.consume(d), l++, f) : f(d);
    }
    function p(d) {
      return d === 58 ? (e.enter("definitionMarker"), e.consume(d), e.exit("definitionMarker"), i.includes(o) || i.push(o), O(e, h, "gfmFootnoteDefinitionWhitespace")) : n(d);
    }
    function h(d) {
      return t(d);
    }
  }
  function Gc(e, t, n) {
    return e.check(Ye, t, e.attempt($c, t, n));
  }
  function Kc(e) {
    e.exit("gfmFootnoteDefinition");
  }
  function Jc(e, t, n) {
    const r = this;
    return O(e, i, "gfmFootnoteDefinitionIndent", 4 + 1);
    function i(o) {
      const l = r.events[r.events.length - 1];
      return l && l[1].type === "gfmFootnoteDefinitionIndent" && l[2].sliceSerialize(l[1], true).length === 4 ? t(o) : n(o);
    }
  }
  function Zc(e) {
    let n = (e || {}).singleTilde;
    const r = {
      name: "strikethrough",
      tokenize: o,
      resolveAll: i
    };
    return n == null && (n = true), {
      text: {
        126: r
      },
      insideSpan: {
        null: [
          r
        ]
      },
      attentionMarkers: {
        null: [
          126
        ]
      }
    };
    function i(l, a) {
      let u = -1;
      for (; ++u < l.length; )
        if (l[u][0] === "enter" && l[u][1].type === "strikethroughSequenceTemporary" && l[u][1]._close) {
          let s = u;
          for (; s--; )
            if (l[s][0] === "exit" && l[s][1].type === "strikethroughSequenceTemporary" && l[s][1]._open && l[u][1].end.offset - l[u][1].start.offset === l[s][1].end.offset - l[s][1].start.offset) {
              l[u][1].type = "strikethroughSequence", l[s][1].type = "strikethroughSequence";
              const f = {
                type: "strikethrough",
                start: Object.assign({}, l[s][1].start),
                end: Object.assign({}, l[u][1].end)
              }, c = {
                type: "strikethroughText",
                start: Object.assign({}, l[s][1].end),
                end: Object.assign({}, l[u][1].start)
              }, p = [
                [
                  "enter",
                  f,
                  a
                ],
                [
                  "enter",
                  l[s][1],
                  a
                ],
                [
                  "exit",
                  l[s][1],
                  a
                ],
                [
                  "enter",
                  c,
                  a
                ]
              ], h = a.parser.constructs.insideSpan.null;
              h && re(p, p.length, 0, cn(h, l.slice(s + 1, u), a)), re(p, p.length, 0, [
                [
                  "exit",
                  c,
                  a
                ],
                [
                  "enter",
                  l[u][1],
                  a
                ],
                [
                  "exit",
                  l[u][1],
                  a
                ],
                [
                  "exit",
                  f,
                  a
                ]
              ]), re(l, s - 1, u - s + 3, p), u = s + p.length - 2;
              break;
            }
        }
      for (u = -1; ++u < l.length; )
        l[u][1].type === "strikethroughSequenceTemporary" && (l[u][1].type = "data");
      return l;
    }
    function o(l, a, u) {
      const s = this.previous, f = this.events;
      let c = 0;
      return p;
      function p(d) {
        return s === 126 && f[f.length - 1][1].type !== "characterEscape" ? u(d) : (l.enter("strikethroughSequenceTemporary"), h(d));
      }
      function h(d) {
        const x = Fe(s);
        if (d === 126)
          return c > 1 ? u(d) : (l.consume(d), c++, h);
        if (c < 2 && !n)
          return u(d);
        const C = l.exit("strikethroughSequenceTemporary"), y = Fe(d);
        return C._open = !y || y === 2 && !!x, C._close = !x || x === 2 && !!y, a(d);
      }
    }
  }
  class ef {
    constructor() {
      this.map = [];
    }
    add(t, n, r) {
      nf(this, t, n, r);
    }
    consume(t) {
      if (this.map.sort(function(o, l) {
        return o[0] - l[0];
      }), this.map.length === 0)
        return;
      let n = this.map.length;
      const r = [];
      for (; n > 0; )
        n -= 1, r.push(t.slice(this.map[n][0] + this.map[n][1]), this.map[n][2]), t.length = this.map[n][0];
      r.push(t.slice()), t.length = 0;
      let i = r.pop();
      for (; i; ) {
        for (const o of i)
          t.push(o);
        i = r.pop();
      }
      this.map.length = 0;
    }
  }
  function nf(e, t, n, r) {
    let i = 0;
    if (!(n === 0 && r.length === 0)) {
      for (; i < e.map.length; ) {
        if (e.map[i][0] === t) {
          e.map[i][1] += n, e.map[i][2].push(...r);
          return;
        }
        i += 1;
      }
      e.map.push([
        t,
        n,
        r
      ]);
    }
  }
  function tf(e, t) {
    let n = false;
    const r = [];
    for (; t < e.length; ) {
      const i = e[t];
      if (n) {
        if (i[0] === "enter")
          i[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
        else if (i[1].type === "tableContent") {
          if (e[t - 1][1].type === "tableDelimiterMarker") {
            const o = r.length - 1;
            r[o] = r[o] === "left" ? "center" : "right";
          }
        } else if (i[1].type === "tableDelimiterRow")
          break;
      } else
        i[0] === "enter" && i[1].type === "tableDelimiterRow" && (n = true);
      t += 1;
    }
    return r;
  }
  function rf() {
    return {
      flow: {
        null: {
          name: "table",
          tokenize: lf,
          resolveAll: of
        }
      }
    };
  }
  function lf(e, t, n) {
    const r = this;
    let i = 0, o = 0, l;
    return a;
    function a(k) {
      let T = r.events.length - 1;
      for (; T > -1; ) {
        const q = r.events[T][1].type;
        if (q === "lineEnding" || q === "linePrefix")
          T--;
        else
          break;
      }
      const P = T > -1 ? r.events[T][1].type : null, j = P === "tableHead" || P === "tableRow" ? w : u;
      return j === w && r.parser.lazy[r.now().line] ? n(k) : j(k);
    }
    function u(k) {
      return e.enter("tableHead"), e.enter("tableRow"), s(k);
    }
    function s(k) {
      return k === 124 || (l = true, o += 1), f(k);
    }
    function f(k) {
      return k === null ? n(k) : v(k) ? o > 1 ? (o = 0, r.interrupt = true, e.exit("tableRow"), e.enter("lineEnding"), e.consume(k), e.exit("lineEnding"), h) : n(k) : R(k) ? O(e, f, "whitespace")(k) : (o += 1, l && (l = false, i += 1), k === 124 ? (e.enter("tableCellDivider"), e.consume(k), e.exit("tableCellDivider"), l = true, f) : (e.enter("data"), c(k)));
    }
    function c(k) {
      return k === null || k === 124 || U(k) ? (e.exit("data"), f(k)) : (e.consume(k), k === 92 ? p : c);
    }
    function p(k) {
      return k === 92 || k === 124 ? (e.consume(k), c) : c(k);
    }
    function h(k) {
      return r.interrupt = false, r.parser.lazy[r.now().line] ? n(k) : (e.enter("tableDelimiterRow"), l = false, R(k) ? O(e, d, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(k) : d(k));
    }
    function d(k) {
      return k === 45 || k === 58 ? C(k) : k === 124 ? (l = true, e.enter("tableCellDivider"), e.consume(k), e.exit("tableCellDivider"), x) : F(k);
    }
    function x(k) {
      return R(k) ? O(e, C, "whitespace")(k) : C(k);
    }
    function C(k) {
      return k === 58 ? (o += 1, l = true, e.enter("tableDelimiterMarker"), e.consume(k), e.exit("tableDelimiterMarker"), y) : k === 45 ? (o += 1, y(k)) : k === null || v(k) ? L(k) : F(k);
    }
    function y(k) {
      return k === 45 ? (e.enter("tableDelimiterFiller"), A(k)) : F(k);
    }
    function A(k) {
      return k === 45 ? (e.consume(k), A) : k === 58 ? (l = true, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(k), e.exit("tableDelimiterMarker"), E) : (e.exit("tableDelimiterFiller"), E(k));
    }
    function E(k) {
      return R(k) ? O(e, L, "whitespace")(k) : L(k);
    }
    function L(k) {
      return k === 124 ? d(k) : k === null || v(k) ? !l || i !== o ? F(k) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(k)) : F(k);
    }
    function F(k) {
      return n(k);
    }
    function w(k) {
      return e.enter("tableRow"), M(k);
    }
    function M(k) {
      return k === 124 ? (e.enter("tableCellDivider"), e.consume(k), e.exit("tableCellDivider"), M) : k === null || v(k) ? (e.exit("tableRow"), t(k)) : R(k) ? O(e, M, "whitespace")(k) : (e.enter("data"), $(k));
    }
    function $(k) {
      return k === null || k === 124 || U(k) ? (e.exit("data"), M(k)) : (e.consume(k), k === 92 ? B : $);
    }
    function B(k) {
      return k === 92 || k === 124 ? (e.consume(k), $) : $(k);
    }
  }
  function of(e, t) {
    let n = -1, r = true, i = 0, o = [
      0,
      0,
      0,
      0
    ], l = [
      0,
      0,
      0,
      0
    ], a = false, u = 0, s, f, c;
    const p = new ef();
    for (; ++n < e.length; ) {
      const h = e[n], d = h[1];
      h[0] === "enter" ? d.type === "tableHead" ? (a = false, u !== 0 && (lr(p, t, u, s, f), f = void 0, u = 0), s = {
        type: "table",
        start: Object.assign({}, d.start),
        end: Object.assign({}, d.end)
      }, p.add(n, 0, [
        [
          "enter",
          s,
          t
        ]
      ])) : d.type === "tableRow" || d.type === "tableDelimiterRow" ? (r = true, c = void 0, o = [
        0,
        0,
        0,
        0
      ], l = [
        0,
        n + 1,
        0,
        0
      ], a && (a = false, f = {
        type: "tableBody",
        start: Object.assign({}, d.start),
        end: Object.assign({}, d.end)
      }, p.add(n, 0, [
        [
          "enter",
          f,
          t
        ]
      ])), i = d.type === "tableDelimiterRow" ? 2 : f ? 3 : 1) : i && (d.type === "data" || d.type === "tableDelimiterMarker" || d.type === "tableDelimiterFiller") ? (r = false, l[2] === 0 && (o[1] !== 0 && (l[0] = l[1], c = Ze(p, t, o, i, void 0, c), o = [
        0,
        0,
        0,
        0
      ]), l[2] = n)) : d.type === "tableCellDivider" && (r ? r = false : (o[1] !== 0 && (l[0] = l[1], c = Ze(p, t, o, i, void 0, c)), o = l, l = [
        o[1],
        n,
        0,
        0
      ])) : d.type === "tableHead" ? (a = true, u = n) : d.type === "tableRow" || d.type === "tableDelimiterRow" ? (u = n, o[1] !== 0 ? (l[0] = l[1], c = Ze(p, t, o, i, n, c)) : l[1] !== 0 && (c = Ze(p, t, l, i, n, c)), i = 0) : i && (d.type === "data" || d.type === "tableDelimiterMarker" || d.type === "tableDelimiterFiller") && (l[3] = n);
    }
    for (u !== 0 && lr(p, t, u, s, f), p.consume(t.events), n = -1; ++n < t.events.length; ) {
      const h = t.events[n];
      h[0] === "enter" && h[1].type === "table" && (h[1]._align = tf(t.events, n));
    }
    return e;
  }
  function Ze(e, t, n, r, i, o) {
    const l = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData", a = "tableContent";
    n[0] !== 0 && (o.end = Object.assign({}, ze(t.events, n[0])), e.add(n[0], 0, [
      [
        "exit",
        o,
        t
      ]
    ]));
    const u = ze(t.events, n[1]);
    if (o = {
      type: l,
      start: Object.assign({}, u),
      end: Object.assign({}, u)
    }, e.add(n[1], 0, [
      [
        "enter",
        o,
        t
      ]
    ]), n[2] !== 0) {
      const s = ze(t.events, n[2]), f = ze(t.events, n[3]), c = {
        type: a,
        start: Object.assign({}, s),
        end: Object.assign({}, f)
      };
      if (e.add(n[2], 0, [
        [
          "enter",
          c,
          t
        ]
      ]), r !== 2) {
        const p = t.events[n[2]], h = t.events[n[3]];
        if (p[1].end = Object.assign({}, h[1].end), p[1].type = "chunkText", p[1].contentType = "text", n[3] > n[2] + 1) {
          const d = n[2] + 1, x = n[3] - n[2] - 1;
          e.add(d, x, []);
        }
      }
      e.add(n[3] + 1, 0, [
        [
          "exit",
          c,
          t
        ]
      ]);
    }
    return i !== void 0 && (o.end = Object.assign({}, ze(t.events, i)), e.add(i, 0, [
      [
        "exit",
        o,
        t
      ]
    ]), o = void 0), o;
  }
  function lr(e, t, n, r, i) {
    const o = [], l = ze(t.events, n);
    i && (i.end = Object.assign({}, l), o.push([
      "exit",
      i,
      t
    ])), r.end = Object.assign({}, l), o.push([
      "exit",
      r,
      t
    ]), e.add(n + 1, 0, o);
  }
  function ze(e, t) {
    const n = e[t], r = n[0] === "enter" ? "start" : "end";
    return n[1][r];
  }
  const af = {
    name: "tasklistCheck",
    tokenize: sf
  };
  function uf() {
    return {
      text: {
        91: af
      }
    };
  }
  function sf(e, t, n) {
    const r = this;
    return i;
    function i(u) {
      return r.previous !== null || !r._gfmTasklistFirstContentOfListItem ? n(u) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(u), e.exit("taskListCheckMarker"), o);
    }
    function o(u) {
      return U(u) ? (e.enter("taskListCheckValueUnchecked"), e.consume(u), e.exit("taskListCheckValueUnchecked"), l) : u === 88 || u === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(u), e.exit("taskListCheckValueChecked"), l) : n(u);
    }
    function l(u) {
      return u === 93 ? (e.enter("taskListCheckMarker"), e.consume(u), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), a) : n(u);
    }
    function a(u) {
      return v(u) ? t(u) : R(u) ? e.check({
        tokenize: cf
      }, t, n)(u) : n(u);
    }
  }
  function cf(e, t, n) {
    return O(e, r, "whitespace");
    function r(i) {
      return i === null ? n(i) : t(i);
    }
  }
  function ff(e) {
    return wr([
      _c(),
      qc(),
      Zc(e),
      rf(),
      uf()
    ]);
  }
  const hf = {};
  function pf(e) {
    const t = this, n = e || hf, r = t.data(), i = r.micromarkExtensions || (r.micromarkExtensions = []), o = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []), l = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
    i.push(ff(n)), o.push(Dc()), l.push(Lc(n));
  }
  const mf = "bg-gray-50 dark:bg-slate-900 p-3 rounded border border-gray-100 dark:border-slate-700";
  yf = function({ text: e }) {
    return De.jsx("div", {
      className: mf,
      children: De.jsx("div", {
        className: "prose prose-sm dark:prose-invert max-w-none prose-headings:mt-3 prose-headings:mb-1 prose-p:text-xs prose-p:my-1 prose-li:text-xs prose-code:text-xs prose-pre:text-xs prose-td:text-xs prose-th:text-xs prose-blockquote:text-xs prose-a:text-blue-600 dark:prose-a:text-blue-400",
        children: De.jsx(Zu, {
          remarkPlugins: [
            pf
          ],
          children: e
        })
      })
    });
  };
});
export {
  yf as M,
  __tla
};
