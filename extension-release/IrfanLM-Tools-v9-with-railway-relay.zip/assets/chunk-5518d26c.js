import { r as y, j as t, X as Q, u as X, J as k, U as B, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { d as N, l as x, av as v, k as S, P as O, B as Y, ay as Z, I as q, O as ee, S as te, b as se, a as ae, h as re, T as oe, K as ne, Q as ce, i as le, H as ie, J as de, aM as R } from "./chunk-68adfa56.js";
import { i as ue, z as ge, Q as fe, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { L as me, __tla as __tla_2 } from "./chunk-de7ca15a.js";
import { A as pe, __tla as __tla_3 } from "./chunk-5a4465c9.js";
import { A as xe, __tla as __tla_4 } from "./chunk-57988b21.js";
import { A as be, __tla as __tla_5 } from "./chunk-234b1720.js";
let _e;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  const _ = "nlmtools-backup", M = 1, ye = 10 * 1024 * 1024, A = [
    Y,
    Z,
    q,
    ee,
    te,
    se,
    ae,
    re,
    oe,
    ne,
    ce,
    le,
    ie,
    de
  ], P = (e) => {
    if (!e)
      return 0;
    const s = e.tags || {};
    return typeof s == "object" ? Object.keys(s).length : 0;
  }, U = (e) => {
    if (!e || !e.folders)
      return 0;
    let s = 0;
    for (const a of Object.values(e.folders))
      s += Object.keys(a).length;
    return s;
  }, D = (e) => Array.isArray(e) ? e.length : e && typeof e == "object" && Array.isArray(e.customPrompts) ? e.customPrompts.length : 0, T = [
    {
      key: "tags",
      label: "Tags",
      storageKeys: [
        N
      ],
      countFn: async () => {
        const e = await x.get(N);
        return P(e);
      },
      countLabel: (e) => `${e} tag${e !== 1 ? "s" : ""}`
    },
    {
      key: "sourceFolders",
      label: "Source Folders",
      storageKeys: [
        v
      ],
      countFn: async () => {
        const e = await x.get(v);
        return U(e);
      },
      countLabel: (e) => `${e} folder${e !== 1 ? "s" : ""}`
    },
    {
      key: "prompts",
      label: "Prompts",
      storageKeys: [
        S,
        O
      ],
      countFn: async () => {
        const e = await x.get(S);
        return D(e);
      },
      countLabel: (e) => `${e} prompt${e !== 1 ? "s" : ""}`
    },
    {
      key: "preferences",
      label: "Preferences",
      storageKeys: A,
      countFn: async () => {
        const e = await x.getKeys(A);
        return Object.keys(e).filter((s) => e[s] !== void 0).length;
      },
      countLabel: (e) => `${e} setting${e !== 1 ? "s" : ""}`
    }
  ], he = (e) => T.find((s) => s.key === e), ke = async (e) => {
    const s = {};
    for (const a of e)
      if (he(a)) {
        if (a === "tags") {
          const n = await x.get(N);
          s.tags = {
            data: n || {
              tags: {},
              notebookTags: {}
            },
            count: P(n)
          };
        } else if (a === "sourceFolders") {
          const n = await x.get(v);
          s.sourceFolders = {
            data: n || {
              folders: {},
              sourceFolderMap: {}
            },
            count: U(n)
          };
        } else if (a === "prompts") {
          const n = await x.get(S), o = await x.get(O);
          s.prompts = {
            data: {
              prompts: n || [],
              usage: o || {}
            },
            count: D(n)
          };
        } else if (a === "preferences") {
          const n = await x.getKeys(A), o = {};
          for (const l of A)
            n[l] !== void 0 && (o[l] = n[l]);
          s.preferences = {
            data: o,
            count: Object.keys(o).length
          };
        }
      }
    return {
      version: M,
      type: _,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      extensionVersion: chrome.runtime.getManifest().version,
      categories: s
    };
  }, je = (e) => {
    if (!e || typeof e != "object")
      return {
        valid: false,
        error: "Invalid JSON file"
      };
    if (e.type !== _)
      return {
        valid: false,
        error: "Not a NLM Tools backup file"
      };
    if (e.version > M)
      return {
        valid: false,
        error: "Unsupported backup version. Please update the extension."
      };
    if (!e.categories || typeof e.categories != "object")
      return {
        valid: false,
        error: "Invalid backup structure"
      };
    if (e.categories.tags) {
      const s = e.categories.tags.data;
      if (!s || typeof s != "object")
        return {
          valid: false,
          error: "Invalid tags data"
        };
    }
    if (e.categories.sourceFolders) {
      const s = e.categories.sourceFolders.data;
      if (!s || typeof s != "object")
        return {
          valid: false,
          error: "Invalid source folders data"
        };
    }
    if (e.categories.prompts) {
      const s = e.categories.prompts.data;
      if (!s || typeof s != "object")
        return {
          valid: false,
          error: "Invalid prompts data"
        };
    }
    if (e.categories.preferences) {
      const s = e.categories.preferences.data;
      if (!s || typeof s != "object")
        return {
          valid: false,
          error: "Invalid preferences data"
        };
    }
    return {
      valid: true
    };
  }, we = (e) => {
    const s = [];
    for (const a of T)
      e.categories[a.key] && s.push({
        key: a.key,
        label: a.label,
        count: e.categories[a.key].count || 0,
        countLabel: a.countLabel(e.categories[a.key].count || 0)
      });
    return s;
  }, Ne = async (e, s, a = "replace") => {
    const r = {};
    for (const n of s) {
      const o = e.categories[n];
      if (o)
        if (n === "tags")
          if (a === "merge") {
            const l = await x.get(N);
            r[N] = ve(l, o.data);
          } else
            r[N] = o.data;
        else if (n === "sourceFolders")
          if (a === "merge") {
            const l = await x.get(v);
            r[v] = Se(l, o.data);
          } else
            r[v] = o.data;
        else if (n === "prompts")
          if (a === "merge") {
            const l = await x.get(S), f = await x.get(O), d = Ee(l, f, o.data);
            r[S] = d.prompts, r[O] = d.usage;
          } else
            r[S] = o.data.prompts || [], r[O] = o.data.usage || {};
        else
          n === "preferences" && a === "replace" && Object.assign(r, o.data);
    }
    await new Promise((n, o) => {
      try {
        chrome.storage.local.set(r, () => {
          if (chrome.runtime.lastError) {
            o(new Error(chrome.runtime.lastError.message));
            return;
          }
          n();
        });
      } catch (l) {
        o(l);
      }
    });
  }, ve = (e, s) => {
    const a = e || {
      tags: {},
      notebookTags: {}
    }, r = a.tags || {}, n = a.notebookTags || {}, o = s.tags || {}, l = s.notebookTags || {}, f = new Set(Object.values(r).map((m) => m.name.toLowerCase())), d = {}, b = {
      ...r
    };
    for (const [m, i] of Object.entries(o)) {
      if (f.has(i.name.toLowerCase())) {
        const p = Object.values(r).find((h) => h.name.toLowerCase() === i.name.toLowerCase());
        p && (d[m] = p.id);
        continue;
      }
      b[m] = i, d[m] = m, f.add(i.name.toLowerCase());
    }
    const u = {
      ...n
    };
    for (const [m, i] of Object.entries(l)) {
      const p = i.map((h) => d[h]).filter(Boolean);
      if (p.length > 0) {
        const h = u[m] || [];
        u[m] = [
          .../* @__PURE__ */ new Set([
            ...h,
            ...p
          ])
        ];
      }
    }
    return {
      tags: b,
      notebookTags: u
    };
  }, Se = (e, s) => {
    const a = e || {
      folders: {},
      sourceFolderMap: {}
    }, r = {
      folders: {
        ...a.folders
      },
      sourceFolderMap: {
        ...a.sourceFolderMap
      }
    }, n = s.folders || {};
    for (const [l, f] of Object.entries(n)) {
      const d = r.folders[l] || {}, b = new Set(Object.values(d).map((m) => m.name.toLowerCase())), u = {
        ...d
      };
      for (const [m, i] of Object.entries(f))
        b.has(i.name.toLowerCase()) || (u[m] = i, b.add(i.name.toLowerCase()));
      r.folders[l] = u;
    }
    const o = s.sourceFolderMap || {};
    for (const [l, f] of Object.entries(o)) {
      const d = r.sourceFolderMap[l] || {};
      r.sourceFolderMap[l] = {
        ...d,
        ...f
      };
    }
    return r;
  }, Ee = (e, s, a) => {
    const r = Array.isArray(e) ? e : [], n = s || {}, o = a.prompts || [], l = a.usage || {}, f = new Set(r.map((u) => u.title.toLowerCase())), d = [
      ...r
    ], b = {
      ...n
    };
    for (const u of o)
      f.has(u.title.toLowerCase()) || (d.push(u), f.add(u.title.toLowerCase()), l[u.id] && (b[u.id] = l[u.id]));
    return {
      prompts: d,
      usage: b
    };
  };
  function Oe({ open: e, onClose: s, pendingBackup: a, availableCategories: r, onRestore: n, isRestoring: o }) {
    const [l, f] = y.useState({}), [d, b] = y.useState("replace");
    y.useEffect(() => {
      r.length > 0 && (f(Object.fromEntries(r.map((i) => [
        i.key,
        true
      ]))), b("replace"));
    }, [
      r
    ]);
    const u = Object.values(l).filter(Boolean).length, m = () => {
      const i = Object.entries(l).filter(([, p]) => p).map(([p]) => p);
      i.length !== 0 && n(i, d);
    };
    return t.jsxs(ue, {
      open: e,
      onClose: () => {
        o || s();
      },
      className: "relative z-50",
      children: [
        t.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        t.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: t.jsxs(ge, {
            className: "w-full max-w-sm bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              t.jsxs("div", {
                className: "flex items-center justify-between",
                children: [
                  t.jsx(fe, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                    children: "Restore Backup"
                  }),
                  t.jsx("button", {
                    onClick: s,
                    disabled: o,
                    "aria-label": "Close",
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: t.jsx(Q, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              a && t.jsxs("div", {
                className: "mt-3 space-y-3",
                children: [
                  t.jsxs("p", {
                    className: "text-xs text-gray-500 dark:text-slate-400",
                    children: [
                      "Backup from ",
                      new Date(a.exportedAt).toLocaleDateString(),
                      a.extensionVersion && ` (v${a.extensionVersion})`
                    ]
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx("label", {
                        className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5 block",
                        children: "Select data to restore:"
                      }),
                      t.jsx("div", {
                        className: "space-y-1.5",
                        children: r.map((i) => t.jsxs("label", {
                          className: "flex items-center gap-2 cursor-pointer",
                          children: [
                            t.jsx("input", {
                              type: "checkbox",
                              checked: l[i.key] || false,
                              onChange: (p) => f((h) => ({
                                ...h,
                                [i.key]: p.target.checked
                              })),
                              disabled: o,
                              className: "rounded border-gray-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                            }),
                            t.jsx("span", {
                              className: "text-xs text-gray-700 dark:text-slate-300",
                              children: i.label
                            }),
                            t.jsxs("span", {
                              className: "text-xs text-gray-400 dark:text-slate-500",
                              children: [
                                "(",
                                i.countLabel,
                                ")"
                              ]
                            })
                          ]
                        }, i.key))
                      })
                    ]
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx("label", {
                        className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5 block",
                        children: "Restore mode:"
                      }),
                      t.jsxs("div", {
                        className: "space-y-1",
                        children: [
                          t.jsxs("label", {
                            className: "flex items-center gap-2 cursor-pointer",
                            children: [
                              t.jsx("input", {
                                type: "radio",
                                name: "restoreMode",
                                value: "replace",
                                checked: d === "replace",
                                onChange: () => b("replace"),
                                disabled: o,
                                className: "border-gray-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                              }),
                              t.jsx("span", {
                                className: "text-xs text-gray-700 dark:text-slate-300",
                                children: "Replace existing data"
                              })
                            ]
                          }),
                          t.jsxs("label", {
                            className: "flex items-center gap-2 cursor-pointer",
                            children: [
                              t.jsx("input", {
                                type: "radio",
                                name: "restoreMode",
                                value: "merge",
                                checked: d === "merge",
                                onChange: () => b("merge"),
                                disabled: o,
                                className: "border-gray-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                              }),
                              t.jsx("span", {
                                className: "text-xs text-gray-700 dark:text-slate-300",
                                children: "Merge with existing data"
                              })
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  d === "replace" && t.jsx("div", {
                    className: "bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded p-2",
                    children: t.jsx("p", {
                      className: "text-xs text-amber-700 dark:text-amber-200",
                      children: "Replace mode will overwrite your current data for selected categories."
                    })
                  })
                ]
              }),
              t.jsxs("div", {
                className: "mt-4 flex justify-end gap-2",
                children: [
                  t.jsx("button", {
                    onClick: s,
                    disabled: o,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  t.jsx("button", {
                    onClick: m,
                    disabled: o || u === 0,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
                    children: o ? "Restoring..." : "Restore"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  const Te = (e) => {
    if (!e)
      return null;
    const s = Date.now() - new Date(e).getTime(), a = Math.floor(s / 6e4);
    if (a < 1)
      return "Just now";
    if (a < 60)
      return `${a}m ago`;
    const r = Math.floor(a / 60);
    if (r < 24)
      return `${r}h ago`;
    const n = Math.floor(r / 24);
    return n === 1 ? "Yesterday" : n < 30 ? `${n} days ago` : new Date(e).toLocaleDateString();
  };
  _e = function() {
    const [, e] = X(), s = y.useRef(null), [a, r] = y.useState(false), [n, o] = y.useState(false), [l, f] = y.useState(null), [d, b] = y.useState({}), [u, m] = y.useState(Object.fromEntries(T.map((c) => [
      c.key,
      true
    ]))), [i, p] = y.useState(false), [h, C] = y.useState(null), [$, G] = y.useState([]);
    y.useEffect(() => {
      L(), K();
    }, []);
    const L = async () => {
      const c = {};
      for (const g of T)
        try {
          c[g.key] = await g.countFn();
        } catch {
          c[g.key] = 0;
        }
      b(c);
    }, K = async () => {
      try {
        const c = await x.get(R);
        c && f(c);
      } catch {
      }
    }, V = Object.values(u).filter(Boolean).length, J = async () => {
      const c = Object.entries(u).filter(([, g]) => g).map(([g]) => g);
      if (c.length !== 0) {
        r(true);
        try {
          const g = await ke(c), j = new Blob([
            JSON.stringify(g, null, 2)
          ], {
            type: "application/json"
          }), I = URL.createObjectURL(j), w = document.createElement("a");
          w.href = I, w.download = `nlmtools-backup-${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`, document.body.appendChild(w), w.click(), document.body.removeChild(w), URL.revokeObjectURL(I);
          const E = (/* @__PURE__ */ new Date()).toISOString();
          await x.set(R, E), f(E), k.success("Backup created"), B(() => e.isLicensed());
        } catch (g) {
          k.error(`Failed to create backup: ${g.message}`);
        } finally {
          r(false);
        }
      }
    }, H = () => {
      var _a;
      (_a = s.current) == null ? void 0 : _a.click();
    }, W = async (c) => {
      var _a;
      const g = (_a = c.target.files) == null ? void 0 : _a[0];
      if (s.current && (s.current.value = ""), !g)
        return;
      if (g.size > ye) {
        k.error("File too large (max 10MB)");
        return;
      }
      if (!g.name.endsWith(".json")) {
        k.error("Please select a JSON file");
        return;
      }
      const j = new FileReader();
      j.onerror = () => k.error("Failed to read file"), j.onload = (I) => {
        try {
          const w = JSON.parse(I.target.result), E = je(w);
          if (!E.valid) {
            k.error(E.error);
            return;
          }
          const F = we(w);
          if (F.length === 0) {
            k.error("Backup file contains no data");
            return;
          }
          C(w), G(F), p(true);
        } catch {
          k.error("Invalid JSON file");
        }
      }, j.readAsText(g);
    }, z = async (c, g) => {
      if (c.length !== 0) {
        o(true);
        try {
          await Ne(h, c, g), c.includes("tags") && await e.loadTags(), c.includes("sourceFolders") && await e.loadSourceFolders(), c.includes("prompts") && (await e.loadPrompts(), await e.loadUsageData()), c.includes("preferences") && await Promise.all([
            e.loadThemeMode(),
            e.loadAllLanguagePreferences()
          ]), p(false), C(null), k.success(`Restored ${c.length} categor${c.length !== 1 ? "ies" : "y"}`), B(() => e.isLicensed()), await L();
        } catch (j) {
          k.error(`Failed to restore: ${j.message}`);
        } finally {
          o(false);
        }
      }
    };
    return t.jsxs(t.Fragment, {
      children: [
        t.jsx("div", {
          className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
          children: t.jsxs("div", {
            className: "p-3",
            children: [
              t.jsxs("div", {
                className: "flex items-center gap-1.5 mb-2",
                children: [
                  t.jsx(pe, {
                    className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
                  }),
                  t.jsx("h2", {
                    className: "font-medium text-gray-900 dark:text-slate-100",
                    children: "Backup & Restore"
                  })
                ]
              }),
              t.jsx("p", {
                className: "text-xs text-gray-500 dark:text-slate-400 mb-3",
                children: "Back up your data to transfer between profiles or keep a safety copy."
              }),
              l && t.jsxs("p", {
                className: "text-xs text-gray-400 dark:text-slate-500 mb-3",
                children: [
                  "Last backup: ",
                  Te(l)
                ]
              }),
              t.jsx("div", {
                className: "mb-3",
                children: t.jsx(me, {})
              }),
              t.jsxs("div", {
                className: "mb-3",
                children: [
                  t.jsx("label", {
                    className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5 block",
                    children: "Export Selections:"
                  }),
                  t.jsx("div", {
                    className: "space-y-1.5",
                    children: T.map((c) => t.jsxs("label", {
                      className: "flex items-center gap-2 cursor-pointer",
                      children: [
                        t.jsx("input", {
                          type: "checkbox",
                          checked: u[c.key],
                          onChange: (g) => m((j) => ({
                            ...j,
                            [c.key]: g.target.checked
                          })),
                          className: "rounded border-gray-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                        }),
                        t.jsx("span", {
                          className: "text-xs text-gray-700 dark:text-slate-300",
                          children: c.label
                        }),
                        t.jsxs("span", {
                          className: "text-xs text-gray-400 dark:text-slate-500",
                          children: [
                            "(",
                            d[c.key] !== void 0 ? c.countLabel(d[c.key]) : "...",
                            ")"
                          ]
                        })
                      ]
                    }, c.key))
                  })
                ]
              }),
              t.jsxs("div", {
                className: "flex gap-2",
                children: [
                  t.jsxs("button", {
                    onClick: J,
                    disabled: a || V === 0,
                    className: "flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
                    children: [
                      t.jsx(xe, {
                        className: "w-3.5 h-3.5"
                      }),
                      a ? "Creating..." : "Create Backup"
                    ]
                  }),
                  t.jsxs("button", {
                    onClick: H,
                    disabled: n,
                    className: "flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: [
                      t.jsx(be, {
                        className: "w-3.5 h-3.5"
                      }),
                      "Restore from Backup"
                    ]
                  })
                ]
              }),
              t.jsx("input", {
                ref: s,
                type: "file",
                accept: ".json",
                onChange: W,
                className: "hidden"
              })
            ]
          })
        }),
        t.jsx(Oe, {
          open: i,
          onClose: () => {
            p(false), C(null);
          },
          pendingBackup: h,
          availableCategories: $,
          onRestore: z,
          isRestoring: n
        })
      ]
    });
  };
});
export {
  _e as B,
  __tla
};
