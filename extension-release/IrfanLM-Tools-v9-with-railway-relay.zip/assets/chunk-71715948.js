import { u as N, r as n, j as e, e as o, h as y, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { N as v, b as m, d as h, C as w, e as p, K as A, S, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { aD as u, s as K, r as L } from "./chunk-68adfa56.js";
import { f as C } from "./chunk-10b7446f.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let U;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  U = function() {
    var _a, _b, _c;
    const [f, l] = N(), { isActivating: t, error: a, me: d } = f.auth, c = ((_a = d == null ? void 0 : d.licenseKey) == null ? void 0 : _a.customer) || {}, j = (_b = d == null ? void 0 : d.licenseKey) == null ? void 0 : _b.displayKey, i = (_c = d == null ? void 0 : d.licenseKey) == null ? void 0 : _c.expiresAt, [r, b] = n.useState(""), [x, k] = n.useState("form");
    if (l.isLicensed() && x === "form")
      return e.jsx(v, {
        to: "/profile",
        replace: true
      });
    const g = async (s) => {
      if (s.preventDefault(), !r.trim())
        return;
      await l.activateLicenseKey(r.trim()) && k("success");
    };
    return x === "success" ? e.jsxs(m, {
      children: [
        e.jsx(h, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "License Activated"
          })
        }),
        e.jsxs("div", {
          className: "max-w-sm mx-auto px-4 py-6 space-y-4",
          children: [
            e.jsxs("div", {
              className: "rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 space-y-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-1.5",
                  children: [
                    e.jsx(w, {
                      className: "w-4 h-4 text-emerald-600 dark:text-emerald-400"
                    }),
                    e.jsx("span", {
                      className: "text-xs font-semibold text-emerald-900 dark:text-emerald-100",
                      children: "License Activated"
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "text-xs text-slate-700 dark:text-slate-300",
                  children: "You're one of the people keeping this tool alive. Thank you \u2014 it genuinely means a lot. \u2014 Trung"
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2.5",
                  children: [
                    e.jsx("div", {
                      className: "w-8 h-8 rounded-full bg-emerald-200 dark:bg-emerald-800 flex items-center justify-center text-xs font-semibold text-emerald-700 dark:text-emerald-300",
                      children: c.email ? c.email[0].toUpperCase() : "?"
                    }),
                    e.jsx("span", {
                      className: "text-xs text-slate-700 dark:text-slate-300 truncate",
                      children: c.email || "No email"
                    })
                  ]
                }),
                e.jsxs("dl", {
                  className: "space-y-1.5 text-xs",
                  children: [
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("dt", {
                          className: "text-slate-500 dark:text-slate-400",
                          children: "Key"
                        }),
                        e.jsx("dd", {
                          className: "text-slate-700 dark:text-slate-300 font-mono",
                          children: j || "****"
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("dt", {
                          className: "text-slate-500 dark:text-slate-400",
                          children: "Valid until"
                        }),
                        e.jsx("dd", {
                          className: "text-slate-700 dark:text-slate-300",
                          children: i ? C(i) : "Never"
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 space-y-3",
              children: [
                e.jsx("span", {
                  className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
                  children: "What you unlocked"
                }),
                e.jsx("ul", {
                  className: "space-y-1.5",
                  children: u.map((s) => e.jsxs("li", {
                    className: "flex items-center gap-1.5",
                    children: [
                      e.jsx(p, {
                        className: "w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0"
                      }),
                      e.jsx("span", {
                        className: "text-xs text-slate-700 dark:text-slate-300",
                        children: s
                      })
                    ]
                  }, s))
                })
              ]
            }),
            e.jsx("a", {
              href: "#/profile",
              className: "flex items-center justify-center w-full px-3 py-2 text-xs font-medium text-white bg-emerald-600 rounded-md hover:bg-emerald-700",
              children: "View Your Profile"
            })
          ]
        })
      ]
    }) : e.jsxs(m, {
      children: [
        e.jsx(h, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "Activate License"
          })
        }),
        e.jsxs("div", {
          className: "max-w-sm mx-auto px-4 py-3 space-y-3",
          children: [
            e.jsxs("div", {
              className: "text-center",
              children: [
                e.jsx("h1", {
                  className: "text-sm font-bold text-slate-900 dark:text-slate-100",
                  children: "Activate your license"
                }),
                e.jsx("p", {
                  className: "text-xs text-slate-500 dark:text-slate-400",
                  children: "Support development and unlock a few extras"
                })
              ]
            }),
            e.jsxs("div", {
              className: "rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 space-y-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-1.5",
                  children: [
                    e.jsx(A, {
                      className: "w-4 h-4 text-slate-500 dark:text-slate-400"
                    }),
                    e.jsx("span", {
                      className: "text-xs font-semibold text-slate-900 dark:text-slate-100",
                      children: "Get licensed"
                    })
                  ]
                }),
                e.jsx("ul", {
                  className: "space-y-0.5",
                  children: u.map((s) => e.jsxs("li", {
                    className: "flex items-center gap-1.5",
                    children: [
                      e.jsx(p, {
                        className: "w-3.5 h-3.5 text-emerald-500 shrink-0"
                      }),
                      e.jsx("span", {
                        className: "text-xs text-slate-700 dark:text-slate-300",
                        children: s
                      })
                    ]
                  }, s))
                }),
                e.jsxs("a", {
                  href: K("activate-page"),
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "flex items-center justify-center gap-1 w-full px-3 py-2 text-xs font-medium text-white bg-slate-700 dark:bg-slate-600 rounded-md hover:bg-slate-800 dark:hover:bg-slate-500",
                  children: [
                    "Buy a license",
                    e.jsx(o, {
                      className: "w-3 h-3"
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "border-t border-slate-200 dark:border-slate-700"
                }),
                e.jsxs("div", {
                  className: "space-y-1.5",
                  children: [
                    e.jsx("span", {
                      className: "block text-xs font-semibold text-slate-700 dark:text-slate-300",
                      children: "Already have a key?"
                    }),
                    e.jsxs("form", {
                      onSubmit: g,
                      className: "flex gap-2",
                      children: [
                        e.jsx("input", {
                          type: "text",
                          value: r,
                          onChange: (s) => {
                            b(s.target.value), l.clearAuthError();
                          },
                          disabled: t,
                          autoFocus: true,
                          "aria-invalid": !!a,
                          placeholder: "Paste your license key...",
                          className: `flex-1 px-3 py-2 text-xs rounded-md border bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 disabled:opacity-50 ${a ? "border-red-300 dark:border-red-700 focus:border-red-500 focus:ring-red-500" : "border-slate-300 dark:border-slate-600 focus:border-emerald-500 focus:ring-emerald-500"}`
                        }),
                        e.jsxs("button", {
                          type: "submit",
                          disabled: t || !r.trim(),
                          className: "shrink-0 inline-flex items-center gap-1 px-3 py-2 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/40 rounded-md hover:bg-emerald-200 dark:hover:bg-emerald-800/40 disabled:opacity-50 disabled:cursor-not-allowed",
                          children: [
                            t && e.jsx(y, {
                              className: "w-3 h-3 animate-spin"
                            }),
                            t ? "Activating..." : "Activate"
                          ]
                        })
                      ]
                    }),
                    a && e.jsx(S, {
                      type: "error",
                      message: a
                    })
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "text-center space-y-1",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-center gap-2 text-xs",
                  children: [
                    e.jsxs("a", {
                      href: L,
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className: "inline-flex items-center gap-0.5 text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300",
                      children: [
                        "Manage license",
                        e.jsx(o, {
                          className: "w-3 h-3"
                        })
                      ]
                    }),
                    e.jsx("span", {
                      className: "text-slate-300 dark:text-slate-600",
                      children: "|"
                    }),
                    e.jsx("a", {
                      href: "#/",
                      className: "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300",
                      children: "Skip for now"
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "text-xs text-slate-400 dark:text-slate-500",
                  children: "All features work without a license"
                })
              ]
            })
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  U as default
};
