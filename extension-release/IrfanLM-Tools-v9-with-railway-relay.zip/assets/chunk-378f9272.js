function m(t) {
  try {
    return new URL(t).hostname.replace("www.", "");
  } catch {
    return t;
  }
}
const u = () => (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
function h(t) {
  if (!t)
    return "";
  const e = Date.now(), c = new Date(t).getTime(), f = e - c, a = Math.floor(f / 1e3), n = Math.floor(a / 60), r = Math.floor(n / 60), o = Math.floor(r / 24), s = Math.floor(o / 7), i = Math.floor(o / 30);
  return a < 60 ? "just now" : n < 60 ? `${n}m ago` : r < 24 ? `${r}h ago` : o < 7 ? `${o}d ago` : s < 5 ? `${s}w ago` : i < 12 ? `${i}mo ago` : new Date(t).toLocaleDateString(void 0, { year: "numeric", month: "short", day: "numeric" });
}
export {
  m as g,
  h as r,
  u as t
};
