import { j as De, __tla as __tla_0 } from "./chunk-b41980cc.js";
let T4, A4;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  A4 = function({ value: r, max: e, color: t = "bg-blue-500", height: a = "h-1", className: n = "" }) {
    const l = e > 0 ? Math.min(r / e * 100, 100) : 0;
    return De.jsx("div", {
      className: `bg-gray-200 dark:bg-slate-700 rounded-full ${a} ${n}`,
      children: De.jsx("div", {
        className: `${t} ${a} rounded-full`,
        style: {
          width: `${l}%`
        }
      })
    });
  };
  class k extends Error {
    constructor(e, t) {
      var a = "KaTeX parse error: " + e, n, l, u = t && t.loc;
      if (u && u.start <= u.end) {
        var h = u.lexer.input;
        n = u.start, l = u.end, n === h.length ? a += " at end of input: " : a += " at position " + (n + 1) + ": ";
        var c = h.slice(n, l).replace(/[^]/g, "$&\u0332"), p;
        n > 15 ? p = "\u2026" + h.slice(n - 15, n) : p = h.slice(0, n);
        var g;
        l + 15 < h.length ? g = h.slice(l, l + 15) + "\u2026" : g = h.slice(l), a += p + c + g;
      }
      super(a), this.name = "ParseError", Object.setPrototypeOf(this, k.prototype), this.position = n, n != null && l != null && (this.length = l - n), this.rawMessage = e;
    }
  }
  var I1 = /([A-Z])/g, Mt = (r) => r.replace(I1, "-$1").toLowerCase(), N1 = {
    "&": "&amp;",
    ">": "&gt;",
    "<": "&lt;",
    '"': "&quot;",
    "'": "&#x27;"
  }, H1 = /[&><"']/g, a0 = (r) => String(r).replace(H1, (e) => N1[e]), Te = (r) => r.type === "ordgroup" || r.type === "color" ? r.body.length === 1 ? Te(r.body[0]) : r : r.type === "font" ? Te(r.body) : r, O1 = /* @__PURE__ */ new Set([
    "mathord",
    "textord",
    "atom"
  ]), D0 = (r) => O1.has(Te(r).type), F1 = (r) => {
    var e = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(r);
    return e ? e[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(e[1]) ? null : e[1].toLowerCase() : "_relative";
  }, mt = {
    displayMode: {
      type: "boolean",
      description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
      cli: "-d, --display-mode"
    },
    output: {
      type: {
        enum: [
          "htmlAndMathml",
          "html",
          "mathml"
        ]
      },
      description: "Determines the markup language of the output.",
      cli: "-F, --format <type>"
    },
    leqno: {
      type: "boolean",
      description: "Render display math in leqno style (left-justified tags)."
    },
    fleqn: {
      type: "boolean",
      description: "Render display math flush left."
    },
    throwOnError: {
      type: "boolean",
      default: true,
      cli: "-t, --no-throw-on-error",
      cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
    },
    errorColor: {
      type: "string",
      default: "#cc0000",
      cli: "-c, --error-color <color>",
      cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
      cliProcessor: (r) => "#" + r
    },
    macros: {
      type: "object",
      cli: "-m, --macro <def>",
      cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
      cliDefault: [],
      cliProcessor: (r, e) => (e.push(r), e)
    },
    minRuleThickness: {
      type: "number",
      description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
      processor: (r) => Math.max(0, r),
      cli: "--min-rule-thickness <size>",
      cliProcessor: parseFloat
    },
    colorIsTextColor: {
      type: "boolean",
      description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
      cli: "-b, --color-is-text-color"
    },
    strict: {
      type: [
        {
          enum: [
            "warn",
            "ignore",
            "error"
          ]
        },
        "boolean",
        "function"
      ],
      description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
      cli: "-S, --strict",
      cliDefault: false
    },
    trust: {
      type: [
        "boolean",
        "function"
      ],
      description: "Trust the input, enabling all HTML features such as \\url.",
      cli: "-T, --trust"
    },
    maxSize: {
      type: "number",
      default: 1 / 0,
      description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
      processor: (r) => Math.max(0, r),
      cli: "-s, --max-size <n>",
      cliProcessor: parseInt
    },
    maxExpand: {
      type: "number",
      default: 1e3,
      description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
      processor: (r) => Math.max(0, r),
      cli: "-e, --max-expand <n>",
      cliProcessor: (r) => r === "Infinity" ? 1 / 0 : parseInt(r)
    },
    globalGroup: {
      type: "boolean",
      cli: false
    }
  };
  function L1(r) {
    if ("default" in r)
      return r.default;
    var e = r.type, t = Array.isArray(e) ? e[0] : e;
    if (typeof t != "string")
      return t.enum[0];
    switch (t) {
      case "boolean":
        return false;
      case "string":
        return "";
      case "number":
        return 0;
      case "object":
        return {};
    }
  }
  class At {
    constructor(e) {
      e === void 0 && (e = {}), e = e || {};
      for (var t of Object.keys(mt)) {
        var a = mt[t], n = e[t];
        this[t] = n !== void 0 ? a.processor ? a.processor(n) : n : L1(a);
      }
    }
    reportNonstrict(e, t, a) {
      var n = this.strict;
      if (typeof n == "function" && (n = n(e, t, a)), !(!n || n === "ignore")) {
        if (n === true || n === "error")
          throw new k("LaTeX-incompatible input and strict mode is set to 'error': " + (t + " [" + e + "]"), a);
        n === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + n + "': " + t + " [" + e + "]"));
      }
    }
    useStrictBehavior(e, t, a) {
      var n = this.strict;
      if (typeof n == "function")
        try {
          n = n(e, t, a);
        } catch {
          n = "error";
        }
      return !n || n === "ignore" ? false : n === true || n === "error" ? true : n === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")), false) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + n + "': " + t + " [" + e + "]")), false);
    }
    isTrusted(e) {
      if ("url" in e && e.url && !e.protocol) {
        var t = F1(e.url);
        if (t == null)
          return false;
        e.protocol = t;
      }
      var a = typeof this.trust == "function" ? this.trust(e) : this.trust;
      return !!a;
    }
  }
  class N0 {
    constructor(e, t, a) {
      this.id = e, this.size = t, this.cramped = a;
    }
    sup() {
      return x0[P1[this.id]];
    }
    sub() {
      return x0[G1[this.id]];
    }
    fracNum() {
      return x0[U1[this.id]];
    }
    fracDen() {
      return x0[V1[this.id]];
    }
    cramp() {
      return x0[$1[this.id]];
    }
    text() {
      return x0[W1[this.id]];
    }
    isTight() {
      return this.size >= 2;
    }
  }
  var Tt = 0, Ce = 1, Q0 = 2, T0 = 3, oe = 4, v0 = 5, _0 = 6, s0 = 7, x0 = [
    new N0(Tt, 0, false),
    new N0(Ce, 0, true),
    new N0(Q0, 1, false),
    new N0(T0, 1, true),
    new N0(oe, 2, false),
    new N0(v0, 2, true),
    new N0(_0, 3, false),
    new N0(s0, 3, true)
  ], P1 = [
    oe,
    v0,
    oe,
    v0,
    _0,
    s0,
    _0,
    s0
  ], G1 = [
    v0,
    v0,
    v0,
    v0,
    s0,
    s0,
    s0,
    s0
  ], U1 = [
    Q0,
    T0,
    oe,
    v0,
    _0,
    s0,
    _0,
    s0
  ], V1 = [
    T0,
    T0,
    v0,
    v0,
    s0,
    s0,
    s0,
    s0
  ], $1 = [
    Ce,
    Ce,
    T0,
    T0,
    v0,
    v0,
    s0,
    s0
  ], W1 = [
    Tt,
    Ce,
    Q0,
    T0,
    Q0,
    T0,
    Q0,
    T0
  ], N = {
    DISPLAY: x0[Tt],
    TEXT: x0[Q0],
    SCRIPT: x0[oe],
    SCRIPTSCRIPT: x0[_0]
  }, ct = [
    {
      name: "latin",
      blocks: [
        [
          256,
          591
        ],
        [
          768,
          879
        ]
      ]
    },
    {
      name: "cyrillic",
      blocks: [
        [
          1024,
          1279
        ]
      ]
    },
    {
      name: "armenian",
      blocks: [
        [
          1328,
          1423
        ]
      ]
    },
    {
      name: "brahmic",
      blocks: [
        [
          2304,
          4255
        ]
      ]
    },
    {
      name: "georgian",
      blocks: [
        [
          4256,
          4351
        ]
      ]
    },
    {
      name: "cjk",
      blocks: [
        [
          12288,
          12543
        ],
        [
          19968,
          40879
        ],
        [
          65280,
          65376
        ]
      ]
    },
    {
      name: "hangul",
      blocks: [
        [
          44032,
          55215
        ]
      ]
    }
  ];
  function X1(r) {
    for (var e = 0; e < ct.length; e++)
      for (var t = ct[e], a = 0; a < t.blocks.length; a++) {
        var n = t.blocks[a];
        if (r >= n[0] && r <= n[1])
          return t.name;
      }
    return null;
  }
  var Be = [];
  ct.forEach((r) => r.blocks.forEach((e) => Be.push(...e)));
  function Cr(r) {
    for (var e = 0; e < Be.length; e += 2)
      if (r >= Be[e] && r <= Be[e + 1])
        return true;
    return false;
  }
  var J0 = 80, Y1 = function(e, t) {
    return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
  }, j1 = function(e, t) {
    return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
  }, Z1 = function(e, t) {
    return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
  }, K1 = function(e, t) {
    return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
  }, J1 = function(e, t) {
    return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
  }, Q1 = function(e) {
    var t = e / 2;
    return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
  }, _1 = function(e, t, a) {
    var n = a - 54 - t - e;
    return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + n + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
  }, ea = function(e, t, a) {
    t = 1e3 * t;
    var n = "";
    switch (e) {
      case "sqrtMain":
        n = Y1(t, J0);
        break;
      case "sqrtSize1":
        n = j1(t, J0);
        break;
      case "sqrtSize2":
        n = Z1(t, J0);
        break;
      case "sqrtSize3":
        n = K1(t, J0);
        break;
      case "sqrtSize4":
        n = J1(t, J0);
        break;
      case "sqrtTall":
        n = _1(t, J0, a);
    }
    return n;
  }, ta = function(e, t) {
    switch (e) {
      case "\u239C":
        return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
      case "\u2223":
        return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
      case "\u2225":
        return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
      case "\u239F":
        return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
      case "\u23A2":
        return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
      case "\u23A5":
        return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
      case "\u23AA":
        return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
      case "\u23D0":
        return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
      case "\u2016":
        return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
      default:
        return "";
    }
  }, Qt = {
    doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
    doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
    leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
    leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
    leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
    leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
    leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
    leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
    leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
    leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
    leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
    lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
    leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
    leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
    leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
    longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
    midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
    midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
    oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
    oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
    oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
    oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
    rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
    rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
    rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
    rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
    rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
    rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
    rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
    rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
    rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
    righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
    rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
    rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
    twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
    twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
    tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
    tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
    tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
    tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
    vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
    widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
    widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
    widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
    widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
    widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
    widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
    widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
    widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
    baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
    rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
    baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
    rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
    shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
    shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
  }, ra = function(e, t) {
    switch (e) {
      case "lbrack":
        return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
      case "rbrack":
        return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
      case "vert":
        return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
      case "doublevert":
        return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
      case "lfloor":
        return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
      case "rfloor":
        return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
      case "lceil":
        return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
      case "rceil":
        return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
      case "lparen":
        return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
      case "rparen":
        return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
      default:
        throw new Error("Unknown stretchy delimiter.");
    }
  };
  class re {
    constructor(e) {
      this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
    }
    hasClass(e) {
      return this.classes.includes(e);
    }
    toNode() {
      for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
        e.appendChild(this.children[t].toNode());
      return e;
    }
    toMarkup() {
      for (var e = "", t = 0; t < this.children.length; t++)
        e += this.children[t].toMarkup();
      return e;
    }
    toText() {
      var e = (t) => t.toText();
      return this.children.map(e).join("");
    }
  }
  var dt = {
    pt: 1,
    mm: 7227 / 2540,
    cm: 7227 / 254,
    in: 72.27,
    bp: 803 / 800,
    pc: 12,
    dd: 1238 / 1157,
    cc: 14856 / 1157,
    nd: 685 / 642,
    nc: 1370 / 107,
    sp: 1 / 65536,
    px: 803 / 800
  }, aa = {
    ex: true,
    em: true,
    mu: true
  }, qr = function(e) {
    return typeof e != "string" && (e = e.unit), e in dt || e in aa || e === "ex";
  }, K = function(e, t) {
    var a;
    if (e.unit in dt)
      a = dt[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
    else if (e.unit === "mu")
      a = t.fontMetrics().cssEmPerMu;
    else {
      var n;
      if (t.style.isTight() ? n = t.havingStyle(t.style.text()) : n = t, e.unit === "ex")
        a = n.fontMetrics().xHeight;
      else if (e.unit === "em")
        a = n.fontMetrics().quad;
      else
        throw new k("Invalid unit: '" + e.unit + "'");
      n !== t && (a *= n.sizeMultiplier / t.sizeMultiplier);
    }
    return Math.min(e.number * a, t.maxSize);
  }, M = function(e) {
    return +e.toFixed(4) + "em";
  }, F0 = function(e) {
    return e.filter((t) => t).join(" ");
  }, Er = function(e, t, a) {
    if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a || {}, t) {
      t.style.isTight() && this.classes.push("mtight");
      var n = t.getColor();
      n && (this.style.color = n);
    }
  }, Rr = function(e) {
    var t = document.createElement(e);
    t.className = F0(this.classes);
    for (var a of Object.keys(this.style))
      t.style[a] = this.style[a];
    for (var n of Object.keys(this.attributes))
      t.setAttribute(n, this.attributes[n]);
    for (var l = 0; l < this.children.length; l++)
      t.appendChild(this.children[l].toNode());
    return t;
  }, na = /[\s"'>/=\x00-\x1f]/, Ir = function(e) {
    var t = "<" + e;
    this.classes.length && (t += ' class="' + a0(F0(this.classes)) + '"');
    var a = "";
    for (var n of Object.keys(this.style))
      a += Mt(n) + ":" + this.style[n] + ";";
    a && (t += ' style="' + a0(a) + '"');
    for (var l of Object.keys(this.attributes)) {
      if (na.test(l))
        throw new k("Invalid attribute name '" + l + "'");
      t += " " + l + '="' + a0(this.attributes[l]) + '"';
    }
    t += ">";
    for (var u = 0; u < this.children.length; u++)
      t += this.children[u].toMarkup();
    return t += "</" + e + ">", t;
  };
  class ae {
    constructor(e, t, a, n) {
      Er.call(this, e, a, n), this.children = t || [];
    }
    setAttribute(e, t) {
      this.attributes[e] = t;
    }
    hasClass(e) {
      return this.classes.includes(e);
    }
    toNode() {
      return Rr.call(this, "span");
    }
    toMarkup() {
      return Ir.call(this, "span");
    }
  }
  class Ne {
    constructor(e, t, a, n) {
      Er.call(this, t, n), this.children = a || [], this.setAttribute("href", e);
    }
    setAttribute(e, t) {
      this.attributes[e] = t;
    }
    hasClass(e) {
      return this.classes.includes(e);
    }
    toNode() {
      return Rr.call(this, "a");
    }
    toMarkup() {
      return Ir.call(this, "a");
    }
  }
  class ia {
    constructor(e, t, a) {
      this.alt = t, this.src = e, this.classes = [
        "mord"
      ], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a;
    }
    hasClass(e) {
      return this.classes.includes(e);
    }
    toNode() {
      var e = document.createElement("img");
      e.src = this.src, e.alt = this.alt, e.className = "mord";
      for (var t of Object.keys(this.style))
        e.style[t] = this.style[t];
      return e;
    }
    toMarkup() {
      var e = '<img src="' + a0(this.src) + '"' + (' alt="' + a0(this.alt) + '"'), t = "";
      for (var a of Object.keys(this.style))
        t += Mt(a) + ":" + this.style[a] + ";";
      return t && (e += ' style="' + a0(t) + '"'), e += "'/>", e;
    }
  }
  var la = {
    \u00EE: "\u0131\u0302",
    \u00EF: "\u0131\u0308",
    \u00ED: "\u0131\u0301",
    \u00EC: "\u0131\u0300"
  };
  class d0 {
    constructor(e, t, a, n, l, u, h, c) {
      this.text = e, this.height = t || 0, this.depth = a || 0, this.italic = n || 0, this.skew = l || 0, this.width = u || 0, this.classes = h || [], this.style = c || {}, this.maxFontSize = 0;
      var p = X1(this.text.charCodeAt(0));
      p && this.classes.push(p + "_fallback"), /[îïíì]/.test(this.text) && (this.text = la[this.text]);
    }
    hasClass(e) {
      return this.classes.includes(e);
    }
    toNode() {
      var e = document.createTextNode(this.text), t = null;
      this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = M(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = F0(this.classes));
      for (var a of Object.keys(this.style))
        t = t || document.createElement("span"), t.style[a] = this.style[a];
      return t ? (t.appendChild(e), t) : e;
    }
    toMarkup() {
      var e = false, t = "<span";
      this.classes.length && (e = true, t += ' class="', t += a0(F0(this.classes)), t += '"');
      var a = "";
      this.italic > 0 && (a += "margin-right:" + this.italic + "em;");
      for (var n of Object.keys(this.style))
        a += Mt(n) + ":" + this.style[n] + ";";
      a && (e = true, t += ' style="' + a0(a) + '"');
      var l = a0(this.text);
      return e ? (t += ">", t += l, t += "</span>", t) : l;
    }
  }
  class B0 {
    constructor(e, t) {
      this.children = e || [], this.attributes = t || {};
    }
    toNode() {
      var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
      for (var a of Object.keys(this.attributes))
        t.setAttribute(a, this.attributes[a]);
      for (var n = 0; n < this.children.length; n++)
        t.appendChild(this.children[n].toNode());
      return t;
    }
    toMarkup() {
      var e = '<svg xmlns="http://www.w3.org/2000/svg"';
      for (var t of Object.keys(this.attributes))
        e += " " + t + '="' + a0(this.attributes[t]) + '"';
      e += ">";
      for (var a = 0; a < this.children.length; a++)
        e += this.children[a].toMarkup();
      return e += "</svg>", e;
    }
  }
  class L0 {
    constructor(e, t) {
      this.pathName = e, this.alternate = t;
    }
    toNode() {
      var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
      return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", Qt[this.pathName]), t;
    }
    toMarkup() {
      return this.alternate ? '<path d="' + a0(this.alternate) + '"/>' : '<path d="' + a0(Qt[this.pathName]) + '"/>';
    }
  }
  class ft {
    constructor(e) {
      this.attributes = e || {};
    }
    toNode() {
      var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
      for (var a of Object.keys(this.attributes))
        t.setAttribute(a, this.attributes[a]);
      return t;
    }
    toMarkup() {
      var e = "<line";
      for (var t of Object.keys(this.attributes))
        e += " " + t + '="' + a0(this.attributes[t]) + '"';
      return e += "/>", e;
    }
  }
  function sa(r) {
    if (r instanceof d0)
      return r;
    throw new Error("Expected symbolNode but got " + String(r) + ".");
  }
  function ua(r) {
    if (r instanceof ae)
      return r;
    throw new Error("Expected span<HtmlDomNode> but got " + String(r) + ".");
  }
  var oa = (r) => r instanceof ae || r instanceof Ne || r instanceof re, w0 = {
    "AMS-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      65: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      66: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      67: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      68: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      69: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      70: [
        0,
        0.68889,
        0,
        0,
        0.61111
      ],
      71: [
        0,
        0.68889,
        0,
        0,
        0.77778
      ],
      72: [
        0,
        0.68889,
        0,
        0,
        0.77778
      ],
      73: [
        0,
        0.68889,
        0,
        0,
        0.38889
      ],
      74: [
        0.16667,
        0.68889,
        0,
        0,
        0.5
      ],
      75: [
        0,
        0.68889,
        0,
        0,
        0.77778
      ],
      76: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      77: [
        0,
        0.68889,
        0,
        0,
        0.94445
      ],
      78: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      79: [
        0.16667,
        0.68889,
        0,
        0,
        0.77778
      ],
      80: [
        0,
        0.68889,
        0,
        0,
        0.61111
      ],
      81: [
        0.16667,
        0.68889,
        0,
        0,
        0.77778
      ],
      82: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      83: [
        0,
        0.68889,
        0,
        0,
        0.55556
      ],
      84: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      85: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      86: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      87: [
        0,
        0.68889,
        0,
        0,
        1
      ],
      88: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      89: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      90: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      107: [
        0,
        0.68889,
        0,
        0,
        0.55556
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      165: [
        0,
        0.675,
        0.025,
        0,
        0.75
      ],
      174: [
        0.15559,
        0.69224,
        0,
        0,
        0.94666
      ],
      240: [
        0,
        0.68889,
        0,
        0,
        0.55556
      ],
      295: [
        0,
        0.68889,
        0,
        0,
        0.54028
      ],
      710: [
        0,
        0.825,
        0,
        0,
        2.33334
      ],
      732: [
        0,
        0.9,
        0,
        0,
        2.33334
      ],
      770: [
        0,
        0.825,
        0,
        0,
        2.33334
      ],
      771: [
        0,
        0.9,
        0,
        0,
        2.33334
      ],
      989: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      1008: [
        0,
        0.43056,
        0.04028,
        0,
        0.66667
      ],
      8245: [
        0,
        0.54986,
        0,
        0,
        0.275
      ],
      8463: [
        0,
        0.68889,
        0,
        0,
        0.54028
      ],
      8487: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      8498: [
        0,
        0.68889,
        0,
        0,
        0.55556
      ],
      8502: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      8503: [
        0,
        0.68889,
        0,
        0,
        0.44445
      ],
      8504: [
        0,
        0.68889,
        0,
        0,
        0.66667
      ],
      8513: [
        0,
        0.68889,
        0,
        0,
        0.63889
      ],
      8592: [
        -0.03598,
        0.46402,
        0,
        0,
        0.5
      ],
      8594: [
        -0.03598,
        0.46402,
        0,
        0,
        0.5
      ],
      8602: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8603: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8606: [
        0.01354,
        0.52239,
        0,
        0,
        1
      ],
      8608: [
        0.01354,
        0.52239,
        0,
        0,
        1
      ],
      8610: [
        0.01354,
        0.52239,
        0,
        0,
        1.11111
      ],
      8611: [
        0.01354,
        0.52239,
        0,
        0,
        1.11111
      ],
      8619: [
        0,
        0.54986,
        0,
        0,
        1
      ],
      8620: [
        0,
        0.54986,
        0,
        0,
        1
      ],
      8621: [
        -0.13313,
        0.37788,
        0,
        0,
        1.38889
      ],
      8622: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8624: [
        0,
        0.69224,
        0,
        0,
        0.5
      ],
      8625: [
        0,
        0.69224,
        0,
        0,
        0.5
      ],
      8630: [
        0,
        0.43056,
        0,
        0,
        1
      ],
      8631: [
        0,
        0.43056,
        0,
        0,
        1
      ],
      8634: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8635: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8638: [
        0.19444,
        0.69224,
        0,
        0,
        0.41667
      ],
      8639: [
        0.19444,
        0.69224,
        0,
        0,
        0.41667
      ],
      8642: [
        0.19444,
        0.69224,
        0,
        0,
        0.41667
      ],
      8643: [
        0.19444,
        0.69224,
        0,
        0,
        0.41667
      ],
      8644: [
        0.1808,
        0.675,
        0,
        0,
        1
      ],
      8646: [
        0.1808,
        0.675,
        0,
        0,
        1
      ],
      8647: [
        0.1808,
        0.675,
        0,
        0,
        1
      ],
      8648: [
        0.19444,
        0.69224,
        0,
        0,
        0.83334
      ],
      8649: [
        0.1808,
        0.675,
        0,
        0,
        1
      ],
      8650: [
        0.19444,
        0.69224,
        0,
        0,
        0.83334
      ],
      8651: [
        0.01354,
        0.52239,
        0,
        0,
        1
      ],
      8652: [
        0.01354,
        0.52239,
        0,
        0,
        1
      ],
      8653: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8654: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8655: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8666: [
        0.13667,
        0.63667,
        0,
        0,
        1
      ],
      8667: [
        0.13667,
        0.63667,
        0,
        0,
        1
      ],
      8669: [
        -0.13313,
        0.37788,
        0,
        0,
        1
      ],
      8672: [
        -0.064,
        0.437,
        0,
        0,
        1.334
      ],
      8674: [
        -0.064,
        0.437,
        0,
        0,
        1.334
      ],
      8705: [
        0,
        0.825,
        0,
        0,
        0.5
      ],
      8708: [
        0,
        0.68889,
        0,
        0,
        0.55556
      ],
      8709: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      8717: [
        0,
        0.43056,
        0,
        0,
        0.42917
      ],
      8722: [
        -0.03598,
        0.46402,
        0,
        0,
        0.5
      ],
      8724: [
        0.08198,
        0.69224,
        0,
        0,
        0.77778
      ],
      8726: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      8733: [
        0,
        0.69224,
        0,
        0,
        0.77778
      ],
      8736: [
        0,
        0.69224,
        0,
        0,
        0.72222
      ],
      8737: [
        0,
        0.69224,
        0,
        0,
        0.72222
      ],
      8738: [
        0.03517,
        0.52239,
        0,
        0,
        0.72222
      ],
      8739: [
        0.08167,
        0.58167,
        0,
        0,
        0.22222
      ],
      8740: [
        0.25142,
        0.74111,
        0,
        0,
        0.27778
      ],
      8741: [
        0.08167,
        0.58167,
        0,
        0,
        0.38889
      ],
      8742: [
        0.25142,
        0.74111,
        0,
        0,
        0.5
      ],
      8756: [
        0,
        0.69224,
        0,
        0,
        0.66667
      ],
      8757: [
        0,
        0.69224,
        0,
        0,
        0.66667
      ],
      8764: [
        -0.13313,
        0.36687,
        0,
        0,
        0.77778
      ],
      8765: [
        -0.13313,
        0.37788,
        0,
        0,
        0.77778
      ],
      8769: [
        -0.13313,
        0.36687,
        0,
        0,
        0.77778
      ],
      8770: [
        -0.03625,
        0.46375,
        0,
        0,
        0.77778
      ],
      8774: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8776: [
        -0.01688,
        0.48312,
        0,
        0,
        0.77778
      ],
      8778: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      8782: [
        0.06062,
        0.54986,
        0,
        0,
        0.77778
      ],
      8783: [
        0.06062,
        0.54986,
        0,
        0,
        0.77778
      ],
      8785: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8786: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8787: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8790: [
        0,
        0.69224,
        0,
        0,
        0.77778
      ],
      8791: [
        0.22958,
        0.72958,
        0,
        0,
        0.77778
      ],
      8796: [
        0.08198,
        0.91667,
        0,
        0,
        0.77778
      ],
      8806: [
        0.25583,
        0.75583,
        0,
        0,
        0.77778
      ],
      8807: [
        0.25583,
        0.75583,
        0,
        0,
        0.77778
      ],
      8808: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      8809: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      8812: [
        0.25583,
        0.75583,
        0,
        0,
        0.5
      ],
      8814: [
        0.20576,
        0.70576,
        0,
        0,
        0.77778
      ],
      8815: [
        0.20576,
        0.70576,
        0,
        0,
        0.77778
      ],
      8816: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8817: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8818: [
        0.22958,
        0.72958,
        0,
        0,
        0.77778
      ],
      8819: [
        0.22958,
        0.72958,
        0,
        0,
        0.77778
      ],
      8822: [
        0.1808,
        0.675,
        0,
        0,
        0.77778
      ],
      8823: [
        0.1808,
        0.675,
        0,
        0,
        0.77778
      ],
      8828: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      8829: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      8830: [
        0.22958,
        0.72958,
        0,
        0,
        0.77778
      ],
      8831: [
        0.22958,
        0.72958,
        0,
        0,
        0.77778
      ],
      8832: [
        0.20576,
        0.70576,
        0,
        0,
        0.77778
      ],
      8833: [
        0.20576,
        0.70576,
        0,
        0,
        0.77778
      ],
      8840: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8841: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8842: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8843: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8847: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      8848: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      8858: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8859: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8861: [
        0.08198,
        0.58198,
        0,
        0,
        0.77778
      ],
      8862: [
        0,
        0.675,
        0,
        0,
        0.77778
      ],
      8863: [
        0,
        0.675,
        0,
        0,
        0.77778
      ],
      8864: [
        0,
        0.675,
        0,
        0,
        0.77778
      ],
      8865: [
        0,
        0.675,
        0,
        0,
        0.77778
      ],
      8872: [
        0,
        0.69224,
        0,
        0,
        0.61111
      ],
      8873: [
        0,
        0.69224,
        0,
        0,
        0.72222
      ],
      8874: [
        0,
        0.69224,
        0,
        0,
        0.88889
      ],
      8876: [
        0,
        0.68889,
        0,
        0,
        0.61111
      ],
      8877: [
        0,
        0.68889,
        0,
        0,
        0.61111
      ],
      8878: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      8879: [
        0,
        0.68889,
        0,
        0,
        0.72222
      ],
      8882: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      8883: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      8884: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      8885: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      8888: [
        0,
        0.54986,
        0,
        0,
        1.11111
      ],
      8890: [
        0.19444,
        0.43056,
        0,
        0,
        0.55556
      ],
      8891: [
        0.19444,
        0.69224,
        0,
        0,
        0.61111
      ],
      8892: [
        0.19444,
        0.69224,
        0,
        0,
        0.61111
      ],
      8901: [
        0,
        0.54986,
        0,
        0,
        0.27778
      ],
      8903: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      8905: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      8906: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      8907: [
        0,
        0.69224,
        0,
        0,
        0.77778
      ],
      8908: [
        0,
        0.69224,
        0,
        0,
        0.77778
      ],
      8909: [
        -0.03598,
        0.46402,
        0,
        0,
        0.77778
      ],
      8910: [
        0,
        0.54986,
        0,
        0,
        0.76042
      ],
      8911: [
        0,
        0.54986,
        0,
        0,
        0.76042
      ],
      8912: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      8913: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      8914: [
        0,
        0.54986,
        0,
        0,
        0.66667
      ],
      8915: [
        0,
        0.54986,
        0,
        0,
        0.66667
      ],
      8916: [
        0,
        0.69224,
        0,
        0,
        0.66667
      ],
      8918: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      8919: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      8920: [
        0.03517,
        0.54986,
        0,
        0,
        1.33334
      ],
      8921: [
        0.03517,
        0.54986,
        0,
        0,
        1.33334
      ],
      8922: [
        0.38569,
        0.88569,
        0,
        0,
        0.77778
      ],
      8923: [
        0.38569,
        0.88569,
        0,
        0,
        0.77778
      ],
      8926: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      8927: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      8928: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8929: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8934: [
        0.23222,
        0.74111,
        0,
        0,
        0.77778
      ],
      8935: [
        0.23222,
        0.74111,
        0,
        0,
        0.77778
      ],
      8936: [
        0.23222,
        0.74111,
        0,
        0,
        0.77778
      ],
      8937: [
        0.23222,
        0.74111,
        0,
        0,
        0.77778
      ],
      8938: [
        0.20576,
        0.70576,
        0,
        0,
        0.77778
      ],
      8939: [
        0.20576,
        0.70576,
        0,
        0,
        0.77778
      ],
      8940: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8941: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      8994: [
        0.19444,
        0.69224,
        0,
        0,
        0.77778
      ],
      8995: [
        0.19444,
        0.69224,
        0,
        0,
        0.77778
      ],
      9416: [
        0.15559,
        0.69224,
        0,
        0,
        0.90222
      ],
      9484: [
        0,
        0.69224,
        0,
        0,
        0.5
      ],
      9488: [
        0,
        0.69224,
        0,
        0,
        0.5
      ],
      9492: [
        0,
        0.37788,
        0,
        0,
        0.5
      ],
      9496: [
        0,
        0.37788,
        0,
        0,
        0.5
      ],
      9585: [
        0.19444,
        0.68889,
        0,
        0,
        0.88889
      ],
      9586: [
        0.19444,
        0.74111,
        0,
        0,
        0.88889
      ],
      9632: [
        0,
        0.675,
        0,
        0,
        0.77778
      ],
      9633: [
        0,
        0.675,
        0,
        0,
        0.77778
      ],
      9650: [
        0,
        0.54986,
        0,
        0,
        0.72222
      ],
      9651: [
        0,
        0.54986,
        0,
        0,
        0.72222
      ],
      9654: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      9660: [
        0,
        0.54986,
        0,
        0,
        0.72222
      ],
      9661: [
        0,
        0.54986,
        0,
        0,
        0.72222
      ],
      9664: [
        0.03517,
        0.54986,
        0,
        0,
        0.77778
      ],
      9674: [
        0.11111,
        0.69224,
        0,
        0,
        0.66667
      ],
      9733: [
        0.19444,
        0.69224,
        0,
        0,
        0.94445
      ],
      10003: [
        0,
        0.69224,
        0,
        0,
        0.83334
      ],
      10016: [
        0,
        0.69224,
        0,
        0,
        0.83334
      ],
      10731: [
        0.11111,
        0.69224,
        0,
        0,
        0.66667
      ],
      10846: [
        0.19444,
        0.75583,
        0,
        0,
        0.61111
      ],
      10877: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      10878: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      10885: [
        0.25583,
        0.75583,
        0,
        0,
        0.77778
      ],
      10886: [
        0.25583,
        0.75583,
        0,
        0,
        0.77778
      ],
      10887: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      10888: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      10889: [
        0.26167,
        0.75726,
        0,
        0,
        0.77778
      ],
      10890: [
        0.26167,
        0.75726,
        0,
        0,
        0.77778
      ],
      10891: [
        0.48256,
        0.98256,
        0,
        0,
        0.77778
      ],
      10892: [
        0.48256,
        0.98256,
        0,
        0,
        0.77778
      ],
      10901: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      10902: [
        0.13667,
        0.63667,
        0,
        0,
        0.77778
      ],
      10933: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      10934: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      10935: [
        0.26167,
        0.75726,
        0,
        0,
        0.77778
      ],
      10936: [
        0.26167,
        0.75726,
        0,
        0,
        0.77778
      ],
      10937: [
        0.26167,
        0.75726,
        0,
        0,
        0.77778
      ],
      10938: [
        0.26167,
        0.75726,
        0,
        0,
        0.77778
      ],
      10949: [
        0.25583,
        0.75583,
        0,
        0,
        0.77778
      ],
      10950: [
        0.25583,
        0.75583,
        0,
        0,
        0.77778
      ],
      10955: [
        0.28481,
        0.79383,
        0,
        0,
        0.77778
      ],
      10956: [
        0.28481,
        0.79383,
        0,
        0,
        0.77778
      ],
      57350: [
        0.08167,
        0.58167,
        0,
        0,
        0.22222
      ],
      57351: [
        0.08167,
        0.58167,
        0,
        0,
        0.38889
      ],
      57352: [
        0.08167,
        0.58167,
        0,
        0,
        0.77778
      ],
      57353: [
        0,
        0.43056,
        0.04028,
        0,
        0.66667
      ],
      57356: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      57357: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      57358: [
        0.41951,
        0.91951,
        0,
        0,
        0.77778
      ],
      57359: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      57360: [
        0.30274,
        0.79383,
        0,
        0,
        0.77778
      ],
      57361: [
        0.41951,
        0.91951,
        0,
        0,
        0.77778
      ],
      57366: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      57367: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      57368: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      57369: [
        0.25142,
        0.75726,
        0,
        0,
        0.77778
      ],
      57370: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      57371: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ]
    },
    "Caligraphic-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      65: [
        0,
        0.68333,
        0,
        0.19445,
        0.79847
      ],
      66: [
        0,
        0.68333,
        0.03041,
        0.13889,
        0.65681
      ],
      67: [
        0,
        0.68333,
        0.05834,
        0.13889,
        0.52653
      ],
      68: [
        0,
        0.68333,
        0.02778,
        0.08334,
        0.77139
      ],
      69: [
        0,
        0.68333,
        0.08944,
        0.11111,
        0.52778
      ],
      70: [
        0,
        0.68333,
        0.09931,
        0.11111,
        0.71875
      ],
      71: [
        0.09722,
        0.68333,
        0.0593,
        0.11111,
        0.59487
      ],
      72: [
        0,
        0.68333,
        965e-5,
        0.11111,
        0.84452
      ],
      73: [
        0,
        0.68333,
        0.07382,
        0,
        0.54452
      ],
      74: [
        0.09722,
        0.68333,
        0.18472,
        0.16667,
        0.67778
      ],
      75: [
        0,
        0.68333,
        0.01445,
        0.05556,
        0.76195
      ],
      76: [
        0,
        0.68333,
        0,
        0.13889,
        0.68972
      ],
      77: [
        0,
        0.68333,
        0,
        0.13889,
        1.2009
      ],
      78: [
        0,
        0.68333,
        0.14736,
        0.08334,
        0.82049
      ],
      79: [
        0,
        0.68333,
        0.02778,
        0.11111,
        0.79611
      ],
      80: [
        0,
        0.68333,
        0.08222,
        0.08334,
        0.69556
      ],
      81: [
        0.09722,
        0.68333,
        0,
        0.11111,
        0.81667
      ],
      82: [
        0,
        0.68333,
        0,
        0.08334,
        0.8475
      ],
      83: [
        0,
        0.68333,
        0.075,
        0.13889,
        0.60556
      ],
      84: [
        0,
        0.68333,
        0.25417,
        0,
        0.54464
      ],
      85: [
        0,
        0.68333,
        0.09931,
        0.08334,
        0.62583
      ],
      86: [
        0,
        0.68333,
        0.08222,
        0,
        0.61278
      ],
      87: [
        0,
        0.68333,
        0.08222,
        0.08334,
        0.98778
      ],
      88: [
        0,
        0.68333,
        0.14643,
        0.13889,
        0.7133
      ],
      89: [
        0.09722,
        0.68333,
        0.08222,
        0.08334,
        0.66834
      ],
      90: [
        0,
        0.68333,
        0.07944,
        0.13889,
        0.72473
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ]
    },
    "Fraktur-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69141,
        0,
        0,
        0.29574
      ],
      34: [
        0,
        0.69141,
        0,
        0,
        0.21471
      ],
      38: [
        0,
        0.69141,
        0,
        0,
        0.73786
      ],
      39: [
        0,
        0.69141,
        0,
        0,
        0.21201
      ],
      40: [
        0.24982,
        0.74947,
        0,
        0,
        0.38865
      ],
      41: [
        0.24982,
        0.74947,
        0,
        0,
        0.38865
      ],
      42: [
        0,
        0.62119,
        0,
        0,
        0.27764
      ],
      43: [
        0.08319,
        0.58283,
        0,
        0,
        0.75623
      ],
      44: [
        0,
        0.10803,
        0,
        0,
        0.27764
      ],
      45: [
        0.08319,
        0.58283,
        0,
        0,
        0.75623
      ],
      46: [
        0,
        0.10803,
        0,
        0,
        0.27764
      ],
      47: [
        0.24982,
        0.74947,
        0,
        0,
        0.50181
      ],
      48: [
        0,
        0.47534,
        0,
        0,
        0.50181
      ],
      49: [
        0,
        0.47534,
        0,
        0,
        0.50181
      ],
      50: [
        0,
        0.47534,
        0,
        0,
        0.50181
      ],
      51: [
        0.18906,
        0.47534,
        0,
        0,
        0.50181
      ],
      52: [
        0.18906,
        0.47534,
        0,
        0,
        0.50181
      ],
      53: [
        0.18906,
        0.47534,
        0,
        0,
        0.50181
      ],
      54: [
        0,
        0.69141,
        0,
        0,
        0.50181
      ],
      55: [
        0.18906,
        0.47534,
        0,
        0,
        0.50181
      ],
      56: [
        0,
        0.69141,
        0,
        0,
        0.50181
      ],
      57: [
        0.18906,
        0.47534,
        0,
        0,
        0.50181
      ],
      58: [
        0,
        0.47534,
        0,
        0,
        0.21606
      ],
      59: [
        0.12604,
        0.47534,
        0,
        0,
        0.21606
      ],
      61: [
        -0.13099,
        0.36866,
        0,
        0,
        0.75623
      ],
      63: [
        0,
        0.69141,
        0,
        0,
        0.36245
      ],
      65: [
        0,
        0.69141,
        0,
        0,
        0.7176
      ],
      66: [
        0,
        0.69141,
        0,
        0,
        0.88397
      ],
      67: [
        0,
        0.69141,
        0,
        0,
        0.61254
      ],
      68: [
        0,
        0.69141,
        0,
        0,
        0.83158
      ],
      69: [
        0,
        0.69141,
        0,
        0,
        0.66278
      ],
      70: [
        0.12604,
        0.69141,
        0,
        0,
        0.61119
      ],
      71: [
        0,
        0.69141,
        0,
        0,
        0.78539
      ],
      72: [
        0.06302,
        0.69141,
        0,
        0,
        0.7203
      ],
      73: [
        0,
        0.69141,
        0,
        0,
        0.55448
      ],
      74: [
        0.12604,
        0.69141,
        0,
        0,
        0.55231
      ],
      75: [
        0,
        0.69141,
        0,
        0,
        0.66845
      ],
      76: [
        0,
        0.69141,
        0,
        0,
        0.66602
      ],
      77: [
        0,
        0.69141,
        0,
        0,
        1.04953
      ],
      78: [
        0,
        0.69141,
        0,
        0,
        0.83212
      ],
      79: [
        0,
        0.69141,
        0,
        0,
        0.82699
      ],
      80: [
        0.18906,
        0.69141,
        0,
        0,
        0.82753
      ],
      81: [
        0.03781,
        0.69141,
        0,
        0,
        0.82699
      ],
      82: [
        0,
        0.69141,
        0,
        0,
        0.82807
      ],
      83: [
        0,
        0.69141,
        0,
        0,
        0.82861
      ],
      84: [
        0,
        0.69141,
        0,
        0,
        0.66899
      ],
      85: [
        0,
        0.69141,
        0,
        0,
        0.64576
      ],
      86: [
        0,
        0.69141,
        0,
        0,
        0.83131
      ],
      87: [
        0,
        0.69141,
        0,
        0,
        1.04602
      ],
      88: [
        0,
        0.69141,
        0,
        0,
        0.71922
      ],
      89: [
        0.18906,
        0.69141,
        0,
        0,
        0.83293
      ],
      90: [
        0.12604,
        0.69141,
        0,
        0,
        0.60201
      ],
      91: [
        0.24982,
        0.74947,
        0,
        0,
        0.27764
      ],
      93: [
        0.24982,
        0.74947,
        0,
        0,
        0.27764
      ],
      94: [
        0,
        0.69141,
        0,
        0,
        0.49965
      ],
      97: [
        0,
        0.47534,
        0,
        0,
        0.50046
      ],
      98: [
        0,
        0.69141,
        0,
        0,
        0.51315
      ],
      99: [
        0,
        0.47534,
        0,
        0,
        0.38946
      ],
      100: [
        0,
        0.62119,
        0,
        0,
        0.49857
      ],
      101: [
        0,
        0.47534,
        0,
        0,
        0.40053
      ],
      102: [
        0.18906,
        0.69141,
        0,
        0,
        0.32626
      ],
      103: [
        0.18906,
        0.47534,
        0,
        0,
        0.5037
      ],
      104: [
        0.18906,
        0.69141,
        0,
        0,
        0.52126
      ],
      105: [
        0,
        0.69141,
        0,
        0,
        0.27899
      ],
      106: [
        0,
        0.69141,
        0,
        0,
        0.28088
      ],
      107: [
        0,
        0.69141,
        0,
        0,
        0.38946
      ],
      108: [
        0,
        0.69141,
        0,
        0,
        0.27953
      ],
      109: [
        0,
        0.47534,
        0,
        0,
        0.76676
      ],
      110: [
        0,
        0.47534,
        0,
        0,
        0.52666
      ],
      111: [
        0,
        0.47534,
        0,
        0,
        0.48885
      ],
      112: [
        0.18906,
        0.52396,
        0,
        0,
        0.50046
      ],
      113: [
        0.18906,
        0.47534,
        0,
        0,
        0.48912
      ],
      114: [
        0,
        0.47534,
        0,
        0,
        0.38919
      ],
      115: [
        0,
        0.47534,
        0,
        0,
        0.44266
      ],
      116: [
        0,
        0.62119,
        0,
        0,
        0.33301
      ],
      117: [
        0,
        0.47534,
        0,
        0,
        0.5172
      ],
      118: [
        0,
        0.52396,
        0,
        0,
        0.5118
      ],
      119: [
        0,
        0.52396,
        0,
        0,
        0.77351
      ],
      120: [
        0.18906,
        0.47534,
        0,
        0,
        0.38865
      ],
      121: [
        0.18906,
        0.47534,
        0,
        0,
        0.49884
      ],
      122: [
        0.18906,
        0.47534,
        0,
        0,
        0.39054
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      8216: [
        0,
        0.69141,
        0,
        0,
        0.21471
      ],
      8217: [
        0,
        0.69141,
        0,
        0,
        0.21471
      ],
      58112: [
        0,
        0.62119,
        0,
        0,
        0.49749
      ],
      58113: [
        0,
        0.62119,
        0,
        0,
        0.4983
      ],
      58114: [
        0.18906,
        0.69141,
        0,
        0,
        0.33328
      ],
      58115: [
        0.18906,
        0.69141,
        0,
        0,
        0.32923
      ],
      58116: [
        0.18906,
        0.47534,
        0,
        0,
        0.50343
      ],
      58117: [
        0,
        0.69141,
        0,
        0,
        0.33301
      ],
      58118: [
        0,
        0.62119,
        0,
        0,
        0.33409
      ],
      58119: [
        0,
        0.47534,
        0,
        0,
        0.50073
      ]
    },
    "Main-Bold": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0,
        0,
        0.35
      ],
      34: [
        0,
        0.69444,
        0,
        0,
        0.60278
      ],
      35: [
        0.19444,
        0.69444,
        0,
        0,
        0.95833
      ],
      36: [
        0.05556,
        0.75,
        0,
        0,
        0.575
      ],
      37: [
        0.05556,
        0.75,
        0,
        0,
        0.95833
      ],
      38: [
        0,
        0.69444,
        0,
        0,
        0.89444
      ],
      39: [
        0,
        0.69444,
        0,
        0,
        0.31944
      ],
      40: [
        0.25,
        0.75,
        0,
        0,
        0.44722
      ],
      41: [
        0.25,
        0.75,
        0,
        0,
        0.44722
      ],
      42: [
        0,
        0.75,
        0,
        0,
        0.575
      ],
      43: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      44: [
        0.19444,
        0.15556,
        0,
        0,
        0.31944
      ],
      45: [
        0,
        0.44444,
        0,
        0,
        0.38333
      ],
      46: [
        0,
        0.15556,
        0,
        0,
        0.31944
      ],
      47: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      48: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      49: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      50: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      51: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      52: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      53: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      54: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      55: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      56: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      57: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      58: [
        0,
        0.44444,
        0,
        0,
        0.31944
      ],
      59: [
        0.19444,
        0.44444,
        0,
        0,
        0.31944
      ],
      60: [
        0.08556,
        0.58556,
        0,
        0,
        0.89444
      ],
      61: [
        -0.10889,
        0.39111,
        0,
        0,
        0.89444
      ],
      62: [
        0.08556,
        0.58556,
        0,
        0,
        0.89444
      ],
      63: [
        0,
        0.69444,
        0,
        0,
        0.54305
      ],
      64: [
        0,
        0.69444,
        0,
        0,
        0.89444
      ],
      65: [
        0,
        0.68611,
        0,
        0,
        0.86944
      ],
      66: [
        0,
        0.68611,
        0,
        0,
        0.81805
      ],
      67: [
        0,
        0.68611,
        0,
        0,
        0.83055
      ],
      68: [
        0,
        0.68611,
        0,
        0,
        0.88194
      ],
      69: [
        0,
        0.68611,
        0,
        0,
        0.75555
      ],
      70: [
        0,
        0.68611,
        0,
        0,
        0.72361
      ],
      71: [
        0,
        0.68611,
        0,
        0,
        0.90416
      ],
      72: [
        0,
        0.68611,
        0,
        0,
        0.9
      ],
      73: [
        0,
        0.68611,
        0,
        0,
        0.43611
      ],
      74: [
        0,
        0.68611,
        0,
        0,
        0.59444
      ],
      75: [
        0,
        0.68611,
        0,
        0,
        0.90138
      ],
      76: [
        0,
        0.68611,
        0,
        0,
        0.69166
      ],
      77: [
        0,
        0.68611,
        0,
        0,
        1.09166
      ],
      78: [
        0,
        0.68611,
        0,
        0,
        0.9
      ],
      79: [
        0,
        0.68611,
        0,
        0,
        0.86388
      ],
      80: [
        0,
        0.68611,
        0,
        0,
        0.78611
      ],
      81: [
        0.19444,
        0.68611,
        0,
        0,
        0.86388
      ],
      82: [
        0,
        0.68611,
        0,
        0,
        0.8625
      ],
      83: [
        0,
        0.68611,
        0,
        0,
        0.63889
      ],
      84: [
        0,
        0.68611,
        0,
        0,
        0.8
      ],
      85: [
        0,
        0.68611,
        0,
        0,
        0.88472
      ],
      86: [
        0,
        0.68611,
        0.01597,
        0,
        0.86944
      ],
      87: [
        0,
        0.68611,
        0.01597,
        0,
        1.18888
      ],
      88: [
        0,
        0.68611,
        0,
        0,
        0.86944
      ],
      89: [
        0,
        0.68611,
        0.02875,
        0,
        0.86944
      ],
      90: [
        0,
        0.68611,
        0,
        0,
        0.70277
      ],
      91: [
        0.25,
        0.75,
        0,
        0,
        0.31944
      ],
      92: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      93: [
        0.25,
        0.75,
        0,
        0,
        0.31944
      ],
      94: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      95: [
        0.31,
        0.13444,
        0.03194,
        0,
        0.575
      ],
      97: [
        0,
        0.44444,
        0,
        0,
        0.55902
      ],
      98: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      99: [
        0,
        0.44444,
        0,
        0,
        0.51111
      ],
      100: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      101: [
        0,
        0.44444,
        0,
        0,
        0.52708
      ],
      102: [
        0,
        0.69444,
        0.10903,
        0,
        0.35139
      ],
      103: [
        0.19444,
        0.44444,
        0.01597,
        0,
        0.575
      ],
      104: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      105: [
        0,
        0.69444,
        0,
        0,
        0.31944
      ],
      106: [
        0.19444,
        0.69444,
        0,
        0,
        0.35139
      ],
      107: [
        0,
        0.69444,
        0,
        0,
        0.60694
      ],
      108: [
        0,
        0.69444,
        0,
        0,
        0.31944
      ],
      109: [
        0,
        0.44444,
        0,
        0,
        0.95833
      ],
      110: [
        0,
        0.44444,
        0,
        0,
        0.63889
      ],
      111: [
        0,
        0.44444,
        0,
        0,
        0.575
      ],
      112: [
        0.19444,
        0.44444,
        0,
        0,
        0.63889
      ],
      113: [
        0.19444,
        0.44444,
        0,
        0,
        0.60694
      ],
      114: [
        0,
        0.44444,
        0,
        0,
        0.47361
      ],
      115: [
        0,
        0.44444,
        0,
        0,
        0.45361
      ],
      116: [
        0,
        0.63492,
        0,
        0,
        0.44722
      ],
      117: [
        0,
        0.44444,
        0,
        0,
        0.63889
      ],
      118: [
        0,
        0.44444,
        0.01597,
        0,
        0.60694
      ],
      119: [
        0,
        0.44444,
        0.01597,
        0,
        0.83055
      ],
      120: [
        0,
        0.44444,
        0,
        0,
        0.60694
      ],
      121: [
        0.19444,
        0.44444,
        0.01597,
        0,
        0.60694
      ],
      122: [
        0,
        0.44444,
        0,
        0,
        0.51111
      ],
      123: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      124: [
        0.25,
        0.75,
        0,
        0,
        0.31944
      ],
      125: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      126: [
        0.35,
        0.34444,
        0,
        0,
        0.575
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      163: [
        0,
        0.69444,
        0,
        0,
        0.86853
      ],
      168: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      172: [
        0,
        0.44444,
        0,
        0,
        0.76666
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.86944
      ],
      177: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.51111
      ],
      198: [
        0,
        0.68611,
        0,
        0,
        1.04166
      ],
      215: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      216: [
        0.04861,
        0.73472,
        0,
        0,
        0.89444
      ],
      223: [
        0,
        0.69444,
        0,
        0,
        0.59722
      ],
      230: [
        0,
        0.44444,
        0,
        0,
        0.83055
      ],
      247: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      248: [
        0.09722,
        0.54167,
        0,
        0,
        0.575
      ],
      305: [
        0,
        0.44444,
        0,
        0,
        0.31944
      ],
      338: [
        0,
        0.68611,
        0,
        0,
        1.16944
      ],
      339: [
        0,
        0.44444,
        0,
        0,
        0.89444
      ],
      567: [
        0.19444,
        0.44444,
        0,
        0,
        0.35139
      ],
      710: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      711: [
        0,
        0.63194,
        0,
        0,
        0.575
      ],
      713: [
        0,
        0.59611,
        0,
        0,
        0.575
      ],
      714: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      715: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      728: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      729: [
        0,
        0.69444,
        0,
        0,
        0.31944
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.86944
      ],
      732: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      733: [
        0,
        0.69444,
        0,
        0,
        0.575
      ],
      915: [
        0,
        0.68611,
        0,
        0,
        0.69166
      ],
      916: [
        0,
        0.68611,
        0,
        0,
        0.95833
      ],
      920: [
        0,
        0.68611,
        0,
        0,
        0.89444
      ],
      923: [
        0,
        0.68611,
        0,
        0,
        0.80555
      ],
      926: [
        0,
        0.68611,
        0,
        0,
        0.76666
      ],
      928: [
        0,
        0.68611,
        0,
        0,
        0.9
      ],
      931: [
        0,
        0.68611,
        0,
        0,
        0.83055
      ],
      933: [
        0,
        0.68611,
        0,
        0,
        0.89444
      ],
      934: [
        0,
        0.68611,
        0,
        0,
        0.83055
      ],
      936: [
        0,
        0.68611,
        0,
        0,
        0.89444
      ],
      937: [
        0,
        0.68611,
        0,
        0,
        0.83055
      ],
      8211: [
        0,
        0.44444,
        0.03194,
        0,
        0.575
      ],
      8212: [
        0,
        0.44444,
        0.03194,
        0,
        1.14999
      ],
      8216: [
        0,
        0.69444,
        0,
        0,
        0.31944
      ],
      8217: [
        0,
        0.69444,
        0,
        0,
        0.31944
      ],
      8220: [
        0,
        0.69444,
        0,
        0,
        0.60278
      ],
      8221: [
        0,
        0.69444,
        0,
        0,
        0.60278
      ],
      8224: [
        0.19444,
        0.69444,
        0,
        0,
        0.51111
      ],
      8225: [
        0.19444,
        0.69444,
        0,
        0,
        0.51111
      ],
      8242: [
        0,
        0.55556,
        0,
        0,
        0.34444
      ],
      8407: [
        0,
        0.72444,
        0.15486,
        0,
        0.575
      ],
      8463: [
        0,
        0.69444,
        0,
        0,
        0.66759
      ],
      8465: [
        0,
        0.69444,
        0,
        0,
        0.83055
      ],
      8467: [
        0,
        0.69444,
        0,
        0,
        0.47361
      ],
      8472: [
        0.19444,
        0.44444,
        0,
        0,
        0.74027
      ],
      8476: [
        0,
        0.69444,
        0,
        0,
        0.83055
      ],
      8501: [
        0,
        0.69444,
        0,
        0,
        0.70277
      ],
      8592: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8593: [
        0.19444,
        0.69444,
        0,
        0,
        0.575
      ],
      8594: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8595: [
        0.19444,
        0.69444,
        0,
        0,
        0.575
      ],
      8596: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8597: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      8598: [
        0.19444,
        0.69444,
        0,
        0,
        1.14999
      ],
      8599: [
        0.19444,
        0.69444,
        0,
        0,
        1.14999
      ],
      8600: [
        0.19444,
        0.69444,
        0,
        0,
        1.14999
      ],
      8601: [
        0.19444,
        0.69444,
        0,
        0,
        1.14999
      ],
      8636: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8637: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8640: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8641: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8656: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8657: [
        0.19444,
        0.69444,
        0,
        0,
        0.70277
      ],
      8658: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8659: [
        0.19444,
        0.69444,
        0,
        0,
        0.70277
      ],
      8660: [
        -0.10889,
        0.39111,
        0,
        0,
        1.14999
      ],
      8661: [
        0.25,
        0.75,
        0,
        0,
        0.70277
      ],
      8704: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      8706: [
        0,
        0.69444,
        0.06389,
        0,
        0.62847
      ],
      8707: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      8709: [
        0.05556,
        0.75,
        0,
        0,
        0.575
      ],
      8711: [
        0,
        0.68611,
        0,
        0,
        0.95833
      ],
      8712: [
        0.08556,
        0.58556,
        0,
        0,
        0.76666
      ],
      8715: [
        0.08556,
        0.58556,
        0,
        0,
        0.76666
      ],
      8722: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8723: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8725: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      8726: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      8727: [
        -0.02778,
        0.47222,
        0,
        0,
        0.575
      ],
      8728: [
        -0.02639,
        0.47361,
        0,
        0,
        0.575
      ],
      8729: [
        -0.02639,
        0.47361,
        0,
        0,
        0.575
      ],
      8730: [
        0.18,
        0.82,
        0,
        0,
        0.95833
      ],
      8733: [
        0,
        0.44444,
        0,
        0,
        0.89444
      ],
      8734: [
        0,
        0.44444,
        0,
        0,
        1.14999
      ],
      8736: [
        0,
        0.69224,
        0,
        0,
        0.72222
      ],
      8739: [
        0.25,
        0.75,
        0,
        0,
        0.31944
      ],
      8741: [
        0.25,
        0.75,
        0,
        0,
        0.575
      ],
      8743: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8744: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8745: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8746: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8747: [
        0.19444,
        0.69444,
        0.12778,
        0,
        0.56875
      ],
      8764: [
        -0.10889,
        0.39111,
        0,
        0,
        0.89444
      ],
      8768: [
        0.19444,
        0.69444,
        0,
        0,
        0.31944
      ],
      8771: [
        222e-5,
        0.50222,
        0,
        0,
        0.89444
      ],
      8773: [
        0.027,
        0.638,
        0,
        0,
        0.894
      ],
      8776: [
        0.02444,
        0.52444,
        0,
        0,
        0.89444
      ],
      8781: [
        222e-5,
        0.50222,
        0,
        0,
        0.89444
      ],
      8801: [
        222e-5,
        0.50222,
        0,
        0,
        0.89444
      ],
      8804: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      8805: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      8810: [
        0.08556,
        0.58556,
        0,
        0,
        1.14999
      ],
      8811: [
        0.08556,
        0.58556,
        0,
        0,
        1.14999
      ],
      8826: [
        0.08556,
        0.58556,
        0,
        0,
        0.89444
      ],
      8827: [
        0.08556,
        0.58556,
        0,
        0,
        0.89444
      ],
      8834: [
        0.08556,
        0.58556,
        0,
        0,
        0.89444
      ],
      8835: [
        0.08556,
        0.58556,
        0,
        0,
        0.89444
      ],
      8838: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      8839: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      8846: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8849: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      8850: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      8851: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8852: [
        0,
        0.55556,
        0,
        0,
        0.76666
      ],
      8853: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8854: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8855: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8856: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8857: [
        0.13333,
        0.63333,
        0,
        0,
        0.89444
      ],
      8866: [
        0,
        0.69444,
        0,
        0,
        0.70277
      ],
      8867: [
        0,
        0.69444,
        0,
        0,
        0.70277
      ],
      8868: [
        0,
        0.69444,
        0,
        0,
        0.89444
      ],
      8869: [
        0,
        0.69444,
        0,
        0,
        0.89444
      ],
      8900: [
        -0.02639,
        0.47361,
        0,
        0,
        0.575
      ],
      8901: [
        -0.02639,
        0.47361,
        0,
        0,
        0.31944
      ],
      8902: [
        -0.02778,
        0.47222,
        0,
        0,
        0.575
      ],
      8968: [
        0.25,
        0.75,
        0,
        0,
        0.51111
      ],
      8969: [
        0.25,
        0.75,
        0,
        0,
        0.51111
      ],
      8970: [
        0.25,
        0.75,
        0,
        0,
        0.51111
      ],
      8971: [
        0.25,
        0.75,
        0,
        0,
        0.51111
      ],
      8994: [
        -0.13889,
        0.36111,
        0,
        0,
        1.14999
      ],
      8995: [
        -0.13889,
        0.36111,
        0,
        0,
        1.14999
      ],
      9651: [
        0.19444,
        0.69444,
        0,
        0,
        1.02222
      ],
      9657: [
        -0.02778,
        0.47222,
        0,
        0,
        0.575
      ],
      9661: [
        0.19444,
        0.69444,
        0,
        0,
        1.02222
      ],
      9667: [
        -0.02778,
        0.47222,
        0,
        0,
        0.575
      ],
      9711: [
        0.19444,
        0.69444,
        0,
        0,
        1.14999
      ],
      9824: [
        0.12963,
        0.69444,
        0,
        0,
        0.89444
      ],
      9825: [
        0.12963,
        0.69444,
        0,
        0,
        0.89444
      ],
      9826: [
        0.12963,
        0.69444,
        0,
        0,
        0.89444
      ],
      9827: [
        0.12963,
        0.69444,
        0,
        0,
        0.89444
      ],
      9837: [
        0,
        0.75,
        0,
        0,
        0.44722
      ],
      9838: [
        0.19444,
        0.69444,
        0,
        0,
        0.44722
      ],
      9839: [
        0.19444,
        0.69444,
        0,
        0,
        0.44722
      ],
      10216: [
        0.25,
        0.75,
        0,
        0,
        0.44722
      ],
      10217: [
        0.25,
        0.75,
        0,
        0,
        0.44722
      ],
      10815: [
        0,
        0.68611,
        0,
        0,
        0.9
      ],
      10927: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      10928: [
        0.19667,
        0.69667,
        0,
        0,
        0.89444
      ],
      57376: [
        0.19444,
        0.69444,
        0,
        0,
        0
      ]
    },
    "Main-BoldItalic": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0.11417,
        0,
        0.38611
      ],
      34: [
        0,
        0.69444,
        0.07939,
        0,
        0.62055
      ],
      35: [
        0.19444,
        0.69444,
        0.06833,
        0,
        0.94444
      ],
      37: [
        0.05556,
        0.75,
        0.12861,
        0,
        0.94444
      ],
      38: [
        0,
        0.69444,
        0.08528,
        0,
        0.88555
      ],
      39: [
        0,
        0.69444,
        0.12945,
        0,
        0.35555
      ],
      40: [
        0.25,
        0.75,
        0.15806,
        0,
        0.47333
      ],
      41: [
        0.25,
        0.75,
        0.03306,
        0,
        0.47333
      ],
      42: [
        0,
        0.75,
        0.14333,
        0,
        0.59111
      ],
      43: [
        0.10333,
        0.60333,
        0.03306,
        0,
        0.88555
      ],
      44: [
        0.19444,
        0.14722,
        0,
        0,
        0.35555
      ],
      45: [
        0,
        0.44444,
        0.02611,
        0,
        0.41444
      ],
      46: [
        0,
        0.14722,
        0,
        0,
        0.35555
      ],
      47: [
        0.25,
        0.75,
        0.15806,
        0,
        0.59111
      ],
      48: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      49: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      50: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      51: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      52: [
        0.19444,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      53: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      54: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      55: [
        0.19444,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      56: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      57: [
        0,
        0.64444,
        0.13167,
        0,
        0.59111
      ],
      58: [
        0,
        0.44444,
        0.06695,
        0,
        0.35555
      ],
      59: [
        0.19444,
        0.44444,
        0.06695,
        0,
        0.35555
      ],
      61: [
        -0.10889,
        0.39111,
        0.06833,
        0,
        0.88555
      ],
      63: [
        0,
        0.69444,
        0.11472,
        0,
        0.59111
      ],
      64: [
        0,
        0.69444,
        0.09208,
        0,
        0.88555
      ],
      65: [
        0,
        0.68611,
        0,
        0,
        0.86555
      ],
      66: [
        0,
        0.68611,
        0.0992,
        0,
        0.81666
      ],
      67: [
        0,
        0.68611,
        0.14208,
        0,
        0.82666
      ],
      68: [
        0,
        0.68611,
        0.09062,
        0,
        0.87555
      ],
      69: [
        0,
        0.68611,
        0.11431,
        0,
        0.75666
      ],
      70: [
        0,
        0.68611,
        0.12903,
        0,
        0.72722
      ],
      71: [
        0,
        0.68611,
        0.07347,
        0,
        0.89527
      ],
      72: [
        0,
        0.68611,
        0.17208,
        0,
        0.8961
      ],
      73: [
        0,
        0.68611,
        0.15681,
        0,
        0.47166
      ],
      74: [
        0,
        0.68611,
        0.145,
        0,
        0.61055
      ],
      75: [
        0,
        0.68611,
        0.14208,
        0,
        0.89499
      ],
      76: [
        0,
        0.68611,
        0,
        0,
        0.69777
      ],
      77: [
        0,
        0.68611,
        0.17208,
        0,
        1.07277
      ],
      78: [
        0,
        0.68611,
        0.17208,
        0,
        0.8961
      ],
      79: [
        0,
        0.68611,
        0.09062,
        0,
        0.85499
      ],
      80: [
        0,
        0.68611,
        0.0992,
        0,
        0.78721
      ],
      81: [
        0.19444,
        0.68611,
        0.09062,
        0,
        0.85499
      ],
      82: [
        0,
        0.68611,
        0.02559,
        0,
        0.85944
      ],
      83: [
        0,
        0.68611,
        0.11264,
        0,
        0.64999
      ],
      84: [
        0,
        0.68611,
        0.12903,
        0,
        0.7961
      ],
      85: [
        0,
        0.68611,
        0.17208,
        0,
        0.88083
      ],
      86: [
        0,
        0.68611,
        0.18625,
        0,
        0.86555
      ],
      87: [
        0,
        0.68611,
        0.18625,
        0,
        1.15999
      ],
      88: [
        0,
        0.68611,
        0.15681,
        0,
        0.86555
      ],
      89: [
        0,
        0.68611,
        0.19803,
        0,
        0.86555
      ],
      90: [
        0,
        0.68611,
        0.14208,
        0,
        0.70888
      ],
      91: [
        0.25,
        0.75,
        0.1875,
        0,
        0.35611
      ],
      93: [
        0.25,
        0.75,
        0.09972,
        0,
        0.35611
      ],
      94: [
        0,
        0.69444,
        0.06709,
        0,
        0.59111
      ],
      95: [
        0.31,
        0.13444,
        0.09811,
        0,
        0.59111
      ],
      97: [
        0,
        0.44444,
        0.09426,
        0,
        0.59111
      ],
      98: [
        0,
        0.69444,
        0.07861,
        0,
        0.53222
      ],
      99: [
        0,
        0.44444,
        0.05222,
        0,
        0.53222
      ],
      100: [
        0,
        0.69444,
        0.10861,
        0,
        0.59111
      ],
      101: [
        0,
        0.44444,
        0.085,
        0,
        0.53222
      ],
      102: [
        0.19444,
        0.69444,
        0.21778,
        0,
        0.4
      ],
      103: [
        0.19444,
        0.44444,
        0.105,
        0,
        0.53222
      ],
      104: [
        0,
        0.69444,
        0.09426,
        0,
        0.59111
      ],
      105: [
        0,
        0.69326,
        0.11387,
        0,
        0.35555
      ],
      106: [
        0.19444,
        0.69326,
        0.1672,
        0,
        0.35555
      ],
      107: [
        0,
        0.69444,
        0.11111,
        0,
        0.53222
      ],
      108: [
        0,
        0.69444,
        0.10861,
        0,
        0.29666
      ],
      109: [
        0,
        0.44444,
        0.09426,
        0,
        0.94444
      ],
      110: [
        0,
        0.44444,
        0.09426,
        0,
        0.64999
      ],
      111: [
        0,
        0.44444,
        0.07861,
        0,
        0.59111
      ],
      112: [
        0.19444,
        0.44444,
        0.07861,
        0,
        0.59111
      ],
      113: [
        0.19444,
        0.44444,
        0.105,
        0,
        0.53222
      ],
      114: [
        0,
        0.44444,
        0.11111,
        0,
        0.50167
      ],
      115: [
        0,
        0.44444,
        0.08167,
        0,
        0.48694
      ],
      116: [
        0,
        0.63492,
        0.09639,
        0,
        0.385
      ],
      117: [
        0,
        0.44444,
        0.09426,
        0,
        0.62055
      ],
      118: [
        0,
        0.44444,
        0.11111,
        0,
        0.53222
      ],
      119: [
        0,
        0.44444,
        0.11111,
        0,
        0.76777
      ],
      120: [
        0,
        0.44444,
        0.12583,
        0,
        0.56055
      ],
      121: [
        0.19444,
        0.44444,
        0.105,
        0,
        0.56166
      ],
      122: [
        0,
        0.44444,
        0.13889,
        0,
        0.49055
      ],
      126: [
        0.35,
        0.34444,
        0.11472,
        0,
        0.59111
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      168: [
        0,
        0.69444,
        0.11473,
        0,
        0.59111
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.94888
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.53222
      ],
      198: [
        0,
        0.68611,
        0.11431,
        0,
        1.02277
      ],
      216: [
        0.04861,
        0.73472,
        0.09062,
        0,
        0.88555
      ],
      223: [
        0.19444,
        0.69444,
        0.09736,
        0,
        0.665
      ],
      230: [
        0,
        0.44444,
        0.085,
        0,
        0.82666
      ],
      248: [
        0.09722,
        0.54167,
        0.09458,
        0,
        0.59111
      ],
      305: [
        0,
        0.44444,
        0.09426,
        0,
        0.35555
      ],
      338: [
        0,
        0.68611,
        0.11431,
        0,
        1.14054
      ],
      339: [
        0,
        0.44444,
        0.085,
        0,
        0.82666
      ],
      567: [
        0.19444,
        0.44444,
        0.04611,
        0,
        0.385
      ],
      710: [
        0,
        0.69444,
        0.06709,
        0,
        0.59111
      ],
      711: [
        0,
        0.63194,
        0.08271,
        0,
        0.59111
      ],
      713: [
        0,
        0.59444,
        0.10444,
        0,
        0.59111
      ],
      714: [
        0,
        0.69444,
        0.08528,
        0,
        0.59111
      ],
      715: [
        0,
        0.69444,
        0,
        0,
        0.59111
      ],
      728: [
        0,
        0.69444,
        0.10333,
        0,
        0.59111
      ],
      729: [
        0,
        0.69444,
        0.12945,
        0,
        0.35555
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.94888
      ],
      732: [
        0,
        0.69444,
        0.11472,
        0,
        0.59111
      ],
      733: [
        0,
        0.69444,
        0.11472,
        0,
        0.59111
      ],
      915: [
        0,
        0.68611,
        0.12903,
        0,
        0.69777
      ],
      916: [
        0,
        0.68611,
        0,
        0,
        0.94444
      ],
      920: [
        0,
        0.68611,
        0.09062,
        0,
        0.88555
      ],
      923: [
        0,
        0.68611,
        0,
        0,
        0.80666
      ],
      926: [
        0,
        0.68611,
        0.15092,
        0,
        0.76777
      ],
      928: [
        0,
        0.68611,
        0.17208,
        0,
        0.8961
      ],
      931: [
        0,
        0.68611,
        0.11431,
        0,
        0.82666
      ],
      933: [
        0,
        0.68611,
        0.10778,
        0,
        0.88555
      ],
      934: [
        0,
        0.68611,
        0.05632,
        0,
        0.82666
      ],
      936: [
        0,
        0.68611,
        0.10778,
        0,
        0.88555
      ],
      937: [
        0,
        0.68611,
        0.0992,
        0,
        0.82666
      ],
      8211: [
        0,
        0.44444,
        0.09811,
        0,
        0.59111
      ],
      8212: [
        0,
        0.44444,
        0.09811,
        0,
        1.18221
      ],
      8216: [
        0,
        0.69444,
        0.12945,
        0,
        0.35555
      ],
      8217: [
        0,
        0.69444,
        0.12945,
        0,
        0.35555
      ],
      8220: [
        0,
        0.69444,
        0.16772,
        0,
        0.62055
      ],
      8221: [
        0,
        0.69444,
        0.07939,
        0,
        0.62055
      ]
    },
    "Main-Italic": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0.12417,
        0,
        0.30667
      ],
      34: [
        0,
        0.69444,
        0.06961,
        0,
        0.51444
      ],
      35: [
        0.19444,
        0.69444,
        0.06616,
        0,
        0.81777
      ],
      37: [
        0.05556,
        0.75,
        0.13639,
        0,
        0.81777
      ],
      38: [
        0,
        0.69444,
        0.09694,
        0,
        0.76666
      ],
      39: [
        0,
        0.69444,
        0.12417,
        0,
        0.30667
      ],
      40: [
        0.25,
        0.75,
        0.16194,
        0,
        0.40889
      ],
      41: [
        0.25,
        0.75,
        0.03694,
        0,
        0.40889
      ],
      42: [
        0,
        0.75,
        0.14917,
        0,
        0.51111
      ],
      43: [
        0.05667,
        0.56167,
        0.03694,
        0,
        0.76666
      ],
      44: [
        0.19444,
        0.10556,
        0,
        0,
        0.30667
      ],
      45: [
        0,
        0.43056,
        0.02826,
        0,
        0.35778
      ],
      46: [
        0,
        0.10556,
        0,
        0,
        0.30667
      ],
      47: [
        0.25,
        0.75,
        0.16194,
        0,
        0.51111
      ],
      48: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      49: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      50: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      51: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      52: [
        0.19444,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      53: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      54: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      55: [
        0.19444,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      56: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      57: [
        0,
        0.64444,
        0.13556,
        0,
        0.51111
      ],
      58: [
        0,
        0.43056,
        0.0582,
        0,
        0.30667
      ],
      59: [
        0.19444,
        0.43056,
        0.0582,
        0,
        0.30667
      ],
      61: [
        -0.13313,
        0.36687,
        0.06616,
        0,
        0.76666
      ],
      63: [
        0,
        0.69444,
        0.1225,
        0,
        0.51111
      ],
      64: [
        0,
        0.69444,
        0.09597,
        0,
        0.76666
      ],
      65: [
        0,
        0.68333,
        0,
        0,
        0.74333
      ],
      66: [
        0,
        0.68333,
        0.10257,
        0,
        0.70389
      ],
      67: [
        0,
        0.68333,
        0.14528,
        0,
        0.71555
      ],
      68: [
        0,
        0.68333,
        0.09403,
        0,
        0.755
      ],
      69: [
        0,
        0.68333,
        0.12028,
        0,
        0.67833
      ],
      70: [
        0,
        0.68333,
        0.13305,
        0,
        0.65277
      ],
      71: [
        0,
        0.68333,
        0.08722,
        0,
        0.77361
      ],
      72: [
        0,
        0.68333,
        0.16389,
        0,
        0.74333
      ],
      73: [
        0,
        0.68333,
        0.15806,
        0,
        0.38555
      ],
      74: [
        0,
        0.68333,
        0.14028,
        0,
        0.525
      ],
      75: [
        0,
        0.68333,
        0.14528,
        0,
        0.76888
      ],
      76: [
        0,
        0.68333,
        0,
        0,
        0.62722
      ],
      77: [
        0,
        0.68333,
        0.16389,
        0,
        0.89666
      ],
      78: [
        0,
        0.68333,
        0.16389,
        0,
        0.74333
      ],
      79: [
        0,
        0.68333,
        0.09403,
        0,
        0.76666
      ],
      80: [
        0,
        0.68333,
        0.10257,
        0,
        0.67833
      ],
      81: [
        0.19444,
        0.68333,
        0.09403,
        0,
        0.76666
      ],
      82: [
        0,
        0.68333,
        0.03868,
        0,
        0.72944
      ],
      83: [
        0,
        0.68333,
        0.11972,
        0,
        0.56222
      ],
      84: [
        0,
        0.68333,
        0.13305,
        0,
        0.71555
      ],
      85: [
        0,
        0.68333,
        0.16389,
        0,
        0.74333
      ],
      86: [
        0,
        0.68333,
        0.18361,
        0,
        0.74333
      ],
      87: [
        0,
        0.68333,
        0.18361,
        0,
        0.99888
      ],
      88: [
        0,
        0.68333,
        0.15806,
        0,
        0.74333
      ],
      89: [
        0,
        0.68333,
        0.19383,
        0,
        0.74333
      ],
      90: [
        0,
        0.68333,
        0.14528,
        0,
        0.61333
      ],
      91: [
        0.25,
        0.75,
        0.1875,
        0,
        0.30667
      ],
      93: [
        0.25,
        0.75,
        0.10528,
        0,
        0.30667
      ],
      94: [
        0,
        0.69444,
        0.06646,
        0,
        0.51111
      ],
      95: [
        0.31,
        0.12056,
        0.09208,
        0,
        0.51111
      ],
      97: [
        0,
        0.43056,
        0.07671,
        0,
        0.51111
      ],
      98: [
        0,
        0.69444,
        0.06312,
        0,
        0.46
      ],
      99: [
        0,
        0.43056,
        0.05653,
        0,
        0.46
      ],
      100: [
        0,
        0.69444,
        0.10333,
        0,
        0.51111
      ],
      101: [
        0,
        0.43056,
        0.07514,
        0,
        0.46
      ],
      102: [
        0.19444,
        0.69444,
        0.21194,
        0,
        0.30667
      ],
      103: [
        0.19444,
        0.43056,
        0.08847,
        0,
        0.46
      ],
      104: [
        0,
        0.69444,
        0.07671,
        0,
        0.51111
      ],
      105: [
        0,
        0.65536,
        0.1019,
        0,
        0.30667
      ],
      106: [
        0.19444,
        0.65536,
        0.14467,
        0,
        0.30667
      ],
      107: [
        0,
        0.69444,
        0.10764,
        0,
        0.46
      ],
      108: [
        0,
        0.69444,
        0.10333,
        0,
        0.25555
      ],
      109: [
        0,
        0.43056,
        0.07671,
        0,
        0.81777
      ],
      110: [
        0,
        0.43056,
        0.07671,
        0,
        0.56222
      ],
      111: [
        0,
        0.43056,
        0.06312,
        0,
        0.51111
      ],
      112: [
        0.19444,
        0.43056,
        0.06312,
        0,
        0.51111
      ],
      113: [
        0.19444,
        0.43056,
        0.08847,
        0,
        0.46
      ],
      114: [
        0,
        0.43056,
        0.10764,
        0,
        0.42166
      ],
      115: [
        0,
        0.43056,
        0.08208,
        0,
        0.40889
      ],
      116: [
        0,
        0.61508,
        0.09486,
        0,
        0.33222
      ],
      117: [
        0,
        0.43056,
        0.07671,
        0,
        0.53666
      ],
      118: [
        0,
        0.43056,
        0.10764,
        0,
        0.46
      ],
      119: [
        0,
        0.43056,
        0.10764,
        0,
        0.66444
      ],
      120: [
        0,
        0.43056,
        0.12042,
        0,
        0.46389
      ],
      121: [
        0.19444,
        0.43056,
        0.08847,
        0,
        0.48555
      ],
      122: [
        0,
        0.43056,
        0.12292,
        0,
        0.40889
      ],
      126: [
        0.35,
        0.31786,
        0.11585,
        0,
        0.51111
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      168: [
        0,
        0.66786,
        0.10474,
        0,
        0.51111
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.83129
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.46
      ],
      198: [
        0,
        0.68333,
        0.12028,
        0,
        0.88277
      ],
      216: [
        0.04861,
        0.73194,
        0.09403,
        0,
        0.76666
      ],
      223: [
        0.19444,
        0.69444,
        0.10514,
        0,
        0.53666
      ],
      230: [
        0,
        0.43056,
        0.07514,
        0,
        0.71555
      ],
      248: [
        0.09722,
        0.52778,
        0.09194,
        0,
        0.51111
      ],
      338: [
        0,
        0.68333,
        0.12028,
        0,
        0.98499
      ],
      339: [
        0,
        0.43056,
        0.07514,
        0,
        0.71555
      ],
      710: [
        0,
        0.69444,
        0.06646,
        0,
        0.51111
      ],
      711: [
        0,
        0.62847,
        0.08295,
        0,
        0.51111
      ],
      713: [
        0,
        0.56167,
        0.10333,
        0,
        0.51111
      ],
      714: [
        0,
        0.69444,
        0.09694,
        0,
        0.51111
      ],
      715: [
        0,
        0.69444,
        0,
        0,
        0.51111
      ],
      728: [
        0,
        0.69444,
        0.10806,
        0,
        0.51111
      ],
      729: [
        0,
        0.66786,
        0.11752,
        0,
        0.30667
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.83129
      ],
      732: [
        0,
        0.66786,
        0.11585,
        0,
        0.51111
      ],
      733: [
        0,
        0.69444,
        0.1225,
        0,
        0.51111
      ],
      915: [
        0,
        0.68333,
        0.13305,
        0,
        0.62722
      ],
      916: [
        0,
        0.68333,
        0,
        0,
        0.81777
      ],
      920: [
        0,
        0.68333,
        0.09403,
        0,
        0.76666
      ],
      923: [
        0,
        0.68333,
        0,
        0,
        0.69222
      ],
      926: [
        0,
        0.68333,
        0.15294,
        0,
        0.66444
      ],
      928: [
        0,
        0.68333,
        0.16389,
        0,
        0.74333
      ],
      931: [
        0,
        0.68333,
        0.12028,
        0,
        0.71555
      ],
      933: [
        0,
        0.68333,
        0.11111,
        0,
        0.76666
      ],
      934: [
        0,
        0.68333,
        0.05986,
        0,
        0.71555
      ],
      936: [
        0,
        0.68333,
        0.11111,
        0,
        0.76666
      ],
      937: [
        0,
        0.68333,
        0.10257,
        0,
        0.71555
      ],
      8211: [
        0,
        0.43056,
        0.09208,
        0,
        0.51111
      ],
      8212: [
        0,
        0.43056,
        0.09208,
        0,
        1.02222
      ],
      8216: [
        0,
        0.69444,
        0.12417,
        0,
        0.30667
      ],
      8217: [
        0,
        0.69444,
        0.12417,
        0,
        0.30667
      ],
      8220: [
        0,
        0.69444,
        0.1685,
        0,
        0.51444
      ],
      8221: [
        0,
        0.69444,
        0.06961,
        0,
        0.51444
      ],
      8463: [
        0,
        0.68889,
        0,
        0,
        0.54028
      ]
    },
    "Main-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      34: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      35: [
        0.19444,
        0.69444,
        0,
        0,
        0.83334
      ],
      36: [
        0.05556,
        0.75,
        0,
        0,
        0.5
      ],
      37: [
        0.05556,
        0.75,
        0,
        0,
        0.83334
      ],
      38: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      39: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      40: [
        0.25,
        0.75,
        0,
        0,
        0.38889
      ],
      41: [
        0.25,
        0.75,
        0,
        0,
        0.38889
      ],
      42: [
        0,
        0.75,
        0,
        0,
        0.5
      ],
      43: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      44: [
        0.19444,
        0.10556,
        0,
        0,
        0.27778
      ],
      45: [
        0,
        0.43056,
        0,
        0,
        0.33333
      ],
      46: [
        0,
        0.10556,
        0,
        0,
        0.27778
      ],
      47: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      48: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      49: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      50: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      51: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      52: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      53: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      54: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      55: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      56: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      57: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      58: [
        0,
        0.43056,
        0,
        0,
        0.27778
      ],
      59: [
        0.19444,
        0.43056,
        0,
        0,
        0.27778
      ],
      60: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      61: [
        -0.13313,
        0.36687,
        0,
        0,
        0.77778
      ],
      62: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      63: [
        0,
        0.69444,
        0,
        0,
        0.47222
      ],
      64: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      65: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      66: [
        0,
        0.68333,
        0,
        0,
        0.70834
      ],
      67: [
        0,
        0.68333,
        0,
        0,
        0.72222
      ],
      68: [
        0,
        0.68333,
        0,
        0,
        0.76389
      ],
      69: [
        0,
        0.68333,
        0,
        0,
        0.68056
      ],
      70: [
        0,
        0.68333,
        0,
        0,
        0.65278
      ],
      71: [
        0,
        0.68333,
        0,
        0,
        0.78472
      ],
      72: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      73: [
        0,
        0.68333,
        0,
        0,
        0.36111
      ],
      74: [
        0,
        0.68333,
        0,
        0,
        0.51389
      ],
      75: [
        0,
        0.68333,
        0,
        0,
        0.77778
      ],
      76: [
        0,
        0.68333,
        0,
        0,
        0.625
      ],
      77: [
        0,
        0.68333,
        0,
        0,
        0.91667
      ],
      78: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      79: [
        0,
        0.68333,
        0,
        0,
        0.77778
      ],
      80: [
        0,
        0.68333,
        0,
        0,
        0.68056
      ],
      81: [
        0.19444,
        0.68333,
        0,
        0,
        0.77778
      ],
      82: [
        0,
        0.68333,
        0,
        0,
        0.73611
      ],
      83: [
        0,
        0.68333,
        0,
        0,
        0.55556
      ],
      84: [
        0,
        0.68333,
        0,
        0,
        0.72222
      ],
      85: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      86: [
        0,
        0.68333,
        0.01389,
        0,
        0.75
      ],
      87: [
        0,
        0.68333,
        0.01389,
        0,
        1.02778
      ],
      88: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      89: [
        0,
        0.68333,
        0.025,
        0,
        0.75
      ],
      90: [
        0,
        0.68333,
        0,
        0,
        0.61111
      ],
      91: [
        0.25,
        0.75,
        0,
        0,
        0.27778
      ],
      92: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      93: [
        0.25,
        0.75,
        0,
        0,
        0.27778
      ],
      94: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      95: [
        0.31,
        0.12056,
        0.02778,
        0,
        0.5
      ],
      97: [
        0,
        0.43056,
        0,
        0,
        0.5
      ],
      98: [
        0,
        0.69444,
        0,
        0,
        0.55556
      ],
      99: [
        0,
        0.43056,
        0,
        0,
        0.44445
      ],
      100: [
        0,
        0.69444,
        0,
        0,
        0.55556
      ],
      101: [
        0,
        0.43056,
        0,
        0,
        0.44445
      ],
      102: [
        0,
        0.69444,
        0.07778,
        0,
        0.30556
      ],
      103: [
        0.19444,
        0.43056,
        0.01389,
        0,
        0.5
      ],
      104: [
        0,
        0.69444,
        0,
        0,
        0.55556
      ],
      105: [
        0,
        0.66786,
        0,
        0,
        0.27778
      ],
      106: [
        0.19444,
        0.66786,
        0,
        0,
        0.30556
      ],
      107: [
        0,
        0.69444,
        0,
        0,
        0.52778
      ],
      108: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      109: [
        0,
        0.43056,
        0,
        0,
        0.83334
      ],
      110: [
        0,
        0.43056,
        0,
        0,
        0.55556
      ],
      111: [
        0,
        0.43056,
        0,
        0,
        0.5
      ],
      112: [
        0.19444,
        0.43056,
        0,
        0,
        0.55556
      ],
      113: [
        0.19444,
        0.43056,
        0,
        0,
        0.52778
      ],
      114: [
        0,
        0.43056,
        0,
        0,
        0.39167
      ],
      115: [
        0,
        0.43056,
        0,
        0,
        0.39445
      ],
      116: [
        0,
        0.61508,
        0,
        0,
        0.38889
      ],
      117: [
        0,
        0.43056,
        0,
        0,
        0.55556
      ],
      118: [
        0,
        0.43056,
        0.01389,
        0,
        0.52778
      ],
      119: [
        0,
        0.43056,
        0.01389,
        0,
        0.72222
      ],
      120: [
        0,
        0.43056,
        0,
        0,
        0.52778
      ],
      121: [
        0.19444,
        0.43056,
        0.01389,
        0,
        0.52778
      ],
      122: [
        0,
        0.43056,
        0,
        0,
        0.44445
      ],
      123: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      124: [
        0.25,
        0.75,
        0,
        0,
        0.27778
      ],
      125: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      126: [
        0.35,
        0.31786,
        0,
        0,
        0.5
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      163: [
        0,
        0.69444,
        0,
        0,
        0.76909
      ],
      167: [
        0.19444,
        0.69444,
        0,
        0,
        0.44445
      ],
      168: [
        0,
        0.66786,
        0,
        0,
        0.5
      ],
      172: [
        0,
        0.43056,
        0,
        0,
        0.66667
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.75
      ],
      177: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      182: [
        0.19444,
        0.69444,
        0,
        0,
        0.61111
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.44445
      ],
      198: [
        0,
        0.68333,
        0,
        0,
        0.90278
      ],
      215: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      216: [
        0.04861,
        0.73194,
        0,
        0,
        0.77778
      ],
      223: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      230: [
        0,
        0.43056,
        0,
        0,
        0.72222
      ],
      247: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      248: [
        0.09722,
        0.52778,
        0,
        0,
        0.5
      ],
      305: [
        0,
        0.43056,
        0,
        0,
        0.27778
      ],
      338: [
        0,
        0.68333,
        0,
        0,
        1.01389
      ],
      339: [
        0,
        0.43056,
        0,
        0,
        0.77778
      ],
      567: [
        0.19444,
        0.43056,
        0,
        0,
        0.30556
      ],
      710: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      711: [
        0,
        0.62847,
        0,
        0,
        0.5
      ],
      713: [
        0,
        0.56778,
        0,
        0,
        0.5
      ],
      714: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      715: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      728: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      729: [
        0,
        0.66786,
        0,
        0,
        0.27778
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.75
      ],
      732: [
        0,
        0.66786,
        0,
        0,
        0.5
      ],
      733: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      915: [
        0,
        0.68333,
        0,
        0,
        0.625
      ],
      916: [
        0,
        0.68333,
        0,
        0,
        0.83334
      ],
      920: [
        0,
        0.68333,
        0,
        0,
        0.77778
      ],
      923: [
        0,
        0.68333,
        0,
        0,
        0.69445
      ],
      926: [
        0,
        0.68333,
        0,
        0,
        0.66667
      ],
      928: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      931: [
        0,
        0.68333,
        0,
        0,
        0.72222
      ],
      933: [
        0,
        0.68333,
        0,
        0,
        0.77778
      ],
      934: [
        0,
        0.68333,
        0,
        0,
        0.72222
      ],
      936: [
        0,
        0.68333,
        0,
        0,
        0.77778
      ],
      937: [
        0,
        0.68333,
        0,
        0,
        0.72222
      ],
      8211: [
        0,
        0.43056,
        0.02778,
        0,
        0.5
      ],
      8212: [
        0,
        0.43056,
        0.02778,
        0,
        1
      ],
      8216: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      8217: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      8220: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      8221: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      8224: [
        0.19444,
        0.69444,
        0,
        0,
        0.44445
      ],
      8225: [
        0.19444,
        0.69444,
        0,
        0,
        0.44445
      ],
      8230: [
        0,
        0.123,
        0,
        0,
        1.172
      ],
      8242: [
        0,
        0.55556,
        0,
        0,
        0.275
      ],
      8407: [
        0,
        0.71444,
        0.15382,
        0,
        0.5
      ],
      8463: [
        0,
        0.68889,
        0,
        0,
        0.54028
      ],
      8465: [
        0,
        0.69444,
        0,
        0,
        0.72222
      ],
      8467: [
        0,
        0.69444,
        0,
        0.11111,
        0.41667
      ],
      8472: [
        0.19444,
        0.43056,
        0,
        0.11111,
        0.63646
      ],
      8476: [
        0,
        0.69444,
        0,
        0,
        0.72222
      ],
      8501: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      8592: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8593: [
        0.19444,
        0.69444,
        0,
        0,
        0.5
      ],
      8594: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8595: [
        0.19444,
        0.69444,
        0,
        0,
        0.5
      ],
      8596: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8597: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      8598: [
        0.19444,
        0.69444,
        0,
        0,
        1
      ],
      8599: [
        0.19444,
        0.69444,
        0,
        0,
        1
      ],
      8600: [
        0.19444,
        0.69444,
        0,
        0,
        1
      ],
      8601: [
        0.19444,
        0.69444,
        0,
        0,
        1
      ],
      8614: [
        0.011,
        0.511,
        0,
        0,
        1
      ],
      8617: [
        0.011,
        0.511,
        0,
        0,
        1.126
      ],
      8618: [
        0.011,
        0.511,
        0,
        0,
        1.126
      ],
      8636: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8637: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8640: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8641: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8652: [
        0.011,
        0.671,
        0,
        0,
        1
      ],
      8656: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8657: [
        0.19444,
        0.69444,
        0,
        0,
        0.61111
      ],
      8658: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8659: [
        0.19444,
        0.69444,
        0,
        0,
        0.61111
      ],
      8660: [
        -0.13313,
        0.36687,
        0,
        0,
        1
      ],
      8661: [
        0.25,
        0.75,
        0,
        0,
        0.61111
      ],
      8704: [
        0,
        0.69444,
        0,
        0,
        0.55556
      ],
      8706: [
        0,
        0.69444,
        0.05556,
        0.08334,
        0.5309
      ],
      8707: [
        0,
        0.69444,
        0,
        0,
        0.55556
      ],
      8709: [
        0.05556,
        0.75,
        0,
        0,
        0.5
      ],
      8711: [
        0,
        0.68333,
        0,
        0,
        0.83334
      ],
      8712: [
        0.0391,
        0.5391,
        0,
        0,
        0.66667
      ],
      8715: [
        0.0391,
        0.5391,
        0,
        0,
        0.66667
      ],
      8722: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8723: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8725: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      8726: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      8727: [
        -0.03472,
        0.46528,
        0,
        0,
        0.5
      ],
      8728: [
        -0.05555,
        0.44445,
        0,
        0,
        0.5
      ],
      8729: [
        -0.05555,
        0.44445,
        0,
        0,
        0.5
      ],
      8730: [
        0.2,
        0.8,
        0,
        0,
        0.83334
      ],
      8733: [
        0,
        0.43056,
        0,
        0,
        0.77778
      ],
      8734: [
        0,
        0.43056,
        0,
        0,
        1
      ],
      8736: [
        0,
        0.69224,
        0,
        0,
        0.72222
      ],
      8739: [
        0.25,
        0.75,
        0,
        0,
        0.27778
      ],
      8741: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      8743: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8744: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8745: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8746: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8747: [
        0.19444,
        0.69444,
        0.11111,
        0,
        0.41667
      ],
      8764: [
        -0.13313,
        0.36687,
        0,
        0,
        0.77778
      ],
      8768: [
        0.19444,
        0.69444,
        0,
        0,
        0.27778
      ],
      8771: [
        -0.03625,
        0.46375,
        0,
        0,
        0.77778
      ],
      8773: [
        -0.022,
        0.589,
        0,
        0,
        0.778
      ],
      8776: [
        -0.01688,
        0.48312,
        0,
        0,
        0.77778
      ],
      8781: [
        -0.03625,
        0.46375,
        0,
        0,
        0.77778
      ],
      8784: [
        -0.133,
        0.673,
        0,
        0,
        0.778
      ],
      8801: [
        -0.03625,
        0.46375,
        0,
        0,
        0.77778
      ],
      8804: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8805: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8810: [
        0.0391,
        0.5391,
        0,
        0,
        1
      ],
      8811: [
        0.0391,
        0.5391,
        0,
        0,
        1
      ],
      8826: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      8827: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      8834: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      8835: [
        0.0391,
        0.5391,
        0,
        0,
        0.77778
      ],
      8838: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8839: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8846: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8849: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8850: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      8851: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8852: [
        0,
        0.55556,
        0,
        0,
        0.66667
      ],
      8853: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8854: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8855: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8856: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8857: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      8866: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      8867: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      8868: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      8869: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      8872: [
        0.249,
        0.75,
        0,
        0,
        0.867
      ],
      8900: [
        -0.05555,
        0.44445,
        0,
        0,
        0.5
      ],
      8901: [
        -0.05555,
        0.44445,
        0,
        0,
        0.27778
      ],
      8902: [
        -0.03472,
        0.46528,
        0,
        0,
        0.5
      ],
      8904: [
        5e-3,
        0.505,
        0,
        0,
        0.9
      ],
      8942: [
        0.03,
        0.903,
        0,
        0,
        0.278
      ],
      8943: [
        -0.19,
        0.313,
        0,
        0,
        1.172
      ],
      8945: [
        -0.1,
        0.823,
        0,
        0,
        1.282
      ],
      8968: [
        0.25,
        0.75,
        0,
        0,
        0.44445
      ],
      8969: [
        0.25,
        0.75,
        0,
        0,
        0.44445
      ],
      8970: [
        0.25,
        0.75,
        0,
        0,
        0.44445
      ],
      8971: [
        0.25,
        0.75,
        0,
        0,
        0.44445
      ],
      8994: [
        -0.14236,
        0.35764,
        0,
        0,
        1
      ],
      8995: [
        -0.14236,
        0.35764,
        0,
        0,
        1
      ],
      9136: [
        0.244,
        0.744,
        0,
        0,
        0.412
      ],
      9137: [
        0.244,
        0.745,
        0,
        0,
        0.412
      ],
      9651: [
        0.19444,
        0.69444,
        0,
        0,
        0.88889
      ],
      9657: [
        -0.03472,
        0.46528,
        0,
        0,
        0.5
      ],
      9661: [
        0.19444,
        0.69444,
        0,
        0,
        0.88889
      ],
      9667: [
        -0.03472,
        0.46528,
        0,
        0,
        0.5
      ],
      9711: [
        0.19444,
        0.69444,
        0,
        0,
        1
      ],
      9824: [
        0.12963,
        0.69444,
        0,
        0,
        0.77778
      ],
      9825: [
        0.12963,
        0.69444,
        0,
        0,
        0.77778
      ],
      9826: [
        0.12963,
        0.69444,
        0,
        0,
        0.77778
      ],
      9827: [
        0.12963,
        0.69444,
        0,
        0,
        0.77778
      ],
      9837: [
        0,
        0.75,
        0,
        0,
        0.38889
      ],
      9838: [
        0.19444,
        0.69444,
        0,
        0,
        0.38889
      ],
      9839: [
        0.19444,
        0.69444,
        0,
        0,
        0.38889
      ],
      10216: [
        0.25,
        0.75,
        0,
        0,
        0.38889
      ],
      10217: [
        0.25,
        0.75,
        0,
        0,
        0.38889
      ],
      10222: [
        0.244,
        0.744,
        0,
        0,
        0.412
      ],
      10223: [
        0.244,
        0.745,
        0,
        0,
        0.412
      ],
      10229: [
        0.011,
        0.511,
        0,
        0,
        1.609
      ],
      10230: [
        0.011,
        0.511,
        0,
        0,
        1.638
      ],
      10231: [
        0.011,
        0.511,
        0,
        0,
        1.859
      ],
      10232: [
        0.024,
        0.525,
        0,
        0,
        1.609
      ],
      10233: [
        0.024,
        0.525,
        0,
        0,
        1.638
      ],
      10234: [
        0.024,
        0.525,
        0,
        0,
        1.858
      ],
      10236: [
        0.011,
        0.511,
        0,
        0,
        1.638
      ],
      10815: [
        0,
        0.68333,
        0,
        0,
        0.75
      ],
      10927: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      10928: [
        0.13597,
        0.63597,
        0,
        0,
        0.77778
      ],
      57376: [
        0.19444,
        0.69444,
        0,
        0,
        0
      ]
    },
    "Math-BoldItalic": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      48: [
        0,
        0.44444,
        0,
        0,
        0.575
      ],
      49: [
        0,
        0.44444,
        0,
        0,
        0.575
      ],
      50: [
        0,
        0.44444,
        0,
        0,
        0.575
      ],
      51: [
        0.19444,
        0.44444,
        0,
        0,
        0.575
      ],
      52: [
        0.19444,
        0.44444,
        0,
        0,
        0.575
      ],
      53: [
        0.19444,
        0.44444,
        0,
        0,
        0.575
      ],
      54: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      55: [
        0.19444,
        0.44444,
        0,
        0,
        0.575
      ],
      56: [
        0,
        0.64444,
        0,
        0,
        0.575
      ],
      57: [
        0.19444,
        0.44444,
        0,
        0,
        0.575
      ],
      65: [
        0,
        0.68611,
        0,
        0,
        0.86944
      ],
      66: [
        0,
        0.68611,
        0.04835,
        0,
        0.8664
      ],
      67: [
        0,
        0.68611,
        0.06979,
        0,
        0.81694
      ],
      68: [
        0,
        0.68611,
        0.03194,
        0,
        0.93812
      ],
      69: [
        0,
        0.68611,
        0.05451,
        0,
        0.81007
      ],
      70: [
        0,
        0.68611,
        0.15972,
        0,
        0.68889
      ],
      71: [
        0,
        0.68611,
        0,
        0,
        0.88673
      ],
      72: [
        0,
        0.68611,
        0.08229,
        0,
        0.98229
      ],
      73: [
        0,
        0.68611,
        0.07778,
        0,
        0.51111
      ],
      74: [
        0,
        0.68611,
        0.10069,
        0,
        0.63125
      ],
      75: [
        0,
        0.68611,
        0.06979,
        0,
        0.97118
      ],
      76: [
        0,
        0.68611,
        0,
        0,
        0.75555
      ],
      77: [
        0,
        0.68611,
        0.11424,
        0,
        1.14201
      ],
      78: [
        0,
        0.68611,
        0.11424,
        0,
        0.95034
      ],
      79: [
        0,
        0.68611,
        0.03194,
        0,
        0.83666
      ],
      80: [
        0,
        0.68611,
        0.15972,
        0,
        0.72309
      ],
      81: [
        0.19444,
        0.68611,
        0,
        0,
        0.86861
      ],
      82: [
        0,
        0.68611,
        421e-5,
        0,
        0.87235
      ],
      83: [
        0,
        0.68611,
        0.05382,
        0,
        0.69271
      ],
      84: [
        0,
        0.68611,
        0.15972,
        0,
        0.63663
      ],
      85: [
        0,
        0.68611,
        0.11424,
        0,
        0.80027
      ],
      86: [
        0,
        0.68611,
        0.25555,
        0,
        0.67778
      ],
      87: [
        0,
        0.68611,
        0.15972,
        0,
        1.09305
      ],
      88: [
        0,
        0.68611,
        0.07778,
        0,
        0.94722
      ],
      89: [
        0,
        0.68611,
        0.25555,
        0,
        0.67458
      ],
      90: [
        0,
        0.68611,
        0.06979,
        0,
        0.77257
      ],
      97: [
        0,
        0.44444,
        0,
        0,
        0.63287
      ],
      98: [
        0,
        0.69444,
        0,
        0,
        0.52083
      ],
      99: [
        0,
        0.44444,
        0,
        0,
        0.51342
      ],
      100: [
        0,
        0.69444,
        0,
        0,
        0.60972
      ],
      101: [
        0,
        0.44444,
        0,
        0,
        0.55361
      ],
      102: [
        0.19444,
        0.69444,
        0.11042,
        0,
        0.56806
      ],
      103: [
        0.19444,
        0.44444,
        0.03704,
        0,
        0.5449
      ],
      104: [
        0,
        0.69444,
        0,
        0,
        0.66759
      ],
      105: [
        0,
        0.69326,
        0,
        0,
        0.4048
      ],
      106: [
        0.19444,
        0.69326,
        0.0622,
        0,
        0.47083
      ],
      107: [
        0,
        0.69444,
        0.01852,
        0,
        0.6037
      ],
      108: [
        0,
        0.69444,
        88e-4,
        0,
        0.34815
      ],
      109: [
        0,
        0.44444,
        0,
        0,
        1.0324
      ],
      110: [
        0,
        0.44444,
        0,
        0,
        0.71296
      ],
      111: [
        0,
        0.44444,
        0,
        0,
        0.58472
      ],
      112: [
        0.19444,
        0.44444,
        0,
        0,
        0.60092
      ],
      113: [
        0.19444,
        0.44444,
        0.03704,
        0,
        0.54213
      ],
      114: [
        0,
        0.44444,
        0.03194,
        0,
        0.5287
      ],
      115: [
        0,
        0.44444,
        0,
        0,
        0.53125
      ],
      116: [
        0,
        0.63492,
        0,
        0,
        0.41528
      ],
      117: [
        0,
        0.44444,
        0,
        0,
        0.68102
      ],
      118: [
        0,
        0.44444,
        0.03704,
        0,
        0.56666
      ],
      119: [
        0,
        0.44444,
        0.02778,
        0,
        0.83148
      ],
      120: [
        0,
        0.44444,
        0,
        0,
        0.65903
      ],
      121: [
        0.19444,
        0.44444,
        0.03704,
        0,
        0.59028
      ],
      122: [
        0,
        0.44444,
        0.04213,
        0,
        0.55509
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      915: [
        0,
        0.68611,
        0.15972,
        0,
        0.65694
      ],
      916: [
        0,
        0.68611,
        0,
        0,
        0.95833
      ],
      920: [
        0,
        0.68611,
        0.03194,
        0,
        0.86722
      ],
      923: [
        0,
        0.68611,
        0,
        0,
        0.80555
      ],
      926: [
        0,
        0.68611,
        0.07458,
        0,
        0.84125
      ],
      928: [
        0,
        0.68611,
        0.08229,
        0,
        0.98229
      ],
      931: [
        0,
        0.68611,
        0.05451,
        0,
        0.88507
      ],
      933: [
        0,
        0.68611,
        0.15972,
        0,
        0.67083
      ],
      934: [
        0,
        0.68611,
        0,
        0,
        0.76666
      ],
      936: [
        0,
        0.68611,
        0.11653,
        0,
        0.71402
      ],
      937: [
        0,
        0.68611,
        0.04835,
        0,
        0.8789
      ],
      945: [
        0,
        0.44444,
        0,
        0,
        0.76064
      ],
      946: [
        0.19444,
        0.69444,
        0.03403,
        0,
        0.65972
      ],
      947: [
        0.19444,
        0.44444,
        0.06389,
        0,
        0.59003
      ],
      948: [
        0,
        0.69444,
        0.03819,
        0,
        0.52222
      ],
      949: [
        0,
        0.44444,
        0,
        0,
        0.52882
      ],
      950: [
        0.19444,
        0.69444,
        0.06215,
        0,
        0.50833
      ],
      951: [
        0.19444,
        0.44444,
        0.03704,
        0,
        0.6
      ],
      952: [
        0,
        0.69444,
        0.03194,
        0,
        0.5618
      ],
      953: [
        0,
        0.44444,
        0,
        0,
        0.41204
      ],
      954: [
        0,
        0.44444,
        0,
        0,
        0.66759
      ],
      955: [
        0,
        0.69444,
        0,
        0,
        0.67083
      ],
      956: [
        0.19444,
        0.44444,
        0,
        0,
        0.70787
      ],
      957: [
        0,
        0.44444,
        0.06898,
        0,
        0.57685
      ],
      958: [
        0.19444,
        0.69444,
        0.03021,
        0,
        0.50833
      ],
      959: [
        0,
        0.44444,
        0,
        0,
        0.58472
      ],
      960: [
        0,
        0.44444,
        0.03704,
        0,
        0.68241
      ],
      961: [
        0.19444,
        0.44444,
        0,
        0,
        0.6118
      ],
      962: [
        0.09722,
        0.44444,
        0.07917,
        0,
        0.42361
      ],
      963: [
        0,
        0.44444,
        0.03704,
        0,
        0.68588
      ],
      964: [
        0,
        0.44444,
        0.13472,
        0,
        0.52083
      ],
      965: [
        0,
        0.44444,
        0.03704,
        0,
        0.63055
      ],
      966: [
        0.19444,
        0.44444,
        0,
        0,
        0.74722
      ],
      967: [
        0.19444,
        0.44444,
        0,
        0,
        0.71805
      ],
      968: [
        0.19444,
        0.69444,
        0.03704,
        0,
        0.75833
      ],
      969: [
        0,
        0.44444,
        0.03704,
        0,
        0.71782
      ],
      977: [
        0,
        0.69444,
        0,
        0,
        0.69155
      ],
      981: [
        0.19444,
        0.69444,
        0,
        0,
        0.7125
      ],
      982: [
        0,
        0.44444,
        0.03194,
        0,
        0.975
      ],
      1009: [
        0.19444,
        0.44444,
        0,
        0,
        0.6118
      ],
      1013: [
        0,
        0.44444,
        0,
        0,
        0.48333
      ],
      57649: [
        0,
        0.44444,
        0,
        0,
        0.39352
      ],
      57911: [
        0.19444,
        0.44444,
        0,
        0,
        0.43889
      ]
    },
    "Math-Italic": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      48: [
        0,
        0.43056,
        0,
        0,
        0.5
      ],
      49: [
        0,
        0.43056,
        0,
        0,
        0.5
      ],
      50: [
        0,
        0.43056,
        0,
        0,
        0.5
      ],
      51: [
        0.19444,
        0.43056,
        0,
        0,
        0.5
      ],
      52: [
        0.19444,
        0.43056,
        0,
        0,
        0.5
      ],
      53: [
        0.19444,
        0.43056,
        0,
        0,
        0.5
      ],
      54: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      55: [
        0.19444,
        0.43056,
        0,
        0,
        0.5
      ],
      56: [
        0,
        0.64444,
        0,
        0,
        0.5
      ],
      57: [
        0.19444,
        0.43056,
        0,
        0,
        0.5
      ],
      65: [
        0,
        0.68333,
        0,
        0.13889,
        0.75
      ],
      66: [
        0,
        0.68333,
        0.05017,
        0.08334,
        0.75851
      ],
      67: [
        0,
        0.68333,
        0.07153,
        0.08334,
        0.71472
      ],
      68: [
        0,
        0.68333,
        0.02778,
        0.05556,
        0.82792
      ],
      69: [
        0,
        0.68333,
        0.05764,
        0.08334,
        0.7382
      ],
      70: [
        0,
        0.68333,
        0.13889,
        0.08334,
        0.64306
      ],
      71: [
        0,
        0.68333,
        0,
        0.08334,
        0.78625
      ],
      72: [
        0,
        0.68333,
        0.08125,
        0.05556,
        0.83125
      ],
      73: [
        0,
        0.68333,
        0.07847,
        0.11111,
        0.43958
      ],
      74: [
        0,
        0.68333,
        0.09618,
        0.16667,
        0.55451
      ],
      75: [
        0,
        0.68333,
        0.07153,
        0.05556,
        0.84931
      ],
      76: [
        0,
        0.68333,
        0,
        0.02778,
        0.68056
      ],
      77: [
        0,
        0.68333,
        0.10903,
        0.08334,
        0.97014
      ],
      78: [
        0,
        0.68333,
        0.10903,
        0.08334,
        0.80347
      ],
      79: [
        0,
        0.68333,
        0.02778,
        0.08334,
        0.76278
      ],
      80: [
        0,
        0.68333,
        0.13889,
        0.08334,
        0.64201
      ],
      81: [
        0.19444,
        0.68333,
        0,
        0.08334,
        0.79056
      ],
      82: [
        0,
        0.68333,
        773e-5,
        0.08334,
        0.75929
      ],
      83: [
        0,
        0.68333,
        0.05764,
        0.08334,
        0.6132
      ],
      84: [
        0,
        0.68333,
        0.13889,
        0.08334,
        0.58438
      ],
      85: [
        0,
        0.68333,
        0.10903,
        0.02778,
        0.68278
      ],
      86: [
        0,
        0.68333,
        0.22222,
        0,
        0.58333
      ],
      87: [
        0,
        0.68333,
        0.13889,
        0,
        0.94445
      ],
      88: [
        0,
        0.68333,
        0.07847,
        0.08334,
        0.82847
      ],
      89: [
        0,
        0.68333,
        0.22222,
        0,
        0.58056
      ],
      90: [
        0,
        0.68333,
        0.07153,
        0.08334,
        0.68264
      ],
      97: [
        0,
        0.43056,
        0,
        0,
        0.52859
      ],
      98: [
        0,
        0.69444,
        0,
        0,
        0.42917
      ],
      99: [
        0,
        0.43056,
        0,
        0.05556,
        0.43276
      ],
      100: [
        0,
        0.69444,
        0,
        0.16667,
        0.52049
      ],
      101: [
        0,
        0.43056,
        0,
        0.05556,
        0.46563
      ],
      102: [
        0.19444,
        0.69444,
        0.10764,
        0.16667,
        0.48959
      ],
      103: [
        0.19444,
        0.43056,
        0.03588,
        0.02778,
        0.47697
      ],
      104: [
        0,
        0.69444,
        0,
        0,
        0.57616
      ],
      105: [
        0,
        0.65952,
        0,
        0,
        0.34451
      ],
      106: [
        0.19444,
        0.65952,
        0.05724,
        0,
        0.41181
      ],
      107: [
        0,
        0.69444,
        0.03148,
        0,
        0.5206
      ],
      108: [
        0,
        0.69444,
        0.01968,
        0.08334,
        0.29838
      ],
      109: [
        0,
        0.43056,
        0,
        0,
        0.87801
      ],
      110: [
        0,
        0.43056,
        0,
        0,
        0.60023
      ],
      111: [
        0,
        0.43056,
        0,
        0.05556,
        0.48472
      ],
      112: [
        0.19444,
        0.43056,
        0,
        0.08334,
        0.50313
      ],
      113: [
        0.19444,
        0.43056,
        0.03588,
        0.08334,
        0.44641
      ],
      114: [
        0,
        0.43056,
        0.02778,
        0.05556,
        0.45116
      ],
      115: [
        0,
        0.43056,
        0,
        0.05556,
        0.46875
      ],
      116: [
        0,
        0.61508,
        0,
        0.08334,
        0.36111
      ],
      117: [
        0,
        0.43056,
        0,
        0.02778,
        0.57246
      ],
      118: [
        0,
        0.43056,
        0.03588,
        0.02778,
        0.48472
      ],
      119: [
        0,
        0.43056,
        0.02691,
        0.08334,
        0.71592
      ],
      120: [
        0,
        0.43056,
        0,
        0.02778,
        0.57153
      ],
      121: [
        0.19444,
        0.43056,
        0.03588,
        0.05556,
        0.49028
      ],
      122: [
        0,
        0.43056,
        0.04398,
        0.05556,
        0.46505
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      915: [
        0,
        0.68333,
        0.13889,
        0.08334,
        0.61528
      ],
      916: [
        0,
        0.68333,
        0,
        0.16667,
        0.83334
      ],
      920: [
        0,
        0.68333,
        0.02778,
        0.08334,
        0.76278
      ],
      923: [
        0,
        0.68333,
        0,
        0.16667,
        0.69445
      ],
      926: [
        0,
        0.68333,
        0.07569,
        0.08334,
        0.74236
      ],
      928: [
        0,
        0.68333,
        0.08125,
        0.05556,
        0.83125
      ],
      931: [
        0,
        0.68333,
        0.05764,
        0.08334,
        0.77986
      ],
      933: [
        0,
        0.68333,
        0.13889,
        0.05556,
        0.58333
      ],
      934: [
        0,
        0.68333,
        0,
        0.08334,
        0.66667
      ],
      936: [
        0,
        0.68333,
        0.11,
        0.05556,
        0.61222
      ],
      937: [
        0,
        0.68333,
        0.05017,
        0.08334,
        0.7724
      ],
      945: [
        0,
        0.43056,
        37e-4,
        0.02778,
        0.6397
      ],
      946: [
        0.19444,
        0.69444,
        0.05278,
        0.08334,
        0.56563
      ],
      947: [
        0.19444,
        0.43056,
        0.05556,
        0,
        0.51773
      ],
      948: [
        0,
        0.69444,
        0.03785,
        0.05556,
        0.44444
      ],
      949: [
        0,
        0.43056,
        0,
        0.08334,
        0.46632
      ],
      950: [
        0.19444,
        0.69444,
        0.07378,
        0.08334,
        0.4375
      ],
      951: [
        0.19444,
        0.43056,
        0.03588,
        0.05556,
        0.49653
      ],
      952: [
        0,
        0.69444,
        0.02778,
        0.08334,
        0.46944
      ],
      953: [
        0,
        0.43056,
        0,
        0.05556,
        0.35394
      ],
      954: [
        0,
        0.43056,
        0,
        0,
        0.57616
      ],
      955: [
        0,
        0.69444,
        0,
        0,
        0.58334
      ],
      956: [
        0.19444,
        0.43056,
        0,
        0.02778,
        0.60255
      ],
      957: [
        0,
        0.43056,
        0.06366,
        0.02778,
        0.49398
      ],
      958: [
        0.19444,
        0.69444,
        0.04601,
        0.11111,
        0.4375
      ],
      959: [
        0,
        0.43056,
        0,
        0.05556,
        0.48472
      ],
      960: [
        0,
        0.43056,
        0.03588,
        0,
        0.57003
      ],
      961: [
        0.19444,
        0.43056,
        0,
        0.08334,
        0.51702
      ],
      962: [
        0.09722,
        0.43056,
        0.07986,
        0.08334,
        0.36285
      ],
      963: [
        0,
        0.43056,
        0.03588,
        0,
        0.57141
      ],
      964: [
        0,
        0.43056,
        0.1132,
        0.02778,
        0.43715
      ],
      965: [
        0,
        0.43056,
        0.03588,
        0.02778,
        0.54028
      ],
      966: [
        0.19444,
        0.43056,
        0,
        0.08334,
        0.65417
      ],
      967: [
        0.19444,
        0.43056,
        0,
        0.05556,
        0.62569
      ],
      968: [
        0.19444,
        0.69444,
        0.03588,
        0.11111,
        0.65139
      ],
      969: [
        0,
        0.43056,
        0.03588,
        0,
        0.62245
      ],
      977: [
        0,
        0.69444,
        0,
        0.08334,
        0.59144
      ],
      981: [
        0.19444,
        0.69444,
        0,
        0.08334,
        0.59583
      ],
      982: [
        0,
        0.43056,
        0.02778,
        0,
        0.82813
      ],
      1009: [
        0.19444,
        0.43056,
        0,
        0.08334,
        0.51702
      ],
      1013: [
        0,
        0.43056,
        0,
        0.05556,
        0.4059
      ],
      57649: [
        0,
        0.43056,
        0,
        0.02778,
        0.32246
      ],
      57911: [
        0.19444,
        0.43056,
        0,
        0.08334,
        0.38403
      ]
    },
    "SansSerif-Bold": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0,
        0,
        0.36667
      ],
      34: [
        0,
        0.69444,
        0,
        0,
        0.55834
      ],
      35: [
        0.19444,
        0.69444,
        0,
        0,
        0.91667
      ],
      36: [
        0.05556,
        0.75,
        0,
        0,
        0.55
      ],
      37: [
        0.05556,
        0.75,
        0,
        0,
        1.02912
      ],
      38: [
        0,
        0.69444,
        0,
        0,
        0.83056
      ],
      39: [
        0,
        0.69444,
        0,
        0,
        0.30556
      ],
      40: [
        0.25,
        0.75,
        0,
        0,
        0.42778
      ],
      41: [
        0.25,
        0.75,
        0,
        0,
        0.42778
      ],
      42: [
        0,
        0.75,
        0,
        0,
        0.55
      ],
      43: [
        0.11667,
        0.61667,
        0,
        0,
        0.85556
      ],
      44: [
        0.10556,
        0.13056,
        0,
        0,
        0.30556
      ],
      45: [
        0,
        0.45833,
        0,
        0,
        0.36667
      ],
      46: [
        0,
        0.13056,
        0,
        0,
        0.30556
      ],
      47: [
        0.25,
        0.75,
        0,
        0,
        0.55
      ],
      48: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      49: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      50: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      51: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      52: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      53: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      54: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      55: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      56: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      57: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      58: [
        0,
        0.45833,
        0,
        0,
        0.30556
      ],
      59: [
        0.10556,
        0.45833,
        0,
        0,
        0.30556
      ],
      61: [
        -0.09375,
        0.40625,
        0,
        0,
        0.85556
      ],
      63: [
        0,
        0.69444,
        0,
        0,
        0.51945
      ],
      64: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      65: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      66: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      67: [
        0,
        0.69444,
        0,
        0,
        0.70278
      ],
      68: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      69: [
        0,
        0.69444,
        0,
        0,
        0.64167
      ],
      70: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      71: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      72: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      73: [
        0,
        0.69444,
        0,
        0,
        0.33056
      ],
      74: [
        0,
        0.69444,
        0,
        0,
        0.51945
      ],
      75: [
        0,
        0.69444,
        0,
        0,
        0.76389
      ],
      76: [
        0,
        0.69444,
        0,
        0,
        0.58056
      ],
      77: [
        0,
        0.69444,
        0,
        0,
        0.97778
      ],
      78: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      79: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      80: [
        0,
        0.69444,
        0,
        0,
        0.70278
      ],
      81: [
        0.10556,
        0.69444,
        0,
        0,
        0.79445
      ],
      82: [
        0,
        0.69444,
        0,
        0,
        0.70278
      ],
      83: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      84: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      85: [
        0,
        0.69444,
        0,
        0,
        0.76389
      ],
      86: [
        0,
        0.69444,
        0.01528,
        0,
        0.73334
      ],
      87: [
        0,
        0.69444,
        0.01528,
        0,
        1.03889
      ],
      88: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      89: [
        0,
        0.69444,
        0.0275,
        0,
        0.73334
      ],
      90: [
        0,
        0.69444,
        0,
        0,
        0.67223
      ],
      91: [
        0.25,
        0.75,
        0,
        0,
        0.34306
      ],
      93: [
        0.25,
        0.75,
        0,
        0,
        0.34306
      ],
      94: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      95: [
        0.35,
        0.10833,
        0.03056,
        0,
        0.55
      ],
      97: [
        0,
        0.45833,
        0,
        0,
        0.525
      ],
      98: [
        0,
        0.69444,
        0,
        0,
        0.56111
      ],
      99: [
        0,
        0.45833,
        0,
        0,
        0.48889
      ],
      100: [
        0,
        0.69444,
        0,
        0,
        0.56111
      ],
      101: [
        0,
        0.45833,
        0,
        0,
        0.51111
      ],
      102: [
        0,
        0.69444,
        0.07639,
        0,
        0.33611
      ],
      103: [
        0.19444,
        0.45833,
        0.01528,
        0,
        0.55
      ],
      104: [
        0,
        0.69444,
        0,
        0,
        0.56111
      ],
      105: [
        0,
        0.69444,
        0,
        0,
        0.25556
      ],
      106: [
        0.19444,
        0.69444,
        0,
        0,
        0.28611
      ],
      107: [
        0,
        0.69444,
        0,
        0,
        0.53056
      ],
      108: [
        0,
        0.69444,
        0,
        0,
        0.25556
      ],
      109: [
        0,
        0.45833,
        0,
        0,
        0.86667
      ],
      110: [
        0,
        0.45833,
        0,
        0,
        0.56111
      ],
      111: [
        0,
        0.45833,
        0,
        0,
        0.55
      ],
      112: [
        0.19444,
        0.45833,
        0,
        0,
        0.56111
      ],
      113: [
        0.19444,
        0.45833,
        0,
        0,
        0.56111
      ],
      114: [
        0,
        0.45833,
        0.01528,
        0,
        0.37222
      ],
      115: [
        0,
        0.45833,
        0,
        0,
        0.42167
      ],
      116: [
        0,
        0.58929,
        0,
        0,
        0.40417
      ],
      117: [
        0,
        0.45833,
        0,
        0,
        0.56111
      ],
      118: [
        0,
        0.45833,
        0.01528,
        0,
        0.5
      ],
      119: [
        0,
        0.45833,
        0.01528,
        0,
        0.74445
      ],
      120: [
        0,
        0.45833,
        0,
        0,
        0.5
      ],
      121: [
        0.19444,
        0.45833,
        0.01528,
        0,
        0.5
      ],
      122: [
        0,
        0.45833,
        0,
        0,
        0.47639
      ],
      126: [
        0.35,
        0.34444,
        0,
        0,
        0.55
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      168: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      180: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.48889
      ],
      305: [
        0,
        0.45833,
        0,
        0,
        0.25556
      ],
      567: [
        0.19444,
        0.45833,
        0,
        0,
        0.28611
      ],
      710: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      711: [
        0,
        0.63542,
        0,
        0,
        0.55
      ],
      713: [
        0,
        0.63778,
        0,
        0,
        0.55
      ],
      728: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      729: [
        0,
        0.69444,
        0,
        0,
        0.30556
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      732: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      733: [
        0,
        0.69444,
        0,
        0,
        0.55
      ],
      915: [
        0,
        0.69444,
        0,
        0,
        0.58056
      ],
      916: [
        0,
        0.69444,
        0,
        0,
        0.91667
      ],
      920: [
        0,
        0.69444,
        0,
        0,
        0.85556
      ],
      923: [
        0,
        0.69444,
        0,
        0,
        0.67223
      ],
      926: [
        0,
        0.69444,
        0,
        0,
        0.73334
      ],
      928: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      931: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      933: [
        0,
        0.69444,
        0,
        0,
        0.85556
      ],
      934: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      936: [
        0,
        0.69444,
        0,
        0,
        0.85556
      ],
      937: [
        0,
        0.69444,
        0,
        0,
        0.79445
      ],
      8211: [
        0,
        0.45833,
        0.03056,
        0,
        0.55
      ],
      8212: [
        0,
        0.45833,
        0.03056,
        0,
        1.10001
      ],
      8216: [
        0,
        0.69444,
        0,
        0,
        0.30556
      ],
      8217: [
        0,
        0.69444,
        0,
        0,
        0.30556
      ],
      8220: [
        0,
        0.69444,
        0,
        0,
        0.55834
      ],
      8221: [
        0,
        0.69444,
        0,
        0,
        0.55834
      ]
    },
    "SansSerif-Italic": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0.05733,
        0,
        0.31945
      ],
      34: [
        0,
        0.69444,
        316e-5,
        0,
        0.5
      ],
      35: [
        0.19444,
        0.69444,
        0.05087,
        0,
        0.83334
      ],
      36: [
        0.05556,
        0.75,
        0.11156,
        0,
        0.5
      ],
      37: [
        0.05556,
        0.75,
        0.03126,
        0,
        0.83334
      ],
      38: [
        0,
        0.69444,
        0.03058,
        0,
        0.75834
      ],
      39: [
        0,
        0.69444,
        0.07816,
        0,
        0.27778
      ],
      40: [
        0.25,
        0.75,
        0.13164,
        0,
        0.38889
      ],
      41: [
        0.25,
        0.75,
        0.02536,
        0,
        0.38889
      ],
      42: [
        0,
        0.75,
        0.11775,
        0,
        0.5
      ],
      43: [
        0.08333,
        0.58333,
        0.02536,
        0,
        0.77778
      ],
      44: [
        0.125,
        0.08333,
        0,
        0,
        0.27778
      ],
      45: [
        0,
        0.44444,
        0.01946,
        0,
        0.33333
      ],
      46: [
        0,
        0.08333,
        0,
        0,
        0.27778
      ],
      47: [
        0.25,
        0.75,
        0.13164,
        0,
        0.5
      ],
      48: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      49: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      50: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      51: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      52: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      53: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      54: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      55: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      56: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      57: [
        0,
        0.65556,
        0.11156,
        0,
        0.5
      ],
      58: [
        0,
        0.44444,
        0.02502,
        0,
        0.27778
      ],
      59: [
        0.125,
        0.44444,
        0.02502,
        0,
        0.27778
      ],
      61: [
        -0.13,
        0.37,
        0.05087,
        0,
        0.77778
      ],
      63: [
        0,
        0.69444,
        0.11809,
        0,
        0.47222
      ],
      64: [
        0,
        0.69444,
        0.07555,
        0,
        0.66667
      ],
      65: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      66: [
        0,
        0.69444,
        0.08293,
        0,
        0.66667
      ],
      67: [
        0,
        0.69444,
        0.11983,
        0,
        0.63889
      ],
      68: [
        0,
        0.69444,
        0.07555,
        0,
        0.72223
      ],
      69: [
        0,
        0.69444,
        0.11983,
        0,
        0.59722
      ],
      70: [
        0,
        0.69444,
        0.13372,
        0,
        0.56945
      ],
      71: [
        0,
        0.69444,
        0.11983,
        0,
        0.66667
      ],
      72: [
        0,
        0.69444,
        0.08094,
        0,
        0.70834
      ],
      73: [
        0,
        0.69444,
        0.13372,
        0,
        0.27778
      ],
      74: [
        0,
        0.69444,
        0.08094,
        0,
        0.47222
      ],
      75: [
        0,
        0.69444,
        0.11983,
        0,
        0.69445
      ],
      76: [
        0,
        0.69444,
        0,
        0,
        0.54167
      ],
      77: [
        0,
        0.69444,
        0.08094,
        0,
        0.875
      ],
      78: [
        0,
        0.69444,
        0.08094,
        0,
        0.70834
      ],
      79: [
        0,
        0.69444,
        0.07555,
        0,
        0.73611
      ],
      80: [
        0,
        0.69444,
        0.08293,
        0,
        0.63889
      ],
      81: [
        0.125,
        0.69444,
        0.07555,
        0,
        0.73611
      ],
      82: [
        0,
        0.69444,
        0.08293,
        0,
        0.64584
      ],
      83: [
        0,
        0.69444,
        0.09205,
        0,
        0.55556
      ],
      84: [
        0,
        0.69444,
        0.13372,
        0,
        0.68056
      ],
      85: [
        0,
        0.69444,
        0.08094,
        0,
        0.6875
      ],
      86: [
        0,
        0.69444,
        0.1615,
        0,
        0.66667
      ],
      87: [
        0,
        0.69444,
        0.1615,
        0,
        0.94445
      ],
      88: [
        0,
        0.69444,
        0.13372,
        0,
        0.66667
      ],
      89: [
        0,
        0.69444,
        0.17261,
        0,
        0.66667
      ],
      90: [
        0,
        0.69444,
        0.11983,
        0,
        0.61111
      ],
      91: [
        0.25,
        0.75,
        0.15942,
        0,
        0.28889
      ],
      93: [
        0.25,
        0.75,
        0.08719,
        0,
        0.28889
      ],
      94: [
        0,
        0.69444,
        0.0799,
        0,
        0.5
      ],
      95: [
        0.35,
        0.09444,
        0.08616,
        0,
        0.5
      ],
      97: [
        0,
        0.44444,
        981e-5,
        0,
        0.48056
      ],
      98: [
        0,
        0.69444,
        0.03057,
        0,
        0.51667
      ],
      99: [
        0,
        0.44444,
        0.08336,
        0,
        0.44445
      ],
      100: [
        0,
        0.69444,
        0.09483,
        0,
        0.51667
      ],
      101: [
        0,
        0.44444,
        0.06778,
        0,
        0.44445
      ],
      102: [
        0,
        0.69444,
        0.21705,
        0,
        0.30556
      ],
      103: [
        0.19444,
        0.44444,
        0.10836,
        0,
        0.5
      ],
      104: [
        0,
        0.69444,
        0.01778,
        0,
        0.51667
      ],
      105: [
        0,
        0.67937,
        0.09718,
        0,
        0.23889
      ],
      106: [
        0.19444,
        0.67937,
        0.09162,
        0,
        0.26667
      ],
      107: [
        0,
        0.69444,
        0.08336,
        0,
        0.48889
      ],
      108: [
        0,
        0.69444,
        0.09483,
        0,
        0.23889
      ],
      109: [
        0,
        0.44444,
        0.01778,
        0,
        0.79445
      ],
      110: [
        0,
        0.44444,
        0.01778,
        0,
        0.51667
      ],
      111: [
        0,
        0.44444,
        0.06613,
        0,
        0.5
      ],
      112: [
        0.19444,
        0.44444,
        0.0389,
        0,
        0.51667
      ],
      113: [
        0.19444,
        0.44444,
        0.04169,
        0,
        0.51667
      ],
      114: [
        0,
        0.44444,
        0.10836,
        0,
        0.34167
      ],
      115: [
        0,
        0.44444,
        0.0778,
        0,
        0.38333
      ],
      116: [
        0,
        0.57143,
        0.07225,
        0,
        0.36111
      ],
      117: [
        0,
        0.44444,
        0.04169,
        0,
        0.51667
      ],
      118: [
        0,
        0.44444,
        0.10836,
        0,
        0.46111
      ],
      119: [
        0,
        0.44444,
        0.10836,
        0,
        0.68334
      ],
      120: [
        0,
        0.44444,
        0.09169,
        0,
        0.46111
      ],
      121: [
        0.19444,
        0.44444,
        0.10836,
        0,
        0.46111
      ],
      122: [
        0,
        0.44444,
        0.08752,
        0,
        0.43472
      ],
      126: [
        0.35,
        0.32659,
        0.08826,
        0,
        0.5
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      168: [
        0,
        0.67937,
        0.06385,
        0,
        0.5
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.73752
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.44445
      ],
      305: [
        0,
        0.44444,
        0.04169,
        0,
        0.23889
      ],
      567: [
        0.19444,
        0.44444,
        0.04169,
        0,
        0.26667
      ],
      710: [
        0,
        0.69444,
        0.0799,
        0,
        0.5
      ],
      711: [
        0,
        0.63194,
        0.08432,
        0,
        0.5
      ],
      713: [
        0,
        0.60889,
        0.08776,
        0,
        0.5
      ],
      714: [
        0,
        0.69444,
        0.09205,
        0,
        0.5
      ],
      715: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      728: [
        0,
        0.69444,
        0.09483,
        0,
        0.5
      ],
      729: [
        0,
        0.67937,
        0.07774,
        0,
        0.27778
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.73752
      ],
      732: [
        0,
        0.67659,
        0.08826,
        0,
        0.5
      ],
      733: [
        0,
        0.69444,
        0.09205,
        0,
        0.5
      ],
      915: [
        0,
        0.69444,
        0.13372,
        0,
        0.54167
      ],
      916: [
        0,
        0.69444,
        0,
        0,
        0.83334
      ],
      920: [
        0,
        0.69444,
        0.07555,
        0,
        0.77778
      ],
      923: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      926: [
        0,
        0.69444,
        0.12816,
        0,
        0.66667
      ],
      928: [
        0,
        0.69444,
        0.08094,
        0,
        0.70834
      ],
      931: [
        0,
        0.69444,
        0.11983,
        0,
        0.72222
      ],
      933: [
        0,
        0.69444,
        0.09031,
        0,
        0.77778
      ],
      934: [
        0,
        0.69444,
        0.04603,
        0,
        0.72222
      ],
      936: [
        0,
        0.69444,
        0.09031,
        0,
        0.77778
      ],
      937: [
        0,
        0.69444,
        0.08293,
        0,
        0.72222
      ],
      8211: [
        0,
        0.44444,
        0.08616,
        0,
        0.5
      ],
      8212: [
        0,
        0.44444,
        0.08616,
        0,
        1
      ],
      8216: [
        0,
        0.69444,
        0.07816,
        0,
        0.27778
      ],
      8217: [
        0,
        0.69444,
        0.07816,
        0,
        0.27778
      ],
      8220: [
        0,
        0.69444,
        0.14205,
        0,
        0.5
      ],
      8221: [
        0,
        0.69444,
        316e-5,
        0,
        0.5
      ]
    },
    "SansSerif-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      33: [
        0,
        0.69444,
        0,
        0,
        0.31945
      ],
      34: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      35: [
        0.19444,
        0.69444,
        0,
        0,
        0.83334
      ],
      36: [
        0.05556,
        0.75,
        0,
        0,
        0.5
      ],
      37: [
        0.05556,
        0.75,
        0,
        0,
        0.83334
      ],
      38: [
        0,
        0.69444,
        0,
        0,
        0.75834
      ],
      39: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      40: [
        0.25,
        0.75,
        0,
        0,
        0.38889
      ],
      41: [
        0.25,
        0.75,
        0,
        0,
        0.38889
      ],
      42: [
        0,
        0.75,
        0,
        0,
        0.5
      ],
      43: [
        0.08333,
        0.58333,
        0,
        0,
        0.77778
      ],
      44: [
        0.125,
        0.08333,
        0,
        0,
        0.27778
      ],
      45: [
        0,
        0.44444,
        0,
        0,
        0.33333
      ],
      46: [
        0,
        0.08333,
        0,
        0,
        0.27778
      ],
      47: [
        0.25,
        0.75,
        0,
        0,
        0.5
      ],
      48: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      49: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      50: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      51: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      52: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      53: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      54: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      55: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      56: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      57: [
        0,
        0.65556,
        0,
        0,
        0.5
      ],
      58: [
        0,
        0.44444,
        0,
        0,
        0.27778
      ],
      59: [
        0.125,
        0.44444,
        0,
        0,
        0.27778
      ],
      61: [
        -0.13,
        0.37,
        0,
        0,
        0.77778
      ],
      63: [
        0,
        0.69444,
        0,
        0,
        0.47222
      ],
      64: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      65: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      66: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      67: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      68: [
        0,
        0.69444,
        0,
        0,
        0.72223
      ],
      69: [
        0,
        0.69444,
        0,
        0,
        0.59722
      ],
      70: [
        0,
        0.69444,
        0,
        0,
        0.56945
      ],
      71: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      72: [
        0,
        0.69444,
        0,
        0,
        0.70834
      ],
      73: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      74: [
        0,
        0.69444,
        0,
        0,
        0.47222
      ],
      75: [
        0,
        0.69444,
        0,
        0,
        0.69445
      ],
      76: [
        0,
        0.69444,
        0,
        0,
        0.54167
      ],
      77: [
        0,
        0.69444,
        0,
        0,
        0.875
      ],
      78: [
        0,
        0.69444,
        0,
        0,
        0.70834
      ],
      79: [
        0,
        0.69444,
        0,
        0,
        0.73611
      ],
      80: [
        0,
        0.69444,
        0,
        0,
        0.63889
      ],
      81: [
        0.125,
        0.69444,
        0,
        0,
        0.73611
      ],
      82: [
        0,
        0.69444,
        0,
        0,
        0.64584
      ],
      83: [
        0,
        0.69444,
        0,
        0,
        0.55556
      ],
      84: [
        0,
        0.69444,
        0,
        0,
        0.68056
      ],
      85: [
        0,
        0.69444,
        0,
        0,
        0.6875
      ],
      86: [
        0,
        0.69444,
        0.01389,
        0,
        0.66667
      ],
      87: [
        0,
        0.69444,
        0.01389,
        0,
        0.94445
      ],
      88: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      89: [
        0,
        0.69444,
        0.025,
        0,
        0.66667
      ],
      90: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      91: [
        0.25,
        0.75,
        0,
        0,
        0.28889
      ],
      93: [
        0.25,
        0.75,
        0,
        0,
        0.28889
      ],
      94: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      95: [
        0.35,
        0.09444,
        0.02778,
        0,
        0.5
      ],
      97: [
        0,
        0.44444,
        0,
        0,
        0.48056
      ],
      98: [
        0,
        0.69444,
        0,
        0,
        0.51667
      ],
      99: [
        0,
        0.44444,
        0,
        0,
        0.44445
      ],
      100: [
        0,
        0.69444,
        0,
        0,
        0.51667
      ],
      101: [
        0,
        0.44444,
        0,
        0,
        0.44445
      ],
      102: [
        0,
        0.69444,
        0.06944,
        0,
        0.30556
      ],
      103: [
        0.19444,
        0.44444,
        0.01389,
        0,
        0.5
      ],
      104: [
        0,
        0.69444,
        0,
        0,
        0.51667
      ],
      105: [
        0,
        0.67937,
        0,
        0,
        0.23889
      ],
      106: [
        0.19444,
        0.67937,
        0,
        0,
        0.26667
      ],
      107: [
        0,
        0.69444,
        0,
        0,
        0.48889
      ],
      108: [
        0,
        0.69444,
        0,
        0,
        0.23889
      ],
      109: [
        0,
        0.44444,
        0,
        0,
        0.79445
      ],
      110: [
        0,
        0.44444,
        0,
        0,
        0.51667
      ],
      111: [
        0,
        0.44444,
        0,
        0,
        0.5
      ],
      112: [
        0.19444,
        0.44444,
        0,
        0,
        0.51667
      ],
      113: [
        0.19444,
        0.44444,
        0,
        0,
        0.51667
      ],
      114: [
        0,
        0.44444,
        0.01389,
        0,
        0.34167
      ],
      115: [
        0,
        0.44444,
        0,
        0,
        0.38333
      ],
      116: [
        0,
        0.57143,
        0,
        0,
        0.36111
      ],
      117: [
        0,
        0.44444,
        0,
        0,
        0.51667
      ],
      118: [
        0,
        0.44444,
        0.01389,
        0,
        0.46111
      ],
      119: [
        0,
        0.44444,
        0.01389,
        0,
        0.68334
      ],
      120: [
        0,
        0.44444,
        0,
        0,
        0.46111
      ],
      121: [
        0.19444,
        0.44444,
        0.01389,
        0,
        0.46111
      ],
      122: [
        0,
        0.44444,
        0,
        0,
        0.43472
      ],
      126: [
        0.35,
        0.32659,
        0,
        0,
        0.5
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      168: [
        0,
        0.67937,
        0,
        0,
        0.5
      ],
      176: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      184: [
        0.17014,
        0,
        0,
        0,
        0.44445
      ],
      305: [
        0,
        0.44444,
        0,
        0,
        0.23889
      ],
      567: [
        0.19444,
        0.44444,
        0,
        0,
        0.26667
      ],
      710: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      711: [
        0,
        0.63194,
        0,
        0,
        0.5
      ],
      713: [
        0,
        0.60889,
        0,
        0,
        0.5
      ],
      714: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      715: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      728: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      729: [
        0,
        0.67937,
        0,
        0,
        0.27778
      ],
      730: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      732: [
        0,
        0.67659,
        0,
        0,
        0.5
      ],
      733: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      915: [
        0,
        0.69444,
        0,
        0,
        0.54167
      ],
      916: [
        0,
        0.69444,
        0,
        0,
        0.83334
      ],
      920: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      923: [
        0,
        0.69444,
        0,
        0,
        0.61111
      ],
      926: [
        0,
        0.69444,
        0,
        0,
        0.66667
      ],
      928: [
        0,
        0.69444,
        0,
        0,
        0.70834
      ],
      931: [
        0,
        0.69444,
        0,
        0,
        0.72222
      ],
      933: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      934: [
        0,
        0.69444,
        0,
        0,
        0.72222
      ],
      936: [
        0,
        0.69444,
        0,
        0,
        0.77778
      ],
      937: [
        0,
        0.69444,
        0,
        0,
        0.72222
      ],
      8211: [
        0,
        0.44444,
        0.02778,
        0,
        0.5
      ],
      8212: [
        0,
        0.44444,
        0.02778,
        0,
        1
      ],
      8216: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      8217: [
        0,
        0.69444,
        0,
        0,
        0.27778
      ],
      8220: [
        0,
        0.69444,
        0,
        0,
        0.5
      ],
      8221: [
        0,
        0.69444,
        0,
        0,
        0.5
      ]
    },
    "Script-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      65: [
        0,
        0.7,
        0.22925,
        0,
        0.80253
      ],
      66: [
        0,
        0.7,
        0.04087,
        0,
        0.90757
      ],
      67: [
        0,
        0.7,
        0.1689,
        0,
        0.66619
      ],
      68: [
        0,
        0.7,
        0.09371,
        0,
        0.77443
      ],
      69: [
        0,
        0.7,
        0.18583,
        0,
        0.56162
      ],
      70: [
        0,
        0.7,
        0.13634,
        0,
        0.89544
      ],
      71: [
        0,
        0.7,
        0.17322,
        0,
        0.60961
      ],
      72: [
        0,
        0.7,
        0.29694,
        0,
        0.96919
      ],
      73: [
        0,
        0.7,
        0.19189,
        0,
        0.80907
      ],
      74: [
        0.27778,
        0.7,
        0.19189,
        0,
        1.05159
      ],
      75: [
        0,
        0.7,
        0.31259,
        0,
        0.91364
      ],
      76: [
        0,
        0.7,
        0.19189,
        0,
        0.87373
      ],
      77: [
        0,
        0.7,
        0.15981,
        0,
        1.08031
      ],
      78: [
        0,
        0.7,
        0.3525,
        0,
        0.9015
      ],
      79: [
        0,
        0.7,
        0.08078,
        0,
        0.73787
      ],
      80: [
        0,
        0.7,
        0.08078,
        0,
        1.01262
      ],
      81: [
        0,
        0.7,
        0.03305,
        0,
        0.88282
      ],
      82: [
        0,
        0.7,
        0.06259,
        0,
        0.85
      ],
      83: [
        0,
        0.7,
        0.19189,
        0,
        0.86767
      ],
      84: [
        0,
        0.7,
        0.29087,
        0,
        0.74697
      ],
      85: [
        0,
        0.7,
        0.25815,
        0,
        0.79996
      ],
      86: [
        0,
        0.7,
        0.27523,
        0,
        0.62204
      ],
      87: [
        0,
        0.7,
        0.27523,
        0,
        0.80532
      ],
      88: [
        0,
        0.7,
        0.26006,
        0,
        0.94445
      ],
      89: [
        0,
        0.7,
        0.2939,
        0,
        0.70961
      ],
      90: [
        0,
        0.7,
        0.24037,
        0,
        0.8212
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ]
    },
    "Size1-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      40: [
        0.35001,
        0.85,
        0,
        0,
        0.45834
      ],
      41: [
        0.35001,
        0.85,
        0,
        0,
        0.45834
      ],
      47: [
        0.35001,
        0.85,
        0,
        0,
        0.57778
      ],
      91: [
        0.35001,
        0.85,
        0,
        0,
        0.41667
      ],
      92: [
        0.35001,
        0.85,
        0,
        0,
        0.57778
      ],
      93: [
        0.35001,
        0.85,
        0,
        0,
        0.41667
      ],
      123: [
        0.35001,
        0.85,
        0,
        0,
        0.58334
      ],
      125: [
        0.35001,
        0.85,
        0,
        0,
        0.58334
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      710: [
        0,
        0.72222,
        0,
        0,
        0.55556
      ],
      732: [
        0,
        0.72222,
        0,
        0,
        0.55556
      ],
      770: [
        0,
        0.72222,
        0,
        0,
        0.55556
      ],
      771: [
        0,
        0.72222,
        0,
        0,
        0.55556
      ],
      8214: [
        -99e-5,
        0.601,
        0,
        0,
        0.77778
      ],
      8593: [
        1e-5,
        0.6,
        0,
        0,
        0.66667
      ],
      8595: [
        1e-5,
        0.6,
        0,
        0,
        0.66667
      ],
      8657: [
        1e-5,
        0.6,
        0,
        0,
        0.77778
      ],
      8659: [
        1e-5,
        0.6,
        0,
        0,
        0.77778
      ],
      8719: [
        0.25001,
        0.75,
        0,
        0,
        0.94445
      ],
      8720: [
        0.25001,
        0.75,
        0,
        0,
        0.94445
      ],
      8721: [
        0.25001,
        0.75,
        0,
        0,
        1.05556
      ],
      8730: [
        0.35001,
        0.85,
        0,
        0,
        1
      ],
      8739: [
        -599e-5,
        0.606,
        0,
        0,
        0.33333
      ],
      8741: [
        -599e-5,
        0.606,
        0,
        0,
        0.55556
      ],
      8747: [
        0.30612,
        0.805,
        0.19445,
        0,
        0.47222
      ],
      8748: [
        0.306,
        0.805,
        0.19445,
        0,
        0.47222
      ],
      8749: [
        0.306,
        0.805,
        0.19445,
        0,
        0.47222
      ],
      8750: [
        0.30612,
        0.805,
        0.19445,
        0,
        0.47222
      ],
      8896: [
        0.25001,
        0.75,
        0,
        0,
        0.83334
      ],
      8897: [
        0.25001,
        0.75,
        0,
        0,
        0.83334
      ],
      8898: [
        0.25001,
        0.75,
        0,
        0,
        0.83334
      ],
      8899: [
        0.25001,
        0.75,
        0,
        0,
        0.83334
      ],
      8968: [
        0.35001,
        0.85,
        0,
        0,
        0.47222
      ],
      8969: [
        0.35001,
        0.85,
        0,
        0,
        0.47222
      ],
      8970: [
        0.35001,
        0.85,
        0,
        0,
        0.47222
      ],
      8971: [
        0.35001,
        0.85,
        0,
        0,
        0.47222
      ],
      9168: [
        -99e-5,
        0.601,
        0,
        0,
        0.66667
      ],
      10216: [
        0.35001,
        0.85,
        0,
        0,
        0.47222
      ],
      10217: [
        0.35001,
        0.85,
        0,
        0,
        0.47222
      ],
      10752: [
        0.25001,
        0.75,
        0,
        0,
        1.11111
      ],
      10753: [
        0.25001,
        0.75,
        0,
        0,
        1.11111
      ],
      10754: [
        0.25001,
        0.75,
        0,
        0,
        1.11111
      ],
      10756: [
        0.25001,
        0.75,
        0,
        0,
        0.83334
      ],
      10758: [
        0.25001,
        0.75,
        0,
        0,
        0.83334
      ]
    },
    "Size2-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      40: [
        0.65002,
        1.15,
        0,
        0,
        0.59722
      ],
      41: [
        0.65002,
        1.15,
        0,
        0,
        0.59722
      ],
      47: [
        0.65002,
        1.15,
        0,
        0,
        0.81111
      ],
      91: [
        0.65002,
        1.15,
        0,
        0,
        0.47222
      ],
      92: [
        0.65002,
        1.15,
        0,
        0,
        0.81111
      ],
      93: [
        0.65002,
        1.15,
        0,
        0,
        0.47222
      ],
      123: [
        0.65002,
        1.15,
        0,
        0,
        0.66667
      ],
      125: [
        0.65002,
        1.15,
        0,
        0,
        0.66667
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      710: [
        0,
        0.75,
        0,
        0,
        1
      ],
      732: [
        0,
        0.75,
        0,
        0,
        1
      ],
      770: [
        0,
        0.75,
        0,
        0,
        1
      ],
      771: [
        0,
        0.75,
        0,
        0,
        1
      ],
      8719: [
        0.55001,
        1.05,
        0,
        0,
        1.27778
      ],
      8720: [
        0.55001,
        1.05,
        0,
        0,
        1.27778
      ],
      8721: [
        0.55001,
        1.05,
        0,
        0,
        1.44445
      ],
      8730: [
        0.65002,
        1.15,
        0,
        0,
        1
      ],
      8747: [
        0.86225,
        1.36,
        0.44445,
        0,
        0.55556
      ],
      8748: [
        0.862,
        1.36,
        0.44445,
        0,
        0.55556
      ],
      8749: [
        0.862,
        1.36,
        0.44445,
        0,
        0.55556
      ],
      8750: [
        0.86225,
        1.36,
        0.44445,
        0,
        0.55556
      ],
      8896: [
        0.55001,
        1.05,
        0,
        0,
        1.11111
      ],
      8897: [
        0.55001,
        1.05,
        0,
        0,
        1.11111
      ],
      8898: [
        0.55001,
        1.05,
        0,
        0,
        1.11111
      ],
      8899: [
        0.55001,
        1.05,
        0,
        0,
        1.11111
      ],
      8968: [
        0.65002,
        1.15,
        0,
        0,
        0.52778
      ],
      8969: [
        0.65002,
        1.15,
        0,
        0,
        0.52778
      ],
      8970: [
        0.65002,
        1.15,
        0,
        0,
        0.52778
      ],
      8971: [
        0.65002,
        1.15,
        0,
        0,
        0.52778
      ],
      10216: [
        0.65002,
        1.15,
        0,
        0,
        0.61111
      ],
      10217: [
        0.65002,
        1.15,
        0,
        0,
        0.61111
      ],
      10752: [
        0.55001,
        1.05,
        0,
        0,
        1.51112
      ],
      10753: [
        0.55001,
        1.05,
        0,
        0,
        1.51112
      ],
      10754: [
        0.55001,
        1.05,
        0,
        0,
        1.51112
      ],
      10756: [
        0.55001,
        1.05,
        0,
        0,
        1.11111
      ],
      10758: [
        0.55001,
        1.05,
        0,
        0,
        1.11111
      ]
    },
    "Size3-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      40: [
        0.95003,
        1.45,
        0,
        0,
        0.73611
      ],
      41: [
        0.95003,
        1.45,
        0,
        0,
        0.73611
      ],
      47: [
        0.95003,
        1.45,
        0,
        0,
        1.04445
      ],
      91: [
        0.95003,
        1.45,
        0,
        0,
        0.52778
      ],
      92: [
        0.95003,
        1.45,
        0,
        0,
        1.04445
      ],
      93: [
        0.95003,
        1.45,
        0,
        0,
        0.52778
      ],
      123: [
        0.95003,
        1.45,
        0,
        0,
        0.75
      ],
      125: [
        0.95003,
        1.45,
        0,
        0,
        0.75
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      710: [
        0,
        0.75,
        0,
        0,
        1.44445
      ],
      732: [
        0,
        0.75,
        0,
        0,
        1.44445
      ],
      770: [
        0,
        0.75,
        0,
        0,
        1.44445
      ],
      771: [
        0,
        0.75,
        0,
        0,
        1.44445
      ],
      8730: [
        0.95003,
        1.45,
        0,
        0,
        1
      ],
      8968: [
        0.95003,
        1.45,
        0,
        0,
        0.58334
      ],
      8969: [
        0.95003,
        1.45,
        0,
        0,
        0.58334
      ],
      8970: [
        0.95003,
        1.45,
        0,
        0,
        0.58334
      ],
      8971: [
        0.95003,
        1.45,
        0,
        0,
        0.58334
      ],
      10216: [
        0.95003,
        1.45,
        0,
        0,
        0.75
      ],
      10217: [
        0.95003,
        1.45,
        0,
        0,
        0.75
      ]
    },
    "Size4-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.25
      ],
      40: [
        1.25003,
        1.75,
        0,
        0,
        0.79167
      ],
      41: [
        1.25003,
        1.75,
        0,
        0,
        0.79167
      ],
      47: [
        1.25003,
        1.75,
        0,
        0,
        1.27778
      ],
      91: [
        1.25003,
        1.75,
        0,
        0,
        0.58334
      ],
      92: [
        1.25003,
        1.75,
        0,
        0,
        1.27778
      ],
      93: [
        1.25003,
        1.75,
        0,
        0,
        0.58334
      ],
      123: [
        1.25003,
        1.75,
        0,
        0,
        0.80556
      ],
      125: [
        1.25003,
        1.75,
        0,
        0,
        0.80556
      ],
      160: [
        0,
        0,
        0,
        0,
        0.25
      ],
      710: [
        0,
        0.825,
        0,
        0,
        1.8889
      ],
      732: [
        0,
        0.825,
        0,
        0,
        1.8889
      ],
      770: [
        0,
        0.825,
        0,
        0,
        1.8889
      ],
      771: [
        0,
        0.825,
        0,
        0,
        1.8889
      ],
      8730: [
        1.25003,
        1.75,
        0,
        0,
        1
      ],
      8968: [
        1.25003,
        1.75,
        0,
        0,
        0.63889
      ],
      8969: [
        1.25003,
        1.75,
        0,
        0,
        0.63889
      ],
      8970: [
        1.25003,
        1.75,
        0,
        0,
        0.63889
      ],
      8971: [
        1.25003,
        1.75,
        0,
        0,
        0.63889
      ],
      9115: [
        0.64502,
        1.155,
        0,
        0,
        0.875
      ],
      9116: [
        1e-5,
        0.6,
        0,
        0,
        0.875
      ],
      9117: [
        0.64502,
        1.155,
        0,
        0,
        0.875
      ],
      9118: [
        0.64502,
        1.155,
        0,
        0,
        0.875
      ],
      9119: [
        1e-5,
        0.6,
        0,
        0,
        0.875
      ],
      9120: [
        0.64502,
        1.155,
        0,
        0,
        0.875
      ],
      9121: [
        0.64502,
        1.155,
        0,
        0,
        0.66667
      ],
      9122: [
        -99e-5,
        0.601,
        0,
        0,
        0.66667
      ],
      9123: [
        0.64502,
        1.155,
        0,
        0,
        0.66667
      ],
      9124: [
        0.64502,
        1.155,
        0,
        0,
        0.66667
      ],
      9125: [
        -99e-5,
        0.601,
        0,
        0,
        0.66667
      ],
      9126: [
        0.64502,
        1.155,
        0,
        0,
        0.66667
      ],
      9127: [
        1e-5,
        0.9,
        0,
        0,
        0.88889
      ],
      9128: [
        0.65002,
        1.15,
        0,
        0,
        0.88889
      ],
      9129: [
        0.90001,
        0,
        0,
        0,
        0.88889
      ],
      9130: [
        0,
        0.3,
        0,
        0,
        0.88889
      ],
      9131: [
        1e-5,
        0.9,
        0,
        0,
        0.88889
      ],
      9132: [
        0.65002,
        1.15,
        0,
        0,
        0.88889
      ],
      9133: [
        0.90001,
        0,
        0,
        0,
        0.88889
      ],
      9143: [
        0.88502,
        0.915,
        0,
        0,
        1.05556
      ],
      10216: [
        1.25003,
        1.75,
        0,
        0,
        0.80556
      ],
      10217: [
        1.25003,
        1.75,
        0,
        0,
        0.80556
      ],
      57344: [
        -499e-5,
        0.605,
        0,
        0,
        1.05556
      ],
      57345: [
        -499e-5,
        0.605,
        0,
        0,
        1.05556
      ],
      57680: [
        0,
        0.12,
        0,
        0,
        0.45
      ],
      57681: [
        0,
        0.12,
        0,
        0,
        0.45
      ],
      57682: [
        0,
        0.12,
        0,
        0,
        0.45
      ],
      57683: [
        0,
        0.12,
        0,
        0,
        0.45
      ]
    },
    "Typewriter-Regular": {
      32: [
        0,
        0,
        0,
        0,
        0.525
      ],
      33: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      34: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      35: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      36: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      37: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      38: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      39: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      40: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      41: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      42: [
        0,
        0.52083,
        0,
        0,
        0.525
      ],
      43: [
        -0.08056,
        0.53055,
        0,
        0,
        0.525
      ],
      44: [
        0.13889,
        0.125,
        0,
        0,
        0.525
      ],
      45: [
        -0.08056,
        0.53055,
        0,
        0,
        0.525
      ],
      46: [
        0,
        0.125,
        0,
        0,
        0.525
      ],
      47: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      48: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      49: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      50: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      51: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      52: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      53: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      54: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      55: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      56: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      57: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      58: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      59: [
        0.13889,
        0.43056,
        0,
        0,
        0.525
      ],
      60: [
        -0.05556,
        0.55556,
        0,
        0,
        0.525
      ],
      61: [
        -0.19549,
        0.41562,
        0,
        0,
        0.525
      ],
      62: [
        -0.05556,
        0.55556,
        0,
        0,
        0.525
      ],
      63: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      64: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      65: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      66: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      67: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      68: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      69: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      70: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      71: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      72: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      73: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      74: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      75: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      76: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      77: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      78: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      79: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      80: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      81: [
        0.13889,
        0.61111,
        0,
        0,
        0.525
      ],
      82: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      83: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      84: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      85: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      86: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      87: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      88: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      89: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      90: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      91: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      92: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      93: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      94: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      95: [
        0.09514,
        0,
        0,
        0,
        0.525
      ],
      96: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      97: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      98: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      99: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      100: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      101: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      102: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      103: [
        0.22222,
        0.43056,
        0,
        0,
        0.525
      ],
      104: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      105: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      106: [
        0.22222,
        0.61111,
        0,
        0,
        0.525
      ],
      107: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      108: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      109: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      110: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      111: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      112: [
        0.22222,
        0.43056,
        0,
        0,
        0.525
      ],
      113: [
        0.22222,
        0.43056,
        0,
        0,
        0.525
      ],
      114: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      115: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      116: [
        0,
        0.55358,
        0,
        0,
        0.525
      ],
      117: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      118: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      119: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      120: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      121: [
        0.22222,
        0.43056,
        0,
        0,
        0.525
      ],
      122: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      123: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      124: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      125: [
        0.08333,
        0.69444,
        0,
        0,
        0.525
      ],
      126: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      127: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      160: [
        0,
        0,
        0,
        0,
        0.525
      ],
      176: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      184: [
        0.19445,
        0,
        0,
        0,
        0.525
      ],
      305: [
        0,
        0.43056,
        0,
        0,
        0.525
      ],
      567: [
        0.22222,
        0.43056,
        0,
        0,
        0.525
      ],
      711: [
        0,
        0.56597,
        0,
        0,
        0.525
      ],
      713: [
        0,
        0.56555,
        0,
        0,
        0.525
      ],
      714: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      715: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      728: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      730: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      770: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      771: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      776: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      915: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      916: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      920: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      923: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      926: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      928: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      931: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      933: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      934: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      936: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      937: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      8216: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      8217: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      8242: [
        0,
        0.61111,
        0,
        0,
        0.525
      ],
      9251: [
        0.11111,
        0.21944,
        0,
        0,
        0.525
      ]
    }
  }, be = {
    slant: [
      0.25,
      0.25,
      0.25
    ],
    space: [
      0,
      0,
      0
    ],
    stretch: [
      0,
      0,
      0
    ],
    shrink: [
      0,
      0,
      0
    ],
    xHeight: [
      0.431,
      0.431,
      0.431
    ],
    quad: [
      1,
      1.171,
      1.472
    ],
    extraSpace: [
      0,
      0,
      0
    ],
    num1: [
      0.677,
      0.732,
      0.925
    ],
    num2: [
      0.394,
      0.384,
      0.387
    ],
    num3: [
      0.444,
      0.471,
      0.504
    ],
    denom1: [
      0.686,
      0.752,
      1.025
    ],
    denom2: [
      0.345,
      0.344,
      0.532
    ],
    sup1: [
      0.413,
      0.503,
      0.504
    ],
    sup2: [
      0.363,
      0.431,
      0.404
    ],
    sup3: [
      0.289,
      0.286,
      0.294
    ],
    sub1: [
      0.15,
      0.143,
      0.2
    ],
    sub2: [
      0.247,
      0.286,
      0.4
    ],
    supDrop: [
      0.386,
      0.353,
      0.494
    ],
    subDrop: [
      0.05,
      0.071,
      0.1
    ],
    delim1: [
      2.39,
      1.7,
      1.98
    ],
    delim2: [
      1.01,
      1.157,
      1.42
    ],
    axisHeight: [
      0.25,
      0.25,
      0.25
    ],
    defaultRuleThickness: [
      0.04,
      0.049,
      0.049
    ],
    bigOpSpacing1: [
      0.111,
      0.111,
      0.111
    ],
    bigOpSpacing2: [
      0.166,
      0.166,
      0.166
    ],
    bigOpSpacing3: [
      0.2,
      0.2,
      0.2
    ],
    bigOpSpacing4: [
      0.6,
      0.611,
      0.611
    ],
    bigOpSpacing5: [
      0.1,
      0.143,
      0.143
    ],
    sqrtRuleThickness: [
      0.04,
      0.04,
      0.04
    ],
    ptPerEm: [
      10,
      10,
      10
    ],
    doubleRuleSep: [
      0.2,
      0.2,
      0.2
    ],
    arrayRuleWidth: [
      0.04,
      0.04,
      0.04
    ],
    fboxsep: [
      0.3,
      0.3,
      0.3
    ],
    fboxrule: [
      0.04,
      0.04,
      0.04
    ]
  }, _t = {
    \u00C5: "A",
    \u00D0: "D",
    \u00DE: "o",
    \u00E5: "a",
    \u00F0: "d",
    \u00FE: "o",
    \u0410: "A",
    \u0411: "B",
    \u0412: "B",
    \u0413: "F",
    \u0414: "A",
    \u0415: "E",
    \u0416: "K",
    \u0417: "3",
    \u0418: "N",
    \u0419: "N",
    \u041A: "K",
    \u041B: "N",
    \u041C: "M",
    \u041D: "H",
    \u041E: "O",
    \u041F: "N",
    \u0420: "P",
    \u0421: "C",
    \u0422: "T",
    \u0423: "y",
    \u0424: "O",
    \u0425: "X",
    \u0426: "U",
    \u0427: "h",
    \u0428: "W",
    \u0429: "W",
    \u042A: "B",
    \u042B: "X",
    \u042C: "B",
    \u042D: "3",
    \u042E: "X",
    \u042F: "R",
    \u0430: "a",
    \u0431: "b",
    \u0432: "a",
    \u0433: "r",
    \u0434: "y",
    \u0435: "e",
    \u0436: "m",
    \u0437: "e",
    \u0438: "n",
    \u0439: "n",
    \u043A: "n",
    \u043B: "n",
    \u043C: "m",
    \u043D: "n",
    \u043E: "o",
    \u043F: "n",
    \u0440: "p",
    \u0441: "c",
    \u0442: "o",
    \u0443: "y",
    \u0444: "b",
    \u0445: "x",
    \u0446: "n",
    \u0447: "n",
    \u0448: "w",
    \u0449: "w",
    \u044A: "a",
    \u044B: "m",
    \u044C: "a",
    \u044D: "e",
    \u044E: "m",
    \u044F: "r"
  };
  function ha(r, e) {
    w0[r] = e;
  }
  function Bt(r, e, t) {
    if (!w0[e])
      throw new Error("Font metrics not found for font: " + e + ".");
    var a = r.charCodeAt(0), n = w0[e][a];
    if (!n && r[0] in _t && (a = _t[r[0]].charCodeAt(0), n = w0[e][a]), !n && t === "text" && Cr(a) && (n = w0[e][77]), n)
      return {
        depth: n[0],
        height: n[1],
        italic: n[2],
        skew: n[3],
        width: n[4]
      };
  }
  var Ze = {};
  function ma(r) {
    var e;
    if (r >= 5 ? e = 0 : r >= 3 ? e = 1 : e = 2, !Ze[e]) {
      var t = Ze[e] = {
        cssEmPerMu: be.quad[e] / 18
      };
      for (var a in be)
        be.hasOwnProperty(a) && (t[a] = be[a][e]);
    }
    return Ze[e];
  }
  var ca = {
    bin: 1,
    close: 1,
    inner: 1,
    open: 1,
    punct: 1,
    rel: 1
  }, da = {
    "accent-token": 1,
    mathord: 1,
    "op-token": 1,
    spacing: 1,
    textord: 1
  }, Y = {
    math: {},
    text: {}
  };
  function i(r, e, t, a, n, l) {
    Y[r][n] = {
      font: e,
      group: t,
      replace: a
    }, l && a && (Y[r][a] = Y[r][n]);
  }
  var s = "math", w = "text", o = "main", d = "ams", j = "accent-token", D = "bin", u0 = "close", ne = "inner", E = "mathord", e0 = "op-token", f0 = "open", He = "punct", f = "rel", C0 = "spacing", v = "textord";
  i(s, o, f, "\u2261", "\\equiv", true);
  i(s, o, f, "\u227A", "\\prec", true);
  i(s, o, f, "\u227B", "\\succ", true);
  i(s, o, f, "\u223C", "\\sim", true);
  i(s, o, f, "\u22A5", "\\perp");
  i(s, o, f, "\u2AAF", "\\preceq", true);
  i(s, o, f, "\u2AB0", "\\succeq", true);
  i(s, o, f, "\u2243", "\\simeq", true);
  i(s, o, f, "\u2223", "\\mid", true);
  i(s, o, f, "\u226A", "\\ll", true);
  i(s, o, f, "\u226B", "\\gg", true);
  i(s, o, f, "\u224D", "\\asymp", true);
  i(s, o, f, "\u2225", "\\parallel");
  i(s, o, f, "\u22C8", "\\bowtie", true);
  i(s, o, f, "\u2323", "\\smile", true);
  i(s, o, f, "\u2291", "\\sqsubseteq", true);
  i(s, o, f, "\u2292", "\\sqsupseteq", true);
  i(s, o, f, "\u2250", "\\doteq", true);
  i(s, o, f, "\u2322", "\\frown", true);
  i(s, o, f, "\u220B", "\\ni", true);
  i(s, o, f, "\u221D", "\\propto", true);
  i(s, o, f, "\u22A2", "\\vdash", true);
  i(s, o, f, "\u22A3", "\\dashv", true);
  i(s, o, f, "\u220B", "\\owns");
  i(s, o, He, ".", "\\ldotp");
  i(s, o, He, "\u22C5", "\\cdotp");
  i(s, o, v, "#", "\\#");
  i(w, o, v, "#", "\\#");
  i(s, o, v, "&", "\\&");
  i(w, o, v, "&", "\\&");
  i(s, o, v, "\u2135", "\\aleph", true);
  i(s, o, v, "\u2200", "\\forall", true);
  i(s, o, v, "\u210F", "\\hbar", true);
  i(s, o, v, "\u2203", "\\exists", true);
  i(s, o, v, "\u2207", "\\nabla", true);
  i(s, o, v, "\u266D", "\\flat", true);
  i(s, o, v, "\u2113", "\\ell", true);
  i(s, o, v, "\u266E", "\\natural", true);
  i(s, o, v, "\u2663", "\\clubsuit", true);
  i(s, o, v, "\u2118", "\\wp", true);
  i(s, o, v, "\u266F", "\\sharp", true);
  i(s, o, v, "\u2662", "\\diamondsuit", true);
  i(s, o, v, "\u211C", "\\Re", true);
  i(s, o, v, "\u2661", "\\heartsuit", true);
  i(s, o, v, "\u2111", "\\Im", true);
  i(s, o, v, "\u2660", "\\spadesuit", true);
  i(s, o, v, "\xA7", "\\S", true);
  i(w, o, v, "\xA7", "\\S");
  i(s, o, v, "\xB6", "\\P", true);
  i(w, o, v, "\xB6", "\\P");
  i(s, o, v, "\u2020", "\\dag");
  i(w, o, v, "\u2020", "\\dag");
  i(w, o, v, "\u2020", "\\textdagger");
  i(s, o, v, "\u2021", "\\ddag");
  i(w, o, v, "\u2021", "\\ddag");
  i(w, o, v, "\u2021", "\\textdaggerdbl");
  i(s, o, u0, "\u23B1", "\\rmoustache", true);
  i(s, o, f0, "\u23B0", "\\lmoustache", true);
  i(s, o, u0, "\u27EF", "\\rgroup", true);
  i(s, o, f0, "\u27EE", "\\lgroup", true);
  i(s, o, D, "\u2213", "\\mp", true);
  i(s, o, D, "\u2296", "\\ominus", true);
  i(s, o, D, "\u228E", "\\uplus", true);
  i(s, o, D, "\u2293", "\\sqcap", true);
  i(s, o, D, "\u2217", "\\ast");
  i(s, o, D, "\u2294", "\\sqcup", true);
  i(s, o, D, "\u25EF", "\\bigcirc", true);
  i(s, o, D, "\u2219", "\\bullet", true);
  i(s, o, D, "\u2021", "\\ddagger");
  i(s, o, D, "\u2240", "\\wr", true);
  i(s, o, D, "\u2A3F", "\\amalg");
  i(s, o, D, "&", "\\And");
  i(s, o, f, "\u27F5", "\\longleftarrow", true);
  i(s, o, f, "\u21D0", "\\Leftarrow", true);
  i(s, o, f, "\u27F8", "\\Longleftarrow", true);
  i(s, o, f, "\u27F6", "\\longrightarrow", true);
  i(s, o, f, "\u21D2", "\\Rightarrow", true);
  i(s, o, f, "\u27F9", "\\Longrightarrow", true);
  i(s, o, f, "\u2194", "\\leftrightarrow", true);
  i(s, o, f, "\u27F7", "\\longleftrightarrow", true);
  i(s, o, f, "\u21D4", "\\Leftrightarrow", true);
  i(s, o, f, "\u27FA", "\\Longleftrightarrow", true);
  i(s, o, f, "\u21A6", "\\mapsto", true);
  i(s, o, f, "\u27FC", "\\longmapsto", true);
  i(s, o, f, "\u2197", "\\nearrow", true);
  i(s, o, f, "\u21A9", "\\hookleftarrow", true);
  i(s, o, f, "\u21AA", "\\hookrightarrow", true);
  i(s, o, f, "\u2198", "\\searrow", true);
  i(s, o, f, "\u21BC", "\\leftharpoonup", true);
  i(s, o, f, "\u21C0", "\\rightharpoonup", true);
  i(s, o, f, "\u2199", "\\swarrow", true);
  i(s, o, f, "\u21BD", "\\leftharpoondown", true);
  i(s, o, f, "\u21C1", "\\rightharpoondown", true);
  i(s, o, f, "\u2196", "\\nwarrow", true);
  i(s, o, f, "\u21CC", "\\rightleftharpoons", true);
  i(s, d, f, "\u226E", "\\nless", true);
  i(s, d, f, "\uE010", "\\@nleqslant");
  i(s, d, f, "\uE011", "\\@nleqq");
  i(s, d, f, "\u2A87", "\\lneq", true);
  i(s, d, f, "\u2268", "\\lneqq", true);
  i(s, d, f, "\uE00C", "\\@lvertneqq");
  i(s, d, f, "\u22E6", "\\lnsim", true);
  i(s, d, f, "\u2A89", "\\lnapprox", true);
  i(s, d, f, "\u2280", "\\nprec", true);
  i(s, d, f, "\u22E0", "\\npreceq", true);
  i(s, d, f, "\u22E8", "\\precnsim", true);
  i(s, d, f, "\u2AB9", "\\precnapprox", true);
  i(s, d, f, "\u2241", "\\nsim", true);
  i(s, d, f, "\uE006", "\\@nshortmid");
  i(s, d, f, "\u2224", "\\nmid", true);
  i(s, d, f, "\u22AC", "\\nvdash", true);
  i(s, d, f, "\u22AD", "\\nvDash", true);
  i(s, d, f, "\u22EA", "\\ntriangleleft");
  i(s, d, f, "\u22EC", "\\ntrianglelefteq", true);
  i(s, d, f, "\u228A", "\\subsetneq", true);
  i(s, d, f, "\uE01A", "\\@varsubsetneq");
  i(s, d, f, "\u2ACB", "\\subsetneqq", true);
  i(s, d, f, "\uE017", "\\@varsubsetneqq");
  i(s, d, f, "\u226F", "\\ngtr", true);
  i(s, d, f, "\uE00F", "\\@ngeqslant");
  i(s, d, f, "\uE00E", "\\@ngeqq");
  i(s, d, f, "\u2A88", "\\gneq", true);
  i(s, d, f, "\u2269", "\\gneqq", true);
  i(s, d, f, "\uE00D", "\\@gvertneqq");
  i(s, d, f, "\u22E7", "\\gnsim", true);
  i(s, d, f, "\u2A8A", "\\gnapprox", true);
  i(s, d, f, "\u2281", "\\nsucc", true);
  i(s, d, f, "\u22E1", "\\nsucceq", true);
  i(s, d, f, "\u22E9", "\\succnsim", true);
  i(s, d, f, "\u2ABA", "\\succnapprox", true);
  i(s, d, f, "\u2246", "\\ncong", true);
  i(s, d, f, "\uE007", "\\@nshortparallel");
  i(s, d, f, "\u2226", "\\nparallel", true);
  i(s, d, f, "\u22AF", "\\nVDash", true);
  i(s, d, f, "\u22EB", "\\ntriangleright");
  i(s, d, f, "\u22ED", "\\ntrianglerighteq", true);
  i(s, d, f, "\uE018", "\\@nsupseteqq");
  i(s, d, f, "\u228B", "\\supsetneq", true);
  i(s, d, f, "\uE01B", "\\@varsupsetneq");
  i(s, d, f, "\u2ACC", "\\supsetneqq", true);
  i(s, d, f, "\uE019", "\\@varsupsetneqq");
  i(s, d, f, "\u22AE", "\\nVdash", true);
  i(s, d, f, "\u2AB5", "\\precneqq", true);
  i(s, d, f, "\u2AB6", "\\succneqq", true);
  i(s, d, f, "\uE016", "\\@nsubseteqq");
  i(s, d, D, "\u22B4", "\\unlhd");
  i(s, d, D, "\u22B5", "\\unrhd");
  i(s, d, f, "\u219A", "\\nleftarrow", true);
  i(s, d, f, "\u219B", "\\nrightarrow", true);
  i(s, d, f, "\u21CD", "\\nLeftarrow", true);
  i(s, d, f, "\u21CF", "\\nRightarrow", true);
  i(s, d, f, "\u21AE", "\\nleftrightarrow", true);
  i(s, d, f, "\u21CE", "\\nLeftrightarrow", true);
  i(s, d, f, "\u25B3", "\\vartriangle");
  i(s, d, v, "\u210F", "\\hslash");
  i(s, d, v, "\u25BD", "\\triangledown");
  i(s, d, v, "\u25CA", "\\lozenge");
  i(s, d, v, "\u24C8", "\\circledS");
  i(s, d, v, "\xAE", "\\circledR");
  i(w, d, v, "\xAE", "\\circledR");
  i(s, d, v, "\u2221", "\\measuredangle", true);
  i(s, d, v, "\u2204", "\\nexists");
  i(s, d, v, "\u2127", "\\mho");
  i(s, d, v, "\u2132", "\\Finv", true);
  i(s, d, v, "\u2141", "\\Game", true);
  i(s, d, v, "\u2035", "\\backprime");
  i(s, d, v, "\u25B2", "\\blacktriangle");
  i(s, d, v, "\u25BC", "\\blacktriangledown");
  i(s, d, v, "\u25A0", "\\blacksquare");
  i(s, d, v, "\u29EB", "\\blacklozenge");
  i(s, d, v, "\u2605", "\\bigstar");
  i(s, d, v, "\u2222", "\\sphericalangle", true);
  i(s, d, v, "\u2201", "\\complement", true);
  i(s, d, v, "\xF0", "\\eth", true);
  i(w, o, v, "\xF0", "\xF0");
  i(s, d, v, "\u2571", "\\diagup");
  i(s, d, v, "\u2572", "\\diagdown");
  i(s, d, v, "\u25A1", "\\square");
  i(s, d, v, "\u25A1", "\\Box");
  i(s, d, v, "\u25CA", "\\Diamond");
  i(s, d, v, "\xA5", "\\yen", true);
  i(w, d, v, "\xA5", "\\yen", true);
  i(s, d, v, "\u2713", "\\checkmark", true);
  i(w, d, v, "\u2713", "\\checkmark");
  i(s, d, v, "\u2136", "\\beth", true);
  i(s, d, v, "\u2138", "\\daleth", true);
  i(s, d, v, "\u2137", "\\gimel", true);
  i(s, d, v, "\u03DD", "\\digamma", true);
  i(s, d, v, "\u03F0", "\\varkappa");
  i(s, d, f0, "\u250C", "\\@ulcorner", true);
  i(s, d, u0, "\u2510", "\\@urcorner", true);
  i(s, d, f0, "\u2514", "\\@llcorner", true);
  i(s, d, u0, "\u2518", "\\@lrcorner", true);
  i(s, d, f, "\u2266", "\\leqq", true);
  i(s, d, f, "\u2A7D", "\\leqslant", true);
  i(s, d, f, "\u2A95", "\\eqslantless", true);
  i(s, d, f, "\u2272", "\\lesssim", true);
  i(s, d, f, "\u2A85", "\\lessapprox", true);
  i(s, d, f, "\u224A", "\\approxeq", true);
  i(s, d, D, "\u22D6", "\\lessdot");
  i(s, d, f, "\u22D8", "\\lll", true);
  i(s, d, f, "\u2276", "\\lessgtr", true);
  i(s, d, f, "\u22DA", "\\lesseqgtr", true);
  i(s, d, f, "\u2A8B", "\\lesseqqgtr", true);
  i(s, d, f, "\u2251", "\\doteqdot");
  i(s, d, f, "\u2253", "\\risingdotseq", true);
  i(s, d, f, "\u2252", "\\fallingdotseq", true);
  i(s, d, f, "\u223D", "\\backsim", true);
  i(s, d, f, "\u22CD", "\\backsimeq", true);
  i(s, d, f, "\u2AC5", "\\subseteqq", true);
  i(s, d, f, "\u22D0", "\\Subset", true);
  i(s, d, f, "\u228F", "\\sqsubset", true);
  i(s, d, f, "\u227C", "\\preccurlyeq", true);
  i(s, d, f, "\u22DE", "\\curlyeqprec", true);
  i(s, d, f, "\u227E", "\\precsim", true);
  i(s, d, f, "\u2AB7", "\\precapprox", true);
  i(s, d, f, "\u22B2", "\\vartriangleleft");
  i(s, d, f, "\u22B4", "\\trianglelefteq");
  i(s, d, f, "\u22A8", "\\vDash", true);
  i(s, d, f, "\u22AA", "\\Vvdash", true);
  i(s, d, f, "\u2323", "\\smallsmile");
  i(s, d, f, "\u2322", "\\smallfrown");
  i(s, d, f, "\u224F", "\\bumpeq", true);
  i(s, d, f, "\u224E", "\\Bumpeq", true);
  i(s, d, f, "\u2267", "\\geqq", true);
  i(s, d, f, "\u2A7E", "\\geqslant", true);
  i(s, d, f, "\u2A96", "\\eqslantgtr", true);
  i(s, d, f, "\u2273", "\\gtrsim", true);
  i(s, d, f, "\u2A86", "\\gtrapprox", true);
  i(s, d, D, "\u22D7", "\\gtrdot");
  i(s, d, f, "\u22D9", "\\ggg", true);
  i(s, d, f, "\u2277", "\\gtrless", true);
  i(s, d, f, "\u22DB", "\\gtreqless", true);
  i(s, d, f, "\u2A8C", "\\gtreqqless", true);
  i(s, d, f, "\u2256", "\\eqcirc", true);
  i(s, d, f, "\u2257", "\\circeq", true);
  i(s, d, f, "\u225C", "\\triangleq", true);
  i(s, d, f, "\u223C", "\\thicksim");
  i(s, d, f, "\u2248", "\\thickapprox");
  i(s, d, f, "\u2AC6", "\\supseteqq", true);
  i(s, d, f, "\u22D1", "\\Supset", true);
  i(s, d, f, "\u2290", "\\sqsupset", true);
  i(s, d, f, "\u227D", "\\succcurlyeq", true);
  i(s, d, f, "\u22DF", "\\curlyeqsucc", true);
  i(s, d, f, "\u227F", "\\succsim", true);
  i(s, d, f, "\u2AB8", "\\succapprox", true);
  i(s, d, f, "\u22B3", "\\vartriangleright");
  i(s, d, f, "\u22B5", "\\trianglerighteq");
  i(s, d, f, "\u22A9", "\\Vdash", true);
  i(s, d, f, "\u2223", "\\shortmid");
  i(s, d, f, "\u2225", "\\shortparallel");
  i(s, d, f, "\u226C", "\\between", true);
  i(s, d, f, "\u22D4", "\\pitchfork", true);
  i(s, d, f, "\u221D", "\\varpropto");
  i(s, d, f, "\u25C0", "\\blacktriangleleft");
  i(s, d, f, "\u2234", "\\therefore", true);
  i(s, d, f, "\u220D", "\\backepsilon");
  i(s, d, f, "\u25B6", "\\blacktriangleright");
  i(s, d, f, "\u2235", "\\because", true);
  i(s, d, f, "\u22D8", "\\llless");
  i(s, d, f, "\u22D9", "\\gggtr");
  i(s, d, D, "\u22B2", "\\lhd");
  i(s, d, D, "\u22B3", "\\rhd");
  i(s, d, f, "\u2242", "\\eqsim", true);
  i(s, o, f, "\u22C8", "\\Join");
  i(s, d, f, "\u2251", "\\Doteq", true);
  i(s, d, D, "\u2214", "\\dotplus", true);
  i(s, d, D, "\u2216", "\\smallsetminus");
  i(s, d, D, "\u22D2", "\\Cap", true);
  i(s, d, D, "\u22D3", "\\Cup", true);
  i(s, d, D, "\u2A5E", "\\doublebarwedge", true);
  i(s, d, D, "\u229F", "\\boxminus", true);
  i(s, d, D, "\u229E", "\\boxplus", true);
  i(s, d, D, "\u22C7", "\\divideontimes", true);
  i(s, d, D, "\u22C9", "\\ltimes", true);
  i(s, d, D, "\u22CA", "\\rtimes", true);
  i(s, d, D, "\u22CB", "\\leftthreetimes", true);
  i(s, d, D, "\u22CC", "\\rightthreetimes", true);
  i(s, d, D, "\u22CF", "\\curlywedge", true);
  i(s, d, D, "\u22CE", "\\curlyvee", true);
  i(s, d, D, "\u229D", "\\circleddash", true);
  i(s, d, D, "\u229B", "\\circledast", true);
  i(s, d, D, "\u22C5", "\\centerdot");
  i(s, d, D, "\u22BA", "\\intercal", true);
  i(s, d, D, "\u22D2", "\\doublecap");
  i(s, d, D, "\u22D3", "\\doublecup");
  i(s, d, D, "\u22A0", "\\boxtimes", true);
  i(s, d, f, "\u21E2", "\\dashrightarrow", true);
  i(s, d, f, "\u21E0", "\\dashleftarrow", true);
  i(s, d, f, "\u21C7", "\\leftleftarrows", true);
  i(s, d, f, "\u21C6", "\\leftrightarrows", true);
  i(s, d, f, "\u21DA", "\\Lleftarrow", true);
  i(s, d, f, "\u219E", "\\twoheadleftarrow", true);
  i(s, d, f, "\u21A2", "\\leftarrowtail", true);
  i(s, d, f, "\u21AB", "\\looparrowleft", true);
  i(s, d, f, "\u21CB", "\\leftrightharpoons", true);
  i(s, d, f, "\u21B6", "\\curvearrowleft", true);
  i(s, d, f, "\u21BA", "\\circlearrowleft", true);
  i(s, d, f, "\u21B0", "\\Lsh", true);
  i(s, d, f, "\u21C8", "\\upuparrows", true);
  i(s, d, f, "\u21BF", "\\upharpoonleft", true);
  i(s, d, f, "\u21C3", "\\downharpoonleft", true);
  i(s, o, f, "\u22B6", "\\origof", true);
  i(s, o, f, "\u22B7", "\\imageof", true);
  i(s, d, f, "\u22B8", "\\multimap", true);
  i(s, d, f, "\u21AD", "\\leftrightsquigarrow", true);
  i(s, d, f, "\u21C9", "\\rightrightarrows", true);
  i(s, d, f, "\u21C4", "\\rightleftarrows", true);
  i(s, d, f, "\u21A0", "\\twoheadrightarrow", true);
  i(s, d, f, "\u21A3", "\\rightarrowtail", true);
  i(s, d, f, "\u21AC", "\\looparrowright", true);
  i(s, d, f, "\u21B7", "\\curvearrowright", true);
  i(s, d, f, "\u21BB", "\\circlearrowright", true);
  i(s, d, f, "\u21B1", "\\Rsh", true);
  i(s, d, f, "\u21CA", "\\downdownarrows", true);
  i(s, d, f, "\u21BE", "\\upharpoonright", true);
  i(s, d, f, "\u21C2", "\\downharpoonright", true);
  i(s, d, f, "\u21DD", "\\rightsquigarrow", true);
  i(s, d, f, "\u21DD", "\\leadsto");
  i(s, d, f, "\u21DB", "\\Rrightarrow", true);
  i(s, d, f, "\u21BE", "\\restriction");
  i(s, o, v, "\u2018", "`");
  i(s, o, v, "$", "\\$");
  i(w, o, v, "$", "\\$");
  i(w, o, v, "$", "\\textdollar");
  i(s, o, v, "%", "\\%");
  i(w, o, v, "%", "\\%");
  i(s, o, v, "_", "\\_");
  i(w, o, v, "_", "\\_");
  i(w, o, v, "_", "\\textunderscore");
  i(s, o, v, "\u2220", "\\angle", true);
  i(s, o, v, "\u221E", "\\infty", true);
  i(s, o, v, "\u2032", "\\prime");
  i(s, o, v, "\u25B3", "\\triangle");
  i(s, o, v, "\u0393", "\\Gamma", true);
  i(s, o, v, "\u0394", "\\Delta", true);
  i(s, o, v, "\u0398", "\\Theta", true);
  i(s, o, v, "\u039B", "\\Lambda", true);
  i(s, o, v, "\u039E", "\\Xi", true);
  i(s, o, v, "\u03A0", "\\Pi", true);
  i(s, o, v, "\u03A3", "\\Sigma", true);
  i(s, o, v, "\u03A5", "\\Upsilon", true);
  i(s, o, v, "\u03A6", "\\Phi", true);
  i(s, o, v, "\u03A8", "\\Psi", true);
  i(s, o, v, "\u03A9", "\\Omega", true);
  i(s, o, v, "A", "\u0391");
  i(s, o, v, "B", "\u0392");
  i(s, o, v, "E", "\u0395");
  i(s, o, v, "Z", "\u0396");
  i(s, o, v, "H", "\u0397");
  i(s, o, v, "I", "\u0399");
  i(s, o, v, "K", "\u039A");
  i(s, o, v, "M", "\u039C");
  i(s, o, v, "N", "\u039D");
  i(s, o, v, "O", "\u039F");
  i(s, o, v, "P", "\u03A1");
  i(s, o, v, "T", "\u03A4");
  i(s, o, v, "X", "\u03A7");
  i(s, o, v, "\xAC", "\\neg", true);
  i(s, o, v, "\xAC", "\\lnot");
  i(s, o, v, "\u22A4", "\\top");
  i(s, o, v, "\u22A5", "\\bot");
  i(s, o, v, "\u2205", "\\emptyset");
  i(s, d, v, "\u2205", "\\varnothing");
  i(s, o, E, "\u03B1", "\\alpha", true);
  i(s, o, E, "\u03B2", "\\beta", true);
  i(s, o, E, "\u03B3", "\\gamma", true);
  i(s, o, E, "\u03B4", "\\delta", true);
  i(s, o, E, "\u03F5", "\\epsilon", true);
  i(s, o, E, "\u03B6", "\\zeta", true);
  i(s, o, E, "\u03B7", "\\eta", true);
  i(s, o, E, "\u03B8", "\\theta", true);
  i(s, o, E, "\u03B9", "\\iota", true);
  i(s, o, E, "\u03BA", "\\kappa", true);
  i(s, o, E, "\u03BB", "\\lambda", true);
  i(s, o, E, "\u03BC", "\\mu", true);
  i(s, o, E, "\u03BD", "\\nu", true);
  i(s, o, E, "\u03BE", "\\xi", true);
  i(s, o, E, "\u03BF", "\\omicron", true);
  i(s, o, E, "\u03C0", "\\pi", true);
  i(s, o, E, "\u03C1", "\\rho", true);
  i(s, o, E, "\u03C3", "\\sigma", true);
  i(s, o, E, "\u03C4", "\\tau", true);
  i(s, o, E, "\u03C5", "\\upsilon", true);
  i(s, o, E, "\u03D5", "\\phi", true);
  i(s, o, E, "\u03C7", "\\chi", true);
  i(s, o, E, "\u03C8", "\\psi", true);
  i(s, o, E, "\u03C9", "\\omega", true);
  i(s, o, E, "\u03B5", "\\varepsilon", true);
  i(s, o, E, "\u03D1", "\\vartheta", true);
  i(s, o, E, "\u03D6", "\\varpi", true);
  i(s, o, E, "\u03F1", "\\varrho", true);
  i(s, o, E, "\u03C2", "\\varsigma", true);
  i(s, o, E, "\u03C6", "\\varphi", true);
  i(s, o, D, "\u2217", "*", true);
  i(s, o, D, "+", "+");
  i(s, o, D, "\u2212", "-", true);
  i(s, o, D, "\u22C5", "\\cdot", true);
  i(s, o, D, "\u2218", "\\circ", true);
  i(s, o, D, "\xF7", "\\div", true);
  i(s, o, D, "\xB1", "\\pm", true);
  i(s, o, D, "\xD7", "\\times", true);
  i(s, o, D, "\u2229", "\\cap", true);
  i(s, o, D, "\u222A", "\\cup", true);
  i(s, o, D, "\u2216", "\\setminus", true);
  i(s, o, D, "\u2227", "\\land");
  i(s, o, D, "\u2228", "\\lor");
  i(s, o, D, "\u2227", "\\wedge", true);
  i(s, o, D, "\u2228", "\\vee", true);
  i(s, o, v, "\u221A", "\\surd");
  i(s, o, f0, "\u27E8", "\\langle", true);
  i(s, o, f0, "\u2223", "\\lvert");
  i(s, o, f0, "\u2225", "\\lVert");
  i(s, o, u0, "?", "?");
  i(s, o, u0, "!", "!");
  i(s, o, u0, "\u27E9", "\\rangle", true);
  i(s, o, u0, "\u2223", "\\rvert");
  i(s, o, u0, "\u2225", "\\rVert");
  i(s, o, f, "=", "=");
  i(s, o, f, ":", ":");
  i(s, o, f, "\u2248", "\\approx", true);
  i(s, o, f, "\u2245", "\\cong", true);
  i(s, o, f, "\u2265", "\\ge");
  i(s, o, f, "\u2265", "\\geq", true);
  i(s, o, f, "\u2190", "\\gets");
  i(s, o, f, ">", "\\gt", true);
  i(s, o, f, "\u2208", "\\in", true);
  i(s, o, f, "\uE020", "\\@not");
  i(s, o, f, "\u2282", "\\subset", true);
  i(s, o, f, "\u2283", "\\supset", true);
  i(s, o, f, "\u2286", "\\subseteq", true);
  i(s, o, f, "\u2287", "\\supseteq", true);
  i(s, d, f, "\u2288", "\\nsubseteq", true);
  i(s, d, f, "\u2289", "\\nsupseteq", true);
  i(s, o, f, "\u22A8", "\\models");
  i(s, o, f, "\u2190", "\\leftarrow", true);
  i(s, o, f, "\u2264", "\\le");
  i(s, o, f, "\u2264", "\\leq", true);
  i(s, o, f, "<", "\\lt", true);
  i(s, o, f, "\u2192", "\\rightarrow", true);
  i(s, o, f, "\u2192", "\\to");
  i(s, d, f, "\u2271", "\\ngeq", true);
  i(s, d, f, "\u2270", "\\nleq", true);
  i(s, o, C0, "\xA0", "\\ ");
  i(s, o, C0, "\xA0", "\\space");
  i(s, o, C0, "\xA0", "\\nobreakspace");
  i(w, o, C0, "\xA0", "\\ ");
  i(w, o, C0, "\xA0", " ");
  i(w, o, C0, "\xA0", "\\space");
  i(w, o, C0, "\xA0", "\\nobreakspace");
  i(s, o, C0, null, "\\nobreak");
  i(s, o, C0, null, "\\allowbreak");
  i(s, o, He, ",", ",");
  i(s, o, He, ";", ";");
  i(s, d, D, "\u22BC", "\\barwedge", true);
  i(s, d, D, "\u22BB", "\\veebar", true);
  i(s, o, D, "\u2299", "\\odot", true);
  i(s, o, D, "\u2295", "\\oplus", true);
  i(s, o, D, "\u2297", "\\otimes", true);
  i(s, o, v, "\u2202", "\\partial", true);
  i(s, o, D, "\u2298", "\\oslash", true);
  i(s, d, D, "\u229A", "\\circledcirc", true);
  i(s, d, D, "\u22A1", "\\boxdot", true);
  i(s, o, D, "\u25B3", "\\bigtriangleup");
  i(s, o, D, "\u25BD", "\\bigtriangledown");
  i(s, o, D, "\u2020", "\\dagger");
  i(s, o, D, "\u22C4", "\\diamond");
  i(s, o, D, "\u22C6", "\\star");
  i(s, o, D, "\u25C3", "\\triangleleft");
  i(s, o, D, "\u25B9", "\\triangleright");
  i(s, o, f0, "{", "\\{");
  i(w, o, v, "{", "\\{");
  i(w, o, v, "{", "\\textbraceleft");
  i(s, o, u0, "}", "\\}");
  i(w, o, v, "}", "\\}");
  i(w, o, v, "}", "\\textbraceright");
  i(s, o, f0, "{", "\\lbrace");
  i(s, o, u0, "}", "\\rbrace");
  i(s, o, f0, "[", "\\lbrack", true);
  i(w, o, v, "[", "\\lbrack", true);
  i(s, o, u0, "]", "\\rbrack", true);
  i(w, o, v, "]", "\\rbrack", true);
  i(s, o, f0, "(", "\\lparen", true);
  i(s, o, u0, ")", "\\rparen", true);
  i(w, o, v, "<", "\\textless", true);
  i(w, o, v, ">", "\\textgreater", true);
  i(s, o, f0, "\u230A", "\\lfloor", true);
  i(s, o, u0, "\u230B", "\\rfloor", true);
  i(s, o, f0, "\u2308", "\\lceil", true);
  i(s, o, u0, "\u2309", "\\rceil", true);
  i(s, o, v, "\\", "\\backslash");
  i(s, o, v, "\u2223", "|");
  i(s, o, v, "\u2223", "\\vert");
  i(w, o, v, "|", "\\textbar", true);
  i(s, o, v, "\u2225", "\\|");
  i(s, o, v, "\u2225", "\\Vert");
  i(w, o, v, "\u2225", "\\textbardbl");
  i(w, o, v, "~", "\\textasciitilde");
  i(w, o, v, "\\", "\\textbackslash");
  i(w, o, v, "^", "\\textasciicircum");
  i(s, o, f, "\u2191", "\\uparrow", true);
  i(s, o, f, "\u21D1", "\\Uparrow", true);
  i(s, o, f, "\u2193", "\\downarrow", true);
  i(s, o, f, "\u21D3", "\\Downarrow", true);
  i(s, o, f, "\u2195", "\\updownarrow", true);
  i(s, o, f, "\u21D5", "\\Updownarrow", true);
  i(s, o, e0, "\u2210", "\\coprod");
  i(s, o, e0, "\u22C1", "\\bigvee");
  i(s, o, e0, "\u22C0", "\\bigwedge");
  i(s, o, e0, "\u2A04", "\\biguplus");
  i(s, o, e0, "\u22C2", "\\bigcap");
  i(s, o, e0, "\u22C3", "\\bigcup");
  i(s, o, e0, "\u222B", "\\int");
  i(s, o, e0, "\u222B", "\\intop");
  i(s, o, e0, "\u222C", "\\iint");
  i(s, o, e0, "\u222D", "\\iiint");
  i(s, o, e0, "\u220F", "\\prod");
  i(s, o, e0, "\u2211", "\\sum");
  i(s, o, e0, "\u2A02", "\\bigotimes");
  i(s, o, e0, "\u2A01", "\\bigoplus");
  i(s, o, e0, "\u2A00", "\\bigodot");
  i(s, o, e0, "\u222E", "\\oint");
  i(s, o, e0, "\u222F", "\\oiint");
  i(s, o, e0, "\u2230", "\\oiiint");
  i(s, o, e0, "\u2A06", "\\bigsqcup");
  i(s, o, e0, "\u222B", "\\smallint");
  i(w, o, ne, "\u2026", "\\textellipsis");
  i(s, o, ne, "\u2026", "\\mathellipsis");
  i(w, o, ne, "\u2026", "\\ldots", true);
  i(s, o, ne, "\u2026", "\\ldots", true);
  i(s, o, ne, "\u22EF", "\\@cdots", true);
  i(s, o, ne, "\u22F1", "\\ddots", true);
  i(s, o, v, "\u22EE", "\\varvdots");
  i(w, o, v, "\u22EE", "\\varvdots");
  i(s, o, j, "\u02CA", "\\acute");
  i(s, o, j, "\u02CB", "\\grave");
  i(s, o, j, "\xA8", "\\ddot");
  i(s, o, j, "~", "\\tilde");
  i(s, o, j, "\u02C9", "\\bar");
  i(s, o, j, "\u02D8", "\\breve");
  i(s, o, j, "\u02C7", "\\check");
  i(s, o, j, "^", "\\hat");
  i(s, o, j, "\u20D7", "\\vec");
  i(s, o, j, "\u02D9", "\\dot");
  i(s, o, j, "\u02DA", "\\mathring");
  i(s, o, E, "\uE131", "\\@imath");
  i(s, o, E, "\uE237", "\\@jmath");
  i(s, o, v, "\u0131", "\u0131");
  i(s, o, v, "\u0237", "\u0237");
  i(w, o, v, "\u0131", "\\i", true);
  i(w, o, v, "\u0237", "\\j", true);
  i(w, o, v, "\xDF", "\\ss", true);
  i(w, o, v, "\xE6", "\\ae", true);
  i(w, o, v, "\u0153", "\\oe", true);
  i(w, o, v, "\xF8", "\\o", true);
  i(w, o, v, "\xC6", "\\AE", true);
  i(w, o, v, "\u0152", "\\OE", true);
  i(w, o, v, "\xD8", "\\O", true);
  i(w, o, j, "\u02CA", "\\'");
  i(w, o, j, "\u02CB", "\\`");
  i(w, o, j, "\u02C6", "\\^");
  i(w, o, j, "\u02DC", "\\~");
  i(w, o, j, "\u02C9", "\\=");
  i(w, o, j, "\u02D8", "\\u");
  i(w, o, j, "\u02D9", "\\.");
  i(w, o, j, "\xB8", "\\c");
  i(w, o, j, "\u02DA", "\\r");
  i(w, o, j, "\u02C7", "\\v");
  i(w, o, j, "\xA8", '\\"');
  i(w, o, j, "\u02DD", "\\H");
  i(w, o, j, "\u25EF", "\\textcircled");
  var Nr = {
    "--": true,
    "---": true,
    "``": true,
    "''": true
  };
  i(w, o, v, "\u2013", "--", true);
  i(w, o, v, "\u2013", "\\textendash");
  i(w, o, v, "\u2014", "---", true);
  i(w, o, v, "\u2014", "\\textemdash");
  i(w, o, v, "\u2018", "`", true);
  i(w, o, v, "\u2018", "\\textquoteleft");
  i(w, o, v, "\u2019", "'", true);
  i(w, o, v, "\u2019", "\\textquoteright");
  i(w, o, v, "\u201C", "``", true);
  i(w, o, v, "\u201C", "\\textquotedblleft");
  i(w, o, v, "\u201D", "''", true);
  i(w, o, v, "\u201D", "\\textquotedblright");
  i(s, o, v, "\xB0", "\\degree", true);
  i(w, o, v, "\xB0", "\\degree");
  i(w, o, v, "\xB0", "\\textdegree", true);
  i(s, o, v, "\xA3", "\\pounds");
  i(s, o, v, "\xA3", "\\mathsterling", true);
  i(w, o, v, "\xA3", "\\pounds");
  i(w, o, v, "\xA3", "\\textsterling", true);
  i(s, d, v, "\u2720", "\\maltese");
  i(w, d, v, "\u2720", "\\maltese");
  var er = '0123456789/@."';
  for (var Ke = 0; Ke < er.length; Ke++) {
    var tr = er.charAt(Ke);
    i(s, o, v, tr, tr);
  }
  var rr = '0123456789!@*()-=+";:?/.,';
  for (var Je = 0; Je < rr.length; Je++) {
    var ar = rr.charAt(Je);
    i(w, o, v, ar, ar);
  }
  var qe = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  for (var Qe = 0; Qe < qe.length; Qe++) {
    var ye = qe.charAt(Qe);
    i(s, o, E, ye, ye), i(w, o, v, ye, ye);
  }
  i(s, d, v, "C", "\u2102");
  i(w, d, v, "C", "\u2102");
  i(s, d, v, "H", "\u210D");
  i(w, d, v, "H", "\u210D");
  i(s, d, v, "N", "\u2115");
  i(w, d, v, "N", "\u2115");
  i(s, d, v, "P", "\u2119");
  i(w, d, v, "P", "\u2119");
  i(s, d, v, "Q", "\u211A");
  i(w, d, v, "Q", "\u211A");
  i(s, d, v, "R", "\u211D");
  i(w, d, v, "R", "\u211D");
  i(s, d, v, "Z", "\u2124");
  i(w, d, v, "Z", "\u2124");
  i(s, o, E, "h", "\u210E");
  i(w, o, E, "h", "\u210E");
  var R = "";
  for (var i0 = 0; i0 < qe.length; i0++) {
    var J = qe.charAt(i0);
    R = String.fromCharCode(55349, 56320 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56372 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56424 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56580 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56684 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56736 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56788 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56840 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56944 + i0), i(s, o, E, J, R), i(w, o, v, J, R), i0 < 26 && (R = String.fromCharCode(55349, 56632 + i0), i(s, o, E, J, R), i(w, o, v, J, R), R = String.fromCharCode(55349, 56476 + i0), i(s, o, E, J, R), i(w, o, v, J, R));
  }
  R = String.fromCharCode(55349, 56668);
  i(s, o, E, "k", R);
  i(w, o, v, "k", R);
  for (var $0 = 0; $0 < 10; $0++) {
    var H0 = $0.toString();
    R = String.fromCharCode(55349, 57294 + $0), i(s, o, E, H0, R), i(w, o, v, H0, R), R = String.fromCharCode(55349, 57314 + $0), i(s, o, E, H0, R), i(w, o, v, H0, R), R = String.fromCharCode(55349, 57324 + $0), i(s, o, E, H0, R), i(w, o, v, H0, R), R = String.fromCharCode(55349, 57334 + $0), i(s, o, E, H0, R), i(w, o, v, H0, R);
  }
  var pt = "\xD0\xDE\xFE";
  for (var _e = 0; _e < pt.length; _e++) {
    var xe = pt.charAt(_e);
    i(s, o, E, xe, xe), i(w, o, v, xe, xe);
  }
  var we = [
    [
      "mathbf",
      "textbf",
      "Main-Bold"
    ],
    [
      "mathbf",
      "textbf",
      "Main-Bold"
    ],
    [
      "mathnormal",
      "textit",
      "Math-Italic"
    ],
    [
      "mathnormal",
      "textit",
      "Math-Italic"
    ],
    [
      "boldsymbol",
      "boldsymbol",
      "Main-BoldItalic"
    ],
    [
      "boldsymbol",
      "boldsymbol",
      "Main-BoldItalic"
    ],
    [
      "mathscr",
      "textscr",
      "Script-Regular"
    ],
    [
      "",
      "",
      ""
    ],
    [
      "",
      "",
      ""
    ],
    [
      "",
      "",
      ""
    ],
    [
      "mathfrak",
      "textfrak",
      "Fraktur-Regular"
    ],
    [
      "mathfrak",
      "textfrak",
      "Fraktur-Regular"
    ],
    [
      "mathbb",
      "textbb",
      "AMS-Regular"
    ],
    [
      "mathbb",
      "textbb",
      "AMS-Regular"
    ],
    [
      "mathboldfrak",
      "textboldfrak",
      "Fraktur-Regular"
    ],
    [
      "mathboldfrak",
      "textboldfrak",
      "Fraktur-Regular"
    ],
    [
      "mathsf",
      "textsf",
      "SansSerif-Regular"
    ],
    [
      "mathsf",
      "textsf",
      "SansSerif-Regular"
    ],
    [
      "mathboldsf",
      "textboldsf",
      "SansSerif-Bold"
    ],
    [
      "mathboldsf",
      "textboldsf",
      "SansSerif-Bold"
    ],
    [
      "mathitsf",
      "textitsf",
      "SansSerif-Italic"
    ],
    [
      "mathitsf",
      "textitsf",
      "SansSerif-Italic"
    ],
    [
      "",
      "",
      ""
    ],
    [
      "",
      "",
      ""
    ],
    [
      "mathtt",
      "texttt",
      "Typewriter-Regular"
    ],
    [
      "mathtt",
      "texttt",
      "Typewriter-Regular"
    ]
  ], nr = [
    [
      "mathbf",
      "textbf",
      "Main-Bold"
    ],
    [
      "",
      "",
      ""
    ],
    [
      "mathsf",
      "textsf",
      "SansSerif-Regular"
    ],
    [
      "mathboldsf",
      "textboldsf",
      "SansSerif-Bold"
    ],
    [
      "mathtt",
      "texttt",
      "Typewriter-Regular"
    ]
  ], fa = (r, e) => {
    var t = r.charCodeAt(0), a = r.charCodeAt(1), n = (t - 55296) * 1024 + (a - 56320) + 65536, l = e === "math" ? 0 : 1;
    if (119808 <= n && n < 120484) {
      var u = Math.floor((n - 119808) / 26);
      return [
        we[u][2],
        we[u][l]
      ];
    } else if (120782 <= n && n <= 120831) {
      var h = Math.floor((n - 120782) / 10);
      return [
        nr[h][2],
        nr[h][l]
      ];
    } else {
      if (n === 120485 || n === 120486)
        return [
          we[0][2],
          we[0][l]
        ];
      if (120486 < n && n < 120782)
        return [
          "",
          ""
        ];
      throw new k("Unsupported character: " + r);
    }
  }, Oe = function(e, t, a) {
    if (Y[a][e]) {
      var n = Y[a][e].replace;
      n && (e = n);
    }
    return {
      value: e,
      metrics: Bt(e, t, a)
    };
  }, l0 = function(e, t, a, n, l) {
    var u = Oe(e, t, a), h = u.metrics;
    e = u.value;
    var c;
    if (h) {
      var p = h.italic;
      (a === "text" || n && n.font === "mathit") && (p = 0), c = new d0(e, h.height, h.depth, p, h.skew, h.width, l);
    } else
      typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + a + "'")), c = new d0(e, 0, 0, 0, 0, 0, l);
    if (n) {
      c.maxFontSize = n.sizeMultiplier, n.style.isTight() && c.classes.push("mtight");
      var g = n.getColor();
      g && (c.style.color = g);
    }
    return c;
  }, Dt = function(e, t, a, n) {
    return n === void 0 && (n = []), a.font === "boldsymbol" && Oe(e, "Main-Bold", t).metrics ? l0(e, "Main-Bold", t, a, n.concat([
      "mathbf"
    ])) : e === "\\" || Y[t][e].font === "main" ? l0(e, "Main-Regular", t, a, n) : l0(e, "AMS-Regular", t, a, n.concat([
      "amsrm"
    ]));
  }, pa = function(e, t, a, n, l) {
    return l !== "textord" && Oe(e, "Math-BoldItalic", t).metrics ? {
      fontName: "Math-BoldItalic",
      fontClass: "boldsymbol"
    } : {
      fontName: "Main-Bold",
      fontClass: "mathbf"
    };
  }, Fe = function(e, t, a) {
    var n = e.mode, l = e.text, u = [
      "mord"
    ], h = n === "math" || n === "text" && t.font, c = h ? t.font : t.fontFamily, p = "", g = "";
    if (l.charCodeAt(0) === 55349 && ([p, g] = fa(l, n)), p.length > 0)
      return l0(l, p, n, t, u.concat(g));
    if (c) {
      var b, y;
      if (c === "boldsymbol") {
        var x = pa(l, n, t, u, a);
        b = x.fontName, y = [
          x.fontClass
        ];
      } else
        h ? (b = vt[c].fontName, y = [
          c
        ]) : (b = Se(c, t.fontWeight, t.fontShape), y = [
          c,
          t.fontWeight,
          t.fontShape
        ]);
      if (Oe(l, b, n).metrics)
        return l0(l, b, n, t, u.concat(y));
      if (Nr.hasOwnProperty(l) && b.slice(0, 10) === "Typewriter") {
        for (var A = [], T = 0; T < l.length; T++)
          A.push(l0(l[T], b, n, t, u.concat(y)));
        return q0(A);
      }
    }
    if (a === "mathord")
      return l0(l, "Math-Italic", n, t, u.concat([
        "mathnormal"
      ]));
    if (a === "textord") {
      var C = Y[n][l] && Y[n][l].font;
      if (C === "ams") {
        var q = Se("amsrm", t.fontWeight, t.fontShape);
        return l0(l, q, n, t, u.concat("amsrm", t.fontWeight, t.fontShape));
      } else if (C === "main" || !C) {
        var I = Se("textrm", t.fontWeight, t.fontShape);
        return l0(l, I, n, t, u.concat(t.fontWeight, t.fontShape));
      } else {
        var H = Se(C, t.fontWeight, t.fontShape);
        return l0(l, H, n, t, u.concat(H, t.fontWeight, t.fontShape));
      }
    } else
      throw new Error("unexpected type: " + a + " in makeOrd");
  }, va = (r, e) => {
    if (F0(r.classes) !== F0(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize || r.italic !== 0 && r.hasClass("mathnormal"))
      return false;
    if (r.classes.length === 1) {
      var t = r.classes[0];
      if (t === "mbin" || t === "mord")
        return false;
    }
    for (var a of Object.keys(r.style))
      if (r.style[a] !== e.style[a])
        return false;
    for (var n of Object.keys(e.style))
      if (r.style[n] !== e.style[n])
        return false;
    return true;
  }, Hr = (r) => {
    for (var e = 0; e < r.length - 1; e++) {
      var t = r[e], a = r[e + 1];
      t instanceof d0 && a instanceof d0 && va(t, a) && (t.text += a.text, t.height = Math.max(t.height, a.height), t.depth = Math.max(t.depth, a.depth), t.italic = a.italic, r.splice(e + 1, 1), e--);
    }
    return r;
  }, Ct = function(e) {
    for (var t = 0, a = 0, n = 0, l = 0; l < e.children.length; l++) {
      var u = e.children[l];
      u.height > t && (t = u.height), u.depth > a && (a = u.depth), u.maxFontSize > n && (n = u.maxFontSize);
    }
    e.height = t, e.depth = a, e.maxFontSize = n;
  }, S = function(e, t, a, n) {
    var l = new ae(e, t, a, n);
    return Ct(l), l;
  }, P0 = (r, e, t, a) => new ae(r, e, t, a), ee = function(e, t, a) {
    var n = S([
      e
    ], [], t);
    return n.height = Math.max(a || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), n.style.borderBottomWidth = M(n.height), n.maxFontSize = 1, n;
  }, ga = function(e, t, a, n) {
    var l = new Ne(e, t, a, n);
    return Ct(l), l;
  }, q0 = function(e) {
    var t = new re(e);
    return Ct(t), t;
  }, te = function(e, t) {
    return e instanceof re ? S([], [
      e
    ], t) : e;
  }, ba = function(e) {
    if (e.positionType === "individualShift") {
      for (var t = e.children, a = [
        t[0]
      ], n = -t[0].shift - t[0].elem.depth, l = n, u = 1; u < t.length; u++) {
        var h = -t[u].shift - l - t[u].elem.depth, c = h - (t[u - 1].elem.height + t[u - 1].elem.depth);
        l = l + h, a.push({
          type: "kern",
          size: c
        }), a.push(t[u]);
      }
      return {
        children: a,
        depth: n
      };
    }
    var p;
    if (e.positionType === "top") {
      for (var g = e.positionData, b = 0; b < e.children.length; b++) {
        var y = e.children[b];
        g -= y.type === "kern" ? y.size : y.elem.height + y.elem.depth;
      }
      p = g;
    } else if (e.positionType === "bottom")
      p = -e.positionData;
    else {
      var x = e.children[0];
      if (x.type !== "elem")
        throw new Error('First child must have type "elem".');
      if (e.positionType === "shift")
        p = -x.elem.depth - e.positionData;
      else if (e.positionType === "firstBaseline")
        p = -x.elem.depth;
      else
        throw new Error("Invalid positionType " + e.positionType + ".");
    }
    return {
      children: e.children,
      depth: p
    };
  }, G = function(e, t) {
    for (var { children: a, depth: n } = ba(e), l = 0, u = 0; u < a.length; u++) {
      var h = a[u];
      if (h.type === "elem") {
        var c = h.elem;
        l = Math.max(l, c.maxFontSize, c.height);
      }
    }
    l += 2;
    var p = S([
      "pstrut"
    ], []);
    p.style.height = M(l);
    for (var g = [], b = n, y = n, x = n, A = 0; A < a.length; A++) {
      var T = a[A];
      if (T.type === "kern")
        x += T.size;
      else {
        var C = T.elem, q = T.wrapperClasses || [], I = T.wrapperStyle || {}, H = S(q, [
          p,
          C
        ], void 0, I);
        H.style.top = M(-l - x - C.depth), T.marginLeft && (H.style.marginLeft = T.marginLeft), T.marginRight && (H.style.marginRight = T.marginRight), g.push(H), x += C.height + C.depth;
      }
      b = Math.min(b, x), y = Math.max(y, x);
    }
    var F = S([
      "vlist"
    ], g);
    F.style.height = M(y);
    var V;
    if (b < 0) {
      var L = S([], []), P = S([
        "vlist"
      ], [
        L
      ]);
      P.style.height = M(-b);
      var X = S([
        "vlist-s"
      ], [
        new d0("\u200B")
      ]);
      V = [
        S([
          "vlist-r"
        ], [
          F,
          X
        ]),
        S([
          "vlist-r"
        ], [
          P
        ])
      ];
    } else
      V = [
        S([
          "vlist-r"
        ], [
          F
        ])
      ];
    var $ = S([
      "vlist-t"
    ], V);
    return V.length === 2 && $.classes.push("vlist-t2"), $.height = y, $.depth = -b, $;
  }, Or = (r, e) => {
    var t = S([
      "mspace"
    ], [], e), a = K(r, e);
    return t.style.marginRight = M(a), t;
  }, Se = function(e, t, a) {
    var n = "";
    switch (e) {
      case "amsrm":
        n = "AMS";
        break;
      case "textrm":
        n = "Main";
        break;
      case "textsf":
        n = "SansSerif";
        break;
      case "texttt":
        n = "Typewriter";
        break;
      default:
        n = e;
    }
    var l;
    return t === "textbf" && a === "textit" ? l = "BoldItalic" : t === "textbf" ? l = "Bold" : t === "textit" ? l = "Italic" : l = "Regular", n + "-" + l;
  }, vt = {
    mathbf: {
      variant: "bold",
      fontName: "Main-Bold"
    },
    mathrm: {
      variant: "normal",
      fontName: "Main-Regular"
    },
    textit: {
      variant: "italic",
      fontName: "Main-Italic"
    },
    mathit: {
      variant: "italic",
      fontName: "Main-Italic"
    },
    mathnormal: {
      variant: "italic",
      fontName: "Math-Italic"
    },
    mathsfit: {
      variant: "sans-serif-italic",
      fontName: "SansSerif-Italic"
    },
    mathbb: {
      variant: "double-struck",
      fontName: "AMS-Regular"
    },
    mathcal: {
      variant: "script",
      fontName: "Caligraphic-Regular"
    },
    mathfrak: {
      variant: "fraktur",
      fontName: "Fraktur-Regular"
    },
    mathscr: {
      variant: "script",
      fontName: "Script-Regular"
    },
    mathsf: {
      variant: "sans-serif",
      fontName: "SansSerif-Regular"
    },
    mathtt: {
      variant: "monospace",
      fontName: "Typewriter-Regular"
    }
  }, Fr = {
    vec: [
      "vec",
      0.471,
      0.714
    ],
    oiintSize1: [
      "oiintSize1",
      0.957,
      0.499
    ],
    oiintSize2: [
      "oiintSize2",
      1.472,
      0.659
    ],
    oiiintSize1: [
      "oiiintSize1",
      1.304,
      0.499
    ],
    oiiintSize2: [
      "oiiintSize2",
      1.98,
      0.659
    ]
  }, Lr = function(e, t) {
    var [a, n, l] = Fr[e], u = new L0(a), h = new B0([
      u
    ], {
      width: M(n),
      height: M(l),
      style: "width:" + M(n),
      viewBox: "0 0 " + 1e3 * n + " " + 1e3 * l,
      preserveAspectRatio: "xMinYMin"
    }), c = P0([
      "overlay"
    ], [
      h
    ], t);
    return c.height = l, c.style.height = M(l), c.style.width = M(n), c;
  }, Z = {
    number: 3,
    unit: "mu"
  }, W0 = {
    number: 4,
    unit: "mu"
  }, M0 = {
    number: 5,
    unit: "mu"
  }, ya = {
    mord: {
      mop: Z,
      mbin: W0,
      mrel: M0,
      minner: Z
    },
    mop: {
      mord: Z,
      mop: Z,
      mrel: M0,
      minner: Z
    },
    mbin: {
      mord: W0,
      mop: W0,
      mopen: W0,
      minner: W0
    },
    mrel: {
      mord: M0,
      mop: M0,
      mopen: M0,
      minner: M0
    },
    mopen: {},
    mclose: {
      mop: Z,
      mbin: W0,
      mrel: M0,
      minner: Z
    },
    mpunct: {
      mord: Z,
      mop: Z,
      mrel: M0,
      mopen: Z,
      mclose: Z,
      mpunct: Z,
      minner: Z
    },
    minner: {
      mord: Z,
      mop: Z,
      mbin: W0,
      mrel: M0,
      mopen: Z,
      mpunct: Z,
      minner: Z
    }
  }, xa = {
    mord: {
      mop: Z
    },
    mop: {
      mord: Z,
      mop: Z
    },
    mbin: {},
    mrel: {},
    mopen: {},
    mclose: {
      mop: Z
    },
    mpunct: {},
    minner: {
      mop: Z
    }
  }, Pr = {}, Ee = {}, Re = {};
  function B(r) {
    for (var { type: e, names: t, props: a, handler: n, htmlBuilder: l, mathmlBuilder: u } = r, h = {
      type: e,
      numArgs: a.numArgs,
      argTypes: a.argTypes,
      allowedInArgument: !!a.allowedInArgument,
      allowedInText: !!a.allowedInText,
      allowedInMath: a.allowedInMath === void 0 ? true : a.allowedInMath,
      numOptionalArgs: a.numOptionalArgs || 0,
      infix: !!a.infix,
      primitive: !!a.primitive,
      handler: n
    }, c = 0; c < t.length; ++c)
      Pr[t[c]] = h;
    e && (l && (Ee[e] = l), u && (Re[e] = u));
  }
  function X0(r) {
    var { type: e, htmlBuilder: t, mathmlBuilder: a } = r;
    B({
      type: e,
      names: [],
      props: {
        numArgs: 0
      },
      handler() {
        throw new Error("Should never be called.");
      },
      htmlBuilder: t,
      mathmlBuilder: a
    });
  }
  var Ie = function(e) {
    return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
  }, Q = function(e) {
    return e.type === "ordgroup" ? e.body : [
      e
    ];
  }, wa = /* @__PURE__ */ new Set([
    "leftmost",
    "mbin",
    "mopen",
    "mrel",
    "mop",
    "mpunct"
  ]), Sa = /* @__PURE__ */ new Set([
    "rightmost",
    "mrel",
    "mclose",
    "mpunct"
  ]), ka = {
    display: N.DISPLAY,
    text: N.TEXT,
    script: N.SCRIPT,
    scriptscript: N.SCRIPTSCRIPT
  }, za = {
    mord: "mord",
    mop: "mop",
    mbin: "mbin",
    mrel: "mrel",
    mopen: "mopen",
    mclose: "mclose",
    mpunct: "mpunct",
    minner: "minner"
  }, r0 = function(e, t, a, n) {
    n === void 0 && (n = [
      null,
      null
    ]);
    for (var l = [], u = 0; u < e.length; u++) {
      var h = U(e[u], t);
      if (h instanceof re) {
        var c = h.children;
        l.push(...c);
      } else
        l.push(h);
    }
    if (Hr(l), !a)
      return l;
    var p = t;
    if (e.length === 1) {
      var g = e[0];
      g.type === "sizing" ? p = t.havingSize(g.size) : g.type === "styling" && (p = t.havingStyle(ka[g.style]));
    }
    var b = S([
      n[0] || "leftmost"
    ], [], t), y = S([
      n[1] || "rightmost"
    ], [], t), x = a === "root";
    return gt(l, (A, T) => {
      var C = T.classes[0], q = A.classes[0];
      C === "mbin" && Sa.has(q) ? T.classes[0] = "mord" : q === "mbin" && wa.has(C) && (A.classes[0] = "mord");
    }, {
      node: b
    }, y, x), gt(l, (A, T) => {
      var C, q, I = yt(T), H = yt(A), F = I && H ? A.hasClass("mtight") ? (C = xa[I]) == null ? void 0 : C[H] : (q = ya[I]) == null ? void 0 : q[H] : null;
      if (F)
        return Or(F, p);
    }, {
      node: b
    }, y, x), l;
  }, gt = function(e, t, a, n, l) {
    n && e.push(n);
    for (var u = 0; u < e.length; u++) {
      var h = e[u], c = Gr(h);
      if (c) {
        gt(c.children, t, a, null, l);
        continue;
      }
      var p = !h.hasClass("mspace");
      if (p) {
        var g = t(h, a.node);
        g && (a.insertAfter ? a.insertAfter(g) : (e.unshift(g), u++));
      }
      p ? a.node = h : l && h.hasClass("newline") && (a.node = S([
        "leftmost"
      ])), a.insertAfter = ((b) => (y) => {
        e.splice(b + 1, 0, y), u++;
      })(u);
    }
    n && e.pop();
  }, Gr = function(e) {
    return e instanceof re || e instanceof Ne || e instanceof ae && e.hasClass("enclosing") ? e : null;
  }, bt = function(e, t) {
    var a = Gr(e);
    if (a) {
      var n = a.children;
      if (n.length) {
        if (t === "right")
          return bt(n[n.length - 1], "right");
        if (t === "left")
          return bt(n[0], "left");
      }
    }
    return e;
  }, yt = function(e, t) {
    if (!e)
      return null;
    t && (e = bt(e, t));
    var a = e.classes[0];
    return za[a] || null;
  }, he = function(e, t) {
    var a = [
      "nulldelimiter"
    ].concat(e.baseSizingClasses());
    return S(t.concat(a));
  }, U = function(e, t, a) {
    if (!e)
      return S();
    if (Ee[e.type]) {
      var n = Ee[e.type](e, t);
      if (a && t.size !== a.size) {
        n = S(t.sizingClasses(a), [
          n
        ], t);
        var l = t.sizeMultiplier / a.sizeMultiplier;
        n.height *= l, n.depth *= l;
      }
      return n;
    } else
      throw new k("Got group of unknown type: '" + e.type + "'");
  };
  function ke(r, e) {
    var t = S([
      "base"
    ], r, e), a = S([
      "strut"
    ]);
    return a.style.height = M(t.height + t.depth), t.depth && (a.style.verticalAlign = M(-t.depth)), t.children.unshift(a), t;
  }
  function xt(r, e) {
    var t = null;
    r.length === 1 && r[0].type === "tag" && (t = r[0].tag, r = r[0].body);
    var a = r0(r, e, "root"), n;
    a.length === 2 && a[1].hasClass("tag") && (n = a.pop());
    for (var l = [], u = [], h = 0; h < a.length; h++)
      if (u.push(a[h]), a[h].hasClass("mbin") || a[h].hasClass("mrel") || a[h].hasClass("allowbreak")) {
        for (var c = false; h < a.length - 1 && a[h + 1].hasClass("mspace") && !a[h + 1].hasClass("newline"); )
          h++, u.push(a[h]), a[h].hasClass("nobreak") && (c = true);
        c || (l.push(ke(u, e)), u = []);
      } else
        a[h].hasClass("newline") && (u.pop(), u.length > 0 && (l.push(ke(u, e)), u = []), l.push(a[h]));
    u.length > 0 && l.push(ke(u, e));
    var p;
    t ? (p = ke(r0(t, e, true), e), p.classes = [
      "tag"
    ], l.push(p)) : n && l.push(n);
    var g = S([
      "katex-html"
    ], l);
    if (g.setAttribute("aria-hidden", "true"), p) {
      var b = p.children[0];
      b.style.height = M(g.height + g.depth), g.depth && (b.style.verticalAlign = M(-g.depth));
    }
    return g;
  }
  function Ur(r) {
    return new re(r);
  }
  class z {
    constructor(e, t, a) {
      this.type = e, this.attributes = {}, this.children = t || [], this.classes = a || [];
    }
    setAttribute(e, t) {
      this.attributes[e] = t;
    }
    getAttribute(e) {
      return this.attributes[e];
    }
    toNode() {
      var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
      for (var t in this.attributes)
        Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
      this.classes.length > 0 && (e.className = F0(this.classes));
      for (var a = 0; a < this.children.length; a++)
        if (this.children[a] instanceof _ && this.children[a + 1] instanceof _) {
          for (var n = this.children[a].toText() + this.children[++a].toText(); this.children[a + 1] instanceof _; )
            n += this.children[++a].toText();
          e.appendChild(new _(n).toNode());
        } else
          e.appendChild(this.children[a].toNode());
      return e;
    }
    toMarkup() {
      var e = "<" + this.type;
      for (var t in this.attributes)
        Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += a0(this.attributes[t]), e += '"');
      this.classes.length > 0 && (e += ' class ="' + a0(F0(this.classes)) + '"'), e += ">";
      for (var a = 0; a < this.children.length; a++)
        e += this.children[a].toMarkup();
      return e += "</" + this.type + ">", e;
    }
    toText() {
      return this.children.map((e) => e.toText()).join("");
    }
  }
  class _ {
    constructor(e) {
      this.text = e;
    }
    toNode() {
      return document.createTextNode(this.text);
    }
    toMarkup() {
      return a0(this.toText());
    }
    toText() {
      return this.text;
    }
  }
  class Vr {
    constructor(e) {
      this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = "\u200A" : e >= 0.1666 && e <= 0.1667 ? this.character = "\u2009" : e >= 0.2222 && e <= 0.2223 ? this.character = "\u2005" : e >= 0.2777 && e <= 0.2778 ? this.character = "\u2005\u200A" : e >= -0.05556 && e <= -0.05555 ? this.character = "\u200A\u2063" : e >= -0.1667 && e <= -0.1666 ? this.character = "\u2009\u2063" : e >= -0.2223 && e <= -0.2222 ? this.character = "\u205F\u2063" : e >= -0.2778 && e <= -0.2777 ? this.character = "\u2005\u2063" : this.character = null;
    }
    toNode() {
      if (this.character)
        return document.createTextNode(this.character);
      var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
      return e.setAttribute("width", M(this.width)), e;
    }
    toMarkup() {
      return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + M(this.width) + '"/>';
    }
    toText() {
      return this.character ? this.character : " ";
    }
  }
  var Ma = /* @__PURE__ */ new Set([
    "\\imath",
    "\\jmath"
  ]), Aa = /* @__PURE__ */ new Set([
    "mrow",
    "mtable"
  ]), g0 = function(e, t, a) {
    return Y[t][e] && Y[t][e].replace && e.charCodeAt(0) !== 55349 && !(Nr.hasOwnProperty(e) && a && (a.fontFamily && a.fontFamily.slice(4, 6) === "tt" || a.font && a.font.slice(4, 6) === "tt")) && (e = Y[t][e].replace), new _(e);
  }, qt = function(e) {
    return e.length === 1 ? e[0] : new z("mrow", e);
  }, Et = function(e, t) {
    if (t.fontFamily === "texttt")
      return "monospace";
    if (t.fontFamily === "textsf")
      return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
    if (t.fontShape === "textit" && t.fontWeight === "textbf")
      return "bold-italic";
    if (t.fontShape === "textit")
      return "italic";
    if (t.fontWeight === "textbf")
      return "bold";
    var a = t.font;
    if (!a || a === "mathnormal")
      return null;
    var n = e.mode;
    if (a === "mathit")
      return "italic";
    if (a === "boldsymbol")
      return e.type === "textord" ? "bold" : "bold-italic";
    if (a === "mathbf")
      return "bold";
    if (a === "mathbb")
      return "double-struck";
    if (a === "mathsfit")
      return "sans-serif-italic";
    if (a === "mathfrak")
      return "fraktur";
    if (a === "mathscr" || a === "mathcal")
      return "script";
    if (a === "mathsf")
      return "sans-serif";
    if (a === "mathtt")
      return "monospace";
    var l = e.text;
    if (Ma.has(l))
      return null;
    if (Y[n][l]) {
      var u = Y[n][l].replace;
      u && (l = u);
    }
    var h = vt[a].fontName;
    return Bt(l, h, n) ? vt[a].variant : null;
  };
  function et(r) {
    if (!r)
      return false;
    if (r.type === "mi" && r.children.length === 1) {
      var e = r.children[0];
      return e instanceof _ && e.text === ".";
    } else if (r.type === "mo" && r.children.length === 1 && r.getAttribute("separator") === "true" && r.getAttribute("lspace") === "0em" && r.getAttribute("rspace") === "0em") {
      var t = r.children[0];
      return t instanceof _ && t.text === ",";
    } else
      return false;
  }
  var p0 = function(e, t, a) {
    if (e.length === 1) {
      var n = W(e[0], t);
      return a && n instanceof z && n.type === "mo" && (n.setAttribute("lspace", "0em"), n.setAttribute("rspace", "0em")), [
        n
      ];
    }
    for (var l = [], u, h = 0; h < e.length; h++) {
      var c = W(e[h], t);
      if (c instanceof z && u instanceof z) {
        if (c.type === "mtext" && u.type === "mtext" && c.getAttribute("mathvariant") === u.getAttribute("mathvariant")) {
          u.children.push(...c.children);
          continue;
        } else if (c.type === "mn" && u.type === "mn") {
          u.children.push(...c.children);
          continue;
        } else if (et(c) && u.type === "mn") {
          u.children.push(...c.children);
          continue;
        } else if (c.type === "mn" && et(u))
          c.children = [
            ...u.children,
            ...c.children
          ], l.pop();
        else if ((c.type === "msup" || c.type === "msub") && c.children.length >= 1 && (u.type === "mn" || et(u))) {
          var p = c.children[0];
          p instanceof z && p.type === "mn" && (p.children = [
            ...u.children,
            ...p.children
          ], l.pop());
        } else if (u.type === "mi" && u.children.length === 1) {
          var g = u.children[0];
          if (g instanceof _ && g.text === "\u0338" && (c.type === "mo" || c.type === "mi" || c.type === "mn")) {
            var b = c.children[0];
            b instanceof _ && b.text.length > 0 && (b.text = b.text.slice(0, 1) + "\u0338" + b.text.slice(1), l.pop());
          }
        }
      }
      l.push(c), u = c;
    }
    return l;
  }, G0 = function(e, t, a) {
    return qt(p0(e, t, a));
  }, W = function(e, t) {
    if (!e)
      return new z("mrow");
    if (Re[e.type]) {
      var a = Re[e.type](e, t);
      return a;
    } else
      throw new k("Got group of unknown type: '" + e.type + "'");
  };
  function ir(r, e, t, a, n) {
    var l = p0(r, t), u;
    l.length === 1 && l[0] instanceof z && Aa.has(l[0].type) ? u = l[0] : u = new z("mrow", l);
    var h = new z("annotation", [
      new _(e)
    ]);
    h.setAttribute("encoding", "application/x-tex");
    var c = new z("semantics", [
      u,
      h
    ]), p = new z("math", [
      c
    ]);
    p.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), a && p.setAttribute("display", "block");
    var g = n ? "katex" : "katex-mathml";
    return S([
      g
    ], [
      p
    ]);
  }
  var Ta = [
    [
      1,
      1,
      1
    ],
    [
      2,
      1,
      1
    ],
    [
      3,
      1,
      1
    ],
    [
      4,
      2,
      1
    ],
    [
      5,
      2,
      1
    ],
    [
      6,
      3,
      1
    ],
    [
      7,
      4,
      2
    ],
    [
      8,
      6,
      3
    ],
    [
      9,
      7,
      6
    ],
    [
      10,
      8,
      7
    ],
    [
      11,
      10,
      9
    ]
  ], lr = [
    0.5,
    0.6,
    0.7,
    0.8,
    0.9,
    1,
    1.2,
    1.44,
    1.728,
    2.074,
    2.488
  ], sr = function(e, t) {
    return t.size < 2 ? e : Ta[e - 1][t.size - 1];
  };
  class A0 {
    constructor(e) {
      this.style = e.style, this.color = e.color, this.size = e.size || A0.BASESIZE, this.textSize = e.textSize || this.size, this.phantom = !!e.phantom, this.font = e.font || "", this.fontFamily = e.fontFamily || "", this.fontWeight = e.fontWeight || "", this.fontShape = e.fontShape || "", this.sizeMultiplier = lr[this.size - 1], this.maxSize = e.maxSize, this.minRuleThickness = e.minRuleThickness, this._fontMetrics = void 0;
    }
    extend(e) {
      var t = {
        style: this.style,
        size: this.size,
        textSize: this.textSize,
        color: this.color,
        phantom: this.phantom,
        font: this.font,
        fontFamily: this.fontFamily,
        fontWeight: this.fontWeight,
        fontShape: this.fontShape,
        maxSize: this.maxSize,
        minRuleThickness: this.minRuleThickness
      };
      return Object.assign(t, e), new A0(t);
    }
    havingStyle(e) {
      return this.style === e ? this : this.extend({
        style: e,
        size: sr(this.textSize, e)
      });
    }
    havingCrampedStyle() {
      return this.havingStyle(this.style.cramp());
    }
    havingSize(e) {
      return this.size === e && this.textSize === e ? this : this.extend({
        style: this.style.text(),
        size: e,
        textSize: e,
        sizeMultiplier: lr[e - 1]
      });
    }
    havingBaseStyle(e) {
      e = e || this.style.text();
      var t = sr(A0.BASESIZE, e);
      return this.size === t && this.textSize === A0.BASESIZE && this.style === e ? this : this.extend({
        style: e,
        size: t
      });
    }
    havingBaseSizing() {
      var e;
      switch (this.style.id) {
        case 4:
        case 5:
          e = 3;
          break;
        case 6:
        case 7:
          e = 1;
          break;
        default:
          e = 6;
      }
      return this.extend({
        style: this.style.text(),
        size: e
      });
    }
    withColor(e) {
      return this.extend({
        color: e
      });
    }
    withPhantom() {
      return this.extend({
        phantom: true
      });
    }
    withFont(e) {
      return this.extend({
        font: e
      });
    }
    withTextFontFamily(e) {
      return this.extend({
        fontFamily: e,
        font: ""
      });
    }
    withTextFontWeight(e) {
      return this.extend({
        fontWeight: e,
        font: ""
      });
    }
    withTextFontShape(e) {
      return this.extend({
        fontShape: e,
        font: ""
      });
    }
    sizingClasses(e) {
      return e.size !== this.size ? [
        "sizing",
        "reset-size" + e.size,
        "size" + this.size
      ] : [];
    }
    baseSizingClasses() {
      return this.size !== A0.BASESIZE ? [
        "sizing",
        "reset-size" + this.size,
        "size" + A0.BASESIZE
      ] : [];
    }
    fontMetrics() {
      return this._fontMetrics || (this._fontMetrics = ma(this.size)), this._fontMetrics;
    }
    getColor() {
      return this.phantom ? "transparent" : this.color;
    }
  }
  A0.BASESIZE = 6;
  var $r = function(e) {
    return new A0({
      style: e.displayMode ? N.DISPLAY : N.TEXT,
      maxSize: e.maxSize,
      minRuleThickness: e.minRuleThickness
    });
  }, Wr = function(e, t) {
    if (t.displayMode) {
      var a = [
        "katex-display"
      ];
      t.leqno && a.push("leqno"), t.fleqn && a.push("fleqn"), e = S(a, [
        e
      ]);
    }
    return e;
  }, Ba = function(e, t, a) {
    var n = $r(a), l;
    if (a.output === "mathml")
      return ir(e, t, n, a.displayMode, true);
    if (a.output === "html") {
      var u = xt(e, n);
      l = S([
        "katex"
      ], [
        u
      ]);
    } else {
      var h = ir(e, t, n, a.displayMode, false), c = xt(e, n);
      l = S([
        "katex"
      ], [
        h,
        c
      ]);
    }
    return Wr(l, a);
  }, Da = function(e, t, a) {
    var n = $r(a), l = xt(e, n), u = S([
      "katex"
    ], [
      l
    ]);
    return Wr(u, a);
  }, Ca = {
    widehat: "^",
    widecheck: "\u02C7",
    widetilde: "~",
    utilde: "~",
    overleftarrow: "\u2190",
    underleftarrow: "\u2190",
    xleftarrow: "\u2190",
    overrightarrow: "\u2192",
    underrightarrow: "\u2192",
    xrightarrow: "\u2192",
    underbrace: "\u23DF",
    overbrace: "\u23DE",
    overgroup: "\u23E0",
    undergroup: "\u23E1",
    overleftrightarrow: "\u2194",
    underleftrightarrow: "\u2194",
    xleftrightarrow: "\u2194",
    Overrightarrow: "\u21D2",
    xRightarrow: "\u21D2",
    overleftharpoon: "\u21BC",
    xleftharpoonup: "\u21BC",
    overrightharpoon: "\u21C0",
    xrightharpoonup: "\u21C0",
    xLeftarrow: "\u21D0",
    xLeftrightarrow: "\u21D4",
    xhookleftarrow: "\u21A9",
    xhookrightarrow: "\u21AA",
    xmapsto: "\u21A6",
    xrightharpoondown: "\u21C1",
    xleftharpoondown: "\u21BD",
    xrightleftharpoons: "\u21CC",
    xleftrightharpoons: "\u21CB",
    xtwoheadleftarrow: "\u219E",
    xtwoheadrightarrow: "\u21A0",
    xlongequal: "=",
    xtofrom: "\u21C4",
    xrightleftarrows: "\u21C4",
    xrightequilibrium: "\u21CC",
    xleftequilibrium: "\u21CB",
    "\\cdrightarrow": "\u2192",
    "\\cdleftarrow": "\u2190",
    "\\cdlongequal": "="
  }, Le = function(e) {
    var t = new z("mo", [
      new _(Ca[e.replace(/^\\/, "")])
    ]);
    return t.setAttribute("stretchy", "true"), t;
  }, qa = {
    overrightarrow: [
      [
        "rightarrow"
      ],
      0.888,
      522,
      "xMaxYMin"
    ],
    overleftarrow: [
      [
        "leftarrow"
      ],
      0.888,
      522,
      "xMinYMin"
    ],
    underrightarrow: [
      [
        "rightarrow"
      ],
      0.888,
      522,
      "xMaxYMin"
    ],
    underleftarrow: [
      [
        "leftarrow"
      ],
      0.888,
      522,
      "xMinYMin"
    ],
    xrightarrow: [
      [
        "rightarrow"
      ],
      1.469,
      522,
      "xMaxYMin"
    ],
    "\\cdrightarrow": [
      [
        "rightarrow"
      ],
      3,
      522,
      "xMaxYMin"
    ],
    xleftarrow: [
      [
        "leftarrow"
      ],
      1.469,
      522,
      "xMinYMin"
    ],
    "\\cdleftarrow": [
      [
        "leftarrow"
      ],
      3,
      522,
      "xMinYMin"
    ],
    Overrightarrow: [
      [
        "doublerightarrow"
      ],
      0.888,
      560,
      "xMaxYMin"
    ],
    xRightarrow: [
      [
        "doublerightarrow"
      ],
      1.526,
      560,
      "xMaxYMin"
    ],
    xLeftarrow: [
      [
        "doubleleftarrow"
      ],
      1.526,
      560,
      "xMinYMin"
    ],
    overleftharpoon: [
      [
        "leftharpoon"
      ],
      0.888,
      522,
      "xMinYMin"
    ],
    xleftharpoonup: [
      [
        "leftharpoon"
      ],
      0.888,
      522,
      "xMinYMin"
    ],
    xleftharpoondown: [
      [
        "leftharpoondown"
      ],
      0.888,
      522,
      "xMinYMin"
    ],
    overrightharpoon: [
      [
        "rightharpoon"
      ],
      0.888,
      522,
      "xMaxYMin"
    ],
    xrightharpoonup: [
      [
        "rightharpoon"
      ],
      0.888,
      522,
      "xMaxYMin"
    ],
    xrightharpoondown: [
      [
        "rightharpoondown"
      ],
      0.888,
      522,
      "xMaxYMin"
    ],
    xlongequal: [
      [
        "longequal"
      ],
      0.888,
      334,
      "xMinYMin"
    ],
    "\\cdlongequal": [
      [
        "longequal"
      ],
      3,
      334,
      "xMinYMin"
    ],
    xtwoheadleftarrow: [
      [
        "twoheadleftarrow"
      ],
      0.888,
      334,
      "xMinYMin"
    ],
    xtwoheadrightarrow: [
      [
        "twoheadrightarrow"
      ],
      0.888,
      334,
      "xMaxYMin"
    ],
    overleftrightarrow: [
      [
        "leftarrow",
        "rightarrow"
      ],
      0.888,
      522
    ],
    overbrace: [
      [
        "leftbrace",
        "midbrace",
        "rightbrace"
      ],
      1.6,
      548
    ],
    underbrace: [
      [
        "leftbraceunder",
        "midbraceunder",
        "rightbraceunder"
      ],
      1.6,
      548
    ],
    underleftrightarrow: [
      [
        "leftarrow",
        "rightarrow"
      ],
      0.888,
      522
    ],
    xleftrightarrow: [
      [
        "leftarrow",
        "rightarrow"
      ],
      1.75,
      522
    ],
    xLeftrightarrow: [
      [
        "doubleleftarrow",
        "doublerightarrow"
      ],
      1.75,
      560
    ],
    xrightleftharpoons: [
      [
        "leftharpoondownplus",
        "rightharpoonplus"
      ],
      1.75,
      716
    ],
    xleftrightharpoons: [
      [
        "leftharpoonplus",
        "rightharpoondownplus"
      ],
      1.75,
      716
    ],
    xhookleftarrow: [
      [
        "leftarrow",
        "righthook"
      ],
      1.08,
      522
    ],
    xhookrightarrow: [
      [
        "lefthook",
        "rightarrow"
      ],
      1.08,
      522
    ],
    overlinesegment: [
      [
        "leftlinesegment",
        "rightlinesegment"
      ],
      0.888,
      522
    ],
    underlinesegment: [
      [
        "leftlinesegment",
        "rightlinesegment"
      ],
      0.888,
      522
    ],
    overgroup: [
      [
        "leftgroup",
        "rightgroup"
      ],
      0.888,
      342
    ],
    undergroup: [
      [
        "leftgroupunder",
        "rightgroupunder"
      ],
      0.888,
      342
    ],
    xmapsto: [
      [
        "leftmapsto",
        "rightarrow"
      ],
      1.5,
      522
    ],
    xtofrom: [
      [
        "leftToFrom",
        "rightToFrom"
      ],
      1.75,
      528
    ],
    xrightleftarrows: [
      [
        "baraboveleftarrow",
        "rightarrowabovebar"
      ],
      1.75,
      901
    ],
    xrightequilibrium: [
      [
        "baraboveshortleftharpoon",
        "rightharpoonaboveshortbar"
      ],
      1.75,
      716
    ],
    xleftequilibrium: [
      [
        "shortbaraboveleftharpoon",
        "shortrightharpoonabovebar"
      ],
      1.75,
      716
    ]
  }, Ea = /* @__PURE__ */ new Set([
    "widehat",
    "widecheck",
    "widetilde",
    "utilde"
  ]), Pe = function(e, t) {
    function a() {
      var h = 4e5, c = e.label.slice(1);
      if (Ea.has(c)) {
        var p = e, g = p.base.type === "ordgroup" ? p.base.body.length : 1, b, y, x;
        if (g > 5)
          c === "widehat" || c === "widecheck" ? (b = 420, h = 2364, x = 0.42, y = c + "4") : (b = 312, h = 2340, x = 0.34, y = "tilde4");
        else {
          var A = [
            1,
            1,
            2,
            2,
            3,
            3
          ][g];
          c === "widehat" || c === "widecheck" ? (h = [
            0,
            1062,
            2364,
            2364,
            2364
          ][A], b = [
            0,
            239,
            300,
            360,
            420
          ][A], x = [
            0,
            0.24,
            0.3,
            0.3,
            0.36,
            0.42
          ][A], y = c + A) : (h = [
            0,
            600,
            1033,
            2339,
            2340
          ][A], b = [
            0,
            260,
            286,
            306,
            312
          ][A], x = [
            0,
            0.26,
            0.286,
            0.3,
            0.306,
            0.34
          ][A], y = "tilde" + A);
        }
        var T = new L0(y), C = new B0([
          T
        ], {
          width: "100%",
          height: M(x),
          viewBox: "0 0 " + h + " " + b,
          preserveAspectRatio: "none"
        });
        return {
          span: P0([], [
            C
          ], t),
          minWidth: 0,
          height: x
        };
      } else {
        var q = [], I = qa[c], [H, F, V] = I, L = V / 1e3, P = H.length, X, $;
        if (P === 1) {
          var o0 = I[3];
          X = [
            "hide-tail"
          ], $ = [
            o0
          ];
        } else if (P === 2)
          X = [
            "halfarrow-left",
            "halfarrow-right"
          ], $ = [
            "xMinYMin",
            "xMaxYMin"
          ];
        else if (P === 3)
          X = [
            "brace-left",
            "brace-center",
            "brace-right"
          ], $ = [
            "xMinYMin",
            "xMidYMin",
            "xMaxYMin"
          ];
        else
          throw new Error(`Correct katexImagesData or update code here to support
                    ` + P + " children.");
        for (var n0 = 0; n0 < P; n0++) {
          var t0 = new L0(H[n0]), V0 = new B0([
            t0
          ], {
            width: "400em",
            height: M(L),
            viewBox: "0 0 " + h + " " + V,
            preserveAspectRatio: $[n0] + " slice"
          }), h0 = P0([
            X[n0]
          ], [
            V0
          ], t);
          if (P === 1)
            return {
              span: h0,
              minWidth: F,
              height: L
            };
          h0.style.height = M(L), q.push(h0);
        }
        return {
          span: S([
            "stretchy"
          ], q, t),
          minWidth: F,
          height: L
        };
      }
    }
    var { span: n, minWidth: l, height: u } = a();
    return n.height = u, n.style.height = M(u), l > 0 && (n.style.minWidth = M(l)), n;
  }, Ra = function(e, t, a, n, l) {
    var u, h = e.height + e.depth + a + n;
    if (/fbox|color|angl/.test(t)) {
      if (u = S([
        "stretchy",
        t
      ], [], l), t === "fbox") {
        var c = l.color && l.getColor();
        c && (u.style.borderColor = c);
      }
    } else {
      var p = [];
      /^[bx]cancel$/.test(t) && p.push(new ft({
        x1: "0",
        y1: "0",
        x2: "100%",
        y2: "100%",
        "stroke-width": "0.046em"
      })), /^x?cancel$/.test(t) && p.push(new ft({
        x1: "0",
        y1: "100%",
        x2: "100%",
        y2: "0",
        "stroke-width": "0.046em"
      }));
      var g = new B0(p, {
        width: "100%",
        height: M(h)
      });
      u = P0([], [
        g
      ], l);
    }
    return u.height = h, u.style.height = M(h), u;
  };
  function O(r, e) {
    if (!r || r.type !== e)
      throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r)));
    return r;
  }
  function Ge(r) {
    var e = Ue(r);
    if (!e)
      throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r)));
    return e;
  }
  function Ue(r) {
    return r && (r.type === "atom" || da.hasOwnProperty(r.type)) ? r : null;
  }
  var Xr = (r) => {
    if (r instanceof d0)
      return r;
    if (oa(r) && r.children.length === 1)
      return Xr(r.children[0]);
  }, Rt = (r, e) => {
    var t, a, n;
    r && r.type === "supsub" ? (a = O(r.base, "accent"), t = a.base, r.base = t, n = ua(U(r, e)), r.base = a) : (a = O(r, "accent"), t = a.base);
    var l = U(t, e.havingCrampedStyle()), u = a.isShifty && D0(t), h = 0;
    if (u) {
      var c, p;
      h = (c = (p = Xr(l)) == null ? void 0 : p.skew) != null ? c : 0;
    }
    var g = a.label === "\\c", b = g ? l.height + l.depth : Math.min(l.height, e.fontMetrics().xHeight), y;
    if (a.isStretchy)
      y = Pe(a, e), y = G({
        positionType: "firstBaseline",
        children: [
          {
            type: "elem",
            elem: l
          },
          {
            type: "elem",
            elem: y,
            wrapperClasses: [
              "svg-align"
            ],
            wrapperStyle: h > 0 ? {
              width: "calc(100% - " + M(2 * h) + ")",
              marginLeft: M(2 * h)
            } : void 0
          }
        ]
      });
    else {
      var x, A;
      a.label === "\\vec" ? (x = Lr("vec", e), A = Fr.vec[1]) : (x = Fe({
        type: "textord",
        mode: a.mode,
        text: a.label
      }, e, "textord"), x = sa(x), x.italic = 0, A = x.width, g && (b += x.depth)), y = S([
        "accent-body"
      ], [
        x
      ]);
      var T = a.label === "\\textcircled";
      T && (y.classes.push("accent-full"), b = l.height);
      var C = h;
      T || (C -= A / 2), y.style.left = M(C), a.label === "\\textcircled" && (y.style.top = ".2em"), y = G({
        positionType: "firstBaseline",
        children: [
          {
            type: "elem",
            elem: l
          },
          {
            type: "kern",
            size: -b
          },
          {
            type: "elem",
            elem: y
          }
        ]
      });
    }
    var q = S([
      "mord",
      "accent"
    ], [
      y
    ], e);
    return n ? (n.children[0] = q, n.height = Math.max(q.height, n.height), n.classes[0] = "mord", n) : q;
  }, Yr = (r, e) => {
    var t = r.isStretchy ? Le(r.label) : new z("mo", [
      g0(r.label, r.mode)
    ]), a = new z("mover", [
      W(r.base, e),
      t
    ]);
    return a.setAttribute("accent", "true"), a;
  }, Ia = new RegExp([
    "\\acute",
    "\\grave",
    "\\ddot",
    "\\tilde",
    "\\bar",
    "\\breve",
    "\\check",
    "\\hat",
    "\\vec",
    "\\dot",
    "\\mathring"
  ].map((r) => "\\" + r).join("|"));
  B({
    type: "accent",
    names: [
      "\\acute",
      "\\grave",
      "\\ddot",
      "\\tilde",
      "\\bar",
      "\\breve",
      "\\check",
      "\\hat",
      "\\vec",
      "\\dot",
      "\\mathring",
      "\\widecheck",
      "\\widehat",
      "\\widetilde",
      "\\overrightarrow",
      "\\overleftarrow",
      "\\Overrightarrow",
      "\\overleftrightarrow",
      "\\overgroup",
      "\\overlinesegment",
      "\\overleftharpoon",
      "\\overrightharpoon"
    ],
    props: {
      numArgs: 1
    },
    handler: (r, e) => {
      var t = Ie(e[0]), a = !Ia.test(r.funcName), n = !a || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck";
      return {
        type: "accent",
        mode: r.parser.mode,
        label: r.funcName,
        isStretchy: a,
        isShifty: n,
        base: t
      };
    },
    htmlBuilder: Rt,
    mathmlBuilder: Yr
  });
  B({
    type: "accent",
    names: [
      "\\'",
      "\\`",
      "\\^",
      "\\~",
      "\\=",
      "\\u",
      "\\.",
      '\\"',
      "\\c",
      "\\r",
      "\\H",
      "\\v",
      "\\textcircled"
    ],
    props: {
      numArgs: 1,
      allowedInText: true,
      allowedInMath: true,
      argTypes: [
        "primitive"
      ]
    },
    handler: (r, e) => {
      var t = e[0], a = r.parser.mode;
      return a === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), a = "text"), {
        type: "accent",
        mode: a,
        label: r.funcName,
        isStretchy: false,
        isShifty: true,
        base: t
      };
    },
    htmlBuilder: Rt,
    mathmlBuilder: Yr
  });
  B({
    type: "accentUnder",
    names: [
      "\\underleftarrow",
      "\\underrightarrow",
      "\\underleftrightarrow",
      "\\undergroup",
      "\\underlinesegment",
      "\\utilde"
    ],
    props: {
      numArgs: 1
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = e[0];
      return {
        type: "accentUnder",
        mode: t.mode,
        label: a,
        base: n
      };
    },
    htmlBuilder: (r, e) => {
      var t = U(r.base, e), a = Pe(r, e), n = r.label === "\\utilde" ? 0.12 : 0, l = G({
        positionType: "top",
        positionData: t.height,
        children: [
          {
            type: "elem",
            elem: a,
            wrapperClasses: [
              "svg-align"
            ]
          },
          {
            type: "kern",
            size: n
          },
          {
            type: "elem",
            elem: t
          }
        ]
      });
      return S([
        "mord",
        "accentunder"
      ], [
        l
      ], e);
    },
    mathmlBuilder: (r, e) => {
      var t = Le(r.label), a = new z("munder", [
        W(r.base, e),
        t
      ]);
      return a.setAttribute("accentunder", "true"), a;
    }
  });
  var ze = (r) => {
    var e = new z("mpadded", r ? [
      r
    ] : []);
    return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
  };
  B({
    type: "xArrow",
    names: [
      "\\xleftarrow",
      "\\xrightarrow",
      "\\xLeftarrow",
      "\\xRightarrow",
      "\\xleftrightarrow",
      "\\xLeftrightarrow",
      "\\xhookleftarrow",
      "\\xhookrightarrow",
      "\\xmapsto",
      "\\xrightharpoondown",
      "\\xrightharpoonup",
      "\\xleftharpoondown",
      "\\xleftharpoonup",
      "\\xrightleftharpoons",
      "\\xleftrightharpoons",
      "\\xlongequal",
      "\\xtwoheadrightarrow",
      "\\xtwoheadleftarrow",
      "\\xtofrom",
      "\\xrightleftarrows",
      "\\xrightequilibrium",
      "\\xleftequilibrium",
      "\\\\cdrightarrow",
      "\\\\cdleftarrow",
      "\\\\cdlongequal"
    ],
    props: {
      numArgs: 1,
      numOptionalArgs: 1
    },
    handler(r, e, t) {
      var { parser: a, funcName: n } = r;
      return {
        type: "xArrow",
        mode: a.mode,
        label: n,
        body: e[0],
        below: t[0]
      };
    },
    htmlBuilder(r, e) {
      var t = e.style, a = e.havingStyle(t.sup()), n = te(U(r.body, a, e), e), l = r.label.slice(0, 2) === "\\x" ? "x" : "cd";
      n.classes.push(l + "-arrow-pad");
      var u;
      r.below && (a = e.havingStyle(t.sub()), u = te(U(r.below, a, e), e), u.classes.push(l + "-arrow-pad"));
      var h = Pe(r, e), c = -e.fontMetrics().axisHeight + 0.5 * h.height, p = -e.fontMetrics().axisHeight - 0.5 * h.height - 0.111;
      (n.depth > 0.25 || r.label === "\\xleftequilibrium") && (p -= n.depth);
      var g;
      if (u) {
        var b = -e.fontMetrics().axisHeight + u.height + 0.5 * h.height + 0.111;
        g = G({
          positionType: "individualShift",
          children: [
            {
              type: "elem",
              elem: n,
              shift: p
            },
            {
              type: "elem",
              elem: h,
              shift: c
            },
            {
              type: "elem",
              elem: u,
              shift: b
            }
          ]
        });
      } else
        g = G({
          positionType: "individualShift",
          children: [
            {
              type: "elem",
              elem: n,
              shift: p
            },
            {
              type: "elem",
              elem: h,
              shift: c
            }
          ]
        });
      return g.children[0].children[0].children[1].classes.push("svg-align"), S([
        "mrel",
        "x-arrow"
      ], [
        g
      ], e);
    },
    mathmlBuilder(r, e) {
      var t = Le(r.label);
      t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em");
      var a;
      if (r.body) {
        var n = ze(W(r.body, e));
        if (r.below) {
          var l = ze(W(r.below, e));
          a = new z("munderover", [
            t,
            l,
            n
          ]);
        } else
          a = new z("mover", [
            t,
            n
          ]);
      } else if (r.below) {
        var u = ze(W(r.below, e));
        a = new z("munder", [
          t,
          u
        ]);
      } else
        a = ze(), a = new z("mover", [
          t,
          a
        ]);
      return a;
    }
  });
  function jr(r, e) {
    var t = r0(r.body, e, true);
    return S([
      r.mclass
    ], t, e);
  }
  function Zr(r, e) {
    var t, a = p0(r.body, e);
    return r.mclass === "minner" ? t = new z("mpadded", a) : r.mclass === "mord" ? r.isCharacterBox ? (t = a[0], t.type = "mi") : t = new z("mi", a) : (r.isCharacterBox ? (t = a[0], t.type = "mo") : t = new z("mo", a), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
  }
  B({
    type: "mclass",
    names: [
      "\\mathord",
      "\\mathbin",
      "\\mathrel",
      "\\mathopen",
      "\\mathclose",
      "\\mathpunct",
      "\\mathinner"
    ],
    props: {
      numArgs: 1,
      primitive: true
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r, n = e[0];
      return {
        type: "mclass",
        mode: t.mode,
        mclass: "m" + a.slice(5),
        body: Q(n),
        isCharacterBox: D0(n)
      };
    },
    htmlBuilder: jr,
    mathmlBuilder: Zr
  });
  var Ve = (r) => {
    var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r;
    return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
  };
  B({
    type: "mclass",
    names: [
      "\\@binrel"
    ],
    props: {
      numArgs: 2
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "mclass",
        mode: t.mode,
        mclass: Ve(e[0]),
        body: Q(e[1]),
        isCharacterBox: D0(e[1])
      };
    }
  });
  B({
    type: "mclass",
    names: [
      "\\stackrel",
      "\\overset",
      "\\underset"
    ],
    props: {
      numArgs: 2
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r, n = e[1], l = e[0], u;
      a !== "\\stackrel" ? u = Ve(n) : u = "mrel";
      var h = {
        type: "op",
        mode: n.mode,
        limits: true,
        alwaysHandleSupSub: true,
        parentIsSupSub: false,
        symbol: false,
        suppressBaseShift: a !== "\\stackrel",
        body: Q(n)
      }, c = {
        type: "supsub",
        mode: l.mode,
        base: h,
        sup: a === "\\underset" ? null : l,
        sub: a === "\\underset" ? l : null
      };
      return {
        type: "mclass",
        mode: t.mode,
        mclass: u,
        body: [
          c
        ],
        isCharacterBox: D0(c)
      };
    },
    htmlBuilder: jr,
    mathmlBuilder: Zr
  });
  B({
    type: "pmb",
    names: [
      "\\pmb"
    ],
    props: {
      numArgs: 1,
      allowedInText: true
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "pmb",
        mode: t.mode,
        mclass: Ve(e[0]),
        body: Q(e[0])
      };
    },
    htmlBuilder(r, e) {
      var t = r0(r.body, e, true), a = S([
        r.mclass
      ], t, e);
      return a.style.textShadow = "0.02em 0.01em 0.04px", a;
    },
    mathmlBuilder(r, e) {
      var t = p0(r.body, e), a = new z("mstyle", t);
      return a.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), a;
    }
  });
  var Na = {
    ">": "\\\\cdrightarrow",
    "<": "\\\\cdleftarrow",
    "=": "\\\\cdlongequal",
    A: "\\uparrow",
    V: "\\downarrow",
    "|": "\\Vert",
    ".": "no arrow"
  }, ur = () => ({
    type: "styling",
    body: [],
    mode: "math",
    style: "display"
  }), or = (r) => r.type === "textord" && r.text === "@", Ha = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
  function Oa(r, e, t) {
    var a = Na[r];
    switch (a) {
      case "\\\\cdrightarrow":
      case "\\\\cdleftarrow":
        return t.callFunction(a, [
          e[0]
        ], [
          e[1]
        ]);
      case "\\uparrow":
      case "\\downarrow": {
        var n = t.callFunction("\\\\cdleft", [
          e[0]
        ], []), l = {
          type: "atom",
          text: a,
          mode: "math",
          family: "rel"
        }, u = t.callFunction("\\Big", [
          l
        ], []), h = t.callFunction("\\\\cdright", [
          e[1]
        ], []), c = {
          type: "ordgroup",
          mode: "math",
          body: [
            n,
            u,
            h
          ]
        };
        return t.callFunction("\\\\cdparent", [
          c
        ], []);
      }
      case "\\\\cdlongequal":
        return t.callFunction("\\\\cdlongequal", [], []);
      case "\\Vert": {
        var p = {
          type: "textord",
          text: "\\Vert",
          mode: "math"
        };
        return t.callFunction("\\Big", [
          p
        ], []);
      }
      default:
        return {
          type: "textord",
          text: " ",
          mode: "math"
        };
    }
  }
  function Fa(r) {
    var e = [];
    for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup(); ; ) {
      e.push(r.parseExpression(false, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
      var t = r.fetch().text;
      if (t === "&" || t === "\\\\")
        r.consume();
      else if (t === "\\end") {
        e[e.length - 1].length === 0 && e.pop();
        break;
      } else
        throw new k("Expected \\\\ or \\cr or \\end", r.nextToken);
    }
    for (var a = [], n = [
      a
    ], l = 0; l < e.length; l++) {
      for (var u = e[l], h = ur(), c = 0; c < u.length; c++)
        if (!or(u[c]))
          h.body.push(u[c]);
        else {
          a.push(h), c += 1;
          var p = Ge(u[c]).text, g = new Array(2);
          if (g[0] = {
            type: "ordgroup",
            mode: "math",
            body: []
          }, g[1] = {
            type: "ordgroup",
            mode: "math",
            body: []
          }, !"=|.".includes(p))
            if ("<>AV".includes(p))
              for (var b = 0; b < 2; b++) {
                for (var y = true, x = c + 1; x < u.length; x++) {
                  if (Ha(u[x], p)) {
                    y = false, c = x;
                    break;
                  }
                  if (or(u[x]))
                    throw new k("Missing a " + p + " character to complete a CD arrow.", u[x]);
                  g[b].body.push(u[x]);
                }
                if (y)
                  throw new k("Missing a " + p + " character to complete a CD arrow.", u[c]);
              }
            else
              throw new k('Expected one of "<>AV=|." after @', u[c]);
          var A = Oa(p, g, r), T = {
            type: "styling",
            body: [
              A
            ],
            mode: "math",
            style: "display"
          };
          a.push(T), h = ur();
        }
      l % 2 === 0 ? a.push(h) : a.shift(), a = [], n.push(a);
    }
    r.gullet.endGroup(), r.gullet.endGroup();
    var C = new Array(n[0].length).fill({
      type: "align",
      align: "c",
      pregap: 0.25,
      postgap: 0.25
    });
    return {
      type: "array",
      mode: "math",
      body: n,
      arraystretch: 1,
      addJot: true,
      rowGaps: [
        null
      ],
      cols: C,
      colSeparationType: "CD",
      hLinesBeforeRow: new Array(n.length + 1).fill([])
    };
  }
  B({
    type: "cdlabel",
    names: [
      "\\\\cdleft",
      "\\\\cdright"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r;
      return {
        type: "cdlabel",
        mode: t.mode,
        side: a.slice(4),
        label: e[0]
      };
    },
    htmlBuilder(r, e) {
      var t = e.havingStyle(e.style.sup()), a = te(U(r.label, t, e), e);
      return a.classes.push("cd-label-" + r.side), a.style.bottom = M(0.8 - a.depth), a.height = 0, a.depth = 0, a;
    },
    mathmlBuilder(r, e) {
      var t = new z("mrow", [
        W(r.label, e)
      ]);
      return t = new z("mpadded", [
        t
      ]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new z("mstyle", [
        t
      ]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
    }
  });
  B({
    type: "cdlabelparent",
    names: [
      "\\\\cdparent"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "cdlabelparent",
        mode: t.mode,
        fragment: e[0]
      };
    },
    htmlBuilder(r, e) {
      var t = te(U(r.fragment, e), e);
      return t.classes.push("cd-vert-arrow"), t;
    },
    mathmlBuilder(r, e) {
      return new z("mrow", [
        W(r.fragment, e)
      ]);
    }
  });
  B({
    type: "textord",
    names: [
      "\\@char"
    ],
    props: {
      numArgs: 1,
      allowedInText: true
    },
    handler(r, e) {
      for (var { parser: t } = r, a = O(e[0], "ordgroup"), n = a.body, l = "", u = 0; u < n.length; u++) {
        var h = O(n[u], "textord");
        l += h.text;
      }
      var c = parseInt(l), p;
      if (isNaN(c))
        throw new k("\\@char has non-numeric argument " + l);
      if (c < 0 || c >= 1114111)
        throw new k("\\@char with invalid code point " + l);
      return c <= 65535 ? p = String.fromCharCode(c) : (c -= 65536, p = String.fromCharCode((c >> 10) + 55296, (c & 1023) + 56320)), {
        type: "textord",
        mode: t.mode,
        text: p
      };
    }
  });
  var Kr = (r, e) => {
    var t = r0(r.body, e.withColor(r.color), false);
    return q0(t);
  }, Jr = (r, e) => {
    var t = p0(r.body, e.withColor(r.color)), a = new z("mstyle", t);
    return a.setAttribute("mathcolor", r.color), a;
  };
  B({
    type: "color",
    names: [
      "\\textcolor"
    ],
    props: {
      numArgs: 2,
      allowedInText: true,
      argTypes: [
        "color",
        "original"
      ]
    },
    handler(r, e) {
      var { parser: t } = r, a = O(e[0], "color-token").color, n = e[1];
      return {
        type: "color",
        mode: t.mode,
        color: a,
        body: Q(n)
      };
    },
    htmlBuilder: Kr,
    mathmlBuilder: Jr
  });
  B({
    type: "color",
    names: [
      "\\color"
    ],
    props: {
      numArgs: 1,
      allowedInText: true,
      argTypes: [
        "color"
      ]
    },
    handler(r, e) {
      var { parser: t, breakOnTokenText: a } = r, n = O(e[0], "color-token").color;
      t.gullet.macros.set("\\current@color", n);
      var l = t.parseExpression(true, a);
      return {
        type: "color",
        mode: t.mode,
        color: n,
        body: l
      };
    },
    htmlBuilder: Kr,
    mathmlBuilder: Jr
  });
  B({
    type: "cr",
    names: [
      "\\\\"
    ],
    props: {
      numArgs: 0,
      numOptionalArgs: 0,
      allowedInText: true
    },
    handler(r, e, t) {
      var { parser: a } = r, n = a.gullet.future().text === "[" ? a.parseSizeGroup(true) : null, l = !a.settings.displayMode || !a.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
      return {
        type: "cr",
        mode: a.mode,
        newLine: l,
        size: n && O(n, "size").value
      };
    },
    htmlBuilder(r, e) {
      var t = S([
        "mspace"
      ], [], e);
      return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = M(K(r.size, e)))), t;
    },
    mathmlBuilder(r, e) {
      var t = new z("mspace");
      return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", M(K(r.size, e)))), t;
    }
  });
  var wt = {
    "\\global": "\\global",
    "\\long": "\\\\globallong",
    "\\\\globallong": "\\\\globallong",
    "\\def": "\\gdef",
    "\\gdef": "\\gdef",
    "\\edef": "\\xdef",
    "\\xdef": "\\xdef",
    "\\let": "\\\\globallet",
    "\\futurelet": "\\\\globalfuture"
  }, Qr = (r) => {
    var e = r.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
      throw new k("Expected a control sequence", r);
    return e;
  }, La = (r) => {
    var e = r.gullet.popToken();
    return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e;
  }, _r = (r, e, t, a) => {
    var n = r.gullet.macros.get(t.text);
    n == null && (t.noexpand = true, n = {
      tokens: [
        t
      ],
      numArgs: 0,
      unexpandable: !r.gullet.isExpandable(t.text)
    }), r.gullet.macros.set(e, n, a);
  };
  B({
    type: "internal",
    names: [
      "\\global",
      "\\long",
      "\\\\globallong"
    ],
    props: {
      numArgs: 0,
      allowedInText: true
    },
    handler(r) {
      var { parser: e, funcName: t } = r;
      e.consumeSpaces();
      var a = e.fetch();
      if (wt[a.text])
        return (t === "\\global" || t === "\\\\globallong") && (a.text = wt[a.text]), O(e.parseFunction(), "internal");
      throw new k("Invalid token after macro prefix", a);
    }
  });
  B({
    type: "internal",
    names: [
      "\\def",
      "\\gdef",
      "\\edef",
      "\\xdef"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      primitive: true
    },
    handler(r) {
      var { parser: e, funcName: t } = r, a = e.gullet.popToken(), n = a.text;
      if (/^(?:[\\{}$&#^_]|EOF)$/.test(n))
        throw new k("Expected a control sequence", a);
      for (var l = 0, u, h = [
        []
      ]; e.gullet.future().text !== "{"; )
        if (a = e.gullet.popToken(), a.text === "#") {
          if (e.gullet.future().text === "{") {
            u = e.gullet.future(), h[l].push("{");
            break;
          }
          if (a = e.gullet.popToken(), !/^[1-9]$/.test(a.text))
            throw new k('Invalid argument number "' + a.text + '"');
          if (parseInt(a.text) !== l + 1)
            throw new k('Argument number "' + a.text + '" out of order');
          l++, h.push([]);
        } else {
          if (a.text === "EOF")
            throw new k("Expected a macro definition");
          h[l].push(a.text);
        }
      var { tokens: c } = e.gullet.consumeArg();
      return u && c.unshift(u), (t === "\\edef" || t === "\\xdef") && (c = e.gullet.expandTokens(c), c.reverse()), e.gullet.macros.set(n, {
        tokens: c,
        numArgs: l,
        delimiters: h
      }, t === wt[t]), {
        type: "internal",
        mode: e.mode
      };
    }
  });
  B({
    type: "internal",
    names: [
      "\\let",
      "\\\\globallet"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      primitive: true
    },
    handler(r) {
      var { parser: e, funcName: t } = r, a = Qr(e.gullet.popToken());
      e.gullet.consumeSpaces();
      var n = La(e);
      return _r(e, a, n, t === "\\\\globallet"), {
        type: "internal",
        mode: e.mode
      };
    }
  });
  B({
    type: "internal",
    names: [
      "\\futurelet",
      "\\\\globalfuture"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      primitive: true
    },
    handler(r) {
      var { parser: e, funcName: t } = r, a = Qr(e.gullet.popToken()), n = e.gullet.popToken(), l = e.gullet.popToken();
      return _r(e, a, l, t === "\\\\globalfuture"), e.gullet.pushToken(l), e.gullet.pushToken(n), {
        type: "internal",
        mode: e.mode
      };
    }
  });
  var se = function(e, t, a) {
    var n = Y.math[e] && Y.math[e].replace, l = Bt(n || e, t, a);
    if (!l)
      throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
    return l;
  }, It = function(e, t, a, n) {
    var l = a.havingBaseStyle(t), u = S(n.concat(l.sizingClasses(a)), [
      e
    ], a), h = l.sizeMultiplier / a.sizeMultiplier;
    return u.height *= h, u.depth *= h, u.maxFontSize = l.sizeMultiplier, u;
  }, e1 = function(e, t, a) {
    var n = t.havingBaseStyle(a), l = (1 - t.sizeMultiplier / n.sizeMultiplier) * t.fontMetrics().axisHeight;
    e.classes.push("delimcenter"), e.style.top = M(l), e.height -= l, e.depth += l;
  }, Pa = function(e, t, a, n, l, u) {
    var h = l0(e, "Main-Regular", l, n), c = It(h, t, n, u);
    return a && e1(c, n, t), c;
  }, Ga = function(e, t, a, n) {
    return l0(e, "Size" + t + "-Regular", a, n);
  }, t1 = function(e, t, a, n, l, u) {
    var h = Ga(e, t, l, n), c = It(S([
      "delimsizing",
      "size" + t
    ], [
      h
    ], n), N.TEXT, n, u);
    return a && e1(c, n, N.TEXT), c;
  }, tt = function(e, t, a) {
    var n;
    t === "Size1-Regular" ? n = "delim-size1" : n = "delim-size4";
    var l = S([
      "delimsizinginner",
      n
    ], [
      S([], [
        l0(e, t, a)
      ])
    ]);
    return {
      type: "elem",
      elem: l
    };
  }, rt = function(e, t, a) {
    var n = w0["Size4-Regular"][e.charCodeAt(0)] ? w0["Size4-Regular"][e.charCodeAt(0)][4] : w0["Size1-Regular"][e.charCodeAt(0)][4], l = new L0("inner", ta(e, Math.round(1e3 * t))), u = new B0([
      l
    ], {
      width: M(n),
      height: M(t),
      style: "width:" + M(n),
      viewBox: "0 0 " + 1e3 * n + " " + Math.round(1e3 * t),
      preserveAspectRatio: "xMinYMin"
    }), h = P0([], [
      u
    ], a);
    return h.height = t, h.style.height = M(t), h.style.width = M(n), {
      type: "elem",
      elem: h
    };
  }, St = 8e-3, Me = {
    type: "kern",
    size: -1 * St
  }, Ua = /* @__PURE__ */ new Set([
    "|",
    "\\lvert",
    "\\rvert",
    "\\vert"
  ]), Va = /* @__PURE__ */ new Set([
    "\\|",
    "\\lVert",
    "\\rVert",
    "\\Vert"
  ]), r1 = function(e, t, a, n, l, u) {
    var h, c, p, g, b = "", y = 0;
    h = p = g = e, c = null;
    var x = "Size1-Regular";
    e === "\\uparrow" ? p = g = "\u23D0" : e === "\\Uparrow" ? p = g = "\u2016" : e === "\\downarrow" ? h = p = "\u23D0" : e === "\\Downarrow" ? h = p = "\u2016" : e === "\\updownarrow" ? (h = "\\uparrow", p = "\u23D0", g = "\\downarrow") : e === "\\Updownarrow" ? (h = "\\Uparrow", p = "\u2016", g = "\\Downarrow") : Ua.has(e) ? (p = "\u2223", b = "vert", y = 333) : Va.has(e) ? (p = "\u2225", b = "doublevert", y = 556) : e === "[" || e === "\\lbrack" ? (h = "\u23A1", p = "\u23A2", g = "\u23A3", x = "Size4-Regular", b = "lbrack", y = 667) : e === "]" || e === "\\rbrack" ? (h = "\u23A4", p = "\u23A5", g = "\u23A6", x = "Size4-Regular", b = "rbrack", y = 667) : e === "\\lfloor" || e === "\u230A" ? (p = h = "\u23A2", g = "\u23A3", x = "Size4-Regular", b = "lfloor", y = 667) : e === "\\lceil" || e === "\u2308" ? (h = "\u23A1", p = g = "\u23A2", x = "Size4-Regular", b = "lceil", y = 667) : e === "\\rfloor" || e === "\u230B" ? (p = h = "\u23A5", g = "\u23A6", x = "Size4-Regular", b = "rfloor", y = 667) : e === "\\rceil" || e === "\u2309" ? (h = "\u23A4", p = g = "\u23A5", x = "Size4-Regular", b = "rceil", y = 667) : e === "(" || e === "\\lparen" ? (h = "\u239B", p = "\u239C", g = "\u239D", x = "Size4-Regular", b = "lparen", y = 875) : e === ")" || e === "\\rparen" ? (h = "\u239E", p = "\u239F", g = "\u23A0", x = "Size4-Regular", b = "rparen", y = 875) : e === "\\{" || e === "\\lbrace" ? (h = "\u23A7", c = "\u23A8", g = "\u23A9", p = "\u23AA", x = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (h = "\u23AB", c = "\u23AC", g = "\u23AD", p = "\u23AA", x = "Size4-Regular") : e === "\\lgroup" || e === "\u27EE" ? (h = "\u23A7", g = "\u23A9", p = "\u23AA", x = "Size4-Regular") : e === "\\rgroup" || e === "\u27EF" ? (h = "\u23AB", g = "\u23AD", p = "\u23AA", x = "Size4-Regular") : e === "\\lmoustache" || e === "\u23B0" ? (h = "\u23A7", g = "\u23AD", p = "\u23AA", x = "Size4-Regular") : (e === "\\rmoustache" || e === "\u23B1") && (h = "\u23AB", g = "\u23A9", p = "\u23AA", x = "Size4-Regular");
    var A = se(h, x, l), T = A.height + A.depth, C = se(p, x, l), q = C.height + C.depth, I = se(g, x, l), H = I.height + I.depth, F = 0, V = 1;
    if (c !== null) {
      var L = se(c, x, l);
      F = L.height + L.depth, V = 2;
    }
    var P = T + H + F, X = Math.max(0, Math.ceil((t - P) / (V * q))), $ = P + X * V * q, o0 = n.fontMetrics().axisHeight;
    a && (o0 *= n.sizeMultiplier);
    var n0 = $ / 2 - o0, t0 = [];
    if (b.length > 0) {
      var V0 = $ - T - H, h0 = Math.round($ * 1e3), b0 = ra(b, Math.round(V0 * 1e3)), E0 = new L0(b, b0), Y0 = (y / 1e3).toFixed(3) + "em", j0 = (h0 / 1e3).toFixed(3) + "em", Ye = new B0([
        E0
      ], {
        width: Y0,
        height: j0,
        viewBox: "0 0 " + y + " " + h0
      }), R0 = P0([], [
        Ye
      ], n);
      R0.height = h0 / 1e3, R0.style.width = Y0, R0.style.height = j0, t0.push({
        type: "elem",
        elem: R0
      });
    } else {
      if (t0.push(tt(g, x, l)), t0.push(Me), c === null) {
        var I0 = $ - T - H + 2 * St;
        t0.push(rt(p, I0, n));
      } else {
        var le = ($ - T - H - F) / 2 + 2 * St;
        t0.push(rt(p, le, n)), t0.push(Me), t0.push(tt(c, x, l)), t0.push(Me), t0.push(rt(p, le, n));
      }
      t0.push(Me), t0.push(tt(h, x, l));
    }
    var y0 = n.havingBaseStyle(N.TEXT), ce = G({
      positionType: "bottom",
      positionData: n0,
      children: t0
    });
    return It(S([
      "delimsizing",
      "mult"
    ], [
      ce
    ], y0), N.TEXT, n, u);
  }, at = 80, nt = 0.08, it = function(e, t, a, n, l) {
    var u = ea(e, n, a), h = new L0(e, u), c = new B0([
      h
    ], {
      width: "400em",
      height: M(t),
      viewBox: "0 0 400000 " + a,
      preserveAspectRatio: "xMinYMin slice"
    });
    return P0([
      "hide-tail"
    ], [
      c
    ], l);
  }, $a = function(e, t) {
    var a = t.havingBaseSizing(), n = s1("\\surd", e * a.sizeMultiplier, l1, a), l = a.sizeMultiplier, u = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), h, c = 0, p = 0, g = 0, b;
    return n.type === "small" ? (g = 1e3 + 1e3 * u + at, e < 1 ? l = 1 : e < 1.4 && (l = 0.7), c = (1 + u + nt) / l, p = (1 + u) / l, h = it("sqrtMain", c, g, u, t), h.style.minWidth = "0.853em", b = 0.833 / l) : n.type === "large" ? (g = (1e3 + at) * ue[n.size], p = (ue[n.size] + u) / l, c = (ue[n.size] + u + nt) / l, h = it("sqrtSize" + n.size, c, g, u, t), h.style.minWidth = "1.02em", b = 1 / l) : (c = e + u + nt, p = e + u, g = Math.floor(1e3 * e + u) + at, h = it("sqrtTall", c, g, u, t), h.style.minWidth = "0.742em", b = 1.056), h.height = p, h.style.height = M(c), {
      span: h,
      advanceWidth: b,
      ruleWidth: (t.fontMetrics().sqrtRuleThickness + u) * l
    };
  }, a1 = /* @__PURE__ */ new Set([
    "(",
    "\\lparen",
    ")",
    "\\rparen",
    "[",
    "\\lbrack",
    "]",
    "\\rbrack",
    "\\{",
    "\\lbrace",
    "\\}",
    "\\rbrace",
    "\\lfloor",
    "\\rfloor",
    "\u230A",
    "\u230B",
    "\\lceil",
    "\\rceil",
    "\u2308",
    "\u2309",
    "\\surd"
  ]), Wa = /* @__PURE__ */ new Set([
    "\\uparrow",
    "\\downarrow",
    "\\updownarrow",
    "\\Uparrow",
    "\\Downarrow",
    "\\Updownarrow",
    "|",
    "\\|",
    "\\vert",
    "\\Vert",
    "\\lvert",
    "\\rvert",
    "\\lVert",
    "\\rVert",
    "\\lgroup",
    "\\rgroup",
    "\u27EE",
    "\u27EF",
    "\\lmoustache",
    "\\rmoustache",
    "\u23B0",
    "\u23B1"
  ]), n1 = /* @__PURE__ */ new Set([
    "<",
    ">",
    "\\langle",
    "\\rangle",
    "/",
    "\\backslash",
    "\\lt",
    "\\gt"
  ]), ue = [
    0,
    1.2,
    1.8,
    2.4,
    3
  ], i1 = function(e, t, a, n, l) {
    if (e === "<" || e === "\\lt" || e === "\u27E8" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "\u27E9") && (e = "\\rangle"), a1.has(e) || n1.has(e))
      return t1(e, t, false, a, n, l);
    if (Wa.has(e))
      return r1(e, ue[t], false, a, n, l);
    throw new k("Illegal delimiter: '" + e + "'");
  }, Xa = [
    {
      type: "small",
      style: N.SCRIPTSCRIPT
    },
    {
      type: "small",
      style: N.SCRIPT
    },
    {
      type: "small",
      style: N.TEXT
    },
    {
      type: "large",
      size: 1
    },
    {
      type: "large",
      size: 2
    },
    {
      type: "large",
      size: 3
    },
    {
      type: "large",
      size: 4
    }
  ], Ya = [
    {
      type: "small",
      style: N.SCRIPTSCRIPT
    },
    {
      type: "small",
      style: N.SCRIPT
    },
    {
      type: "small",
      style: N.TEXT
    },
    {
      type: "stack"
    }
  ], l1 = [
    {
      type: "small",
      style: N.SCRIPTSCRIPT
    },
    {
      type: "small",
      style: N.SCRIPT
    },
    {
      type: "small",
      style: N.TEXT
    },
    {
      type: "large",
      size: 1
    },
    {
      type: "large",
      size: 2
    },
    {
      type: "large",
      size: 3
    },
    {
      type: "large",
      size: 4
    },
    {
      type: "stack"
    }
  ], ja = function(e) {
    if (e.type === "small")
      return "Main-Regular";
    if (e.type === "large")
      return "Size" + e.size + "-Regular";
    if (e.type === "stack")
      return "Size4-Regular";
    var t = e.type;
    throw new Error("Add support for delim type '" + t + "' here.");
  }, s1 = function(e, t, a, n) {
    for (var l = Math.min(2, 3 - n.style.size), u = l; u < a.length; u++) {
      var h = a[u];
      if (h.type === "stack")
        break;
      var c = se(e, ja(h), "math"), p = c.height + c.depth;
      if (h.type === "small") {
        var g = n.havingBaseStyle(h.style);
        p *= g.sizeMultiplier;
      }
      if (p > t)
        return h;
    }
    return a[a.length - 1];
  }, kt = function(e, t, a, n, l, u) {
    e === "<" || e === "\\lt" || e === "\u27E8" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "\u27E9") && (e = "\\rangle");
    var h;
    n1.has(e) ? h = Xa : a1.has(e) ? h = l1 : h = Ya;
    var c = s1(e, t, h, n);
    return c.type === "small" ? Pa(e, c.style, a, n, l, u) : c.type === "large" ? t1(e, c.size, a, n, l, u) : r1(e, t, a, n, l, u);
  }, lt = function(e, t, a, n, l, u) {
    var h = n.fontMetrics().axisHeight * n.sizeMultiplier, c = 901, p = 5 / n.fontMetrics().ptPerEm, g = Math.max(t - h, a + h), b = Math.max(g / 500 * c, 2 * g - p);
    return kt(e, b, true, n, l, u);
  }, hr = {
    "\\bigl": {
      mclass: "mopen",
      size: 1
    },
    "\\Bigl": {
      mclass: "mopen",
      size: 2
    },
    "\\biggl": {
      mclass: "mopen",
      size: 3
    },
    "\\Biggl": {
      mclass: "mopen",
      size: 4
    },
    "\\bigr": {
      mclass: "mclose",
      size: 1
    },
    "\\Bigr": {
      mclass: "mclose",
      size: 2
    },
    "\\biggr": {
      mclass: "mclose",
      size: 3
    },
    "\\Biggr": {
      mclass: "mclose",
      size: 4
    },
    "\\bigm": {
      mclass: "mrel",
      size: 1
    },
    "\\Bigm": {
      mclass: "mrel",
      size: 2
    },
    "\\biggm": {
      mclass: "mrel",
      size: 3
    },
    "\\Biggm": {
      mclass: "mrel",
      size: 4
    },
    "\\big": {
      mclass: "mord",
      size: 1
    },
    "\\Big": {
      mclass: "mord",
      size: 2
    },
    "\\bigg": {
      mclass: "mord",
      size: 3
    },
    "\\Bigg": {
      mclass: "mord",
      size: 4
    }
  }, Za = /* @__PURE__ */ new Set([
    "(",
    "\\lparen",
    ")",
    "\\rparen",
    "[",
    "\\lbrack",
    "]",
    "\\rbrack",
    "\\{",
    "\\lbrace",
    "\\}",
    "\\rbrace",
    "\\lfloor",
    "\\rfloor",
    "\u230A",
    "\u230B",
    "\\lceil",
    "\\rceil",
    "\u2308",
    "\u2309",
    "<",
    ">",
    "\\langle",
    "\u27E8",
    "\\rangle",
    "\u27E9",
    "\\lt",
    "\\gt",
    "\\lvert",
    "\\rvert",
    "\\lVert",
    "\\rVert",
    "\\lgroup",
    "\\rgroup",
    "\u27EE",
    "\u27EF",
    "\\lmoustache",
    "\\rmoustache",
    "\u23B0",
    "\u23B1",
    "/",
    "\\backslash",
    "|",
    "\\vert",
    "\\|",
    "\\Vert",
    "\\uparrow",
    "\\Uparrow",
    "\\downarrow",
    "\\Downarrow",
    "\\updownarrow",
    "\\Updownarrow",
    "."
  ]);
  function $e(r, e) {
    var t = Ue(r);
    if (t && Za.has(t.text))
      return t;
    throw t ? new k("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new k("Invalid delimiter type '" + r.type + "'", r);
  }
  B({
    type: "delimsizing",
    names: [
      "\\bigl",
      "\\Bigl",
      "\\biggl",
      "\\Biggl",
      "\\bigr",
      "\\Bigr",
      "\\biggr",
      "\\Biggr",
      "\\bigm",
      "\\Bigm",
      "\\biggm",
      "\\Biggm",
      "\\big",
      "\\Big",
      "\\bigg",
      "\\Bigg"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "primitive"
      ]
    },
    handler: (r, e) => {
      var t = $e(e[0], r);
      return {
        type: "delimsizing",
        mode: r.parser.mode,
        size: hr[r.funcName].size,
        mclass: hr[r.funcName].mclass,
        delim: t.text
      };
    },
    htmlBuilder: (r, e) => r.delim === "." ? S([
      r.mclass
    ]) : i1(r.delim, r.size, e, r.mode, [
      r.mclass
    ]),
    mathmlBuilder: (r) => {
      var e = [];
      r.delim !== "." && e.push(g0(r.delim, r.mode));
      var t = new z("mo", e);
      r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
      var a = M(ue[r.size]);
      return t.setAttribute("minsize", a), t.setAttribute("maxsize", a), t;
    }
  });
  function mr(r) {
    if (!r.body)
      throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
  }
  B({
    type: "leftright-right",
    names: [
      "\\right"
    ],
    props: {
      numArgs: 1,
      primitive: true
    },
    handler: (r, e) => {
      var t = r.parser.gullet.macros.get("\\current@color");
      if (t && typeof t != "string")
        throw new k("\\current@color set to non-string in \\right");
      return {
        type: "leftright-right",
        mode: r.parser.mode,
        delim: $e(e[0], r).text,
        color: t
      };
    }
  });
  B({
    type: "leftright",
    names: [
      "\\left"
    ],
    props: {
      numArgs: 1,
      primitive: true
    },
    handler: (r, e) => {
      var t = $e(e[0], r), a = r.parser;
      ++a.leftrightDepth;
      var n = a.parseExpression(false);
      --a.leftrightDepth, a.expect("\\right", false);
      var l = O(a.parseFunction(), "leftright-right");
      return {
        type: "leftright",
        mode: a.mode,
        body: n,
        left: t.text,
        right: l.delim,
        rightColor: l.color
      };
    },
    htmlBuilder: (r, e) => {
      mr(r);
      for (var t = r0(r.body, e, true, [
        "mopen",
        "mclose"
      ]), a = 0, n = 0, l = false, u = 0; u < t.length; u++)
        t[u].isMiddle ? l = true : (a = Math.max(t[u].height, a), n = Math.max(t[u].depth, n));
      a *= e.sizeMultiplier, n *= e.sizeMultiplier;
      var h;
      if (r.left === "." ? h = he(e, [
        "mopen"
      ]) : h = lt(r.left, a, n, e, r.mode, [
        "mopen"
      ]), t.unshift(h), l)
        for (var c = 1; c < t.length; c++) {
          var p = t[c], g = p.isMiddle;
          g && (t[c] = lt(g.delim, a, n, g.options, r.mode, []));
        }
      var b;
      if (r.right === ".")
        b = he(e, [
          "mclose"
        ]);
      else {
        var y = r.rightColor ? e.withColor(r.rightColor) : e;
        b = lt(r.right, a, n, y, r.mode, [
          "mclose"
        ]);
      }
      return t.push(b), S([
        "minner"
      ], t, e);
    },
    mathmlBuilder: (r, e) => {
      mr(r);
      var t = p0(r.body, e);
      if (r.left !== ".") {
        var a = new z("mo", [
          g0(r.left, r.mode)
        ]);
        a.setAttribute("fence", "true"), t.unshift(a);
      }
      if (r.right !== ".") {
        var n = new z("mo", [
          g0(r.right, r.mode)
        ]);
        n.setAttribute("fence", "true"), r.rightColor && n.setAttribute("mathcolor", r.rightColor), t.push(n);
      }
      return qt(t);
    }
  });
  B({
    type: "middle",
    names: [
      "\\middle"
    ],
    props: {
      numArgs: 1,
      primitive: true
    },
    handler: (r, e) => {
      var t = $e(e[0], r);
      if (!r.parser.leftrightDepth)
        throw new k("\\middle without preceding \\left", t);
      return {
        type: "middle",
        mode: r.parser.mode,
        delim: t.text
      };
    },
    htmlBuilder: (r, e) => {
      var t;
      if (r.delim === ".")
        t = he(e, []);
      else {
        t = i1(r.delim, 1, e, r.mode, []);
        var a = {
          delim: r.delim,
          options: e
        };
        t.isMiddle = a;
      }
      return t;
    },
    mathmlBuilder: (r, e) => {
      var t = r.delim === "\\vert" || r.delim === "|" ? g0("|", "text") : g0(r.delim, r.mode), a = new z("mo", [
        t
      ]);
      return a.setAttribute("fence", "true"), a.setAttribute("lspace", "0.05em"), a.setAttribute("rspace", "0.05em"), a;
    }
  });
  var Nt = (r, e) => {
    var t = te(U(r.body, e), e), a = r.label.slice(1), n = e.sizeMultiplier, l, u = 0, h = D0(r.body);
    if (a === "sout")
      l = S([
        "stretchy",
        "sout"
      ]), l.height = e.fontMetrics().defaultRuleThickness / n, u = -0.5 * e.fontMetrics().xHeight;
    else if (a === "phase") {
      var c = K({
        number: 0.6,
        unit: "pt"
      }, e), p = K({
        number: 0.35,
        unit: "ex"
      }, e), g = e.havingBaseSizing();
      n = n / g.sizeMultiplier;
      var b = t.height + t.depth + c + p;
      t.style.paddingLeft = M(b / 2 + c);
      var y = Math.floor(1e3 * b * n), x = Q1(y), A = new B0([
        new L0("phase", x)
      ], {
        width: "400em",
        height: M(y / 1e3),
        viewBox: "0 0 400000 " + y,
        preserveAspectRatio: "xMinYMin slice"
      });
      l = P0([
        "hide-tail"
      ], [
        A
      ], e), l.style.height = M(b), u = t.depth + c + p;
    } else {
      /cancel/.test(a) ? h || t.classes.push("cancel-pad") : a === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
      var T = 0, C = 0, q = 0;
      /box/.test(a) ? (q = Math.max(e.fontMetrics().fboxrule, e.minRuleThickness), T = e.fontMetrics().fboxsep + (a === "colorbox" ? 0 : q), C = T) : a === "angl" ? (q = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), T = 4 * q, C = Math.max(0, 0.25 - t.depth)) : (T = h ? 0.2 : 0, C = T), l = Ra(t, a, T, C, e), /fbox|boxed|fcolorbox/.test(a) ? (l.style.borderStyle = "solid", l.style.borderWidth = M(q)) : a === "angl" && q !== 0.049 && (l.style.borderTopWidth = M(q), l.style.borderRightWidth = M(q)), u = t.depth + C, r.backgroundColor && (l.style.backgroundColor = r.backgroundColor, r.borderColor && (l.style.borderColor = r.borderColor));
    }
    var I;
    if (r.backgroundColor)
      I = G({
        positionType: "individualShift",
        children: [
          {
            type: "elem",
            elem: l,
            shift: u
          },
          {
            type: "elem",
            elem: t,
            shift: 0
          }
        ]
      });
    else {
      var H = /cancel|phase/.test(a) ? [
        "svg-align"
      ] : [];
      I = G({
        positionType: "individualShift",
        children: [
          {
            type: "elem",
            elem: t,
            shift: 0
          },
          {
            type: "elem",
            elem: l,
            shift: u,
            wrapperClasses: H
          }
        ]
      });
    }
    return /cancel/.test(a) && (I.height = t.height, I.depth = t.depth), /cancel/.test(a) && !h ? S([
      "mord",
      "cancel-lap"
    ], [
      I
    ], e) : S([
      "mord"
    ], [
      I
    ], e);
  }, Ht = (r, e) => {
    var t = 0, a = new z(r.label.includes("colorbox") ? "mpadded" : "menclose", [
      W(r.body, e)
    ]);
    switch (r.label) {
      case "\\cancel":
        a.setAttribute("notation", "updiagonalstrike");
        break;
      case "\\bcancel":
        a.setAttribute("notation", "downdiagonalstrike");
        break;
      case "\\phase":
        a.setAttribute("notation", "phasorangle");
        break;
      case "\\sout":
        a.setAttribute("notation", "horizontalstrike");
        break;
      case "\\fbox":
        a.setAttribute("notation", "box");
        break;
      case "\\angl":
        a.setAttribute("notation", "actuarial");
        break;
      case "\\fcolorbox":
      case "\\colorbox":
        if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, a.setAttribute("width", "+" + 2 * t + "pt"), a.setAttribute("height", "+" + 2 * t + "pt"), a.setAttribute("lspace", t + "pt"), a.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
          var n = Math.max(e.fontMetrics().fboxrule, e.minRuleThickness);
          a.setAttribute("style", "border: " + n + "em solid " + String(r.borderColor));
        }
        break;
      case "\\xcancel":
        a.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
        break;
    }
    return r.backgroundColor && a.setAttribute("mathbackground", r.backgroundColor), a;
  };
  B({
    type: "enclose",
    names: [
      "\\colorbox"
    ],
    props: {
      numArgs: 2,
      allowedInText: true,
      argTypes: [
        "color",
        "text"
      ]
    },
    handler(r, e, t) {
      var { parser: a, funcName: n } = r, l = O(e[0], "color-token").color, u = e[1];
      return {
        type: "enclose",
        mode: a.mode,
        label: n,
        backgroundColor: l,
        body: u
      };
    },
    htmlBuilder: Nt,
    mathmlBuilder: Ht
  });
  B({
    type: "enclose",
    names: [
      "\\fcolorbox"
    ],
    props: {
      numArgs: 3,
      allowedInText: true,
      argTypes: [
        "color",
        "color",
        "text"
      ]
    },
    handler(r, e, t) {
      var { parser: a, funcName: n } = r, l = O(e[0], "color-token").color, u = O(e[1], "color-token").color, h = e[2];
      return {
        type: "enclose",
        mode: a.mode,
        label: n,
        backgroundColor: u,
        borderColor: l,
        body: h
      };
    },
    htmlBuilder: Nt,
    mathmlBuilder: Ht
  });
  B({
    type: "enclose",
    names: [
      "\\fbox"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "hbox"
      ],
      allowedInText: true
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "enclose",
        mode: t.mode,
        label: "\\fbox",
        body: e[0]
      };
    }
  });
  B({
    type: "enclose",
    names: [
      "\\cancel",
      "\\bcancel",
      "\\xcancel",
      "\\sout",
      "\\phase"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r, n = e[0];
      return {
        type: "enclose",
        mode: t.mode,
        label: a,
        body: n
      };
    },
    htmlBuilder: Nt,
    mathmlBuilder: Ht
  });
  B({
    type: "enclose",
    names: [
      "\\angl"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "hbox"
      ],
      allowedInText: false
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "enclose",
        mode: t.mode,
        label: "\\angl",
        body: e[0]
      };
    }
  });
  var u1 = {};
  function S0(r) {
    for (var { type: e, names: t, props: a, handler: n, htmlBuilder: l, mathmlBuilder: u } = r, h = {
      type: e,
      numArgs: a.numArgs || 0,
      allowedInText: false,
      numOptionalArgs: 0,
      handler: n
    }, c = 0; c < t.length; ++c)
      u1[t[c]] = h;
    l && (Ee[e] = l), u && (Re[e] = u);
  }
  var o1 = {};
  function m(r, e) {
    o1[r] = e;
  }
  class m0 {
    constructor(e, t, a) {
      this.lexer = e, this.start = t, this.end = a;
    }
    static range(e, t) {
      return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new m0(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
    }
  }
  class c0 {
    constructor(e, t) {
      this.text = e, this.loc = t;
    }
    range(e, t) {
      return new c0(t, m0.range(this, e));
    }
  }
  function cr(r) {
    var e = [];
    r.consumeSpaces();
    var t = r.fetch().text;
    for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline"; )
      r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text;
    return e;
  }
  var We = (r) => {
    var e = r.parser.settings;
    if (!e.displayMode)
      throw new k("{" + r.envName + "} can be used only in display mode.");
  }, Ka = /* @__PURE__ */ new Set([
    "gather",
    "gather*"
  ]);
  function Ot(r) {
    if (!r.includes("ed"))
      return !r.includes("*");
  }
  function U0(r, e, t) {
    var { hskipBeforeAndAfter: a, addJot: n, cols: l, arraystretch: u, colSeparationType: h, autoTag: c, singleRow: p, emptySingleRow: g, maxNumCols: b, leqno: y } = e;
    if (r.gullet.beginGroup(), p || r.gullet.macros.set("\\cr", "\\\\\\relax"), !u) {
      var x = r.gullet.expandMacroAsText("\\arraystretch");
      if (x == null)
        u = 1;
      else if (u = parseFloat(x), !u || u < 0)
        throw new k("Invalid \\arraystretch: " + x);
    }
    r.gullet.beginGroup();
    var A = [], T = [
      A
    ], C = [], q = [], I = c != null ? [] : void 0;
    function H() {
      c && r.gullet.macros.set("\\@eqnsw", "1", true);
    }
    function F() {
      I && (r.gullet.macros.get("\\df@tag") ? (I.push(r.subparse([
        new c0("\\df@tag")
      ])), r.gullet.macros.set("\\df@tag", void 0, true)) : I.push(!!c && r.gullet.macros.get("\\@eqnsw") === "1"));
    }
    for (H(), q.push(cr(r)); ; ) {
      var V = r.parseExpression(false, p ? "\\end" : "\\\\");
      r.gullet.endGroup(), r.gullet.beginGroup();
      var L = {
        type: "ordgroup",
        mode: r.mode,
        body: V
      };
      t && (L = {
        type: "styling",
        mode: r.mode,
        style: t,
        body: [
          L
        ]
      }), A.push(L);
      var P = r.fetch().text;
      if (P === "&") {
        if (b && A.length === b) {
          if (p || h)
            throw new k("Too many tab characters: &", r.nextToken);
          r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
        }
        r.consume();
      } else if (P === "\\end") {
        F(), A.length === 1 && L.type === "styling" && L.body.length === 1 && L.body[0].type === "ordgroup" && L.body[0].body.length === 0 && (T.length > 1 || !g) && T.pop(), q.length < T.length + 1 && q.push([]);
        break;
      } else if (P === "\\\\") {
        r.consume();
        var X = void 0;
        r.gullet.future().text !== " " && (X = r.parseSizeGroup(true)), C.push(X ? X.value : null), F(), q.push(cr(r)), A = [], T.push(A), H();
      } else
        throw new k("Expected & or \\\\ or \\cr or \\end", r.nextToken);
    }
    return r.gullet.endGroup(), r.gullet.endGroup(), {
      type: "array",
      mode: r.mode,
      addJot: n,
      arraystretch: u,
      body: T,
      cols: l,
      rowGaps: C,
      hskipBeforeAndAfter: a,
      hLinesBeforeRow: q,
      colSeparationType: h,
      tags: I,
      leqno: y
    };
  }
  function Ft(r) {
    return r.slice(0, 1) === "d" ? "display" : "text";
  }
  var k0 = function(e, t) {
    var a, n, l = e.body.length, u = e.hLinesBeforeRow, h = 0, c = new Array(l), p = [], g = Math.max(t.fontMetrics().arrayRuleWidth, t.minRuleThickness), b = 1 / t.fontMetrics().ptPerEm, y = 5 * b;
    if (e.colSeparationType && e.colSeparationType === "small") {
      var x = t.havingStyle(N.SCRIPT).sizeMultiplier;
      y = 0.2778 * (x / t.sizeMultiplier);
    }
    var A = e.colSeparationType === "CD" ? K({
      number: 3,
      unit: "ex"
    }, t) : 12 * b, T = 3 * b, C = e.arraystretch * A, q = 0.7 * C, I = 0.3 * C, H = 0;
    function F(ve) {
      for (var ge = 0; ge < ve.length; ++ge)
        ge > 0 && (H += 0.25), p.push({
          pos: H,
          isDashed: ve[ge]
        });
    }
    for (F(u[0]), a = 0; a < e.body.length; ++a) {
      var V = e.body[a], L = q, P = I;
      h < V.length && (h = V.length);
      var X = new Array(V.length);
      for (n = 0; n < V.length; ++n) {
        var $ = U(V[n], t);
        P < $.depth && (P = $.depth), L < $.height && (L = $.height), X[n] = $;
      }
      var o0 = e.rowGaps[a], n0 = 0;
      o0 && (n0 = K(o0, t), n0 > 0 && (n0 += I, P < n0 && (P = n0), n0 = 0)), e.addJot && (P += T), X.height = L, X.depth = P, H += L, X.pos = H, H += P + n0, c[a] = X, F(u[a + 1]);
    }
    var t0 = H / 2 + t.fontMetrics().axisHeight, V0 = e.cols || [], h0 = [], b0, E0, Y0 = [];
    if (e.tags && e.tags.some((ve) => ve))
      for (a = 0; a < l; ++a) {
        var j0 = c[a], Ye = j0.pos - t0, R0 = e.tags[a], I0 = void 0;
        R0 === true ? I0 = S([
          "eqn-num"
        ], [], t) : R0 === false ? I0 = S([], [], t) : I0 = S([], r0(R0, t, true), t), I0.depth = j0.depth, I0.height = j0.height, Y0.push({
          type: "elem",
          elem: I0,
          shift: Ye
        });
      }
    for (n = 0, E0 = 0; n < h || E0 < V0.length; ++n, ++E0) {
      for (var le, y0 = V0[E0], ce = true; ((Vt = y0) == null ? void 0 : Vt.type) === "separator"; ) {
        var Vt;
        if (ce || (b0 = S([
          "arraycolsep"
        ], []), b0.style.width = M(t.fontMetrics().doubleRuleSep), h0.push(b0)), y0.separator === "|" || y0.separator === ":") {
          var A1 = y0.separator === "|" ? "solid" : "dashed", Z0 = S([
            "vertical-separator"
          ], [], t);
          Z0.style.height = M(H), Z0.style.borderRightWidth = M(g), Z0.style.borderRightStyle = A1, Z0.style.margin = "0 " + M(-g / 2);
          var $t = H - t0;
          $t && (Z0.style.verticalAlign = M(-$t)), h0.push(Z0);
        } else
          throw new k("Invalid separator type: " + y0.separator);
        E0++, y0 = V0[E0], ce = false;
      }
      if (!(n >= h)) {
        var K0 = void 0;
        if (n > 0 || e.hskipBeforeAndAfter) {
          var Wt, Xt;
          K0 = (Wt = (Xt = y0) == null ? void 0 : Xt.pregap) != null ? Wt : y, K0 !== 0 && (b0 = S([
            "arraycolsep"
          ], []), b0.style.width = M(K0), h0.push(b0));
        }
        var Yt = [];
        for (a = 0; a < l; ++a) {
          var de = c[a], fe = de[n];
          if (fe) {
            var T1 = de.pos - t0;
            fe.depth = de.depth, fe.height = de.height, Yt.push({
              type: "elem",
              elem: fe,
              shift: T1
            });
          }
        }
        var B1 = G({
          positionType: "individualShift",
          children: Yt
        }), D1 = S([
          "col-align-" + (((le = y0) == null ? void 0 : le.align) || "c")
        ], [
          B1
        ]);
        if (h0.push(D1), n < h - 1 || e.hskipBeforeAndAfter) {
          var jt, Zt;
          K0 = (jt = (Zt = y0) == null ? void 0 : Zt.postgap) != null ? jt : y, K0 !== 0 && (b0 = S([
            "arraycolsep"
          ], []), b0.style.width = M(K0), h0.push(b0));
        }
      }
    }
    var pe = S([
      "mtable"
    ], h0);
    if (p.length > 0) {
      for (var C1 = ee("hline", t, g), q1 = ee("hdashline", t, g), je = [
        {
          type: "elem",
          elem: pe,
          shift: 0
        }
      ]; p.length > 0; ) {
        var Kt = p.pop(), Jt = Kt.pos - t0;
        Kt.isDashed ? je.push({
          type: "elem",
          elem: q1,
          shift: Jt
        }) : je.push({
          type: "elem",
          elem: C1,
          shift: Jt
        });
      }
      pe = G({
        positionType: "individualShift",
        children: je
      });
    }
    if (Y0.length === 0)
      return S([
        "mord"
      ], [
        pe
      ], t);
    var E1 = G({
      positionType: "individualShift",
      children: Y0
    }), R1 = S([
      "tag"
    ], [
      E1
    ], t);
    return q0([
      pe,
      R1
    ]);
  }, Ja = {
    c: "center ",
    l: "left ",
    r: "right "
  }, z0 = function(e, t) {
    for (var a = [], n = new z("mtd", [], [
      "mtr-glue"
    ]), l = new z("mtd", [], [
      "mml-eqn-num"
    ]), u = 0; u < e.body.length; u++) {
      for (var h = e.body[u], c = [], p = 0; p < h.length; p++)
        c.push(new z("mtd", [
          W(h[p], t)
        ]));
      e.tags && e.tags[u] && (c.unshift(n), c.push(n), e.leqno ? c.unshift(l) : c.push(l)), a.push(new z("mtr", c));
    }
    var g = new z("mtable", a), b = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
    g.setAttribute("rowspacing", M(b));
    var y = "", x = "";
    if (e.cols && e.cols.length > 0) {
      var A = e.cols, T = "", C = false, q = 0, I = A.length;
      A[0].type === "separator" && (y += "top ", q = 1), A[A.length - 1].type === "separator" && (y += "bottom ", I -= 1);
      for (var H = q; H < I; H++) {
        var F = A[H];
        F.type === "align" ? (x += Ja[F.align], C && (T += "none "), C = true) : F.type === "separator" && C && (T += F.separator === "|" ? "solid " : "dashed ", C = false);
      }
      g.setAttribute("columnalign", x.trim()), /[sd]/.test(T) && g.setAttribute("columnlines", T.trim());
    }
    if (e.colSeparationType === "align") {
      for (var V = e.cols || [], L = "", P = 1; P < V.length; P++)
        L += P % 2 ? "0em " : "1em ";
      g.setAttribute("columnspacing", L.trim());
    } else
      e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? g.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? g.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? g.setAttribute("columnspacing", "0.5em") : g.setAttribute("columnspacing", "1em");
    var X = "", $ = e.hLinesBeforeRow;
    y += $[0].length > 0 ? "left " : "", y += $[$.length - 1].length > 0 ? "right " : "";
    for (var o0 = 1; o0 < $.length - 1; o0++)
      X += $[o0].length === 0 ? "none " : $[o0][0] ? "dashed " : "solid ";
    return /[sd]/.test(X) && g.setAttribute("rowlines", X.trim()), y !== "" && (g = new z("menclose", [
      g
    ]), g.setAttribute("notation", y.trim())), e.arraystretch && e.arraystretch < 1 && (g = new z("mstyle", [
      g
    ]), g.setAttribute("scriptlevel", "1")), g;
  }, h1 = function(e, t) {
    e.envName.includes("ed") || We(e);
    var a = [], n = e.envName.includes("at") ? "alignat" : "align", l = e.envName === "split", u = U0(e.parser, {
      cols: a,
      addJot: true,
      autoTag: l ? void 0 : Ot(e.envName),
      emptySingleRow: true,
      colSeparationType: n,
      maxNumCols: l ? 2 : void 0,
      leqno: e.parser.settings.leqno
    }, "display"), h = 0, c = 0, p = {
      type: "ordgroup",
      mode: e.mode,
      body: []
    };
    if (t[0] && t[0].type === "ordgroup") {
      for (var g = "", b = 0; b < t[0].body.length; b++) {
        var y = O(t[0].body[b], "textord");
        g += y.text;
      }
      h = Number(g), c = h * 2;
    }
    var x = !c;
    u.body.forEach(function(q) {
      for (var I = 1; I < q.length; I += 2) {
        var H = O(q[I], "styling"), F = O(H.body[0], "ordgroup");
        F.body.unshift(p);
      }
      if (x)
        c < q.length && (c = q.length);
      else {
        var V = q.length / 2;
        if (h < V)
          throw new k("Too many math in a row: " + ("expected " + h + ", but got " + V), q[0]);
      }
    });
    for (var A = 0; A < c; ++A) {
      var T = "r", C = 0;
      A % 2 === 1 ? T = "l" : A > 0 && x && (C = 1), a[A] = {
        type: "align",
        align: T,
        pregap: C,
        postgap: 0
      };
    }
    return u.colSeparationType = x ? "align" : "alignat", u;
  };
  S0({
    type: "array",
    names: [
      "array",
      "darray"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var t = Ue(e[0]), a = t ? [
        e[0]
      ] : O(e[0], "ordgroup").body, n = a.map(function(u) {
        var h = Ge(u), c = h.text;
        if ("lcr".includes(c))
          return {
            type: "align",
            align: c
          };
        if (c === "|")
          return {
            type: "separator",
            separator: "|"
          };
        if (c === ":")
          return {
            type: "separator",
            separator: ":"
          };
        throw new k("Unknown column alignment: " + c, u);
      }), l = {
        cols: n,
        hskipBeforeAndAfter: true,
        maxNumCols: n.length
      };
      return U0(r.parser, l, Ft(r.envName));
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "matrix",
      "pmatrix",
      "bmatrix",
      "Bmatrix",
      "vmatrix",
      "Vmatrix",
      "matrix*",
      "pmatrix*",
      "bmatrix*",
      "Bmatrix*",
      "vmatrix*",
      "Vmatrix*"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      var e = {
        matrix: null,
        pmatrix: [
          "(",
          ")"
        ],
        bmatrix: [
          "[",
          "]"
        ],
        Bmatrix: [
          "\\{",
          "\\}"
        ],
        vmatrix: [
          "|",
          "|"
        ],
        Vmatrix: [
          "\\Vert",
          "\\Vert"
        ]
      }[r.envName.replace("*", "")], t = "c", a = {
        hskipBeforeAndAfter: false,
        cols: [
          {
            type: "align",
            align: t
          }
        ]
      };
      if (r.envName.charAt(r.envName.length - 1) === "*") {
        var n = r.parser;
        if (n.consumeSpaces(), n.fetch().text === "[") {
          if (n.consume(), n.consumeSpaces(), t = n.fetch().text, !"lcr".includes(t))
            throw new k("Expected l or c or r", n.nextToken);
          n.consume(), n.consumeSpaces(), n.expect("]"), n.consume(), a.cols = [
            {
              type: "align",
              align: t
            }
          ];
        }
      }
      var l = U0(r.parser, a, Ft(r.envName)), u = Math.max(0, ...l.body.map((h) => h.length));
      return l.cols = new Array(u).fill({
        type: "align",
        align: t
      }), e ? {
        type: "leftright",
        mode: r.mode,
        body: [
          l
        ],
        left: e[0],
        right: e[1],
        rightColor: void 0
      } : l;
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "smallmatrix"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      var e = {
        arraystretch: 0.5
      }, t = U0(r.parser, e, "script");
      return t.colSeparationType = "small", t;
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "subarray"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var t = Ue(e[0]), a = t ? [
        e[0]
      ] : O(e[0], "ordgroup").body, n = a.map(function(h) {
        var c = Ge(h), p = c.text;
        if ("lc".includes(p))
          return {
            type: "align",
            align: p
          };
        throw new k("Unknown column alignment: " + p, h);
      });
      if (n.length > 1)
        throw new k("{subarray} can contain only one column");
      var l = {
        cols: n,
        hskipBeforeAndAfter: false,
        arraystretch: 0.5
      }, u = U0(r.parser, l, "script");
      if (u.body.length > 0 && u.body[0].length > 1)
        throw new k("{subarray} can contain only one column");
      return u;
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "cases",
      "dcases",
      "rcases",
      "drcases"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      var e = {
        arraystretch: 1.2,
        cols: [
          {
            type: "align",
            align: "l",
            pregap: 0,
            postgap: 1
          },
          {
            type: "align",
            align: "l",
            pregap: 0,
            postgap: 0
          }
        ]
      }, t = U0(r.parser, e, Ft(r.envName));
      return {
        type: "leftright",
        mode: r.mode,
        body: [
          t
        ],
        left: r.envName.includes("r") ? "." : "\\{",
        right: r.envName.includes("r") ? "\\}" : ".",
        rightColor: void 0
      };
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "align",
      "align*",
      "aligned",
      "split"
    ],
    props: {
      numArgs: 0
    },
    handler: h1,
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "gathered",
      "gather",
      "gather*"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      Ka.has(r.envName) && We(r);
      var e = {
        cols: [
          {
            type: "align",
            align: "c"
          }
        ],
        addJot: true,
        colSeparationType: "gather",
        autoTag: Ot(r.envName),
        emptySingleRow: true,
        leqno: r.parser.settings.leqno
      };
      return U0(r.parser, e, "display");
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "alignat",
      "alignat*",
      "alignedat"
    ],
    props: {
      numArgs: 1
    },
    handler: h1,
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "equation",
      "equation*"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      We(r);
      var e = {
        autoTag: Ot(r.envName),
        emptySingleRow: true,
        singleRow: true,
        maxNumCols: 1,
        leqno: r.parser.settings.leqno
      };
      return U0(r.parser, e, "display");
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  S0({
    type: "array",
    names: [
      "CD"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      return We(r), Fa(r.parser);
    },
    htmlBuilder: k0,
    mathmlBuilder: z0
  });
  m("\\nonumber", "\\gdef\\@eqnsw{0}");
  m("\\notag", "\\nonumber");
  B({
    type: "text",
    names: [
      "\\hline",
      "\\hdashline"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      allowedInMath: true
    },
    handler(r, e) {
      throw new k(r.funcName + " valid only within array environment");
    }
  });
  var dr = u1;
  B({
    type: "environment",
    names: [
      "\\begin",
      "\\end"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "text"
      ]
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r, n = e[0];
      if (n.type !== "ordgroup")
        throw new k("Invalid environment name", n);
      for (var l = "", u = 0; u < n.body.length; ++u)
        l += O(n.body[u], "textord").text;
      if (a === "\\begin") {
        if (!dr.hasOwnProperty(l))
          throw new k("No such environment: " + l, n);
        var h = dr[l], { args: c, optArgs: p } = t.parseArguments("\\begin{" + l + "}", h), g = {
          mode: t.mode,
          envName: l,
          parser: t
        }, b = h.handler(g, c, p);
        t.expect("\\end", false);
        var y = t.nextToken, x = O(t.parseFunction(), "environment");
        if (x.name !== l)
          throw new k("Mismatch: \\begin{" + l + "} matched by \\end{" + x.name + "}", y);
        return b;
      }
      return {
        type: "environment",
        mode: t.mode,
        name: l,
        nameGroup: n
      };
    }
  });
  var m1 = (r, e) => {
    var t = r.font, a = e.withFont(t);
    return U(r.body, a);
  }, c1 = (r, e) => {
    var t = r.font, a = e.withFont(t);
    return W(r.body, a);
  }, fr = {
    "\\Bbb": "\\mathbb",
    "\\bold": "\\mathbf",
    "\\frak": "\\mathfrak",
    "\\bm": "\\boldsymbol"
  };
  B({
    type: "font",
    names: [
      "\\mathrm",
      "\\mathit",
      "\\mathbf",
      "\\mathnormal",
      "\\mathsfit",
      "\\mathbb",
      "\\mathcal",
      "\\mathfrak",
      "\\mathscr",
      "\\mathsf",
      "\\mathtt",
      "\\Bbb",
      "\\bold",
      "\\frak"
    ],
    props: {
      numArgs: 1,
      allowedInArgument: true
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = Ie(e[0]), l = a;
      return l in fr && (l = fr[l]), {
        type: "font",
        mode: t.mode,
        font: l.slice(1),
        body: n
      };
    },
    htmlBuilder: m1,
    mathmlBuilder: c1
  });
  B({
    type: "mclass",
    names: [
      "\\boldsymbol",
      "\\bm"
    ],
    props: {
      numArgs: 1
    },
    handler: (r, e) => {
      var { parser: t } = r, a = e[0];
      return {
        type: "mclass",
        mode: t.mode,
        mclass: Ve(a),
        body: [
          {
            type: "font",
            mode: t.mode,
            font: "boldsymbol",
            body: a
          }
        ],
        isCharacterBox: D0(a)
      };
    }
  });
  B({
    type: "font",
    names: [
      "\\rm",
      "\\sf",
      "\\tt",
      "\\bf",
      "\\it",
      "\\cal"
    ],
    props: {
      numArgs: 0,
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t, funcName: a, breakOnTokenText: n } = r, { mode: l } = t, u = t.parseExpression(true, n), h = "math" + a.slice(1);
      return {
        type: "font",
        mode: l,
        font: h,
        body: {
          type: "ordgroup",
          mode: t.mode,
          body: u
        }
      };
    },
    htmlBuilder: m1,
    mathmlBuilder: c1
  });
  var Qa = (r, e) => {
    var t = e.style, a = t.fracNum(), n = t.fracDen(), l;
    l = e.havingStyle(a);
    var u = U(r.numer, l, e);
    if (r.continued) {
      var h = 8.5 / e.fontMetrics().ptPerEm, c = 3.5 / e.fontMetrics().ptPerEm;
      u.height = u.height < h ? h : u.height, u.depth = u.depth < c ? c : u.depth;
    }
    l = e.havingStyle(n);
    var p = U(r.denom, l, e), g, b, y;
    r.hasBarLine ? (r.barSize ? (b = K(r.barSize, e), g = ee("frac-line", e, b)) : g = ee("frac-line", e), b = g.height, y = g.height) : (g = null, b = 0, y = e.fontMetrics().defaultRuleThickness);
    var x, A, T;
    t.size === N.DISPLAY.size ? (x = e.fontMetrics().num1, b > 0 ? A = 3 * y : A = 7 * y, T = e.fontMetrics().denom1) : (b > 0 ? (x = e.fontMetrics().num2, A = y) : (x = e.fontMetrics().num3, A = 3 * y), T = e.fontMetrics().denom2);
    var C;
    if (g) {
      var I = e.fontMetrics().axisHeight;
      x - u.depth - (I + 0.5 * b) < A && (x += A - (x - u.depth - (I + 0.5 * b))), I - 0.5 * b - (p.height - T) < A && (T += A - (I - 0.5 * b - (p.height - T)));
      var H = -(I - 0.5 * b);
      C = G({
        positionType: "individualShift",
        children: [
          {
            type: "elem",
            elem: p,
            shift: T
          },
          {
            type: "elem",
            elem: g,
            shift: H
          },
          {
            type: "elem",
            elem: u,
            shift: -x
          }
        ]
      });
    } else {
      var q = x - u.depth - (p.height - T);
      q < A && (x += 0.5 * (A - q), T += 0.5 * (A - q)), C = G({
        positionType: "individualShift",
        children: [
          {
            type: "elem",
            elem: p,
            shift: T
          },
          {
            type: "elem",
            elem: u,
            shift: -x
          }
        ]
      });
    }
    l = e.havingStyle(t), C.height *= l.sizeMultiplier / e.sizeMultiplier, C.depth *= l.sizeMultiplier / e.sizeMultiplier;
    var F;
    t.size === N.DISPLAY.size ? F = e.fontMetrics().delim1 : t.size === N.SCRIPTSCRIPT.size ? F = e.havingStyle(N.SCRIPT).fontMetrics().delim2 : F = e.fontMetrics().delim2;
    var V, L;
    return r.leftDelim == null ? V = he(e, [
      "mopen"
    ]) : V = kt(r.leftDelim, F, true, e.havingStyle(t), r.mode, [
      "mopen"
    ]), r.continued ? L = S([]) : r.rightDelim == null ? L = he(e, [
      "mclose"
    ]) : L = kt(r.rightDelim, F, true, e.havingStyle(t), r.mode, [
      "mclose"
    ]), S([
      "mord"
    ].concat(l.sizingClasses(e)), [
      V,
      S([
        "mfrac"
      ], [
        C
      ]),
      L
    ], e);
  }, _a = (r, e) => {
    var t = new z("mfrac", [
      W(r.numer, e),
      W(r.denom, e)
    ]);
    if (!r.hasBarLine)
      t.setAttribute("linethickness", "0px");
    else if (r.barSize) {
      var a = K(r.barSize, e);
      t.setAttribute("linethickness", M(a));
    }
    if (r.leftDelim != null || r.rightDelim != null) {
      var n = [];
      if (r.leftDelim != null) {
        var l = new z("mo", [
          new _(r.leftDelim.replace("\\", ""))
        ]);
        l.setAttribute("fence", "true"), n.push(l);
      }
      if (n.push(t), r.rightDelim != null) {
        var u = new z("mo", [
          new _(r.rightDelim.replace("\\", ""))
        ]);
        u.setAttribute("fence", "true"), n.push(u);
      }
      return qt(n);
    }
    return t;
  }, d1 = (r, e) => {
    if (!e)
      return r;
    var t = {
      type: "styling",
      mode: r.mode,
      style: e,
      body: [
        r
      ]
    };
    return t;
  };
  B({
    type: "genfrac",
    names: [
      "\\cfrac",
      "\\dfrac",
      "\\frac",
      "\\tfrac",
      "\\dbinom",
      "\\binom",
      "\\tbinom",
      "\\\\atopfrac",
      "\\\\bracefrac",
      "\\\\brackfrac"
    ],
    props: {
      numArgs: 2,
      allowedInArgument: true
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = e[0], l = e[1], u, h = null, c = null;
      switch (a) {
        case "\\cfrac":
        case "\\dfrac":
        case "\\frac":
        case "\\tfrac":
          u = true;
          break;
        case "\\\\atopfrac":
          u = false;
          break;
        case "\\dbinom":
        case "\\binom":
        case "\\tbinom":
          u = false, h = "(", c = ")";
          break;
        case "\\\\bracefrac":
          u = false, h = "\\{", c = "\\}";
          break;
        case "\\\\brackfrac":
          u = false, h = "[", c = "]";
          break;
        default:
          throw new Error("Unrecognized genfrac command");
      }
      var p = a === "\\cfrac", g = null;
      return p || a.startsWith("\\d") ? g = "display" : a.startsWith("\\t") && (g = "text"), d1({
        type: "genfrac",
        mode: t.mode,
        numer: n,
        denom: l,
        continued: p,
        hasBarLine: u,
        leftDelim: h,
        rightDelim: c,
        barSize: null
      }, g);
    },
    htmlBuilder: Qa,
    mathmlBuilder: _a
  });
  B({
    type: "infix",
    names: [
      "\\over",
      "\\choose",
      "\\atop",
      "\\brace",
      "\\brack"
    ],
    props: {
      numArgs: 0,
      infix: true
    },
    handler(r) {
      var { parser: e, funcName: t, token: a } = r, n;
      switch (t) {
        case "\\over":
          n = "\\frac";
          break;
        case "\\choose":
          n = "\\binom";
          break;
        case "\\atop":
          n = "\\\\atopfrac";
          break;
        case "\\brace":
          n = "\\\\bracefrac";
          break;
        case "\\brack":
          n = "\\\\brackfrac";
          break;
        default:
          throw new Error("Unrecognized infix genfrac command");
      }
      return {
        type: "infix",
        mode: e.mode,
        replaceWith: n,
        token: a
      };
    }
  });
  var pr = [
    "display",
    "text",
    "script",
    "scriptscript"
  ], vr = function(e) {
    var t = null;
    return e.length > 0 && (t = e, t = t === "." ? null : t), t;
  };
  B({
    type: "genfrac",
    names: [
      "\\genfrac"
    ],
    props: {
      numArgs: 6,
      allowedInArgument: true,
      argTypes: [
        "math",
        "math",
        "size",
        "text",
        "math",
        "math"
      ]
    },
    handler(r, e) {
      var { parser: t } = r, a = e[4], n = e[5], l = Ie(e[0]), u = l.type === "atom" && l.family === "open" ? vr(l.text) : null, h = Ie(e[1]), c = h.type === "atom" && h.family === "close" ? vr(h.text) : null, p = O(e[2], "size"), g, b = null;
      p.isBlank ? g = true : (b = p.value, g = b.number > 0);
      var y = null, x = e[3];
      if (x.type === "ordgroup") {
        if (x.body.length > 0) {
          var A = O(x.body[0], "textord");
          y = pr[Number(A.text)];
        }
      } else
        x = O(x, "textord"), y = pr[Number(x.text)];
      return d1({
        type: "genfrac",
        mode: t.mode,
        numer: a,
        denom: n,
        continued: false,
        hasBarLine: g,
        barSize: b,
        leftDelim: u,
        rightDelim: c
      }, y);
    }
  });
  B({
    type: "infix",
    names: [
      "\\above"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "size"
      ],
      infix: true
    },
    handler(r, e) {
      var { parser: t, funcName: a, token: n } = r;
      return {
        type: "infix",
        mode: t.mode,
        replaceWith: "\\\\abovefrac",
        size: O(e[0], "size").value,
        token: n
      };
    }
  });
  B({
    type: "genfrac",
    names: [
      "\\\\abovefrac"
    ],
    props: {
      numArgs: 3,
      argTypes: [
        "math",
        "size",
        "math"
      ]
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = e[0], l = O(e[1], "infix").size;
      if (!l)
        throw new Error("\\\\abovefrac expected size, but got " + String(l));
      var u = e[2], h = l.number > 0;
      return {
        type: "genfrac",
        mode: t.mode,
        numer: n,
        denom: u,
        continued: false,
        hasBarLine: h,
        barSize: l,
        leftDelim: null,
        rightDelim: null
      };
    }
  });
  var f1 = (r, e) => {
    var t = e.style, a, n;
    r.type === "supsub" ? (a = r.sup ? U(r.sup, e.havingStyle(t.sup()), e) : U(r.sub, e.havingStyle(t.sub()), e), n = O(r.base, "horizBrace")) : n = O(r, "horizBrace");
    var l = U(n.base, e.havingBaseStyle(N.DISPLAY)), u = Pe(n, e), h;
    if (n.isOver ? (h = G({
      positionType: "firstBaseline",
      children: [
        {
          type: "elem",
          elem: l
        },
        {
          type: "kern",
          size: 0.1
        },
        {
          type: "elem",
          elem: u
        }
      ]
    }), h.children[0].children[0].children[1].classes.push("svg-align")) : (h = G({
      positionType: "bottom",
      positionData: l.depth + 0.1 + u.height,
      children: [
        {
          type: "elem",
          elem: u
        },
        {
          type: "kern",
          size: 0.1
        },
        {
          type: "elem",
          elem: l
        }
      ]
    }), h.children[0].children[0].children[0].classes.push("svg-align")), a) {
      var c = S([
        "mord",
        n.isOver ? "mover" : "munder"
      ], [
        h
      ], e);
      n.isOver ? h = G({
        positionType: "firstBaseline",
        children: [
          {
            type: "elem",
            elem: c
          },
          {
            type: "kern",
            size: 0.2
          },
          {
            type: "elem",
            elem: a
          }
        ]
      }) : h = G({
        positionType: "bottom",
        positionData: c.depth + 0.2 + a.height + a.depth,
        children: [
          {
            type: "elem",
            elem: a
          },
          {
            type: "kern",
            size: 0.2
          },
          {
            type: "elem",
            elem: c
          }
        ]
      });
    }
    return S([
      "mord",
      n.isOver ? "mover" : "munder"
    ], [
      h
    ], e);
  }, e4 = (r, e) => {
    var t = Le(r.label);
    return new z(r.isOver ? "mover" : "munder", [
      W(r.base, e),
      t
    ]);
  };
  B({
    type: "horizBrace",
    names: [
      "\\overbrace",
      "\\underbrace"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r;
      return {
        type: "horizBrace",
        mode: t.mode,
        label: a,
        isOver: /^\\over/.test(a),
        base: e[0]
      };
    },
    htmlBuilder: f1,
    mathmlBuilder: e4
  });
  B({
    type: "href",
    names: [
      "\\href"
    ],
    props: {
      numArgs: 2,
      argTypes: [
        "url",
        "original"
      ],
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t } = r, a = e[1], n = O(e[0], "url").url;
      return t.settings.isTrusted({
        command: "\\href",
        url: n
      }) ? {
        type: "href",
        mode: t.mode,
        href: n,
        body: Q(a)
      } : t.formatUnsupportedCmd("\\href");
    },
    htmlBuilder: (r, e) => {
      var t = r0(r.body, e, false);
      return ga(r.href, [], t, e);
    },
    mathmlBuilder: (r, e) => {
      var t = G0(r.body, e);
      return t instanceof z || (t = new z("mrow", [
        t
      ])), t.setAttribute("href", r.href), t;
    }
  });
  B({
    type: "href",
    names: [
      "\\url"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "url"
      ],
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t } = r, a = O(e[0], "url").url;
      if (!t.settings.isTrusted({
        command: "\\url",
        url: a
      }))
        return t.formatUnsupportedCmd("\\url");
      for (var n = [], l = 0; l < a.length; l++) {
        var u = a[l];
        u === "~" && (u = "\\textasciitilde"), n.push({
          type: "textord",
          mode: "text",
          text: u
        });
      }
      var h = {
        type: "text",
        mode: t.mode,
        font: "\\texttt",
        body: n
      };
      return {
        type: "href",
        mode: t.mode,
        href: a,
        body: Q(h)
      };
    }
  });
  B({
    type: "hbox",
    names: [
      "\\hbox"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "text"
      ],
      allowedInText: true,
      primitive: true
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "hbox",
        mode: t.mode,
        body: Q(e[0])
      };
    },
    htmlBuilder(r, e) {
      var t = r0(r.body, e, false);
      return q0(t);
    },
    mathmlBuilder(r, e) {
      return new z("mrow", p0(r.body, e));
    }
  });
  B({
    type: "html",
    names: [
      "\\htmlClass",
      "\\htmlId",
      "\\htmlStyle",
      "\\htmlData"
    ],
    props: {
      numArgs: 2,
      argTypes: [
        "raw",
        "original"
      ],
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t, funcName: a, token: n } = r, l = O(e[0], "raw").string, u = e[1];
      t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
      var h, c = {};
      switch (a) {
        case "\\htmlClass":
          c.class = l, h = {
            command: "\\htmlClass",
            class: l
          };
          break;
        case "\\htmlId":
          c.id = l, h = {
            command: "\\htmlId",
            id: l
          };
          break;
        case "\\htmlStyle":
          c.style = l, h = {
            command: "\\htmlStyle",
            style: l
          };
          break;
        case "\\htmlData": {
          for (var p = l.split(","), g = 0; g < p.length; g++) {
            var b = p[g], y = b.indexOf("=");
            if (y < 0)
              throw new k("\\htmlData key/value '" + b + "' missing equals sign");
            var x = b.slice(0, y), A = b.slice(y + 1);
            c["data-" + x.trim()] = A;
          }
          h = {
            command: "\\htmlData",
            attributes: c
          };
          break;
        }
        default:
          throw new Error("Unrecognized html command");
      }
      return t.settings.isTrusted(h) ? {
        type: "html",
        mode: t.mode,
        attributes: c,
        body: Q(u)
      } : t.formatUnsupportedCmd(a);
    },
    htmlBuilder: (r, e) => {
      var t = r0(r.body, e, false), a = [
        "enclosing"
      ];
      r.attributes.class && a.push(...r.attributes.class.trim().split(/\s+/));
      var n = S(a, t, e);
      for (var l in r.attributes)
        l !== "class" && r.attributes.hasOwnProperty(l) && n.setAttribute(l, r.attributes[l]);
      return n;
    },
    mathmlBuilder: (r, e) => G0(r.body, e)
  });
  B({
    type: "htmlmathml",
    names: [
      "\\html@mathml"
    ],
    props: {
      numArgs: 2,
      allowedInArgument: true,
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t } = r;
      return {
        type: "htmlmathml",
        mode: t.mode,
        html: Q(e[0]),
        mathml: Q(e[1])
      };
    },
    htmlBuilder: (r, e) => {
      var t = r0(r.html, e, false);
      return q0(t);
    },
    mathmlBuilder: (r, e) => G0(r.mathml, e)
  });
  var st = function(e) {
    if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
      return {
        number: +e,
        unit: "bp"
      };
    var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
    if (!t)
      throw new k("Invalid size: '" + e + "' in \\includegraphics");
    var a = {
      number: +(t[1] + t[2]),
      unit: t[3]
    };
    if (!qr(a))
      throw new k("Invalid unit: '" + a.unit + "' in \\includegraphics.");
    return a;
  };
  B({
    type: "includegraphics",
    names: [
      "\\includegraphics"
    ],
    props: {
      numArgs: 1,
      numOptionalArgs: 1,
      argTypes: [
        "raw",
        "url"
      ],
      allowedInText: false
    },
    handler: (r, e, t) => {
      var { parser: a } = r, n = {
        number: 0,
        unit: "em"
      }, l = {
        number: 0.9,
        unit: "em"
      }, u = {
        number: 0,
        unit: "em"
      }, h = "";
      if (t[0])
        for (var c = O(t[0], "raw").string, p = c.split(","), g = 0; g < p.length; g++) {
          var b = p[g].split("=");
          if (b.length === 2) {
            var y = b[1].trim();
            switch (b[0].trim()) {
              case "alt":
                h = y;
                break;
              case "width":
                n = st(y);
                break;
              case "height":
                l = st(y);
                break;
              case "totalheight":
                u = st(y);
                break;
              default:
                throw new k("Invalid key: '" + b[0] + "' in \\includegraphics.");
            }
          }
        }
      var x = O(e[0], "url").url;
      return h === "" && (h = x, h = h.replace(/^.*[\\/]/, ""), h = h.substring(0, h.lastIndexOf("."))), a.settings.isTrusted({
        command: "\\includegraphics",
        url: x
      }) ? {
        type: "includegraphics",
        mode: a.mode,
        alt: h,
        width: n,
        height: l,
        totalheight: u,
        src: x
      } : a.formatUnsupportedCmd("\\includegraphics");
    },
    htmlBuilder: (r, e) => {
      var t = K(r.height, e), a = 0;
      r.totalheight.number > 0 && (a = K(r.totalheight, e) - t);
      var n = 0;
      r.width.number > 0 && (n = K(r.width, e));
      var l = {
        height: M(t + a)
      };
      n > 0 && (l.width = M(n)), a > 0 && (l.verticalAlign = M(-a));
      var u = new ia(r.src, r.alt, l);
      return u.height = t, u.depth = a, u;
    },
    mathmlBuilder: (r, e) => {
      var t = new z("mglyph", []);
      t.setAttribute("alt", r.alt);
      var a = K(r.height, e), n = 0;
      if (r.totalheight.number > 0 && (n = K(r.totalheight, e) - a, t.setAttribute("valign", M(-n))), t.setAttribute("height", M(a + n)), r.width.number > 0) {
        var l = K(r.width, e);
        t.setAttribute("width", M(l));
      }
      return t.setAttribute("src", r.src), t;
    }
  });
  B({
    type: "kern",
    names: [
      "\\kern",
      "\\mkern",
      "\\hskip",
      "\\mskip"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "size"
      ],
      primitive: true,
      allowedInText: true
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r, n = O(e[0], "size");
      if (t.settings.strict) {
        var l = a[1] === "m", u = n.value.unit === "mu";
        l ? (u || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " supports only mu units, " + ("not " + n.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " works only in math mode")) : u && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " doesn't support mu units");
      }
      return {
        type: "kern",
        mode: t.mode,
        dimension: n.value
      };
    },
    htmlBuilder(r, e) {
      return Or(r.dimension, e);
    },
    mathmlBuilder(r, e) {
      var t = K(r.dimension, e);
      return new Vr(t);
    }
  });
  B({
    type: "lap",
    names: [
      "\\mathllap",
      "\\mathrlap",
      "\\mathclap"
    ],
    props: {
      numArgs: 1,
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = e[0];
      return {
        type: "lap",
        mode: t.mode,
        alignment: a.slice(5),
        body: n
      };
    },
    htmlBuilder: (r, e) => {
      var t;
      r.alignment === "clap" ? (t = S([], [
        U(r.body, e)
      ]), t = S([
        "inner"
      ], [
        t
      ], e)) : t = S([
        "inner"
      ], [
        U(r.body, e)
      ]);
      var a = S([
        "fix"
      ], []), n = S([
        r.alignment
      ], [
        t,
        a
      ], e), l = S([
        "strut"
      ]);
      return l.style.height = M(n.height + n.depth), n.depth && (l.style.verticalAlign = M(-n.depth)), n.children.unshift(l), n = S([
        "thinbox"
      ], [
        n
      ], e), S([
        "mord",
        "vbox"
      ], [
        n
      ], e);
    },
    mathmlBuilder: (r, e) => {
      var t = new z("mpadded", [
        W(r.body, e)
      ]);
      if (r.alignment !== "rlap") {
        var a = r.alignment === "llap" ? "-1" : "-0.5";
        t.setAttribute("lspace", a + "width");
      }
      return t.setAttribute("width", "0px"), t;
    }
  });
  B({
    type: "styling",
    names: [
      "\\(",
      "$"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      allowedInMath: false
    },
    handler(r, e) {
      var { funcName: t, parser: a } = r, n = a.mode;
      a.switchMode("math");
      var l = t === "\\(" ? "\\)" : "$", u = a.parseExpression(false, l);
      return a.expect(l), a.switchMode(n), {
        type: "styling",
        mode: a.mode,
        style: "text",
        body: u
      };
    }
  });
  B({
    type: "text",
    names: [
      "\\)",
      "\\]"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      allowedInMath: false
    },
    handler(r, e) {
      throw new k("Mismatched " + r.funcName);
    }
  });
  var gr = (r, e) => {
    switch (e.style.size) {
      case N.DISPLAY.size:
        return r.display;
      case N.TEXT.size:
        return r.text;
      case N.SCRIPT.size:
        return r.script;
      case N.SCRIPTSCRIPT.size:
        return r.scriptscript;
      default:
        return r.text;
    }
  };
  B({
    type: "mathchoice",
    names: [
      "\\mathchoice"
    ],
    props: {
      numArgs: 4,
      primitive: true
    },
    handler: (r, e) => {
      var { parser: t } = r;
      return {
        type: "mathchoice",
        mode: t.mode,
        display: Q(e[0]),
        text: Q(e[1]),
        script: Q(e[2]),
        scriptscript: Q(e[3])
      };
    },
    htmlBuilder: (r, e) => {
      var t = gr(r, e), a = r0(t, e, false);
      return q0(a);
    },
    mathmlBuilder: (r, e) => {
      var t = gr(r, e);
      return G0(t, e);
    }
  });
  var p1 = (r, e, t, a, n, l, u) => {
    r = S([], [
      r
    ]);
    var h = t && D0(t), c, p;
    if (e) {
      var g = U(e, a.havingStyle(n.sup()), a);
      p = {
        elem: g,
        kern: Math.max(a.fontMetrics().bigOpSpacing1, a.fontMetrics().bigOpSpacing3 - g.depth)
      };
    }
    if (t) {
      var b = U(t, a.havingStyle(n.sub()), a);
      c = {
        elem: b,
        kern: Math.max(a.fontMetrics().bigOpSpacing2, a.fontMetrics().bigOpSpacing4 - b.height)
      };
    }
    var y;
    if (p && c) {
      var x = a.fontMetrics().bigOpSpacing5 + c.elem.height + c.elem.depth + c.kern + r.depth + u;
      y = G({
        positionType: "bottom",
        positionData: x,
        children: [
          {
            type: "kern",
            size: a.fontMetrics().bigOpSpacing5
          },
          {
            type: "elem",
            elem: c.elem,
            marginLeft: M(-l)
          },
          {
            type: "kern",
            size: c.kern
          },
          {
            type: "elem",
            elem: r
          },
          {
            type: "kern",
            size: p.kern
          },
          {
            type: "elem",
            elem: p.elem,
            marginLeft: M(l)
          },
          {
            type: "kern",
            size: a.fontMetrics().bigOpSpacing5
          }
        ]
      });
    } else if (c) {
      var A = r.height - u;
      y = G({
        positionType: "top",
        positionData: A,
        children: [
          {
            type: "kern",
            size: a.fontMetrics().bigOpSpacing5
          },
          {
            type: "elem",
            elem: c.elem,
            marginLeft: M(-l)
          },
          {
            type: "kern",
            size: c.kern
          },
          {
            type: "elem",
            elem: r
          }
        ]
      });
    } else if (p) {
      var T = r.depth + u;
      y = G({
        positionType: "bottom",
        positionData: T,
        children: [
          {
            type: "elem",
            elem: r
          },
          {
            type: "kern",
            size: p.kern
          },
          {
            type: "elem",
            elem: p.elem,
            marginLeft: M(l)
          },
          {
            type: "kern",
            size: a.fontMetrics().bigOpSpacing5
          }
        ]
      });
    } else
      return r;
    var C = [
      y
    ];
    if (c && l !== 0 && !h) {
      var q = S([
        "mspace"
      ], [], a);
      q.style.marginRight = M(l), C.unshift(q);
    }
    return S([
      "mop",
      "op-limits"
    ], C, a);
  }, v1 = /* @__PURE__ */ new Set([
    "\\smallint"
  ]), ie = (r, e) => {
    var t, a, n = false, l;
    r.type === "supsub" ? (t = r.sup, a = r.sub, l = O(r.base, "op"), n = true) : l = O(r, "op");
    var u = e.style, h = false;
    u.size === N.DISPLAY.size && l.symbol && !v1.has(l.name) && (h = true);
    var c;
    if (l.symbol) {
      var p = h ? "Size2-Regular" : "Size1-Regular", g = "";
      if ((l.name === "\\oiint" || l.name === "\\oiiint") && (g = l.name.slice(1), l.name = g === "oiint" ? "\\iint" : "\\iiint"), c = l0(l.name, p, "math", e, [
        "mop",
        "op-symbol",
        h ? "large-op" : "small-op"
      ]), g.length > 0) {
        var b = c.italic, y = Lr(g + "Size" + (h ? "2" : "1"), e);
        c = G({
          positionType: "individualShift",
          children: [
            {
              type: "elem",
              elem: c,
              shift: 0
            },
            {
              type: "elem",
              elem: y,
              shift: h ? 0.08 : 0
            }
          ]
        }), l.name = "\\" + g, c.classes.unshift("mop"), c.italic = b;
      }
    } else if (l.body) {
      var x = r0(l.body, e, true);
      x.length === 1 && x[0] instanceof d0 ? (c = x[0], c.classes[0] = "mop") : c = S([
        "mop"
      ], x, e);
    } else {
      for (var A = [], T = 1; T < l.name.length; T++)
        A.push(Dt(l.name[T], l.mode, e));
      c = S([
        "mop"
      ], A, e);
    }
    var C = 0, q = 0;
    return (c instanceof d0 || l.name === "\\oiint" || l.name === "\\oiiint") && !l.suppressBaseShift && (C = (c.height - c.depth) / 2 - e.fontMetrics().axisHeight, q = c.italic || 0), n ? p1(c, t, a, e, u, q, C) : (C && (c.style.position = "relative", c.style.top = M(C)), c);
  }, me = (r, e) => {
    var t;
    if (r.symbol)
      t = new z("mo", [
        g0(r.name, r.mode)
      ]), v1.has(r.name) && t.setAttribute("largeop", "false");
    else if (r.body)
      t = new z("mo", p0(r.body, e));
    else {
      t = new z("mi", [
        new _(r.name.slice(1))
      ]);
      var a = new z("mo", [
        g0("\u2061", "text")
      ]);
      r.parentIsSupSub ? t = new z("mrow", [
        t,
        a
      ]) : t = Ur([
        t,
        a
      ]);
    }
    return t;
  }, t4 = {
    "\u220F": "\\prod",
    "\u2210": "\\coprod",
    "\u2211": "\\sum",
    "\u22C0": "\\bigwedge",
    "\u22C1": "\\bigvee",
    "\u22C2": "\\bigcap",
    "\u22C3": "\\bigcup",
    "\u2A00": "\\bigodot",
    "\u2A01": "\\bigoplus",
    "\u2A02": "\\bigotimes",
    "\u2A04": "\\biguplus",
    "\u2A06": "\\bigsqcup"
  };
  B({
    type: "op",
    names: [
      "\\coprod",
      "\\bigvee",
      "\\bigwedge",
      "\\biguplus",
      "\\bigcap",
      "\\bigcup",
      "\\intop",
      "\\prod",
      "\\sum",
      "\\bigotimes",
      "\\bigoplus",
      "\\bigodot",
      "\\bigsqcup",
      "\\smallint",
      "\u220F",
      "\u2210",
      "\u2211",
      "\u22C0",
      "\u22C1",
      "\u22C2",
      "\u22C3",
      "\u2A00",
      "\u2A01",
      "\u2A02",
      "\u2A04",
      "\u2A06"
    ],
    props: {
      numArgs: 0
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = a;
      return n.length === 1 && (n = t4[n]), {
        type: "op",
        mode: t.mode,
        limits: true,
        parentIsSupSub: false,
        symbol: true,
        name: n
      };
    },
    htmlBuilder: ie,
    mathmlBuilder: me
  });
  B({
    type: "op",
    names: [
      "\\mathop"
    ],
    props: {
      numArgs: 1,
      primitive: true
    },
    handler: (r, e) => {
      var { parser: t } = r, a = e[0];
      return {
        type: "op",
        mode: t.mode,
        limits: false,
        parentIsSupSub: false,
        symbol: false,
        body: Q(a)
      };
    },
    htmlBuilder: ie,
    mathmlBuilder: me
  });
  var r4 = {
    "\u222B": "\\int",
    "\u222C": "\\iint",
    "\u222D": "\\iiint",
    "\u222E": "\\oint",
    "\u222F": "\\oiint",
    "\u2230": "\\oiiint"
  };
  B({
    type: "op",
    names: [
      "\\arcsin",
      "\\arccos",
      "\\arctan",
      "\\arctg",
      "\\arcctg",
      "\\arg",
      "\\ch",
      "\\cos",
      "\\cosec",
      "\\cosh",
      "\\cot",
      "\\cotg",
      "\\coth",
      "\\csc",
      "\\ctg",
      "\\cth",
      "\\deg",
      "\\dim",
      "\\exp",
      "\\hom",
      "\\ker",
      "\\lg",
      "\\ln",
      "\\log",
      "\\sec",
      "\\sin",
      "\\sinh",
      "\\sh",
      "\\tan",
      "\\tanh",
      "\\tg",
      "\\th"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      var { parser: e, funcName: t } = r;
      return {
        type: "op",
        mode: e.mode,
        limits: false,
        parentIsSupSub: false,
        symbol: false,
        name: t
      };
    },
    htmlBuilder: ie,
    mathmlBuilder: me
  });
  B({
    type: "op",
    names: [
      "\\det",
      "\\gcd",
      "\\inf",
      "\\lim",
      "\\max",
      "\\min",
      "\\Pr",
      "\\sup"
    ],
    props: {
      numArgs: 0
    },
    handler(r) {
      var { parser: e, funcName: t } = r;
      return {
        type: "op",
        mode: e.mode,
        limits: true,
        parentIsSupSub: false,
        symbol: false,
        name: t
      };
    },
    htmlBuilder: ie,
    mathmlBuilder: me
  });
  B({
    type: "op",
    names: [
      "\\int",
      "\\iint",
      "\\iiint",
      "\\oint",
      "\\oiint",
      "\\oiiint",
      "\u222B",
      "\u222C",
      "\u222D",
      "\u222E",
      "\u222F",
      "\u2230"
    ],
    props: {
      numArgs: 0,
      allowedInArgument: true
    },
    handler(r) {
      var { parser: e, funcName: t } = r, a = t;
      return a.length === 1 && (a = r4[a]), {
        type: "op",
        mode: e.mode,
        limits: false,
        parentIsSupSub: false,
        symbol: true,
        name: a
      };
    },
    htmlBuilder: ie,
    mathmlBuilder: me
  });
  var g1 = (r, e) => {
    var t, a, n = false, l;
    r.type === "supsub" ? (t = r.sup, a = r.sub, l = O(r.base, "operatorname"), n = true) : l = O(r, "operatorname");
    var u;
    if (l.body.length > 0) {
      for (var h = l.body.map((b) => {
        var y = "text" in b ? b.text : void 0;
        return typeof y == "string" ? {
          type: "textord",
          mode: b.mode,
          text: y
        } : b;
      }), c = r0(h, e.withFont("mathrm"), true), p = 0; p < c.length; p++) {
        var g = c[p];
        g instanceof d0 && (g.text = g.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
      }
      u = S([
        "mop"
      ], c, e);
    } else
      u = S([
        "mop"
      ], [], e);
    return n ? p1(u, t, a, e, e.style, 0, 0) : u;
  }, a4 = (r, e) => {
    for (var t = p0(r.body, e.withFont("mathrm")), a = true, n = 0; n < t.length; n++) {
      var l = t[n];
      if (!(l instanceof Vr))
        if (l instanceof z)
          switch (l.type) {
            case "mi":
            case "mn":
            case "mspace":
            case "mtext":
              break;
            case "mo": {
              var u = l.children[0];
              l.children.length === 1 && u instanceof _ ? u.text = u.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : a = false;
              break;
            }
            default:
              a = false;
          }
        else
          a = false;
    }
    if (a) {
      var h = t.map((g) => g.toText()).join("");
      t = [
        new _(h)
      ];
    }
    var c = new z("mi", t);
    c.setAttribute("mathvariant", "normal");
    var p = new z("mo", [
      g0("\u2061", "text")
    ]);
    return r.parentIsSupSub ? new z("mrow", [
      c,
      p
    ]) : Ur([
      c,
      p
    ]);
  };
  B({
    type: "operatorname",
    names: [
      "\\operatorname@",
      "\\operatornamewithlimits"
    ],
    props: {
      numArgs: 1
    },
    handler: (r, e) => {
      var { parser: t, funcName: a } = r, n = e[0];
      return {
        type: "operatorname",
        mode: t.mode,
        body: Q(n),
        alwaysHandleSupSub: a === "\\operatornamewithlimits",
        limits: false,
        parentIsSupSub: false
      };
    },
    htmlBuilder: g1,
    mathmlBuilder: a4
  });
  m("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
  X0({
    type: "ordgroup",
    htmlBuilder(r, e) {
      return r.semisimple ? q0(r0(r.body, e, false)) : S([
        "mord"
      ], r0(r.body, e, true), e);
    },
    mathmlBuilder(r, e) {
      return G0(r.body, e, true);
    }
  });
  B({
    type: "overline",
    names: [
      "\\overline"
    ],
    props: {
      numArgs: 1
    },
    handler(r, e) {
      var { parser: t } = r, a = e[0];
      return {
        type: "overline",
        mode: t.mode,
        body: a
      };
    },
    htmlBuilder(r, e) {
      var t = U(r.body, e.havingCrampedStyle()), a = ee("overline-line", e), n = e.fontMetrics().defaultRuleThickness, l = G({
        positionType: "firstBaseline",
        children: [
          {
            type: "elem",
            elem: t
          },
          {
            type: "kern",
            size: 3 * n
          },
          {
            type: "elem",
            elem: a
          },
          {
            type: "kern",
            size: n
          }
        ]
      });
      return S([
        "mord",
        "overline"
      ], [
        l
      ], e);
    },
    mathmlBuilder(r, e) {
      var t = new z("mo", [
        new _("\u203E")
      ]);
      t.setAttribute("stretchy", "true");
      var a = new z("mover", [
        W(r.body, e),
        t
      ]);
      return a.setAttribute("accent", "true"), a;
    }
  });
  B({
    type: "phantom",
    names: [
      "\\phantom"
    ],
    props: {
      numArgs: 1,
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t } = r, a = e[0];
      return {
        type: "phantom",
        mode: t.mode,
        body: Q(a)
      };
    },
    htmlBuilder: (r, e) => {
      var t = r0(r.body, e.withPhantom(), false);
      return q0(t);
    },
    mathmlBuilder: (r, e) => {
      var t = p0(r.body, e);
      return new z("mphantom", t);
    }
  });
  m("\\hphantom", "\\smash{\\phantom{#1}}");
  B({
    type: "vphantom",
    names: [
      "\\vphantom"
    ],
    props: {
      numArgs: 1,
      allowedInText: true
    },
    handler: (r, e) => {
      var { parser: t } = r, a = e[0];
      return {
        type: "vphantom",
        mode: t.mode,
        body: a
      };
    },
    htmlBuilder: (r, e) => {
      var t = S([
        "inner"
      ], [
        U(r.body, e.withPhantom())
      ]), a = S([
        "fix"
      ], []);
      return S([
        "mord",
        "rlap"
      ], [
        t,
        a
      ], e);
    },
    mathmlBuilder: (r, e) => {
      var t = p0(Q(r.body), e), a = new z("mphantom", t), n = new z("mpadded", [
        a
      ]);
      return n.setAttribute("width", "0px"), n;
    }
  });
  B({
    type: "raisebox",
    names: [
      "\\raisebox"
    ],
    props: {
      numArgs: 2,
      argTypes: [
        "size",
        "hbox"
      ],
      allowedInText: true
    },
    handler(r, e) {
      var { parser: t } = r, a = O(e[0], "size").value, n = e[1];
      return {
        type: "raisebox",
        mode: t.mode,
        dy: a,
        body: n
      };
    },
    htmlBuilder(r, e) {
      var t = U(r.body, e), a = K(r.dy, e);
      return G({
        positionType: "shift",
        positionData: -a,
        children: [
          {
            type: "elem",
            elem: t
          }
        ]
      });
    },
    mathmlBuilder(r, e) {
      var t = new z("mpadded", [
        W(r.body, e)
      ]), a = r.dy.number + r.dy.unit;
      return t.setAttribute("voffset", a), t;
    }
  });
  B({
    type: "internal",
    names: [
      "\\relax"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      allowedInArgument: true
    },
    handler(r) {
      var { parser: e } = r;
      return {
        type: "internal",
        mode: e.mode
      };
    }
  });
  B({
    type: "rule",
    names: [
      "\\rule"
    ],
    props: {
      numArgs: 2,
      numOptionalArgs: 1,
      allowedInText: true,
      allowedInMath: true,
      argTypes: [
        "size",
        "size",
        "size"
      ]
    },
    handler(r, e, t) {
      var { parser: a } = r, n = t[0], l = O(e[0], "size"), u = O(e[1], "size");
      return {
        type: "rule",
        mode: a.mode,
        shift: n && O(n, "size").value,
        width: l.value,
        height: u.value
      };
    },
    htmlBuilder(r, e) {
      var t = S([
        "mord",
        "rule"
      ], [], e), a = K(r.width, e), n = K(r.height, e), l = r.shift ? K(r.shift, e) : 0;
      return t.style.borderRightWidth = M(a), t.style.borderTopWidth = M(n), t.style.bottom = M(l), t.width = a, t.height = n + l, t.depth = -l, t.maxFontSize = n * 1.125 * e.sizeMultiplier, t;
    },
    mathmlBuilder(r, e) {
      var t = K(r.width, e), a = K(r.height, e), n = r.shift ? K(r.shift, e) : 0, l = e.color && e.getColor() || "black", u = new z("mspace");
      u.setAttribute("mathbackground", l), u.setAttribute("width", M(t)), u.setAttribute("height", M(a));
      var h = new z("mpadded", [
        u
      ]);
      return n >= 0 ? h.setAttribute("height", M(n)) : (h.setAttribute("height", M(n)), h.setAttribute("depth", M(-n))), h.setAttribute("voffset", M(n)), h;
    }
  });
  function b1(r, e, t) {
    for (var a = r0(r, e, false), n = e.sizeMultiplier / t.sizeMultiplier, l = 0; l < a.length; l++) {
      var u = a[l].classes.indexOf("sizing");
      u < 0 ? Array.prototype.push.apply(a[l].classes, e.sizingClasses(t)) : a[l].classes[u + 1] === "reset-size" + e.size && (a[l].classes[u + 1] = "reset-size" + t.size), a[l].height *= n, a[l].depth *= n;
    }
    return q0(a);
  }
  var br = [
    "\\tiny",
    "\\sixptsize",
    "\\scriptsize",
    "\\footnotesize",
    "\\small",
    "\\normalsize",
    "\\large",
    "\\Large",
    "\\LARGE",
    "\\huge",
    "\\Huge"
  ], n4 = (r, e) => {
    var t = e.havingSize(r.size);
    return b1(r.body, t, e);
  };
  B({
    type: "sizing",
    names: br,
    props: {
      numArgs: 0,
      allowedInText: true
    },
    handler: (r, e) => {
      var { breakOnTokenText: t, funcName: a, parser: n } = r, l = n.parseExpression(false, t);
      return {
        type: "sizing",
        mode: n.mode,
        size: br.indexOf(a) + 1,
        body: l
      };
    },
    htmlBuilder: n4,
    mathmlBuilder: (r, e) => {
      var t = e.havingSize(r.size), a = p0(r.body, t), n = new z("mstyle", a);
      return n.setAttribute("mathsize", M(t.sizeMultiplier)), n;
    }
  });
  B({
    type: "smash",
    names: [
      "\\smash"
    ],
    props: {
      numArgs: 1,
      numOptionalArgs: 1,
      allowedInText: true
    },
    handler: (r, e, t) => {
      var { parser: a } = r, n = false, l = false, u = t[0] && O(t[0], "ordgroup");
      if (u)
        for (var h = "", c = 0; c < u.body.length; ++c) {
          var p = u.body[c];
          if (h = Ge(p).text, h === "t")
            n = true;
          else if (h === "b")
            l = true;
          else {
            n = false, l = false;
            break;
          }
        }
      else
        n = true, l = true;
      var g = e[0];
      return {
        type: "smash",
        mode: a.mode,
        body: g,
        smashHeight: n,
        smashDepth: l
      };
    },
    htmlBuilder: (r, e) => {
      var t = S([], [
        U(r.body, e)
      ]);
      if (!r.smashHeight && !r.smashDepth)
        return t;
      if (r.smashHeight && (t.height = 0), r.smashDepth && (t.depth = 0), r.smashHeight && r.smashDepth)
        return S([
          "mord",
          "smash"
        ], [
          t
        ], e);
      if (t.children)
        for (var a = 0; a < t.children.length; a++)
          r.smashHeight && (t.children[a].height = 0), r.smashDepth && (t.children[a].depth = 0);
      var n = G({
        positionType: "firstBaseline",
        children: [
          {
            type: "elem",
            elem: t
          }
        ]
      });
      return S([
        "mord"
      ], [
        n
      ], e);
    },
    mathmlBuilder: (r, e) => {
      var t = new z("mpadded", [
        W(r.body, e)
      ]);
      return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t;
    }
  });
  B({
    type: "sqrt",
    names: [
      "\\sqrt"
    ],
    props: {
      numArgs: 1,
      numOptionalArgs: 1
    },
    handler(r, e, t) {
      var { parser: a } = r, n = t[0], l = e[0];
      return {
        type: "sqrt",
        mode: a.mode,
        body: l,
        index: n
      };
    },
    htmlBuilder(r, e) {
      var t = U(r.body, e.havingCrampedStyle());
      t.height === 0 && (t.height = e.fontMetrics().xHeight), t = te(t, e);
      var a = e.fontMetrics(), n = a.defaultRuleThickness, l = n;
      e.style.id < N.TEXT.id && (l = e.fontMetrics().xHeight);
      var u = n + l / 4, h = t.height + t.depth + u + n, { span: c, ruleWidth: p, advanceWidth: g } = $a(h, e), b = c.height - p;
      b > t.height + t.depth + u && (u = (u + b - t.height - t.depth) / 2);
      var y = c.height - t.height - u - p;
      t.style.paddingLeft = M(g);
      var x = G({
        positionType: "firstBaseline",
        children: [
          {
            type: "elem",
            elem: t,
            wrapperClasses: [
              "svg-align"
            ]
          },
          {
            type: "kern",
            size: -(t.height + y)
          },
          {
            type: "elem",
            elem: c
          },
          {
            type: "kern",
            size: p
          }
        ]
      });
      if (r.index) {
        var A = e.havingStyle(N.SCRIPTSCRIPT), T = U(r.index, A, e), C = 0.6 * (x.height - x.depth), q = G({
          positionType: "shift",
          positionData: -C,
          children: [
            {
              type: "elem",
              elem: T
            }
          ]
        }), I = S([
          "root"
        ], [
          q
        ]);
        return S([
          "mord",
          "sqrt"
        ], [
          I,
          x
        ], e);
      } else
        return S([
          "mord",
          "sqrt"
        ], [
          x
        ], e);
    },
    mathmlBuilder(r, e) {
      var { body: t, index: a } = r;
      return a ? new z("mroot", [
        W(t, e),
        W(a, e)
      ]) : new z("msqrt", [
        W(t, e)
      ]);
    }
  });
  var yr = {
    display: N.DISPLAY,
    text: N.TEXT,
    script: N.SCRIPT,
    scriptscript: N.SCRIPTSCRIPT
  };
  B({
    type: "styling",
    names: [
      "\\displaystyle",
      "\\textstyle",
      "\\scriptstyle",
      "\\scriptscriptstyle"
    ],
    props: {
      numArgs: 0,
      allowedInText: true,
      primitive: true
    },
    handler(r, e) {
      var { breakOnTokenText: t, funcName: a, parser: n } = r, l = n.parseExpression(true, t), u = a.slice(1, a.length - 5);
      return {
        type: "styling",
        mode: n.mode,
        style: u,
        body: l
      };
    },
    htmlBuilder(r, e) {
      var t = yr[r.style], a = e.havingStyle(t).withFont("");
      return b1(r.body, a, e);
    },
    mathmlBuilder(r, e) {
      var t = yr[r.style], a = e.havingStyle(t), n = p0(r.body, a), l = new z("mstyle", n), u = {
        display: [
          "0",
          "true"
        ],
        text: [
          "0",
          "false"
        ],
        script: [
          "1",
          "false"
        ],
        scriptscript: [
          "2",
          "false"
        ]
      }, h = u[r.style];
      return l.setAttribute("scriptlevel", h[0]), l.setAttribute("displaystyle", h[1]), l;
    }
  });
  var i4 = function(e, t) {
    var a = e.base;
    if (a)
      if (a.type === "op") {
        var n = a.limits && (t.style.size === N.DISPLAY.size || a.alwaysHandleSupSub);
        return n ? ie : null;
      } else if (a.type === "operatorname") {
        var l = a.alwaysHandleSupSub && (t.style.size === N.DISPLAY.size || a.limits);
        return l ? g1 : null;
      } else {
        if (a.type === "accent")
          return D0(a.base) ? Rt : null;
        if (a.type === "horizBrace") {
          var u = !e.sub;
          return u === a.isOver ? f1 : null;
        } else
          return null;
      }
    else
      return null;
  };
  X0({
    type: "supsub",
    htmlBuilder(r, e) {
      var t = i4(r, e);
      if (t)
        return t(r, e);
      var { base: a, sup: n, sub: l } = r, u = U(a, e), h, c, p = e.fontMetrics(), g = 0, b = 0, y = a && D0(a);
      if (n) {
        var x = e.havingStyle(e.style.sup());
        h = U(n, x, e), y || (g = u.height - x.fontMetrics().supDrop * x.sizeMultiplier / e.sizeMultiplier);
      }
      if (l) {
        var A = e.havingStyle(e.style.sub());
        c = U(l, A, e), y || (b = u.depth + A.fontMetrics().subDrop * A.sizeMultiplier / e.sizeMultiplier);
      }
      var T;
      e.style === N.DISPLAY ? T = p.sup1 : e.style.cramped ? T = p.sup3 : T = p.sup2;
      var C = e.sizeMultiplier, q = M(0.5 / p.ptPerEm / C), I = null;
      if (c) {
        var H = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
        (u instanceof d0 || H) && (I = M(-u.italic));
      }
      var F;
      if (h && c) {
        g = Math.max(g, T, h.depth + 0.25 * p.xHeight), b = Math.max(b, p.sub2);
        var V = p.defaultRuleThickness, L = 4 * V;
        if (g - h.depth - (c.height - b) < L) {
          b = L - (g - h.depth) + c.height;
          var P = 0.8 * p.xHeight - (g - h.depth);
          P > 0 && (g += P, b -= P);
        }
        var X = [
          {
            type: "elem",
            elem: c,
            shift: b,
            marginRight: q,
            marginLeft: I
          },
          {
            type: "elem",
            elem: h,
            shift: -g,
            marginRight: q
          }
        ];
        F = G({
          positionType: "individualShift",
          children: X
        });
      } else if (c) {
        b = Math.max(b, p.sub1, c.height - 0.8 * p.xHeight);
        var $ = [
          {
            type: "elem",
            elem: c,
            marginLeft: I,
            marginRight: q
          }
        ];
        F = G({
          positionType: "shift",
          positionData: b,
          children: $
        });
      } else if (h)
        g = Math.max(g, T, h.depth + 0.25 * p.xHeight), F = G({
          positionType: "shift",
          positionData: -g,
          children: [
            {
              type: "elem",
              elem: h,
              marginRight: q
            }
          ]
        });
      else
        throw new Error("supsub must have either sup or sub.");
      var o0 = yt(u, "right") || "mord";
      return S([
        o0
      ], [
        u,
        S([
          "msupsub"
        ], [
          F
        ])
      ], e);
    },
    mathmlBuilder(r, e) {
      var t = false, a, n;
      r.base && r.base.type === "horizBrace" && (n = !!r.sup, n === r.base.isOver && (t = true, a = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = true);
      var l = [
        W(r.base, e)
      ];
      r.sub && l.push(W(r.sub, e)), r.sup && l.push(W(r.sup, e));
      var u;
      if (t)
        u = a ? "mover" : "munder";
      else if (r.sub)
        if (r.sup) {
          var p = r.base;
          p && p.type === "op" && p.limits && e.style === N.DISPLAY || p && p.type === "operatorname" && p.alwaysHandleSupSub && (e.style === N.DISPLAY || p.limits) ? u = "munderover" : u = "msubsup";
        } else {
          var c = r.base;
          c && c.type === "op" && c.limits && (e.style === N.DISPLAY || c.alwaysHandleSupSub) || c && c.type === "operatorname" && c.alwaysHandleSupSub && (c.limits || e.style === N.DISPLAY) ? u = "munder" : u = "msub";
        }
      else {
        var h = r.base;
        h && h.type === "op" && h.limits && (e.style === N.DISPLAY || h.alwaysHandleSupSub) || h && h.type === "operatorname" && h.alwaysHandleSupSub && (h.limits || e.style === N.DISPLAY) ? u = "mover" : u = "msup";
      }
      return new z(u, l);
    }
  });
  X0({
    type: "atom",
    htmlBuilder(r, e) {
      return Dt(r.text, r.mode, e, [
        "m" + r.family
      ]);
    },
    mathmlBuilder(r, e) {
      var t = new z("mo", [
        g0(r.text, r.mode)
      ]);
      if (r.family === "bin") {
        var a = Et(r, e);
        a === "bold-italic" && t.setAttribute("mathvariant", a);
      } else
        r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false");
      return t;
    }
  });
  var y1 = {
    mi: "italic",
    mn: "normal",
    mtext: "normal"
  };
  X0({
    type: "mathord",
    htmlBuilder(r, e) {
      return Fe(r, e, "mathord");
    },
    mathmlBuilder(r, e) {
      var t = new z("mi", [
        g0(r.text, r.mode, e)
      ]), a = Et(r, e) || "italic";
      return a !== y1[t.type] && t.setAttribute("mathvariant", a), t;
    }
  });
  X0({
    type: "textord",
    htmlBuilder(r, e) {
      return Fe(r, e, "textord");
    },
    mathmlBuilder(r, e) {
      var t = g0(r.text, r.mode, e), a = Et(r, e) || "normal", n;
      return r.mode === "text" ? n = new z("mtext", [
        t
      ]) : /[0-9]/.test(r.text) ? n = new z("mn", [
        t
      ]) : r.text === "\\prime" ? n = new z("mo", [
        t
      ]) : n = new z("mi", [
        t
      ]), a !== y1[n.type] && n.setAttribute("mathvariant", a), n;
    }
  });
  var ut = {
    "\\nobreak": "nobreak",
    "\\allowbreak": "allowbreak"
  }, ot = {
    " ": {},
    "\\ ": {},
    "~": {
      className: "nobreak"
    },
    "\\space": {},
    "\\nobreakspace": {
      className: "nobreak"
    }
  };
  X0({
    type: "spacing",
    htmlBuilder(r, e) {
      if (ot.hasOwnProperty(r.text)) {
        var t = ot[r.text].className || "";
        if (r.mode === "text") {
          var a = Fe(r, e, "textord");
          return a.classes.push(t), a;
        } else
          return S([
            "mspace",
            t
          ], [
            Dt(r.text, r.mode, e)
          ], e);
      } else {
        if (ut.hasOwnProperty(r.text))
          return S([
            "mspace",
            ut[r.text]
          ], [], e);
        throw new k('Unknown type of space "' + r.text + '"');
      }
    },
    mathmlBuilder(r, e) {
      var t;
      if (ot.hasOwnProperty(r.text))
        t = new z("mtext", [
          new _("\xA0")
        ]);
      else {
        if (ut.hasOwnProperty(r.text))
          return new z("mspace");
        throw new k('Unknown type of space "' + r.text + '"');
      }
      return t;
    }
  });
  var xr = () => {
    var r = new z("mtd", []);
    return r.setAttribute("width", "50%"), r;
  };
  X0({
    type: "tag",
    mathmlBuilder(r, e) {
      var t = new z("mtable", [
        new z("mtr", [
          xr(),
          new z("mtd", [
            G0(r.body, e)
          ]),
          xr(),
          new z("mtd", [
            G0(r.tag, e)
          ])
        ])
      ]);
      return t.setAttribute("width", "100%"), t;
    }
  });
  var wr = {
    "\\text": void 0,
    "\\textrm": "textrm",
    "\\textsf": "textsf",
    "\\texttt": "texttt",
    "\\textnormal": "textrm"
  }, Sr = {
    "\\textbf": "textbf",
    "\\textmd": "textmd"
  }, l4 = {
    "\\textit": "textit",
    "\\textup": "textup"
  }, kr = (r, e) => {
    var t = r.font;
    if (t) {
      if (wr[t])
        return e.withTextFontFamily(wr[t]);
      if (Sr[t])
        return e.withTextFontWeight(Sr[t]);
      if (t === "\\emph")
        return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
    } else
      return e;
    return e.withTextFontShape(l4[t]);
  };
  B({
    type: "text",
    names: [
      "\\text",
      "\\textrm",
      "\\textsf",
      "\\texttt",
      "\\textnormal",
      "\\textbf",
      "\\textmd",
      "\\textit",
      "\\textup",
      "\\emph"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "text"
      ],
      allowedInArgument: true,
      allowedInText: true
    },
    handler(r, e) {
      var { parser: t, funcName: a } = r, n = e[0];
      return {
        type: "text",
        mode: t.mode,
        body: Q(n),
        font: a
      };
    },
    htmlBuilder(r, e) {
      var t = kr(r, e), a = r0(r.body, t, true);
      return S([
        "mord",
        "text"
      ], a, t);
    },
    mathmlBuilder(r, e) {
      var t = kr(r, e);
      return G0(r.body, t);
    }
  });
  B({
    type: "underline",
    names: [
      "\\underline"
    ],
    props: {
      numArgs: 1,
      allowedInText: true
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "underline",
        mode: t.mode,
        body: e[0]
      };
    },
    htmlBuilder(r, e) {
      var t = U(r.body, e), a = ee("underline-line", e), n = e.fontMetrics().defaultRuleThickness, l = G({
        positionType: "top",
        positionData: t.height,
        children: [
          {
            type: "kern",
            size: n
          },
          {
            type: "elem",
            elem: a
          },
          {
            type: "kern",
            size: 3 * n
          },
          {
            type: "elem",
            elem: t
          }
        ]
      });
      return S([
        "mord",
        "underline"
      ], [
        l
      ], e);
    },
    mathmlBuilder(r, e) {
      var t = new z("mo", [
        new _("\u203E")
      ]);
      t.setAttribute("stretchy", "true");
      var a = new z("munder", [
        W(r.body, e),
        t
      ]);
      return a.setAttribute("accentunder", "true"), a;
    }
  });
  B({
    type: "vcenter",
    names: [
      "\\vcenter"
    ],
    props: {
      numArgs: 1,
      argTypes: [
        "original"
      ],
      allowedInText: false
    },
    handler(r, e) {
      var { parser: t } = r;
      return {
        type: "vcenter",
        mode: t.mode,
        body: e[0]
      };
    },
    htmlBuilder(r, e) {
      var t = U(r.body, e), a = e.fontMetrics().axisHeight, n = 0.5 * (t.height - a - (t.depth + a));
      return G({
        positionType: "shift",
        positionData: n,
        children: [
          {
            type: "elem",
            elem: t
          }
        ]
      });
    },
    mathmlBuilder(r, e) {
      return new z("mpadded", [
        W(r.body, e)
      ], [
        "vcenter"
      ]);
    }
  });
  B({
    type: "verb",
    names: [
      "\\verb"
    ],
    props: {
      numArgs: 0,
      allowedInText: true
    },
    handler(r, e, t) {
      throw new k("\\verb ended by end of line instead of matching delimiter");
    },
    htmlBuilder(r, e) {
      for (var t = zr(r), a = [], n = e.havingStyle(e.style.text()), l = 0; l < t.length; l++) {
        var u = t[l];
        u === "~" && (u = "\\textasciitilde"), a.push(l0(u, "Typewriter-Regular", r.mode, n, [
          "mord",
          "texttt"
        ]));
      }
      return S([
        "mord",
        "text"
      ].concat(n.sizingClasses(e)), Hr(a), n);
    },
    mathmlBuilder(r, e) {
      var t = new _(zr(r)), a = new z("mtext", [
        t
      ]);
      return a.setAttribute("mathvariant", "monospace"), a;
    }
  });
  var zr = (r) => r.body.replace(/ /g, r.star ? "\u2423" : "\xA0"), O0 = Pr, x1 = `[ \r
	]`, s4 = "\\\\[a-zA-Z@]+", u4 = "\\\\[^\uD800-\uDFFF]", o4 = "(" + s4 + ")" + x1 + "*", h4 = `\\\\(
|[ \r	]+
?)[ \r	]*`, zt = "[\u0300-\u036F]", m4 = new RegExp(zt + "+$"), c4 = "(" + x1 + "+)|" + (h4 + "|") + "([!-\\[\\]-\u2027\u202A-\uD7FF\uF900-\uFFFF]" + (zt + "*") + "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + (zt + "*") + "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + ("|" + o4) + ("|" + u4 + ")");
  class Mr {
    constructor(e, t) {
      this.input = e, this.settings = t, this.tokenRegex = new RegExp(c4, "g"), this.catcodes = {
        "%": 14,
        "~": 13
      };
    }
    setCatcode(e, t) {
      this.catcodes[e] = t;
    }
    lex() {
      var e = this.input, t = this.tokenRegex.lastIndex;
      if (t === e.length)
        return new c0("EOF", new m0(this, t, t));
      var a = this.tokenRegex.exec(e);
      if (a === null || a.index !== t)
        throw new k("Unexpected character: '" + e[t] + "'", new c0(e[t], new m0(this, t, t + 1)));
      var n = a[6] || a[3] || (a[2] ? "\\ " : " ");
      if (this.catcodes[n] === 14) {
        var l = e.indexOf(`
`, this.tokenRegex.lastIndex);
        return l === -1 ? (this.tokenRegex.lastIndex = e.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = l + 1, this.lex();
      }
      return new c0(n, new m0(this, t, this.tokenRegex.lastIndex));
    }
  }
  class d4 {
    constructor(e, t) {
      e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = t, this.builtins = e, this.undefStack = [];
    }
    beginGroup() {
      this.undefStack.push({});
    }
    endGroup() {
      if (this.undefStack.length === 0)
        throw new k("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
      var e = this.undefStack.pop();
      for (var t in e)
        e.hasOwnProperty(t) && (e[t] == null ? delete this.current[t] : this.current[t] = e[t]);
    }
    endGroups() {
      for (; this.undefStack.length > 0; )
        this.endGroup();
    }
    has(e) {
      return this.current.hasOwnProperty(e) || this.builtins.hasOwnProperty(e);
    }
    get(e) {
      return this.current.hasOwnProperty(e) ? this.current[e] : this.builtins[e];
    }
    set(e, t, a) {
      if (a === void 0 && (a = false), a) {
        for (var n = 0; n < this.undefStack.length; n++)
          delete this.undefStack[n][e];
        this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
      } else {
        var l = this.undefStack[this.undefStack.length - 1];
        l && !l.hasOwnProperty(e) && (l[e] = this.current[e]);
      }
      t == null ? delete this.current[e] : this.current[e] = t;
    }
  }
  var f4 = o1;
  m("\\noexpand", function(r) {
    var e = r.popToken();
    return r.isExpandable(e.text) && (e.noexpand = true, e.treatAsRelax = true), {
      tokens: [
        e
      ],
      numArgs: 0
    };
  });
  m("\\expandafter", function(r) {
    var e = r.popToken();
    return r.expandOnce(true), {
      tokens: [
        e
      ],
      numArgs: 0
    };
  });
  m("\\@firstoftwo", function(r) {
    var e = r.consumeArgs(2);
    return {
      tokens: e[0],
      numArgs: 0
    };
  });
  m("\\@secondoftwo", function(r) {
    var e = r.consumeArgs(2);
    return {
      tokens: e[1],
      numArgs: 0
    };
  });
  m("\\@ifnextchar", function(r) {
    var e = r.consumeArgs(3);
    r.consumeSpaces();
    var t = r.future();
    return e[0].length === 1 && e[0][0].text === t.text ? {
      tokens: e[1],
      numArgs: 0
    } : {
      tokens: e[2],
      numArgs: 0
    };
  });
  m("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
  m("\\TextOrMath", function(r) {
    var e = r.consumeArgs(2);
    return r.mode === "text" ? {
      tokens: e[0],
      numArgs: 0
    } : {
      tokens: e[1],
      numArgs: 0
    };
  });
  var Ar = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    a: 10,
    A: 10,
    b: 11,
    B: 11,
    c: 12,
    C: 12,
    d: 13,
    D: 13,
    e: 14,
    E: 14,
    f: 15,
    F: 15
  };
  m("\\char", function(r) {
    var e = r.popToken(), t, a = 0;
    if (e.text === "'")
      t = 8, e = r.popToken();
    else if (e.text === '"')
      t = 16, e = r.popToken();
    else if (e.text === "`")
      if (e = r.popToken(), e.text[0] === "\\")
        a = e.text.charCodeAt(1);
      else {
        if (e.text === "EOF")
          throw new k("\\char` missing argument");
        a = e.text.charCodeAt(0);
      }
    else
      t = 10;
    if (t) {
      if (a = Ar[e.text], a == null || a >= t)
        throw new k("Invalid base-" + t + " digit " + e.text);
      for (var n; (n = Ar[r.future().text]) != null && n < t; )
        a *= t, a += n, r.popToken();
    }
    return "\\@char{" + a + "}";
  });
  var Lt = (r, e, t, a) => {
    var n = r.consumeArg().tokens;
    if (n.length !== 1)
      throw new k("\\newcommand's first argument must be a macro name");
    var l = n[0].text, u = r.isDefined(l);
    if (u && !e)
      throw new k("\\newcommand{" + l + "} attempting to redefine " + (l + "; use \\renewcommand"));
    if (!u && !t)
      throw new k("\\renewcommand{" + l + "} when command " + l + " does not yet exist; use \\newcommand");
    var h = 0;
    if (n = r.consumeArg().tokens, n.length === 1 && n[0].text === "[") {
      for (var c = "", p = r.expandNextToken(); p.text !== "]" && p.text !== "EOF"; )
        c += p.text, p = r.expandNextToken();
      if (!c.match(/^\s*[0-9]+\s*$/))
        throw new k("Invalid number of arguments: " + c);
      h = parseInt(c), n = r.consumeArg().tokens;
    }
    return u && a || r.macros.set(l, {
      tokens: n,
      numArgs: h
    }), "";
  };
  m("\\newcommand", (r) => Lt(r, false, true, false));
  m("\\renewcommand", (r) => Lt(r, true, false, false));
  m("\\providecommand", (r) => Lt(r, true, true, true));
  m("\\message", (r) => {
    var e = r.consumeArgs(1)[0];
    return console.log(e.reverse().map((t) => t.text).join("")), "";
  });
  m("\\errmessage", (r) => {
    var e = r.consumeArgs(1)[0];
    return console.error(e.reverse().map((t) => t.text).join("")), "";
  });
  m("\\show", (r) => {
    var e = r.popToken(), t = e.text;
    return console.log(e, r.macros.get(t), O0[t], Y.math[t], Y.text[t]), "";
  });
  m("\\bgroup", "{");
  m("\\egroup", "}");
  m("~", "\\nobreakspace");
  m("\\lq", "`");
  m("\\rq", "'");
  m("\\aa", "\\r a");
  m("\\AA", "\\r A");
  m("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`\xA9}");
  m("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
  m("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`\xAE}");
  m("\u212C", "\\mathscr{B}");
  m("\u2130", "\\mathscr{E}");
  m("\u2131", "\\mathscr{F}");
  m("\u210B", "\\mathscr{H}");
  m("\u2110", "\\mathscr{I}");
  m("\u2112", "\\mathscr{L}");
  m("\u2133", "\\mathscr{M}");
  m("\u211B", "\\mathscr{R}");
  m("\u212D", "\\mathfrak{C}");
  m("\u210C", "\\mathfrak{H}");
  m("\u2128", "\\mathfrak{Z}");
  m("\\Bbbk", "\\Bbb{k}");
  m("\xB7", "\\cdotp");
  m("\\llap", "\\mathllap{\\textrm{#1}}");
  m("\\rlap", "\\mathrlap{\\textrm{#1}}");
  m("\\clap", "\\mathclap{\\textrm{#1}}");
  m("\\mathstrut", "\\vphantom{(}");
  m("\\underbar", "\\underline{\\text{#1}}");
  m("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char"338}');
  m("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`\u2260}}");
  m("\\ne", "\\neq");
  m("\u2260", "\\neq");
  m("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`\u2209}}");
  m("\u2209", "\\notin");
  m("\u2258", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`\u2258}}");
  m("\u2259", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`\u2258}}");
  m("\u225A", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`\u225A}}");
  m("\u225B", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`\u225B}}");
  m("\u225D", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`\u225D}}");
  m("\u225E", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`\u225E}}");
  m("\u225F", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`\u225F}}");
  m("\u27C2", "\\perp");
  m("\u203C", "\\mathclose{!\\mkern-0.8mu!}");
  m("\u220C", "\\notni");
  m("\u231C", "\\ulcorner");
  m("\u231D", "\\urcorner");
  m("\u231E", "\\llcorner");
  m("\u231F", "\\lrcorner");
  m("\xA9", "\\copyright");
  m("\xAE", "\\textregistered");
  m("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
  m("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
  m("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
  m("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
  m("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
  m("\u22EE", "\\vdots");
  m("\\varGamma", "\\mathit{\\Gamma}");
  m("\\varDelta", "\\mathit{\\Delta}");
  m("\\varTheta", "\\mathit{\\Theta}");
  m("\\varLambda", "\\mathit{\\Lambda}");
  m("\\varXi", "\\mathit{\\Xi}");
  m("\\varPi", "\\mathit{\\Pi}");
  m("\\varSigma", "\\mathit{\\Sigma}");
  m("\\varUpsilon", "\\mathit{\\Upsilon}");
  m("\\varPhi", "\\mathit{\\Phi}");
  m("\\varPsi", "\\mathit{\\Psi}");
  m("\\varOmega", "\\mathit{\\Omega}");
  m("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
  m("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
  m("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
  m("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
  m("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
  m("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
  m("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
  m("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
  var Tr = {
    ",": "\\dotsc",
    "\\not": "\\dotsb",
    "+": "\\dotsb",
    "=": "\\dotsb",
    "<": "\\dotsb",
    ">": "\\dotsb",
    "-": "\\dotsb",
    "*": "\\dotsb",
    ":": "\\dotsb",
    "\\DOTSB": "\\dotsb",
    "\\coprod": "\\dotsb",
    "\\bigvee": "\\dotsb",
    "\\bigwedge": "\\dotsb",
    "\\biguplus": "\\dotsb",
    "\\bigcap": "\\dotsb",
    "\\bigcup": "\\dotsb",
    "\\prod": "\\dotsb",
    "\\sum": "\\dotsb",
    "\\bigotimes": "\\dotsb",
    "\\bigoplus": "\\dotsb",
    "\\bigodot": "\\dotsb",
    "\\bigsqcup": "\\dotsb",
    "\\And": "\\dotsb",
    "\\longrightarrow": "\\dotsb",
    "\\Longrightarrow": "\\dotsb",
    "\\longleftarrow": "\\dotsb",
    "\\Longleftarrow": "\\dotsb",
    "\\longleftrightarrow": "\\dotsb",
    "\\Longleftrightarrow": "\\dotsb",
    "\\mapsto": "\\dotsb",
    "\\longmapsto": "\\dotsb",
    "\\hookrightarrow": "\\dotsb",
    "\\doteq": "\\dotsb",
    "\\mathbin": "\\dotsb",
    "\\mathrel": "\\dotsb",
    "\\relbar": "\\dotsb",
    "\\Relbar": "\\dotsb",
    "\\xrightarrow": "\\dotsb",
    "\\xleftarrow": "\\dotsb",
    "\\DOTSI": "\\dotsi",
    "\\int": "\\dotsi",
    "\\oint": "\\dotsi",
    "\\iint": "\\dotsi",
    "\\iiint": "\\dotsi",
    "\\iiiint": "\\dotsi",
    "\\idotsint": "\\dotsi",
    "\\DOTSX": "\\dotsx"
  }, p4 = /* @__PURE__ */ new Set([
    "bin",
    "rel"
  ]);
  m("\\dots", function(r) {
    var e = "\\dotso", t = r.expandAfterFuture().text;
    return t in Tr ? e = Tr[t] : (t.slice(0, 4) === "\\not" || t in Y.math && p4.has(Y.math[t].group)) && (e = "\\dotsb"), e;
  });
  var Pt = {
    ")": true,
    "]": true,
    "\\rbrack": true,
    "\\}": true,
    "\\rbrace": true,
    "\\rangle": true,
    "\\rceil": true,
    "\\rfloor": true,
    "\\rgroup": true,
    "\\rmoustache": true,
    "\\right": true,
    "\\bigr": true,
    "\\biggr": true,
    "\\Bigr": true,
    "\\Biggr": true,
    $: true,
    ";": true,
    ".": true,
    ",": true
  };
  m("\\dotso", function(r) {
    var e = r.future().text;
    return e in Pt ? "\\ldots\\," : "\\ldots";
  });
  m("\\dotsc", function(r) {
    var e = r.future().text;
    return e in Pt && e !== "," ? "\\ldots\\," : "\\ldots";
  });
  m("\\cdots", function(r) {
    var e = r.future().text;
    return e in Pt ? "\\@cdots\\," : "\\@cdots";
  });
  m("\\dotsb", "\\cdots");
  m("\\dotsm", "\\cdots");
  m("\\dotsi", "\\!\\cdots");
  m("\\dotsx", "\\ldots\\,");
  m("\\DOTSI", "\\relax");
  m("\\DOTSB", "\\relax");
  m("\\DOTSX", "\\relax");
  m("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
  m("\\,", "\\tmspace+{3mu}{.1667em}");
  m("\\thinspace", "\\,");
  m("\\>", "\\mskip{4mu}");
  m("\\:", "\\tmspace+{4mu}{.2222em}");
  m("\\medspace", "\\:");
  m("\\;", "\\tmspace+{5mu}{.2777em}");
  m("\\thickspace", "\\;");
  m("\\!", "\\tmspace-{3mu}{.1667em}");
  m("\\negthinspace", "\\!");
  m("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
  m("\\negthickspace", "\\tmspace-{5mu}{.277em}");
  m("\\enspace", "\\kern.5em ");
  m("\\enskip", "\\hskip.5em\\relax");
  m("\\quad", "\\hskip1em\\relax");
  m("\\qquad", "\\hskip2em\\relax");
  m("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
  m("\\tag@paren", "\\tag@literal{({#1})}");
  m("\\tag@literal", (r) => {
    if (r.macros.get("\\df@tag"))
      throw new k("Multiple \\tag");
    return "\\gdef\\df@tag{\\text{#1}}";
  });
  m("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
  m("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
  m("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
  m("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
  m("\\newline", "\\\\\\relax");
  m("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
  var w1 = M(w0["Main-Regular"]["T".charCodeAt(0)][1] - 0.7 * w0["Main-Regular"]["A".charCodeAt(0)][1]);
  m("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + w1 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
  m("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + w1 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
  m("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
  m("\\@hspace", "\\hskip #1\\relax");
  m("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
  m("\\ordinarycolon", ":");
  m("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
  m("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
  m("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
  m("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
  m("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
  m("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
  m("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
  m("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
  m("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
  m("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
  m("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
  m("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
  m("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
  m("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
  m("\u2237", "\\dblcolon");
  m("\u2239", "\\eqcolon");
  m("\u2254", "\\coloneqq");
  m("\u2255", "\\eqqcolon");
  m("\u2A74", "\\Coloneqq");
  m("\\ratio", "\\vcentcolon");
  m("\\coloncolon", "\\dblcolon");
  m("\\colonequals", "\\coloneqq");
  m("\\coloncolonequals", "\\Coloneqq");
  m("\\equalscolon", "\\eqqcolon");
  m("\\equalscoloncolon", "\\Eqqcolon");
  m("\\colonminus", "\\coloneq");
  m("\\coloncolonminus", "\\Coloneq");
  m("\\minuscolon", "\\eqcolon");
  m("\\minuscoloncolon", "\\Eqcolon");
  m("\\coloncolonapprox", "\\Colonapprox");
  m("\\coloncolonsim", "\\Colonsim");
  m("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
  m("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
  m("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
  m("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
  m("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`\u220C}}");
  m("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
  m("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
  m("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
  m("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
  m("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
  m("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
  m("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
  m("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
  m("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{\u2269}");
  m("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{\u2268}");
  m("\\ngeqq", "\\html@mathml{\\@ngeqq}{\u2271}");
  m("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{\u2271}");
  m("\\nleqq", "\\html@mathml{\\@nleqq}{\u2270}");
  m("\\nleqslant", "\\html@mathml{\\@nleqslant}{\u2270}");
  m("\\nshortmid", "\\html@mathml{\\@nshortmid}{\u2224}");
  m("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{\u2226}");
  m("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{\u2288}");
  m("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{\u2289}");
  m("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{\u228A}");
  m("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{\u2ACB}");
  m("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{\u228B}");
  m("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{\u2ACC}");
  m("\\imath", "\\html@mathml{\\@imath}{\u0131}");
  m("\\jmath", "\\html@mathml{\\@jmath}{\u0237}");
  m("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`\u27E6}}");
  m("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`\u27E7}}");
  m("\u27E6", "\\llbracket");
  m("\u27E7", "\\rrbracket");
  m("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`\u2983}}");
  m("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`\u2984}}");
  m("\u2983", "\\lBrace");
  m("\u2984", "\\rBrace");
  m("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`\u29B5}}");
  m("\u29B5", "\\minuso");
  m("\\darr", "\\downarrow");
  m("\\dArr", "\\Downarrow");
  m("\\Darr", "\\Downarrow");
  m("\\lang", "\\langle");
  m("\\rang", "\\rangle");
  m("\\uarr", "\\uparrow");
  m("\\uArr", "\\Uparrow");
  m("\\Uarr", "\\Uparrow");
  m("\\N", "\\mathbb{N}");
  m("\\R", "\\mathbb{R}");
  m("\\Z", "\\mathbb{Z}");
  m("\\alef", "\\aleph");
  m("\\alefsym", "\\aleph");
  m("\\Alpha", "\\mathrm{A}");
  m("\\Beta", "\\mathrm{B}");
  m("\\bull", "\\bullet");
  m("\\Chi", "\\mathrm{X}");
  m("\\clubs", "\\clubsuit");
  m("\\cnums", "\\mathbb{C}");
  m("\\Complex", "\\mathbb{C}");
  m("\\Dagger", "\\ddagger");
  m("\\diamonds", "\\diamondsuit");
  m("\\empty", "\\emptyset");
  m("\\Epsilon", "\\mathrm{E}");
  m("\\Eta", "\\mathrm{H}");
  m("\\exist", "\\exists");
  m("\\harr", "\\leftrightarrow");
  m("\\hArr", "\\Leftrightarrow");
  m("\\Harr", "\\Leftrightarrow");
  m("\\hearts", "\\heartsuit");
  m("\\image", "\\Im");
  m("\\infin", "\\infty");
  m("\\Iota", "\\mathrm{I}");
  m("\\isin", "\\in");
  m("\\Kappa", "\\mathrm{K}");
  m("\\larr", "\\leftarrow");
  m("\\lArr", "\\Leftarrow");
  m("\\Larr", "\\Leftarrow");
  m("\\lrarr", "\\leftrightarrow");
  m("\\lrArr", "\\Leftrightarrow");
  m("\\Lrarr", "\\Leftrightarrow");
  m("\\Mu", "\\mathrm{M}");
  m("\\natnums", "\\mathbb{N}");
  m("\\Nu", "\\mathrm{N}");
  m("\\Omicron", "\\mathrm{O}");
  m("\\plusmn", "\\pm");
  m("\\rarr", "\\rightarrow");
  m("\\rArr", "\\Rightarrow");
  m("\\Rarr", "\\Rightarrow");
  m("\\real", "\\Re");
  m("\\reals", "\\mathbb{R}");
  m("\\Reals", "\\mathbb{R}");
  m("\\Rho", "\\mathrm{P}");
  m("\\sdot", "\\cdot");
  m("\\sect", "\\S");
  m("\\spades", "\\spadesuit");
  m("\\sub", "\\subset");
  m("\\sube", "\\subseteq");
  m("\\supe", "\\supseteq");
  m("\\Tau", "\\mathrm{T}");
  m("\\thetasym", "\\vartheta");
  m("\\weierp", "\\wp");
  m("\\Zeta", "\\mathrm{Z}");
  m("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
  m("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
  m("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
  m("\\bra", "\\mathinner{\\langle{#1}|}");
  m("\\ket", "\\mathinner{|{#1}\\rangle}");
  m("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
  m("\\Bra", "\\left\\langle#1\\right|");
  m("\\Ket", "\\left|#1\\right\\rangle");
  var S1 = (r) => (e) => {
    var t = e.consumeArg().tokens, a = e.consumeArg().tokens, n = e.consumeArg().tokens, l = e.consumeArg().tokens, u = e.macros.get("|"), h = e.macros.get("\\|");
    e.macros.beginGroup();
    var c = (b) => (y) => {
      r && (y.macros.set("|", u), n.length && y.macros.set("\\|", h));
      var x = b;
      if (!b && n.length) {
        var A = y.future();
        A.text === "|" && (y.popToken(), x = true);
      }
      return {
        tokens: x ? n : a,
        numArgs: 0
      };
    };
    e.macros.set("|", c(false)), n.length && e.macros.set("\\|", c(true));
    var p = e.consumeArg().tokens, g = e.expandTokens([
      ...l,
      ...p,
      ...t
    ]);
    return e.macros.endGroup(), {
      tokens: g.reverse(),
      numArgs: 0
    };
  };
  m("\\bra@ket", S1(false));
  m("\\bra@set", S1(true));
  m("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
  m("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
  m("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
  m("\\angln", "{\\angl n}");
  m("\\blue", "\\textcolor{##6495ed}{#1}");
  m("\\orange", "\\textcolor{##ffa500}{#1}");
  m("\\pink", "\\textcolor{##ff00af}{#1}");
  m("\\red", "\\textcolor{##df0030}{#1}");
  m("\\green", "\\textcolor{##28ae7b}{#1}");
  m("\\gray", "\\textcolor{gray}{#1}");
  m("\\purple", "\\textcolor{##9d38bd}{#1}");
  m("\\blueA", "\\textcolor{##ccfaff}{#1}");
  m("\\blueB", "\\textcolor{##80f6ff}{#1}");
  m("\\blueC", "\\textcolor{##63d9ea}{#1}");
  m("\\blueD", "\\textcolor{##11accd}{#1}");
  m("\\blueE", "\\textcolor{##0c7f99}{#1}");
  m("\\tealA", "\\textcolor{##94fff5}{#1}");
  m("\\tealB", "\\textcolor{##26edd5}{#1}");
  m("\\tealC", "\\textcolor{##01d1c1}{#1}");
  m("\\tealD", "\\textcolor{##01a995}{#1}");
  m("\\tealE", "\\textcolor{##208170}{#1}");
  m("\\greenA", "\\textcolor{##b6ffb0}{#1}");
  m("\\greenB", "\\textcolor{##8af281}{#1}");
  m("\\greenC", "\\textcolor{##74cf70}{#1}");
  m("\\greenD", "\\textcolor{##1fab54}{#1}");
  m("\\greenE", "\\textcolor{##0d923f}{#1}");
  m("\\goldA", "\\textcolor{##ffd0a9}{#1}");
  m("\\goldB", "\\textcolor{##ffbb71}{#1}");
  m("\\goldC", "\\textcolor{##ff9c39}{#1}");
  m("\\goldD", "\\textcolor{##e07d10}{#1}");
  m("\\goldE", "\\textcolor{##a75a05}{#1}");
  m("\\redA", "\\textcolor{##fca9a9}{#1}");
  m("\\redB", "\\textcolor{##ff8482}{#1}");
  m("\\redC", "\\textcolor{##f9685d}{#1}");
  m("\\redD", "\\textcolor{##e84d39}{#1}");
  m("\\redE", "\\textcolor{##bc2612}{#1}");
  m("\\maroonA", "\\textcolor{##ffbde0}{#1}");
  m("\\maroonB", "\\textcolor{##ff92c6}{#1}");
  m("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
  m("\\maroonD", "\\textcolor{##ca337c}{#1}");
  m("\\maroonE", "\\textcolor{##9e034e}{#1}");
  m("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
  m("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
  m("\\purpleC", "\\textcolor{##aa87ff}{#1}");
  m("\\purpleD", "\\textcolor{##7854ab}{#1}");
  m("\\purpleE", "\\textcolor{##543b78}{#1}");
  m("\\mintA", "\\textcolor{##f5f9e8}{#1}");
  m("\\mintB", "\\textcolor{##edf2df}{#1}");
  m("\\mintC", "\\textcolor{##e0e5cc}{#1}");
  m("\\grayA", "\\textcolor{##f6f7f7}{#1}");
  m("\\grayB", "\\textcolor{##f0f1f2}{#1}");
  m("\\grayC", "\\textcolor{##e3e5e6}{#1}");
  m("\\grayD", "\\textcolor{##d6d8da}{#1}");
  m("\\grayE", "\\textcolor{##babec2}{#1}");
  m("\\grayF", "\\textcolor{##888d93}{#1}");
  m("\\grayG", "\\textcolor{##626569}{#1}");
  m("\\grayH", "\\textcolor{##3b3e40}{#1}");
  m("\\grayI", "\\textcolor{##21242c}{#1}");
  m("\\kaBlue", "\\textcolor{##314453}{#1}");
  m("\\kaGreen", "\\textcolor{##71B307}{#1}");
  var k1 = {
    "^": true,
    _: true,
    "\\limits": true,
    "\\nolimits": true
  };
  class v4 {
    constructor(e, t, a) {
      this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new d4(f4, t.macros), this.mode = a, this.stack = [];
    }
    feed(e) {
      this.lexer = new Mr(e, this.settings);
    }
    switchMode(e) {
      this.mode = e;
    }
    beginGroup() {
      this.macros.beginGroup();
    }
    endGroup() {
      this.macros.endGroup();
    }
    endGroups() {
      this.macros.endGroups();
    }
    future() {
      return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
    }
    popToken() {
      return this.future(), this.stack.pop();
    }
    pushToken(e) {
      this.stack.push(e);
    }
    pushTokens(e) {
      this.stack.push(...e);
    }
    scanArgument(e) {
      var t, a, n;
      if (e) {
        if (this.consumeSpaces(), this.future().text !== "[")
          return null;
        t = this.popToken(), { tokens: n, end: a } = this.consumeArg([
          "]"
        ]);
      } else
        ({ tokens: n, start: t, end: a } = this.consumeArg());
      return this.pushToken(new c0("EOF", a.loc)), this.pushTokens(n), new c0("", m0.range(t, a));
    }
    consumeSpaces() {
      for (; ; ) {
        var e = this.future();
        if (e.text === " ")
          this.stack.pop();
        else
          break;
      }
    }
    consumeArg(e) {
      var t = [], a = e && e.length > 0;
      a || this.consumeSpaces();
      var n = this.future(), l, u = 0, h = 0;
      do {
        if (l = this.popToken(), t.push(l), l.text === "{")
          ++u;
        else if (l.text === "}") {
          if (--u, u === -1)
            throw new k("Extra }", l);
        } else if (l.text === "EOF")
          throw new k("Unexpected end of input in a macro argument, expected '" + (e && a ? e[h] : "}") + "'", l);
        if (e && a)
          if ((u === 0 || u === 1 && e[h] === "{") && l.text === e[h]) {
            if (++h, h === e.length) {
              t.splice(-h, h);
              break;
            }
          } else
            h = 0;
      } while (u !== 0 || a);
      return n.text === "{" && t[t.length - 1].text === "}" && (t.pop(), t.shift()), t.reverse(), {
        tokens: t,
        start: n,
        end: l
      };
    }
    consumeArgs(e, t) {
      if (t) {
        if (t.length !== e + 1)
          throw new k("The length of delimiters doesn't match the number of args!");
        for (var a = t[0], n = 0; n < a.length; n++) {
          var l = this.popToken();
          if (a[n] !== l.text)
            throw new k("Use of the macro doesn't match its definition", l);
        }
      }
      for (var u = [], h = 0; h < e; h++)
        u.push(this.consumeArg(t && t[h + 1]).tokens);
      return u;
    }
    countExpansion(e) {
      if (this.expansionCount += e, this.expansionCount > this.settings.maxExpand)
        throw new k("Too many expansions: infinite loop or need to increase maxExpand setting");
    }
    expandOnce(e) {
      var t = this.popToken(), a = t.text, n = t.noexpand ? null : this._getExpansion(a);
      if (n == null || e && n.unexpandable) {
        if (e && n == null && a[0] === "\\" && !this.isDefined(a))
          throw new k("Undefined control sequence: " + a);
        return this.pushToken(t), false;
      }
      this.countExpansion(1);
      var l = n.tokens, u = this.consumeArgs(n.numArgs, n.delimiters);
      if (n.numArgs) {
        l = l.slice();
        for (var h = l.length - 1; h >= 0; --h) {
          var c = l[h];
          if (c.text === "#") {
            if (h === 0)
              throw new k("Incomplete placeholder at end of macro body", c);
            if (c = l[--h], c.text === "#")
              l.splice(h + 1, 1);
            else if (/^[1-9]$/.test(c.text))
              l.splice(h, 2, ...u[+c.text - 1]);
            else
              throw new k("Not a valid argument number", c);
          }
        }
      }
      return this.pushTokens(l), l.length;
    }
    expandAfterFuture() {
      return this.expandOnce(), this.future();
    }
    expandNextToken() {
      for (; ; )
        if (this.expandOnce() === false) {
          var e = this.stack.pop();
          return e.treatAsRelax && (e.text = "\\relax"), e;
        }
    }
    expandMacro(e) {
      return this.macros.has(e) ? this.expandTokens([
        new c0(e)
      ]) : void 0;
    }
    expandTokens(e) {
      var t = [], a = this.stack.length;
      for (this.pushTokens(e); this.stack.length > a; )
        if (this.expandOnce(true) === false) {
          var n = this.stack.pop();
          n.treatAsRelax && (n.noexpand = false, n.treatAsRelax = false), t.push(n);
        }
      return this.countExpansion(t.length), t;
    }
    expandMacroAsText(e) {
      var t = this.expandMacro(e);
      return t && t.map((a) => a.text).join("");
    }
    _getExpansion(e) {
      var t = this.macros.get(e);
      if (t == null)
        return t;
      if (e.length === 1) {
        var a = this.lexer.catcodes[e];
        if (a != null && a !== 13)
          return;
      }
      var n = typeof t == "function" ? t(this) : t;
      if (typeof n == "string") {
        var l = 0;
        if (n.includes("#"))
          for (var u = n.replace(/##/g, ""); u.includes("#" + (l + 1)); )
            ++l;
        for (var h = new Mr(n, this.settings), c = [], p = h.lex(); p.text !== "EOF"; )
          c.push(p), p = h.lex();
        c.reverse();
        var g = {
          tokens: c,
          numArgs: l
        };
        return g;
      }
      return n;
    }
    isDefined(e) {
      return this.macros.has(e) || O0.hasOwnProperty(e) || Y.math.hasOwnProperty(e) || Y.text.hasOwnProperty(e) || k1.hasOwnProperty(e);
    }
    isExpandable(e) {
      var t = this.macros.get(e);
      return t != null ? typeof t == "string" || typeof t == "function" || !t.unexpandable : O0.hasOwnProperty(e) && !O0[e].primitive;
    }
  }
  var Br = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, Ae = Object.freeze({
    "\u208A": "+",
    "\u208B": "-",
    "\u208C": "=",
    "\u208D": "(",
    "\u208E": ")",
    "\u2080": "0",
    "\u2081": "1",
    "\u2082": "2",
    "\u2083": "3",
    "\u2084": "4",
    "\u2085": "5",
    "\u2086": "6",
    "\u2087": "7",
    "\u2088": "8",
    "\u2089": "9",
    "\u2090": "a",
    "\u2091": "e",
    "\u2095": "h",
    "\u1D62": "i",
    "\u2C7C": "j",
    "\u2096": "k",
    "\u2097": "l",
    "\u2098": "m",
    "\u2099": "n",
    "\u2092": "o",
    "\u209A": "p",
    "\u1D63": "r",
    "\u209B": "s",
    "\u209C": "t",
    "\u1D64": "u",
    "\u1D65": "v",
    "\u2093": "x",
    "\u1D66": "\u03B2",
    "\u1D67": "\u03B3",
    "\u1D68": "\u03C1",
    "\u1D69": "\u03D5",
    "\u1D6A": "\u03C7",
    "\u207A": "+",
    "\u207B": "-",
    "\u207C": "=",
    "\u207D": "(",
    "\u207E": ")",
    "\u2070": "0",
    "\xB9": "1",
    "\xB2": "2",
    "\xB3": "3",
    "\u2074": "4",
    "\u2075": "5",
    "\u2076": "6",
    "\u2077": "7",
    "\u2078": "8",
    "\u2079": "9",
    "\u1D2C": "A",
    "\u1D2E": "B",
    "\u1D30": "D",
    "\u1D31": "E",
    "\u1D33": "G",
    "\u1D34": "H",
    "\u1D35": "I",
    "\u1D36": "J",
    "\u1D37": "K",
    "\u1D38": "L",
    "\u1D39": "M",
    "\u1D3A": "N",
    "\u1D3C": "O",
    "\u1D3E": "P",
    "\u1D3F": "R",
    "\u1D40": "T",
    "\u1D41": "U",
    "\u2C7D": "V",
    "\u1D42": "W",
    "\u1D43": "a",
    "\u1D47": "b",
    "\u1D9C": "c",
    "\u1D48": "d",
    "\u1D49": "e",
    "\u1DA0": "f",
    "\u1D4D": "g",
    \u02B0: "h",
    "\u2071": "i",
    \u02B2: "j",
    "\u1D4F": "k",
    \u02E1: "l",
    "\u1D50": "m",
    \u207F: "n",
    "\u1D52": "o",
    "\u1D56": "p",
    \u02B3: "r",
    \u02E2: "s",
    "\u1D57": "t",
    "\u1D58": "u",
    "\u1D5B": "v",
    \u02B7: "w",
    \u02E3: "x",
    \u02B8: "y",
    "\u1DBB": "z",
    "\u1D5D": "\u03B2",
    "\u1D5E": "\u03B3",
    "\u1D5F": "\u03B4",
    "\u1D60": "\u03D5",
    "\u1D61": "\u03C7",
    "\u1DBF": "\u03B8"
  }), ht = {
    "\u0301": {
      text: "\\'",
      math: "\\acute"
    },
    "\u0300": {
      text: "\\`",
      math: "\\grave"
    },
    "\u0308": {
      text: '\\"',
      math: "\\ddot"
    },
    "\u0303": {
      text: "\\~",
      math: "\\tilde"
    },
    "\u0304": {
      text: "\\=",
      math: "\\bar"
    },
    "\u0306": {
      text: "\\u",
      math: "\\breve"
    },
    "\u030C": {
      text: "\\v",
      math: "\\check"
    },
    "\u0302": {
      text: "\\^",
      math: "\\hat"
    },
    "\u0307": {
      text: "\\.",
      math: "\\dot"
    },
    "\u030A": {
      text: "\\r",
      math: "\\mathring"
    },
    "\u030B": {
      text: "\\H"
    },
    "\u0327": {
      text: "\\c"
    }
  }, Dr = {
    \u00E1: "a\u0301",
    \u00E0: "a\u0300",
    \u00E4: "a\u0308",
    \u01DF: "a\u0308\u0304",
    \u00E3: "a\u0303",
    \u0101: "a\u0304",
    \u0103: "a\u0306",
    \u1EAF: "a\u0306\u0301",
    \u1EB1: "a\u0306\u0300",
    \u1EB5: "a\u0306\u0303",
    \u01CE: "a\u030C",
    \u00E2: "a\u0302",
    \u1EA5: "a\u0302\u0301",
    \u1EA7: "a\u0302\u0300",
    \u1EAB: "a\u0302\u0303",
    \u0227: "a\u0307",
    \u01E1: "a\u0307\u0304",
    \u00E5: "a\u030A",
    \u01FB: "a\u030A\u0301",
    \u1E03: "b\u0307",
    \u0107: "c\u0301",
    \u1E09: "c\u0327\u0301",
    \u010D: "c\u030C",
    \u0109: "c\u0302",
    \u010B: "c\u0307",
    \u00E7: "c\u0327",
    \u010F: "d\u030C",
    \u1E0B: "d\u0307",
    \u1E11: "d\u0327",
    \u00E9: "e\u0301",
    \u00E8: "e\u0300",
    \u00EB: "e\u0308",
    \u1EBD: "e\u0303",
    \u0113: "e\u0304",
    \u1E17: "e\u0304\u0301",
    \u1E15: "e\u0304\u0300",
    \u0115: "e\u0306",
    \u1E1D: "e\u0327\u0306",
    \u011B: "e\u030C",
    \u00EA: "e\u0302",
    \u1EBF: "e\u0302\u0301",
    \u1EC1: "e\u0302\u0300",
    \u1EC5: "e\u0302\u0303",
    \u0117: "e\u0307",
    \u0229: "e\u0327",
    \u1E1F: "f\u0307",
    \u01F5: "g\u0301",
    \u1E21: "g\u0304",
    \u011F: "g\u0306",
    \u01E7: "g\u030C",
    \u011D: "g\u0302",
    \u0121: "g\u0307",
    \u0123: "g\u0327",
    \u1E27: "h\u0308",
    \u021F: "h\u030C",
    \u0125: "h\u0302",
    \u1E23: "h\u0307",
    \u1E29: "h\u0327",
    \u00ED: "i\u0301",
    \u00EC: "i\u0300",
    \u00EF: "i\u0308",
    \u1E2F: "i\u0308\u0301",
    \u0129: "i\u0303",
    \u012B: "i\u0304",
    \u012D: "i\u0306",
    \u01D0: "i\u030C",
    \u00EE: "i\u0302",
    \u01F0: "j\u030C",
    \u0135: "j\u0302",
    \u1E31: "k\u0301",
    \u01E9: "k\u030C",
    \u0137: "k\u0327",
    \u013A: "l\u0301",
    \u013E: "l\u030C",
    \u013C: "l\u0327",
    \u1E3F: "m\u0301",
    \u1E41: "m\u0307",
    \u0144: "n\u0301",
    \u01F9: "n\u0300",
    \u00F1: "n\u0303",
    \u0148: "n\u030C",
    \u1E45: "n\u0307",
    \u0146: "n\u0327",
    \u00F3: "o\u0301",
    \u00F2: "o\u0300",
    \u00F6: "o\u0308",
    \u022B: "o\u0308\u0304",
    \u00F5: "o\u0303",
    \u1E4D: "o\u0303\u0301",
    \u1E4F: "o\u0303\u0308",
    \u022D: "o\u0303\u0304",
    \u014D: "o\u0304",
    \u1E53: "o\u0304\u0301",
    \u1E51: "o\u0304\u0300",
    \u014F: "o\u0306",
    \u01D2: "o\u030C",
    \u00F4: "o\u0302",
    \u1ED1: "o\u0302\u0301",
    \u1ED3: "o\u0302\u0300",
    \u1ED7: "o\u0302\u0303",
    \u022F: "o\u0307",
    \u0231: "o\u0307\u0304",
    \u0151: "o\u030B",
    \u1E55: "p\u0301",
    \u1E57: "p\u0307",
    \u0155: "r\u0301",
    \u0159: "r\u030C",
    \u1E59: "r\u0307",
    \u0157: "r\u0327",
    \u015B: "s\u0301",
    \u1E65: "s\u0301\u0307",
    \u0161: "s\u030C",
    \u1E67: "s\u030C\u0307",
    \u015D: "s\u0302",
    \u1E61: "s\u0307",
    \u015F: "s\u0327",
    \u1E97: "t\u0308",
    \u0165: "t\u030C",
    \u1E6B: "t\u0307",
    \u0163: "t\u0327",
    \u00FA: "u\u0301",
    \u00F9: "u\u0300",
    \u00FC: "u\u0308",
    \u01D8: "u\u0308\u0301",
    \u01DC: "u\u0308\u0300",
    \u01D6: "u\u0308\u0304",
    \u01DA: "u\u0308\u030C",
    \u0169: "u\u0303",
    \u1E79: "u\u0303\u0301",
    \u016B: "u\u0304",
    \u1E7B: "u\u0304\u0308",
    \u016D: "u\u0306",
    \u01D4: "u\u030C",
    \u00FB: "u\u0302",
    \u016F: "u\u030A",
    \u0171: "u\u030B",
    \u1E7D: "v\u0303",
    \u1E83: "w\u0301",
    \u1E81: "w\u0300",
    \u1E85: "w\u0308",
    \u0175: "w\u0302",
    \u1E87: "w\u0307",
    \u1E98: "w\u030A",
    \u1E8D: "x\u0308",
    \u1E8B: "x\u0307",
    \u00FD: "y\u0301",
    \u1EF3: "y\u0300",
    \u00FF: "y\u0308",
    \u1EF9: "y\u0303",
    \u0233: "y\u0304",
    \u0177: "y\u0302",
    \u1E8F: "y\u0307",
    \u1E99: "y\u030A",
    \u017A: "z\u0301",
    \u017E: "z\u030C",
    \u1E91: "z\u0302",
    \u017C: "z\u0307",
    \u00C1: "A\u0301",
    \u00C0: "A\u0300",
    \u00C4: "A\u0308",
    \u01DE: "A\u0308\u0304",
    \u00C3: "A\u0303",
    \u0100: "A\u0304",
    \u0102: "A\u0306",
    \u1EAE: "A\u0306\u0301",
    \u1EB0: "A\u0306\u0300",
    \u1EB4: "A\u0306\u0303",
    \u01CD: "A\u030C",
    \u00C2: "A\u0302",
    \u1EA4: "A\u0302\u0301",
    \u1EA6: "A\u0302\u0300",
    \u1EAA: "A\u0302\u0303",
    \u0226: "A\u0307",
    \u01E0: "A\u0307\u0304",
    \u00C5: "A\u030A",
    \u01FA: "A\u030A\u0301",
    \u1E02: "B\u0307",
    \u0106: "C\u0301",
    \u1E08: "C\u0327\u0301",
    \u010C: "C\u030C",
    \u0108: "C\u0302",
    \u010A: "C\u0307",
    \u00C7: "C\u0327",
    \u010E: "D\u030C",
    \u1E0A: "D\u0307",
    \u1E10: "D\u0327",
    \u00C9: "E\u0301",
    \u00C8: "E\u0300",
    \u00CB: "E\u0308",
    \u1EBC: "E\u0303",
    \u0112: "E\u0304",
    \u1E16: "E\u0304\u0301",
    \u1E14: "E\u0304\u0300",
    \u0114: "E\u0306",
    \u1E1C: "E\u0327\u0306",
    \u011A: "E\u030C",
    \u00CA: "E\u0302",
    \u1EBE: "E\u0302\u0301",
    \u1EC0: "E\u0302\u0300",
    \u1EC4: "E\u0302\u0303",
    \u0116: "E\u0307",
    \u0228: "E\u0327",
    \u1E1E: "F\u0307",
    \u01F4: "G\u0301",
    \u1E20: "G\u0304",
    \u011E: "G\u0306",
    \u01E6: "G\u030C",
    \u011C: "G\u0302",
    \u0120: "G\u0307",
    \u0122: "G\u0327",
    \u1E26: "H\u0308",
    \u021E: "H\u030C",
    \u0124: "H\u0302",
    \u1E22: "H\u0307",
    \u1E28: "H\u0327",
    \u00CD: "I\u0301",
    \u00CC: "I\u0300",
    \u00CF: "I\u0308",
    \u1E2E: "I\u0308\u0301",
    \u0128: "I\u0303",
    \u012A: "I\u0304",
    \u012C: "I\u0306",
    \u01CF: "I\u030C",
    \u00CE: "I\u0302",
    \u0130: "I\u0307",
    \u0134: "J\u0302",
    \u1E30: "K\u0301",
    \u01E8: "K\u030C",
    \u0136: "K\u0327",
    \u0139: "L\u0301",
    \u013D: "L\u030C",
    \u013B: "L\u0327",
    \u1E3E: "M\u0301",
    \u1E40: "M\u0307",
    \u0143: "N\u0301",
    \u01F8: "N\u0300",
    \u00D1: "N\u0303",
    \u0147: "N\u030C",
    \u1E44: "N\u0307",
    \u0145: "N\u0327",
    \u00D3: "O\u0301",
    \u00D2: "O\u0300",
    \u00D6: "O\u0308",
    \u022A: "O\u0308\u0304",
    \u00D5: "O\u0303",
    \u1E4C: "O\u0303\u0301",
    \u1E4E: "O\u0303\u0308",
    \u022C: "O\u0303\u0304",
    \u014C: "O\u0304",
    \u1E52: "O\u0304\u0301",
    \u1E50: "O\u0304\u0300",
    \u014E: "O\u0306",
    \u01D1: "O\u030C",
    \u00D4: "O\u0302",
    \u1ED0: "O\u0302\u0301",
    \u1ED2: "O\u0302\u0300",
    \u1ED6: "O\u0302\u0303",
    \u022E: "O\u0307",
    \u0230: "O\u0307\u0304",
    \u0150: "O\u030B",
    \u1E54: "P\u0301",
    \u1E56: "P\u0307",
    \u0154: "R\u0301",
    \u0158: "R\u030C",
    \u1E58: "R\u0307",
    \u0156: "R\u0327",
    \u015A: "S\u0301",
    \u1E64: "S\u0301\u0307",
    \u0160: "S\u030C",
    \u1E66: "S\u030C\u0307",
    \u015C: "S\u0302",
    \u1E60: "S\u0307",
    \u015E: "S\u0327",
    \u0164: "T\u030C",
    \u1E6A: "T\u0307",
    \u0162: "T\u0327",
    \u00DA: "U\u0301",
    \u00D9: "U\u0300",
    \u00DC: "U\u0308",
    \u01D7: "U\u0308\u0301",
    \u01DB: "U\u0308\u0300",
    \u01D5: "U\u0308\u0304",
    \u01D9: "U\u0308\u030C",
    \u0168: "U\u0303",
    \u1E78: "U\u0303\u0301",
    \u016A: "U\u0304",
    \u1E7A: "U\u0304\u0308",
    \u016C: "U\u0306",
    \u01D3: "U\u030C",
    \u00DB: "U\u0302",
    \u016E: "U\u030A",
    \u0170: "U\u030B",
    \u1E7C: "V\u0303",
    \u1E82: "W\u0301",
    \u1E80: "W\u0300",
    \u1E84: "W\u0308",
    \u0174: "W\u0302",
    \u1E86: "W\u0307",
    \u1E8C: "X\u0308",
    \u1E8A: "X\u0307",
    \u00DD: "Y\u0301",
    \u1EF2: "Y\u0300",
    \u0178: "Y\u0308",
    \u1EF8: "Y\u0303",
    \u0232: "Y\u0304",
    \u0176: "Y\u0302",
    \u1E8E: "Y\u0307",
    \u0179: "Z\u0301",
    \u017D: "Z\u030C",
    \u1E90: "Z\u0302",
    \u017B: "Z\u0307",
    \u03AC: "\u03B1\u0301",
    \u1F70: "\u03B1\u0300",
    \u1FB1: "\u03B1\u0304",
    \u1FB0: "\u03B1\u0306",
    \u03AD: "\u03B5\u0301",
    \u1F72: "\u03B5\u0300",
    \u03AE: "\u03B7\u0301",
    \u1F74: "\u03B7\u0300",
    \u03AF: "\u03B9\u0301",
    \u1F76: "\u03B9\u0300",
    \u03CA: "\u03B9\u0308",
    \u0390: "\u03B9\u0308\u0301",
    \u1FD2: "\u03B9\u0308\u0300",
    \u1FD1: "\u03B9\u0304",
    \u1FD0: "\u03B9\u0306",
    \u03CC: "\u03BF\u0301",
    \u1F78: "\u03BF\u0300",
    \u03CD: "\u03C5\u0301",
    \u1F7A: "\u03C5\u0300",
    \u03CB: "\u03C5\u0308",
    \u03B0: "\u03C5\u0308\u0301",
    \u1FE2: "\u03C5\u0308\u0300",
    \u1FE1: "\u03C5\u0304",
    \u1FE0: "\u03C5\u0306",
    \u03CE: "\u03C9\u0301",
    \u1F7C: "\u03C9\u0300",
    \u038E: "\u03A5\u0301",
    \u1FEA: "\u03A5\u0300",
    \u03AB: "\u03A5\u0308",
    \u1FE9: "\u03A5\u0304",
    \u1FE8: "\u03A5\u0306",
    \u038F: "\u03A9\u0301",
    \u1FFA: "\u03A9\u0300"
  };
  class Xe {
    constructor(e, t) {
      this.mode = "math", this.gullet = new v4(e, t, this.mode), this.settings = t, this.leftrightDepth = 0, this.nextToken = null;
    }
    expect(e, t) {
      if (t === void 0 && (t = true), this.fetch().text !== e)
        throw new k("Expected '" + e + "', got '" + this.fetch().text + "'", this.fetch());
      t && this.consume();
    }
    consume() {
      this.nextToken = null;
    }
    fetch() {
      return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken;
    }
    switchMode(e) {
      this.mode = e, this.gullet.switchMode(e);
    }
    parse() {
      this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
      try {
        var e = this.parseExpression(false);
        return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
      } finally {
        this.gullet.endGroups();
      }
    }
    subparse(e) {
      var t = this.nextToken;
      this.consume(), this.gullet.pushToken(new c0("}")), this.gullet.pushTokens(e);
      var a = this.parseExpression(false);
      return this.expect("}"), this.nextToken = t, a;
    }
    parseExpression(e, t) {
      for (var a = []; ; ) {
        this.mode === "math" && this.consumeSpaces();
        var n = this.fetch();
        if (Xe.endOfExpression.has(n.text) || t && n.text === t || e && O0[n.text] && O0[n.text].infix)
          break;
        var l = this.parseAtom(t);
        if (l) {
          if (l.type === "internal")
            continue;
        } else
          break;
        a.push(l);
      }
      return this.mode === "text" && this.formLigatures(a), this.handleInfixNodes(a);
    }
    handleInfixNodes(e) {
      for (var t = -1, a, n = 0; n < e.length; n++) {
        var l = e[n];
        if (l.type === "infix") {
          if (t !== -1)
            throw new k("only one infix operator per group", l.token);
          t = n, a = l.replaceWith;
        }
      }
      if (t !== -1 && a) {
        var u, h, c = e.slice(0, t), p = e.slice(t + 1);
        c.length === 1 && c[0].type === "ordgroup" ? u = c[0] : u = {
          type: "ordgroup",
          mode: this.mode,
          body: c
        }, p.length === 1 && p[0].type === "ordgroup" ? h = p[0] : h = {
          type: "ordgroup",
          mode: this.mode,
          body: p
        };
        var g;
        return a === "\\\\abovefrac" ? g = this.callFunction(a, [
          u,
          e[t],
          h
        ], []) : g = this.callFunction(a, [
          u,
          h
        ], []), [
          g
        ];
      } else
        return e;
    }
    handleSupSubscript(e) {
      var t = this.fetch(), a = t.text;
      this.consume(), this.consumeSpaces();
      var n;
      do {
        var l;
        n = this.parseGroup(e);
      } while (((l = n) == null ? void 0 : l.type) === "internal");
      if (!n)
        throw new k("Expected group after '" + a + "'", t);
      return n;
    }
    formatUnsupportedCmd(e) {
      for (var t = [], a = 0; a < e.length; a++)
        t.push({
          type: "textord",
          mode: "text",
          text: e[a]
        });
      var n = {
        type: "text",
        mode: this.mode,
        body: t
      }, l = {
        type: "color",
        mode: this.mode,
        color: this.settings.errorColor,
        body: [
          n
        ]
      };
      return l;
    }
    parseAtom(e) {
      var t = this.parseGroup("atom", e);
      if ((t == null ? void 0 : t.type) === "internal" || this.mode === "text")
        return t;
      for (var a, n; ; ) {
        this.consumeSpaces();
        var l = this.fetch();
        if (l.text === "\\limits" || l.text === "\\nolimits") {
          if (t && t.type === "op") {
            var u = l.text === "\\limits";
            t.limits = u, t.alwaysHandleSupSub = true;
          } else if (t && t.type === "operatorname")
            t.alwaysHandleSupSub && (t.limits = l.text === "\\limits");
          else
            throw new k("Limit controls must follow a math operator", l);
          this.consume();
        } else if (l.text === "^") {
          if (a)
            throw new k("Double superscript", l);
          a = this.handleSupSubscript("superscript");
        } else if (l.text === "_") {
          if (n)
            throw new k("Double subscript", l);
          n = this.handleSupSubscript("subscript");
        } else if (l.text === "'") {
          if (a)
            throw new k("Double superscript", l);
          var h = {
            type: "textord",
            mode: this.mode,
            text: "\\prime"
          }, c = [
            h
          ];
          for (this.consume(); this.fetch().text === "'"; )
            c.push(h), this.consume();
          this.fetch().text === "^" && c.push(this.handleSupSubscript("superscript")), a = {
            type: "ordgroup",
            mode: this.mode,
            body: c
          };
        } else if (Ae[l.text]) {
          var p = Br.test(l.text), g = [];
          for (g.push(new c0(Ae[l.text])), this.consume(); ; ) {
            var b = this.fetch().text;
            if (!Ae[b] || Br.test(b) !== p)
              break;
            g.unshift(new c0(Ae[b])), this.consume();
          }
          var y = this.subparse(g);
          p ? n = {
            type: "ordgroup",
            mode: "math",
            body: y
          } : a = {
            type: "ordgroup",
            mode: "math",
            body: y
          };
        } else
          break;
      }
      return a || n ? {
        type: "supsub",
        mode: this.mode,
        base: t,
        sup: a,
        sub: n
      } : t;
    }
    parseFunction(e, t) {
      var a = this.fetch(), n = a.text, l = O0[n];
      if (!l)
        return null;
      if (this.consume(), t && t !== "atom" && !l.allowedInArgument)
        throw new k("Got function '" + n + "' with no arguments" + (t ? " as " + t : ""), a);
      if (this.mode === "text" && !l.allowedInText)
        throw new k("Can't use function '" + n + "' in text mode", a);
      if (this.mode === "math" && l.allowedInMath === false)
        throw new k("Can't use function '" + n + "' in math mode", a);
      var { args: u, optArgs: h } = this.parseArguments(n, l);
      return this.callFunction(n, u, h, a, e);
    }
    callFunction(e, t, a, n, l) {
      var u = {
        funcName: e,
        parser: this,
        token: n,
        breakOnTokenText: l
      }, h = O0[e];
      if (h && h.handler)
        return h.handler(u, t, a);
      throw new k("No function handler for " + e);
    }
    parseArguments(e, t) {
      var a = t.numArgs + t.numOptionalArgs;
      if (a === 0)
        return {
          args: [],
          optArgs: []
        };
      for (var n = [], l = [], u = 0; u < a; u++) {
        var h = t.argTypes && t.argTypes[u], c = u < t.numOptionalArgs;
        ("primitive" in t && t.primitive && h == null || t.type === "sqrt" && u === 1 && l[0] == null) && (h = "primitive");
        var p = this.parseGroupOfType("argument to '" + e + "'", h, c);
        if (c)
          l.push(p);
        else if (p != null)
          n.push(p);
        else
          throw new k("Null argument, please report this as a bug");
      }
      return {
        args: n,
        optArgs: l
      };
    }
    parseGroupOfType(e, t, a) {
      switch (t) {
        case "color":
          return this.parseColorGroup(a);
        case "size":
          return this.parseSizeGroup(a);
        case "url":
          return this.parseUrlGroup(a);
        case "math":
        case "text":
          return this.parseArgumentGroup(a, t);
        case "hbox": {
          var n = this.parseArgumentGroup(a, "text");
          return n != null ? {
            type: "styling",
            mode: n.mode,
            body: [
              n
            ],
            style: "text"
          } : null;
        }
        case "raw": {
          var l = this.parseStringGroup("raw", a);
          return l != null ? {
            type: "raw",
            mode: "text",
            string: l.text
          } : null;
        }
        case "primitive": {
          if (a)
            throw new k("A primitive argument cannot be optional");
          var u = this.parseGroup(e);
          if (u == null)
            throw new k("Expected group as " + e, this.fetch());
          return u;
        }
        case "original":
        case null:
        case void 0:
          return this.parseArgumentGroup(a);
        default:
          throw new k("Unknown group type as " + e, this.fetch());
      }
    }
    consumeSpaces() {
      for (; this.fetch().text === " "; )
        this.consume();
    }
    parseStringGroup(e, t) {
      var a = this.gullet.scanArgument(t);
      if (a == null)
        return null;
      for (var n = "", l; (l = this.fetch()).text !== "EOF"; )
        n += l.text, this.consume();
      return this.consume(), a.text = n, a;
    }
    parseRegexGroup(e, t) {
      for (var a = this.fetch(), n = a, l = "", u; (u = this.fetch()).text !== "EOF" && e.test(l + u.text); )
        n = u, l += n.text, this.consume();
      if (l === "")
        throw new k("Invalid " + t + ": '" + a.text + "'", a);
      return a.range(n, l);
    }
    parseColorGroup(e) {
      var t = this.parseStringGroup("color", e);
      if (t == null)
        return null;
      var a = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(t.text);
      if (!a)
        throw new k("Invalid color: '" + t.text + "'", t);
      var n = a[0];
      return /^[0-9a-f]{6}$/i.test(n) && (n = "#" + n), {
        type: "color-token",
        mode: this.mode,
        color: n
      };
    }
    parseSizeGroup(e) {
      var t, a = false;
      if (this.gullet.consumeSpaces(), !e && this.gullet.future().text !== "{" ? t = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : t = this.parseStringGroup("size", e), !t)
        return null;
      !e && t.text.length === 0 && (t.text = "0pt", a = true);
      var n = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t.text);
      if (!n)
        throw new k("Invalid size: '" + t.text + "'", t);
      var l = {
        number: +(n[1] + n[2]),
        unit: n[3]
      };
      if (!qr(l))
        throw new k("Invalid unit: '" + l.unit + "'", t);
      return {
        type: "size",
        mode: this.mode,
        value: l,
        isBlank: a
      };
    }
    parseUrlGroup(e) {
      this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
      var t = this.parseStringGroup("url", e);
      if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), t == null)
        return null;
      var a = t.text.replace(/\\([#$%&~_^{}])/g, "$1");
      return {
        type: "url",
        mode: this.mode,
        url: a
      };
    }
    parseArgumentGroup(e, t) {
      var a = this.gullet.scanArgument(e);
      if (a == null)
        return null;
      var n = this.mode;
      t && this.switchMode(t), this.gullet.beginGroup();
      var l = this.parseExpression(false, "EOF");
      this.expect("EOF"), this.gullet.endGroup();
      var u = {
        type: "ordgroup",
        mode: this.mode,
        loc: a.loc,
        body: l
      };
      return t && this.switchMode(n), u;
    }
    parseGroup(e, t) {
      var a = this.fetch(), n = a.text, l;
      if (n === "{" || n === "\\begingroup") {
        this.consume();
        var u = n === "{" ? "}" : "\\endgroup";
        this.gullet.beginGroup();
        var h = this.parseExpression(false, u), c = this.fetch();
        this.expect(u), this.gullet.endGroup(), l = {
          type: "ordgroup",
          mode: this.mode,
          loc: m0.range(a, c),
          body: h,
          semisimple: n === "\\begingroup" || void 0
        };
      } else if (l = this.parseFunction(t, e) || this.parseSymbol(), l == null && n[0] === "\\" && !k1.hasOwnProperty(n)) {
        if (this.settings.throwOnError)
          throw new k("Undefined control sequence: " + n, a);
        l = this.formatUnsupportedCmd(n), this.consume();
      }
      return l;
    }
    formLigatures(e) {
      for (var t = e.length - 1, a = 0; a < t; ++a) {
        var n = e[a];
        if (n.type === "textord") {
          var l = n.text, u = e[a + 1];
          if (!(!u || u.type !== "textord")) {
            if (l === "-" && u.text === "-") {
              var h = e[a + 2];
              a + 1 < t && h && h.type === "textord" && h.text === "-" ? (e.splice(a, 3, {
                type: "textord",
                mode: "text",
                loc: m0.range(n, h),
                text: "---"
              }), t -= 2) : (e.splice(a, 2, {
                type: "textord",
                mode: "text",
                loc: m0.range(n, u),
                text: "--"
              }), t -= 1);
            }
            (l === "'" || l === "`") && u.text === l && (e.splice(a, 2, {
              type: "textord",
              mode: "text",
              loc: m0.range(n, u),
              text: l + l
            }), t -= 1);
          }
        }
      }
    }
    parseSymbol() {
      var e = this.fetch(), t = e.text;
      if (/^\\verb[^a-zA-Z]/.test(t)) {
        this.consume();
        var a = t.slice(5), n = a.charAt(0) === "*";
        if (n && (a = a.slice(1)), a.length < 2 || a.charAt(0) !== a.slice(-1))
          throw new k(`\\verb assertion failed --
                    please report what input caused this bug`);
        return a = a.slice(1, -1), {
          type: "verb",
          mode: "text",
          body: a,
          star: n
        };
      }
      Dr.hasOwnProperty(t[0]) && !Y[this.mode][t[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + t[0] + '" used in math mode', e), t = Dr[t[0]] + t.slice(1));
      var l = m4.exec(t);
      l && (t = t.substring(0, l.index), t === "i" ? t = "\u0131" : t === "j" && (t = "\u0237"));
      var u;
      if (Y[this.mode][t]) {
        this.settings.strict && this.mode === "math" && pt.includes(t) && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + t[0] + '" used in math mode', e);
        var h = Y[this.mode][t].group, c = m0.range(e), p;
        if (ca.hasOwnProperty(h)) {
          var g = h;
          p = {
            type: "atom",
            mode: this.mode,
            family: g,
            loc: c,
            text: t
          };
        } else
          p = {
            type: h,
            mode: this.mode,
            loc: c,
            text: t
          };
        u = p;
      } else if (t.charCodeAt(0) >= 128)
        this.settings.strict && (Cr(t.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + t[0] + '" used in math mode', e) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + t[0] + '"' + (" (" + t.charCodeAt(0) + ")"), e)), u = {
          type: "textord",
          mode: "text",
          loc: m0.range(e),
          text: t
        };
      else
        return null;
      if (this.consume(), l)
        for (var b = 0; b < l[0].length; b++) {
          var y = l[0][b];
          if (!ht[y])
            throw new k("Unknown accent ' " + y + "'", e);
          var x = ht[y][this.mode] || ht[y].text;
          if (!x)
            throw new k("Accent " + y + " unsupported in " + this.mode + " mode", e);
          u = {
            type: "accent",
            mode: this.mode,
            loc: m0.range(e),
            label: x,
            isStretchy: false,
            isShifty: true,
            base: u
          };
        }
      return u;
    }
  }
  Xe.endOfExpression = /* @__PURE__ */ new Set([
    "}",
    "\\endgroup",
    "\\end",
    "\\right",
    "&"
  ]);
  var Gt = function(e, t) {
    if (!(typeof e == "string" || e instanceof String))
      throw new TypeError("KaTeX can only parse string typed expression");
    var a = new Xe(e, t);
    delete a.gullet.macros.current["\\df@tag"];
    var n = a.parse();
    if (delete a.gullet.macros.current["\\current@color"], delete a.gullet.macros.current["\\color"], a.gullet.macros.get("\\df@tag")) {
      if (!t.displayMode)
        throw new k("\\tag works only in display equations");
      n = [
        {
          type: "tag",
          mode: "text",
          body: n,
          tag: a.subparse([
            new c0("\\df@tag")
          ])
        }
      ];
    }
    return n;
  }, z1 = function(e, t, a) {
    t.textContent = "";
    var n = Ut(e, a).toNode();
    t.appendChild(n);
  };
  typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), z1 = function() {
    throw new k("KaTeX doesn't work in quirks mode.");
  });
  var g4 = function(e, t) {
    var a = Ut(e, t).toMarkup();
    return a;
  }, b4 = function(e, t) {
    var a = new At(t);
    return Gt(e, a);
  }, M1 = function(e, t, a) {
    if (a.throwOnError || !(e instanceof k))
      throw e;
    var n = S([
      "katex-error"
    ], [
      new d0(t)
    ]);
    return n.setAttribute("title", e.toString()), n.setAttribute("style", "color:" + a.errorColor), n;
  }, Ut = function(e, t) {
    var a = new At(t);
    try {
      var n = Gt(e, a);
      return Ba(n, e, a);
    } catch (l) {
      return M1(l, e, a);
    }
  }, y4 = function(e, t) {
    var a = new At(t);
    try {
      var n = Gt(e, a);
      return Da(n, e, a);
    } catch (l) {
      return M1(l, e, a);
    }
  }, x4 = "0.16.38", w4 = {
    Span: ae,
    Anchor: Ne,
    SymbolNode: d0,
    SvgNode: B0,
    PathNode: L0,
    LineNode: ft
  }, S4 = {
    version: x4,
    render: z1,
    renderToString: g4,
    ParseError: k,
    SETTINGS_SCHEMA: mt,
    __parse: b4,
    __renderToDomTree: Ut,
    __renderToHTMLTree: y4,
    __setFontMetrics: ha,
    __defineSymbol: i,
    __defineFunction: B,
    __defineMacro: m,
    __domTree: w4
  };
  const k4 = /(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$)/g;
  function z4(r, e) {
    const t = r.startsWith("$$") && r.endsWith("$$"), a = !t && r.startsWith("$") && r.endsWith("$");
    if (!t && !a)
      return r;
    const n = t ? r.slice(2, -2) : r.slice(1, -1);
    try {
      const l = S4.renderToString(n, {
        output: "mathml",
        throwOnError: false,
        displayMode: t
      });
      return De.jsx("span", {
        dangerouslySetInnerHTML: {
          __html: l
        }
      }, e);
    } catch {
      return r;
    }
  }
  T4 = function({ children: r }) {
    if (typeof r != "string" || !r.includes("$"))
      return r;
    const e = r.split(k4);
    return e.length === 1 ? r : De.jsx("span", {
      children: e.map(z4)
    });
  };
});
export {
  T4 as L,
  A4 as P,
  __tla
};
