import { b as v, P as o, d as f, i as D, g as y } from "./chunk-9bfc7485.js";
var h = (l = "") => {
  const p = v();
  let t, r = [];
  const a = y(), i = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), m = (e, g) => {
    switch (e.status) {
      case "undeliverable":
        r.some((s) => s.message.messageID === e.message.messageID) || (r = [...r, { message: e.message, resolvedDestination: e.resolvedDestination }]);
        return;
      case "deliverable":
        r = r.reduce((s, n) => n.resolvedDestination === e.deliverableTo ? (o.toBackground(g, { type: "deliver", message: n.message }), s) : [...s, n], []);
        return;
      case "delivered":
        e.receipt.message.messageType === "message" && a.add(e.receipt);
        return;
      case "incoming":
        e.message.messageType === "reply" && a.remove(e.message.messageID), i.forEach((s) => s(e.message, g));
        return;
      case "terminated": {
        const s = a.entries().filter((n) => e.fingerprint === n.to);
        a.remove(s), s.forEach(({ message: n }) => c.forEach((u) => u(n)));
      }
    }
  }, d = () => {
    t = f.runtime.connect({ name: D({ endpointName: l, fingerprint: p }) }), t.onMessage.addListener(m), t.onDisconnect.addListener(d), o.toBackground(t, { type: "sync", pendingResponses: a.entries(), pendingDeliveries: [...new Set(r.map(({ resolvedDestination: e }) => e))] });
  };
  return d(), { onFailure(e) {
    c.add(e);
  }, onMessage(e) {
    i.add(e);
  }, postMessage(e) {
    o.toBackground(t, { type: "deliver", message: e });
  } };
};
export {
  h as c
};
