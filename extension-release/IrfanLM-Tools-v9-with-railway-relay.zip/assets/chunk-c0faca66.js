import { j as r, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { M as t, __tla as __tla_1 } from "./chunk-e0aab7c8.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
let d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  d = function({ content: e }) {
    return (e == null ? void 0 : e.markdown) ? r.jsx("div", {
      className: "bg-white dark:bg-slate-900 shadow-sm rounded-lg p-4",
      children: r.jsx(t, {
        text: e.markdown
      })
    }) : r.jsx("p", {
      className: "text-xs text-gray-500 dark:text-slate-400",
      children: "No report content available."
    });
  };
});
export {
  __tla,
  d as default
};
