const Tt = (r) => new Promise((t, e) => {
  try {
    chrome.storage.local.get([r], function(n) {
      if (chrome.runtime.lastError) {
        e(new Error(chrome.runtime.lastError.message));
        return;
      }
      t(n[r]);
    });
  } catch (n) {
    e(n);
  }
}), At = (r, t) => new Promise((e, n) => {
  try {
    chrome.storage.local.set({ [r]: t }, function() {
      if (chrome.runtime.lastError) {
        n(new Error(chrome.runtime.lastError.message));
        return;
      }
      e();
    });
  } catch (s) {
    n(s);
  }
}), _t = (r) => new Promise((t, e) => {
  try {
    chrome.storage.local.remove([r], function() {
      if (chrome.runtime.lastError) {
        e(new Error(chrome.runtime.lastError.message));
        return;
      }
      t();
    });
  } catch (n) {
    e(n);
  }
}), St = (r) => new Promise((t, e) => {
  try {
    chrome.storage.local.get(r, function(n) {
      if (chrome.runtime.lastError) {
        e(new Error(chrome.runtime.lastError.message));
        return;
      }
      t(n);
    });
  } catch (n) {
    e(n);
  }
}), v = { get: Tt, set: At, remove: _t, getKeys: St }, Wt = "IrfanLM Tools", Ot = "https://www.nlmtools.com", Kt = (r) => `${Ot}/pricing?ref=ext-${r || "nudge"}`, $t = "NLMTools.com", Xt = "https://polar.sh/nlmtools/portal", qt = "https://notebooklm-tools.userjot.com", _ = "YT_NOTEBOOKLM_TOOLS", jt = `${_}_POWER_BUTTON`, Jt = `${_}_LICENSE_CODE`, Qt = `${_}_ME`, zt = `${_}_UPGRADE_NUDGE`, Zt = `${_}_LIFETIME_USAGE`, te = `${_}_MILESTONES_SHOWN`, ee = [50, 100, 250], ne = "https://api.nlmtools.com", re = ["Multi-type Studio generation", "Clean, banner-free experience", "Early access to new features", "Priority feature requests", "Support the tool you rely on"], se = { page_view: { threshold: 5 }, feature_used: { threshold: 3 } }, le = 4, oe = "show-upgrade-nudge", nt = `${_}_CONFIG_NLM`, rt = `${_}_CONFIG_NLM_ACCOUNTS`, ae = `${_}_NOTEBOOKLM_PROJECTS`, ce = `${_}_INTERFACE_LANGUAGE`, ue = `${_}_OUTPUT_LANGUAGE`, ie = `${_}_SWITCHER_POSITION`, Ee = `${_}_SWITCHER_VISIBLE`, Te = `${_}_SWITCHER_ORIENTATION`, Ae = `${_}_SWITCHER_COLLAPSED`, _e = `${_}_FAVORITE_LANGUAGES`, Se = `${_}_FAVORITE_OUTPUT_LANGUAGES`, Oe = `${_}_TAGS_VISIBLE_HOME`, Ie = `${_}_TAGS_VISIBLE_DETAIL`, he = `${_}_DETAIL_OUTPUTS_VISIBLE`, pe = `${_}_DETAIL_ACTIONS_VISIBLE`, de = `${_}_DETAIL_LOGO_VISIBLE`, fe = { GENERATE: "generate", DUPLICATES: "duplicates" }, Re = `${_}_PENDING_CONTEXT_ACTIONS_MAP`, Ce = `${_}_NOTEBOOK_TAGS`, De = `${_}_SOURCE_FOLDERS`, Le = 100, Ne = 500, ge = 50, me = 5e3, ye = `${_}_NOTEBOOK_LABEL_MODE`, Ue = 5, Pe = `${_}_LABEL_SCOPE_LEGEND_SEEN`, It = `${_}_TAB_BEHAVIOR_AFTER_IMPORT`, ht = `${_}_OPEN_TABS_IN_BACKGROUND`, be = `${_}_ALL_TAGS_BAR_VISIBLE`, Ge = `${_}_ALL_TAGS_BAR_ONBOARDING_SEEN`, we = `${_}_ARTIFACT_STATS_CACHE`, Me = `${_}_SOURCE_FRESHNESS_CACHE`, Fe = `${_}_THEME_MODE`, Be = `${_}_PROMPTS`, ve = `${_}_PROMPTS_USAGE`, He = { MAX_PROMPTS: 100, CATEGORY_MAX_LENGTH: 50, TITLE_MAX_LENGTH: 100, TEXT_MAX_LENGTH: 1e4 }, Ve = `${_}_NOTEBOOK_DETAIL_ACTIVE_TAB`, xe = `${_}_LAST_BACKUP_DATE`, q = 3e4, ke = '.ql-editor[contenteditable="true"],.message-container textarea,.cdk-overlay-pane textarea,textarea', st = (r) => i(r, 0) ? (r[0] || 0) + (r[1] || 0) / 1e9 : null;
function pt(r) {
  const t = o(r, 6);
  return t ? { audioUrl: o(t, 2), downloadUrl: o(t, 3), urls: i(o(t, 5)) ? o(t, 5).map((e) => ({ url: e[0], type: e[1], format: e[2] })) : [], duration: st(o(t, 6)) } : null;
}
function dt(r) {
  const t = o(r, 7), e = typeof t == "string" ? t : Array.isArray(t) ? t[0] : null;
  return typeof e == "string" && e.length > 0 ? { markdown: e } : null;
}
function ft(r) {
  const t = o(r, 8);
  return t ? { videoUrl: o(t, 1), downloadUrl: o(t, 3), formats: i(o(t, 4)) ? o(t, 4).map((e) => ({ url: e[0], type: e[1], mimeType: e[2] })) : [], duration: st(o(t, 5)) } : null;
}
function Rt(r) {
  var _a;
  const t = o(r, 9);
  return t ? { variant: (_a = t == null ? void 0 : t[1]) == null ? void 0 : _a[0], content: (t == null ? void 0 : t[0]) || null } : null;
}
function Ct(r) {
  var _a, _b, _c, _d;
  const t = o(r, 14);
  if (!t)
    return null;
  const e = (_a = t == null ? void 0 : t[2]) == null ? void 0 : _a[0];
  return { title: o(t, 1), imageUrl: ((_b = e == null ? void 0 : e[1]) == null ? void 0 : _b[0]) || null, width: ((_c = e == null ? void 0 : e[1]) == null ? void 0 : _c[1]) || null, height: ((_d = e == null ? void 0 : e[1]) == null ? void 0 : _d[2]) || null, description: (e == null ? void 0 : e[2]) || null, text: (e == null ? void 0 : e[3]) || null };
}
function Dt(r) {
  const t = o(r, 16);
  return t ? { title: o(t, 1), slides: i(o(t, 2)) ? o(t, 2).map((e) => {
    var _a, _b, _c;
    return { imageUrl: ((_a = e == null ? void 0 : e[0]) == null ? void 0 : _a[0]) || null, width: ((_b = e == null ? void 0 : e[0]) == null ? void 0 : _b[1]) || null, height: ((_c = e == null ? void 0 : e[0]) == null ? void 0 : _c[2]) || null, description: (e == null ? void 0 : e[1]) || null, text: (e == null ? void 0 : e[2]) || null };
  }) : [], pdfUrl: o(t, 3), pptxUrl: o(t, 4) } : null;
}
function lt(r) {
  return typeof r == "string" ? r : Array.isArray(r) ? typeof r[0] == "string" ? r[0] : r.map(lt).join("") : "";
}
function j(r) {
  return i(r) ? r.map((t) => lt(t)).join("") : "";
}
function Lt() {
  return null;
}
function Nt(r) {
  var _a, _b, _c, _d;
  const t = o(r, 18);
  if (!t)
    return null;
  try {
    const e = (_d = (_c = (_b = (_a = t == null ? void 0 : t[0]) == null ? void 0 : _a[0]) == null ? void 0 : _b[0]) == null ? void 0 : _c[0]) == null ? void 0 : _d[4];
    if (!e)
      return { headers: [], rows: [] };
    const n = e[0], s = e[1], l = e[2];
    if (!i(l, 1))
      return { headers: [], rows: [] };
    const c = l[0], u = l[1], T = Array.isArray(c) && typeof c[0] == "number" ? c[2] : c, E = Array.isArray(u) && typeof u[0] == "number" ? u[2] : u, I = i(T) ? T.map((C) => j(i(C) ? C : [C])) : [], U = [];
    if (i(E)) {
      const C = s || I.length || 1;
      for (let D = 0; D < E.length; D += C) {
        const X = E.slice(D, D + C).map((R) => j(i(R) ? R : [R]));
        U.push(X);
      }
    }
    return { headers: I, rows: U, numRows: n, numCols: s };
  } catch {
    return { headers: [], rows: [] };
  }
}
function Ye(r) {
  var _a, _b;
  try {
    const t = (_b = (_a = r == null ? void 0 : r[0]) == null ? void 0 : _a[9]) == null ? void 0 : _b[0];
    if (typeof t != "string")
      return null;
    const e = t.match(/data-app-data="([^"]*)"/);
    if (!e)
      return null;
    const n = e[1].replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#39;/g, "'").replace(/&#x27;/g, "'");
    return JSON.parse(n);
  } catch {
    return null;
  }
}
function gt(r, t) {
  switch (r) {
    case a.AUDIO:
      return pt(t);
    case a.REPORT:
      return dt(t);
    case a.VIDEO:
      return ft(t);
    case a.QUIZ_OR_FLASHCARDS:
      return Rt(t);
    case a.INFOGRAPHIC:
      return Ct(t);
    case a.SLIDE_DECK:
      return Dt(t);
    case a.MIND_MAP:
      return Lt();
    case a.DATA_TABLE:
      return Nt(t);
    default:
      return null;
  }
}
const We = { OWNER: 1, EDITOR: 2, VIEWER: 3 }, h = { GOOGLE_DOCS: 1, GOOGLE_SLIDES: 2, PDF: 3, PASTED_TEXT: 4, WEB_PAGE: 5, MARKDOWN: 8, YOUTUBE: 9, MEDIA: 10, DOCX: 11, IMAGE: 13, DRIVE_FILE: 14, CSV: 16 }, A = { UNSPECIFIED: "SOURCE_TYPE_UNSPECIFIED", URL: "SOURCE_TYPE_URL", TEXT: "SOURCE_TYPE_TEXT", WEB_PAGE: "SOURCE_TYPE_WEB_PAGE", YOUTUBE_VIDEO: "SOURCE_TYPE_YOUTUBE_VIDEO", GOOGLE_DRIVE: "SOURCE_TYPE_GOOGLE_DRIVE", GOOGLE_DOC: "SOURCE_TYPE_GOOGLE_DOC", GOOGLE_SLIDES: "SOURCE_TYPE_GOOGLE_SLIDES", GOOGLE_SHEETS: "SOURCE_TYPE_GOOGLE_SHEETS", PDF: "SOURCE_TYPE_PDF", PDF_FROM_DRIVE: "SOURCE_TYPE_PDF_FROM_DRIVE", TEXT_NOTE: "SOURCE_TYPE_TEXT_NOTE", VIDEO_FILE: "SOURCE_TYPE_VIDEO_FILE", IMAGE: "SOURCE_TYPE_IMAGE", MIND_MAP_NOTE: "SOURCE_TYPE_MIND_MAP_NOTE" }, J = { [A.UNSPECIFIED]: "Unknown", [A.URL]: "Web Page", [A.TEXT]: "Text Document", [A.WEB_PAGE]: "Web Page", [A.YOUTUBE_VIDEO]: "YouTube Video", [A.GOOGLE_DRIVE]: "Google Drive", [A.GOOGLE_DOC]: "Google Docs", [A.GOOGLE_SLIDES]: "Google Slides", [A.GOOGLE_SHEETS]: "Google Sheets", [A.PDF]: "PDF", [A.PDF_FROM_DRIVE]: "PDF (Drive)", [A.TEXT_NOTE]: "Note", [A.VIDEO_FILE]: "Video", [A.IMAGE]: "Image", [A.MIND_MAP_NOTE]: "Mind Map" }, mt = { "application/pdf": A.PDF_FROM_DRIVE, "application/vnd.google-apps.spreadsheet": A.GOOGLE_SHEETS, "application/vnd.google-apps.document": A.GOOGLE_DOC, "application/vnd.google-apps.presentation": A.GOOGLE_SLIDES }, ot = [A.GOOGLE_DRIVE, A.GOOGLE_DOC, A.GOOGLE_SLIDES, A.GOOGLE_SHEETS, A.PDF_FROM_DRIVE], Ke = (r) => {
  const t = [];
  for (const e of r || [])
    for (const n of e.sources || [])
      ot.includes(n.sourceType) && t.push({ notebookId: e.id, notebookTitle: e.title, sourceId: n.id, title: n.title });
  return t;
}, $e = (r) => (r || []).some((t) => (t.sources || []).some((e) => ot.includes(e.sourceType))), Xe = (r) => {
  var _a;
  const t = (_a = r == null ? void 0 : r[0]) == null ? void 0 : _a[1];
  return t === true ? "fresh" : t === false ? "stale" : null;
}, a = { AUDIO: 1, REPORT: 2, VIDEO: 3, QUIZ_OR_FLASHCARDS: 4, MIND_MAP: 5, INFOGRAPHIC: 7, SLIDE_DECK: 8, DATA_TABLE: 9, QUIZ: 10, FLASHCARDS: 11, NOTE: 12 }, x = { [a.AUDIO]: "Audio", [a.REPORT]: "Report", [a.VIDEO]: "Video", [a.QUIZ_OR_FLASHCARDS]: "Quiz/Flashcards", [a.QUIZ]: "Quiz", [a.FLASHCARDS]: "Flashcards", [a.MIND_MAP]: "Mind Map", [a.INFOGRAPHIC]: "Infographic", [a.SLIDE_DECK]: "Slide Deck", [a.DATA_TABLE]: "Data Table", [a.NOTE]: "Note" }, yt = { 1: a.FLASHCARDS, 2: a.QUIZ, 4: a.MIND_MAP }, K = { PROCESSING: 1, PENDING: 2, READY: 3, FAILED: 4 }, i = (r, t = 0) => Array.isArray(r) && r.length > t, L = (r) => {
  if (!i(r, 1))
    return null;
  const [t, e = 0] = r;
  return typeof t != "number" ? null : new Date(t * 1e3 + (e ?? 0) / 1e6).toISOString();
}, o = (r, t, e = null) => i(r) && r.length > t ? r[t] : e;
function at(r, t = 0) {
  if (!r || t > 20)
    return null;
  if (typeof r == "string")
    return { label: r, children: [] };
  const e = r.label || r.name || r.title || r.text || String(r[0] || ""), n = r.children || r.nodes || r.items || [];
  return { label: e, children: Array.isArray(n) ? n.map((s) => at(s, t + 1)).filter(Boolean) : [] };
}
class qe {
  static parseNotebooks(t) {
    if (!i(t))
      return [];
    const e = i(t[0]) ? t[0] : t;
    return i(e) ? e.map((n) => this.parseNotebook(n)).filter(Boolean) : [];
  }
  static parseNotebook(t) {
    if (!i(t, 4))
      return null;
    const [e, n, s, l, , c] = t;
    return s ? { id: s, title: e === "" ? "Untitled notebook" : e, emoji: l || "", sources: this.parseSources(n), ...this.parseProjectMetadata(c) } : null;
  }
  static parseSources(t) {
    return i(t) ? t.map((e) => this.parseSource(e)).filter(Boolean) : [];
  }
  static parseSource(t) {
    if (!i(t, 3))
      return null;
    const [e, n, s] = t, l = o(e, 0);
    return !l || !n ? null : { id: l, title: n, ...this.parseSourceMetadata(s) };
  }
  static parseSourceMetadata(t) {
    const e = { sourceType: A.UNSPECIFIED, sourceTypeEnum: null, updatedAt: null, createdAt: null, url: null, youtubeVideoId: null, authorName: null, driveFileId: null, driveResourceKey: null, mimeType: null };
    if (!i(t))
      return e;
    try {
      e.updatedAt = L(o(t, 2)), e.createdAt = L(o(o(t, 3), 1)), this.extractSourceInfo(t, e);
    } catch (n) {
      console.warn("Error parsing source metadata:", n);
    }
    return e;
  }
  static parseSourceContent(t) {
    if (!i(t))
      return null;
    const e = o(t, 0);
    if (!i(e))
      return null;
    const n = o(e, 1) || "Untitled Source", s = o(o(e, 0), 0), l = o(e, 2), c = o(l, 4), u = o(t, 3);
    if (!i(u))
      return { id: s, title: n, content: "", images: null };
    switch (c) {
      case h.GOOGLE_SLIDES:
        return this.parseSlideSourceContent(s, n, u);
      case h.DRIVE_FILE: {
        const T = o(l, 9);
        return (i(T) ? o(T, 2) : null) === "application/vnd.google-apps.spreadsheet" ? this.parseSheetsSourceContent(s, n, u) : this.parseTextSourceContent(s, n, u);
      }
      default:
        return this.parseTextSourceContent(s, n, u);
    }
  }
  static parseSlideSourceContent(t, e, n) {
    const s = this.extractSlideImages(n);
    return { id: t, title: e, content: null, images: s.length > 0 ? s : null };
  }
  static parseSheetsSourceContent(t, e, n) {
    const s = this.extractSheetsContent(n);
    return { id: t, title: e, content: s || "", images: null };
  }
  static parseTextSourceContent(t, e, n) {
    const s = this.extractTextContent(n);
    return { id: t, title: e, content: s || "", images: null };
  }
  static extractTextContent(t) {
    const e = o(o(t, 0), 0);
    return i(e) && e.map((l) => {
      const c = o(l, 2), u = i(c) ? o(c, 0) : [];
      return i(u) ? u.map((T) => {
        const E = o(T, 2);
        return i(E) ? o(E, 0) : "";
      }).join("") : "";
    }).filter(Boolean).reduce((l, c) => l ? l.endsWith(`
`) || c.startsWith(`
`) ? l + c : l + `
` + c : c, "") || null;
  }
  static extractSlideImages(t) {
    const e = [];
    try {
      const n = o(o(t, 0), 0);
      if (!i(n))
        return e;
      for (const s of n) {
        const l = o(s, 5);
        if (i(l)) {
          const c = o(l, 0);
          c && typeof c == "string" && c.startsWith("https://") && e.push({ url: c, id: o(l, 2) });
        }
      }
    } catch (n) {
      console.warn("Error extracting slide images:", n);
    }
    return e;
  }
  static extractSheetsContent(t) {
    try {
      const e = o(o(t, 0), 0);
      if (!i(e))
        return null;
      const n = [];
      for (const s of e) {
        const l = o(s, 4);
        if (!i(l) || l.length < 3)
          continue;
        const c = o(l, 2);
        if (i(c))
          for (const u of c) {
            const T = this.extractNestedText(u);
            T && n.push(T);
          }
      }
      return n.length > 0 ? n.join(`
`) : null;
    } catch (e) {
      return console.warn("Error extracting sheets content:", e), null;
    }
  }
  static extractNestedText(t, e = 0) {
    if (e > 20)
      return null;
    if (typeof t == "string")
      return t;
    if (!i(t))
      return null;
    for (const n of t) {
      const s = this.extractNestedText(n, e + 1);
      if (s)
        return s;
    }
    return null;
  }
  static extractSourceInfo(t, e) {
    const n = o(t, 4);
    switch (e.sourceTypeEnum = n, n) {
      case h.GOOGLE_DOCS:
        e.sourceType = A.GOOGLE_DOC, this.extractDriveInfo(t, e);
        break;
      case h.GOOGLE_SLIDES:
        e.sourceType = A.GOOGLE_SLIDES, this.extractDriveInfo(t, e);
        break;
      case h.PDF:
        e.sourceType = A.PDF;
        const s = o(t, 7);
        i(s) && (e.url = o(s, 0));
        break;
      case h.PASTED_TEXT:
        e.sourceType = A.TEXT;
        break;
      case h.WEB_PAGE:
        this.parseWebPageSource(t, e);
        break;
      case h.MARKDOWN:
        e.sourceType = A.TEXT;
        break;
      case h.YOUTUBE:
        this.parseYouTubeSource(t, e);
        break;
      case h.MEDIA:
        e.sourceType = A.VIDEO_FILE;
        break;
      case h.DOCX:
        e.sourceType = A.TEXT;
        break;
      case h.IMAGE:
        e.sourceType = A.IMAGE;
        break;
      case h.DRIVE_FILE:
        this.parseDriveFileSource(t, e);
        break;
      case h.CSV:
        e.sourceType = A.TEXT;
        break;
      default:
        e.sourceType = A.UNSPECIFIED;
    }
  }
  static extractDriveInfo(t, e) {
    const n = o(t, 0);
    i(n) && (e.driveFileId = o(n, 0), e.driveResourceKey = o(n, 1));
  }
  static parseDriveFileSource(t, e) {
    const n = o(t, 9);
    i(n) ? (e.driveFileId = o(n, 0), e.mimeType = o(n, 2), e.sourceType = mt[e.mimeType] || A.GOOGLE_DRIVE) : e.sourceType = A.GOOGLE_DRIVE;
  }
  static parseWebPageSource(t, e) {
    e.sourceType = A.WEB_PAGE;
    const n = o(t, 7);
    i(n) && (e.url = o(n, 0));
  }
  static parseYouTubeSource(t, e) {
    e.sourceType = A.YOUTUBE_VIDEO;
    const n = o(t, 5);
    i(n) && (e.url = o(n, 0), e.youtubeVideoId = o(n, 1), e.authorName = o(n, 2));
  }
  static parseProjectMetadata(t) {
    const e = { permissionCode: null, createdAt: null, updatedAt: null };
    if (!i(t))
      return e;
    try {
      e.permissionCode = o(t, 0), e.updatedAt = L(o(t, 5)), e.createdAt = L(o(t, 8));
    } catch (n) {
      console.warn("Error parsing project metadata:", n);
    }
    return e;
  }
  static getSourceTypeLabel(t) {
    return J[t] || J[A.UNSPECIFIED];
  }
  static parseArtifacts(t) {
    if (!i(t))
      return [];
    const e = i(t[0]) ? t[0] : t;
    return i(e) ? e.map((n) => this.parseArtifact(n)).filter(Boolean) : [];
  }
  static parseArtifact(t) {
    var _a;
    if (!i(t, 2))
      return null;
    const e = o(t, 0), n = o(t, 1), s = o(t, 2), l = o(t, 3), c = o(t, 4);
    if (!e)
      return null;
    const u = { id: e, title: n || "Untitled", type: s, typeLabel: x[s] || "Unknown", sourceIds: this.extractSourceIds(l), status: c, isReady: c === K.READY, isProcessing: c === K.PROCESSING || c === K.PENDING };
    if (u.parsedContent = gt(s, t), s === a.QUIZ_OR_FLASHCARDS && ((_a = u.parsedContent) == null ? void 0 : _a.variant)) {
      const E = yt[u.parsedContent.variant];
      E && (u.type = E), u.typeLabel = x[u.type] || "Unknown";
    }
    s === a.AUDIO && Object.assign(u, this.parseAudioArtifact(t));
    const T = this.parseArtifactTimestamps(t);
    return Object.assign(u, T), u;
  }
  static extractSourceIds(t) {
    if (!i(t))
      return [];
    const e = (s) => {
      if (typeof s == "string")
        return s || null;
      if (Array.isArray(s))
        for (const l of s) {
          const c = e(l);
          if (c)
            return c;
        }
      return null;
    }, n = [];
    for (const s of t) {
      const l = e(s);
      l && n.push(l);
    }
    return n;
  }
  static parseAudioArtifact(t) {
    const e = o(t, 6);
    if (!e)
      return {};
    const n = o(e, 5), s = o(e, 6);
    return { audioUrl: o(e, 2), downloadUrl: o(e, 3), urls: i(n) ? n.map((l) => ({ url: l[0], type: l[1], format: l[2] })) : [], duration: i(s, 1) ? s[0] + (s[1] || 0) / 1e9 : null };
  }
  static countArtifactsByType(t) {
    const e = { total: 0 };
    for (const n of t) {
      if (!n.isReady)
        continue;
      e.total++;
      const s = n.type;
      e[s] = (e[s] || 0) + 1;
    }
    return e;
  }
  static parseArtifactTimestamps(t) {
    const e = [9, 10, 11, 12];
    let n = null, s = null;
    for (const l of e) {
      const c = o(t, l);
      if (i(c, 1)) {
        const u = L(c);
        u && (n ? s || (s = u) : n = u);
      }
    }
    return { createdAt: n, updatedAt: s };
  }
  static parseNote(t) {
    if (!i(t, 1))
      return null;
    const e = o(t, 0);
    if (!e || o(t, 2) === 2)
      return null;
    const s = o(t, 1);
    if (i(s)) {
      const l = o(s, 2);
      let c = null, u = null;
      return i(l) && (c = L(o(l, 1)) || L(o(l, 0)), u = L(o(l, 2)) || c), { id: e, title: o(s, 4) || "", content: o(s, 1) || "", createdAt: c, updatedAt: u };
    }
    return typeof s == "string" ? { id: e, title: "", content: s, createdAt: null, updatedAt: null } : null;
  }
  static isMindMapContent(t) {
    if (!t || typeof t != "string")
      return false;
    try {
      const e = JSON.parse(t);
      return typeof e == "object" && e !== null && ("children" in e || "nodes" in e);
    } catch {
      return false;
    }
  }
  static parseNotesAsArtifacts(t, e = null) {
    if (!i(t))
      return [];
    const n = i(t[0]) ? t[0] : t;
    if (!i(n))
      return [];
    const s = (l, c) => {
      if (!c || c.size === 0)
        return [];
      const u = [], T = /* @__PURE__ */ new Set(), E = (I) => {
        if (typeof I == "string")
          c.has(I) && !T.has(I) && (T.add(I), u.push(I));
        else if (Array.isArray(I))
          for (const U of I)
            E(U);
      };
      return E(l), u;
    };
    return n.map((l) => {
      const c = this.parseNote(l);
      if (!c)
        return null;
      const u = s(l, e);
      return { note: c, sourceIds: u };
    }).filter(Boolean).map(({ note: l, sourceIds: c }) => {
      if (this.isMindMapContent(l.content)) {
        let T = null;
        try {
          const E = JSON.parse(l.content);
          T = { tree: at(E) };
        } catch {
          T = null;
        }
        return { id: l.id, title: l.title || "Untitled Mind Map", type: a.MIND_MAP, typeLabel: x[a.MIND_MAP], sourceIds: c, isReady: true, isProcessing: false, isNote: true, parsedContent: T, rawContent: l.content, createdAt: l.createdAt || null, updatedAt: l.updatedAt || null };
      }
      return { id: l.id, title: l.title || "Untitled Note", type: a.NOTE, typeLabel: x[a.NOTE], sourceIds: c, isReady: true, isProcessing: false, isNote: true, parsedContent: { text: l.content }, rawContent: l.content, createdAt: l.createdAt || null, updatedAt: l.updatedAt || null };
    });
  }
}
const Ut = /^[a-z]{2,3}(-[A-Za-z0-9]+)*$/, je = (r) => {
  var _a;
  return (((_a = (r == null ? void 0 : r[0]) || r) == null ? void 0 : _a[1]) || []).map((n) => {
    var _a2;
    return ((_a2 = n == null ? void 0 : n[0]) == null ? void 0 : _a2[0]) || (n == null ? void 0 : n[0]);
  }).filter((n) => typeof n == "string" && n);
}, Je = (r) => {
  var _a, _b, _c;
  const t = (_c = (_b = (_a = r == null ? void 0 : r[0]) == null ? void 0 : _a[2]) == null ? void 0 : _b[4]) == null ? void 0 : _c[0];
  return typeof t == "string" && Ut.test(t) ? t : "en";
}, Qe = (r) => ((r == null ? void 0 : r[0]) || []).filter((t) => Array.isArray(t)).map(([t, e]) => ({ title: t || "", prompt: e || "" })).filter((t) => t.title || t.prompt), b = { DEEP_DIVE: 1, BRIEF: 2, CRITIQUE: 3, DEBATE: 4 }, w = { SHORT: 1, DEFAULT: 2, LONG: 3 }, g = { EXPLAINER: 1, BRIEF: 2, CINEMATIC: 3, SHORT: 4 }, f = { AUTO: 1, CLASSIC: 3, WHITEBOARD: 4, KAWAII: 5, ANIME: 6, WATERCOLOR: 7, RETRO_PRINT: 8, HERITAGE: 9, PAPER_CRAFT: 10 }, m = { FEWER: 1, STANDARD: 2, MORE: 3 }, y = { EASY: 1, MEDIUM: 2, HARD: 3 }, M = { LANDSCAPE: 1, PORTRAIT: 2, SQUARE: 3 }, F = { CONCISE: 1, STANDARD: 2, DETAILED: 3 }, p = { AUTO: 1, SKETCH_NOTE: 2, PROFESSIONAL: 3, BENTO_GRID: 4, EDITORIAL: 5, INSTRUCTIONAL: 6, BRICKS: 7, CLAY: 8, ANIME: 9, KAWAII: 10, SCIENTIFIC: 11 }, H = { DETAILED_DECK: 1, PRESENTER_SLIDES: 2 }, B = { DEFAULT: 1, SHORT: 2, LONG: 3 }, W = { BRIEFING_DOC: { title: "Briefing Doc", desc: "Overview of your sources featuring key insights and quotes", prompt: "Create a comprehensive briefing document that synthesizes the main themes and ideas from the sources. Start with a concise Executive Summary that presents the most critical takeaways upfront. The body of the document must provide a detailed and thorough examination of the main themes, evidence, and conclusions found in the sources. This analysis should be structured logically with headings and bullet points to ensure clarity. The tone must be objective and incisive." }, STUDY_GUIDE: { title: "Study Guide", desc: "Short-answer quiz, suggested essay questions, and glossary of key terms", prompt: "You are a highly capable research assistant and tutor. Create a detailed study guide designed to review understanding of the sources. Create a quiz with ten short-answer questions (2-3 sentences each) and include a separate answer key. Suggest five essay format questions, but do not supply answers. Also conclude with a comprehensive glossary of key terms with definitions." }, BLOG_POST: { title: "Blog Post", desc: "Insightful takeaways distilled into a highly readable article", prompt: "Act as a thoughtful writer and synthesizer of ideas, tasked with creating an engaging and readable blog post for a popular online publishing platform known for its clean aesthetic and insightful content. Your goal is to distill the top most surprising, counter-intuitive, or impactful takeaways from the provided source materials into a compelling listicle. The writing style should be clean, accessible, and highly scannable, employing a conversational yet intelligent tone. Craft a compelling, click-worthy headline. Begin the article with a short introduction that hooks the reader by establishing a relatable problem or curiosity, then present each of the takeaway points as a distinct section with a clear, bolded subheading. Within each section, use short paragraphs to explain the concept clearly, and don't just summarize; offer a brief analysis or a reflection on why this point is so interesting or important, and if a powerful quote exists in the sources, feature it in a blockquote for emphasis. Conclude the post with a brief, forward-looking summary that leaves the reader with a final thought-provoking question or a powerful takeaway to ponder." } }, ze = [a.QUIZ, a.FLASHCARDS], Ze = 5, tn = 5, en = 2e3, nn = 5e3, k = 5e3, rn = 4500, sn = 600, ln = 3e4, on = 3e3, Q = "QuotaExceededError", an = [2e3, 5e3], cn = "adhoc", un = [a.AUDIO, a.QUIZ, a.FLASHCARDS, a.REPORT, a.SLIDE_DECK, a.DATA_TABLE, a.MIND_MAP, a.VIDEO, a.INFOGRAPHIC], En = { TYPE: "type" }, Tn = { NEW: "new", ALL: "all" }, An = "", z = { quantity: m.STANDARD, difficulty: y.MEDIUM }, _n = { [a.AUDIO]: { format: b.DEEP_DIVE, length: w.DEFAULT }, [a.QUIZ]: z, [a.FLASHCARDS]: z, [a.REPORT]: { preset: Object.keys(W)[0] }, [a.SLIDE_DECK]: { format: H.DETAILED_DECK, length: B.DEFAULT }, [a.DATA_TABLE]: {}, [a.MIND_MAP]: { instructions: "" }, [a.VIDEO]: { format: g.EXPLAINER, style: f.AUTO }, [a.INFOGRAPHIC]: { orientation: M.LANDSCAPE, detail: F.STANDARD, style: p.AUTO } }, Z = [{ key: "quantity", label: "Quantity", options: [{ value: m.FEWER, label: "Fewer" }, { value: m.STANDARD, label: "Standard" }, { value: m.MORE, label: "More" }] }, { key: "difficulty", label: "Difficulty", options: [{ value: y.EASY, label: "Easy" }, { value: y.MEDIUM, label: "Medium" }, { value: y.HARD, label: "Hard" }] }], Sn = { [a.AUDIO]: [{ key: "format", label: "Format", options: [{ value: b.DEEP_DIVE, label: "Deep Dive" }, { value: b.BRIEF, label: "Brief" }, { value: b.CRITIQUE, label: "Critique" }, { value: b.DEBATE, label: "Debate" }] }, { key: "length", label: "Length", options: [{ value: w.SHORT, label: "Short" }, { value: w.DEFAULT, label: "Default" }, { value: w.LONG, label: "Long" }] }], [a.QUIZ]: Z, [a.FLASHCARDS]: Z, [a.REPORT]: [{ key: "preset", label: "Type", options: Object.entries(W).map(([r, { title: t }]) => ({ value: r, label: t })) }], [a.SLIDE_DECK]: [{ key: "format", label: "Format", options: [{ value: H.DETAILED_DECK, label: "Detailed Deck" }, { value: H.PRESENTER_SLIDES, label: "Presenter Slides" }] }, { key: "length", label: "Length", options: [{ value: B.DEFAULT, label: "Default" }, { value: B.SHORT, label: "Short" }, { value: B.LONG, label: "Long" }] }], [a.DATA_TABLE]: [], [a.MIND_MAP]: [], [a.VIDEO]: [{ key: "format", label: "Format", options: [{ value: g.EXPLAINER, label: "Explainer" }, { value: g.BRIEF, label: "Brief" }, { value: g.CINEMATIC, label: "Cinematic" }, { value: g.SHORT, label: "Short" }] }, { key: "style", label: "Style", options: [{ value: f.AUTO, label: "Auto" }, { value: f.CLASSIC, label: "Classic" }, { value: f.WHITEBOARD, label: "Whiteboard" }, { value: f.KAWAII, label: "Kawaii" }, { value: f.ANIME, label: "Anime" }, { value: f.WATERCOLOR, label: "Watercolor" }, { value: f.RETRO_PRINT, label: "Retro Print" }, { value: f.HERITAGE, label: "Heritage" }, { value: f.PAPER_CRAFT, label: "Paper Craft" }] }], [a.INFOGRAPHIC]: [{ key: "orientation", label: "Orientation", options: [{ value: M.LANDSCAPE, label: "Landscape" }, { value: M.PORTRAIT, label: "Portrait" }, { value: M.SQUARE, label: "Square" }] }, { key: "detail", label: "Detail", options: [{ value: F.CONCISE, label: "Concise" }, { value: F.STANDARD, label: "Standard" }, { value: F.DETAILED, label: "Detailed" }] }, { key: "style", label: "Style", options: [{ value: p.AUTO, label: "Auto" }, { value: p.SKETCH_NOTE, label: "Sketch Note" }, { value: p.PROFESSIONAL, label: "Professional" }, { value: p.BENTO_GRID, label: "Bento Grid" }, { value: p.EDITORIAL, label: "Editorial" }, { value: p.INSTRUCTIONAL, label: "Instructional" }, { value: p.BRICKS, label: "Bricks" }, { value: p.CLAY, label: "Clay" }, { value: p.ANIME, label: "Anime" }, { value: p.KAWAII, label: "Kawaii" }, { value: p.SCIENTIFIC, label: "Scientific" }] }] }, ct = (r) => r.map((t) => [[t]]), $ = (r) => r.map((t) => [t]), d = (r, t, e) => Object.values(t).includes(r) ? r : e, Pt = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, ut = (r) => {
  const t = (r || "").replace(Pt, "");
  return t.length > k && console.warn(`Instructions truncated from ${t.length} to ${k} chars`), t.length > k ? t.slice(0, k) : t;
}, N = Object.freeze([2, null, null, Object.freeze([1, null, null, null, null, null, null, null, null, null, Object.freeze([1])]), Object.freeze([Object.freeze([1, 4, 2, 3, 6, 5])])]);
function On(r, t, e, n = {}, s = "en") {
  const l = ct(e), c = $(e), u = ut(n.instructions);
  switch (r) {
    case a.AUDIO: {
      const T = d(n.format, b, b.DEEP_DIVE), E = d(n.length, w, w.DEFAULT);
      return [N, t, [null, null, 1, l, null, null, [null, [u, E, null, c, s, null, T]]]];
    }
    case a.REPORT: {
      const T = W[n.preset] || W.BRIEFING_DOC, E = u ? `${T.prompt} ${u}` : T.prompt;
      return [N, t, [null, null, 2, l, null, null, null, [null, [T.title, T.desc, null, c, s, E]]]];
    }
    case a.VIDEO: {
      const T = d(n.format, g, g.EXPLAINER), E = T === g.SHORT, I = [c, s, u, null, T];
      return E ? I.push(null, null, 1) : I.push(d(n.style, f, f.AUTO)), [N, t, [null, null, 3, l, null, null, null, null, [null, null, I]]];
    }
    case a.QUIZ: {
      const T = d(n.quantity, m, m.STANDARD), E = d(n.difficulty, y, y.MEDIUM);
      return [N, t, [null, null, 4, l, null, null, null, null, null, [null, [2, null, u, null, null, null, null, [T, E]]]]];
    }
    case a.FLASHCARDS: {
      const T = d(n.quantity, m, m.STANDARD), E = d(n.difficulty, y, y.MEDIUM);
      return [N, t, [null, null, 4, l, null, null, null, null, null, [null, [1, null, u, null, null, null, [E, T]]]]];
    }
    case a.INFOGRAPHIC: {
      const T = d(n.orientation, M, M.LANDSCAPE), E = d(n.detail, F, F.STANDARD), I = d(n.style, p, p.AUTO);
      return [N, t, [null, null, 7, l, null, null, null, null, null, null, null, null, null, null, [[u, s, null, T, E, I]]]];
    }
    case a.SLIDE_DECK: {
      const T = d(n.format, H, H.DETAILED_DECK), E = d(n.length, B, B.DEFAULT);
      return [N, t, [null, null, 8, l, null, null, null, null, null, null, null, null, null, null, null, null, [[u, s, T, E]]]];
    }
    case a.DATA_TABLE:
      return [N, t, [null, null, 9, l, null, null, null, null, null, null, null, null, null, null, null, null, null, null, [null, [u, s]]]];
    default:
      throw new Error(`Unsupported artifact type: ${r}`);
  }
}
function In(r, t = "") {
  const e = ut(t);
  return [ct(r), null, null, null, null, ["interactive_mindmap", [["[CONTEXT]", e || ""]], ""], null, [2, null, [1], [1]]];
}
const bt = "boq_labs-tailwind-frontend_20250902.08_p1", tt = (r) => {
  if (typeof AbortSignal.timeout == "function")
    return AbortSignal.timeout(r);
  const t = new AbortController(), e = setTimeout(() => t.abort(new DOMException("TimeoutError", "TimeoutError")), r);
  return t.signal.addEventListener("abort", () => clearTimeout(e), { once: true }), t.signal;
}, Gt = (r) => {
  if (typeof AbortSignal.any == "function")
    return { signal: AbortSignal.any(r), cleanup() {
    } };
  const t = new AbortController(), e = [], n = () => {
    for (const { sig: s, handler: l } of e)
      s.removeEventListener("abort", l);
  };
  for (const s of r) {
    if (s.aborted)
      return n(), t.abort(s.reason), { signal: t.signal, cleanup() {
      } };
    const l = () => {
      n(), t.abort(s.reason);
    };
    e.push({ sig: s, handler: l }), s.addEventListener("abort", l, { once: true });
  }
  return { signal: t.signal, cleanup: n };
}, S = { LIST_RECENTLY_VIEWED_PROJECTS: "wXbhsf", CREATE_PROJECT: "CCqFvf", GET_PROJECT: "rLM1Ne", DELETE_PROJECTS: "WWINqb", MUTATE_PROJECT: "s0tc2d", REMOVE_RECENTLY_VIEWED: "fejl7e", ADD_SOURCES: "izAoDd", DELETE_SOURCES: "tGMBJ", MUTATE_SOURCE: "b7Wfje", REFRESH_SOURCE: "FLmJqe", LOAD_SOURCE: "hizoJc", CHECK_SOURCE_FRESHNESS: "yR9Yof", ACT_ON_SOURCES: "yyryJe", LABELS_MANAGE: "agX4Bc", LABELS_LIST: "I3xc3c", LABEL_MUTATE: "le8sX", LABEL_DELETE: "GyzE7e", CREATE_NOTE: "CYK0Xb", MUTATE_NOTE: "cYAfTb", DELETE_NOTES: "AH0mwd", GET_NOTES: "cFji9", CREATE_AUDIO_OVERVIEW: "AHyHrd", GET_AUDIO_OVERVIEW: "VUsiyb", DELETE_AUDIO_OVERVIEW: "sJDbic", GENERATE_DOCUMENT_GUIDES: "tr032e", GENERATE_NOTEBOOK_GUIDE: "VfAZjd", GENERATE_OUTLINE: "lCjAd", GENERATE_SECTION: "BeTrYd", START_DRAFT: "exXvGf", START_SECTION: "pGC7gf", GET_OR_CREATE_ACCOUNT: "ZwVcOc", MUTATE_ACCOUNT: "hT54vc", GET_PROJECT_ANALYTICS: "AUrzMb", SUBMIT_FEEDBACK: "uNyJKe", SHARE_AUDIO: "RGP97b", GET_PROJECT_DETAILS: "JFMDGd", SHARE_PROJECT: "QDyure", DELETE_GUIDEBOOK: "ARGkVc", GET_GUIDEBOOK: "EYqtU", LIST_RECENTLY_VIEWED_GUIDEBOOKS: "YJBpHc", PUBLISH_GUIDEBOOK: "R6smae", GET_GUIDEBOOK_DETAILS: "LJyzeb", SHARE_GUIDEBOOK: "OTl0K", GUIDEBOOK_GENERATE_ANSWER: "itA0pc", LIST_ARTIFACTS: "gArtLc", DELETE_ARTIFACT: "V5N4be", RENAME_ARTIFACT: "rc3d8d", GET_INTERACTIVE_HTML: "v9rmvd", CREATE_ARTIFACT: "R7cb6c", SUGGEST_ARTIFACT_IDEAS: "otmP3b" }, Y = [2, null, null, [1, null, null, null, null, null, null, null, null, null, [1]]];
class O {
  constructor(t, e = [], n = "") {
    this.id = t, this.args = e, this.notebookId = n;
  }
}
class wt {
  constructor(t, e = {}) {
    this.config = t, this.options = e;
  }
  async do(t) {
    var _a;
    const e = new URLSearchParams({ ...this.config.urlParams, ...t.urlParams }), n = `https://${this.config.host}/_/LabsTailwindUi/data/batchexecute?${e}`, s = [[[t.id, JSON.stringify(t.args), null, t.index]]], l = new URLSearchParams({ rpcids: t.id, "f.req": JSON.stringify(s), at: this.config.authToken }), c = { ...this.config.headers };
    this.config.debug && (console.log(`
=== BatchExecute Request ===`), console.log("URL:", n), console.log("Headers:", c), console.log("Form Data:", l.toString()));
    const u = this.options.signal ? Gt([tt(q), this.options.signal]) : null, T = u ? u.signal : tt(q);
    try {
      const E = await fetch(n, { method: "POST", headers: c, body: l, credentials: "include", signal: T });
      if (!E.ok)
        throw (E.status === 401 || E.status === 400) && this.options.onAuthError && await this.options.onAuthError(E.status), new Error(`HTTP ${E.status}: ${E.statusText}`);
      const I = await E.text();
      this.config.debug && (console.log(`
=== BatchExecute Response ===`), console.log("Raw Response:", I));
      const U = I.split(`
`).filter((G) => G.trim());
      if (U.length === 0)
        throw new Error("Empty response");
      let C;
      for (const G of U)
        try {
          const V = JSON.parse(G);
          if (Array.isArray(V) && V.length > 0) {
            C = V;
            break;
          }
        } catch {
        }
      if (!C)
        throw new Error("Could not parse response data");
      const D = C[0], R = (_a = D == null ? void 0 : D[5]) == null ? void 0 : _a[0];
      if (R != null && R !== 0) {
        if (R === 8) {
          const G = new Error("Quota exceeded: daily generation limit reached");
          throw G.name = Q, G;
        }
        throw (R === 16 || R === 7) && this.options.onAuthError && await this.options.onAuthError(R), new Error(`RPC error code ${R}`);
      }
      return { data: (D == null ? void 0 : D[2]) ? JSON.parse(D[2]) : null };
    } catch (E) {
      throw E.name === "AbortError" || E.name === Q ? E : E.name === "TimeoutError" ? new Error("Request timed out \u2014 please try again") : new Error(`BatchExecute request failed: ${E.message}`);
    } finally {
      u == null ? void 0 : u.cleanup();
    }
  }
}
class Mt {
  constructor(t, e = {}) {
    this.config = { host: "notebooklm.google.com", app: (e == null ? void 0 : e.app) || "LabsTailwindUi", authToken: t, debug: e.debug || false, headers: { "content-type": "application/x-www-form-urlencoded;charset=UTF-8", origin: "https://notebooklm.google.com", referer: "https://notebooklm.google.com/", "x-same-domain": "1", accept: "*/*", "accept-language": "en-US,en;q=0.9", "cache-control": "no-cache", pragma: "no-cache", ...e.headers }, urlParams: { bl: (e == null ? void 0 : e.bl) || bt, ...(e == null ? void 0 : e.fsid) ? { "f.sid": e.fsid } : {}, hl: "en", ...Number.isInteger(e == null ? void 0 : e.authuser) && e.authuser > 0 ? { authuser: e.authuser } : {}, ...e.urlParams } }, this.client = new wt(this.config, { ...e, signal: e.signal || null });
  }
  async do(t) {
    this.config.debug && (console.log(`
=== RPC Call ===`), console.log("ID:", t.id), console.log("NotebookID:", t.notebookId), console.log("Args:", t.args));
    const e = { ...this.config.urlParams };
    t.notebookId ? e["source-path"] = `/notebook/${encodeURIComponent(t.notebookId)}` : e["source-path"] = "/";
    const n = { id: t.id, args: t.args, index: "generic", urlParams: e };
    this.config.debug && console.log(`
RPC Request:`, n);
    const s = await this.client.do(n);
    return this.config.debug && console.log(`
RPC Response:`, s), s.data;
  }
  async listNotebooks() {
    return this.do(new O(S.LIST_RECENTLY_VIEWED_PROJECTS, [null, 500]));
  }
  async createNotebook(t) {
    return this.do(new O(S.CREATE_PROJECT, [t, null, null, [2], [1, null, null, null, null, null, null, null, null, null, [1]]]));
  }
  async deleteNotebook(t) {
    return this.do(new O(S.DELETE_PROJECTS, [[t], [2]]));
  }
  async deleteSource(t, e) {
    return this.do(new O(S.DELETE_SOURCES, [[[t]], [2]], e));
  }
  async addSource(t, e) {
    return this.do(new O(S.ADD_SOURCES, [[[null, null, null, null, null, null, null, ["https://www.youtube.com/watch?v=" + t], null, null, 1]], e, [2], [1, null, null, null, null, null, null, null, null, null, [1]]], e));
  }
  async addWebSource(t, e) {
    return this.do(new O(S.ADD_SOURCES, [[[null, null, null, null, null, null, null, [t], null, null, 1]], e, [2], [1, null, null, null, null, null, null, null, null, null, [1]]], e));
  }
  async pastedTextToSource(t, e, n = "Pasted Text") {
    return this.do(new O(S.ADD_SOURCES, [[[null, [n, t], null, 2, null, null, null, null, null, null, 1]], e, [2], [1, null, null, null, null, null, null, null, null, null, [1]]], e));
  }
  async getProject(t) {
    return this.do(new O(S.GET_PROJECT, [t, null, [2]], t));
  }
  async addUrlsToSource(t, e) {
    const n = t.map((s) => [null, null, [s], null, null, null, null, null, null, null, 1]);
    return this.do(new O(S.ADD_SOURCES, [n, e, [2], [1, null, null, null, null, null, null, null, null, null, [1]]], e));
  }
  async loadSource(t, e) {
    return this.do(new O(S.LOAD_SOURCE, [[t], [2], [2]], e));
  }
  async changeOutputLanguage(t) {
    return this.do(new O(S.MUTATE_ACCOUNT, [[[null, [[null, null, null, null, [t]]]]]]));
  }
  async refreshSource(t, e) {
    return this.do(new O(S.REFRESH_SOURCE, [null, [t], [2]], e));
  }
  async checkSourceFreshness(t, e) {
    return this.do(new O(S.CHECK_SOURCE_FRESHNESS, [null, [t], [2]], e));
  }
  async listArtifacts(t) {
    return this.do(new O(S.LIST_ARTIFACTS, [[2], t, 'NOT artifact.status = "ARTIFACT_STATUS_SUGGESTED"'], t));
  }
  async mutateSource(t, e, n) {
    return this.do(new O(S.MUTATE_SOURCE, [null, [t], [[[e]]]], n));
  }
  async listLabels(t, e = []) {
    return this.do(new O(S.LABELS_MANAGE, [[2], t, null, null, e], t));
  }
  async getLabels(t) {
    return this.do(new O(S.LABELS_LIST, [Y, t], t));
  }
  async createLabel(t, e, n = "") {
    return this.do(new O(S.LABELS_MANAGE, [[2], t, null, null, null, [[e, n]]], t));
  }
  async renameLabel(t, e, n) {
    return this.do(new O(S.LABEL_MUTATE, [[2], t, e, [[[n]]]], t));
  }
  async moveSourceToLabel(t, e, n) {
    return this.do(new O(S.LABEL_MUTATE, [Y, t, e, [[null, [[n]]]]], t));
  }
  async removeSourceFromLabel(t, e, n) {
    return this.do(new O(S.LABEL_MUTATE, [Y, t, e, [[null, null, [[n]]]]], t));
  }
  async deleteLabels(t, e) {
    return this.do(new O(S.LABEL_DELETE, [[2], t, e], t));
  }
  async deleteArtifact(t, e) {
    return this.do(new O(S.DELETE_ARTIFACT, [[2], t], e));
  }
  async mutateProject(t, e) {
    return this.do(new O(S.MUTATE_PROJECT, [t, [[null, null, null, [null, e]]]], t));
  }
  async renameArtifact(t, e, n) {
    return this.do(new O(S.RENAME_ARTIFACT, [[t, e], [["title"]]], n));
  }
  async getInteractiveHTML(t, e) {
    return this.do(new O(S.GET_INTERACTIVE_HTML, [t], e));
  }
  async getNotes(t) {
    return this.do(new O(S.GET_NOTES, [t], t));
  }
  async deleteNotes(t, e) {
    return this.do(new O(S.DELETE_NOTES, [e, null, t], e));
  }
  async mutateNote(t, e, n, s) {
    return this.do(new O(S.MUTATE_NOTE, [s, t, [[[e, n, [], 0]]]], s));
  }
  async createArtifact(t, e) {
    return this.do(new O(S.CREATE_ARTIFACT, t, e));
  }
  async suggestArtifactIdeas(t, e, n) {
    const s = [Y, e, $(t), n];
    return this.do(new O(S.SUGGEST_ARTIFACT_IDEAS, s, e));
  }
  async generateMindMap(t, e) {
    return this.do(new O(S.ACT_ON_SOURCES, t, e));
  }
  async createNote(t, e, n) {
    return this.do(new O(S.CREATE_NOTE, [n, [[[t, e, [], 0]]]], n));
  }
  async createMindMapNote(t, e, n, s) {
    const l = $(s);
    return this.do(new O(S.CREATE_NOTE, [n, t, [2, null, null, 5, l], null, e, null, [2]], n));
  }
  async getOrCreateAccount() {
    return this.do(new O(S.GET_OR_CREATE_ACCOUNT, [null, [1, null, null, null, null, null, null, null, null, null, [1]]]));
  }
}
const Ft = async () => {
  var _a, _b;
  try {
    const r = await v.get(rt);
    if ((r == null ? void 0 : r.accounts) && (r == null ? void 0 : r.activeAccount))
      return ((_a = r.accounts[r.activeAccount]) == null ? void 0 : _a.authuser) ?? 0;
  } catch {
  }
  try {
    return ((_b = await v.get(nt)) == null ? void 0 : _b.authuser) ?? 0;
  } catch {
    return 0;
  }
}, Bt = (r, t) => {
  const e = `https://notebooklm.google.com/notebook/${r}`;
  return Number.isInteger(t) && t > 0 ? `${e}?authuser=${t}` : e;
}, hn = (r) => {
  const t = "https://notebooklm.google.com";
  return Number.isInteger(r) && r > 0 ? `${t}?authuser=${r}` : t;
}, pn = async (r) => {
  if (!r)
    return;
  const t = await v.get(It) || "both", e = await v.get(ht) ?? true, n = await Ft(), s = Bt(r, n), l = chrome.runtime.getURL(`popup.html#/notebook/${r}`);
  (t === "both" || t === "notebooklm") && chrome.tabs.create({ url: s, active: !e }), (t === "both" || t === "internal") && chrome.tabs.create({ url: l, active: !e });
}, dn = () => {
  const r = chrome.runtime.getURL("popup.html#/notebooklm-config");
  chrome.tabs.create({ url: r });
}, fn = (r) => {
  const t = chrome.runtime.getURL("popup.html#/settings");
  chrome.tabs.create({ url: t });
}, et = 49e4, P = { watch: { host: "youtube.com", path: "/watch", param: "v" }, short: { host: "youtu.be", pathIndex: 1 }, embed: { host: "youtube.com", pathPrefix: "/embed/", pathIndex: 2 }, video: { host: "youtube.com", pathPrefix: "/v/", pathIndex: 2 } }, vt = (r) => {
  try {
    const t = new URL(r);
    return t.protocol === "http:" || t.protocol === "https:";
  } catch {
    return false;
  }
}, Ht = (r) => {
  try {
    const t = new URL(r);
    if (t.hostname.includes(P.watch.host) && t.pathname === P.watch.path)
      return t.searchParams.get(P.watch.param);
    if (t.hostname === P.short.host)
      return t.pathname.slice(P.short.pathIndex);
    const e = [P.embed, P.video];
    for (const n of e)
      if (t.hostname.includes(n.host) && t.pathname.startsWith(n.pathPrefix))
        return t.pathname.split("/")[n.pathIndex];
    return null;
  } catch {
    return null;
  }
}, Vt = async () => {
  try {
    const t = await v.get(rt);
    if ((t == null ? void 0 : t.accounts) && (t == null ? void 0 : t.activeAccount)) {
      const e = t.accounts[t.activeAccount];
      if (e == null ? void 0 : e.token)
        return e;
    }
  } catch (t) {
    console.warn("[NLM Tools] Failed to read multi-account auth:", t);
  }
  const r = await v.get(nt) || {};
  if (!(r == null ? void 0 : r.token))
    throw new Error("NotebookLM not configured. Please configure your API token.");
  return r;
}, it = async (r = {}) => {
  const t = await Vt();
  return new Mt(t.token, { ...t, ...r });
}, Et = async (r, t = null) => {
  if (t)
    return t;
  const n = (await r.createNotebook(""))[2] ?? null;
  if (!n)
    throw new Error("Failed to create notebook");
  return n;
}, xt = async (r, t, e) => {
  const n = Ht(t);
  n ? await r.addSource(n, e) : await r.addUrlsToSource([t], e);
}, kt = async (r, t, e) => {
  if (!t || t.trim().length === 0)
    return;
  const n = [];
  for (let s = 0; s < t.length; s += et)
    n.push(t.slice(s, s + et));
  for (const s of n)
    await r.pastedTextToSource(s, e);
}, Rn = async ({ url: r, title: t, notebookId: e = null, onProgress: n = null }) => {
  const s = (u, T, E) => {
    n && n({ step: u, message: T, progress: E });
  };
  if (s("validating", "Validating URL...", 5), !r || !vt(r))
    throw new Error("Invalid URL provided");
  s("authenticating", "Connecting to NotebookLM...", 15);
  const l = await it();
  s(e ? "getting-notebook" : "creating-notebook", e ? "Opening notebook..." : "Creating new notebook...", 25);
  const c = await Et(l, e);
  return s("adding-url", "Adding URL source...", 60), await xt(l, r, c), s("complete", "Complete!", 100), c;
}, Cn = async ({ text: r, notebookId: t = null, onProgress: e = null }) => {
  const n = (c, u, T) => {
    e && e({ step: c, message: u, progress: T });
  };
  if (n("validating", "Validating text...", 10), !r || r.trim().length === 0)
    throw new Error("No text provided");
  n("authenticating", "Connecting to NotebookLM...", 30);
  const s = await it();
  n(t ? "getting-notebook" : "creating-notebook", t ? "Opening notebook..." : "Creating new notebook...", 50);
  const l = await Et(s, t);
  return n("uploading-content", "Uploading text...", 80), await kt(s, r, l), n("complete", "Complete!", 100), l;
};
export {
  cn as $,
  we as A,
  jt as B,
  rt as C,
  he as D,
  An as E,
  qt as F,
  Tn as G,
  _e as H,
  ce as I,
  Se as J,
  It as K,
  ne as L,
  Qt as M,
  fe as N,
  ue as O,
  ve as P,
  ht as Q,
  ot as R,
  ie as S,
  Ie as T,
  zt as U,
  Ge as V,
  dn as W,
  A as X,
  qe as Y,
  Mt as Z,
  _n as _,
  Te as a,
  En as a0,
  it as a1,
  je as a2,
  We as a3,
  Ye as a4,
  ze as a5,
  en as a6,
  Q as a7,
  nn as a8,
  tt as a9,
  Me as aA,
  Ke as aB,
  Xe as aC,
  re as aD,
  Bt as aE,
  $e as aF,
  Ne as aG,
  Ue as aH,
  Pe as aI,
  Ve as aJ,
  J as aK,
  Re as aL,
  xe as aM,
  Ze as aN,
  Sn as aO,
  k as aP,
  rn as aQ,
  g as aR,
  at as aS,
  Je as aa,
  sn as ab,
  a as ac,
  In as ad,
  Pt as ae,
  On as af,
  an as ag,
  on as ah,
  ln as ai,
  Zt as aj,
  se as ak,
  te as al,
  ee as am,
  le as an,
  Qe as ao,
  tn as ap,
  Gt as aq,
  Cn as ar,
  _ as as,
  ge as at,
  me as au,
  De as av,
  Le as aw,
  ye as ax,
  Fe as ay,
  He as az,
  Ee as b,
  Ae as c,
  Ce as d,
  pe as e,
  de as f,
  ae as g,
  Oe as h,
  be as i,
  ke as j,
  Be as k,
  v as l,
  nt as m,
  Rn as n,
  fn as o,
  pn as p,
  hn as q,
  Xt as r,
  Kt as s,
  oe as t,
  Wt as u,
  Ot as v,
  $t as w,
  x,
  un as y,
  Jt as z
};
