import { r as o, j as h, u as P, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { aS as V } from "./chunk-68adfa56.js";
import { L as q, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { A as Q, __tla as __tla_2 } from "./chunk-4115c378.js";
import { am as U, __tla as __tla_3 } from "./chunk-2a4ab792.js";
import "./chunk-725317a4.js";
import { __tla as __tla_4 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let Ge;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  function H({ title: e, titleId: t, ...n }, a) {
    return o.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: a,
      "aria-labelledby": t
    }, n), e ? o.createElement("title", {
      id: t
    }, e) : null, o.createElement("path", {
      d: "M6.75 8.25a.75.75 0 0 0 0 1.5h4.5a.75.75 0 0 0 0-1.5h-4.5Z"
    }), o.createElement("path", {
      fillRule: "evenodd",
      d: "M9 2a7 7 0 1 0 4.391 12.452l3.329 3.328a.75.75 0 1 0 1.06-1.06l-3.328-3.329A7 7 0 0 0 9 2ZM3.5 9a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Z",
      clipRule: "evenodd"
    }));
  }
  const J = o.forwardRef(H), K = J;
  function ee({ title: e, titleId: t, ...n }, a) {
    return o.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: a,
      "aria-labelledby": t
    }, n), e ? o.createElement("title", {
      id: t
    }, e) : null, o.createElement("path", {
      d: "M9 6a.75.75 0 0 1 .75.75v1.5h1.5a.75.75 0 0 1 0 1.5h-1.5v1.5a.75.75 0 0 1-1.5 0v-1.5h-1.5a.75.75 0 0 1 0-1.5h1.5v-1.5A.75.75 0 0 1 9 6Z"
    }), o.createElement("path", {
      fillRule: "evenodd",
      d: "M2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Zm7-5.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11Z",
      clipRule: "evenodd"
    }));
  }
  const te = o.forwardRef(ee), ne = te;
  function re({ title: e, titleId: t, ...n }, a) {
    return o.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: a,
      "aria-labelledby": t
    }, n), e ? o.createElement("title", {
      id: t
    }, e) : null, o.createElement("path", {
      d: "M4.25 2A2.25 2.25 0 0 0 2 4.25v2a.75.75 0 0 0 1.5 0v-2a.75.75 0 0 1 .75-.75h2a.75.75 0 0 0 0-1.5h-2ZM13.75 2a.75.75 0 0 0 0 1.5h2a.75.75 0 0 1 .75.75v2a.75.75 0 0 0 1.5 0v-2A2.25 2.25 0 0 0 15.75 2h-2ZM3.5 13.75a.75.75 0 0 0-1.5 0v2A2.25 2.25 0 0 0 4.25 18h2a.75.75 0 0 0 0-1.5h-2a.75.75 0 0 1-.75-.75v-2ZM18 13.75a.75.75 0 0 0-1.5 0v2a.75.75 0 0 1-.75.75h-2a.75.75 0 0 0 0 1.5h2A2.25 2.25 0 0 0 18 15.75v-2ZM7 10a3 3 0 1 1 6 0 3 3 0 0 1-6 0Z"
    }));
  }
  const ae = o.forwardRef(re), se = ae;
  function le(e) {
    var t = 0, n = e.children, a = n && n.length;
    if (!a)
      t = 1;
    else
      for (; --a >= 0; )
        t += n[a].value;
    e.value = t;
  }
  function ie() {
    return this.eachAfter(le);
  }
  function oe(e, t) {
    let n = -1;
    for (const a of this)
      e.call(t, a, ++n, this);
    return this;
  }
  function ce(e, t) {
    for (var n = this, a = [
      n
    ], s, l, u = -1; n = a.pop(); )
      if (e.call(t, n, ++u, this), s = n.children)
        for (l = s.length - 1; l >= 0; --l)
          a.push(s[l]);
    return this;
  }
  function ue(e, t) {
    for (var n = this, a = [
      n
    ], s = [], l, u, f, p = -1; n = a.pop(); )
      if (s.push(n), l = n.children)
        for (u = 0, f = l.length; u < f; ++u)
          a.push(l[u]);
    for (; n = s.pop(); )
      e.call(t, n, ++p, this);
    return this;
  }
  function he(e, t) {
    let n = -1;
    for (const a of this)
      if (e.call(t, a, ++n, this))
        return a;
  }
  function de(e) {
    return this.eachAfter(function(t) {
      for (var n = +e(t.data) || 0, a = t.children, s = a && a.length; --s >= 0; )
        n += a[s].value;
      t.value = n;
    });
  }
  function fe(e) {
    return this.eachBefore(function(t) {
      t.children && t.children.sort(e);
    });
  }
  function xe(e) {
    for (var t = this, n = me(t, e), a = [
      t
    ]; t !== n; )
      t = t.parent, a.push(t);
    for (var s = a.length; e !== n; )
      a.splice(s, 0, e), e = e.parent;
    return a;
  }
  function me(e, t) {
    if (e === t)
      return e;
    var n = e.ancestors(), a = t.ancestors(), s = null;
    for (e = n.pop(), t = a.pop(); e === t; )
      s = e, e = n.pop(), t = a.pop();
    return s;
  }
  function ge() {
    for (var e = this, t = [
      e
    ]; e = e.parent; )
      t.push(e);
    return t;
  }
  function pe() {
    return Array.from(this);
  }
  function be() {
    var e = [];
    return this.eachBefore(function(t) {
      t.children || e.push(t);
    }), e;
  }
  function ye() {
    var e = this, t = [];
    return e.each(function(n) {
      n !== e && t.push({
        source: n.parent,
        target: n
      });
    }), t;
  }
  function* we() {
    var e = this, t, n = [
      e
    ], a, s, l;
    do
      for (t = n.reverse(), n = []; e = t.pop(); )
        if (yield e, a = e.children)
          for (s = 0, l = a.length; s < l; ++s)
            n.push(a[s]);
    while (n.length);
  }
  function L(e, t) {
    e instanceof Map ? (e = [
      void 0,
      e
    ], t === void 0 && (t = ve)) : t === void 0 && (t = ke);
    for (var n = new z(e), a, s = [
      n
    ], l, u, f, p; a = s.pop(); )
      if ((u = t(a.data)) && (p = (u = Array.from(u)).length))
        for (a.children = u, f = p - 1; f >= 0; --f)
          s.push(l = u[f] = new z(u[f])), l.parent = a, l.depth = a.depth + 1;
    return n.eachBefore(Ae);
  }
  function Me() {
    return L(this).eachBefore(je);
  }
  function ke(e) {
    return e.children;
  }
  function ve(e) {
    return Array.isArray(e) ? e[1] : null;
  }
  function je(e) {
    e.data.value !== void 0 && (e.value = e.data.value), e.data = e.data.data;
  }
  function Ae(e) {
    var t = 0;
    do
      e.height = t;
    while ((e = e.parent) && e.height < ++t);
  }
  function z(e) {
    this.data = e, this.depth = this.height = 0, this.parent = null;
  }
  z.prototype = L.prototype = {
    constructor: z,
    count: ie,
    each: oe,
    eachAfter: ue,
    eachBefore: ce,
    find: he,
    sum: de,
    sort: fe,
    path: xe,
    ancestors: ge,
    descendants: pe,
    leaves: be,
    links: ye,
    copy: Me,
    [Symbol.iterator]: we
  };
  function Ce(e, t) {
    return e.parent === t.parent ? 1 : 2;
  }
  function S(e) {
    var t = e.children;
    return t ? t[0] : e.t;
  }
  function B(e) {
    var t = e.children;
    return t ? t[t.length - 1] : e.t;
  }
  function ze(e, t, n) {
    var a = n / (t.i - e.i);
    t.c -= a, t.s += n, e.c += a, t.z += n, t.m += n;
  }
  function Ee(e) {
    for (var t = 0, n = 0, a = e.children, s = a.length, l; --s >= 0; )
      l = a[s], l.z += t, l.m += t, t += l.s + (n += l.c);
  }
  function Ne(e, t, n) {
    return e.a.parent === t.parent ? e.a : n;
  }
  function _(e, t) {
    this._ = e, this.parent = null, this.children = null, this.A = null, this.a = this, this.z = 0, this.m = 0, this.c = 0, this.s = 0, this.t = null, this.i = t;
  }
  _.prototype = Object.create(z.prototype);
  function _e(e) {
    for (var t = new _(e, 0), n, a = [
      t
    ], s, l, u, f; n = a.pop(); )
      if (l = n._.children)
        for (n.children = new Array(f = l.length), u = f - 1; u >= 0; --u)
          a.push(s = n.children[u] = new _(l[u], u)), s.parent = n;
    return (t.parent = new _(null, 0)).children = [
      t
    ], t;
  }
  function $e() {
    var e = Ce, t = 1, n = 1, a = null;
    function s(r) {
      var d = _e(r);
      if (d.eachAfter(l), d.parent.m = -d.z, d.eachBefore(u), a)
        r.eachBefore(p);
      else {
        var g = r, c = r, m = r;
        r.eachBefore(function(x) {
          x.x < g.x && (g = x), x.x > c.x && (c = x), x.depth > m.depth && (m = x);
        });
        var b = g === c ? 1 : e(g, c) / 2, y = b - g.x, w = t / (c.x + b + y), j = n / (m.depth || 1);
        r.eachBefore(function(x) {
          x.x = (x.x + y) * w, x.y = x.depth * j;
        });
      }
      return r;
    }
    function l(r) {
      var d = r.children, g = r.parent.children, c = r.i ? g[r.i - 1] : null;
      if (d) {
        Ee(r);
        var m = (d[0].z + d[d.length - 1].z) / 2;
        c ? (r.z = c.z + e(r._, c._), r.m = r.z - m) : r.z = m;
      } else
        c && (r.z = c.z + e(r._, c._));
      r.parent.A = f(r, c, r.parent.A || g[0]);
    }
    function u(r) {
      r._.x = r.z + r.parent.m, r.m += r.parent.m;
    }
    function f(r, d, g) {
      if (d) {
        for (var c = r, m = r, b = d, y = c.parent.children[0], w = c.m, j = m.m, x = b.m, M = y.m, k; b = B(b), c = S(c), b && c; )
          y = S(y), m = B(m), m.a = r, k = b.z + x - c.z - w + e(b._, c._), k > 0 && (ze(Ne(b, r, g), r, k), w += k, j += k), x += b.m, w += c.m, M += y.m, j += m.m;
        b && !B(m) && (m.t = b, m.m += x - j), c && !S(y) && (y.t = c, y.m += w - M, g = r);
      }
      return g;
    }
    function p(r) {
      r.x *= t, r.y = r.depth * n;
    }
    return s.separation = function(r) {
      return arguments.length ? (e = r, s) : e;
    }, s.size = function(r) {
      return arguments.length ? (a = false, t = +r[0], n = +r[1], s) : a ? null : [
        t,
        n
      ];
    }, s.nodeSize = function(r) {
      return arguments.length ? (a = true, t = +r[0], n = +r[1], s) : a ? [
        t,
        n
      ] : null;
    }, s;
  }
  function Re(e) {
    if (!e || typeof e != "object")
      return {
        nodes: [],
        edges: [],
        bounds: {
          minX: 0,
          maxX: 0,
          minY: 0,
          maxY: 0
        }
      };
    const t = L(e, (r) => r.children);
    $e().nodeSize([
      40,
      200
    ])(t);
    const a = [], s = [];
    let l = 1 / 0, u = -1 / 0, f = 1 / 0, p = -1 / 0;
    return t.each((r) => {
      const d = r.y, g = r.x, c = (r.data.label || "").length * 5.5 + 16, m = 22;
      if (a.push({
        id: r.data.label + "-" + r.depth + "-" + (r.parent ? r.parent.children.indexOf(r) : 0),
        label: r.data.label,
        x: d,
        y: g,
        w: c,
        h: m,
        depth: r.depth
      }), r.parent) {
        const b = r.parent.y, y = r.parent.x, w = (r.parent.data.label || "").length * 5.5 + 16;
        s.push({
          x1: b + w / 2,
          y1: y,
          x2: d - c / 2,
          y2: g
        });
      }
      l = Math.min(l, d - c / 2), u = Math.max(u, d + c / 2), f = Math.min(f, g - m / 2), p = Math.max(p, g + m / 2);
    }), {
      nodes: a,
      edges: s,
      bounds: {
        minX: l,
        maxX: u,
        minY: f,
        maxY: p
      }
    };
  }
  function Se(e, t = 20) {
    const n = e.minX - t, a = e.minY - t, s = e.maxX - e.minX + t * 2, l = e.maxY - e.minY + t * 2;
    return {
      x: n,
      y: a,
      w: s,
      h: l
    };
  }
  const F = {
    light: [
      {
        bg: "#f3f4f6",
        text: "#111827",
        border: "#d1d5db"
      },
      {
        bg: "#eff6ff",
        text: "#1d4ed8",
        border: "#bfdbfe"
      },
      {
        bg: "#f0fdf4",
        text: "#15803d",
        border: "#bbf7d0"
      },
      {
        bg: "#f9fafb",
        text: "#4b5563",
        border: "#e5e7eb"
      }
    ],
    dark: [
      {
        bg: "#1e293b",
        text: "#f1f5f9",
        border: "#475569"
      },
      {
        bg: "#172554",
        text: "#93c5fd",
        border: "#1e3a5f"
      },
      {
        bg: "#052e16",
        text: "#86efac",
        border: "#14532d"
      },
      {
        bg: "#0f172a",
        text: "#94a3b8",
        border: "#334155"
      }
    ]
  };
  function Be({ x: e, y: t, w: n, h: a, label: s, depth: l, isDark: u }) {
    const p = (u ? F.dark : F.light)[Math.min(l, 3)], r = l === 0 ? 6 : 4, d = l === 0 ? 11 : 10;
    return h.jsxs("g", {
      transform: `translate(${e},${t})`,
      children: [
        h.jsx("rect", {
          x: -n / 2,
          y: -a / 2,
          width: n,
          height: a,
          rx: r,
          fill: p.bg,
          stroke: p.border,
          strokeWidth: 1
        }),
        h.jsx("text", {
          textAnchor: "middle",
          dominantBaseline: "central",
          fill: p.text,
          fontSize: d,
          fontFamily: "ui-sans-serif, system-ui, sans-serif",
          fontWeight: l === 0 ? 600 : 400,
          children: s
        })
      ]
    });
  }
  const I = 0.3, O = 2.5, N = 0.15;
  function Le() {
    return document.documentElement.classList.contains("dark");
  }
  Ge = function({ content: e, artifact: t, notebookId: n }) {
    const [a, s] = P(), l = Le(), u = o.useRef(null), f = o.useRef(null), [p, r] = o.useState(1), [d, g] = o.useState({
      x: 0,
      y: 0
    }), [c, m] = o.useState(false), [b, y] = o.useState(false), w = o.useRef(null), { quizContentMap: j } = a.artifacts, x = t == null ? void 0 : t.id, M = x ? j[x] : null, k = !!(e == null ? void 0 : e.tree);
    o.useEffect(() => {
      !k && x && n && !M && s.fetchQuizContent(x, n);
    }, [
      k,
      x,
      n
    ]);
    const $ = o.useMemo(() => (e == null ? void 0 : e.tree) ? e.tree : (M == null ? void 0 : M.data) ? V(M.data) : null, [
      e == null ? void 0 : e.tree,
      M == null ? void 0 : M.data
    ]), v = o.useMemo(() => {
      if (!$)
        return null;
      try {
        return Re($);
      } catch {
        return null;
      }
    }, [
      $
    ]), C = o.useMemo(() => v ? Se(v.bounds, 30) : null, [
      v
    ]), X = o.useCallback(() => {
      r(1), g({
        x: 0,
        y: 0
      });
    }, []), Y = o.useCallback(() => {
      r((i) => Math.min(i + N, O));
    }, []), T = o.useCallback(() => {
      r((i) => Math.max(i - N, I));
    }, []), R = o.useCallback((i) => {
      i.preventDefault();
      const A = i.deltaY > 0 ? -N : N;
      r((E) => Math.min(Math.max(E + A, I), O));
    }, []), W = o.useCallback((i) => {
      i.button === 0 && (y(true), w.current = {
        x: i.clientX - d.x,
        y: i.clientY - d.y
      });
    }, [
      d
    ]), D = o.useCallback((i) => {
      !b || !w.current || g({
        x: i.clientX - w.current.x,
        y: i.clientY - w.current.y
      });
    }, [
      b
    ]), Z = o.useCallback(() => {
      y(false), w.current = null;
    }, []), G = o.useCallback(() => {
      var _a;
      document.fullscreenElement ? document.exitFullscreen() : (_a = f.current) == null ? void 0 : _a.requestFullscreen();
    }, []);
    return o.useEffect(() => {
      const i = f.current;
      if (!i)
        return;
      const A = () => m(document.fullscreenElement === i);
      return i.addEventListener("fullscreenchange", A), () => i.removeEventListener("fullscreenchange", A);
    }, [
      v
    ]), o.useEffect(() => {
      const i = u.current;
      if (i)
        return i.addEventListener("wheel", R, {
          passive: false
        }), () => i.removeEventListener("wheel", R);
    }, [
      R,
      v
    ]), v && C ? h.jsxs("div", {
      ref: f,
      className: `space-y-2 ${c ? "bg-white dark:bg-slate-900 p-2" : ""}`,
      children: [
        h.jsxs("div", {
          className: "flex items-center gap-1",
          children: [
            h.jsx("button", {
              onClick: Y,
              className: "p-1 text-xs font-medium text-gray-600 dark:text-slate-400 bg-gray-100 dark:bg-slate-800 rounded hover:bg-gray-200 dark:hover:bg-slate-700",
              title: "Zoom in",
              children: h.jsx(ne, {
                className: "w-3.5 h-3.5"
              })
            }),
            h.jsx("button", {
              onClick: T,
              className: "p-1 text-xs font-medium text-gray-600 dark:text-slate-400 bg-gray-100 dark:bg-slate-800 rounded hover:bg-gray-200 dark:hover:bg-slate-700",
              title: "Zoom out",
              children: h.jsx(K, {
                className: "w-3.5 h-3.5"
              })
            }),
            h.jsx("button", {
              onClick: X,
              className: "p-1 text-xs font-medium text-gray-600 dark:text-slate-400 bg-gray-100 dark:bg-slate-800 rounded hover:bg-gray-200 dark:hover:bg-slate-700",
              title: "Fit to view",
              children: h.jsx(se, {
                className: "w-3.5 h-3.5"
              })
            }),
            h.jsx("button", {
              onClick: G,
              className: "p-1 text-xs font-medium text-gray-600 dark:text-slate-400 bg-gray-100 dark:bg-slate-800 rounded hover:bg-gray-200 dark:hover:bg-slate-700",
              title: c ? "Exit fullscreen" : "Fullscreen",
              children: c ? h.jsx(Q, {
                className: "w-3.5 h-3.5"
              }) : h.jsx(U, {
                className: "w-3.5 h-3.5"
              })
            }),
            h.jsxs("span", {
              className: "text-xs text-gray-400 dark:text-slate-500 ml-1",
              children: [
                Math.round(p * 100),
                "%"
              ]
            })
          ]
        }),
        h.jsx("div", {
          ref: u,
          className: `${c ? "h-[calc(100vh-40px)]" : "h-[400px]"} overflow-hidden rounded-lg border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900`,
          style: {
            cursor: b ? "grabbing" : "grab"
          },
          onMouseDown: W,
          onMouseMove: D,
          onMouseUp: Z,
          onMouseLeave: Z,
          children: h.jsx("svg", {
            width: "100%",
            height: "100%",
            viewBox: `${C.x} ${C.y} ${C.w} ${C.h}`,
            children: h.jsxs("g", {
              transform: `translate(${d.x / p}, ${d.y / p}) scale(${p})`,
              children: [
                v.edges.map((i, A) => {
                  const E = (i.x1 + i.x2) / 2;
                  return h.jsx("path", {
                    d: `M ${i.x1} ${i.y1} C ${E} ${i.y1}, ${E} ${i.y2}, ${i.x2} ${i.y2}`,
                    fill: "none",
                    stroke: l ? "#475569" : "#d1d5db",
                    strokeWidth: 1.5
                  }, `e-${A}`);
                }),
                v.nodes.map((i) => h.jsx(Be, {
                  x: i.x,
                  y: i.y,
                  w: i.w,
                  h: i.h,
                  label: i.label,
                  depth: i.depth,
                  isDark: l
                }, i.id))
              ]
            })
          })
        })
      ]
    }) : (M == null ? void 0 : M.loading) ? h.jsx("div", {
      className: "flex items-center justify-center py-8",
      children: h.jsx(q, {
        text: "Loading mind map..."
      })
    }) : (M == null ? void 0 : M.error) ? h.jsxs("div", {
      className: "text-center py-6 space-y-2",
      children: [
        h.jsxs("p", {
          className: "text-xs text-red-600 dark:text-red-400",
          children: [
            "Failed to load content: ",
            M.error
          ]
        }),
        h.jsx("button", {
          onClick: () => s.fetchQuizContent(x, n),
          className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
          children: "Retry"
        })
      ]
    }) : (e == null ? void 0 : e.text) ? h.jsx("p", {
      className: "text-xs text-gray-500 dark:text-slate-400",
      children: "Could not parse mind map structure."
    }) : h.jsx("p", {
      className: "text-xs text-gray-500 dark:text-slate-400",
      children: "No mind map data available."
    });
  };
});
export {
  __tla,
  Ge as default
};
