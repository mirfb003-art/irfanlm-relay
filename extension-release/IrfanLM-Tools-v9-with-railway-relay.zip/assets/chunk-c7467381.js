import { u as Z, j as e, X as J, J as I, U as L, a8 as R, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as O, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { u as Q, __tla as __tla_2 } from "./chunk-b81ff817.js";
import { i as U } from "./chunk-e153acea.js";
import { A as $, __tla as __tla_3 } from "./chunk-234b1720.js";
import { i as X, z as G, Q as V, __tla as __tla_4 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_5 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let ne;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  ne = function({ isOpen: P, onClose: T, onImportSuccess: C }) {
    var _a;
    const [A, u] = Z(), { notebookTags: S } = A, { isProcessing: p, setIsProcessing: F, progress: l, setProgress: x, importFile: N, importData: n, importFormat: f, fileInputRef: z, handleFileSelect: E, resetState: _ } = Q({
      isOpen: P
    }), B = async () => {
      if (f === "json" && !n) {
        I.error("Please select a backup file first");
        return;
      }
      if (f === "zip" && !N) {
        I.error("Please select a ZIP file first");
        return;
      }
      F(true);
      try {
        f === "json" ? await D() : await M();
      } catch (a) {
        I.error(a.message || "Import failed");
      } finally {
        F(false);
      }
    }, D = async () => {
      var _a2, _b;
      const a = n.notebooks, g = a.length;
      let i = 0;
      const c = n.tags || [];
      let m = Object.values(S.tags);
      const h = {};
      if (c.length > 0) {
        x({
          current: 0,
          total: g,
          currentNotebook: "",
          phase: "Creating tags",
          sourceProgress: `0/${c.length} tags`
        });
        for (let t = 0; t < c.length; t++) {
          const s = c[t], r = m.find((o) => o.name.toLowerCase() === s.name.toLowerCase());
          if (r)
            h[s.name.toLowerCase()] = r.id;
          else {
            const o = await u.createTag(s.name, s.color);
            o && (h[s.name.toLowerCase()] = o.id, m.push(o));
          }
          x({
            current: 0,
            total: g,
            currentNotebook: "",
            phase: "Creating tags",
            sourceProgress: `${t + 1}/${c.length} tags`
          });
        }
      }
      for (let t = 0; t < a.length; t++) {
        const s = a[t], r = s.notebook || s, o = s.sources || [], j = s.tags || [];
        x({
          current: t + 1,
          total: g,
          currentNotebook: r.title,
          phase: "Creating notebook",
          sourceProgress: ""
        });
        const v = `${r.emoji || ""} ${r.title}`.trim(), d = await u.createNotebookLMProject(v);
        if (d) {
          if (o.length > 0) {
            x({
              current: t + 1,
              total: g,
              currentNotebook: r.title,
              phase: "Importing sources",
              sourceProgress: `0/${o.length} sources`
            });
            const b = n.sourceFolders || s.sourceFolders, k = b ? {
              ...b,
              folders: {
                [d]: ((_a2 = b.folders) == null ? void 0 : _a2[r.id]) || {}
              },
              sourceFolderMap: {
                [d]: ((_b = b.sourceFolderMap) == null ? void 0 : _b[r.id]) || {}
              }
            } : null;
            await U({
              globalActions: u,
              notebookId: d,
              sources: o,
              sourceFolders: k,
              onProgress: (y) => {
                x({
                  current: t + 1,
                  total: g,
                  currentNotebook: r.title,
                  phase: "Importing sources",
                  sourceProgress: `${y.current}/${y.total} sources`
                });
              }
            });
          }
          if (j.length > 0)
            for (const b of j) {
              const k = h[b.toLowerCase()];
              k && await u.addTagToNotebook(d, k);
            }
        }
        i++;
      }
      C == null ? void 0 : C(i), L(() => u.isLicensed());
    }, M = async () => {
      const { default: a } = await R(() => import("./chunk-d45ab30c.js").then((t) => t.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), g = await a.loadAsync(N), i = /* @__PURE__ */ new Map();
      for (const [t, s] of Object.entries(g.files)) {
        if (s.dir)
          continue;
        const r = t.split("/");
        if (r.length >= 2) {
          const o = r[0];
          i.has(o) || i.set(o, []), i.get(o).push({
            path: t,
            file: s
          });
        }
      }
      const c = Array.from(i.keys()), m = c.length;
      let h = 0;
      for (let t = 0; t < c.length; t++) {
        const s = c[t], r = i.get(s);
        x({
          current: t + 1,
          total: m,
          currentNotebook: s,
          phase: "Creating notebook",
          sourceProgress: ""
        });
        const o = await u.createNotebookLMProject(s);
        if (o && r.length > 0) {
          x({
            current: t + 1,
            total: m,
            currentNotebook: s,
            phase: "Importing sources",
            sourceProgress: `0/${r.length} files`
          });
          const j = new a();
          for (const { path: d, file: b } of r) {
            const k = d.split("/").pop(), y = await b.async("blob");
            j.file(k, y);
          }
          const v = await j.generateAsync({
            type: "blob"
          });
          await u.importNotebookSourcesFromZip(o, v, (d) => {
            x({
              current: t + 1,
              total: m,
              currentNotebook: s,
              phase: "Importing sources",
              sourceProgress: `${d.current}/${d.total} files`
            });
          });
        }
        h++;
      }
      C == null ? void 0 : C(h), L(() => u.isLicensed());
    }, w = () => {
      p || (_(), T());
    };
    return e.jsxs(X, {
      open: P,
      onClose: w,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(G, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(V, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx($, {
                        className: "w-4 h-4"
                      }),
                      "Import Notebooks"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: w,
                    disabled: p,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(J, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: e.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    e.jsxs("div", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: [
                        e.jsx("p", {
                          children: "Import notebooks from a previously exported bulk backup file."
                        }),
                        e.jsx("p", {
                          className: "mt-1 text-amber-600 dark:text-amber-400",
                          children: "Note: Each notebook in the backup will be created as a new notebook."
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx("label", {
                          className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                          children: "Select Backup File"
                        }),
                        e.jsx("input", {
                          ref: z,
                          type: "file",
                          accept: ".json,.zip",
                          onChange: E,
                          disabled: p,
                          className: "block w-full text-xs text-gray-500 dark:text-slate-400 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-medium file:bg-gray-100 dark:file:bg-slate-700 file:text-gray-700 dark:file:text-slate-300 hover:file:bg-gray-200 dark:hover:file:bg-slate-600 disabled:opacity-50"
                        })
                      ]
                    }),
                    f === "json" && n && e.jsxs("div", {
                      className: "bg-green-50 dark:bg-green-950 p-3 rounded-lg border border-green-200 dark:border-green-800",
                      children: [
                        e.jsx("h4", {
                          className: "text-xs font-medium text-green-800 dark:text-green-300 mb-2",
                          children: "Backup Preview"
                        }),
                        e.jsxs("div", {
                          className: "space-y-1 text-xs text-green-700 dark:text-green-300",
                          children: [
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Notebooks to import:"
                                }),
                                " ",
                                n.notebooks.length,
                                ((_a = n.tags) == null ? void 0 : _a.length) > 0 && e.jsxs("span", {
                                  className: "ml-2 text-green-600 dark:text-green-400",
                                  children: [
                                    "(",
                                    n.tags.length,
                                    " tags)"
                                  ]
                                })
                              ]
                            }),
                            e.jsx("div", {
                              className: "max-h-24 overflow-y-auto space-y-0.5 mt-2",
                              children: n.notebooks.map((a, g) => {
                                var _a2;
                                const i = a.notebook || a, c = a.sources || [], m = ((_a2 = a.tags) == null ? void 0 : _a2.length) || 0;
                                return e.jsxs("div", {
                                  className: "flex items-center gap-2 text-green-600 dark:text-green-400",
                                  children: [
                                    e.jsx("span", {
                                      children: i.emoji
                                    }),
                                    e.jsx("span", {
                                      className: "truncate",
                                      children: i.title
                                    }),
                                    e.jsxs("span", {
                                      className: "text-green-500 dark:text-green-400 ml-auto flex-shrink-0",
                                      children: [
                                        c.length,
                                        " sources",
                                        m > 0 && `, ${m} tags`
                                      ]
                                    })
                                  ]
                                }, g);
                              })
                            }),
                            n.exportedAt && e.jsxs("p", {
                              className: "mt-2",
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Exported on:"
                                }),
                                " ",
                                new Date(n.exportedAt).toLocaleString()
                              ]
                            })
                          ]
                        })
                      ]
                    }),
                    f === "zip" && N && e.jsxs("div", {
                      className: "bg-green-50 dark:bg-green-950 p-3 rounded-lg border border-green-200 dark:border-green-800",
                      children: [
                        e.jsx("h4", {
                          className: "text-xs font-medium text-green-800 dark:text-green-300 mb-2",
                          children: "ZIP File Selected"
                        }),
                        e.jsxs("div", {
                          className: "space-y-1 text-xs text-green-700 dark:text-green-300",
                          children: [
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "File:"
                                }),
                                " ",
                                N.name
                              ]
                            }),
                            e.jsx("p", {
                              className: "text-amber-600 dark:text-amber-400",
                              children: "Note: Each folder will become a new notebook with .md files as sources"
                            })
                          ]
                        })
                      ]
                    }),
                    p && e.jsxs("div", {
                      className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-2 mb-2",
                          children: [
                            e.jsx(O, {
                              size: "sm"
                            }),
                            e.jsxs("span", {
                              className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                              children: [
                                l.phase,
                                "..."
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "w-full bg-blue-200 rounded-full h-1.5",
                          children: e.jsx("div", {
                            className: "bg-blue-600 h-1.5 rounded-full",
                            style: {
                              width: `${l.total > 0 ? l.current / l.total * 100 : 0}%`
                            }
                          })
                        }),
                        e.jsx("p", {
                          className: "text-xs text-blue-600 dark:text-blue-400 mt-1",
                          children: l.current > 0 ? e.jsxs(e.Fragment, {
                            children: [
                              "Notebook ",
                              l.current,
                              "/",
                              l.total,
                              ": ",
                              l.currentNotebook,
                              l.sourceProgress && e.jsxs("span", {
                                className: "ml-2 text-blue-500 dark:text-blue-400",
                                children: [
                                  "(",
                                  l.sourceProgress,
                                  ")"
                                ]
                              })
                            ]
                          }) : l.sourceProgress
                        })
                      ]
                    })
                  ]
                })
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                children: [
                  e.jsx("button", {
                    onClick: w,
                    disabled: p,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  e.jsxs("button", {
                    onClick: B,
                    disabled: p || (f === "json" ? !n : !N),
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                    children: [
                      e.jsx($, {
                        className: "w-3.5 h-3.5"
                      }),
                      p ? "Importing..." : "Import Backup"
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  ne as default
};
