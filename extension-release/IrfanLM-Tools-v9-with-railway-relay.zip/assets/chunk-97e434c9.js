import { r as l, j as e, J as S, h as te, u as De, q as Oe, a9 as Te, ad as Ie, M as Me, X as Re, e as Pe, a8 as de, U as ie, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { P as fe, e as ke, h as pe, u as _e, b as $e, d as Ue, k as Be, g as Fe, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { L as Ze, R as Ke, __tla as __tla_2 } from "./chunk-cbc671dd.js";
import { aE as Ve } from "./chunk-68adfa56.js";
import { P as we, __tla as __tla_3 } from "./chunk-cfcef7af.js";
import { A as ae, __tla as __tla_4 } from "./chunk-57988b21.js";
import { C as Ye, __tla as __tla_5 } from "./chunk-1302cd21.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
import { __tla as __tla_6 } from "./chunk-1784b260.js";
let Dt;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })()
]).then(async () => {
  function ze({ title: a, titleId: r, ...i }, c) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: c,
      "aria-labelledby": r
    }, i), a ? l.createElement("title", {
      id: r
    }, a) : null, l.createElement("path", {
      d: "M7.712 4.818A1.5 1.5 0 0 1 10 6.095v2.972c.104-.13.234-.248.389-.343l6.323-3.906A1.5 1.5 0 0 1 19 6.095v7.81a1.5 1.5 0 0 1-2.288 1.276l-6.323-3.905a1.505 1.505 0 0 1-.389-.344v2.973a1.5 1.5 0 0 1-2.288 1.276l-6.323-3.905a1.5 1.5 0 0 1 0-2.552l6.323-3.906Z"
    }));
  }
  const He = l.forwardRef(ze), We = He;
  function Xe({ title: a, titleId: r, ...i }, c) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: c,
      "aria-labelledby": r
    }, i), a ? l.createElement("title", {
      id: r
    }, a) : null, l.createElement("path", {
      d: "M10.75 16.82A7.462 7.462 0 0 1 15 15.5c.71 0 1.396.098 2.046.282A.75.75 0 0 0 18 15.06v-11a.75.75 0 0 0-.546-.721A9.006 9.006 0 0 0 15 3a8.963 8.963 0 0 0-4.25 1.065V16.82ZM9.25 4.065A8.963 8.963 0 0 0 5 3c-.85 0-1.673.118-2.454.339A.75.75 0 0 0 2 4.06v11a.75.75 0 0 0 .954.721A7.506 7.506 0 0 1 5 15.5c1.579 0 3.042.487 4.25 1.32V4.065Z"
    }));
  }
  const Je = l.forwardRef(Xe), qe = Je;
  function Ge({ title: a, titleId: r, ...i }, c) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: c,
      "aria-labelledby": r
    }, i), a ? l.createElement("title", {
      id: r
    }, a) : null, l.createElement("path", {
      d: "M3.288 4.818A1.5 1.5 0 0 0 1 6.095v7.81a1.5 1.5 0 0 0 2.288 1.276l6.323-3.905c.155-.096.285-.213.389-.344v2.973a1.5 1.5 0 0 0 2.288 1.276l6.323-3.905a1.5 1.5 0 0 0 0-2.552l-6.323-3.906A1.5 1.5 0 0 0 10 6.095v2.972a1.506 1.506 0 0 0-.389-.343L3.288 4.818Z"
    }));
  }
  const Qe = l.forwardRef(Ge), et = Qe;
  function tt({ title: a, titleId: r, ...i }, c) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: c,
      "aria-labelledby": r
    }, i), a ? l.createElement("title", {
      id: r
    }, a) : null, l.createElement("path", {
      d: "M10.5 3.75a.75.75 0 0 0-1.264-.546L5.203 7H2.667a.75.75 0 0 0-.7.48A6.985 6.985 0 0 0 1.5 10c0 .887.165 1.737.468 2.52.111.29.39.48.7.48h2.535l4.033 3.796a.75.75 0 0 0 1.264-.546V3.75ZM16.45 5.05a.75.75 0 0 0-1.06 1.061 5.5 5.5 0 0 1 0 7.778.75.75 0 0 0 1.06 1.06 7 7 0 0 0 0-9.899Z"
    }), l.createElement("path", {
      d: "M14.329 7.172a.75.75 0 0 0-1.061 1.06 2.5 2.5 0 0 1 0 3.536.75.75 0 0 0 1.06 1.06 4 4 0 0 0 0-5.656Z"
    }));
  }
  const at = l.forwardRef(tt), ue = at;
  function rt({ title: a, titleId: r, ...i }, c) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: c,
      "aria-labelledby": r
    }, i), a ? l.createElement("title", {
      id: r
    }, a) : null, l.createElement("path", {
      d: "M10.047 3.062a.75.75 0 0 1 .453.688v12.5a.75.75 0 0 1-1.264.546L5.203 13H2.667a.75.75 0 0 1-.7-.48A6.985 6.985 0 0 1 1.5 10c0-.887.165-1.737.468-2.52a.75.75 0 0 1 .7-.48h2.535l4.033-3.796a.75.75 0 0 1 .811-.142ZM13.78 7.22a.75.75 0 1 0-1.06 1.06L14.44 10l-1.72 1.72a.75.75 0 0 0 1.06 1.06l1.72-1.72 1.72 1.72a.75.75 0 1 0 1.06-1.06L16.56 10l1.72-1.72a.75.75 0 0 0-1.06-1.06L15.5 8.94l-1.72-1.72Z"
    }));
  }
  const st = l.forwardRef(rt), lt = st;
  function nt({ title: a, titleId: r, ...i }, c) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: c,
      "aria-labelledby": r
    }, i), a ? l.createElement("title", {
      id: r
    }, a) : null, l.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
    }));
  }
  const ot = l.forwardRef(nt), dt = ot;
  function he(a) {
    if (!a || isNaN(a))
      return "0:00";
    const r = Math.floor(a / 60), i = Math.floor(a % 60);
    return `${r}:${i.toString().padStart(2, "0")}`;
  }
  const it = [
    0.5,
    0.75,
    1,
    1.25,
    1.5,
    2
  ];
  function ct({ audioUrl: a, isPlaying: r, initialProgress: i = 0, onPlay: c, onPause: E, onEnded: D, onTimeUpdate: d, onNext: p, onPrevious: M, onRefreshUrl: w, hasNext: v = true, hasPrevious: R = true }) {
    const f = l.useRef(null), Y = l.useRef(a), [h, C] = l.useState(0), [g, Z] = l.useState(0), [N, re] = l.useState(() => {
      const s = localStorage.getItem("YT_NOTEBOOKLM_TOOLS_AUDIO_PLAYBACK_RATE");
      return s ? parseFloat(s) : 1;
    }), [O, K] = l.useState(() => {
      const s = localStorage.getItem("YT_NOTEBOOKLM_TOOLS_AUDIO_VOLUME");
      return s ? parseFloat(s) : 1;
    }), [T, V] = l.useState(false), [F, H] = l.useState(false), [W, $] = l.useState(false), [X, q] = l.useState(false);
    l.useEffect(() => {
      const s = f.current;
      if (!s)
        return;
      const y = () => {
        if (C(s.currentTime), g > 0) {
          const U = s.currentTime / g;
          d == null ? void 0 : d(U);
        }
      }, P = () => {
        Z(s.duration), i > 0 && !F && (s.currentTime = s.duration * i, H(true));
      }, I = () => {
        D == null ? void 0 : D();
      }, A = () => $(true), G = () => $(false), Q = () => $(false), ee = async () => {
        var _a;
        $(false);
        const U = (_a = s.error) == null ? void 0 : _a.code;
        if ((U === 4 || U === 2) && !X && w && (q(true), $(true), S.info("Audio URL expired, refreshing...", {
          duration: 2e3
        }), await w()))
          return;
        let z = "Failed to load audio";
        U === 2 ? z = "Network error loading audio" : U === 3 ? z = "Audio decoding failed" : U === 4 && (z = "Audio not supported or expired"), S.error(z, {
          duration: 3e3
        }), v && setTimeout(() => p == null ? void 0 : p(), 2e3);
      };
      return s.addEventListener("timeupdate", y), s.addEventListener("loadedmetadata", P), s.addEventListener("ended", I), s.addEventListener("waiting", A), s.addEventListener("canplay", G), s.addEventListener("playing", Q), s.addEventListener("error", ee), () => {
        s.removeEventListener("timeupdate", y), s.removeEventListener("loadedmetadata", P), s.removeEventListener("ended", I), s.removeEventListener("waiting", A), s.removeEventListener("canplay", G), s.removeEventListener("playing", Q), s.removeEventListener("error", ee);
      };
    }, [
      a,
      g,
      i,
      F,
      d,
      D,
      v,
      p,
      X,
      w
    ]), l.useEffect(() => {
      const s = f.current;
      !s || !a || (Y.current !== a && (s.load(), Y.current = a), r ? s.play().catch(console.error) : s.pause());
    }, [
      r,
      a
    ]), l.useEffect(() => {
      H(false), q(false);
    }, [
      a
    ]), l.useEffect(() => {
      const s = f.current;
      s && (s.playbackRate = N);
    }, [
      N
    ]), l.useEffect(() => {
      const s = f.current;
      s && (s.volume = T ? 0 : O);
    }, [
      O,
      T
    ]), l.useEffect(() => {
      localStorage.setItem("YT_NOTEBOOKLM_TOOLS_AUDIO_PLAYBACK_RATE", N);
    }, [
      N
    ]), l.useEffect(() => {
      localStorage.setItem("YT_NOTEBOOKLM_TOOLS_AUDIO_VOLUME", O);
    }, [
      O
    ]), l.useEffect(() => {
      const s = (y) => {
        const P = y.target.tagName.toLowerCase();
        if (P === "input" || P === "textarea" || P === "select" || y.target.isContentEditable)
          return;
        const I = f.current;
        if (I)
          switch (y.code) {
            case "Space":
              y.preventDefault(), r ? E == null ? void 0 : E() : c == null ? void 0 : c();
              break;
            case "ArrowLeft":
              y.preventDefault(), I.currentTime = Math.max(0, I.currentTime - 10);
              break;
            case "ArrowRight":
              y.preventDefault(), I.currentTime = Math.min(g, I.currentTime + 30);
              break;
            case "ArrowUp":
              y.preventDefault(), K((A) => Math.min(1, A + 0.1)), V(false);
              break;
            case "ArrowDown":
              y.preventDefault(), K((A) => Math.max(0, A - 0.1));
              break;
            case "KeyM":
              y.preventDefault(), V((A) => !A);
              break;
          }
      };
      return window.addEventListener("keydown", s), () => window.removeEventListener("keydown", s);
    }, [
      r,
      g,
      c,
      E
    ]);
    const se = (s) => {
      const y = f.current;
      if (!y || !g)
        return;
      const P = s.currentTarget.getBoundingClientRect(), A = (s.clientX - P.left) / P.width;
      y.currentTime = A * g;
    }, le = () => {
      const s = f.current;
      s && (s.currentTime = Math.max(0, s.currentTime - 10));
    }, J = () => {
      const s = f.current;
      s && (s.currentTime = Math.min(g, s.currentTime + 30));
    }, ne = g > 0 ? h / g * 100 : 0;
    return e.jsxs("div", {
      className: "flex flex-col gap-2",
      children: [
        e.jsx("audio", {
          ref: f,
          src: a,
          preload: "metadata"
        }),
        e.jsx("div", {
          className: "h-1.5 bg-gray-200 dark:bg-slate-700 rounded-full cursor-pointer",
          onClick: se,
          children: e.jsx("div", {
            className: "h-full bg-gray-900 dark:bg-gray-100 rounded-full",
            style: {
              width: `${ne}%`
            }
          })
        }),
        e.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            e.jsx("span", {
              className: "text-xs text-gray-500 dark:text-slate-400 w-10",
              children: he(h)
            }),
            e.jsxs("div", {
              className: "flex items-center gap-1",
              children: [
                e.jsx("button", {
                  onClick: M,
                  disabled: !R,
                  className: "p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed",
                  children: e.jsx(We, {
                    className: "w-4 h-4 text-gray-700 dark:text-slate-300"
                  })
                }),
                e.jsx("button", {
                  onClick: le,
                  className: "p-1 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 text-xs font-medium text-gray-600 dark:text-slate-400",
                  title: "Skip back 10 seconds",
                  children: "-10s"
                }),
                e.jsx("button", {
                  onClick: r ? E : c,
                  disabled: W,
                  className: "p-2 rounded-full bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-200 disabled:opacity-70",
                  children: W ? e.jsx("div", {
                    className: "w-5 h-5 flex items-center justify-center",
                    children: e.jsx("div", {
                      className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"
                    })
                  }) : r ? e.jsx(we, {
                    className: "w-5 h-5"
                  }) : e.jsx(fe, {
                    className: "w-5 h-5"
                  })
                }),
                e.jsx("button", {
                  onClick: J,
                  className: "p-1 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 text-xs font-medium text-gray-600 dark:text-slate-400",
                  title: "Skip forward 30 seconds",
                  children: "+30s"
                }),
                e.jsx("button", {
                  onClick: p,
                  disabled: !v,
                  className: "p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed",
                  children: e.jsx(et, {
                    className: "w-4 h-4 text-gray-700 dark:text-slate-300"
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-1",
              children: [
                e.jsx("button", {
                  onClick: () => V(!T),
                  className: "p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-700",
                  title: T ? "Unmute" : "Mute",
                  children: T || O === 0 ? e.jsx(lt, {
                    className: "w-4 h-4 text-gray-600 dark:text-slate-400"
                  }) : e.jsx(ue, {
                    className: "w-4 h-4 text-gray-600 dark:text-slate-400"
                  })
                }),
                e.jsx("input", {
                  type: "range",
                  min: "0",
                  max: "1",
                  step: "0.1",
                  value: T ? 0 : O,
                  onChange: (s) => {
                    K(parseFloat(s.target.value)), V(false);
                  },
                  className: "w-12 h-1 accent-gray-900 dark:accent-gray-100 cursor-pointer",
                  title: `Volume: ${Math.round((T ? 0 : O) * 100)}%`
                }),
                e.jsx("select", {
                  value: N,
                  onChange: (s) => re(Number(s.target.value)),
                  className: "px-1 py-0.5 text-xs font-medium text-gray-600 dark:text-slate-400 bg-gray-100 dark:bg-slate-700 rounded hover:bg-gray-200 dark:hover:bg-slate-600 cursor-pointer border-0",
                  children: it.map((s) => e.jsxs("option", {
                    value: s,
                    children: [
                      s,
                      "x"
                    ]
                  }, s))
                }),
                e.jsx("span", {
                  className: "text-xs text-gray-500 dark:text-slate-400 w-10 text-right",
                  children: he(g)
                })
              ]
            })
          ]
        }),
        e.jsx("div", {
          className: "text-xs text-gray-400 dark:text-slate-500",
          children: "Space: play \xB7 \u2190\u2192: skip \xB7 \u2191\u2193: volume \xB7 M: mute"
        })
      ]
    });
  }
  function ut({ audio: a, isPlaying: r, progress: i = 0, onPlay: c, onPause: E, onEnded: D, onTimeUpdate: d, onNext: p, onPrevious: M, onRefreshUrl: w, hasNext: v, hasPrevious: R }) {
    return a ? e.jsxs("div", {
      className: "fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-slate-700 p-3 shadow-lg dark:shadow-slate-900/30 z-50",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2 mb-2",
          children: [
            e.jsx("span", {
              className: "text-sm",
              children: a.notebookEmoji
            }),
            e.jsx("span", {
              className: "text-xs text-gray-500 dark:text-slate-400 truncate",
              children: a.notebookTitle
            }),
            e.jsx("span", {
              className: "text-gray-300 dark:text-slate-600",
              children: "\u2022"
            }),
            e.jsx("span", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100 truncate flex-1",
              children: a.title
            })
          ]
        }),
        e.jsx(ct, {
          audioUrl: a.audioUrl,
          isPlaying: r,
          initialProgress: i,
          onPlay: c,
          onPause: E,
          onEnded: D,
          onTimeUpdate: d,
          onNext: p,
          onPrevious: M,
          onRefreshUrl: w,
          hasNext: v,
          hasPrevious: R
        })
      ]
    }) : null;
  }
  function xt(a) {
    if (!a)
      return "0:00";
    const r = Math.floor(a / 60), i = Math.floor(a % 60);
    return `${r}:${i.toString().padStart(2, "0")}`;
  }
  function mt({ audio: a, isPlaying: r, isCurrent: i, progress: c = 0, isListened: E = false, onClick: D, onToggleListened: d, onDelete: p, isSelected: M = false, isSelecting: w = false, onSelect: v }) {
    const [R, f] = l.useState(false), Y = async (h) => {
      if (h.stopPropagation(), !R) {
        f(true);
        try {
          const C = await fetch(a.downloadUrl || a.audioUrl);
          if (!C.ok)
            throw new Error("Download failed");
          const g = await C.blob(), Z = URL.createObjectURL(g), N = document.createElement("a");
          N.href = Z, N.download = `${a.notebookTitle} - ${a.title}.mp3`, document.body.appendChild(N), N.click(), document.body.removeChild(N), URL.revokeObjectURL(Z), S.success("Download complete", {
            duration: 2e3
          });
        } catch (C) {
          console.error("Download failed:", C), S.error("Download failed", {
            duration: 3e3
          });
        } finally {
          f(false);
        }
      }
    };
    return e.jsxs("div", {
      onClick: () => {
        w ? v == null ? void 0 : v() : D == null ? void 0 : D();
      },
      className: `flex items-center gap-3 p-2 rounded-md cursor-pointer ${M ? "bg-neutral-100 dark:bg-slate-700 ring-1 ring-neutral-300 dark:ring-slate-600" : i ? "bg-gray-100 dark:bg-slate-700" : "hover:bg-gray-50 dark:hover:bg-slate-800"}`,
      children: [
        e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 focus:ring-1 cursor-pointer flex-shrink-0",
          checked: M,
          onChange: () => v == null ? void 0 : v(),
          onClick: (h) => h.stopPropagation()
        }),
        e.jsx("div", {
          className: "flex-shrink-0",
          children: i && r ? e.jsx("div", {
            className: "w-8 h-8 flex items-center justify-center rounded-full bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900",
            children: e.jsx(we, {
              className: "w-4 h-4"
            })
          }) : e.jsx("div", {
            className: `w-8 h-8 flex items-center justify-center rounded-full ${i ? "bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900" : "bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-400"}`,
            children: e.jsx(fe, {
              className: "w-4 h-4"
            })
          })
        }),
        e.jsxs("div", {
          className: "flex-1 min-w-0",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                e.jsx("span", {
                  className: "text-xs",
                  children: a.notebookEmoji
                }),
                e.jsx("span", {
                  className: "text-xs text-gray-500 dark:text-slate-400 truncate",
                  children: a.notebookTitle
                })
              ]
            }),
            e.jsx("p", {
              className: `text-xs font-medium truncate ${E ? "text-gray-400 dark:text-slate-500" : "text-gray-900 dark:text-slate-100"}`,
              children: a.title
            }),
            c > 0 && c < 1 && e.jsx("div", {
              className: "mt-1 h-0.5 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden",
              children: e.jsx("div", {
                className: "h-full bg-gray-600 dark:bg-slate-400 rounded-full",
                style: {
                  width: `${c * 100}%`
                }
              })
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-1 flex-shrink-0",
          children: [
            e.jsx("span", {
              className: "text-xs text-gray-500 dark:text-slate-400",
              children: xt(a.duration)
            }),
            e.jsx("button", {
              onClick: (h) => {
                h.stopPropagation(), d == null ? void 0 : d(a.id);
              },
              className: `p-1 rounded hover:bg-gray-200 dark:hover:bg-slate-600 ${E ? "text-green-500 hover:text-green-600" : "text-gray-400 dark:text-slate-500 hover:text-green-500"}`,
              title: E ? "Listened \u2014 click to mark as unlistened" : "Mark as listened",
              children: E ? e.jsx(ke, {
                className: "w-4 h-4"
              }) : e.jsx(dt, {
                className: "w-4 h-4"
              })
            }),
            e.jsx("button", {
              onClick: Y,
              disabled: R,
              className: "p-1 rounded hover:bg-gray-200 dark:hover:bg-slate-600 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 disabled:opacity-50",
              title: "Download",
              children: R ? e.jsx(te, {
                className: "w-4 h-4 animate-spin"
              }) : e.jsx(ae, {
                className: "w-4 h-4"
              })
            }),
            e.jsx("button", {
              onClick: (h) => {
                h.stopPropagation(), p == null ? void 0 : p();
              },
              className: "p-1 rounded hover:bg-gray-200 dark:hover:bg-slate-600 text-gray-500 dark:text-slate-400 hover:text-red-500 dark:hover:text-red-400",
              title: "Delete",
              children: e.jsx(pe, {
                className: "w-4 h-4"
              })
            })
          ]
        })
      ]
    });
  }
  function ht({ isOpen: a, onClose: r, onConfirm: i, items: c }) {
    const [E, D] = l.useState(false);
    if (l.useEffect(() => {
      a && D(false);
    }, [
      a
    ]), !c || c.length === 0)
      return null;
    const d = c.length, p = d === 1 ? "Delete this podcast?" : `Delete ${d} podcasts?`, M = d === 1 ? `"${c[0].title || "Untitled"}" will be permanently deleted from NotebookLM.` : `${d} podcasts will be permanently deleted from NotebookLM.`, w = async () => {
      D(true);
      try {
        await i(c), r();
      } catch {
        D(false);
      }
    };
    return e.jsx(Ye, {
      open: a,
      onClose: E ? () => {
      } : r,
      onConfirm: w,
      title: p,
      message: M,
      confirmLabel: E ? "Deleting..." : "Delete",
      disabled: E
    });
  }
  const ge = "YT_NOTEBOOKLM_TOOLS_PODCAST_SORT_BY", gt = [
    {
      value: "newest",
      label: "Newest"
    },
    {
      value: "oldest",
      label: "Oldest"
    },
    {
      value: "name",
      label: "Name"
    },
    {
      value: "duration",
      label: "Duration"
    }
  ], be = {
    newest: (a, r) => Date.parse(r.createdAt) - Date.parse(a.createdAt),
    oldest: (a, r) => Date.parse(a.createdAt) - Date.parse(r.createdAt),
    name: (a, r) => (a.title || "").localeCompare(r.title || ""),
    duration: (a, r) => (r.duration || 0) - (a.duration || 0)
  }, ce = "py-1.5 pl-2 pr-7 text-xs font-medium text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-700 border-0 rounded-md focus:ring-0", bt = [
    {
      value: "all",
      label: "All"
    },
    {
      value: "unlistened",
      label: "Unlistened"
    },
    {
      value: "in-progress",
      label: "In progress"
    },
    {
      value: "listened",
      label: "Listened"
    }
  ], ft = [
    {
      value: "all",
      label: "All notebooks"
    },
    {
      value: "my",
      label: "My notebooks"
    },
    {
      value: "shared",
      label: "Shared with me"
    }
  ];
  Dt = function() {
    var _a, _b;
    const [a, r] = De(), i = _e(), { podcastPlayer: c, authNotebookLM: E, notebooklm: D } = a, { playlist: d, loading: p, error: M, scanProgress: w, currentIndex: v, isPlaying: R, progressMap: f } = c, Y = (_a = Oe(a)) == null ? void 0 : _a.authuser, h = v >= 0 ? d[v] : null, [C, g] = l.useState(/* @__PURE__ */ new Set()), Z = C.size > 0, [N, re] = l.useState(() => localStorage.getItem(ge) || "newest"), [O, K] = l.useState(""), [T, V] = l.useState("all"), [F, H] = l.useState("all"), [W, $] = l.useState(null), X = l.useMemo(() => {
      const t = {};
      for (const n of D.projects || [])
        t[n.id] = n.permissionCode;
      return t;
    }, [
      D.projects
    ]), q = (t) => {
      re(t), localStorage.setItem(ge, t);
    }, se = (t) => {
      g((n) => {
        const u = new Set(n);
        return u.has(t) ? u.delete(t) : u.add(t), u;
      });
    }, le = (t) => {
      g((n) => {
        const u = new Set(n), k = t.items.every((o) => n.has(o.id));
        return t.items.forEach((o) => {
          k ? u.delete(o.id) : u.add(o.id);
        }), u;
      });
    };
    l.useEffect(() => {
      r.isNotebookLMAuthenticated() && d.length === 0 && !p && r.loadFromCache();
    }, []);
    const J = l.useMemo(() => {
      const t = {}, n = O.trim().toLowerCase();
      d.forEach((o, b) => {
        if (n && !(o.title || "").toLowerCase().includes(n) && !(o.notebookTitle || "").toLowerCase().includes(n))
          return;
        if (T !== "all") {
          const j = f[o.id];
          if (((j == null ? void 0 : j.isListened) ? "listened" : (j == null ? void 0 : j.progress) > 0 ? "in-progress" : "unlistened") !== T)
            return;
        }
        const x = o.permissionCode ?? X[o.notebookId] ?? null;
        if (F === "my" && !Te({
          permissionCode: x
        }) || F === "shared" && !Ie({
          permissionCode: x
        }))
          return;
        const m = o.notebookId;
        t[m] || (t[m] = {
          notebookId: o.notebookId,
          notebookTitle: o.notebookTitle,
          notebookEmoji: o.notebookEmoji,
          permissionCode: x,
          items: []
        }), t[m].items.push({
          ...o,
          globalIndex: b
        });
      });
      const u = be[N] || be.newest, k = Object.values(t);
      return k.forEach((o) => o.items.sort(u)), N === "name" ? k.sort((o, b) => (o.notebookTitle || "").localeCompare(b.notebookTitle || "")) : k.sort((o, b) => u(o.items[0], b.items[0])), k;
    }, [
      d,
      N,
      O,
      T,
      F,
      f,
      X
    ]), ne = O.trim() !== "" || T !== "all" || F !== "all", s = J.reduce((t, n) => t + n.items.length, 0), y = async () => {
      g(/* @__PURE__ */ new Set()), await r.scanAllNotebooks({
        limit: me
      });
    }, P = async (t) => {
      const n = await r.deletePodcasts(t.map((u) => u.id));
      if (!n) {
        S.error("Not authenticated");
        return;
      }
      n.failed > 0 ? S.warning(`Deleted ${n.deleted} of ${n.deleted + n.failed}`) : S.success(n.deleted === 1 ? "Podcast deleted" : `${n.deleted} podcasts deleted`), g((u) => {
        const k = new Set(u);
        return t.forEach((o) => k.delete(o.id)), k;
      });
    }, I = d.filter((t) => C.has(t.id)), A = I.length > 0 && I.every((t) => {
      var _a2;
      return (_a2 = f[t.id]) == null ? void 0 : _a2.isListened;
    }), G = async () => {
      await r.setListenedBulk([
        ...C
      ], !A), S.success(A ? "Marked as unlistened" : "Marked as listened"), g(/* @__PURE__ */ new Set());
    }, Q = (t) => {
      v === t && R ? r.pauseAudio() : r.playAudio(t);
    }, ee = () => {
      r.forceProgressSave(), r.pauseAudio();
    }, U = () => {
      r.resumeAudio();
    }, z = async () => {
      h && r.markAsListened(h.id);
      const t = await r.playNext(true);
      !(t == null ? void 0 : t.played) && (t == null ? void 0 : t.noMoreUnlistened) && S.info("No more unlistened episodes");
    }, xe = (t) => {
      h && t > 0 && r.updateProgress(h.id, t);
    }, ve = () => {
      r.playNext();
    }, ye = () => {
      r.playPrevious();
    }, je = async () => h ? await r.refreshAudioUrl(h.id) : null, [me, Ne] = l.useState(20), Le = [
      {
        value: null,
        label: "All"
      },
      {
        value: 10,
        label: "Last 10"
      },
      {
        value: 20,
        label: "Last 20"
      },
      {
        value: 50,
        label: "Last 50"
      }
    ], [L, B] = l.useState({
      notebookId: null,
      current: 0,
      total: 0,
      isDownloading: false
    }), Se = async (t) => {
      if (!L.isDownloading) {
        B({
          notebookId: t.notebookId,
          current: 0,
          total: t.items.length,
          isDownloading: true
        });
        try {
          const { default: n } = await de(() => import("./chunk-d45ab30c.js").then((x) => x.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), u = new n();
          for (let x = 0; x < t.items.length; x++) {
            const m = t.items[x];
            B((j) => ({
              ...j,
              current: x + 1
            }));
            try {
              const j = await fetch(m.downloadUrl || m.audioUrl);
              if (!j.ok)
                throw new Error("Fetch failed");
              const _ = await j.blob();
              u.file(`${m.title}.mp3`, _);
            } catch (j) {
              console.warn(`Failed to download: ${m.title}`, j);
            }
          }
          const k = await u.generateAsync({
            type: "blob"
          }), o = URL.createObjectURL(k), b = document.createElement("a");
          b.href = o, b.download = `${t.notebookTitle} - Podcasts.zip`, document.body.appendChild(b), b.click(), document.body.removeChild(b), URL.revokeObjectURL(o), S.success("Download complete", {
            duration: 2e3
          }), ie(() => r.isLicensed());
        } catch (n) {
          console.error("Bulk download failed:", n), S.error("Download failed", {
            duration: 3e3
          });
        } finally {
          B({
            notebookId: null,
            current: 0,
            total: 0,
            isDownloading: false
          });
        }
      }
    }, Ee = async () => {
      if (!(L.isDownloading || d.length === 0)) {
        B({
          notebookId: "all",
          current: 0,
          total: d.length,
          isDownloading: true
        });
        try {
          const { default: t } = await de(() => import("./chunk-d45ab30c.js").then((b) => b.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), n = new t();
          for (let b = 0; b < d.length; b++) {
            const x = d[b];
            B((m) => ({
              ...m,
              current: b + 1
            }));
            try {
              const m = await fetch(x.downloadUrl || x.audioUrl);
              if (!m.ok)
                throw new Error("Fetch failed");
              const j = await m.blob();
              n.folder(x.notebookTitle).file(`${x.title}.mp3`, j);
            } catch (m) {
              console.warn(`Failed to download: ${x.title}`, m);
            }
          }
          const u = await n.generateAsync({
            type: "blob"
          }), k = URL.createObjectURL(u), o = document.createElement("a");
          o.href = k, o.download = "All Podcasts.zip", document.body.appendChild(o), o.click(), document.body.removeChild(o), URL.revokeObjectURL(k), S.success("Download complete", {
            duration: 2e3
          }), ie(() => r.isLicensed());
        } catch (t) {
          console.error("Download all failed:", t), S.error("Download failed", {
            duration: 3e3
          });
        } finally {
          B({
            notebookId: null,
            current: 0,
            total: 0,
            isDownloading: false
          });
        }
      }
    }, Ce = async () => {
      const t = d.filter((n) => C.has(n.id));
      if (!(t.length === 0 || L.isDownloading)) {
        B({
          notebookId: "selected",
          current: 0,
          total: t.length,
          isDownloading: true
        });
        try {
          const { default: n } = await de(() => import("./chunk-d45ab30c.js").then((m) => m.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), u = new n();
          let k = 0;
          for (let m = 0; m < t.length; m++) {
            const j = t[m];
            B((_) => ({
              ..._,
              current: m + 1
            }));
            try {
              const _ = await fetch(j.downloadUrl || j.audioUrl);
              if (!_.ok)
                throw new Error("Fetch failed");
              const Ae = await _.blob();
              u.folder(j.notebookTitle).file(`${j.title}.mp3`, Ae);
            } catch (_) {
              k++, console.warn(`Failed to download: ${j.title}`, _);
            }
          }
          const o = await u.generateAsync({
            type: "blob"
          }), b = URL.createObjectURL(o), x = document.createElement("a");
          x.href = b, x.download = "Selected Podcasts.zip", document.body.appendChild(x), x.click(), document.body.removeChild(x), URL.revokeObjectURL(b), k > 0 ? S.warning(`Downloaded ${t.length - k} of ${t.length} (${k} failed)`) : (S.success("Download complete"), ie(() => r.isLicensed())), g(/* @__PURE__ */ new Set());
        } catch {
          S.error("Download failed");
        } finally {
          B({
            notebookId: null,
            current: 0,
            total: 0,
            isDownloading: false
          });
        }
      }
    }, oe = r.isNotebookLMAuthenticated();
    return e.jsxs($e, {
      children: [
        e.jsx(Ue, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "Podcast Player"
          })
        }),
        e.jsxs("div", {
          className: `flex flex-col gap-4 ${h ? "pb-28" : ""}`,
          children: [
            e.jsx(Be, {}),
            e.jsxs("div", {
              className: "flex items-center justify-between",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx(ue, {
                      className: "w-5 h-5 text-gray-700 dark:text-slate-300"
                    }),
                    e.jsx("h1", {
                      className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                      children: "Podcast Player"
                    }),
                    d.length > 0 && e.jsx("span", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: ne ? `(${s} of ${d.length})` : `(${d.length} audio${d.length !== 1 ? "s" : ""})`
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    d.length > 0 && e.jsx("select", {
                      value: N,
                      onChange: (t) => q(t.target.value),
                      title: "Sort podcasts",
                      className: ce,
                      children: gt.map((t) => e.jsx("option", {
                        value: t.value,
                        children: t.label
                      }, t.value))
                    }),
                    d.length > 0 && e.jsxs("button", {
                      onClick: Ee,
                      disabled: L.isDownloading,
                      className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-700 rounded-md hover:bg-gray-200 dark:hover:bg-slate-600 disabled:opacity-50",
                      children: [
                        L.notebookId === "all" ? e.jsx(te, {
                          className: "w-3.5 h-3.5 animate-spin"
                        }) : e.jsx(ae, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Download All"
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex items-center",
                      children: [
                        e.jsx("select", {
                          value: me ?? "",
                          onChange: (t) => Ne(t.target.value ? Number(t.target.value) : null),
                          disabled: p || !oe,
                          className: "px-2 py-1.5 w-20 text-xs font-medium text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-700 border-0 rounded-l-md focus:ring-0 disabled:opacity-50",
                          children: Le.map((t) => e.jsx("option", {
                            value: t.value ?? "",
                            children: t.label
                          }, t.label))
                        }),
                        e.jsxs("button", {
                          onClick: y,
                          disabled: p || !oe,
                          className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-white dark:text-gray-900 bg-gray-900 dark:bg-gray-100 rounded-r-md hover:bg-gray-800 dark:hover:bg-gray-200 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                          children: [
                            e.jsx(te, {
                              className: `w-3.5 h-3.5 ${p ? "animate-spin" : ""}`
                            }),
                            p ? "Scanning..." : "Scan"
                          ]
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            d.length > 0 && e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs("div", {
                  className: "relative flex-1",
                  children: [
                    e.jsx(Me, {
                      className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                    }),
                    e.jsx("input", {
                      type: "text",
                      value: O,
                      onChange: (t) => K(t.target.value),
                      placeholder: "Search podcasts...",
                      className: "w-full pl-8 pr-7 py-1.5 rounded-md border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-800 dark:text-slate-100"
                    }),
                    O && e.jsx("button", {
                      onClick: () => K(""),
                      className: "absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300",
                      children: e.jsx(Re, {
                        className: "w-3.5 h-3.5"
                      })
                    })
                  ]
                }),
                e.jsx("select", {
                  value: T,
                  onChange: (t) => V(t.target.value),
                  title: "Filter by status",
                  className: ce,
                  children: bt.map((t) => e.jsx("option", {
                    value: t.value,
                    children: t.label
                  }, t.value))
                }),
                e.jsx("select", {
                  value: F,
                  onChange: (t) => H(t.target.value),
                  title: "Filter by ownership",
                  className: ce,
                  children: ft.map((t) => e.jsx("option", {
                    value: t.value,
                    children: t.label
                  }, t.value))
                })
              ]
            }),
            p && w.total > 0 && e.jsxs("div", {
              className: "bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg p-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between mb-1",
                  children: [
                    e.jsxs("span", {
                      className: "text-xs text-gray-600 dark:text-slate-400",
                      children: [
                        "Scanning notebooks... (",
                        w.current,
                        "/",
                        w.total,
                        ")"
                      ]
                    }),
                    e.jsxs("span", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: [
                        Math.round(w.current / w.total * 100),
                        "%"
                      ]
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "h-1.5 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden",
                  children: e.jsx("div", {
                    className: "h-full bg-gray-900 dark:bg-gray-100 rounded-full transition-all",
                    style: {
                      width: `${w.current / w.total * 100}%`
                    }
                  })
                })
              ]
            }),
            L.isDownloading && L.total > 0 && e.jsxs("div", {
              className: "bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between mb-1",
                  children: [
                    e.jsxs("span", {
                      className: "text-xs text-blue-700 dark:text-blue-300",
                      children: [
                        "Downloading... (",
                        L.current,
                        "/",
                        L.total,
                        ")"
                      ]
                    }),
                    e.jsxs("span", {
                      className: "text-xs text-blue-600 dark:text-blue-400",
                      children: [
                        Math.round(L.current / L.total * 100),
                        "%"
                      ]
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "h-1.5 bg-blue-200 dark:bg-blue-900 rounded-full overflow-hidden",
                  children: e.jsx("div", {
                    className: "h-full bg-blue-600 dark:bg-blue-400 rounded-full transition-all",
                    style: {
                      width: `${L.current / L.total * 100}%`
                    }
                  })
                })
              ]
            }),
            Z && e.jsxs("div", {
              className: "flex items-center justify-between bg-neutral-50 dark:bg-slate-900 border border-neutral-200 dark:border-slate-700 rounded-lg p-2 px-3 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("div", {
                      className: "flex items-center justify-center w-5 h-5 rounded-full bg-neutral-200 dark:bg-slate-700",
                      children: e.jsx("span", {
                        className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
                        children: C.size
                      })
                    }),
                    e.jsx("span", {
                      className: "text-xs text-neutral-600 dark:text-slate-400",
                      children: "selected"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("button", {
                      onClick: () => g(/* @__PURE__ */ new Set()),
                      className: "px-2.5 py-1 text-xs font-medium text-neutral-600 dark:text-slate-400 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 shadow-sm dark:shadow-slate-900/30",
                      children: "Clear"
                    }),
                    e.jsxs("button", {
                      onClick: G,
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-neutral-600 dark:text-slate-400 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(ke, {
                          className: "w-3.5 h-3.5"
                        }),
                        A ? "Mark unlistened" : "Mark listened"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => $(I),
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(pe, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Delete"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: Ce,
                      disabled: L.isDownloading,
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white dark:text-gray-900 bg-neutral-900 dark:bg-gray-100 rounded-md hover:bg-neutral-800 dark:hover:bg-gray-200 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(ae, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Download Selected"
                      ]
                    })
                  ]
                })
              ]
            }),
            M && e.jsx("div", {
              className: "bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-3 py-2 rounded-lg text-xs",
              children: M
            }),
            oe ? e.jsx(e.Fragment, {
              children: p && d.length === 0 ? e.jsx("div", {
                className: "flex flex-col items-center justify-center w-full py-12 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
                children: e.jsx(Ze, {
                  text: "Scanning notebooks for audio..."
                })
              }) : d.length > 0 && J.length === 0 ? e.jsxs("div", {
                className: "flex flex-col items-center justify-center py-12 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
                children: [
                  e.jsx("h3", {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: "No podcasts match your search"
                  }),
                  e.jsx("button", {
                    onClick: () => {
                      K(""), V("all"), H("all");
                    },
                    className: "mt-2 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline",
                    children: "Clear filters"
                  })
                ]
              }) : d.length > 0 ? e.jsx("div", {
                className: "bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg divide-y divide-gray-100 dark:divide-slate-700",
                children: J.map((t) => e.jsxs("div", {
                  className: "p-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center justify-between px-2 py-1 mb-1",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-1.5 min-w-0 flex-1",
                          children: [
                            e.jsx("input", {
                              type: "checkbox",
                              className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 focus:ring-1 cursor-pointer flex-shrink-0",
                              checked: t.items.every((n) => C.has(n.id)),
                              onChange: () => le(t)
                            }),
                            e.jsx("span", {
                              className: "text-sm flex-shrink-0",
                              children: t.notebookEmoji
                            }),
                            e.jsx("span", {
                              className: "text-xs font-medium text-gray-700 dark:text-slate-300 truncate min-w-0",
                              children: t.notebookTitle
                            }),
                            e.jsxs("span", {
                              className: "text-xs text-gray-400 dark:text-slate-500 flex-shrink-0",
                              children: [
                                "(",
                                t.items.length,
                                ")"
                              ]
                            }),
                            e.jsx("span", {
                              className: "flex-shrink-0",
                              children: e.jsx(Ke, {
                                code: t.permissionCode,
                                size: "sm"
                              })
                            })
                          ]
                        }),
                        e.jsxs("div", {
                          className: "flex items-center gap-1 flex-shrink-0",
                          children: [
                            e.jsx("button", {
                              onClick: () => i(`/notebook/${t.notebookId}`),
                              className: "p-1.5 rounded-md hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100",
                              title: "Open notebook details",
                              children: e.jsx(qe, {
                                className: "h-3.5 w-3.5"
                              })
                            }),
                            e.jsxs("button", {
                              onClick: () => Se(t),
                              disabled: L.isDownloading,
                              className: "flex items-center gap-1 p-1.5 px-2 rounded-md hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 disabled:opacity-50",
                              title: "Download all as ZIP",
                              children: [
                                L.notebookId === t.notebookId ? e.jsx(te, {
                                  className: "h-3.5 w-3.5 animate-spin"
                                }) : e.jsx(ae, {
                                  className: "h-3.5 w-3.5"
                                }),
                                e.jsx("span", {
                                  className: "text-xs font-medium",
                                  children: "ZIP"
                                })
                              ]
                            }),
                            e.jsxs("a", {
                              href: Ve(t.notebookId, Y),
                              target: "_blank",
                              rel: "noopener noreferrer",
                              className: "flex items-center gap-1.5 p-1.5 px-2 rounded-md hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100",
                              title: "Open in NotebookLM",
                              children: [
                                e.jsx(Fe, {
                                  className: "h-3.5 w-3.5"
                                }),
                                e.jsx("span", {
                                  className: "text-xs font-medium",
                                  children: "NotebookLM"
                                }),
                                e.jsx(Pe, {
                                  className: "h-3 w-3"
                                })
                              ]
                            })
                          ]
                        })
                      ]
                    }),
                    t.items.map((n) => {
                      var _a2, _b2;
                      return e.jsx(mt, {
                        audio: n,
                        isPlaying: R && v === n.globalIndex,
                        isCurrent: v === n.globalIndex,
                        progress: ((_a2 = f[n.id]) == null ? void 0 : _a2.progress) || 0,
                        isListened: ((_b2 = f[n.id]) == null ? void 0 : _b2.isListened) || false,
                        onClick: () => Q(n.globalIndex),
                        onToggleListened: (u) => r.toggleListened(u),
                        onDelete: () => $([
                          n
                        ]),
                        isSelected: C.has(n.id),
                        isSelecting: Z,
                        onSelect: () => se(n.id)
                      }, n.id);
                    })
                  ]
                }, t.notebookId))
              }) : e.jsxs("div", {
                className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
                children: [
                  e.jsx("div", {
                    className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
                    children: e.jsx(ue, {
                      className: "h-6 w-6 text-gray-400 dark:text-slate-500"
                    })
                  }),
                  e.jsx("h3", {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: "No audio found"
                  }),
                  e.jsx("p", {
                    className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center mb-4",
                    children: 'Click "Scan All Notebooks" to find Audio Overviews from your notebooks.'
                  })
                ]
              })
            }) : e.jsxs("div", {
              className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
              children: [
                e.jsx("h3", {
                  className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                  children: "Connect NotebookLM"
                }),
                e.jsx("p", {
                  className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center",
                  children: "Connect your NotebookLM account to access your Audio Overviews."
                })
              ]
            })
          ]
        }),
        e.jsx(ht, {
          isOpen: !!W,
          items: W || [],
          onClose: () => $(null),
          onConfirm: P
        }),
        e.jsx(ut, {
          audio: h,
          isPlaying: R,
          progress: h && ((_b = f[h.id]) == null ? void 0 : _b.progress) || 0,
          onPlay: U,
          onPause: ee,
          onEnded: z,
          onTimeUpdate: xe,
          onNext: ve,
          onPrevious: ye,
          onRefreshUrl: je,
          hasNext: v < d.length - 1,
          hasPrevious: v > 0
        })
      ]
    });
  };
});
export {
  __tla,
  Dt as default
};
