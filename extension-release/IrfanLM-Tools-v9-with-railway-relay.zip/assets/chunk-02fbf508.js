import { u as R, r as g, j as e, X as T, J as m, U as $, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as j, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { D as I, __tla as __tla_2 } from "./chunk-bd7b16ee.js";
import { i as z, z as W, Q as D, __tla as __tla_3 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_4 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let Z;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  const M = 49e4, r = {
    CONFIG: "config",
    FETCHING: "fetching",
    PREVIEW: "preview"
  };
  Z = function({ isOpen: u, onClose: k, notebook: c, selectedSources: d = [], onSuccess: E }) {
    const [F, t] = R(), { sourceMerge: S } = F, { isMerging: n, progress: a, mergeOptions: L, fetchedContents: N, mergedContent: b, contentSize: h, exceedsLimit: V } = S, [l, i] = g.useState(r.CONFIG), [p, v] = g.useState("Merged Sources"), [o, w] = g.useState(false);
    g.useEffect(() => {
      u && (i(r.CONFIG), v("Merged Sources"), w(false), t.resetSourceMerge());
    }, [
      u
    ]);
    const O = async () => {
      if (d.length < 2) {
        m.error("Select at least 2 sources to merge");
        return;
      }
      t.setMergeOptions({
        mergedTitle: p,
        deleteOriginals: o
      }), t.setIsMerging(true), i(r.FETCHING);
      try {
        await t.fetchSourceContents(d, c.id), t.generateMergedContent(), i(r.PREVIEW);
      } catch (s) {
        m.error(`Failed to fetch sources: ${s.message}`), i(r.CONFIG);
      } finally {
        t.setIsMerging(false);
      }
    }, G = async () => {
      t.setIsMerging(true);
      try {
        if (await t.executeMerge(c.id), o) {
          const s = d.map((y) => y.id);
          await t.deleteOriginalSources(s, c.id), await t.bulkRemoveFromFolder(c.id, s);
        }
        m.success("Sources merged successfully"), $(() => t.isLicensed()), t.resetSourceMerge(), E == null ? void 0 : E(), k();
      } catch (s) {
        m.error(`Failed to merge: ${s.message}`);
      } finally {
        t.setIsMerging(false);
      }
    }, f = () => {
      n || (t.resetSourceMerge(), k());
    }, C = (s) => s < 1e3 ? `${s} chars` : s < 1e6 ? `${(s / 1e3).toFixed(1)}K chars` : `${(s / 1e6).toFixed(2)}M chars`, P = a.total > 0 ? Math.round(a.current / a.total * 100) : 0, x = h > 0 ? Math.ceil(h / M) : 1;
    return e.jsxs(z, {
      open: u,
      onClose: f,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(W, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(D, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(I, {
                        className: "w-4 h-4"
                      }),
                      "Merge Sources"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: f,
                    disabled: n,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(T, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "px-4 pt-3",
                children: e.jsxs("div", {
                  className: "flex items-center gap-2 text-xs",
                  children: [
                    e.jsx("span", {
                      className: `px-2 py-0.5 rounded-full ${l === r.CONFIG ? "bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900" : "bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-slate-400"}`,
                      children: "1. Configure"
                    }),
                    e.jsx("span", {
                      className: "text-gray-300 dark:text-slate-600",
                      children: "\u2192"
                    }),
                    e.jsx("span", {
                      className: `px-2 py-0.5 rounded-full ${l === r.FETCHING ? "bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900" : "bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-slate-400"}`,
                      children: "2. Fetch"
                    }),
                    e.jsx("span", {
                      className: "text-gray-300 dark:text-slate-600",
                      children: "\u2192"
                    }),
                    e.jsx("span", {
                      className: `px-2 py-0.5 rounded-full ${l === r.PREVIEW ? "bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900" : "bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-slate-400"}`,
                      children: "3. Preview"
                    })
                  ]
                })
              }),
              e.jsxs("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: [
                  l === r.CONFIG && e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      e.jsxs("div", {
                        children: [
                          e.jsx("label", {
                            className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                            children: "Merged Source Title"
                          }),
                          e.jsx("input", {
                            type: "text",
                            value: p,
                            onChange: (s) => v(s.target.value),
                            placeholder: "Enter title for merged source",
                            className: "w-full px-3 py-2 text-xs border border-gray-300 dark:border-gray-600 dark:bg-slate-700 dark:text-slate-100 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx("input", {
                            type: "checkbox",
                            id: "deleteOriginals",
                            checked: o,
                            onChange: (s) => w(s.target.checked),
                            className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-gray-900"
                          }),
                          e.jsx("label", {
                            htmlFor: "deleteOriginals",
                            className: "text-xs text-gray-700 dark:text-slate-300",
                            children: "Delete original sources after merge"
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border border-gray-200 dark:border-slate-700",
                        children: [
                          e.jsxs("h4", {
                            className: "text-xs font-medium text-gray-900 dark:text-slate-100 mb-2",
                            children: [
                              "Sources to Merge (",
                              d.length,
                              ")"
                            ]
                          }),
                          e.jsx("div", {
                            className: "max-h-32 overflow-y-auto space-y-1",
                            children: d.map((s, y) => e.jsxs("div", {
                              className: "text-xs text-gray-600 dark:text-slate-400 flex items-start gap-1",
                              children: [
                                e.jsxs("span", {
                                  className: "text-gray-400 dark:text-slate-500 w-4 shrink-0",
                                  children: [
                                    y + 1,
                                    "."
                                  ]
                                }),
                                e.jsx("span", {
                                  className: "truncate",
                                  children: s.title || "Untitled"
                                })
                              ]
                            }, s.id))
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "text-xs text-gray-500 dark:text-slate-400 space-y-1",
                        children: [
                          e.jsx("p", {
                            children: "Each source will be separated by a header with title and URL."
                          }),
                          e.jsxs("p", {
                            className: "text-blue-600",
                            children: [
                              "Note: Large content will be split into multiple sources (",
                              C(M),
                              " each)."
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  l === r.FETCHING && e.jsx("div", {
                    className: "space-y-4",
                    children: e.jsxs("div", {
                      className: "bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-2 mb-3",
                          children: [
                            e.jsx(j, {
                              size: "sm"
                            }),
                            e.jsx("span", {
                              className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                              children: a.message || "Fetching sources..."
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "w-full bg-blue-200 rounded-full h-2",
                          children: e.jsx("div", {
                            className: "bg-blue-600 h-2 rounded-full transition-all duration-300",
                            style: {
                              width: `${P}%`
                            }
                          })
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-blue-600 dark:text-blue-400 mt-2",
                          children: [
                            a.current,
                            " / ",
                            a.total,
                            " sources"
                          ]
                        })
                      ]
                    })
                  }),
                  l === r.PREVIEW && e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      e.jsxs("div", {
                        className: "bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border border-gray-200 dark:border-slate-700",
                        children: [
                          e.jsx("h4", {
                            className: "text-xs font-medium text-gray-900 dark:text-slate-100 mb-2",
                            children: "What will happen:"
                          }),
                          e.jsxs("ul", {
                            className: "text-xs text-gray-600 dark:text-slate-400 space-y-1.5",
                            children: [
                              e.jsxs("li", {
                                className: "flex items-start gap-1.5",
                                children: [
                                  e.jsx("span", {
                                    className: "text-gray-400 dark:text-slate-500",
                                    children: "\u2022"
                                  }),
                                  e.jsxs("span", {
                                    children: [
                                      d.length,
                                      " sources \u2192 ",
                                      x,
                                      " merged source",
                                      x > 1 ? "s" : ""
                                    ]
                                  })
                                ]
                              }),
                              e.jsxs("li", {
                                className: "flex items-start gap-1.5",
                                children: [
                                  e.jsx("span", {
                                    className: "text-gray-400 dark:text-slate-500",
                                    children: "\u2022"
                                  }),
                                  e.jsxs("span", {
                                    children: [
                                      "Total content: ",
                                      C(h)
                                    ]
                                  })
                                ]
                              }),
                              N.filter((s) => s.error).length > 0 && e.jsxs("li", {
                                className: "flex items-start gap-1.5 text-amber-600",
                                children: [
                                  e.jsx("span", {
                                    children: "\u2022"
                                  }),
                                  e.jsxs("span", {
                                    children: [
                                      N.filter((s) => s.error).length,
                                      " source(s) had no extractable content"
                                    ]
                                  })
                                ]
                              }),
                              x > 1 && e.jsxs("li", {
                                className: "flex items-start gap-1.5 text-blue-600",
                                children: [
                                  e.jsx("span", {
                                    children: "\u2022"
                                  }),
                                  e.jsxs("span", {
                                    children: [
                                      "Content will be split into ",
                                      x,
                                      " parts"
                                    ]
                                  })
                                ]
                              }),
                              o && e.jsxs("li", {
                                className: "flex items-start gap-1.5 text-red-600 font-medium",
                                children: [
                                  e.jsx("span", {
                                    children: "\u2022"
                                  }),
                                  e.jsxs("span", {
                                    children: [
                                      "Original ",
                                      d.length,
                                      " sources will be permanently deleted"
                                    ]
                                  })
                                ]
                              })
                            ]
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx("h4", {
                            className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-2",
                            children: "Content Preview"
                          }),
                          e.jsx("div", {
                            className: "bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg p-3 max-h-48 overflow-y-auto",
                            children: e.jsxs("pre", {
                              className: "text-xs text-gray-600 dark:text-slate-400 whitespace-pre-wrap font-mono",
                              children: [
                                b == null ? void 0 : b.substring(0, 2e3),
                                (b == null ? void 0 : b.length) > 2e3 && `

... (preview truncated)`
                              ]
                            })
                          })
                        ]
                      }),
                      a.phase === "uploading" && e.jsx("div", {
                        className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                        children: e.jsxs("div", {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsx(j, {
                              size: "sm"
                            }),
                            e.jsx("span", {
                              className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                              children: a.message
                            })
                          ]
                        })
                      }),
                      a.phase === "deleting" && e.jsx("div", {
                        className: "bg-amber-50 dark:bg-amber-950 p-3 rounded-lg border border-amber-200 dark:border-amber-800",
                        children: e.jsxs("div", {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsx(j, {
                              size: "sm"
                            }),
                            e.jsx("span", {
                              className: "text-xs font-medium text-amber-700 dark:text-amber-200",
                              children: a.message
                            })
                          ]
                        })
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-between",
                children: [
                  e.jsx("div", {
                    children: l === r.PREVIEW && !n && e.jsx("button", {
                      onClick: () => i(r.CONFIG),
                      className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                      children: "Back"
                    })
                  }),
                  e.jsxs("div", {
                    className: "flex gap-2",
                    children: [
                      e.jsx("button", {
                        onClick: f,
                        disabled: n,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                        children: "Cancel"
                      }),
                      l === r.CONFIG && e.jsx("button", {
                        onClick: O,
                        disabled: d.length < 2 || !p.trim(),
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                        children: "Fetch Content"
                      }),
                      l === r.PREVIEW && e.jsxs("button", {
                        onClick: G,
                        disabled: n || !b,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                        children: [
                          e.jsx(I, {
                            className: "w-3.5 h-3.5"
                          }),
                          n ? "Merging..." : "Merge Sources"
                        ]
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  Z as default
};
