import { j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { E as s, __tla as __tla_1 } from "./chunk-2a4ab792.js";
let m;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  m = function({ compact: a = false }) {
    const r = e.jsx("a", {
      href: "#/backup",
      className: "underline hover:text-amber-700 dark:hover:text-amber-300",
      children: "backups"
    });
    return a ? e.jsxs("p", {
      className: "text-xs text-amber-600 dark:text-amber-400",
      children: [
        "Tags, folders, prompts, and settings from this extension are stored in your browser only and may be lost if the extension is removed. We recommend regular ",
        r,
        "."
      ]
    }) : e.jsxs("div", {
      className: "flex items-start gap-2 rounded-md bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 px-3 py-2",
      children: [
        e.jsx(s, {
          className: "w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0 mt-0.5"
        }),
        e.jsxs("p", {
          className: "text-xs text-amber-600 dark:text-amber-400",
          children: [
            "Tags, folders, prompts, and settings from this extension are stored in your browser only and may be lost if the extension is removed. We recommend regular ",
            r,
            "."
          ]
        })
      ]
    });
  };
});
export {
  m as L,
  __tla
};
