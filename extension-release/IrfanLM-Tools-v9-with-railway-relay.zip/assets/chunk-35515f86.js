import { j as e, u as G, r as u, P as z, x as R, h as H, X as ne, a0 as M, c as le, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { t as K, w as J, x as U, S as v, y as C, n as Z, B as oe, G as de, J as ce, M as ie, O as xe, V as ue, R as ee, U as be, W as he, X as me, b as X, d as Y, Y as ge, Z as ke, _ as je, $ as pe, a0 as fe, a1 as ye, a2 as Q, a3 as q, a4 as O, P as $, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { C as Ne, __tla as __tla_2 } from "./chunk-9b02a51a.js";
import { P as we, F as Se, __tla as __tla_3 } from "./chunk-602992a9.js";
import { g as Ae, a as Le, r as ve } from "./chunk-e3c02cf0.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let Ue;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  let te, Te, Pe, Ce, De, Ee;
  te = ({ title: t, url: b, label: i = "URL" }) => !t && !b ? null : e.jsxs("div", {
    className: "bg-neutral-50 dark:bg-slate-900 rounded px-3 py-2 border border-neutral-200 dark:border-neutral-700",
    children: [
      e.jsx("p", {
        className: "text-xs font-medium text-neutral-900 dark:text-neutral-100 truncate",
        children: t
      }),
      b && e.jsx("p", {
        className: "text-xs text-neutral-500 dark:text-neutral-400 truncate mt-0.5",
        children: b
      })
    ]
  });
  Te = ({ pendingAction: t, onSuccess: b }) => {
    const [i, a] = G(), { projects: s = [], selectedProject: x, query: D } = i.notebooklm || {}, [r, l] = u.useState(false), [j, c] = u.useState(false), { alsoGenerateProps: h, generateConfig: w } = K(), { isAdding: o, progressMessage: m, progressPercent: p } = i.notebookActions, f = async () => {
      const g = E();
      if (g)
        try {
          await navigator.clipboard.writeText(g), c(true), setTimeout(() => c(false), 2e3);
        } catch (y) {
          console.error("Failed to copy:", y);
        }
    }, S = async (g) => {
      const { type: y, data: L } = t;
      if (y === "ADD_PAGE" || y === "ADD_LINK") {
        const N = {
          url: L.url,
          title: y === "ADD_PAGE" ? L.title : L.selectionText || L.url
        };
        return a.addToNotebook(N, g, {
          generateConfig: w
        });
      }
      return a.addTextContentToNotebook(L.text, g, {
        generateConfig: w
      });
    }, A = async (g) => {
      if (t)
        try {
          await S(g) && (b == null ? void 0 : b(), await R("feature_used"), window.close());
        } catch (y) {
          console.error("Error adding to notebook:", y);
        }
    };
    if (!t)
      return null;
    const { type: n, data: d } = t, T = n === "ADD_PAGE" || n === "ADD_LINK" ? d.url : d.pageUrl, E = () => n === "ADD_TEXT" ? d.text : `URL will be added to NotebookLM:
${T}`, P = E(), I = !!P;
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1",
              children: "URL"
            }),
            e.jsx(te, {
              title: n === "ADD_PAGE" ? d.title : n === "ADD_LINK" ? d.selectionText || d.url : d.pageTitle,
              url: n === "ADD_PAGE" || n === "ADD_LINK" ? d.url : d.pageUrl
            })
          ]
        }),
        e.jsxs("div", {
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between mb-1",
              children: [
                e.jsx("label", {
                  className: "block text-xs font-medium text-neutral-700 dark:text-neutral-300",
                  children: "Content"
                }),
                I && e.jsx("button", {
                  onClick: f,
                  className: "flex items-center gap-1 text-xs text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300",
                  children: j ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(J, {
                        className: "w-3 h-3 text-green-600"
                      }),
                      e.jsx("span", {
                        className: "text-green-600",
                        children: "Copied"
                      })
                    ]
                  }) : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(Ne, {
                        className: "w-3 h-3"
                      }),
                      e.jsx("span", {
                        children: "Copy"
                      })
                    ]
                  })
                })
              ]
            }),
            e.jsx("div", {
              className: "bg-neutral-50 dark:bg-slate-900 rounded px-3 py-2 border border-neutral-200 dark:border-neutral-700 max-h-64 overflow-y-auto",
              children: e.jsx("pre", {
                className: "text-xs whitespace-pre-wrap break-words text-neutral-700 dark:text-neutral-300",
                children: P
              })
            }),
            P && e.jsxs("p", {
              className: "text-xs text-neutral-500 dark:text-neutral-400 mt-1",
              children: [
                P.length,
                " characters"
              ]
            })
          ]
        }),
        e.jsx(U, {
          ...h,
          disabled: o,
          isExistingNotebook: r && !!x
        }),
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            o && m && e.jsx(v, {
              type: "progress",
              message: m,
              progress: p
            }),
            e.jsx(C, {
              onClick: () => A(null),
              disabled: o,
              isLoading: o,
              loadingText: "Creating...",
              children: "Create new notebook"
            }),
            r ? e.jsxs("div", {
              className: "space-y-2 p-2.5 bg-gray-50 dark:bg-slate-900 rounded-lg border border-gray-200 dark:border-slate-700",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between mb-1",
                  children: [
                    e.jsx("label", {
                      className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                      children: "Select notebook"
                    }),
                    e.jsx("button", {
                      onClick: () => l(false),
                      disabled: o,
                      className: "text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 disabled:opacity-50",
                      children: "Cancel"
                    })
                  ]
                }),
                e.jsx(Z, {
                  projects: s,
                  selectedProject: x,
                  onSelectProject: a.setSelectedProject,
                  query: D,
                  onQueryChange: a.setQuery,
                  onClose: () => a.setQuery("")
                }),
                x && e.jsx("div", {
                  className: "px-2 py-1.5 bg-white dark:bg-slate-800 rounded border border-gray-200 dark:border-slate-700",
                  children: e.jsx("p", {
                    className: "text-xs text-gray-600 dark:text-slate-400 truncate",
                    children: e.jsx("span", {
                      className: "font-medium text-gray-900 dark:text-slate-100",
                      children: x.title
                    })
                  })
                }),
                e.jsx(C, {
                  onClick: () => A(x == null ? void 0 : x.id),
                  disabled: o || !x,
                  isLoading: o,
                  loadingText: "Adding...",
                  icon: z,
                  children: "Add to notebook"
                })
              ]
            }) : e.jsx(C, {
              onClick: () => l(true),
              disabled: o || s.length === 0,
              variant: "secondary",
              children: "Add to existing notebook"
            })
          ]
        })
      ]
    });
  };
  Pe = ({ pendingAction: t, onSuccess: b }) => {
    var _a, _b, _c;
    const [i, a] = G(), { projects: s = [], selectedBatchProject: x, batchQuery: D } = i.notebooklm || {}, { isExtracting: r, links: l, error: j } = i.linksExtractor, { isAdding: c, addSuccess: h, actionType: w, error: o, progressMessage: m, progressPercent: p, failedLinks: f, totalLinks: S } = i.batchNotebookActions, [A, n] = u.useState(""), [d, T] = u.useState(""), [E, P] = u.useState(false), [I, g] = u.useState(false), { alsoGenerateProps: y, generateConfig: L } = K();
    u.useEffect(() => {
      l.length > 0 && n(l.join(`
`));
    }, [
      l
    ]), u.useEffect(() => {
      var _a2;
      if ((_a2 = t == null ? void 0 : t.data) == null ? void 0 : _a2.url) {
        const k = t.data.url.toLowerCase(), _ = k.includes("sitemap") && k.endsWith(".xml");
        P(_);
      }
    }, [
      (_a = t == null ? void 0 : t.data) == null ? void 0 : _a.url
    ]), u.useEffect(() => {
      (t == null ? void 0 : t.data) && !r && l.length === 0 && N();
    }, [
      (_b = t == null ? void 0 : t.data) == null ? void 0 : _b.tabId,
      (_c = t == null ? void 0 : t.data) == null ? void 0 : _c.url
    ]);
    const N = async () => {
      var _a2;
      if (!(t == null ? void 0 : t.data))
        return;
      const k = ((_a2 = t.data.url) == null ? void 0 : _a2.toLowerCase()) || "";
      k.includes("sitemap") && k.endsWith(".xml") && t.data.url ? await a.extractFromSitemap(t.data.url) : t.data.tabId && await a.extractLinks(t.data.tabId);
    }, F = (k) => {
      a.setLinks(k);
    }, B = (k) => {
      n(k.join(`
`)), a.setLinks(k);
    }, se = async () => {
      const k = A.split(`
`).filter((_) => _.trim());
      k.length > 0 && (await a.addLinksToNotebook(k, null, {
        generateConfig: L
      }), await R("feature_used"));
    }, ae = async () => {
      const k = A.split(`
`).filter((_) => _.trim());
      k.length > 0 && x && await a.addLinksToNotebook(k, x.id, {
        generateConfig: L
      }) && (await R("feature_used"), setTimeout(() => {
        b == null ? void 0 : b(), window.close();
      }, 1500));
    };
    if (!t)
      return null;
    const { data: V } = t, W = d === "" ? l : oe(l, d), re = d === "" ? A : W.join(`
`);
    return e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-900 dark:text-neutral-100 mb-1.5",
              children: "Source"
            }),
            e.jsx(te, {
              title: V.title,
              url: V.url
            })
          ]
        }),
        E && !r && l.length === 0 && e.jsxs("div", {
          className: "px-2.5 py-2 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800",
          children: [
            e.jsx("p", {
              className: "text-xs text-blue-700 dark:text-blue-300 font-medium",
              children: "Sitemap detected"
            }),
            e.jsx("p", {
              className: "text-xs text-blue-600 dark:text-blue-400 mt-0.5",
              children: "Ready to extract all URLs"
            })
          ]
        }),
        r && e.jsx("div", {
          className: "px-2.5 py-2 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800",
          children: e.jsx("p", {
            className: "text-xs text-blue-700 dark:text-blue-300 font-medium",
            children: E ? "Extracting from sitemap..." : "Extracting links..."
          })
        }),
        j && e.jsx(v, {
          type: "error",
          message: j
        }),
        l.length === 0 && !r && e.jsx(C, {
          onClick: N,
          variant: "secondary",
          icon: H,
          children: "Extract links"
        }),
        l.length > 0 && e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx("div", {
              className: "flex items-center justify-between",
              children: e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx("label", {
                    className: "text-xs font-medium text-neutral-900 dark:text-neutral-100",
                    children: "Extracted Links"
                  }),
                  e.jsx("span", {
                    className: "px-1.5 py-0.5 bg-neutral-100 dark:bg-slate-700 rounded text-xs font-medium text-neutral-700 dark:text-neutral-300",
                    children: d === "" ? l.length : W.length
                  })
                ]
              })
            }),
            !r && e.jsx(de, {
              links: l,
              linkFilter: d,
              setLinkFilter: T,
              onApplyFilter: B,
              disabled: c
            }),
            e.jsx(ce, {
              links: l,
              linksText: re,
              setLinksText: n,
              onLinksChange: F,
              disabled: c || d !== "" || r,
              placeholder: r ? "Extracting links..." : "Links will appear here...",
              rows: 8,
              showTools: l.length > 0
            })
          ]
        }),
        l.length > 0 && !r && e.jsxs("div", {
          className: "pt-2 border-t border-neutral-200 dark:border-neutral-700 space-y-3",
          children: [
            c && m && e.jsx(v, {
              type: "progress",
              message: m,
              progress: p
            }),
            h && e.jsx("div", {
              className: "px-2.5 py-2 bg-green-50 dark:bg-green-950 rounded-md border border-green-200 dark:border-green-800",
              children: e.jsxs("div", {
                className: "flex items-start gap-2",
                children: [
                  e.jsx(J, {
                    className: "w-4 h-4 text-green-600 flex-shrink-0"
                  }),
                  e.jsxs("div", {
                    className: "flex-1 min-w-0",
                    children: [
                      e.jsx("p", {
                        className: "text-xs font-medium text-green-900 dark:text-green-300",
                        children: w === "new" ? "Notebook created" : "Links added successfully"
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-green-700 dark:text-green-300 mt-0.5",
                        children: [
                          S - ((f == null ? void 0 : f.length) || 0),
                          " of ",
                          S,
                          " links processed",
                          (f == null ? void 0 : f.length) > 0 && ` \xB7 ${f.length} failed`
                        ]
                      })
                    ]
                  })
                ]
              })
            }),
            o && e.jsx(v, {
              type: "error",
              message: o
            }),
            !h && e.jsx(U, {
              ...y,
              disabled: c,
              isExistingNotebook: I && !!x
            }),
            !h && e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsx(C, {
                  onClick: se,
                  disabled: c,
                  isLoading: c && w === "new",
                  loadingText: "Creating notebook...",
                  children: "Create new notebook"
                }),
                I ? e.jsxs("div", {
                  className: "space-y-2 p-3 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-neutral-700",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center justify-between",
                      children: [
                        e.jsx("label", {
                          className: "text-xs font-medium text-neutral-900 dark:text-neutral-100",
                          children: "Select notebook"
                        }),
                        e.jsx("button", {
                          onClick: () => {
                            g(false), a.setSelectedBatchProject(null);
                          },
                          disabled: c,
                          className: "text-xs font-medium text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 disabled:opacity-50",
                          children: "Cancel"
                        })
                      ]
                    }),
                    e.jsx(Z, {
                      projects: s,
                      selectedProject: x,
                      onSelectProject: a.setSelectedBatchProject,
                      query: D,
                      onQueryChange: a.setBatchQuery,
                      onClose: () => a.setBatchQuery("")
                    }),
                    x && e.jsxs("div", {
                      className: "px-2.5 py-2 bg-white dark:bg-slate-800 rounded-md border border-neutral-200 dark:border-neutral-700",
                      children: [
                        e.jsx("p", {
                          className: "text-xs text-neutral-500 dark:text-neutral-400",
                          children: "Selected"
                        }),
                        e.jsx("p", {
                          className: "text-xs font-medium text-neutral-900 dark:text-neutral-100 truncate mt-0.5",
                          children: x.title
                        })
                      ]
                    }),
                    e.jsxs(C, {
                      onClick: ae,
                      disabled: c || !x,
                      isLoading: c && w === "existing",
                      loadingText: "Adding links...",
                      icon: z,
                      children: [
                        "Add ",
                        l.length,
                        " ",
                        l.length === 1 ? "link" : "links"
                      ]
                    })
                  ]
                }) : e.jsx("button", {
                  onClick: () => g(true),
                  disabled: c || s.length === 0,
                  className: "w-full px-3 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 bg-white dark:bg-slate-800 border border-neutral-300 dark:border-neutral-600 rounded-md hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed",
                  children: s.length === 0 ? "No notebooks available" : "Add to existing notebook"
                })
              ]
            })
          ]
        })
      ]
    });
  };
  Ce = ({ pendingAction: t, onSuccess: b }) => {
    var _a;
    const [i, a] = G(), [s, x] = u.useState(false), { projects: D = [], selectedBatchProject: r, batchQuery: l } = i.notebooklm || {}, { isParsing: j, parseError: c, videos: h, playlistInfo: w } = i.playlistImport, { isAdding: o, addSuccess: m, actionType: p, error: f, progressMessage: S, progressPercent: A, failedLinks: n, totalLinks: d } = i.batchNotebookActions, { selectedVideoIds: T, addToNewNotebook: E, addToExistingNotebook: P } = ie(), { alsoGenerateProps: I, generateConfig: g } = K();
    u.useEffect(() => {
      var _a2;
      ((_a2 = t == null ? void 0 : t.data) == null ? void 0 : _a2.url) && !h.length && !j && a.parsePlaylist(t.data.url);
    }, [
      (_a = t == null ? void 0 : t.data) == null ? void 0 : _a.url
    ]), u.useEffect(() => () => {
      a.resetPlaylistImport();
    }, []);
    const y = async () => {
      await E(g) && (await R("feature_used"), setTimeout(() => {
        b == null ? void 0 : b(), window.close();
      }, 1500));
    }, L = async () => {
      r && await P(r.id, g) && (await R("feature_used"), setTimeout(() => {
        b == null ? void 0 : b(), window.close();
      }, 1500));
    };
    if (!t)
      return null;
    const { data: N } = t, F = T.length > 0;
    return e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-900 dark:text-neutral-100 mb-1.5",
              children: "Source"
            }),
            e.jsxs("div", {
              className: "px-2.5 py-2 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-neutral-700",
              children: [
                e.jsx("p", {
                  className: "text-xs text-neutral-600 dark:text-neutral-400 truncate",
                  children: N.title || N.url
                }),
                e.jsx("p", {
                  className: "text-xs text-neutral-400 dark:text-neutral-500 truncate mt-0.5",
                  children: N.url
                })
              ]
            })
          ]
        }),
        j && e.jsx(v, {
          type: "progress",
          message: "Parsing playlist..."
        }),
        c && e.jsx(v, {
          type: "error",
          message: c
        }),
        w && h.length > 0 && e.jsxs(e.Fragment, {
          children: [
            e.jsx(xe, {}),
            e.jsx(ue, {})
          ]
        }),
        F && !j && e.jsxs("div", {
          className: "pt-2 border-t border-neutral-200 dark:border-neutral-700 space-y-3",
          children: [
            o && S && e.jsx(v, {
              type: "progress",
              message: S,
              progress: A
            }),
            m && e.jsx(we, {
              actionType: p,
              totalLinks: d,
              failedLinks: n
            }),
            f && e.jsx(v, {
              type: "error",
              message: f
            }),
            !m && e.jsx(U, {
              ...I,
              disabled: o,
              isExistingNotebook: s && !!r
            }),
            !m && e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsxs(C, {
                  onClick: y,
                  disabled: o,
                  isLoading: o && p === "new",
                  loadingText: "Creating notebook...",
                  children: [
                    "Create new notebook with ",
                    T.length,
                    " videos"
                  ]
                }),
                e.jsx(ee, {
                  isOpen: s,
                  onToggle: () => x(!s),
                  projects: D,
                  selectedProject: r,
                  onSelectProject: a.setSelectedBatchProject,
                  query: l,
                  onQueryChange: a.setBatchQuery,
                  isLoading: o,
                  actionType: p,
                  onConfirm: L,
                  itemCount: T.length
                })
              ]
            })
          ]
        }),
        c && e.jsx(C, {
          onClick: () => a.parsePlaylist(N.url),
          variant: "secondary",
          icon: H,
          children: "Retry parsing"
        })
      ]
    });
  };
  De = ({ pendingAction: t, onSuccess: b }) => {
    var _a;
    const [i, a] = G(), [s, x] = u.useState(false), { projects: D = [], selectedBatchProject: r, batchQuery: l } = i.notebooklm || {}, { isParsing: j, parseError: c, articles: h, feedInfo: w } = i.rssImport, { isAdding: o, addSuccess: m, actionType: p, error: f, progressMessage: S, progressPercent: A, failedLinks: n, totalLinks: d } = i.batchNotebookActions, { selectedArticleIds: T, addToNewNotebook: E, addToExistingNotebook: P } = be(), { alsoGenerateProps: I, generateConfig: g } = K();
    u.useEffect(() => {
      var _a2;
      ((_a2 = t == null ? void 0 : t.data) == null ? void 0 : _a2.url) && !h.length && !j && a.parseFeed(t.data.url);
    }, [
      (_a = t == null ? void 0 : t.data) == null ? void 0 : _a.url
    ]), u.useEffect(() => () => {
      a.resetRSSImport();
    }, []);
    const y = async () => {
      await E(g) && (await R("feature_used"), setTimeout(() => {
        b == null ? void 0 : b(), window.close();
      }, 1500));
    }, L = async () => {
      r && await P(r.id, g) && (await R("feature_used"), setTimeout(() => {
        b == null ? void 0 : b(), window.close();
      }, 1500));
    };
    if (!t)
      return null;
    const { data: N } = t, F = T.length > 0;
    return e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx("label", {
              className: "block text-xs font-medium text-neutral-900 dark:text-neutral-100 mb-1.5",
              children: "Source"
            }),
            e.jsxs("div", {
              className: "px-2.5 py-2 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-neutral-700",
              children: [
                e.jsx("p", {
                  className: "text-xs text-neutral-600 dark:text-neutral-400 truncate",
                  children: N.title || N.url
                }),
                e.jsx("p", {
                  className: "text-xs text-neutral-400 dark:text-neutral-500 truncate mt-0.5",
                  children: N.url
                })
              ]
            })
          ]
        }),
        j && e.jsx(v, {
          type: "progress",
          message: "Parsing feed..."
        }),
        c && e.jsx(v, {
          type: "error",
          message: c
        }),
        w && h.length > 0 && e.jsxs(e.Fragment, {
          children: [
            e.jsx(he, {}),
            e.jsx(me, {})
          ]
        }),
        F && !j && e.jsxs("div", {
          className: "pt-2 border-t border-neutral-200 dark:border-neutral-700 space-y-3",
          children: [
            o && S && e.jsx(v, {
              type: "progress",
              message: S,
              progress: A
            }),
            m && e.jsx(Se, {
              actionType: p,
              totalLinks: d,
              failedLinks: n
            }),
            f && e.jsx(v, {
              type: "error",
              message: f
            }),
            !m && e.jsx(U, {
              ...I,
              disabled: o,
              isExistingNotebook: s && !!r
            }),
            !m && e.jsxs("div", {
              className: "space-y-2",
              children: [
                e.jsxs(C, {
                  onClick: y,
                  disabled: o,
                  isLoading: o && p === "new",
                  loadingText: "Creating notebook...",
                  children: [
                    "Create new notebook with ",
                    T.length,
                    " articles"
                  ]
                }),
                e.jsx(ee, {
                  isOpen: s,
                  onToggle: () => x(!s),
                  projects: D,
                  selectedProject: r,
                  onSelectProject: a.setSelectedBatchProject,
                  query: l,
                  onQueryChange: a.setBatchQuery,
                  isLoading: o,
                  actionType: p,
                  onConfirm: L,
                  itemCount: T.length
                })
              ]
            })
          ]
        }),
        c && e.jsx(C, {
          onClick: () => a.parseFeed(N.url),
          variant: "secondary",
          icon: H,
          children: "Retry parsing"
        })
      ]
    });
  };
  Ee = ({ icon: t, title: b, subtitle: i, onCancel: a, disabled: s }) => e.jsx("div", {
    className: "bg-gray-50 dark:bg-slate-900 px-4 py-3 border-b border-gray-200 dark:border-slate-700",
    children: e.jsxs("div", {
      className: "flex items-start justify-between gap-3",
      children: [
        e.jsxs("div", {
          className: "flex items-start gap-2 min-w-0 flex-1",
          children: [
            e.jsx("div", {
              className: "flex-shrink-0 w-5 h-5 text-blue-600 mt-0.5",
              children: t
            }),
            e.jsxs("div", {
              className: "min-w-0 flex-1",
              children: [
                e.jsx("h3", {
                  className: "text-xs font-semibold text-gray-900 dark:text-slate-100 truncate",
                  children: b
                }),
                i && e.jsx("p", {
                  className: "text-xs text-gray-500 dark:text-slate-400 mt-0.5",
                  children: i
                })
              ]
            })
          ]
        }),
        e.jsx("button", {
          onClick: a,
          disabled: s,
          className: "flex-shrink-0 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 disabled:opacity-50 disabled:cursor-not-allowed",
          "aria-label": "Cancel",
          children: e.jsx(ne, {
            className: "w-4 h-4"
          })
        })
      ]
    })
  });
  Ue = () => {
    const [t, b] = G(), [i, a] = u.useState(null), [s, x] = u.useState(null), [D, r] = u.useState(0);
    u.useEffect(() => {
      b.initializeNotebookProjects();
    }, []), u.useEffect(() => {
      const n = Ae();
      n && (a(n), l(n));
    }, []), u.useEffect(() => {
      s && (s.type === "ADD_PAGE_LINKS" ? r(1) : s.type === "ADD_PLAYLIST" ? r(2) : s.type === "ADD_RSS_FEED" ? r(3) : r(0));
    }, [
      s
    ]);
    const l = async (n) => {
      const d = await Le(n);
      d && x(d);
    }, j = async () => {
      await c();
    }, c = async () => {
      i && await ve(i), x(null);
    }, h = async () => {
      await c();
    }, w = () => {
      if (!s)
        return "Review Content";
      switch (s.type) {
        case "ADD_PAGE":
          return "Add Page to Notebook";
        case "ADD_LINK":
          return "Add Link to Notebook";
        case "ADD_TEXT":
          return "Add Selection to Notebook";
        case "ADD_PAGE_LINKS":
          return "Extract Links to Notebook";
        case "ADD_PLAYLIST":
          return "Import Playlist to Notebook";
        case "ADD_RSS_FEED":
          return "Import RSS Feed to Notebook";
        default:
          return "Add to Notebook";
      }
    }, o = () => {
      if (!s)
        return e.jsx(M, {
          className: "w-5 h-5"
        });
      switch (s.type) {
        case "ADD_TEXT":
          return e.jsx(M, {
            className: "w-5 h-5"
          });
        case "ADD_PAGE_LINKS":
          return e.jsx(q, {
            className: "w-5 h-5"
          });
        case "ADD_PLAYLIST":
          return e.jsx($, {
            className: "w-5 h-5 text-red-500"
          });
        case "ADD_RSS_FEED":
          return e.jsx(O, {
            className: "w-5 h-5 text-orange-500"
          });
        default:
          return e.jsx(q, {
            className: "w-5 h-5"
          });
      }
    };
    if (!b.isNotebookLMAuthenticated())
      return e.jsxs(X, {
        children: [
          e.jsx(Y, {
            titleTemplate: "%s",
            children: e.jsx("title", {
              children: "Review Content"
            })
          }),
          e.jsx("div", {
            className: "bg-white dark:bg-slate-800 border border-neutral-200 dark:border-neutral-700 rounded-lg p-8",
            children: e.jsx("div", {
              className: "max-w-md mx-auto",
              children: e.jsx(ge, {})
            })
          })
        ]
      });
    if (!s)
      return e.jsxs(X, {
        children: [
          e.jsx(Y, {
            titleTemplate: "%s",
            children: e.jsx("title", {
              children: "Review Content"
            })
          }),
          e.jsx("div", {
            className: "bg-white dark:bg-slate-800 border border-neutral-200 dark:border-neutral-700 rounded-lg p-8",
            children: e.jsxs("div", {
              className: "text-center",
              children: [
                e.jsx("div", {
                  className: "mx-auto w-12 h-12 bg-neutral-100 dark:bg-slate-700 rounded-full flex items-center justify-center mb-3",
                  children: e.jsx(M, {
                    className: "w-6 h-6 text-neutral-400 dark:text-neutral-500"
                  })
                }),
                e.jsx("h3", {
                  className: "text-xs font-semibold text-neutral-900 dark:text-neutral-100 mb-1",
                  children: "No Content to Review"
                }),
                e.jsx("p", {
                  className: "text-xs text-neutral-500 dark:text-neutral-400",
                  children: "Right-click on a page, link, or text selection and choose an option to add to NotebookLM"
                })
              ]
            })
          })
        ]
      });
    const m = s.type === "ADD_PAGE_LINKS", p = s.type === "ADD_PLAYLIST", f = s.type === "ADD_RSS_FEED", S = t.notebookActions.isAdding || t.batchNotebookActions.isAdding || t.playlistImport.isParsing || t.rssImport.isParsing, A = [
      {
        name: "Content",
        icon: M,
        disabled: m || p || f
      },
      {
        name: "Batch Links",
        icon: q,
        disabled: !m
      },
      {
        name: "Playlist",
        icon: $,
        disabled: !p
      },
      {
        name: "RSS Feed",
        icon: O,
        disabled: !f
      }
    ];
    return e.jsxs(X, {
      children: [
        e.jsx(Y, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: w()
          })
        }),
        e.jsxs("div", {
          className: "bg-white dark:bg-slate-800 border border-neutral-200 dark:border-neutral-700 rounded-lg overflow-hidden",
          children: [
            e.jsx(Ee, {
              icon: o(),
              title: w(),
              subtitle: "Review and confirm before adding",
              onCancel: j,
              disabled: S
            }),
            e.jsxs("div", {
              className: "p-4",
              children: [
                e.jsx("div", {
                  className: "mb-4",
                  children: e.jsx(ke, {})
                }),
                e.jsxs(je, {
                  selectedIndex: D,
                  onChange: r,
                  children: [
                    e.jsx(pe, {
                      className: "flex p-0.5 bg-gray-100 dark:bg-slate-700 rounded-md mb-4",
                      children: A.map((n) => e.jsxs(fe, {
                        disabled: n.disabled,
                        className: le("flex items-center justify-center gap-1.5 px-2 py-1.5 rounded text-xs font-medium flex-1", "focus:outline-none", n.disabled ? "text-gray-400 dark:text-slate-500 cursor-not-allowed" : "text-gray-700 dark:text-slate-300 data-[selected]:bg-white dark:data-[selected]:bg-slate-800 data-[selected]:text-gray-900 dark:data-[selected]:text-slate-100 data-[selected]:shadow-sm dark:data-[selected]:shadow-slate-900/30"),
                        children: [
                          e.jsx(n.icon, {
                            className: "w-3 h-3"
                          }),
                          n.name
                        ]
                      }, n.name))
                    }),
                    e.jsxs(ye, {
                      children: [
                        e.jsx(Q, {
                          className: "focus:outline-none",
                          children: e.jsx(Te, {
                            pendingAction: s,
                            onSuccess: h
                          })
                        }),
                        e.jsx(Q, {
                          className: "focus:outline-none",
                          children: e.jsx(Pe, {
                            pendingAction: s,
                            onSuccess: h
                          })
                        }),
                        e.jsx(Q, {
                          className: "focus:outline-none",
                          children: e.jsx(Ce, {
                            pendingAction: s,
                            onSuccess: h
                          })
                        }),
                        e.jsx(Q, {
                          className: "focus:outline-none",
                          children: e.jsx(De, {
                            pendingAction: s,
                            onSuccess: h
                          })
                        })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  Ue as default
};
