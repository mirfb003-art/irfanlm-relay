const r = (t) => {
  if (!t)
    return "N/A";
  const e = new Date(t);
  return isNaN(e) ? "N/A" : e.toLocaleDateString(void 0, { year: "numeric", month: "short", day: "numeric" });
}, n = r;
export {
  n as f
};
