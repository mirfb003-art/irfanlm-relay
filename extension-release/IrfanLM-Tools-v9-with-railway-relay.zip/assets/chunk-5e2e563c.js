import { b as P, c as _, d as M, e as U, f as k, p as F, a as R, g as O, P as I, _ as g, h as B } from "./chunk-9bfc7485.js";
import { o as G, l as d, C as m, m as C, n as K, p as j, g as D } from "./chunk-68adfa56.js";
import { s as w } from "./chunk-e3c02cf0.js";
import "./chunk-725317a4.js";
var x = O(), c = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Map(), A = /* @__PURE__ */ new Map(), E = (e, n) => (f.set(e, (f.get(e) || /* @__PURE__ */ new Set()).add(n)), () => {
  const t = f.get(e);
  (t == null ? void 0 : t.delete(n)) && (t == null ? void 0 : t.size) === 0 && f.delete(e);
}), T = (e, n) => {
  A.set(e, (A.get(e) || /* @__PURE__ */ new Set()).add(n));
}, u = (e) => ({ withFingerprint: (n) => {
  const t = (a) => ({ and: () => a }), o = { aboutIncomingMessage: (a) => {
    const r = c.get(e);
    return I.toExtensionContext(r.port, { status: "incoming", message: a }), t(o);
  }, aboutSuccessfulDelivery: (a) => {
    const r = c.get(e);
    return I.toExtensionContext(r.port, { status: "delivered", receipt: a }), t(o);
  }, aboutMessageUndeliverability: (a, r) => {
    const i = c.get(e);
    return (i == null ? void 0 : i.fingerprint) === n && I.toExtensionContext(i.port, { status: "undeliverable", resolvedDestination: a, message: r }), t(o);
  }, whenDeliverableTo: (a) => {
    const r = () => {
      const i = c.get(e);
      if ((i == null ? void 0 : i.fingerprint) === n && c.has(a))
        return I.toExtensionContext(i.port, { status: "deliverable", deliverableTo: a }), true;
    };
    if (!r()) {
      const i = E(a, r);
      T(n, i);
    }
    return t(o);
  }, aboutSessionEnded: (a) => {
    const r = c.get(e);
    return (r == null ? void 0 : r.fingerprint) === n && I.toExtensionContext(r.port, { status: "terminated", fingerprint: a }), t(o);
  } };
  return o;
} }), W = P(), S = _("background", (e) => {
  var n;
  if (e.origin.context === "background" && ["content-script", "devtools "].includes(e.destination.context) && !e.destination.tabId)
    throw new TypeError("When sending messages from background page, use @tabId syntax to target specific tab");
  const t = k(g(g({}, e.origin), e.origin.context === "window" && { context: "content-script" })), o = k(B(g(g({}, e.destination), e.destination.context === "window" && { context: "content-script" }), { tabId: e.destination.tabId || e.origin.tabId }));
  e.destination.tabId = null, e.destination.frameId = null;
  const a = () => c.get(o), r = () => c.get(t), i = () => {
    var p;
    u(o).withFingerprint(a().fingerprint).aboutIncomingMessage(e);
    const y = { message: e, to: a().fingerprint, from: { endpointId: t, fingerprint: (p = r()) == null ? void 0 : p.fingerprint } };
    e.messageType === "message" && x.add(y), e.messageType === "reply" && x.remove(e.messageID), r() && u(t).withFingerprint(r().fingerprint).aboutSuccessfulDelivery(y);
  };
  (n = a()) != null && n.port ? i() : e.messageType === "message" && (e.origin.context === "background" ? E(o, i) : r() && u(t).withFingerprint(r().fingerprint).aboutMessageUndeliverability(o, e).and().whenDeliverableTo(o));
}, (e) => {
  const n = k(g(g({}, e.origin), e.origin.context === "window" && { context: "content-script" })), t = c.get(n), o = { message: e, to: W, from: { endpointId: n, fingerprint: t.fingerprint } };
  u(n).withFingerprint(t.fingerprint).aboutSuccessfulDelivery(o);
});
M.runtime.onConnect.addListener((e) => {
  var n;
  const t = U(e.name);
  if (!t)
    return;
  t.endpointName || (t.endpointName = k({ context: "content-script", tabId: e.sender.tab.id, frameId: e.sender.frameId }));
  const { tabId: o, frameId: a } = F(t.endpointName);
  c.set(t.endpointName, { fingerprint: t.fingerprint, port: e }), (n = f.get(t.endpointName)) == null || n.forEach((r) => r()), f.delete(t.endpointName), T(t.fingerprint, () => {
    const r = x.entries().filter((i) => i.to === t.fingerprint);
    x.remove(r), r.forEach((i) => {
      i.from.endpointId === "background" ? S.endTransaction(i.message.transactionId) : u(i.from.endpointId).withFingerprint(i.from.fingerprint).aboutSessionEnded(t.fingerprint);
    });
  }), e.onDisconnect.addListener(() => {
    var r, i;
    ((r = c.get(t.endpointName)) == null ? void 0 : r.fingerprint) === t.fingerprint && c.delete(t.endpointName), (i = A.get(t.fingerprint)) == null || i.forEach((p) => p()), A.delete(t.fingerprint);
  }), e.onMessage.addListener((r) => {
    var i, p;
    if (r.type === "sync") {
      const y = [...c.values()].map((l) => l.fingerprint), L = r.pendingResponses.filter((l) => y.includes(l.to));
      x.add(...L), r.pendingResponses.filter((l) => !y.includes(l.to)).forEach((l) => u(t.endpointName).withFingerprint(t.fingerprint).aboutSessionEnded(l.to)), r.pendingDeliveries.forEach((l) => u(t.endpointName).withFingerprint(t.fingerprint).whenDeliverableTo(l));
      return;
    }
    r.type === "deliver" && ((p = (i = r.message) == null ? void 0 : i.origin) != null && p.context) && (r.message.origin.tabId = o, r.message.origin.frameId = a, S.handleMessage(r.message));
  });
});
var { sendMessage: oe, onMessage: h } = S;
R(S);
const s = { parent: "notebooklm-tools", addPage: "add-current-page-to-notebooklm", addPageLinks: "add-page-links-to-notebooklm", addPlaylist: "add-playlist-to-notebooklm", addRSSFeed: "add-rss-feed-to-notebooklm", addLink: "add-link-to-notebooklm", addText: "add-text-to-notebooklm", separator: "separator", configure: "configure-notebooklm" }, Y = [{ id: s.parent, title: "NotebookLM", contexts: ["page", "link", "selection"] }, { id: s.addPage, parentId: s.parent, title: "Add Page to Notebook", contexts: ["page"], documentUrlPatterns: ["http://*/*", "https://*/*"] }, { id: s.addPageLinks, parentId: s.parent, title: "Extract Links to Notebook", contexts: ["page"], documentUrlPatterns: ["http://*/*", "https://*/*"] }, { id: s.addPlaylist, parentId: s.parent, title: "Import Playlist to Notebook", contexts: ["page"], documentUrlPatterns: ["*://www.youtube.com/playlist*", "*://youtube.com/playlist*", "*://www.youtube.com/watch*list=*", "*://youtube.com/watch*list=*"] }, { id: s.addRSSFeed, parentId: s.parent, title: "Import RSS Feed to Notebook", contexts: ["page"], documentUrlPatterns: ["*://*/*feed*", "*://*/*rss*", "*://*/*atom*", "*://*/feed.xml", "*://*/rss.xml", "*://*/atom.xml", "*://*/index.xml"] }, { id: s.addLink, parentId: s.parent, title: "Add Link to Notebook", contexts: ["link"], targetUrlPatterns: ["http://*/*", "https://*/*"] }, { id: s.addText, parentId: s.parent, title: "Add Selection to Notebook", contexts: ["selection"] }, { id: s.separator, parentId: s.parent, type: "separator", contexts: ["page", "link", "selection"] }, { id: s.configure, parentId: s.parent, title: "Settings", contexts: ["page", "link", "selection"] }], N = () => {
  chrome.contextMenus.removeAll(() => {
    Y.forEach((e) => {
      chrome.contextMenus.create(e);
    });
  });
}, b = async (e) => {
  const n = chrome.runtime.getURL(`popup.html#/context-menu-preview?actionId=${e}`);
  chrome.tabs.create({ url: n, active: true });
}, V = async (e, n) => {
  const t = { type: "ADD_PAGE", data: { url: e.pageUrl, title: n.title }, timestamp: Date.now() }, o = await w(t);
  await b(o);
}, z = async (e, n) => {
  const t = { type: "ADD_PAGE_LINKS", data: { url: e.pageUrl, title: n.title, tabId: n.id }, timestamp: Date.now() }, o = await w(t);
  await b(o);
}, H = async (e, n) => {
  const t = { type: "ADD_PLAYLIST", data: { url: e.pageUrl, title: n.title, tabId: n.id }, timestamp: Date.now() }, o = await w(t);
  await b(o);
}, J = async (e, n) => {
  const t = { type: "ADD_RSS_FEED", data: { url: e.pageUrl, title: n.title, tabId: n.id }, timestamp: Date.now() }, o = await w(t);
  await b(o);
}, X = async (e, n) => {
  const t = { type: "ADD_LINK", data: { url: e.linkUrl, selectionText: e.selectionText, pageUrl: e.pageUrl, pageTitle: n.title }, timestamp: Date.now() }, o = await w(t);
  await b(o);
}, $ = async (e, n) => {
  const t = { type: "ADD_TEXT", data: { text: e.selectionText, pageUrl: e.pageUrl, pageTitle: n.title }, timestamp: Date.now() }, o = await w(t);
  await b(o);
}, q = async (e, n) => {
  await G(n.windowId);
}, Q = async (e, n) => {
  const o = { [s.addPage]: V, [s.addPageLinks]: z, [s.addPlaylist]: H, [s.addRSSFeed]: J, [s.addLink]: X, [s.addText]: $, [s.configure]: q }[e.menuItemId];
  o && await o(e, n);
};
async function v() {
  var _a, _b, _c, _d;
  try {
    const e = await d.get(m);
    let n = false, t = 0;
    (e == null ? void 0 : e.accounts) && (e == null ? void 0 : e.activeAccount) ? (n = !!((_a = e.accounts[e.activeAccount]) == null ? void 0 : _a.token), t = ((_b = await d.get(D) || []) == null ? void 0 : _b.length) || 0) : (n = !!((_c = await d.get(C) || {}) == null ? void 0 : _c.token), t = ((_d = await d.get(D) || []) == null ? void 0 : _d.length) || 0), n ? (chrome.action.setBadgeText({ text: t > 0 ? String(t) : "" }), chrome.action.setBadgeBackgroundColor({ color: "#10b981" }), chrome.action.setBadgeTextColor({ color: "#ffffff" })) : (chrome.action.setBadgeText({ text: "" }), chrome.action.setBadgeBackgroundColor({ color: "#ef4444" }), chrome.action.setBadgeTextColor({ color: "#ffffff" }));
  } catch (e) {
    console.error("Error updating action badge:", e);
  }
}
chrome.runtime.onInstalled.addListener((e) => {
  N(), v(), chrome.runtime.setUninstallURL("https://www.nlmtools.com/uninstalled-chrome-extension"), e.reason === "install" && chrome.tabs.create({ url: "https://www.nlmtools.com/installed-chrome-extension" });
});
chrome.runtime.onStartup.addListener(() => {
  N(), v();
});
chrome.contextMenus.onClicked.addListener(async (e, n) => {
  try {
    await Q(e, n);
  } catch (t) {
    console.error("Context menu action failed:", t);
  }
});
h("ping", async ({ data: e }) => ({ data: e, response: "pong" }));
h("openSidePanel", async ({ data: e }) => {
  try {
    return chrome.sidePanel.open({ windowId: e.windowId }), { success: true };
  } catch (n) {
    return console.error("Error opening side panel:", n), { success: false, error: n.message };
  }
});
h("YTUONG_NLM_PAYLOAD", async ({ data: e }) => {
  try {
    if (!(e == null ? void 0 : e.token) || !(e == null ? void 0 : e.email))
      return console.warn("[NLM Tools] Invalid payload, skipping"), { success: false, error: "Invalid payload" };
    const n = await d.get(m) || {}, t = { ...n.accounts || {} };
    t[e.email] = { ...e, lastRefreshed: (/* @__PURE__ */ new Date()).toISOString() };
    const o = n.activeAccount || e.email, a = n.accountOrder ? [...n.accountOrder] : [];
    a.includes(e.email) || a.push(e.email);
    const r = { accounts: t, activeAccount: o, accountOrder: a };
    return await d.set(m, r), t[o] && await d.set(C, t[o]), await v(), { success: true };
  } catch (n) {
    return console.error("[NLM Tools] Failed to store payload:", n), { success: false, error: n.message };
  }
});
h("UPDATE_BADGE", async () => (await v(), { success: true }));
h("ADD_CURRENT_PAGE", async ({ data: e }) => {
  try {
    const { url: n, title: t, notebookId: o } = e, a = await K({ url: n, title: t, notebookId: o });
    return await j(a), { success: true, notebookId: a };
  } catch (n) {
    return console.error("Error adding current page:", n), { success: false, error: n.message };
  }
});
h("SWITCH_ACTIVE_ACCOUNT", async ({ data: e }) => {
  var _a;
  try {
    const { email: n } = e;
    if (!n)
      return { success: false, error: "No email provided" };
    const t = await d.get(m) || {};
    return ((_a = t.accounts) == null ? void 0 : _a[n]) ? (t.activeAccount = n, await d.set(m, t), await d.set(C, t.accounts[n]), await v(), { success: true }) : { success: false, error: "Account not found" };
  } catch (n) {
    return console.error("Error switching account:", n), { success: false, error: n.message };
  }
});
chrome.storage.onChanged.addListener((e, n) => {
  if (n === "local") {
    const t = C, o = D, a = m;
    (e[t] || e[o] || e[a]) && v();
  }
});
