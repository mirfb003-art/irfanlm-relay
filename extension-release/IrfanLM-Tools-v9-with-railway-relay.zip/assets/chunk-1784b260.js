import { r as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
let l;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function n({ title: r, titleId: a, ...t }, o) {
    return e.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": a
    }, t), r ? e.createElement("title", {
      id: a
    }, r) : null, e.createElement("path", {
      d: "M10 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM3.465 14.493a1.23 1.23 0 0 0 .41 1.412A9.957 9.957 0 0 0 10 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 0 0-13.074.003Z"
    }));
  }
  let c;
  c = e.forwardRef(n);
  l = c;
});
export {
  l as U,
  __tla
};
