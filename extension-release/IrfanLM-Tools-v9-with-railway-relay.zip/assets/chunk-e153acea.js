async function F({ globalActions: o, notebookId: r, sources: i, sourceFolders: c, onProgress: d }) {
  var _a, _b, _c, _d, _e;
  if (!c)
    return o.importNotebookSources(r, { sources: i }, d);
  const M = ((_a = c.sourceFolderMap) == null ? void 0 : _a[r]) || (Object.keys(c.sourceFolderMap || {}).length === 1 ? Object.values(c.sourceFolderMap)[0] : {}), a = ((_b = c.folders) == null ? void 0 : _b[r]) || (Object.keys(c.folders || {}).length === 1 ? Object.values(c.folders)[0] : {});
  if (!a || Object.keys(a).length === 0)
    return o.importNotebookSources(r, { sources: i }, d);
  const n = {}, l = [];
  for (const e of i) {
    const t = M[e.id];
    t && a[t] ? (n[t] || (n[t] = []), n[t].push(e)) : l.push(e);
  }
  const S = {};
  for (const [e, t] of Object.entries(a)) {
    const f = await o.createFolder(r, t.name);
    (f == null ? void 0 : f.folder) && (S[e] = f.folder.id);
  }
  const O = (_c = await o.fetchNotebookLMProjects()) == null ? void 0 : _c.find((e) => e.id === r);
  let j = new Set(((O == null ? void 0 : O.sources) || []).map((e) => e.id));
  const u = { success: 0, failed: 0, errors: [] };
  let p = 0;
  const w = i.length;
  for (const [e, t] of Object.entries(n)) {
    const f = S[e];
    if (!f) {
      l.push(...t);
      continue;
    }
    const h = await o.importNotebookSources(r, { sources: t }, (s) => {
      d && d({ current: p + s.current, total: w });
    });
    p += t.length, u.success += h.success, u.failed += h.failed, u.errors.push(...h.errors);
    const N = (((_e = (_d = await o.fetchNotebookLMProjects()) == null ? void 0 : _d.find((s) => s.id === r)) == null ? void 0 : _e.sources) || []).map((s) => s.id), m = N.filter((s) => !j.has(s));
    m.length > 0 && await o.bulkMoveToFolder(r, m, f), N.forEach((s) => j.add(s));
  }
  if (l.length > 0) {
    const e = await o.importNotebookSources(r, { sources: l }, (t) => {
      d && d({ current: p + t.current, total: w });
    });
    u.success += e.success, u.failed += e.failed, u.errors.push(...e.errors);
  }
  return u;
}
export {
  F as i
};
