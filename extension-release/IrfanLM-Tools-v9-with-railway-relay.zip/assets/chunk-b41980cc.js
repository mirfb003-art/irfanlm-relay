import { L as Ng, l as k, z as Bo, M as Yr, U as ai, B as Ws, C as tn, m as ha, H as Pg, J as bg, I as oi, O as ya, S as si, a as li, b as ii, c as ci, h as ui, T as di, K as fi, Q as pi, i as gi, V as mi, D as hd, e as yd, f as wd, W as Lg, g as hi, X as Ht, Y as ce, Z as ge, _ as _g, $ as Rg, a0 as Qr, y as vd, a1 as Og, a2 as Sd, x as ao, a3 as oo, A as Jn, a4 as Fg, a5 as kd, a6 as Vc, a7 as Ig, a8 as Hc, a9 as Ed, aa as Dg, ab as Gc, ac as O, ad as Ug, ae as $g, af as jg, ag as ms, ah as zg, ai as Bg, t as Vg, aj as Td, ak as xd, al as Ys, am as Hg, an as Gg, ao as Wg, ap as hs, G as so, n as Ad, p as Md, aq as Yg, ar as Qg, d as Cd, as as Nd, at as lo, au as er, av as yi, aw as Pd, ax as bd, ay as Ld, k as Qs, P as Vo, az as ie, aA as Zs, aB as Zg, aC as _d } from "./chunk-68adfa56.js";
import { g as wi } from "./chunk-725317a4.js";
let zE, S2, JE, p2, e2, RE, OE, g2, Bl, IE, B, FE, E2, m2, n0, BE, h2, HE, T1, ht, n2, t2, a2, r2, w2, o2, CS, NS, T2, Jk, Qp, Z1, DE, UE, $E, jE, Wk, vc, Yw, WE, YE, QE, Qw, EE, pw, gE, AE, PE, ir, GE, Hw, VE, k2, v2, y2, d2, s2, A5, u2, l2, ft, f2, Ro, M, E1, y0, h0, $, x, i2, _E, c2, ZE, KE, fv, XE, qE;
let __tla = (async () => {
  function Kg(e, t) {
    for (var n = 0; n < t.length; n++) {
      const r = t[n];
      if (typeof r != "string" && !Array.isArray(r)) {
        for (const a in r)
          if (a !== "default" && !(a in e)) {
            const o = Object.getOwnPropertyDescriptor(r, a);
            o && Object.defineProperty(e, a, o.get ? o : {
              enumerable: true,
              get: () => r[a]
            });
          }
      }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }));
  }
  var Rd = {
    exports: {}
  }, Ho = {}, Od = {
    exports: {}
  }, D = {};
  var wa = Symbol.for("react.element"), Xg = Symbol.for("react.portal"), qg = Symbol.for("react.fragment"), Jg = Symbol.for("react.strict_mode"), em = Symbol.for("react.profiler"), tm = Symbol.for("react.provider"), nm = Symbol.for("react.context"), rm = Symbol.for("react.forward_ref"), am = Symbol.for("react.suspense"), om = Symbol.for("react.memo"), sm = Symbol.for("react.lazy"), Wc = Symbol.iterator;
  function lm(e) {
    return e === null || typeof e != "object" ? null : (e = Wc && e[Wc] || e["@@iterator"], typeof e == "function" ? e : null);
  }
  var Fd = {
    isMounted: function() {
      return false;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, Id = Object.assign, Dd = {};
  function pr(e, t, n) {
    this.props = e, this.context = t, this.refs = Dd, this.updater = n || Fd;
  }
  pr.prototype.isReactComponent = {};
  pr.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null)
      throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState");
  };
  pr.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate");
  };
  function Ud() {
  }
  Ud.prototype = pr.prototype;
  function vi(e, t, n) {
    this.props = e, this.context = t, this.refs = Dd, this.updater = n || Fd;
  }
  var Si = vi.prototype = new Ud();
  Si.constructor = vi;
  Id(Si, pr.prototype);
  Si.isPureReactComponent = true;
  var Yc = Array.isArray, $d = Object.prototype.hasOwnProperty, ki = {
    current: null
  }, jd = {
    key: true,
    ref: true,
    __self: true,
    __source: true
  };
  function zd(e, t, n) {
    var r, a = {}, o = null, s = null;
    if (t != null)
      for (r in t.ref !== void 0 && (s = t.ref), t.key !== void 0 && (o = "" + t.key), t)
        $d.call(t, r) && !jd.hasOwnProperty(r) && (a[r] = t[r]);
    var l = arguments.length - 2;
    if (l === 1)
      a.children = n;
    else if (1 < l) {
      for (var i = Array(l), c = 0; c < l; c++)
        i[c] = arguments[c + 2];
      a.children = i;
    }
    if (e && e.defaultProps)
      for (r in l = e.defaultProps, l)
        a[r] === void 0 && (a[r] = l[r]);
    return {
      $$typeof: wa,
      type: e,
      key: o,
      ref: s,
      props: a,
      _owner: ki.current
    };
  }
  function im(e, t) {
    return {
      $$typeof: wa,
      type: e.type,
      key: t,
      ref: e.ref,
      props: e.props,
      _owner: e._owner
    };
  }
  function Ei(e) {
    return typeof e == "object" && e !== null && e.$$typeof === wa;
  }
  function cm(e) {
    var t = {
      "=": "=0",
      ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
      return t[n];
    });
  }
  var Qc = /\/+/g;
  function ys(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? cm("" + e.key) : t.toString(36);
  }
  function Ga(e, t, n, r, a) {
    var o = typeof e;
    (o === "undefined" || o === "boolean") && (e = null);
    var s = false;
    if (e === null)
      s = true;
    else
      switch (o) {
        case "string":
        case "number":
          s = true;
          break;
        case "object":
          switch (e.$$typeof) {
            case wa:
            case Xg:
              s = true;
          }
      }
    if (s)
      return s = e, a = a(s), e = r === "" ? "." + ys(s, 0) : r, Yc(a) ? (n = "", e != null && (n = e.replace(Qc, "$&/") + "/"), Ga(a, t, n, "", function(c) {
        return c;
      })) : a != null && (Ei(a) && (a = im(a, n + (!a.key || s && s.key === a.key ? "" : ("" + a.key).replace(Qc, "$&/") + "/") + e)), t.push(a)), 1;
    if (s = 0, r = r === "" ? "." : r + ":", Yc(e))
      for (var l = 0; l < e.length; l++) {
        o = e[l];
        var i = r + ys(o, l);
        s += Ga(o, t, n, i, a);
      }
    else if (i = lm(e), typeof i == "function")
      for (e = i.call(e), l = 0; !(o = e.next()).done; )
        o = o.value, i = r + ys(o, l++), s += Ga(o, t, n, i, a);
    else if (o === "object")
      throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return s;
  }
  function Ma(e, t, n) {
    if (e == null)
      return e;
    var r = [], a = 0;
    return Ga(e, r, "", "", function(o) {
      return t.call(n, o, a++);
    }), r;
  }
  function um(e) {
    if (e._status === -1) {
      var t = e._result;
      t = t(), t.then(function(n) {
        (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n);
      }, function(n) {
        (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n);
      }), e._status === -1 && (e._status = 0, e._result = t);
    }
    if (e._status === 1)
      return e._result.default;
    throw e._result;
  }
  var Pe = {
    current: null
  }, Wa = {
    transition: null
  }, dm = {
    ReactCurrentDispatcher: Pe,
    ReactCurrentBatchConfig: Wa,
    ReactCurrentOwner: ki
  };
  function Bd() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  D.Children = {
    map: Ma,
    forEach: function(e, t, n) {
      Ma(e, function() {
        t.apply(this, arguments);
      }, n);
    },
    count: function(e) {
      var t = 0;
      return Ma(e, function() {
        t++;
      }), t;
    },
    toArray: function(e) {
      return Ma(e, function(t) {
        return t;
      }) || [];
    },
    only: function(e) {
      if (!Ei(e))
        throw Error("React.Children.only expected to receive a single React element child.");
      return e;
    }
  };
  D.Component = pr;
  D.Fragment = qg;
  D.Profiler = em;
  D.PureComponent = vi;
  D.StrictMode = Jg;
  D.Suspense = am;
  D.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = dm;
  D.act = Bd;
  D.cloneElement = function(e, t, n) {
    if (e == null)
      throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = Id({}, e.props), a = e.key, o = e.ref, s = e._owner;
    if (t != null) {
      if (t.ref !== void 0 && (o = t.ref, s = ki.current), t.key !== void 0 && (a = "" + t.key), e.type && e.type.defaultProps)
        var l = e.type.defaultProps;
      for (i in t)
        $d.call(t, i) && !jd.hasOwnProperty(i) && (r[i] = t[i] === void 0 && l !== void 0 ? l[i] : t[i]);
    }
    var i = arguments.length - 2;
    if (i === 1)
      r.children = n;
    else if (1 < i) {
      l = Array(i);
      for (var c = 0; c < i; c++)
        l[c] = arguments[c + 2];
      r.children = l;
    }
    return {
      $$typeof: wa,
      type: e.type,
      key: a,
      ref: o,
      props: r,
      _owner: s
    };
  };
  D.createContext = function(e) {
    return e = {
      $$typeof: nm,
      _currentValue: e,
      _currentValue2: e,
      _threadCount: 0,
      Provider: null,
      Consumer: null,
      _defaultValue: null,
      _globalName: null
    }, e.Provider = {
      $$typeof: tm,
      _context: e
    }, e.Consumer = e;
  };
  D.createElement = zd;
  D.createFactory = function(e) {
    var t = zd.bind(null, e);
    return t.type = e, t;
  };
  D.createRef = function() {
    return {
      current: null
    };
  };
  D.forwardRef = function(e) {
    return {
      $$typeof: rm,
      render: e
    };
  };
  D.isValidElement = Ei;
  D.lazy = function(e) {
    return {
      $$typeof: sm,
      _payload: {
        _status: -1,
        _result: e
      },
      _init: um
    };
  };
  D.memo = function(e, t) {
    return {
      $$typeof: om,
      type: e,
      compare: t === void 0 ? null : t
    };
  };
  D.startTransition = function(e) {
    var t = Wa.transition;
    Wa.transition = {};
    try {
      e();
    } finally {
      Wa.transition = t;
    }
  };
  D.unstable_act = Bd;
  D.useCallback = function(e, t) {
    return Pe.current.useCallback(e, t);
  };
  D.useContext = function(e) {
    return Pe.current.useContext(e);
  };
  D.useDebugValue = function() {
  };
  D.useDeferredValue = function(e) {
    return Pe.current.useDeferredValue(e);
  };
  D.useEffect = function(e, t) {
    return Pe.current.useEffect(e, t);
  };
  D.useId = function() {
    return Pe.current.useId();
  };
  D.useImperativeHandle = function(e, t, n) {
    return Pe.current.useImperativeHandle(e, t, n);
  };
  D.useInsertionEffect = function(e, t) {
    return Pe.current.useInsertionEffect(e, t);
  };
  D.useLayoutEffect = function(e, t) {
    return Pe.current.useLayoutEffect(e, t);
  };
  D.useMemo = function(e, t) {
    return Pe.current.useMemo(e, t);
  };
  D.useReducer = function(e, t, n) {
    return Pe.current.useReducer(e, t, n);
  };
  D.useRef = function(e) {
    return Pe.current.useRef(e);
  };
  D.useState = function(e) {
    return Pe.current.useState(e);
  };
  D.useSyncExternalStore = function(e, t, n) {
    return Pe.current.useSyncExternalStore(e, t, n);
  };
  D.useTransition = function() {
    return Pe.current.useTransition();
  };
  D.version = "18.3.1";
  Od.exports = D;
  x = Od.exports;
  M = wi(x);
  _E = Kg({
    __proto__: null,
    default: M
  }, [
    x
  ]);
  var fm = x, pm = Symbol.for("react.element"), gm = Symbol.for("react.fragment"), mm = Object.prototype.hasOwnProperty, hm = fm.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, ym = {
    key: true,
    ref: true,
    __self: true,
    __source: true
  };
  function Vd(e, t, n) {
    var r, a = {}, o = null, s = null;
    n !== void 0 && (o = "" + n), t.key !== void 0 && (o = "" + t.key), t.ref !== void 0 && (s = t.ref);
    for (r in t)
      mm.call(t, r) && !ym.hasOwnProperty(r) && (a[r] = t[r]);
    if (e && e.defaultProps)
      for (r in t = e.defaultProps, t)
        a[r] === void 0 && (a[r] = t[r]);
    return {
      $$typeof: pm,
      type: e,
      key: o,
      ref: s,
      props: a,
      _owner: hm.current
    };
  }
  Ho.Fragment = gm;
  Ho.jsx = Vd;
  Ho.jsxs = Vd;
  Rd.exports = Ho;
  let Hd, Ve, Gd, Wd;
  ft = Rd.exports;
  Hd = {
    exports: {}
  };
  Ve = {};
  Gd = {
    exports: {}
  };
  Wd = {};
  (function(e) {
    function t(P, C) {
      var _ = P.length;
      P.push(C);
      e:
        for (; 0 < _; ) {
          var Z = _ - 1 >>> 1, R = P[Z];
          if (0 < a(R, C))
            P[Z] = C, P[_] = R, _ = Z;
          else
            break e;
        }
    }
    function n(P) {
      return P.length === 0 ? null : P[0];
    }
    function r(P) {
      if (P.length === 0)
        return null;
      var C = P[0], _ = P.pop();
      if (_ !== C) {
        P[0] = _;
        e:
          for (var Z = 0, R = P.length, z = R >>> 1; Z < z; ) {
            var j = 2 * (Z + 1) - 1, de = P[j], Le = j + 1, G = P[Le];
            if (0 > a(de, _))
              Le < R && 0 > a(G, de) ? (P[Z] = G, P[Le] = _, Z = Le) : (P[Z] = de, P[j] = _, Z = j);
            else if (Le < R && 0 > a(G, _))
              P[Z] = G, P[Le] = _, Z = Le;
            else
              break e;
          }
      }
      return C;
    }
    function a(P, C) {
      var _ = P.sortIndex - C.sortIndex;
      return _ !== 0 ? _ : P.id - C.id;
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
      var o = performance;
      e.unstable_now = function() {
        return o.now();
      };
    } else {
      var s = Date, l = s.now();
      e.unstable_now = function() {
        return s.now() - l;
      };
    }
    var i = [], c = [], u = 1, p = null, f = 3, d = false, w = false, y = false, S = typeof setTimeout == "function" ? setTimeout : null, g = typeof clearTimeout == "function" ? clearTimeout : null, m = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function h(P) {
      for (var C = n(c); C !== null; ) {
        if (C.callback === null)
          r(c);
        else if (C.startTime <= P)
          r(c), C.sortIndex = C.expirationTime, t(i, C);
        else
          break;
        C = n(c);
      }
    }
    function v(P) {
      if (y = false, h(P), !w)
        if (n(i) !== null)
          w = true, qe(A);
        else {
          var C = n(c);
          C !== null && Ue(v, C.startTime - P);
        }
    }
    function A(P, C) {
      w = false, y && (y = false, g(L), L = -1), d = true;
      var _ = f;
      try {
        for (h(C), p = n(i); p !== null && (!(p.expirationTime > C) || P && !Se()); ) {
          var Z = p.callback;
          if (typeof Z == "function") {
            p.callback = null, f = p.priorityLevel;
            var R = Z(p.expirationTime <= C);
            C = e.unstable_now(), typeof R == "function" ? p.callback = R : p === n(i) && r(i), h(C);
          } else
            r(i);
          p = n(i);
        }
        if (p !== null)
          var z = true;
        else {
          var j = n(c);
          j !== null && Ue(v, j.startTime - C), z = false;
        }
        return z;
      } finally {
        p = null, f = _, d = false;
      }
    }
    var T = false, N = null, L = -1, W = 5, I = -1;
    function Se() {
      return !(e.unstable_now() - I < W);
    }
    function Ae() {
      if (N !== null) {
        var P = e.unstable_now();
        I = P;
        var C = true;
        try {
          C = N(true, P);
        } finally {
          C ? dt() : (T = false, N = null);
        }
      } else
        T = false;
    }
    var dt;
    if (typeof m == "function")
      dt = function() {
        m(Ae);
      };
    else if (typeof MessageChannel < "u") {
      var kt = new MessageChannel(), Nn = kt.port2;
      kt.port1.onmessage = Ae, dt = function() {
        Nn.postMessage(null);
      };
    } else
      dt = function() {
        S(Ae, 0);
      };
    function qe(P) {
      N = P, T || (T = true, dt());
    }
    function Ue(P, C) {
      L = S(function() {
        P(e.unstable_now());
      }, C);
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(P) {
      P.callback = null;
    }, e.unstable_continueExecution = function() {
      w || d || (w = true, qe(A));
    }, e.unstable_forceFrameRate = function(P) {
      0 > P || 125 < P ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : W = 0 < P ? Math.floor(1e3 / P) : 5;
    }, e.unstable_getCurrentPriorityLevel = function() {
      return f;
    }, e.unstable_getFirstCallbackNode = function() {
      return n(i);
    }, e.unstable_next = function(P) {
      switch (f) {
        case 1:
        case 2:
        case 3:
          var C = 3;
          break;
        default:
          C = f;
      }
      var _ = f;
      f = C;
      try {
        return P();
      } finally {
        f = _;
      }
    }, e.unstable_pauseExecution = function() {
    }, e.unstable_requestPaint = function() {
    }, e.unstable_runWithPriority = function(P, C) {
      switch (P) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          P = 3;
      }
      var _ = f;
      f = P;
      try {
        return C();
      } finally {
        f = _;
      }
    }, e.unstable_scheduleCallback = function(P, C, _) {
      var Z = e.unstable_now();
      switch (typeof _ == "object" && _ !== null ? (_ = _.delay, _ = typeof _ == "number" && 0 < _ ? Z + _ : Z) : _ = Z, P) {
        case 1:
          var R = -1;
          break;
        case 2:
          R = 250;
          break;
        case 5:
          R = 1073741823;
          break;
        case 4:
          R = 1e4;
          break;
        default:
          R = 5e3;
      }
      return R = _ + R, P = {
        id: u++,
        callback: C,
        priorityLevel: P,
        startTime: _,
        expirationTime: R,
        sortIndex: -1
      }, _ > Z ? (P.sortIndex = _, t(c, P), n(i) === null && P === n(c) && (y ? (g(L), L = -1) : y = true, Ue(v, _ - Z))) : (P.sortIndex = R, t(i, P), w || d || (w = true, qe(A))), P;
    }, e.unstable_shouldYield = Se, e.unstable_wrapCallback = function(P) {
      var C = f;
      return function() {
        var _ = f;
        f = C;
        try {
          return P.apply(this, arguments);
        } finally {
          f = _;
        }
      };
    };
  })(Wd);
  Gd.exports = Wd;
  var wm = Gd.exports;
  var vm = x, Be = wm;
  function E(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++)
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  var Yd = /* @__PURE__ */ new Set(), Zr = {};
  function An(e, t) {
    tr(e, t), tr(e + "Capture", t);
  }
  function tr(e, t) {
    for (Zr[e] = t, e = 0; e < t.length; e++)
      Yd.add(t[e]);
  }
  var bt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Ks = Object.prototype.hasOwnProperty, Sm = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, Zc = {}, Kc = {};
  function km(e) {
    return Ks.call(Kc, e) ? true : Ks.call(Zc, e) ? false : Sm.test(e) ? Kc[e] = true : (Zc[e] = true, false);
  }
  function Em(e, t, n, r) {
    if (n !== null && n.type === 0)
      return false;
    switch (typeof t) {
      case "function":
      case "symbol":
        return true;
      case "boolean":
        return r ? false : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
      default:
        return false;
    }
  }
  function Tm(e, t, n, r) {
    if (t === null || typeof t > "u" || Em(e, t, n, r))
      return true;
    if (r)
      return false;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === false;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return false;
  }
  function be(e, t, n, r, a, o, s) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = a, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = s;
  }
  var we = {};
  "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    we[e] = new be(e, 0, false, e, null, false, false);
  });
  [
    [
      "acceptCharset",
      "accept-charset"
    ],
    [
      "className",
      "class"
    ],
    [
      "htmlFor",
      "for"
    ],
    [
      "httpEquiv",
      "http-equiv"
    ]
  ].forEach(function(e) {
    var t = e[0];
    we[t] = new be(t, 1, false, e[1], null, false, false);
  });
  [
    "contentEditable",
    "draggable",
    "spellCheck",
    "value"
  ].forEach(function(e) {
    we[e] = new be(e, 2, false, e.toLowerCase(), null, false, false);
  });
  [
    "autoReverse",
    "externalResourcesRequired",
    "focusable",
    "preserveAlpha"
  ].forEach(function(e) {
    we[e] = new be(e, 2, false, e, null, false, false);
  });
  "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    we[e] = new be(e, 3, false, e.toLowerCase(), null, false, false);
  });
  [
    "checked",
    "multiple",
    "muted",
    "selected"
  ].forEach(function(e) {
    we[e] = new be(e, 3, true, e, null, false, false);
  });
  [
    "capture",
    "download"
  ].forEach(function(e) {
    we[e] = new be(e, 4, false, e, null, false, false);
  });
  [
    "cols",
    "rows",
    "size",
    "span"
  ].forEach(function(e) {
    we[e] = new be(e, 6, false, e, null, false, false);
  });
  [
    "rowSpan",
    "start"
  ].forEach(function(e) {
    we[e] = new be(e, 5, false, e.toLowerCase(), null, false, false);
  });
  var Ti = /[\-:]([a-z])/g;
  function xi(e) {
    return e[1].toUpperCase();
  }
  "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Ti, xi);
    we[t] = new be(t, 1, false, e, null, false, false);
  });
  "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Ti, xi);
    we[t] = new be(t, 1, false, e, "http://www.w3.org/1999/xlink", false, false);
  });
  [
    "xml:base",
    "xml:lang",
    "xml:space"
  ].forEach(function(e) {
    var t = e.replace(Ti, xi);
    we[t] = new be(t, 1, false, e, "http://www.w3.org/XML/1998/namespace", false, false);
  });
  [
    "tabIndex",
    "crossOrigin"
  ].forEach(function(e) {
    we[e] = new be(e, 1, false, e.toLowerCase(), null, false, false);
  });
  we.xlinkHref = new be("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
  [
    "src",
    "href",
    "action",
    "formAction"
  ].forEach(function(e) {
    we[e] = new be(e, 1, false, e.toLowerCase(), null, true, true);
  });
  function Ai(e, t, n, r) {
    var a = we.hasOwnProperty(t) ? we[t] : null;
    (a !== null ? a.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (Tm(t, n, a, r) && (n = null), r || a === null ? km(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : a.mustUseProperty ? e[a.propertyName] = n === null ? a.type === 3 ? false : "" : n : (t = a.attributeName, r = a.attributeNamespace, n === null ? e.removeAttribute(t) : (a = a.type, n = a === 3 || a === 4 && n === true ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var Ot = vm.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, Ca = Symbol.for("react.element"), Rn = Symbol.for("react.portal"), On = Symbol.for("react.fragment"), Mi = Symbol.for("react.strict_mode"), Xs = Symbol.for("react.profiler"), Qd = Symbol.for("react.provider"), Zd = Symbol.for("react.context"), Ci = Symbol.for("react.forward_ref"), qs = Symbol.for("react.suspense"), Js = Symbol.for("react.suspense_list"), Ni = Symbol.for("react.memo"), jt = Symbol.for("react.lazy"), Kd = Symbol.for("react.offscreen"), Xc = Symbol.iterator;
  function Er(e) {
    return e === null || typeof e != "object" ? null : (e = Xc && e[Xc] || e["@@iterator"], typeof e == "function" ? e : null);
  }
  var ne = Object.assign, ws;
  function br(e) {
    if (ws === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        ws = t && t[1] || "";
      }
    return `
` + ws + e;
  }
  var vs = false;
  function Ss(e, t) {
    if (!e || vs)
      return "";
    vs = true;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (t = function() {
          throw Error();
        }, Object.defineProperty(t.prototype, "props", {
          set: function() {
            throw Error();
          }
        }), typeof Reflect == "object" && Reflect.construct) {
          try {
            Reflect.construct(t, []);
          } catch (c) {
            var r = c;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (c) {
            r = c;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (c) {
          r = c;
        }
        e();
      }
    } catch (c) {
      if (c && r && typeof c.stack == "string") {
        for (var a = c.stack.split(`
`), o = r.stack.split(`
`), s = a.length - 1, l = o.length - 1; 1 <= s && 0 <= l && a[s] !== o[l]; )
          l--;
        for (; 1 <= s && 0 <= l; s--, l--)
          if (a[s] !== o[l]) {
            if (s !== 1 || l !== 1)
              do
                if (s--, l--, 0 > l || a[s] !== o[l]) {
                  var i = `
` + a[s].replace(" at new ", " at ");
                  return e.displayName && i.includes("<anonymous>") && (i = i.replace("<anonymous>", e.displayName)), i;
                }
              while (1 <= s && 0 <= l);
            break;
          }
      }
    } finally {
      vs = false, Error.prepareStackTrace = n;
    }
    return (e = e ? e.displayName || e.name : "") ? br(e) : "";
  }
  function xm(e) {
    switch (e.tag) {
      case 5:
        return br(e.type);
      case 16:
        return br("Lazy");
      case 13:
        return br("Suspense");
      case 19:
        return br("SuspenseList");
      case 0:
      case 2:
      case 15:
        return e = Ss(e.type, false), e;
      case 11:
        return e = Ss(e.type.render, false), e;
      case 1:
        return e = Ss(e.type, true), e;
      default:
        return "";
    }
  }
  function el(e) {
    if (e == null)
      return null;
    if (typeof e == "function")
      return e.displayName || e.name || null;
    if (typeof e == "string")
      return e;
    switch (e) {
      case On:
        return "Fragment";
      case Rn:
        return "Portal";
      case Xs:
        return "Profiler";
      case Mi:
        return "StrictMode";
      case qs:
        return "Suspense";
      case Js:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case Zd:
          return (e.displayName || "Context") + ".Consumer";
        case Qd:
          return (e._context.displayName || "Context") + ".Provider";
        case Ci:
          var t = e.render;
          return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Ni:
          return t = e.displayName || null, t !== null ? t : el(e.type) || "Memo";
        case jt:
          t = e._payload, e = e._init;
          try {
            return el(e(t));
          } catch {
          }
      }
    return null;
  }
  function Am(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return el(t);
      case 8:
        return t === Mi ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function")
          return t.displayName || t.name || null;
        if (typeof t == "string")
          return t;
    }
    return null;
  }
  function nn(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function Xd(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function Mm(e) {
    var t = Xd(e) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t), r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
      var a = n.get, o = n.set;
      return Object.defineProperty(e, t, {
        configurable: true,
        get: function() {
          return a.call(this);
        },
        set: function(s) {
          r = "" + s, o.call(this, s);
        }
      }), Object.defineProperty(e, t, {
        enumerable: n.enumerable
      }), {
        getValue: function() {
          return r;
        },
        setValue: function(s) {
          r = "" + s;
        },
        stopTracking: function() {
          e._valueTracker = null, delete e[t];
        }
      };
    }
  }
  function Na(e) {
    e._valueTracker || (e._valueTracker = Mm(e));
  }
  function qd(e) {
    if (!e)
      return false;
    var t = e._valueTracker;
    if (!t)
      return true;
    var n = t.getValue(), r = "";
    return e && (r = Xd(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), true) : false;
  }
  function io(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u")
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function tl(e, t) {
    var n = t.checked;
    return ne({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked
    });
  }
  function qc(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue, r = t.checked != null ? t.checked : t.defaultChecked;
    n = nn(t.value != null ? t.value : n), e._wrapperState = {
      initialChecked: r,
      initialValue: n,
      controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    };
  }
  function Jd(e, t) {
    t = t.checked, t != null && Ai(e, "checked", t, false);
  }
  function nl(e, t) {
    Jd(e, t);
    var n = nn(t.value), r = t.type;
    if (n != null)
      r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    t.hasOwnProperty("value") ? rl(e, t.type, n) : t.hasOwnProperty("defaultValue") && rl(e, t.type, nn(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked);
  }
  function Jc(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null))
        return;
      t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t;
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n);
  }
  function rl(e, t, n) {
    (t !== "number" || io(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var Lr = Array.isArray;
  function Yn(e, t, n, r) {
    if (e = e.options, t) {
      t = {};
      for (var a = 0; a < n.length; a++)
        t["$" + n[a]] = true;
      for (n = 0; n < e.length; n++)
        a = t.hasOwnProperty("$" + e[n].value), e[n].selected !== a && (e[n].selected = a), a && r && (e[n].defaultSelected = true);
    } else {
      for (n = "" + nn(n), t = null, a = 0; a < e.length; a++) {
        if (e[a].value === n) {
          e[a].selected = true, r && (e[a].defaultSelected = true);
          return;
        }
        t !== null || e[a].disabled || (t = e[a]);
      }
      t !== null && (t.selected = true);
    }
  }
  function al(e, t) {
    if (t.dangerouslySetInnerHTML != null)
      throw Error(E(91));
    return ne({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue
    });
  }
  function eu(e, t) {
    var n = t.value;
    if (n == null) {
      if (n = t.children, t = t.defaultValue, n != null) {
        if (t != null)
          throw Error(E(92));
        if (Lr(n)) {
          if (1 < n.length)
            throw Error(E(93));
          n = n[0];
        }
        t = n;
      }
      t == null && (t = ""), n = t;
    }
    e._wrapperState = {
      initialValue: nn(n)
    };
  }
  function ef(e, t) {
    var n = nn(t.value), r = nn(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r);
  }
  function tu(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
  }
  function tf(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function ol(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? tf(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e;
  }
  var Pa, nf = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, a) {
      MSApp.execUnsafeLocalFunction(function() {
        return e(t, n, r, a);
      });
    } : e;
  }(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
      e.innerHTML = t;
    else {
      for (Pa = Pa || document.createElement("div"), Pa.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = Pa.firstChild; e.firstChild; )
        e.removeChild(e.firstChild);
      for (; t.firstChild; )
        e.appendChild(t.firstChild);
    }
  });
  function Kr(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Fr = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    columns: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    flexOrder: true,
    gridArea: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowSpan: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnSpan: true,
    gridColumnStart: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
  }, Cm = [
    "Webkit",
    "ms",
    "Moz",
    "O"
  ];
  Object.keys(Fr).forEach(function(e) {
    Cm.forEach(function(t) {
      t = t + e.charAt(0).toUpperCase() + e.substring(1), Fr[t] = Fr[e];
    });
  });
  function rf(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Fr.hasOwnProperty(e) && Fr[e] ? ("" + t).trim() : t + "px";
  }
  function af(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0, a = rf(n, t[n], r);
        n === "float" && (n = "cssFloat"), r ? e.setProperty(n, a) : e[n] = a;
      }
  }
  var Nm = ne({
    menuitem: true
  }, {
    area: true,
    base: true,
    br: true,
    col: true,
    embed: true,
    hr: true,
    img: true,
    input: true,
    keygen: true,
    link: true,
    meta: true,
    param: true,
    source: true,
    track: true,
    wbr: true
  });
  function sl(e, t) {
    if (t) {
      if (Nm[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(E(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null)
          throw Error(E(60));
        if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML))
          throw Error(E(61));
      }
      if (t.style != null && typeof t.style != "object")
        throw Error(E(62));
    }
  }
  function ll(e, t) {
    if (e.indexOf("-") === -1)
      return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return false;
      default:
        return true;
    }
  }
  var il = null;
  function Pi(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
  }
  var cl = null, Qn = null, Zn = null;
  function nu(e) {
    if (e = ka(e)) {
      if (typeof cl != "function")
        throw Error(E(280));
      var t = e.stateNode;
      t && (t = Zo(t), cl(e.stateNode, e.type, t));
    }
  }
  function of(e) {
    Qn ? Zn ? Zn.push(e) : Zn = [
      e
    ] : Qn = e;
  }
  function sf() {
    if (Qn) {
      var e = Qn, t = Zn;
      if (Zn = Qn = null, nu(e), t)
        for (e = 0; e < t.length; e++)
          nu(t[e]);
    }
  }
  function lf(e, t) {
    return e(t);
  }
  function cf() {
  }
  var ks = false;
  function uf(e, t, n) {
    if (ks)
      return e(t, n);
    ks = true;
    try {
      return lf(e, t, n);
    } finally {
      ks = false, (Qn !== null || Zn !== null) && (cf(), sf());
    }
  }
  function Xr(e, t) {
    var n = e.stateNode;
    if (n === null)
      return null;
    var r = Zo(n);
    if (r === null)
      return null;
    n = r[t];
    e:
      switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
          break e;
        default:
          e = false;
      }
    if (e)
      return null;
    if (n && typeof n != "function")
      throw Error(E(231, t, typeof n));
    return n;
  }
  var ul = false;
  if (bt)
    try {
      var Tr = {};
      Object.defineProperty(Tr, "passive", {
        get: function() {
          ul = true;
        }
      }), window.addEventListener("test", Tr, Tr), window.removeEventListener("test", Tr, Tr);
    } catch {
      ul = false;
    }
  function Pm(e, t, n, r, a, o, s, l, i) {
    var c = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, c);
    } catch (u) {
      this.onError(u);
    }
  }
  var Ir = false, co = null, uo = false, dl = null, bm = {
    onError: function(e) {
      Ir = true, co = e;
    }
  };
  function Lm(e, t, n, r, a, o, s, l, i) {
    Ir = false, co = null, Pm.apply(bm, arguments);
  }
  function _m(e, t, n, r, a, o, s, l, i) {
    if (Lm.apply(this, arguments), Ir) {
      if (Ir) {
        var c = co;
        Ir = false, co = null;
      } else
        throw Error(E(198));
      uo || (uo = true, dl = c);
    }
  }
  function Mn(e) {
    var t = e, n = e;
    if (e.alternate)
      for (; t.return; )
        t = t.return;
    else {
      e = t;
      do
        t = e, t.flags & 4098 && (n = t.return), e = t.return;
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function df(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null)
        return t.dehydrated;
    }
    return null;
  }
  function ru(e) {
    if (Mn(e) !== e)
      throw Error(E(188));
  }
  function Rm(e) {
    var t = e.alternate;
    if (!t) {
      if (t = Mn(e), t === null)
        throw Error(E(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ; ) {
      var a = n.return;
      if (a === null)
        break;
      var o = a.alternate;
      if (o === null) {
        if (r = a.return, r !== null) {
          n = r;
          continue;
        }
        break;
      }
      if (a.child === o.child) {
        for (o = a.child; o; ) {
          if (o === n)
            return ru(a), e;
          if (o === r)
            return ru(a), t;
          o = o.sibling;
        }
        throw Error(E(188));
      }
      if (n.return !== r.return)
        n = a, r = o;
      else {
        for (var s = false, l = a.child; l; ) {
          if (l === n) {
            s = true, n = a, r = o;
            break;
          }
          if (l === r) {
            s = true, r = a, n = o;
            break;
          }
          l = l.sibling;
        }
        if (!s) {
          for (l = o.child; l; ) {
            if (l === n) {
              s = true, n = o, r = a;
              break;
            }
            if (l === r) {
              s = true, r = o, n = a;
              break;
            }
            l = l.sibling;
          }
          if (!s)
            throw Error(E(189));
        }
      }
      if (n.alternate !== r)
        throw Error(E(190));
    }
    if (n.tag !== 3)
      throw Error(E(188));
    return n.stateNode.current === n ? e : t;
  }
  function ff(e) {
    return e = Rm(e), e !== null ? pf(e) : null;
  }
  function pf(e) {
    if (e.tag === 5 || e.tag === 6)
      return e;
    for (e = e.child; e !== null; ) {
      var t = pf(e);
      if (t !== null)
        return t;
      e = e.sibling;
    }
    return null;
  }
  var gf = Be.unstable_scheduleCallback, au = Be.unstable_cancelCallback, Om = Be.unstable_shouldYield, Fm = Be.unstable_requestPaint, oe = Be.unstable_now, Im = Be.unstable_getCurrentPriorityLevel, bi = Be.unstable_ImmediatePriority, mf = Be.unstable_UserBlockingPriority, fo = Be.unstable_NormalPriority, Dm = Be.unstable_LowPriority, hf = Be.unstable_IdlePriority, Go = null, yt = null;
  function Um(e) {
    if (yt && typeof yt.onCommitFiberRoot == "function")
      try {
        yt.onCommitFiberRoot(Go, e, void 0, (e.current.flags & 128) === 128);
      } catch {
      }
  }
  var lt = Math.clz32 ? Math.clz32 : zm, $m = Math.log, jm = Math.LN2;
  function zm(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - ($m(e) / jm | 0) | 0;
  }
  var ba = 64, La = 4194304;
  function _r(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function po(e, t) {
    var n = e.pendingLanes;
    if (n === 0)
      return 0;
    var r = 0, a = e.suspendedLanes, o = e.pingedLanes, s = n & 268435455;
    if (s !== 0) {
      var l = s & ~a;
      l !== 0 ? r = _r(l) : (o &= s, o !== 0 && (r = _r(o)));
    } else
      s = n & ~a, s !== 0 ? r = _r(s) : o !== 0 && (r = _r(o));
    if (r === 0)
      return 0;
    if (t !== 0 && t !== r && !(t & a) && (a = r & -r, o = t & -t, a >= o || a === 16 && (o & 4194240) !== 0))
      return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
      for (e = e.entanglements, t &= r; 0 < t; )
        n = 31 - lt(t), a = 1 << n, r |= e[n], t &= ~a;
    return r;
  }
  function Bm(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Vm(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, a = e.expirationTimes, o = e.pendingLanes; 0 < o; ) {
      var s = 31 - lt(o), l = 1 << s, i = a[s];
      i === -1 ? (!(l & n) || l & r) && (a[s] = Bm(l, t)) : i <= t && (e.expiredLanes |= l), o &= ~l;
    }
  }
  function fl(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0;
  }
  function yf() {
    var e = ba;
    return ba <<= 1, !(ba & 4194240) && (ba = 64), e;
  }
  function Es(e) {
    for (var t = [], n = 0; 31 > n; n++)
      t.push(e);
    return t;
  }
  function va(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - lt(t), e[t] = n;
  }
  function Hm(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n; ) {
      var a = 31 - lt(n), o = 1 << a;
      t[a] = 0, r[a] = -1, e[a] = -1, n &= ~o;
    }
  }
  function Li(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n; ) {
      var r = 31 - lt(n), a = 1 << r;
      a & t | e[r] & t && (e[r] |= t), n &= ~a;
    }
  }
  var V = 0;
  function wf(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1;
  }
  var vf, _i, Sf, kf, Ef, pl = false, _a = [], Yt = null, Qt = null, Zt = null, qr = /* @__PURE__ */ new Map(), Jr = /* @__PURE__ */ new Map(), Bt = [], Gm = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
  function ou(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Yt = null;
        break;
      case "dragenter":
      case "dragleave":
        Qt = null;
        break;
      case "mouseover":
      case "mouseout":
        Zt = null;
        break;
      case "pointerover":
      case "pointerout":
        qr.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Jr.delete(t.pointerId);
    }
  }
  function xr(e, t, n, r, a, o) {
    return e === null || e.nativeEvent !== o ? (e = {
      blockedOn: t,
      domEventName: n,
      eventSystemFlags: r,
      nativeEvent: o,
      targetContainers: [
        a
      ]
    }, t !== null && (t = ka(t), t !== null && _i(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, a !== null && t.indexOf(a) === -1 && t.push(a), e);
  }
  function Wm(e, t, n, r, a) {
    switch (t) {
      case "focusin":
        return Yt = xr(Yt, e, t, n, r, a), true;
      case "dragenter":
        return Qt = xr(Qt, e, t, n, r, a), true;
      case "mouseover":
        return Zt = xr(Zt, e, t, n, r, a), true;
      case "pointerover":
        var o = a.pointerId;
        return qr.set(o, xr(qr.get(o) || null, e, t, n, r, a)), true;
      case "gotpointercapture":
        return o = a.pointerId, Jr.set(o, xr(Jr.get(o) || null, e, t, n, r, a)), true;
    }
    return false;
  }
  function Tf(e) {
    var t = gn(e.target);
    if (t !== null) {
      var n = Mn(t);
      if (n !== null) {
        if (t = n.tag, t === 13) {
          if (t = df(n), t !== null) {
            e.blockedOn = t, Ef(e.priority, function() {
              Sf(n);
            });
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function Ya(e) {
    if (e.blockedOn !== null)
      return false;
    for (var t = e.targetContainers; 0 < t.length; ) {
      var n = gl(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        il = r, n.target.dispatchEvent(r), il = null;
      } else
        return t = ka(n), t !== null && _i(t), e.blockedOn = n, false;
      t.shift();
    }
    return true;
  }
  function su(e, t, n) {
    Ya(e) && n.delete(t);
  }
  function Ym() {
    pl = false, Yt !== null && Ya(Yt) && (Yt = null), Qt !== null && Ya(Qt) && (Qt = null), Zt !== null && Ya(Zt) && (Zt = null), qr.forEach(su), Jr.forEach(su);
  }
  function Ar(e, t) {
    e.blockedOn === t && (e.blockedOn = null, pl || (pl = true, Be.unstable_scheduleCallback(Be.unstable_NormalPriority, Ym)));
  }
  function ea(e) {
    function t(a) {
      return Ar(a, e);
    }
    if (0 < _a.length) {
      Ar(_a[0], e);
      for (var n = 1; n < _a.length; n++) {
        var r = _a[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (Yt !== null && Ar(Yt, e), Qt !== null && Ar(Qt, e), Zt !== null && Ar(Zt, e), qr.forEach(t), Jr.forEach(t), n = 0; n < Bt.length; n++)
      r = Bt[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < Bt.length && (n = Bt[0], n.blockedOn === null); )
      Tf(n), n.blockedOn === null && Bt.shift();
  }
  var Kn = Ot.ReactCurrentBatchConfig, go = true;
  function Qm(e, t, n, r) {
    var a = V, o = Kn.transition;
    Kn.transition = null;
    try {
      V = 1, Ri(e, t, n, r);
    } finally {
      V = a, Kn.transition = o;
    }
  }
  function Zm(e, t, n, r) {
    var a = V, o = Kn.transition;
    Kn.transition = null;
    try {
      V = 4, Ri(e, t, n, r);
    } finally {
      V = a, Kn.transition = o;
    }
  }
  function Ri(e, t, n, r) {
    if (go) {
      var a = gl(e, t, n, r);
      if (a === null)
        _s(e, t, r, mo, n), ou(e, r);
      else if (Wm(a, e, t, n, r))
        r.stopPropagation();
      else if (ou(e, r), t & 4 && -1 < Gm.indexOf(e)) {
        for (; a !== null; ) {
          var o = ka(a);
          if (o !== null && vf(o), o = gl(e, t, n, r), o === null && _s(e, t, r, mo, n), o === a)
            break;
          a = o;
        }
        a !== null && r.stopPropagation();
      } else
        _s(e, t, r, null, n);
    }
  }
  var mo = null;
  function gl(e, t, n, r) {
    if (mo = null, e = Pi(r), e = gn(e), e !== null)
      if (t = Mn(e), t === null)
        e = null;
      else if (n = t.tag, n === 13) {
        if (e = df(t), e !== null)
          return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else
        t !== e && (e = null);
    return mo = e, null;
  }
  function xf(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (Im()) {
          case bi:
            return 1;
          case mf:
            return 4;
          case fo:
          case Dm:
            return 16;
          case hf:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var Gt = null, Oi = null, Qa = null;
  function Af() {
    if (Qa)
      return Qa;
    var e, t = Oi, n = t.length, r, a = "value" in Gt ? Gt.value : Gt.textContent, o = a.length;
    for (e = 0; e < n && t[e] === a[e]; e++)
      ;
    var s = n - e;
    for (r = 1; r <= s && t[n - r] === a[o - r]; r++)
      ;
    return Qa = a.slice(e, 1 < r ? 1 - r : void 0);
  }
  function Za(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
  }
  function Ra() {
    return true;
  }
  function lu() {
    return false;
  }
  function He(e) {
    function t(n, r, a, o, s) {
      this._reactName = n, this._targetInst = a, this.type = r, this.nativeEvent = o, this.target = s, this.currentTarget = null;
      for (var l in e)
        e.hasOwnProperty(l) && (n = e[l], this[l] = n ? n(o) : o[l]);
      return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === false) ? Ra : lu, this.isPropagationStopped = lu, this;
    }
    return ne(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = true;
        var n = this.nativeEvent;
        n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = false), this.isDefaultPrevented = Ra);
      },
      stopPropagation: function() {
        var n = this.nativeEvent;
        n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = true), this.isPropagationStopped = Ra);
      },
      persist: function() {
      },
      isPersistent: Ra
    }), t;
  }
  var gr = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, Fi = He(gr), Sa = ne({}, gr, {
    view: 0,
    detail: 0
  }), Km = He(Sa), Ts, xs, Mr, Wo = ne({}, Sa, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: Ii,
    button: 0,
    buttons: 0,
    relatedTarget: function(e) {
      return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
    },
    movementX: function(e) {
      return "movementX" in e ? e.movementX : (e !== Mr && (Mr && e.type === "mousemove" ? (Ts = e.screenX - Mr.screenX, xs = e.screenY - Mr.screenY) : xs = Ts = 0, Mr = e), Ts);
    },
    movementY: function(e) {
      return "movementY" in e ? e.movementY : xs;
    }
  }), iu = He(Wo), Xm = ne({}, Wo, {
    dataTransfer: 0
  }), qm = He(Xm), Jm = ne({}, Sa, {
    relatedTarget: 0
  }), As = He(Jm), eh = ne({}, gr, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), th = He(eh), nh = ne({}, gr, {
    clipboardData: function(e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    }
  }), rh = He(nh), ah = ne({}, gr, {
    data: 0
  }), cu = He(ah), oh = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, sh = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, lh = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function ih(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = lh[e]) ? !!t[e] : false;
  }
  function Ii() {
    return ih;
  }
  var ch = ne({}, Sa, {
    key: function(e) {
      if (e.key) {
        var t = oh[e.key] || e.key;
        if (t !== "Unidentified")
          return t;
      }
      return e.type === "keypress" ? (e = Za(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? sh[e.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: Ii,
    charCode: function(e) {
      return e.type === "keypress" ? Za(e) : 0;
    },
    keyCode: function(e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function(e) {
      return e.type === "keypress" ? Za(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    }
  }), uh = He(ch), dh = ne({}, Wo, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), uu = He(dh), fh = ne({}, Sa, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: Ii
  }), ph = He(fh), gh = ne({}, gr, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), mh = He(gh), hh = ne({}, Wo, {
    deltaX: function(e) {
      return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
    },
    deltaY: function(e) {
      return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), yh = He(hh), wh = [
    9,
    13,
    27,
    32
  ], Di = bt && "CompositionEvent" in window, Dr = null;
  bt && "documentMode" in document && (Dr = document.documentMode);
  var vh = bt && "TextEvent" in window && !Dr, Mf = bt && (!Di || Dr && 8 < Dr && 11 >= Dr), du = String.fromCharCode(32), fu = false;
  function Cf(e, t) {
    switch (e) {
      case "keyup":
        return wh.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return true;
      default:
        return false;
    }
  }
  function Nf(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
  }
  var Fn = false;
  function Sh(e, t) {
    switch (e) {
      case "compositionend":
        return Nf(t);
      case "keypress":
        return t.which !== 32 ? null : (fu = true, du);
      case "textInput":
        return e = t.data, e === du && fu ? null : e;
      default:
        return null;
    }
  }
  function kh(e, t) {
    if (Fn)
      return e === "compositionend" || !Di && Cf(e, t) ? (e = Af(), Qa = Oi = Gt = null, Fn = false, e) : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
          if (t.char && 1 < t.char.length)
            return t.char;
          if (t.which)
            return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Mf && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Eh = {
    color: true,
    date: true,
    datetime: true,
    "datetime-local": true,
    email: true,
    month: true,
    number: true,
    password: true,
    range: true,
    search: true,
    tel: true,
    text: true,
    time: true,
    url: true,
    week: true
  };
  function pu(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Eh[e.type] : t === "textarea";
  }
  function Pf(e, t, n, r) {
    of(r), t = ho(t, "onChange"), 0 < t.length && (n = new Fi("onChange", "change", null, n, r), e.push({
      event: n,
      listeners: t
    }));
  }
  var Ur = null, ta = null;
  function Th(e) {
    jf(e, 0);
  }
  function Yo(e) {
    var t = Un(e);
    if (qd(t))
      return e;
  }
  function xh(e, t) {
    if (e === "change")
      return t;
  }
  var bf = false;
  if (bt) {
    var Ms;
    if (bt) {
      var Cs = "oninput" in document;
      if (!Cs) {
        var gu = document.createElement("div");
        gu.setAttribute("oninput", "return;"), Cs = typeof gu.oninput == "function";
      }
      Ms = Cs;
    } else
      Ms = false;
    bf = Ms && (!document.documentMode || 9 < document.documentMode);
  }
  function mu() {
    Ur && (Ur.detachEvent("onpropertychange", Lf), ta = Ur = null);
  }
  function Lf(e) {
    if (e.propertyName === "value" && Yo(ta)) {
      var t = [];
      Pf(t, ta, e, Pi(e)), uf(Th, t);
    }
  }
  function Ah(e, t, n) {
    e === "focusin" ? (mu(), Ur = t, ta = n, Ur.attachEvent("onpropertychange", Lf)) : e === "focusout" && mu();
  }
  function Mh(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Yo(ta);
  }
  function Ch(e, t) {
    if (e === "click")
      return Yo(t);
  }
  function Nh(e, t) {
    if (e === "input" || e === "change")
      return Yo(t);
  }
  function Ph(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
  }
  var ut = typeof Object.is == "function" ? Object.is : Ph;
  function na(e, t) {
    if (ut(e, t))
      return true;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null)
      return false;
    var n = Object.keys(e), r = Object.keys(t);
    if (n.length !== r.length)
      return false;
    for (r = 0; r < n.length; r++) {
      var a = n[r];
      if (!Ks.call(t, a) || !ut(e[a], t[a]))
        return false;
    }
    return true;
  }
  function hu(e) {
    for (; e && e.firstChild; )
      e = e.firstChild;
    return e;
  }
  function yu(e, t) {
    var n = hu(e);
    e = 0;
    for (var r; n; ) {
      if (n.nodeType === 3) {
        if (r = e + n.textContent.length, e <= t && r >= t)
          return {
            node: n,
            offset: t - e
          };
        e = r;
      }
      e: {
        for (; n; ) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = hu(n);
    }
  }
  function _f(e, t) {
    return e && t ? e === t ? true : e && e.nodeType === 3 ? false : t && t.nodeType === 3 ? _f(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : false : false;
  }
  function Rf() {
    for (var e = window, t = io(); t instanceof e.HTMLIFrameElement; ) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = false;
      }
      if (n)
        e = t.contentWindow;
      else
        break;
      t = io(e.document);
    }
    return t;
  }
  function Ui(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
  }
  function bh(e) {
    var t = Rf(), n = e.focusedElem, r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && _f(n.ownerDocument.documentElement, n)) {
      if (r !== null && Ui(n)) {
        if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n)
          n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
        else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
          e = e.getSelection();
          var a = n.textContent.length, o = Math.min(r.start, a);
          r = r.end === void 0 ? o : Math.min(r.end, a), !e.extend && o > r && (a = r, r = o, o = a), a = yu(n, o);
          var s = yu(n, r);
          a && s && (e.rangeCount !== 1 || e.anchorNode !== a.node || e.anchorOffset !== a.offset || e.focusNode !== s.node || e.focusOffset !== s.offset) && (t = t.createRange(), t.setStart(a.node, a.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(s.node, s.offset)) : (t.setEnd(s.node, s.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; e = e.parentNode; )
        e.nodeType === 1 && t.push({
          element: e,
          left: e.scrollLeft,
          top: e.scrollTop
        });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top;
    }
  }
  var Lh = bt && "documentMode" in document && 11 >= document.documentMode, In = null, ml = null, $r = null, hl = false;
  function wu(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    hl || In == null || In !== io(r) || (r = In, "selectionStart" in r && Ui(r) ? r = {
      start: r.selectionStart,
      end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
      anchorNode: r.anchorNode,
      anchorOffset: r.anchorOffset,
      focusNode: r.focusNode,
      focusOffset: r.focusOffset
    }), $r && na($r, r) || ($r = r, r = ho(ml, "onSelect"), 0 < r.length && (t = new Fi("onSelect", "select", null, t, n), e.push({
      event: t,
      listeners: r
    }), t.target = In)));
  }
  function Oa(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n;
  }
  var Dn = {
    animationend: Oa("Animation", "AnimationEnd"),
    animationiteration: Oa("Animation", "AnimationIteration"),
    animationstart: Oa("Animation", "AnimationStart"),
    transitionend: Oa("Transition", "TransitionEnd")
  }, Ns = {}, Of = {};
  bt && (Of = document.createElement("div").style, "AnimationEvent" in window || (delete Dn.animationend.animation, delete Dn.animationiteration.animation, delete Dn.animationstart.animation), "TransitionEvent" in window || delete Dn.transitionend.transition);
  function Qo(e) {
    if (Ns[e])
      return Ns[e];
    if (!Dn[e])
      return e;
    var t = Dn[e], n;
    for (n in t)
      if (t.hasOwnProperty(n) && n in Of)
        return Ns[e] = t[n];
    return e;
  }
  var Ff = Qo("animationend"), If = Qo("animationiteration"), Df = Qo("animationstart"), Uf = Qo("transitionend"), $f = /* @__PURE__ */ new Map(), vu = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  function an(e, t) {
    $f.set(e, t), An(t, [
      e
    ]);
  }
  for (var Ps = 0; Ps < vu.length; Ps++) {
    var bs = vu[Ps], _h = bs.toLowerCase(), Rh = bs[0].toUpperCase() + bs.slice(1);
    an(_h, "on" + Rh);
  }
  an(Ff, "onAnimationEnd");
  an(If, "onAnimationIteration");
  an(Df, "onAnimationStart");
  an("dblclick", "onDoubleClick");
  an("focusin", "onFocus");
  an("focusout", "onBlur");
  an(Uf, "onTransitionEnd");
  tr("onMouseEnter", [
    "mouseout",
    "mouseover"
  ]);
  tr("onMouseLeave", [
    "mouseout",
    "mouseover"
  ]);
  tr("onPointerEnter", [
    "pointerout",
    "pointerover"
  ]);
  tr("onPointerLeave", [
    "pointerout",
    "pointerover"
  ]);
  An("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
  An("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
  An("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]);
  An("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
  An("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
  An("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  var Rr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), Oh = new Set("cancel close invalid load scroll toggle".split(" ").concat(Rr));
  function Su(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, _m(r, t, void 0, e), e.currentTarget = null;
  }
  function jf(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n], a = r.event;
      r = r.listeners;
      e: {
        var o = void 0;
        if (t)
          for (var s = r.length - 1; 0 <= s; s--) {
            var l = r[s], i = l.instance, c = l.currentTarget;
            if (l = l.listener, i !== o && a.isPropagationStopped())
              break e;
            Su(a, l, c), o = i;
          }
        else
          for (s = 0; s < r.length; s++) {
            if (l = r[s], i = l.instance, c = l.currentTarget, l = l.listener, i !== o && a.isPropagationStopped())
              break e;
            Su(a, l, c), o = i;
          }
      }
    }
    if (uo)
      throw e = dl, uo = false, dl = null, e;
  }
  function K(e, t) {
    var n = t[kl];
    n === void 0 && (n = t[kl] = /* @__PURE__ */ new Set());
    var r = e + "__bubble";
    n.has(r) || (zf(t, e, 2, false), n.add(r));
  }
  function Ls(e, t, n) {
    var r = 0;
    t && (r |= 4), zf(n, e, r, t);
  }
  var Fa = "_reactListening" + Math.random().toString(36).slice(2);
  function ra(e) {
    if (!e[Fa]) {
      e[Fa] = true, Yd.forEach(function(n) {
        n !== "selectionchange" && (Oh.has(n) || Ls(n, false, e), Ls(n, true, e));
      });
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[Fa] || (t[Fa] = true, Ls("selectionchange", false, t));
    }
  }
  function zf(e, t, n, r) {
    switch (xf(t)) {
      case 1:
        var a = Qm;
        break;
      case 4:
        a = Zm;
        break;
      default:
        a = Ri;
    }
    n = a.bind(null, t, n, e), a = void 0, !ul || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (a = true), r ? a !== void 0 ? e.addEventListener(t, n, {
      capture: true,
      passive: a
    }) : e.addEventListener(t, n, true) : a !== void 0 ? e.addEventListener(t, n, {
      passive: a
    }) : e.addEventListener(t, n, false);
  }
  function _s(e, t, n, r, a) {
    var o = r;
    if (!(t & 1) && !(t & 2) && r !== null)
      e:
        for (; ; ) {
          if (r === null)
            return;
          var s = r.tag;
          if (s === 3 || s === 4) {
            var l = r.stateNode.containerInfo;
            if (l === a || l.nodeType === 8 && l.parentNode === a)
              break;
            if (s === 4)
              for (s = r.return; s !== null; ) {
                var i = s.tag;
                if ((i === 3 || i === 4) && (i = s.stateNode.containerInfo, i === a || i.nodeType === 8 && i.parentNode === a))
                  return;
                s = s.return;
              }
            for (; l !== null; ) {
              if (s = gn(l), s === null)
                return;
              if (i = s.tag, i === 5 || i === 6) {
                r = o = s;
                continue e;
              }
              l = l.parentNode;
            }
          }
          r = r.return;
        }
    uf(function() {
      var c = o, u = Pi(n), p = [];
      e: {
        var f = $f.get(e);
        if (f !== void 0) {
          var d = Fi, w = e;
          switch (e) {
            case "keypress":
              if (Za(n) === 0)
                break e;
            case "keydown":
            case "keyup":
              d = uh;
              break;
            case "focusin":
              w = "focus", d = As;
              break;
            case "focusout":
              w = "blur", d = As;
              break;
            case "beforeblur":
            case "afterblur":
              d = As;
              break;
            case "click":
              if (n.button === 2)
                break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              d = iu;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              d = qm;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              d = ph;
              break;
            case Ff:
            case If:
            case Df:
              d = th;
              break;
            case Uf:
              d = mh;
              break;
            case "scroll":
              d = Km;
              break;
            case "wheel":
              d = yh;
              break;
            case "copy":
            case "cut":
            case "paste":
              d = rh;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              d = uu;
          }
          var y = (t & 4) !== 0, S = !y && e === "scroll", g = y ? f !== null ? f + "Capture" : null : f;
          y = [];
          for (var m = c, h; m !== null; ) {
            h = m;
            var v = h.stateNode;
            if (h.tag === 5 && v !== null && (h = v, g !== null && (v = Xr(m, g), v != null && y.push(aa(m, v, h)))), S)
              break;
            m = m.return;
          }
          0 < y.length && (f = new d(f, w, null, n, u), p.push({
            event: f,
            listeners: y
          }));
        }
      }
      if (!(t & 7)) {
        e: {
          if (f = e === "mouseover" || e === "pointerover", d = e === "mouseout" || e === "pointerout", f && n !== il && (w = n.relatedTarget || n.fromElement) && (gn(w) || w[Lt]))
            break e;
          if ((d || f) && (f = u.window === u ? u : (f = u.ownerDocument) ? f.defaultView || f.parentWindow : window, d ? (w = n.relatedTarget || n.toElement, d = c, w = w ? gn(w) : null, w !== null && (S = Mn(w), w !== S || w.tag !== 5 && w.tag !== 6) && (w = null)) : (d = null, w = c), d !== w)) {
            if (y = iu, v = "onMouseLeave", g = "onMouseEnter", m = "mouse", (e === "pointerout" || e === "pointerover") && (y = uu, v = "onPointerLeave", g = "onPointerEnter", m = "pointer"), S = d == null ? f : Un(d), h = w == null ? f : Un(w), f = new y(v, m + "leave", d, n, u), f.target = S, f.relatedTarget = h, v = null, gn(u) === c && (y = new y(g, m + "enter", w, n, u), y.target = h, y.relatedTarget = S, v = y), S = v, d && w)
              t: {
                for (y = d, g = w, m = 0, h = y; h; h = _n(h))
                  m++;
                for (h = 0, v = g; v; v = _n(v))
                  h++;
                for (; 0 < m - h; )
                  y = _n(y), m--;
                for (; 0 < h - m; )
                  g = _n(g), h--;
                for (; m--; ) {
                  if (y === g || g !== null && y === g.alternate)
                    break t;
                  y = _n(y), g = _n(g);
                }
                y = null;
              }
            else
              y = null;
            d !== null && ku(p, f, d, y, false), w !== null && S !== null && ku(p, S, w, y, true);
          }
        }
        e: {
          if (f = c ? Un(c) : window, d = f.nodeName && f.nodeName.toLowerCase(), d === "select" || d === "input" && f.type === "file")
            var A = xh;
          else if (pu(f))
            if (bf)
              A = Nh;
            else {
              A = Mh;
              var T = Ah;
            }
          else
            (d = f.nodeName) && d.toLowerCase() === "input" && (f.type === "checkbox" || f.type === "radio") && (A = Ch);
          if (A && (A = A(e, c))) {
            Pf(p, A, n, u);
            break e;
          }
          T && T(e, f, c), e === "focusout" && (T = f._wrapperState) && T.controlled && f.type === "number" && rl(f, "number", f.value);
        }
        switch (T = c ? Un(c) : window, e) {
          case "focusin":
            (pu(T) || T.contentEditable === "true") && (In = T, ml = c, $r = null);
            break;
          case "focusout":
            $r = ml = In = null;
            break;
          case "mousedown":
            hl = true;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            hl = false, wu(p, n, u);
            break;
          case "selectionchange":
            if (Lh)
              break;
          case "keydown":
          case "keyup":
            wu(p, n, u);
        }
        var N;
        if (Di)
          e: {
            switch (e) {
              case "compositionstart":
                var L = "onCompositionStart";
                break e;
              case "compositionend":
                L = "onCompositionEnd";
                break e;
              case "compositionupdate":
                L = "onCompositionUpdate";
                break e;
            }
            L = void 0;
          }
        else
          Fn ? Cf(e, n) && (L = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (L = "onCompositionStart");
        L && (Mf && n.locale !== "ko" && (Fn || L !== "onCompositionStart" ? L === "onCompositionEnd" && Fn && (N = Af()) : (Gt = u, Oi = "value" in Gt ? Gt.value : Gt.textContent, Fn = true)), T = ho(c, L), 0 < T.length && (L = new cu(L, e, null, n, u), p.push({
          event: L,
          listeners: T
        }), N ? L.data = N : (N = Nf(n), N !== null && (L.data = N)))), (N = vh ? Sh(e, n) : kh(e, n)) && (c = ho(c, "onBeforeInput"), 0 < c.length && (u = new cu("onBeforeInput", "beforeinput", null, n, u), p.push({
          event: u,
          listeners: c
        }), u.data = N));
      }
      jf(p, t);
    });
  }
  function aa(e, t, n) {
    return {
      instance: e,
      listener: t,
      currentTarget: n
    };
  }
  function ho(e, t) {
    for (var n = t + "Capture", r = []; e !== null; ) {
      var a = e, o = a.stateNode;
      a.tag === 5 && o !== null && (a = o, o = Xr(e, n), o != null && r.unshift(aa(e, o, a)), o = Xr(e, t), o != null && r.push(aa(e, o, a))), e = e.return;
    }
    return r;
  }
  function _n(e) {
    if (e === null)
      return null;
    do
      e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function ku(e, t, n, r, a) {
    for (var o = t._reactName, s = []; n !== null && n !== r; ) {
      var l = n, i = l.alternate, c = l.stateNode;
      if (i !== null && i === r)
        break;
      l.tag === 5 && c !== null && (l = c, a ? (i = Xr(n, o), i != null && s.unshift(aa(n, i, l))) : a || (i = Xr(n, o), i != null && s.push(aa(n, i, l)))), n = n.return;
    }
    s.length !== 0 && e.push({
      event: t,
      listeners: s
    });
  }
  var Fh = /\r\n?/g, Ih = /\u0000|\uFFFD/g;
  function Eu(e) {
    return (typeof e == "string" ? e : "" + e).replace(Fh, `
`).replace(Ih, "");
  }
  function Ia(e, t, n) {
    if (t = Eu(t), Eu(e) !== t && n)
      throw Error(E(425));
  }
  function yo() {
  }
  var yl = null, wl = null;
  function vl(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  var Sl = typeof setTimeout == "function" ? setTimeout : void 0, Dh = typeof clearTimeout == "function" ? clearTimeout : void 0, Tu = typeof Promise == "function" ? Promise : void 0, Uh = typeof queueMicrotask == "function" ? queueMicrotask : typeof Tu < "u" ? function(e) {
    return Tu.resolve(null).then(e).catch($h);
  } : Sl;
  function $h(e) {
    setTimeout(function() {
      throw e;
    });
  }
  function Rs(e, t) {
    var n = t, r = 0;
    do {
      var a = n.nextSibling;
      if (e.removeChild(n), a && a.nodeType === 8)
        if (n = a.data, n === "/$") {
          if (r === 0) {
            e.removeChild(a), ea(t);
            return;
          }
          r--;
        } else
          n !== "$" && n !== "$?" && n !== "$!" || r++;
      n = a;
    } while (n);
    ea(t);
  }
  function Kt(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3)
        break;
      if (t === 8) {
        if (t = e.data, t === "$" || t === "$!" || t === "$?")
          break;
        if (t === "/$")
          return null;
      }
    }
    return e;
  }
  function xu(e) {
    e = e.previousSibling;
    for (var t = 0; e; ) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0)
            return e;
          t--;
        } else
          n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var mr = Math.random().toString(36).slice(2), mt = "__reactFiber$" + mr, oa = "__reactProps$" + mr, Lt = "__reactContainer$" + mr, kl = "__reactEvents$" + mr, jh = "__reactListeners$" + mr, zh = "__reactHandles$" + mr;
  function gn(e) {
    var t = e[mt];
    if (t)
      return t;
    for (var n = e.parentNode; n; ) {
      if (t = n[Lt] || n[mt]) {
        if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
          for (e = xu(e); e !== null; ) {
            if (n = e[mt])
              return n;
            e = xu(e);
          }
        return t;
      }
      e = n, n = e.parentNode;
    }
    return null;
  }
  function ka(e) {
    return e = e[mt] || e[Lt], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e;
  }
  function Un(e) {
    if (e.tag === 5 || e.tag === 6)
      return e.stateNode;
    throw Error(E(33));
  }
  function Zo(e) {
    return e[oa] || null;
  }
  var El = [], $n = -1;
  function on(e) {
    return {
      current: e
    };
  }
  function X(e) {
    0 > $n || (e.current = El[$n], El[$n] = null, $n--);
  }
  function Q(e, t) {
    $n++, El[$n] = e.current, e.current = t;
  }
  var rn = {}, xe = on(rn), Fe = on(false), Sn = rn;
  function nr(e, t) {
    var n = e.type.contextTypes;
    if (!n)
      return rn;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var a = {}, o;
    for (o in n)
      a[o] = t[o];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = a), a;
  }
  function Ie(e) {
    return e = e.childContextTypes, e != null;
  }
  function wo() {
    X(Fe), X(xe);
  }
  function Au(e, t, n) {
    if (xe.current !== rn)
      throw Error(E(168));
    Q(xe, t), Q(Fe, n);
  }
  function Bf(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function")
      return n;
    r = r.getChildContext();
    for (var a in r)
      if (!(a in t))
        throw Error(E(108, Am(e) || "Unknown", a));
    return ne({}, n, r);
  }
  function vo(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || rn, Sn = xe.current, Q(xe, e), Q(Fe, Fe.current), true;
  }
  function Mu(e, t, n) {
    var r = e.stateNode;
    if (!r)
      throw Error(E(169));
    n ? (e = Bf(e, t, Sn), r.__reactInternalMemoizedMergedChildContext = e, X(Fe), X(xe), Q(xe, e)) : X(Fe), Q(Fe, n);
  }
  var Tt = null, Ko = false, Os = false;
  function Vf(e) {
    Tt === null ? Tt = [
      e
    ] : Tt.push(e);
  }
  function Bh(e) {
    Ko = true, Vf(e);
  }
  function sn() {
    if (!Os && Tt !== null) {
      Os = true;
      var e = 0, t = V;
      try {
        var n = Tt;
        for (V = 1; e < n.length; e++) {
          var r = n[e];
          do
            r = r(true);
          while (r !== null);
        }
        Tt = null, Ko = false;
      } catch (a) {
        throw Tt !== null && (Tt = Tt.slice(e + 1)), gf(bi, sn), a;
      } finally {
        V = t, Os = false;
      }
    }
    return null;
  }
  var jn = [], zn = 0, So = null, ko = 0, We = [], Ye = 0, kn = null, At = 1, Mt = "";
  function dn(e, t) {
    jn[zn++] = ko, jn[zn++] = So, So = e, ko = t;
  }
  function Hf(e, t, n) {
    We[Ye++] = At, We[Ye++] = Mt, We[Ye++] = kn, kn = e;
    var r = At;
    e = Mt;
    var a = 32 - lt(r) - 1;
    r &= ~(1 << a), n += 1;
    var o = 32 - lt(t) + a;
    if (30 < o) {
      var s = a - a % 5;
      o = (r & (1 << s) - 1).toString(32), r >>= s, a -= s, At = 1 << 32 - lt(t) + a | n << a | r, Mt = o + e;
    } else
      At = 1 << o | n << a | r, Mt = e;
  }
  function $i(e) {
    e.return !== null && (dn(e, 1), Hf(e, 1, 0));
  }
  function ji(e) {
    for (; e === So; )
      So = jn[--zn], jn[zn] = null, ko = jn[--zn], jn[zn] = null;
    for (; e === kn; )
      kn = We[--Ye], We[Ye] = null, Mt = We[--Ye], We[Ye] = null, At = We[--Ye], We[Ye] = null;
  }
  var ze = null, je = null, J = false, st = null;
  function Gf(e, t) {
    var n = Qe(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [
      n
    ], e.flags |= 16) : t.push(n);
  }
  function Cu(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, ze = e, je = Kt(t.firstChild), true) : false;
      case 6:
        return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, ze = e, je = null, true) : false;
      case 13:
        return t = t.nodeType !== 8 ? null : t, t !== null ? (n = kn !== null ? {
          id: At,
          overflow: Mt
        } : null, e.memoizedState = {
          dehydrated: t,
          treeContext: n,
          retryLane: 1073741824
        }, n = Qe(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, ze = e, je = null, true) : false;
      default:
        return false;
    }
  }
  function Tl(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function xl(e) {
    if (J) {
      var t = je;
      if (t) {
        var n = t;
        if (!Cu(e, t)) {
          if (Tl(e))
            throw Error(E(418));
          t = Kt(n.nextSibling);
          var r = ze;
          t && Cu(e, t) ? Gf(r, n) : (e.flags = e.flags & -4097 | 2, J = false, ze = e);
        }
      } else {
        if (Tl(e))
          throw Error(E(418));
        e.flags = e.flags & -4097 | 2, J = false, ze = e;
      }
    }
  }
  function Nu(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; )
      e = e.return;
    ze = e;
  }
  function Da(e) {
    if (e !== ze)
      return false;
    if (!J)
      return Nu(e), J = true, false;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !vl(e.type, e.memoizedProps)), t && (t = je)) {
      if (Tl(e))
        throw Wf(), Error(E(418));
      for (; t; )
        Gf(e, t), t = Kt(t.nextSibling);
    }
    if (Nu(e), e.tag === 13) {
      if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e)
        throw Error(E(317));
      e: {
        for (e = e.nextSibling, t = 0; e; ) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                je = Kt(e.nextSibling);
                break e;
              }
              t--;
            } else
              n !== "$" && n !== "$!" && n !== "$?" || t++;
          }
          e = e.nextSibling;
        }
        je = null;
      }
    } else
      je = ze ? Kt(e.stateNode.nextSibling) : null;
    return true;
  }
  function Wf() {
    for (var e = je; e; )
      e = Kt(e.nextSibling);
  }
  function rr() {
    je = ze = null, J = false;
  }
  function zi(e) {
    st === null ? st = [
      e
    ] : st.push(e);
  }
  var Vh = Ot.ReactCurrentBatchConfig;
  function Cr(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
      if (n._owner) {
        if (n = n._owner, n) {
          if (n.tag !== 1)
            throw Error(E(309));
          var r = n.stateNode;
        }
        if (!r)
          throw Error(E(147, e));
        var a = r, o = "" + e;
        return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(s) {
          var l = a.refs;
          s === null ? delete l[o] : l[o] = s;
        }, t._stringRef = o, t);
      }
      if (typeof e != "string")
        throw Error(E(284));
      if (!n._owner)
        throw Error(E(290, e));
    }
    return e;
  }
  function Ua(e, t) {
    throw e = Object.prototype.toString.call(t), Error(E(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e));
  }
  function Pu(e) {
    var t = e._init;
    return t(e._payload);
  }
  function Yf(e) {
    function t(g, m) {
      if (e) {
        var h = g.deletions;
        h === null ? (g.deletions = [
          m
        ], g.flags |= 16) : h.push(m);
      }
    }
    function n(g, m) {
      if (!e)
        return null;
      for (; m !== null; )
        t(g, m), m = m.sibling;
      return null;
    }
    function r(g, m) {
      for (g = /* @__PURE__ */ new Map(); m !== null; )
        m.key !== null ? g.set(m.key, m) : g.set(m.index, m), m = m.sibling;
      return g;
    }
    function a(g, m) {
      return g = en(g, m), g.index = 0, g.sibling = null, g;
    }
    function o(g, m, h) {
      return g.index = h, e ? (h = g.alternate, h !== null ? (h = h.index, h < m ? (g.flags |= 2, m) : h) : (g.flags |= 2, m)) : (g.flags |= 1048576, m);
    }
    function s(g) {
      return e && g.alternate === null && (g.flags |= 2), g;
    }
    function l(g, m, h, v) {
      return m === null || m.tag !== 6 ? (m = zs(h, g.mode, v), m.return = g, m) : (m = a(m, h), m.return = g, m);
    }
    function i(g, m, h, v) {
      var A = h.type;
      return A === On ? u(g, m, h.props.children, v, h.key) : m !== null && (m.elementType === A || typeof A == "object" && A !== null && A.$$typeof === jt && Pu(A) === m.type) ? (v = a(m, h.props), v.ref = Cr(g, m, h), v.return = g, v) : (v = no(h.type, h.key, h.props, null, g.mode, v), v.ref = Cr(g, m, h), v.return = g, v);
    }
    function c(g, m, h, v) {
      return m === null || m.tag !== 4 || m.stateNode.containerInfo !== h.containerInfo || m.stateNode.implementation !== h.implementation ? (m = Bs(h, g.mode, v), m.return = g, m) : (m = a(m, h.children || []), m.return = g, m);
    }
    function u(g, m, h, v, A) {
      return m === null || m.tag !== 7 ? (m = vn(h, g.mode, v, A), m.return = g, m) : (m = a(m, h), m.return = g, m);
    }
    function p(g, m, h) {
      if (typeof m == "string" && m !== "" || typeof m == "number")
        return m = zs("" + m, g.mode, h), m.return = g, m;
      if (typeof m == "object" && m !== null) {
        switch (m.$$typeof) {
          case Ca:
            return h = no(m.type, m.key, m.props, null, g.mode, h), h.ref = Cr(g, null, m), h.return = g, h;
          case Rn:
            return m = Bs(m, g.mode, h), m.return = g, m;
          case jt:
            var v = m._init;
            return p(g, v(m._payload), h);
        }
        if (Lr(m) || Er(m))
          return m = vn(m, g.mode, h, null), m.return = g, m;
        Ua(g, m);
      }
      return null;
    }
    function f(g, m, h, v) {
      var A = m !== null ? m.key : null;
      if (typeof h == "string" && h !== "" || typeof h == "number")
        return A !== null ? null : l(g, m, "" + h, v);
      if (typeof h == "object" && h !== null) {
        switch (h.$$typeof) {
          case Ca:
            return h.key === A ? i(g, m, h, v) : null;
          case Rn:
            return h.key === A ? c(g, m, h, v) : null;
          case jt:
            return A = h._init, f(g, m, A(h._payload), v);
        }
        if (Lr(h) || Er(h))
          return A !== null ? null : u(g, m, h, v, null);
        Ua(g, h);
      }
      return null;
    }
    function d(g, m, h, v, A) {
      if (typeof v == "string" && v !== "" || typeof v == "number")
        return g = g.get(h) || null, l(m, g, "" + v, A);
      if (typeof v == "object" && v !== null) {
        switch (v.$$typeof) {
          case Ca:
            return g = g.get(v.key === null ? h : v.key) || null, i(m, g, v, A);
          case Rn:
            return g = g.get(v.key === null ? h : v.key) || null, c(m, g, v, A);
          case jt:
            var T = v._init;
            return d(g, m, h, T(v._payload), A);
        }
        if (Lr(v) || Er(v))
          return g = g.get(h) || null, u(m, g, v, A, null);
        Ua(m, v);
      }
      return null;
    }
    function w(g, m, h, v) {
      for (var A = null, T = null, N = m, L = m = 0, W = null; N !== null && L < h.length; L++) {
        N.index > L ? (W = N, N = null) : W = N.sibling;
        var I = f(g, N, h[L], v);
        if (I === null) {
          N === null && (N = W);
          break;
        }
        e && N && I.alternate === null && t(g, N), m = o(I, m, L), T === null ? A = I : T.sibling = I, T = I, N = W;
      }
      if (L === h.length)
        return n(g, N), J && dn(g, L), A;
      if (N === null) {
        for (; L < h.length; L++)
          N = p(g, h[L], v), N !== null && (m = o(N, m, L), T === null ? A = N : T.sibling = N, T = N);
        return J && dn(g, L), A;
      }
      for (N = r(g, N); L < h.length; L++)
        W = d(N, g, L, h[L], v), W !== null && (e && W.alternate !== null && N.delete(W.key === null ? L : W.key), m = o(W, m, L), T === null ? A = W : T.sibling = W, T = W);
      return e && N.forEach(function(Se) {
        return t(g, Se);
      }), J && dn(g, L), A;
    }
    function y(g, m, h, v) {
      var A = Er(h);
      if (typeof A != "function")
        throw Error(E(150));
      if (h = A.call(h), h == null)
        throw Error(E(151));
      for (var T = A = null, N = m, L = m = 0, W = null, I = h.next(); N !== null && !I.done; L++, I = h.next()) {
        N.index > L ? (W = N, N = null) : W = N.sibling;
        var Se = f(g, N, I.value, v);
        if (Se === null) {
          N === null && (N = W);
          break;
        }
        e && N && Se.alternate === null && t(g, N), m = o(Se, m, L), T === null ? A = Se : T.sibling = Se, T = Se, N = W;
      }
      if (I.done)
        return n(g, N), J && dn(g, L), A;
      if (N === null) {
        for (; !I.done; L++, I = h.next())
          I = p(g, I.value, v), I !== null && (m = o(I, m, L), T === null ? A = I : T.sibling = I, T = I);
        return J && dn(g, L), A;
      }
      for (N = r(g, N); !I.done; L++, I = h.next())
        I = d(N, g, L, I.value, v), I !== null && (e && I.alternate !== null && N.delete(I.key === null ? L : I.key), m = o(I, m, L), T === null ? A = I : T.sibling = I, T = I);
      return e && N.forEach(function(Ae) {
        return t(g, Ae);
      }), J && dn(g, L), A;
    }
    function S(g, m, h, v) {
      if (typeof h == "object" && h !== null && h.type === On && h.key === null && (h = h.props.children), typeof h == "object" && h !== null) {
        switch (h.$$typeof) {
          case Ca:
            e: {
              for (var A = h.key, T = m; T !== null; ) {
                if (T.key === A) {
                  if (A = h.type, A === On) {
                    if (T.tag === 7) {
                      n(g, T.sibling), m = a(T, h.props.children), m.return = g, g = m;
                      break e;
                    }
                  } else if (T.elementType === A || typeof A == "object" && A !== null && A.$$typeof === jt && Pu(A) === T.type) {
                    n(g, T.sibling), m = a(T, h.props), m.ref = Cr(g, T, h), m.return = g, g = m;
                    break e;
                  }
                  n(g, T);
                  break;
                } else
                  t(g, T);
                T = T.sibling;
              }
              h.type === On ? (m = vn(h.props.children, g.mode, v, h.key), m.return = g, g = m) : (v = no(h.type, h.key, h.props, null, g.mode, v), v.ref = Cr(g, m, h), v.return = g, g = v);
            }
            return s(g);
          case Rn:
            e: {
              for (T = h.key; m !== null; ) {
                if (m.key === T)
                  if (m.tag === 4 && m.stateNode.containerInfo === h.containerInfo && m.stateNode.implementation === h.implementation) {
                    n(g, m.sibling), m = a(m, h.children || []), m.return = g, g = m;
                    break e;
                  } else {
                    n(g, m);
                    break;
                  }
                else
                  t(g, m);
                m = m.sibling;
              }
              m = Bs(h, g.mode, v), m.return = g, g = m;
            }
            return s(g);
          case jt:
            return T = h._init, S(g, m, T(h._payload), v);
        }
        if (Lr(h))
          return w(g, m, h, v);
        if (Er(h))
          return y(g, m, h, v);
        Ua(g, h);
      }
      return typeof h == "string" && h !== "" || typeof h == "number" ? (h = "" + h, m !== null && m.tag === 6 ? (n(g, m.sibling), m = a(m, h), m.return = g, g = m) : (n(g, m), m = zs(h, g.mode, v), m.return = g, g = m), s(g)) : n(g, m);
    }
    return S;
  }
  var ar = Yf(true), Qf = Yf(false), Eo = on(null), To = null, Bn = null, Bi = null;
  function Vi() {
    Bi = Bn = To = null;
  }
  function Hi(e) {
    var t = Eo.current;
    X(Eo), e._currentValue = t;
  }
  function Al(e, t, n) {
    for (; e !== null; ) {
      var r = e.alternate;
      if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n)
        break;
      e = e.return;
    }
  }
  function Xn(e, t) {
    To = e, Bi = Bn = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (Oe = true), e.firstContext = null);
  }
  function Ke(e) {
    var t = e._currentValue;
    if (Bi !== e)
      if (e = {
        context: e,
        memoizedValue: t,
        next: null
      }, Bn === null) {
        if (To === null)
          throw Error(E(308));
        Bn = e, To.dependencies = {
          lanes: 0,
          firstContext: e
        };
      } else
        Bn = Bn.next = e;
    return t;
  }
  var mn = null;
  function Gi(e) {
    mn === null ? mn = [
      e
    ] : mn.push(e);
  }
  function Zf(e, t, n, r) {
    var a = t.interleaved;
    return a === null ? (n.next = n, Gi(t)) : (n.next = a.next, a.next = n), t.interleaved = n, _t(e, r);
  }
  function _t(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null; )
      e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null;
  }
  var zt = false;
  function Wi(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: {
        pending: null,
        interleaved: null,
        lanes: 0
      },
      effects: null
    };
  }
  function Kf(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
      baseState: e.baseState,
      firstBaseUpdate: e.firstBaseUpdate,
      lastBaseUpdate: e.lastBaseUpdate,
      shared: e.shared,
      effects: e.effects
    });
  }
  function Ct(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null
    };
  }
  function Xt(e, t, n) {
    var r = e.updateQueue;
    if (r === null)
      return null;
    if (r = r.shared, U & 2) {
      var a = r.pending;
      return a === null ? t.next = t : (t.next = a.next, a.next = t), r.pending = t, _t(e, n);
    }
    return a = r.interleaved, a === null ? (t.next = t, Gi(r)) : (t.next = a.next, a.next = t), r.interleaved = t, _t(e, n);
  }
  function Ka(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
      var r = t.lanes;
      r &= e.pendingLanes, n |= r, t.lanes = n, Li(e, n);
    }
  }
  function bu(e, t) {
    var n = e.updateQueue, r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
      var a = null, o = null;
      if (n = n.firstBaseUpdate, n !== null) {
        do {
          var s = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null
          };
          o === null ? a = o = s : o = o.next = s, n = n.next;
        } while (n !== null);
        o === null ? a = o = t : o = o.next = t;
      } else
        a = o = t;
      n = {
        baseState: r.baseState,
        firstBaseUpdate: a,
        lastBaseUpdate: o,
        shared: r.shared,
        effects: r.effects
      }, e.updateQueue = n;
      return;
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t;
  }
  function xo(e, t, n, r) {
    var a = e.updateQueue;
    zt = false;
    var o = a.firstBaseUpdate, s = a.lastBaseUpdate, l = a.shared.pending;
    if (l !== null) {
      a.shared.pending = null;
      var i = l, c = i.next;
      i.next = null, s === null ? o = c : s.next = c, s = i;
      var u = e.alternate;
      u !== null && (u = u.updateQueue, l = u.lastBaseUpdate, l !== s && (l === null ? u.firstBaseUpdate = c : l.next = c, u.lastBaseUpdate = i));
    }
    if (o !== null) {
      var p = a.baseState;
      s = 0, u = c = i = null, l = o;
      do {
        var f = l.lane, d = l.eventTime;
        if ((r & f) === f) {
          u !== null && (u = u.next = {
            eventTime: d,
            lane: 0,
            tag: l.tag,
            payload: l.payload,
            callback: l.callback,
            next: null
          });
          e: {
            var w = e, y = l;
            switch (f = t, d = n, y.tag) {
              case 1:
                if (w = y.payload, typeof w == "function") {
                  p = w.call(d, p, f);
                  break e;
                }
                p = w;
                break e;
              case 3:
                w.flags = w.flags & -65537 | 128;
              case 0:
                if (w = y.payload, f = typeof w == "function" ? w.call(d, p, f) : w, f == null)
                  break e;
                p = ne({}, p, f);
                break e;
              case 2:
                zt = true;
            }
          }
          l.callback !== null && l.lane !== 0 && (e.flags |= 64, f = a.effects, f === null ? a.effects = [
            l
          ] : f.push(l));
        } else
          d = {
            eventTime: d,
            lane: f,
            tag: l.tag,
            payload: l.payload,
            callback: l.callback,
            next: null
          }, u === null ? (c = u = d, i = p) : u = u.next = d, s |= f;
        if (l = l.next, l === null) {
          if (l = a.shared.pending, l === null)
            break;
          f = l, l = f.next, f.next = null, a.lastBaseUpdate = f, a.shared.pending = null;
        }
      } while (1);
      if (u === null && (i = p), a.baseState = i, a.firstBaseUpdate = c, a.lastBaseUpdate = u, t = a.shared.interleaved, t !== null) {
        a = t;
        do
          s |= a.lane, a = a.next;
        while (a !== t);
      } else
        o === null && (a.shared.lanes = 0);
      Tn |= s, e.lanes = s, e.memoizedState = p;
    }
  }
  function Lu(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
      for (t = 0; t < e.length; t++) {
        var r = e[t], a = r.callback;
        if (a !== null) {
          if (r.callback = null, r = n, typeof a != "function")
            throw Error(E(191, a));
          a.call(r);
        }
      }
  }
  var Ea = {}, wt = on(Ea), sa = on(Ea), la = on(Ea);
  function hn(e) {
    if (e === Ea)
      throw Error(E(174));
    return e;
  }
  function Yi(e, t) {
    switch (Q(la, t), Q(sa, e), Q(wt, Ea), e = t.nodeType, e) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : ol(null, "");
        break;
      default:
        e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = ol(t, e);
    }
    X(wt), Q(wt, t);
  }
  function or() {
    X(wt), X(sa), X(la);
  }
  function Xf(e) {
    hn(la.current);
    var t = hn(wt.current), n = ol(t, e.type);
    t !== n && (Q(sa, e), Q(wt, n));
  }
  function Qi(e) {
    sa.current === e && (X(wt), X(sa));
  }
  var ee = on(0);
  function Ao(e) {
    for (var t = e; t !== null; ) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!"))
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if (t.flags & 128)
          return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === e)
        break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e)
          return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var Fs = [];
  function Zi() {
    for (var e = 0; e < Fs.length; e++)
      Fs[e]._workInProgressVersionPrimary = null;
    Fs.length = 0;
  }
  var Xa = Ot.ReactCurrentDispatcher, Is = Ot.ReactCurrentBatchConfig, En = 0, te = null, le = null, fe = null, Mo = false, jr = false, ia = 0, Hh = 0;
  function ke() {
    throw Error(E(321));
  }
  function Ki(e, t) {
    if (t === null)
      return false;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!ut(e[n], t[n]))
        return false;
    return true;
  }
  function Xi(e, t, n, r, a, o) {
    if (En = o, te = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, Xa.current = e === null || e.memoizedState === null ? Qh : Zh, e = n(r, a), jr) {
      o = 0;
      do {
        if (jr = false, ia = 0, 25 <= o)
          throw Error(E(301));
        o += 1, fe = le = null, t.updateQueue = null, Xa.current = Kh, e = n(r, a);
      } while (jr);
    }
    if (Xa.current = Co, t = le !== null && le.next !== null, En = 0, fe = le = te = null, Mo = false, t)
      throw Error(E(300));
    return e;
  }
  function qi() {
    var e = ia !== 0;
    return ia = 0, e;
  }
  function gt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return fe === null ? te.memoizedState = fe = e : fe = fe.next = e, fe;
  }
  function Xe() {
    if (le === null) {
      var e = te.alternate;
      e = e !== null ? e.memoizedState : null;
    } else
      e = le.next;
    var t = fe === null ? te.memoizedState : fe.next;
    if (t !== null)
      fe = t, le = e;
    else {
      if (e === null)
        throw Error(E(310));
      le = e, e = {
        memoizedState: le.memoizedState,
        baseState: le.baseState,
        baseQueue: le.baseQueue,
        queue: le.queue,
        next: null
      }, fe === null ? te.memoizedState = fe = e : fe = fe.next = e;
    }
    return fe;
  }
  function ca(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Ds(e) {
    var t = Xe(), n = t.queue;
    if (n === null)
      throw Error(E(311));
    n.lastRenderedReducer = e;
    var r = le, a = r.baseQueue, o = n.pending;
    if (o !== null) {
      if (a !== null) {
        var s = a.next;
        a.next = o.next, o.next = s;
      }
      r.baseQueue = a = o, n.pending = null;
    }
    if (a !== null) {
      o = a.next, r = r.baseState;
      var l = s = null, i = null, c = o;
      do {
        var u = c.lane;
        if ((En & u) === u)
          i !== null && (i = i.next = {
            lane: 0,
            action: c.action,
            hasEagerState: c.hasEagerState,
            eagerState: c.eagerState,
            next: null
          }), r = c.hasEagerState ? c.eagerState : e(r, c.action);
        else {
          var p = {
            lane: u,
            action: c.action,
            hasEagerState: c.hasEagerState,
            eagerState: c.eagerState,
            next: null
          };
          i === null ? (l = i = p, s = r) : i = i.next = p, te.lanes |= u, Tn |= u;
        }
        c = c.next;
      } while (c !== null && c !== o);
      i === null ? s = r : i.next = l, ut(r, t.memoizedState) || (Oe = true), t.memoizedState = r, t.baseState = s, t.baseQueue = i, n.lastRenderedState = r;
    }
    if (e = n.interleaved, e !== null) {
      a = e;
      do
        o = a.lane, te.lanes |= o, Tn |= o, a = a.next;
      while (a !== e);
    } else
      a === null && (n.lanes = 0);
    return [
      t.memoizedState,
      n.dispatch
    ];
  }
  function Us(e) {
    var t = Xe(), n = t.queue;
    if (n === null)
      throw Error(E(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch, a = n.pending, o = t.memoizedState;
    if (a !== null) {
      n.pending = null;
      var s = a = a.next;
      do
        o = e(o, s.action), s = s.next;
      while (s !== a);
      ut(o, t.memoizedState) || (Oe = true), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o;
    }
    return [
      o,
      r
    ];
  }
  function qf() {
  }
  function Jf(e, t) {
    var n = te, r = Xe(), a = t(), o = !ut(r.memoizedState, a);
    if (o && (r.memoizedState = a, Oe = true), r = r.queue, Ji(np.bind(null, n, r, e), [
      e
    ]), r.getSnapshot !== t || o || fe !== null && fe.memoizedState.tag & 1) {
      if (n.flags |= 2048, ua(9, tp.bind(null, n, r, a, t), void 0, null), pe === null)
        throw Error(E(349));
      En & 30 || ep(n, t, a);
    }
    return a;
  }
  function ep(e, t, n) {
    e.flags |= 16384, e = {
      getSnapshot: t,
      value: n
    }, t = te.updateQueue, t === null ? (t = {
      lastEffect: null,
      stores: null
    }, te.updateQueue = t, t.stores = [
      e
    ]) : (n = t.stores, n === null ? t.stores = [
      e
    ] : n.push(e));
  }
  function tp(e, t, n, r) {
    t.value = n, t.getSnapshot = r, rp(t) && ap(e);
  }
  function np(e, t, n) {
    return n(function() {
      rp(t) && ap(e);
    });
  }
  function rp(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !ut(e, n);
    } catch {
      return true;
    }
  }
  function ap(e) {
    var t = _t(e, 1);
    t !== null && it(t, e, 1, -1);
  }
  function _u(e) {
    var t = gt();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
      pending: null,
      interleaved: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: ca,
      lastRenderedState: e
    }, t.queue = e, e = e.dispatch = Yh.bind(null, te, e), [
      t.memoizedState,
      e
    ];
  }
  function ua(e, t, n, r) {
    return e = {
      tag: e,
      create: t,
      destroy: n,
      deps: r,
      next: null
    }, t = te.updateQueue, t === null ? (t = {
      lastEffect: null,
      stores: null
    }, te.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e;
  }
  function op() {
    return Xe().memoizedState;
  }
  function qa(e, t, n, r) {
    var a = gt();
    te.flags |= e, a.memoizedState = ua(1 | t, n, void 0, r === void 0 ? null : r);
  }
  function Xo(e, t, n, r) {
    var a = Xe();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (le !== null) {
      var s = le.memoizedState;
      if (o = s.destroy, r !== null && Ki(r, s.deps)) {
        a.memoizedState = ua(t, n, o, r);
        return;
      }
    }
    te.flags |= e, a.memoizedState = ua(1 | t, n, o, r);
  }
  function Ru(e, t) {
    return qa(8390656, 8, e, t);
  }
  function Ji(e, t) {
    return Xo(2048, 8, e, t);
  }
  function sp(e, t) {
    return Xo(4, 2, e, t);
  }
  function lp(e, t) {
    return Xo(4, 4, e, t);
  }
  function ip(e, t) {
    if (typeof t == "function")
      return e = e(), t(e), function() {
        t(null);
      };
    if (t != null)
      return e = e(), t.current = e, function() {
        t.current = null;
      };
  }
  function cp(e, t, n) {
    return n = n != null ? n.concat([
      e
    ]) : null, Xo(4, 4, ip.bind(null, t, e), n);
  }
  function ec() {
  }
  function up(e, t) {
    var n = Xe();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Ki(t, r[1]) ? r[0] : (n.memoizedState = [
      e,
      t
    ], e);
  }
  function dp(e, t) {
    var n = Xe();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Ki(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [
      e,
      t
    ], e);
  }
  function fp(e, t, n) {
    return En & 21 ? (ut(n, t) || (n = yf(), te.lanes |= n, Tn |= n, e.baseState = true), t) : (e.baseState && (e.baseState = false, Oe = true), e.memoizedState = n);
  }
  function Gh(e, t) {
    var n = V;
    V = n !== 0 && 4 > n ? n : 4, e(true);
    var r = Is.transition;
    Is.transition = {};
    try {
      e(false), t();
    } finally {
      V = n, Is.transition = r;
    }
  }
  function pp() {
    return Xe().memoizedState;
  }
  function Wh(e, t, n) {
    var r = Jt(e);
    if (n = {
      lane: r,
      action: n,
      hasEagerState: false,
      eagerState: null,
      next: null
    }, gp(e))
      mp(t, n);
    else if (n = Zf(e, t, n, r), n !== null) {
      var a = Ce();
      it(n, e, r, a), hp(n, t, r);
    }
  }
  function Yh(e, t, n) {
    var r = Jt(e), a = {
      lane: r,
      action: n,
      hasEagerState: false,
      eagerState: null,
      next: null
    };
    if (gp(e))
      mp(t, a);
    else {
      var o = e.alternate;
      if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer, o !== null))
        try {
          var s = t.lastRenderedState, l = o(s, n);
          if (a.hasEagerState = true, a.eagerState = l, ut(l, s)) {
            var i = t.interleaved;
            i === null ? (a.next = a, Gi(t)) : (a.next = i.next, i.next = a), t.interleaved = a;
            return;
          }
        } catch {
        } finally {
        }
      n = Zf(e, t, a, r), n !== null && (a = Ce(), it(n, e, r, a), hp(n, t, r));
    }
  }
  function gp(e) {
    var t = e.alternate;
    return e === te || t !== null && t === te;
  }
  function mp(e, t) {
    jr = Mo = true;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
  }
  function hp(e, t, n) {
    if (n & 4194240) {
      var r = t.lanes;
      r &= e.pendingLanes, n |= r, t.lanes = n, Li(e, n);
    }
  }
  var Co = {
    readContext: Ke,
    useCallback: ke,
    useContext: ke,
    useEffect: ke,
    useImperativeHandle: ke,
    useInsertionEffect: ke,
    useLayoutEffect: ke,
    useMemo: ke,
    useReducer: ke,
    useRef: ke,
    useState: ke,
    useDebugValue: ke,
    useDeferredValue: ke,
    useTransition: ke,
    useMutableSource: ke,
    useSyncExternalStore: ke,
    useId: ke,
    unstable_isNewReconciler: false
  }, Qh = {
    readContext: Ke,
    useCallback: function(e, t) {
      return gt().memoizedState = [
        e,
        t === void 0 ? null : t
      ], e;
    },
    useContext: Ke,
    useEffect: Ru,
    useImperativeHandle: function(e, t, n) {
      return n = n != null ? n.concat([
        e
      ]) : null, qa(4194308, 4, ip.bind(null, t, e), n);
    },
    useLayoutEffect: function(e, t) {
      return qa(4194308, 4, e, t);
    },
    useInsertionEffect: function(e, t) {
      return qa(4, 2, e, t);
    },
    useMemo: function(e, t) {
      var n = gt();
      return t = t === void 0 ? null : t, e = e(), n.memoizedState = [
        e,
        t
      ], e;
    },
    useReducer: function(e, t, n) {
      var r = gt();
      return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: e,
        lastRenderedState: t
      }, r.queue = e, e = e.dispatch = Wh.bind(null, te, e), [
        r.memoizedState,
        e
      ];
    },
    useRef: function(e) {
      var t = gt();
      return e = {
        current: e
      }, t.memoizedState = e;
    },
    useState: _u,
    useDebugValue: ec,
    useDeferredValue: function(e) {
      return gt().memoizedState = e;
    },
    useTransition: function() {
      var e = _u(false), t = e[0];
      return e = Gh.bind(null, e[1]), gt().memoizedState = e, [
        t,
        e
      ];
    },
    useMutableSource: function() {
    },
    useSyncExternalStore: function(e, t, n) {
      var r = te, a = gt();
      if (J) {
        if (n === void 0)
          throw Error(E(407));
        n = n();
      } else {
        if (n = t(), pe === null)
          throw Error(E(349));
        En & 30 || ep(r, t, n);
      }
      a.memoizedState = n;
      var o = {
        value: n,
        getSnapshot: t
      };
      return a.queue = o, Ru(np.bind(null, r, o, e), [
        e
      ]), r.flags |= 2048, ua(9, tp.bind(null, r, o, n, t), void 0, null), n;
    },
    useId: function() {
      var e = gt(), t = pe.identifierPrefix;
      if (J) {
        var n = Mt, r = At;
        n = (r & ~(1 << 32 - lt(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = ia++, 0 < n && (t += "H" + n.toString(32)), t += ":";
      } else
        n = Hh++, t = ":" + t + "r" + n.toString(32) + ":";
      return e.memoizedState = t;
    },
    unstable_isNewReconciler: false
  }, Zh = {
    readContext: Ke,
    useCallback: up,
    useContext: Ke,
    useEffect: Ji,
    useImperativeHandle: cp,
    useInsertionEffect: sp,
    useLayoutEffect: lp,
    useMemo: dp,
    useReducer: Ds,
    useRef: op,
    useState: function() {
      return Ds(ca);
    },
    useDebugValue: ec,
    useDeferredValue: function(e) {
      var t = Xe();
      return fp(t, le.memoizedState, e);
    },
    useTransition: function() {
      var e = Ds(ca)[0], t = Xe().memoizedState;
      return [
        e,
        t
      ];
    },
    useMutableSource: qf,
    useSyncExternalStore: Jf,
    useId: pp,
    unstable_isNewReconciler: false
  }, Kh = {
    readContext: Ke,
    useCallback: up,
    useContext: Ke,
    useEffect: Ji,
    useImperativeHandle: cp,
    useInsertionEffect: sp,
    useLayoutEffect: lp,
    useMemo: dp,
    useReducer: Us,
    useRef: op,
    useState: function() {
      return Us(ca);
    },
    useDebugValue: ec,
    useDeferredValue: function(e) {
      var t = Xe();
      return le === null ? t.memoizedState = e : fp(t, le.memoizedState, e);
    },
    useTransition: function() {
      var e = Us(ca)[0], t = Xe().memoizedState;
      return [
        e,
        t
      ];
    },
    useMutableSource: qf,
    useSyncExternalStore: Jf,
    useId: pp,
    unstable_isNewReconciler: false
  };
  function at(e, t) {
    if (e && e.defaultProps) {
      t = ne({}, t), e = e.defaultProps;
      for (var n in e)
        t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function Ml(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : ne({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n);
  }
  var qo = {
    isMounted: function(e) {
      return (e = e._reactInternals) ? Mn(e) === e : false;
    },
    enqueueSetState: function(e, t, n) {
      e = e._reactInternals;
      var r = Ce(), a = Jt(e), o = Ct(r, a);
      o.payload = t, n != null && (o.callback = n), t = Xt(e, o, a), t !== null && (it(t, e, a, r), Ka(t, e, a));
    },
    enqueueReplaceState: function(e, t, n) {
      e = e._reactInternals;
      var r = Ce(), a = Jt(e), o = Ct(r, a);
      o.tag = 1, o.payload = t, n != null && (o.callback = n), t = Xt(e, o, a), t !== null && (it(t, e, a, r), Ka(t, e, a));
    },
    enqueueForceUpdate: function(e, t) {
      e = e._reactInternals;
      var n = Ce(), r = Jt(e), a = Ct(n, r);
      a.tag = 2, t != null && (a.callback = t), t = Xt(e, a, r), t !== null && (it(t, e, r, n), Ka(t, e, r));
    }
  };
  function Ou(e, t, n, r, a, o, s) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, s) : t.prototype && t.prototype.isPureReactComponent ? !na(n, r) || !na(a, o) : true;
  }
  function yp(e, t, n) {
    var r = false, a = rn, o = t.contextType;
    return typeof o == "object" && o !== null ? o = Ke(o) : (a = Ie(t) ? Sn : xe.current, r = t.contextTypes, o = (r = r != null) ? nr(e, a) : rn), t = new t(n, o), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = qo, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = a, e.__reactInternalMemoizedMaskedChildContext = o), t;
  }
  function Fu(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && qo.enqueueReplaceState(t, t.state, null);
  }
  function Cl(e, t, n, r) {
    var a = e.stateNode;
    a.props = n, a.state = e.memoizedState, a.refs = {}, Wi(e);
    var o = t.contextType;
    typeof o == "object" && o !== null ? a.context = Ke(o) : (o = Ie(t) ? Sn : xe.current, a.context = nr(e, o)), a.state = e.memoizedState, o = t.getDerivedStateFromProps, typeof o == "function" && (Ml(e, t, o, n), a.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof a.getSnapshotBeforeUpdate == "function" || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (t = a.state, typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount(), t !== a.state && qo.enqueueReplaceState(a, a.state, null), xo(e, n, a, r), a.state = e.memoizedState), typeof a.componentDidMount == "function" && (e.flags |= 4194308);
  }
  function sr(e, t) {
    try {
      var n = "", r = t;
      do
        n += xm(r), r = r.return;
      while (r);
      var a = n;
    } catch (o) {
      a = `
Error generating stack: ` + o.message + `
` + o.stack;
    }
    return {
      value: e,
      source: t,
      stack: a,
      digest: null
    };
  }
  function $s(e, t, n) {
    return {
      value: e,
      source: null,
      stack: n ?? null,
      digest: t ?? null
    };
  }
  function Nl(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function() {
        throw n;
      });
    }
  }
  var Xh = typeof WeakMap == "function" ? WeakMap : Map;
  function wp(e, t, n) {
    n = Ct(-1, n), n.tag = 3, n.payload = {
      element: null
    };
    var r = t.value;
    return n.callback = function() {
      Po || (Po = true, Ul = r), Nl(e, t);
    }, n;
  }
  function vp(e, t, n) {
    n = Ct(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var a = t.value;
      n.payload = function() {
        return r(a);
      }, n.callback = function() {
        Nl(e, t);
      };
    }
    var o = e.stateNode;
    return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
      Nl(e, t), typeof r != "function" && (qt === null ? qt = /* @__PURE__ */ new Set([
        this
      ]) : qt.add(this));
      var s = t.stack;
      this.componentDidCatch(t.value, {
        componentStack: s !== null ? s : ""
      });
    }), n;
  }
  function Iu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new Xh();
      var a = /* @__PURE__ */ new Set();
      r.set(t, a);
    } else
      a = r.get(t), a === void 0 && (a = /* @__PURE__ */ new Set(), r.set(t, a));
    a.has(n) || (a.add(n), e = d1.bind(null, e, t, n), t.then(e, e));
  }
  function Du(e) {
    do {
      var t;
      if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : true), t)
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function Uu(e, t, n, r, a) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = a, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = Ct(-1, 1), t.tag = 2, Xt(n, t, 1))), n.lanes |= 1), e);
  }
  var qh = Ot.ReactCurrentOwner, Oe = false;
  function Me(e, t, n, r) {
    t.child = e === null ? Qf(t, null, n, r) : ar(t, e.child, n, r);
  }
  function $u(e, t, n, r, a) {
    n = n.render;
    var o = t.ref;
    return Xn(t, a), r = Xi(e, t, n, r, o, a), n = qi(), e !== null && !Oe ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a, Rt(e, t, a)) : (J && n && $i(t), t.flags |= 1, Me(e, t, r, a), t.child);
  }
  function ju(e, t, n, r, a) {
    if (e === null) {
      var o = n.type;
      return typeof o == "function" && !ic(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = o, Sp(e, t, o, r, a)) : (e = no(n.type, null, r, t, t.mode, a), e.ref = t.ref, e.return = t, t.child = e);
    }
    if (o = e.child, !(e.lanes & a)) {
      var s = o.memoizedProps;
      if (n = n.compare, n = n !== null ? n : na, n(s, r) && e.ref === t.ref)
        return Rt(e, t, a);
    }
    return t.flags |= 1, e = en(o, r), e.ref = t.ref, e.return = t, t.child = e;
  }
  function Sp(e, t, n, r, a) {
    if (e !== null) {
      var o = e.memoizedProps;
      if (na(o, r) && e.ref === t.ref)
        if (Oe = false, t.pendingProps = r = o, (e.lanes & a) !== 0)
          e.flags & 131072 && (Oe = true);
        else
          return t.lanes = e.lanes, Rt(e, t, a);
    }
    return Pl(e, t, n, r, a);
  }
  function kp(e, t, n) {
    var r = t.pendingProps, a = r.children, o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if (!(t.mode & 1))
        t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null
        }, Q(Hn, $e), $e |= n;
      else {
        if (!(n & 1073741824))
          return e = o !== null ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
            baseLanes: e,
            cachePool: null,
            transitions: null
          }, t.updateQueue = null, Q(Hn, $e), $e |= e, null;
        t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null
        }, r = o !== null ? o.baseLanes : n, Q(Hn, $e), $e |= r;
      }
    else
      o !== null ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, Q(Hn, $e), $e |= r;
    return Me(e, t, a, n), t.child;
  }
  function Ep(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152);
  }
  function Pl(e, t, n, r, a) {
    var o = Ie(n) ? Sn : xe.current;
    return o = nr(t, o), Xn(t, a), n = Xi(e, t, n, r, o, a), r = qi(), e !== null && !Oe ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a, Rt(e, t, a)) : (J && r && $i(t), t.flags |= 1, Me(e, t, n, a), t.child);
  }
  function zu(e, t, n, r, a) {
    if (Ie(n)) {
      var o = true;
      vo(t);
    } else
      o = false;
    if (Xn(t, a), t.stateNode === null)
      Ja(e, t), yp(t, n, r), Cl(t, n, r, a), r = true;
    else if (e === null) {
      var s = t.stateNode, l = t.memoizedProps;
      s.props = l;
      var i = s.context, c = n.contextType;
      typeof c == "object" && c !== null ? c = Ke(c) : (c = Ie(n) ? Sn : xe.current, c = nr(t, c));
      var u = n.getDerivedStateFromProps, p = typeof u == "function" || typeof s.getSnapshotBeforeUpdate == "function";
      p || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (l !== r || i !== c) && Fu(t, s, r, c), zt = false;
      var f = t.memoizedState;
      s.state = f, xo(t, r, s, a), i = t.memoizedState, l !== r || f !== i || Fe.current || zt ? (typeof u == "function" && (Ml(t, n, u, r), i = t.memoizedState), (l = zt || Ou(t, n, l, r, f, i, c)) ? (p || typeof s.UNSAFE_componentWillMount != "function" && typeof s.componentWillMount != "function" || (typeof s.componentWillMount == "function" && s.componentWillMount(), typeof s.UNSAFE_componentWillMount == "function" && s.UNSAFE_componentWillMount()), typeof s.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = i), s.props = r, s.state = i, s.context = c, r = l) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), r = false);
    } else {
      s = t.stateNode, Kf(e, t), l = t.memoizedProps, c = t.type === t.elementType ? l : at(t.type, l), s.props = c, p = t.pendingProps, f = s.context, i = n.contextType, typeof i == "object" && i !== null ? i = Ke(i) : (i = Ie(n) ? Sn : xe.current, i = nr(t, i));
      var d = n.getDerivedStateFromProps;
      (u = typeof d == "function" || typeof s.getSnapshotBeforeUpdate == "function") || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (l !== p || f !== i) && Fu(t, s, r, i), zt = false, f = t.memoizedState, s.state = f, xo(t, r, s, a);
      var w = t.memoizedState;
      l !== p || f !== w || Fe.current || zt ? (typeof d == "function" && (Ml(t, n, d, r), w = t.memoizedState), (c = zt || Ou(t, n, c, r, f, w, i) || false) ? (u || typeof s.UNSAFE_componentWillUpdate != "function" && typeof s.componentWillUpdate != "function" || (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(r, w, i), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(r, w, i)), typeof s.componentDidUpdate == "function" && (t.flags |= 4), typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof s.componentDidUpdate != "function" || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = w), s.props = r, s.state = w, s.context = i, r = c) : (typeof s.componentDidUpdate != "function" || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = false);
    }
    return bl(e, t, n, r, o, a);
  }
  function bl(e, t, n, r, a, o) {
    Ep(e, t);
    var s = (t.flags & 128) !== 0;
    if (!r && !s)
      return a && Mu(t, n, false), Rt(e, t, o);
    r = t.stateNode, qh.current = t;
    var l = s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && s ? (t.child = ar(t, e.child, null, o), t.child = ar(t, null, l, o)) : Me(e, t, l, o), t.memoizedState = r.state, a && Mu(t, n, true), t.child;
  }
  function Tp(e) {
    var t = e.stateNode;
    t.pendingContext ? Au(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Au(e, t.context, false), Yi(e, t.containerInfo);
  }
  function Bu(e, t, n, r, a) {
    return rr(), zi(a), t.flags |= 256, Me(e, t, n, r), t.child;
  }
  var Ll = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
  };
  function _l(e) {
    return {
      baseLanes: e,
      cachePool: null,
      transitions: null
    };
  }
  function xp(e, t, n) {
    var r = t.pendingProps, a = ee.current, o = false, s = (t.flags & 128) !== 0, l;
    if ((l = s) || (l = e !== null && e.memoizedState === null ? false : (a & 2) !== 0), l ? (o = true, t.flags &= -129) : (e === null || e.memoizedState !== null) && (a |= 1), Q(ee, a & 1), e === null)
      return xl(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (s = r.children, e = r.fallback, o ? (r = t.mode, o = t.child, s = {
        mode: "hidden",
        children: s
      }, !(r & 1) && o !== null ? (o.childLanes = 0, o.pendingProps = s) : o = ts(s, r, 0, null), e = vn(e, r, n, null), o.return = t, e.return = t, o.sibling = e, t.child = o, t.child.memoizedState = _l(n), t.memoizedState = Ll, e) : tc(t, s));
    if (a = e.memoizedState, a !== null && (l = a.dehydrated, l !== null))
      return Jh(e, t, s, r, l, a, n);
    if (o) {
      o = r.fallback, s = t.mode, a = e.child, l = a.sibling;
      var i = {
        mode: "hidden",
        children: r.children
      };
      return !(s & 1) && t.child !== a ? (r = t.child, r.childLanes = 0, r.pendingProps = i, t.deletions = null) : (r = en(a, i), r.subtreeFlags = a.subtreeFlags & 14680064), l !== null ? o = en(l, o) : (o = vn(o, s, n, null), o.flags |= 2), o.return = t, r.return = t, r.sibling = o, t.child = r, r = o, o = t.child, s = e.child.memoizedState, s = s === null ? _l(n) : {
        baseLanes: s.baseLanes | n,
        cachePool: null,
        transitions: s.transitions
      }, o.memoizedState = s, o.childLanes = e.childLanes & ~n, t.memoizedState = Ll, r;
    }
    return o = e.child, e = o.sibling, r = en(o, {
      mode: "visible",
      children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [
      e
    ], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r;
  }
  function tc(e, t) {
    return t = ts({
      mode: "visible",
      children: t
    }, e.mode, 0, null), t.return = e, e.child = t;
  }
  function $a(e, t, n, r) {
    return r !== null && zi(r), ar(t, e.child, null, n), e = tc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
  }
  function Jh(e, t, n, r, a, o, s) {
    if (n)
      return t.flags & 256 ? (t.flags &= -257, r = $s(Error(E(422))), $a(e, t, s, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, a = t.mode, r = ts({
        mode: "visible",
        children: r.children
      }, a, 0, null), o = vn(o, a, s, null), o.flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, t.mode & 1 && ar(t, e.child, null, s), t.child.memoizedState = _l(s), t.memoizedState = Ll, o);
    if (!(t.mode & 1))
      return $a(e, t, s, null);
    if (a.data === "$!") {
      if (r = a.nextSibling && a.nextSibling.dataset, r)
        var l = r.dgst;
      return r = l, o = Error(E(419)), r = $s(o, r, void 0), $a(e, t, s, r);
    }
    if (l = (s & e.childLanes) !== 0, Oe || l) {
      if (r = pe, r !== null) {
        switch (s & -s) {
          case 4:
            a = 2;
            break;
          case 16:
            a = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            a = 32;
            break;
          case 536870912:
            a = 268435456;
            break;
          default:
            a = 0;
        }
        a = a & (r.suspendedLanes | s) ? 0 : a, a !== 0 && a !== o.retryLane && (o.retryLane = a, _t(e, a), it(r, e, a, -1));
      }
      return lc(), r = $s(Error(E(421))), $a(e, t, s, r);
    }
    return a.data === "$?" ? (t.flags |= 128, t.child = e.child, t = f1.bind(null, e), a._reactRetry = t, null) : (e = o.treeContext, je = Kt(a.nextSibling), ze = t, J = true, st = null, e !== null && (We[Ye++] = At, We[Ye++] = Mt, We[Ye++] = kn, At = e.id, Mt = e.overflow, kn = t), t = tc(t, r.children), t.flags |= 4096, t);
  }
  function Vu(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), Al(e.return, t, n);
  }
  function js(e, t, n, r, a) {
    var o = e.memoizedState;
    o === null ? e.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: r,
      tail: n,
      tailMode: a
    } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = a);
  }
  function Ap(e, t, n) {
    var r = t.pendingProps, a = r.revealOrder, o = r.tail;
    if (Me(e, t, r.children, n), r = ee.current, r & 2)
      r = r & 1 | 2, t.flags |= 128;
    else {
      if (e !== null && e.flags & 128)
        e:
          for (e = t.child; e !== null; ) {
            if (e.tag === 13)
              e.memoizedState !== null && Vu(e, n, t);
            else if (e.tag === 19)
              Vu(e, n, t);
            else if (e.child !== null) {
              e.child.return = e, e = e.child;
              continue;
            }
            if (e === t)
              break e;
            for (; e.sibling === null; ) {
              if (e.return === null || e.return === t)
                break e;
              e = e.return;
            }
            e.sibling.return = e.return, e = e.sibling;
          }
      r &= 1;
    }
    if (Q(ee, r), !(t.mode & 1))
      t.memoizedState = null;
    else
      switch (a) {
        case "forwards":
          for (n = t.child, a = null; n !== null; )
            e = n.alternate, e !== null && Ao(e) === null && (a = n), n = n.sibling;
          n = a, n === null ? (a = t.child, t.child = null) : (a = n.sibling, n.sibling = null), js(t, false, a, n, o);
          break;
        case "backwards":
          for (n = null, a = t.child, t.child = null; a !== null; ) {
            if (e = a.alternate, e !== null && Ao(e) === null) {
              t.child = a;
              break;
            }
            e = a.sibling, a.sibling = n, n = a, a = e;
          }
          js(t, true, n, null, o);
          break;
        case "together":
          js(t, false, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function Ja(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2);
  }
  function Rt(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), Tn |= t.lanes, !(n & t.childLanes))
      return null;
    if (e !== null && t.child !== e.child)
      throw Error(E(153));
    if (t.child !== null) {
      for (e = t.child, n = en(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null; )
        e = e.sibling, n = n.sibling = en(e, e.pendingProps), n.return = t;
      n.sibling = null;
    }
    return t.child;
  }
  function e1(e, t, n) {
    switch (t.tag) {
      case 3:
        Tp(t), rr();
        break;
      case 5:
        Xf(t);
        break;
      case 1:
        Ie(t.type) && vo(t);
        break;
      case 4:
        Yi(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context, a = t.memoizedProps.value;
        Q(Eo, r._currentValue), r._currentValue = a;
        break;
      case 13:
        if (r = t.memoizedState, r !== null)
          return r.dehydrated !== null ? (Q(ee, ee.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? xp(e, t, n) : (Q(ee, ee.current & 1), e = Rt(e, t, n), e !== null ? e.sibling : null);
        Q(ee, ee.current & 1);
        break;
      case 19:
        if (r = (n & t.childLanes) !== 0, e.flags & 128) {
          if (r)
            return Ap(e, t, n);
          t.flags |= 128;
        }
        if (a = t.memoizedState, a !== null && (a.rendering = null, a.tail = null, a.lastEffect = null), Q(ee, ee.current), r)
          break;
        return null;
      case 22:
      case 23:
        return t.lanes = 0, kp(e, t, n);
    }
    return Rt(e, t, n);
  }
  var Mp, Rl, Cp, Np;
  Mp = function(e, t) {
    for (var n = t.child; n !== null; ) {
      if (n.tag === 5 || n.tag === 6)
        e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        n.child.return = n, n = n.child;
        continue;
      }
      if (n === t)
        break;
      for (; n.sibling === null; ) {
        if (n.return === null || n.return === t)
          return;
        n = n.return;
      }
      n.sibling.return = n.return, n = n.sibling;
    }
  };
  Rl = function() {
  };
  Cp = function(e, t, n, r) {
    var a = e.memoizedProps;
    if (a !== r) {
      e = t.stateNode, hn(wt.current);
      var o = null;
      switch (n) {
        case "input":
          a = tl(e, a), r = tl(e, r), o = [];
          break;
        case "select":
          a = ne({}, a, {
            value: void 0
          }), r = ne({}, r, {
            value: void 0
          }), o = [];
          break;
        case "textarea":
          a = al(e, a), r = al(e, r), o = [];
          break;
        default:
          typeof a.onClick != "function" && typeof r.onClick == "function" && (e.onclick = yo);
      }
      sl(n, r);
      var s;
      n = null;
      for (c in a)
        if (!r.hasOwnProperty(c) && a.hasOwnProperty(c) && a[c] != null)
          if (c === "style") {
            var l = a[c];
            for (s in l)
              l.hasOwnProperty(s) && (n || (n = {}), n[s] = "");
          } else
            c !== "dangerouslySetInnerHTML" && c !== "children" && c !== "suppressContentEditableWarning" && c !== "suppressHydrationWarning" && c !== "autoFocus" && (Zr.hasOwnProperty(c) ? o || (o = []) : (o = o || []).push(c, null));
      for (c in r) {
        var i = r[c];
        if (l = a == null ? void 0 : a[c], r.hasOwnProperty(c) && i !== l && (i != null || l != null))
          if (c === "style")
            if (l) {
              for (s in l)
                !l.hasOwnProperty(s) || i && i.hasOwnProperty(s) || (n || (n = {}), n[s] = "");
              for (s in i)
                i.hasOwnProperty(s) && l[s] !== i[s] && (n || (n = {}), n[s] = i[s]);
            } else
              n || (o || (o = []), o.push(c, n)), n = i;
          else
            c === "dangerouslySetInnerHTML" ? (i = i ? i.__html : void 0, l = l ? l.__html : void 0, i != null && l !== i && (o = o || []).push(c, i)) : c === "children" ? typeof i != "string" && typeof i != "number" || (o = o || []).push(c, "" + i) : c !== "suppressContentEditableWarning" && c !== "suppressHydrationWarning" && (Zr.hasOwnProperty(c) ? (i != null && c === "onScroll" && K("scroll", e), o || l === i || (o = [])) : (o = o || []).push(c, i));
      }
      n && (o = o || []).push("style", n);
      var c = o;
      (t.updateQueue = c) && (t.flags |= 4);
    }
  };
  Np = function(e, t, n, r) {
    n !== r && (t.flags |= 4);
  };
  function Nr(e, t) {
    if (!J)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null; )
            t.alternate !== null && (n = t), t = t.sibling;
          n === null ? e.tail = null : n.sibling = null;
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null; )
            n.alternate !== null && (r = n), n = n.sibling;
          r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null;
      }
  }
  function Ee(e) {
    var t = e.alternate !== null && e.alternate.child === e.child, n = 0, r = 0;
    if (t)
      for (var a = e.child; a !== null; )
        n |= a.lanes | a.childLanes, r |= a.subtreeFlags & 14680064, r |= a.flags & 14680064, a.return = e, a = a.sibling;
    else
      for (a = e.child; a !== null; )
        n |= a.lanes | a.childLanes, r |= a.subtreeFlags, r |= a.flags, a.return = e, a = a.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t;
  }
  function t1(e, t, n) {
    var r = t.pendingProps;
    switch (ji(t), t.tag) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Ee(t), null;
      case 1:
        return Ie(t.type) && wo(), Ee(t), null;
      case 3:
        return r = t.stateNode, or(), X(Fe), X(xe), Zi(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (Da(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, st !== null && (zl(st), st = null))), Rl(e, t), Ee(t), null;
      case 5:
        Qi(t);
        var a = hn(la.current);
        if (n = t.type, e !== null && t.stateNode != null)
          Cp(e, t, n, r, a), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
        else {
          if (!r) {
            if (t.stateNode === null)
              throw Error(E(166));
            return Ee(t), null;
          }
          if (e = hn(wt.current), Da(t)) {
            r = t.stateNode, n = t.type;
            var o = t.memoizedProps;
            switch (r[mt] = t, r[oa] = o, e = (t.mode & 1) !== 0, n) {
              case "dialog":
                K("cancel", r), K("close", r);
                break;
              case "iframe":
              case "object":
              case "embed":
                K("load", r);
                break;
              case "video":
              case "audio":
                for (a = 0; a < Rr.length; a++)
                  K(Rr[a], r);
                break;
              case "source":
                K("error", r);
                break;
              case "img":
              case "image":
              case "link":
                K("error", r), K("load", r);
                break;
              case "details":
                K("toggle", r);
                break;
              case "input":
                qc(r, o), K("invalid", r);
                break;
              case "select":
                r._wrapperState = {
                  wasMultiple: !!o.multiple
                }, K("invalid", r);
                break;
              case "textarea":
                eu(r, o), K("invalid", r);
            }
            sl(n, o), a = null;
            for (var s in o)
              if (o.hasOwnProperty(s)) {
                var l = o[s];
                s === "children" ? typeof l == "string" ? r.textContent !== l && (o.suppressHydrationWarning !== true && Ia(r.textContent, l, e), a = [
                  "children",
                  l
                ]) : typeof l == "number" && r.textContent !== "" + l && (o.suppressHydrationWarning !== true && Ia(r.textContent, l, e), a = [
                  "children",
                  "" + l
                ]) : Zr.hasOwnProperty(s) && l != null && s === "onScroll" && K("scroll", r);
              }
            switch (n) {
              case "input":
                Na(r), Jc(r, o, true);
                break;
              case "textarea":
                Na(r), tu(r);
                break;
              case "select":
              case "option":
                break;
              default:
                typeof o.onClick == "function" && (r.onclick = yo);
            }
            r = a, t.updateQueue = r, r !== null && (t.flags |= 4);
          } else {
            s = a.nodeType === 9 ? a : a.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = tf(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = s.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = s.createElement(n, {
              is: r.is
            }) : (e = s.createElement(n), n === "select" && (s = e, r.multiple ? s.multiple = true : r.size && (s.size = r.size))) : e = s.createElementNS(e, n), e[mt] = t, e[oa] = r, Mp(e, t, false, false), t.stateNode = e;
            e: {
              switch (s = ll(n, r), n) {
                case "dialog":
                  K("cancel", e), K("close", e), a = r;
                  break;
                case "iframe":
                case "object":
                case "embed":
                  K("load", e), a = r;
                  break;
                case "video":
                case "audio":
                  for (a = 0; a < Rr.length; a++)
                    K(Rr[a], e);
                  a = r;
                  break;
                case "source":
                  K("error", e), a = r;
                  break;
                case "img":
                case "image":
                case "link":
                  K("error", e), K("load", e), a = r;
                  break;
                case "details":
                  K("toggle", e), a = r;
                  break;
                case "input":
                  qc(e, r), a = tl(e, r), K("invalid", e);
                  break;
                case "option":
                  a = r;
                  break;
                case "select":
                  e._wrapperState = {
                    wasMultiple: !!r.multiple
                  }, a = ne({}, r, {
                    value: void 0
                  }), K("invalid", e);
                  break;
                case "textarea":
                  eu(e, r), a = al(e, r), K("invalid", e);
                  break;
                default:
                  a = r;
              }
              sl(n, a), l = a;
              for (o in l)
                if (l.hasOwnProperty(o)) {
                  var i = l[o];
                  o === "style" ? af(e, i) : o === "dangerouslySetInnerHTML" ? (i = i ? i.__html : void 0, i != null && nf(e, i)) : o === "children" ? typeof i == "string" ? (n !== "textarea" || i !== "") && Kr(e, i) : typeof i == "number" && Kr(e, "" + i) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (Zr.hasOwnProperty(o) ? i != null && o === "onScroll" && K("scroll", e) : i != null && Ai(e, o, i, s));
                }
              switch (n) {
                case "input":
                  Na(e), Jc(e, r, false);
                  break;
                case "textarea":
                  Na(e), tu(e);
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + nn(r.value));
                  break;
                case "select":
                  e.multiple = !!r.multiple, o = r.value, o != null ? Yn(e, !!r.multiple, o, false) : r.defaultValue != null && Yn(e, !!r.multiple, r.defaultValue, true);
                  break;
                default:
                  typeof a.onClick == "function" && (e.onclick = yo);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = true;
                  break e;
                default:
                  r = false;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && (t.flags |= 512, t.flags |= 2097152);
        }
        return Ee(t), null;
      case 6:
        if (e && t.stateNode != null)
          Np(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null)
            throw Error(E(166));
          if (n = hn(la.current), hn(wt.current), Da(t)) {
            if (r = t.stateNode, n = t.memoizedProps, r[mt] = t, (o = r.nodeValue !== n) && (e = ze, e !== null))
              switch (e.tag) {
                case 3:
                  Ia(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== true && Ia(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            o && (t.flags |= 4);
          } else
            r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[mt] = t, t.stateNode = r;
        }
        return Ee(t), null;
      case 13:
        if (X(ee), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
          if (J && je !== null && t.mode & 1 && !(t.flags & 128))
            Wf(), rr(), t.flags |= 98560, o = false;
          else if (o = Da(t), r !== null && r.dehydrated !== null) {
            if (e === null) {
              if (!o)
                throw Error(E(318));
              if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o)
                throw Error(E(317));
              o[mt] = t;
            } else
              rr(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
            Ee(t), o = false;
          } else
            st !== null && (zl(st), st = null), o = true;
          if (!o)
            return t.flags & 65536 ? t : null;
        }
        return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || ee.current & 1 ? ue === 0 && (ue = 3) : lc())), t.updateQueue !== null && (t.flags |= 4), Ee(t), null);
      case 4:
        return or(), Rl(e, t), e === null && ra(t.stateNode.containerInfo), Ee(t), null;
      case 10:
        return Hi(t.type._context), Ee(t), null;
      case 17:
        return Ie(t.type) && wo(), Ee(t), null;
      case 19:
        if (X(ee), o = t.memoizedState, o === null)
          return Ee(t), null;
        if (r = (t.flags & 128) !== 0, s = o.rendering, s === null)
          if (r)
            Nr(o, false);
          else {
            if (ue !== 0 || e !== null && e.flags & 128)
              for (e = t.child; e !== null; ) {
                if (s = Ao(e), s !== null) {
                  for (t.flags |= 128, Nr(o, false), r = s.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null; )
                    o = n, e = r, o.flags &= 14680066, s = o.alternate, s === null ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = s.childLanes, o.lanes = s.lanes, o.child = s.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = s.memoizedProps, o.memoizedState = s.memoizedState, o.updateQueue = s.updateQueue, o.type = s.type, e = s.dependencies, o.dependencies = e === null ? null : {
                      lanes: e.lanes,
                      firstContext: e.firstContext
                    }), n = n.sibling;
                  return Q(ee, ee.current & 1 | 2), t.child;
                }
                e = e.sibling;
              }
            o.tail !== null && oe() > lr && (t.flags |= 128, r = true, Nr(o, false), t.lanes = 4194304);
          }
        else {
          if (!r)
            if (e = Ao(s), e !== null) {
              if (t.flags |= 128, r = true, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), Nr(o, true), o.tail === null && o.tailMode === "hidden" && !s.alternate && !J)
                return Ee(t), null;
            } else
              2 * oe() - o.renderingStartTime > lr && n !== 1073741824 && (t.flags |= 128, r = true, Nr(o, false), t.lanes = 4194304);
          o.isBackwards ? (s.sibling = t.child, t.child = s) : (n = o.last, n !== null ? n.sibling = s : t.child = s, o.last = s);
        }
        return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = oe(), t.sibling = null, n = ee.current, Q(ee, r ? n & 1 | 2 : n & 1), t) : (Ee(t), null);
      case 22:
      case 23:
        return sc(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? $e & 1073741824 && (Ee(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Ee(t), null;
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(E(156, t.tag));
  }
  function n1(e, t) {
    switch (ji(t), t.tag) {
      case 1:
        return Ie(t.type) && wo(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 3:
        return or(), X(Fe), X(xe), Zi(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
      case 5:
        return Qi(t), null;
      case 13:
        if (X(ee), e = t.memoizedState, e !== null && e.dehydrated !== null) {
          if (t.alternate === null)
            throw Error(E(340));
          rr();
        }
        return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
      case 19:
        return X(ee), null;
      case 4:
        return or(), null;
      case 10:
        return Hi(t.type._context), null;
      case 22:
      case 23:
        return sc(), null;
      case 24:
        return null;
      default:
        return null;
    }
  }
  var ja = false, Te = false, r1 = typeof WeakSet == "function" ? WeakSet : Set, b = null;
  function Vn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          re(e, t, r);
        }
      else
        n.current = null;
  }
  function Ol(e, t, n) {
    try {
      n();
    } catch (r) {
      re(e, t, r);
    }
  }
  var Hu = false;
  function a1(e, t) {
    if (yl = go, e = Rf(), Ui(e)) {
      if ("selectionStart" in e)
        var n = {
          start: e.selectionStart,
          end: e.selectionEnd
        };
      else
        e: {
          n = (n = e.ownerDocument) && n.defaultView || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var a = r.anchorOffset, o = r.focusNode;
            r = r.focusOffset;
            try {
              n.nodeType, o.nodeType;
            } catch {
              n = null;
              break e;
            }
            var s = 0, l = -1, i = -1, c = 0, u = 0, p = e, f = null;
            t:
              for (; ; ) {
                for (var d; p !== n || a !== 0 && p.nodeType !== 3 || (l = s + a), p !== o || r !== 0 && p.nodeType !== 3 || (i = s + r), p.nodeType === 3 && (s += p.nodeValue.length), (d = p.firstChild) !== null; )
                  f = p, p = d;
                for (; ; ) {
                  if (p === e)
                    break t;
                  if (f === n && ++c === a && (l = s), f === o && ++u === r && (i = s), (d = p.nextSibling) !== null)
                    break;
                  p = f, f = p.parentNode;
                }
                p = d;
              }
            n = l === -1 || i === -1 ? null : {
              start: l,
              end: i
            };
          } else
            n = null;
        }
      n = n || {
        start: 0,
        end: 0
      };
    } else
      n = null;
    for (wl = {
      focusedElem: e,
      selectionRange: n
    }, go = false, b = t; b !== null; )
      if (t = b, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null)
        e.return = t, b = e;
      else
        for (; b !== null; ) {
          t = b;
          try {
            var w = t.alternate;
            if (t.flags & 1024)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (w !== null) {
                    var y = w.memoizedProps, S = w.memoizedState, g = t.stateNode, m = g.getSnapshotBeforeUpdate(t.elementType === t.type ? y : at(t.type, y), S);
                    g.__reactInternalSnapshotBeforeUpdate = m;
                  }
                  break;
                case 3:
                  var h = t.stateNode.containerInfo;
                  h.nodeType === 1 ? h.textContent = "" : h.nodeType === 9 && h.documentElement && h.removeChild(h.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(E(163));
              }
          } catch (v) {
            re(t, t.return, v);
          }
          if (e = t.sibling, e !== null) {
            e.return = t.return, b = e;
            break;
          }
          b = t.return;
        }
    return w = Hu, Hu = false, w;
  }
  function zr(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
      var a = r = r.next;
      do {
        if ((a.tag & e) === e) {
          var o = a.destroy;
          a.destroy = void 0, o !== void 0 && Ol(t, n, o);
        }
        a = a.next;
      } while (a !== r);
    }
  }
  function Jo(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
      var n = t = t.next;
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function Fl(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : t.current = e;
    }
  }
  function Pp(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, Pp(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[mt], delete t[oa], delete t[kl], delete t[jh], delete t[zh])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
  }
  function bp(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function Gu(e) {
    e:
      for (; ; ) {
        for (; e.sibling === null; ) {
          if (e.return === null || bp(e.return))
            return null;
          e = e.return;
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
          if (e.flags & 2 || e.child === null || e.tag === 4)
            continue e;
          e.child.return = e, e = e.child;
        }
        if (!(e.flags & 2))
          return e.stateNode;
      }
  }
  function Il(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = yo));
    else if (r !== 4 && (e = e.child, e !== null))
      for (Il(e, t, n), e = e.sibling; e !== null; )
        Il(e, t, n), e = e.sibling;
  }
  function Dl(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
      for (Dl(e, t, n), e = e.sibling; e !== null; )
        Dl(e, t, n), e = e.sibling;
  }
  var he = null, ot = false;
  function $t(e, t, n) {
    for (n = n.child; n !== null; )
      Lp(e, t, n), n = n.sibling;
  }
  function Lp(e, t, n) {
    if (yt && typeof yt.onCommitFiberUnmount == "function")
      try {
        yt.onCommitFiberUnmount(Go, n);
      } catch {
      }
    switch (n.tag) {
      case 5:
        Te || Vn(n, t);
      case 6:
        var r = he, a = ot;
        he = null, $t(e, t, n), he = r, ot = a, he !== null && (ot ? (e = he, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : he.removeChild(n.stateNode));
        break;
      case 18:
        he !== null && (ot ? (e = he, n = n.stateNode, e.nodeType === 8 ? Rs(e.parentNode, n) : e.nodeType === 1 && Rs(e, n), ea(e)) : Rs(he, n.stateNode));
        break;
      case 4:
        r = he, a = ot, he = n.stateNode.containerInfo, ot = true, $t(e, t, n), he = r, ot = a;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (!Te && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
          a = r = r.next;
          do {
            var o = a, s = o.destroy;
            o = o.tag, s !== void 0 && (o & 2 || o & 4) && Ol(n, t, s), a = a.next;
          } while (a !== r);
        }
        $t(e, t, n);
        break;
      case 1:
        if (!Te && (Vn(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function"))
          try {
            r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount();
          } catch (l) {
            re(n, t, l);
          }
        $t(e, t, n);
        break;
      case 21:
        $t(e, t, n);
        break;
      case 22:
        n.mode & 1 ? (Te = (r = Te) || n.memoizedState !== null, $t(e, t, n), Te = r) : $t(e, t, n);
        break;
      default:
        $t(e, t, n);
    }
  }
  function Wu(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      n === null && (n = e.stateNode = new r1()), t.forEach(function(r) {
        var a = p1.bind(null, e, r);
        n.has(r) || (n.add(r), r.then(a, a));
      });
    }
  }
  function nt(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var a = n[r];
        try {
          var o = e, s = t, l = s;
          e:
            for (; l !== null; ) {
              switch (l.tag) {
                case 5:
                  he = l.stateNode, ot = false;
                  break e;
                case 3:
                  he = l.stateNode.containerInfo, ot = true;
                  break e;
                case 4:
                  he = l.stateNode.containerInfo, ot = true;
                  break e;
              }
              l = l.return;
            }
          if (he === null)
            throw Error(E(160));
          Lp(o, s, a), he = null, ot = false;
          var i = a.alternate;
          i !== null && (i.return = null), a.return = null;
        } catch (c) {
          re(a, t, c);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null; )
        _p(t, e), t = t.sibling;
  }
  function _p(e, t) {
    var n = e.alternate, r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if (nt(t, e), pt(e), r & 4) {
          try {
            zr(3, e, e.return), Jo(3, e);
          } catch (y) {
            re(e, e.return, y);
          }
          try {
            zr(5, e, e.return);
          } catch (y) {
            re(e, e.return, y);
          }
        }
        break;
      case 1:
        nt(t, e), pt(e), r & 512 && n !== null && Vn(n, n.return);
        break;
      case 5:
        if (nt(t, e), pt(e), r & 512 && n !== null && Vn(n, n.return), e.flags & 32) {
          var a = e.stateNode;
          try {
            Kr(a, "");
          } catch (y) {
            re(e, e.return, y);
          }
        }
        if (r & 4 && (a = e.stateNode, a != null)) {
          var o = e.memoizedProps, s = n !== null ? n.memoizedProps : o, l = e.type, i = e.updateQueue;
          if (e.updateQueue = null, i !== null)
            try {
              l === "input" && o.type === "radio" && o.name != null && Jd(a, o), ll(l, s);
              var c = ll(l, o);
              for (s = 0; s < i.length; s += 2) {
                var u = i[s], p = i[s + 1];
                u === "style" ? af(a, p) : u === "dangerouslySetInnerHTML" ? nf(a, p) : u === "children" ? Kr(a, p) : Ai(a, u, p, c);
              }
              switch (l) {
                case "input":
                  nl(a, o);
                  break;
                case "textarea":
                  ef(a, o);
                  break;
                case "select":
                  var f = a._wrapperState.wasMultiple;
                  a._wrapperState.wasMultiple = !!o.multiple;
                  var d = o.value;
                  d != null ? Yn(a, !!o.multiple, d, false) : f !== !!o.multiple && (o.defaultValue != null ? Yn(a, !!o.multiple, o.defaultValue, true) : Yn(a, !!o.multiple, o.multiple ? [] : "", false));
              }
              a[oa] = o;
            } catch (y) {
              re(e, e.return, y);
            }
        }
        break;
      case 6:
        if (nt(t, e), pt(e), r & 4) {
          if (e.stateNode === null)
            throw Error(E(162));
          a = e.stateNode, o = e.memoizedProps;
          try {
            a.nodeValue = o;
          } catch (y) {
            re(e, e.return, y);
          }
        }
        break;
      case 3:
        if (nt(t, e), pt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
          try {
            ea(t.containerInfo);
          } catch (y) {
            re(e, e.return, y);
          }
        break;
      case 4:
        nt(t, e), pt(e);
        break;
      case 13:
        nt(t, e), pt(e), a = e.child, a.flags & 8192 && (o = a.memoizedState !== null, a.stateNode.isHidden = o, !o || a.alternate !== null && a.alternate.memoizedState !== null || (ac = oe())), r & 4 && Wu(e);
        break;
      case 22:
        if (u = n !== null && n.memoizedState !== null, e.mode & 1 ? (Te = (c = Te) || u, nt(t, e), Te = c) : nt(t, e), pt(e), r & 8192) {
          if (c = e.memoizedState !== null, (e.stateNode.isHidden = c) && !u && e.mode & 1)
            for (b = e, u = e.child; u !== null; ) {
              for (p = b = u; b !== null; ) {
                switch (f = b, d = f.child, f.tag) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    zr(4, f, f.return);
                    break;
                  case 1:
                    Vn(f, f.return);
                    var w = f.stateNode;
                    if (typeof w.componentWillUnmount == "function") {
                      r = f, n = f.return;
                      try {
                        t = r, w.props = t.memoizedProps, w.state = t.memoizedState, w.componentWillUnmount();
                      } catch (y) {
                        re(r, n, y);
                      }
                    }
                    break;
                  case 5:
                    Vn(f, f.return);
                    break;
                  case 22:
                    if (f.memoizedState !== null) {
                      Qu(p);
                      continue;
                    }
                }
                d !== null ? (d.return = f, b = d) : Qu(p);
              }
              u = u.sibling;
            }
          e:
            for (u = null, p = e; ; ) {
              if (p.tag === 5) {
                if (u === null) {
                  u = p;
                  try {
                    a = p.stateNode, c ? (o = a.style, typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (l = p.stateNode, i = p.memoizedProps.style, s = i != null && i.hasOwnProperty("display") ? i.display : null, l.style.display = rf("display", s));
                  } catch (y) {
                    re(e, e.return, y);
                  }
                }
              } else if (p.tag === 6) {
                if (u === null)
                  try {
                    p.stateNode.nodeValue = c ? "" : p.memoizedProps;
                  } catch (y) {
                    re(e, e.return, y);
                  }
              } else if ((p.tag !== 22 && p.tag !== 23 || p.memoizedState === null || p === e) && p.child !== null) {
                p.child.return = p, p = p.child;
                continue;
              }
              if (p === e)
                break e;
              for (; p.sibling === null; ) {
                if (p.return === null || p.return === e)
                  break e;
                u === p && (u = null), p = p.return;
              }
              u === p && (u = null), p.sibling.return = p.return, p = p.sibling;
            }
        }
        break;
      case 19:
        nt(t, e), pt(e), r & 4 && Wu(e);
        break;
      case 21:
        break;
      default:
        nt(t, e), pt(e);
    }
  }
  function pt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null; ) {
            if (bp(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(E(160));
        }
        switch (r.tag) {
          case 5:
            var a = r.stateNode;
            r.flags & 32 && (Kr(a, ""), r.flags &= -33);
            var o = Gu(e);
            Dl(e, o, a);
            break;
          case 3:
          case 4:
            var s = r.stateNode.containerInfo, l = Gu(e);
            Il(e, l, s);
            break;
          default:
            throw Error(E(161));
        }
      } catch (i) {
        re(e, e.return, i);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function o1(e, t, n) {
    b = e, Rp(e);
  }
  function Rp(e, t, n) {
    for (var r = (e.mode & 1) !== 0; b !== null; ) {
      var a = b, o = a.child;
      if (a.tag === 22 && r) {
        var s = a.memoizedState !== null || ja;
        if (!s) {
          var l = a.alternate, i = l !== null && l.memoizedState !== null || Te;
          l = ja;
          var c = Te;
          if (ja = s, (Te = i) && !c)
            for (b = a; b !== null; )
              s = b, i = s.child, s.tag === 22 && s.memoizedState !== null ? Zu(a) : i !== null ? (i.return = s, b = i) : Zu(a);
          for (; o !== null; )
            b = o, Rp(o), o = o.sibling;
          b = a, ja = l, Te = c;
        }
        Yu(e);
      } else
        a.subtreeFlags & 8772 && o !== null ? (o.return = a, b = o) : Yu(e);
    }
  }
  function Yu(e) {
    for (; b !== null; ) {
      var t = b;
      if (t.flags & 8772) {
        var n = t.alternate;
        try {
          if (t.flags & 8772)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                Te || Jo(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !Te)
                  if (n === null)
                    r.componentDidMount();
                  else {
                    var a = t.elementType === t.type ? n.memoizedProps : at(t.type, n.memoizedProps);
                    r.componentDidUpdate(a, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate);
                  }
                var o = t.updateQueue;
                o !== null && Lu(t, o, r);
                break;
              case 3:
                var s = t.updateQueue;
                if (s !== null) {
                  if (n = null, t.child !== null)
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  Lu(t, s, n);
                }
                break;
              case 5:
                var l = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = l;
                  var i = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      i.autoFocus && n.focus();
                      break;
                    case "img":
                      i.src && (n.src = i.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var c = t.alternate;
                  if (c !== null) {
                    var u = c.memoizedState;
                    if (u !== null) {
                      var p = u.dehydrated;
                      p !== null && ea(p);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(E(163));
            }
          Te || t.flags & 512 && Fl(t);
        } catch (f) {
          re(t, t.return, f);
        }
      }
      if (t === e) {
        b = null;
        break;
      }
      if (n = t.sibling, n !== null) {
        n.return = t.return, b = n;
        break;
      }
      b = t.return;
    }
  }
  function Qu(e) {
    for (; b !== null; ) {
      var t = b;
      if (t === e) {
        b = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        n.return = t.return, b = n;
        break;
      }
      b = t.return;
    }
  }
  function Zu(e) {
    for (; b !== null; ) {
      var t = b;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              Jo(4, t);
            } catch (i) {
              re(t, n, i);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var a = t.return;
              try {
                r.componentDidMount();
              } catch (i) {
                re(t, a, i);
              }
            }
            var o = t.return;
            try {
              Fl(t);
            } catch (i) {
              re(t, o, i);
            }
            break;
          case 5:
            var s = t.return;
            try {
              Fl(t);
            } catch (i) {
              re(t, s, i);
            }
        }
      } catch (i) {
        re(t, t.return, i);
      }
      if (t === e) {
        b = null;
        break;
      }
      var l = t.sibling;
      if (l !== null) {
        l.return = t.return, b = l;
        break;
      }
      b = t.return;
    }
  }
  var s1 = Math.ceil, No = Ot.ReactCurrentDispatcher, nc = Ot.ReactCurrentOwner, Ze = Ot.ReactCurrentBatchConfig, U = 0, pe = null, se = null, ye = 0, $e = 0, Hn = on(0), ue = 0, da = null, Tn = 0, es = 0, rc = 0, Br = null, Re = null, ac = 0, lr = 1 / 0, Et = null, Po = false, Ul = null, qt = null, za = false, Wt = null, bo = 0, Vr = 0, $l = null, eo = -1, to = 0;
  function Ce() {
    return U & 6 ? oe() : eo !== -1 ? eo : eo = oe();
  }
  function Jt(e) {
    return e.mode & 1 ? U & 2 && ye !== 0 ? ye & -ye : Vh.transition !== null ? (to === 0 && (to = yf()), to) : (e = V, e !== 0 || (e = window.event, e = e === void 0 ? 16 : xf(e.type)), e) : 1;
  }
  function it(e, t, n, r) {
    if (50 < Vr)
      throw Vr = 0, $l = null, Error(E(185));
    va(e, n, r), (!(U & 2) || e !== pe) && (e === pe && (!(U & 2) && (es |= n), ue === 4 && Vt(e, ye)), De(e, r), n === 1 && U === 0 && !(t.mode & 1) && (lr = oe() + 500, Ko && sn()));
  }
  function De(e, t) {
    var n = e.callbackNode;
    Vm(e, t);
    var r = po(e, e === pe ? ye : 0);
    if (r === 0)
      n !== null && au(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
      if (n != null && au(n), t === 1)
        e.tag === 0 ? Bh(Ku.bind(null, e)) : Vf(Ku.bind(null, e)), Uh(function() {
          !(U & 6) && sn();
        }), n = null;
      else {
        switch (wf(r)) {
          case 1:
            n = bi;
            break;
          case 4:
            n = mf;
            break;
          case 16:
            n = fo;
            break;
          case 536870912:
            n = hf;
            break;
          default:
            n = fo;
        }
        n = zp(n, Op.bind(null, e));
      }
      e.callbackPriority = t, e.callbackNode = n;
    }
  }
  function Op(e, t) {
    if (eo = -1, to = 0, U & 6)
      throw Error(E(327));
    var n = e.callbackNode;
    if (qn() && e.callbackNode !== n)
      return null;
    var r = po(e, e === pe ? ye : 0);
    if (r === 0)
      return null;
    if (r & 30 || r & e.expiredLanes || t)
      t = Lo(e, r);
    else {
      t = r;
      var a = U;
      U |= 2;
      var o = Ip();
      (pe !== e || ye !== t) && (Et = null, lr = oe() + 500, wn(e, t));
      do
        try {
          c1();
          break;
        } catch (l) {
          Fp(e, l);
        }
      while (1);
      Vi(), No.current = o, U = a, se !== null ? t = 0 : (pe = null, ye = 0, t = ue);
    }
    if (t !== 0) {
      if (t === 2 && (a = fl(e), a !== 0 && (r = a, t = jl(e, a))), t === 1)
        throw n = da, wn(e, 0), Vt(e, r), De(e, oe()), n;
      if (t === 6)
        Vt(e, r);
      else {
        if (a = e.current.alternate, !(r & 30) && !l1(a) && (t = Lo(e, r), t === 2 && (o = fl(e), o !== 0 && (r = o, t = jl(e, o))), t === 1))
          throw n = da, wn(e, 0), Vt(e, r), De(e, oe()), n;
        switch (e.finishedWork = a, e.finishedLanes = r, t) {
          case 0:
          case 1:
            throw Error(E(345));
          case 2:
            fn(e, Re, Et);
            break;
          case 3:
            if (Vt(e, r), (r & 130023424) === r && (t = ac + 500 - oe(), 10 < t)) {
              if (po(e, 0) !== 0)
                break;
              if (a = e.suspendedLanes, (a & r) !== r) {
                Ce(), e.pingedLanes |= e.suspendedLanes & a;
                break;
              }
              e.timeoutHandle = Sl(fn.bind(null, e, Re, Et), t);
              break;
            }
            fn(e, Re, Et);
            break;
          case 4:
            if (Vt(e, r), (r & 4194240) === r)
              break;
            for (t = e.eventTimes, a = -1; 0 < r; ) {
              var s = 31 - lt(r);
              o = 1 << s, s = t[s], s > a && (a = s), r &= ~o;
            }
            if (r = a, r = oe() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * s1(r / 1960)) - r, 10 < r) {
              e.timeoutHandle = Sl(fn.bind(null, e, Re, Et), r);
              break;
            }
            fn(e, Re, Et);
            break;
          case 5:
            fn(e, Re, Et);
            break;
          default:
            throw Error(E(329));
        }
      }
    }
    return De(e, oe()), e.callbackNode === n ? Op.bind(null, e) : null;
  }
  function jl(e, t) {
    var n = Br;
    return e.current.memoizedState.isDehydrated && (wn(e, t).flags |= 256), e = Lo(e, t), e !== 2 && (t = Re, Re = n, t !== null && zl(t)), e;
  }
  function zl(e) {
    Re === null ? Re = e : Re.push.apply(Re, e);
  }
  function l1(e) {
    for (var t = e; ; ) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && (n = n.stores, n !== null))
          for (var r = 0; r < n.length; r++) {
            var a = n[r], o = a.getSnapshot;
            a = a.value;
            try {
              if (!ut(o(), a))
                return false;
            } catch {
              return false;
            }
          }
      }
      if (n = t.child, t.subtreeFlags & 16384 && n !== null)
        n.return = t, t = n;
      else {
        if (t === e)
          break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e)
            return true;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
    }
    return true;
  }
  function Vt(e, t) {
    for (t &= ~rc, t &= ~es, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t; ) {
      var n = 31 - lt(t), r = 1 << n;
      e[n] = -1, t &= ~r;
    }
  }
  function Ku(e) {
    if (U & 6)
      throw Error(E(327));
    qn();
    var t = po(e, 0);
    if (!(t & 1))
      return De(e, oe()), null;
    var n = Lo(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = fl(e);
      r !== 0 && (t = r, n = jl(e, r));
    }
    if (n === 1)
      throw n = da, wn(e, 0), Vt(e, t), De(e, oe()), n;
    if (n === 6)
      throw Error(E(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, fn(e, Re, Et), De(e, oe()), null;
  }
  function oc(e, t) {
    var n = U;
    U |= 1;
    try {
      return e(t);
    } finally {
      U = n, U === 0 && (lr = oe() + 500, Ko && sn());
    }
  }
  function xn(e) {
    Wt !== null && Wt.tag === 0 && !(U & 6) && qn();
    var t = U;
    U |= 1;
    var n = Ze.transition, r = V;
    try {
      if (Ze.transition = null, V = 1, e)
        return e();
    } finally {
      V = r, Ze.transition = n, U = t, !(U & 6) && sn();
    }
  }
  function sc() {
    $e = Hn.current, X(Hn);
  }
  function wn(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, Dh(n)), se !== null)
      for (n = se.return; n !== null; ) {
        var r = n;
        switch (ji(r), r.tag) {
          case 1:
            r = r.type.childContextTypes, r != null && wo();
            break;
          case 3:
            or(), X(Fe), X(xe), Zi();
            break;
          case 5:
            Qi(r);
            break;
          case 4:
            or();
            break;
          case 13:
            X(ee);
            break;
          case 19:
            X(ee);
            break;
          case 10:
            Hi(r.type._context);
            break;
          case 22:
          case 23:
            sc();
        }
        n = n.return;
      }
    if (pe = e, se = e = en(e.current, null), ye = $e = t, ue = 0, da = null, rc = es = Tn = 0, Re = Br = null, mn !== null) {
      for (t = 0; t < mn.length; t++)
        if (n = mn[t], r = n.interleaved, r !== null) {
          n.interleaved = null;
          var a = r.next, o = n.pending;
          if (o !== null) {
            var s = o.next;
            o.next = a, r.next = s;
          }
          n.pending = r;
        }
      mn = null;
    }
    return e;
  }
  function Fp(e, t) {
    do {
      var n = se;
      try {
        if (Vi(), Xa.current = Co, Mo) {
          for (var r = te.memoizedState; r !== null; ) {
            var a = r.queue;
            a !== null && (a.pending = null), r = r.next;
          }
          Mo = false;
        }
        if (En = 0, fe = le = te = null, jr = false, ia = 0, nc.current = null, n === null || n.return === null) {
          ue = 1, da = t, se = null;
          break;
        }
        e: {
          var o = e, s = n.return, l = n, i = t;
          if (t = ye, l.flags |= 32768, i !== null && typeof i == "object" && typeof i.then == "function") {
            var c = i, u = l, p = u.tag;
            if (!(u.mode & 1) && (p === 0 || p === 11 || p === 15)) {
              var f = u.alternate;
              f ? (u.updateQueue = f.updateQueue, u.memoizedState = f.memoizedState, u.lanes = f.lanes) : (u.updateQueue = null, u.memoizedState = null);
            }
            var d = Du(s);
            if (d !== null) {
              d.flags &= -257, Uu(d, s, l, o, t), d.mode & 1 && Iu(o, c, t), t = d, i = c;
              var w = t.updateQueue;
              if (w === null) {
                var y = /* @__PURE__ */ new Set();
                y.add(i), t.updateQueue = y;
              } else
                w.add(i);
              break e;
            } else {
              if (!(t & 1)) {
                Iu(o, c, t), lc();
                break e;
              }
              i = Error(E(426));
            }
          } else if (J && l.mode & 1) {
            var S = Du(s);
            if (S !== null) {
              !(S.flags & 65536) && (S.flags |= 256), Uu(S, s, l, o, t), zi(sr(i, l));
              break e;
            }
          }
          o = i = sr(i, l), ue !== 4 && (ue = 2), Br === null ? Br = [
            o
          ] : Br.push(o), o = s;
          do {
            switch (o.tag) {
              case 3:
                o.flags |= 65536, t &= -t, o.lanes |= t;
                var g = wp(o, i, t);
                bu(o, g);
                break e;
              case 1:
                l = i;
                var m = o.type, h = o.stateNode;
                if (!(o.flags & 128) && (typeof m.getDerivedStateFromError == "function" || h !== null && typeof h.componentDidCatch == "function" && (qt === null || !qt.has(h)))) {
                  o.flags |= 65536, t &= -t, o.lanes |= t;
                  var v = vp(o, l, t);
                  bu(o, v);
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
        }
        Up(n);
      } catch (A) {
        t = A, se === n && n !== null && (se = n = n.return);
        continue;
      }
      break;
    } while (1);
  }
  function Ip() {
    var e = No.current;
    return No.current = Co, e === null ? Co : e;
  }
  function lc() {
    (ue === 0 || ue === 3 || ue === 2) && (ue = 4), pe === null || !(Tn & 268435455) && !(es & 268435455) || Vt(pe, ye);
  }
  function Lo(e, t) {
    var n = U;
    U |= 2;
    var r = Ip();
    (pe !== e || ye !== t) && (Et = null, wn(e, t));
    do
      try {
        i1();
        break;
      } catch (a) {
        Fp(e, a);
      }
    while (1);
    if (Vi(), U = n, No.current = r, se !== null)
      throw Error(E(261));
    return pe = null, ye = 0, ue;
  }
  function i1() {
    for (; se !== null; )
      Dp(se);
  }
  function c1() {
    for (; se !== null && !Om(); )
      Dp(se);
  }
  function Dp(e) {
    var t = jp(e.alternate, e, $e);
    e.memoizedProps = e.pendingProps, t === null ? Up(e) : se = t, nc.current = null;
  }
  function Up(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (e = t.return, t.flags & 32768) {
        if (n = n1(n, t), n !== null) {
          n.flags &= 32767, se = n;
          return;
        }
        if (e !== null)
          e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
        else {
          ue = 6, se = null;
          return;
        }
      } else if (n = t1(n, t, $e), n !== null) {
        se = n;
        return;
      }
      if (t = t.sibling, t !== null) {
        se = t;
        return;
      }
      se = t = e;
    } while (t !== null);
    ue === 0 && (ue = 5);
  }
  function fn(e, t, n) {
    var r = V, a = Ze.transition;
    try {
      Ze.transition = null, V = 1, u1(e, t, n, r);
    } finally {
      Ze.transition = a, V = r;
    }
    return null;
  }
  function u1(e, t, n, r) {
    do
      qn();
    while (Wt !== null);
    if (U & 6)
      throw Error(E(327));
    n = e.finishedWork;
    var a = e.finishedLanes;
    if (n === null)
      return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current)
      throw Error(E(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var o = n.lanes | n.childLanes;
    if (Hm(e, o), e === pe && (se = pe = null, ye = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || za || (za = true, zp(fo, function() {
      return qn(), null;
    })), o = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || o) {
      o = Ze.transition, Ze.transition = null;
      var s = V;
      V = 1;
      var l = U;
      U |= 4, nc.current = null, a1(e, n), _p(n, e), bh(wl), go = !!yl, wl = yl = null, e.current = n, o1(n), Fm(), U = l, V = s, Ze.transition = o;
    } else
      e.current = n;
    if (za && (za = false, Wt = e, bo = a), o = e.pendingLanes, o === 0 && (qt = null), Um(n.stateNode), De(e, oe()), t !== null)
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        a = t[n], r(a.value, {
          componentStack: a.stack,
          digest: a.digest
        });
    if (Po)
      throw Po = false, e = Ul, Ul = null, e;
    return bo & 1 && e.tag !== 0 && qn(), o = e.pendingLanes, o & 1 ? e === $l ? Vr++ : (Vr = 0, $l = e) : Vr = 0, sn(), null;
  }
  function qn() {
    if (Wt !== null) {
      var e = wf(bo), t = Ze.transition, n = V;
      try {
        if (Ze.transition = null, V = 16 > e ? 16 : e, Wt === null)
          var r = false;
        else {
          if (e = Wt, Wt = null, bo = 0, U & 6)
            throw Error(E(331));
          var a = U;
          for (U |= 4, b = e.current; b !== null; ) {
            var o = b, s = o.child;
            if (b.flags & 16) {
              var l = o.deletions;
              if (l !== null) {
                for (var i = 0; i < l.length; i++) {
                  var c = l[i];
                  for (b = c; b !== null; ) {
                    var u = b;
                    switch (u.tag) {
                      case 0:
                      case 11:
                      case 15:
                        zr(8, u, o);
                    }
                    var p = u.child;
                    if (p !== null)
                      p.return = u, b = p;
                    else
                      for (; b !== null; ) {
                        u = b;
                        var f = u.sibling, d = u.return;
                        if (Pp(u), u === c) {
                          b = null;
                          break;
                        }
                        if (f !== null) {
                          f.return = d, b = f;
                          break;
                        }
                        b = d;
                      }
                  }
                }
                var w = o.alternate;
                if (w !== null) {
                  var y = w.child;
                  if (y !== null) {
                    w.child = null;
                    do {
                      var S = y.sibling;
                      y.sibling = null, y = S;
                    } while (y !== null);
                  }
                }
                b = o;
              }
            }
            if (o.subtreeFlags & 2064 && s !== null)
              s.return = o, b = s;
            else
              e:
                for (; b !== null; ) {
                  if (o = b, o.flags & 2048)
                    switch (o.tag) {
                      case 0:
                      case 11:
                      case 15:
                        zr(9, o, o.return);
                    }
                  var g = o.sibling;
                  if (g !== null) {
                    g.return = o.return, b = g;
                    break e;
                  }
                  b = o.return;
                }
          }
          var m = e.current;
          for (b = m; b !== null; ) {
            s = b;
            var h = s.child;
            if (s.subtreeFlags & 2064 && h !== null)
              h.return = s, b = h;
            else
              e:
                for (s = m; b !== null; ) {
                  if (l = b, l.flags & 2048)
                    try {
                      switch (l.tag) {
                        case 0:
                        case 11:
                        case 15:
                          Jo(9, l);
                      }
                    } catch (A) {
                      re(l, l.return, A);
                    }
                  if (l === s) {
                    b = null;
                    break e;
                  }
                  var v = l.sibling;
                  if (v !== null) {
                    v.return = l.return, b = v;
                    break e;
                  }
                  b = l.return;
                }
          }
          if (U = a, sn(), yt && typeof yt.onPostCommitFiberRoot == "function")
            try {
              yt.onPostCommitFiberRoot(Go, e);
            } catch {
            }
          r = true;
        }
        return r;
      } finally {
        V = n, Ze.transition = t;
      }
    }
    return false;
  }
  function Xu(e, t, n) {
    t = sr(n, t), t = wp(e, t, 1), e = Xt(e, t, 1), t = Ce(), e !== null && (va(e, 1, t), De(e, t));
  }
  function re(e, t, n) {
    if (e.tag === 3)
      Xu(e, e, n);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          Xu(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (qt === null || !qt.has(r))) {
            e = sr(n, e), e = vp(t, e, 1), t = Xt(t, e, 1), e = Ce(), t !== null && (va(t, 1, e), De(t, e));
            break;
          }
        }
        t = t.return;
      }
  }
  function d1(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = Ce(), e.pingedLanes |= e.suspendedLanes & n, pe === e && (ye & n) === n && (ue === 4 || ue === 3 && (ye & 130023424) === ye && 500 > oe() - ac ? wn(e, 0) : rc |= n), De(e, t);
  }
  function $p(e, t) {
    t === 0 && (e.mode & 1 ? (t = La, La <<= 1, !(La & 130023424) && (La = 4194304)) : t = 1);
    var n = Ce();
    e = _t(e, t), e !== null && (va(e, t, n), De(e, n));
  }
  function f1(e) {
    var t = e.memoizedState, n = 0;
    t !== null && (n = t.retryLane), $p(e, n);
  }
  function p1(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode, a = e.memoizedState;
        a !== null && (n = a.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(E(314));
    }
    r !== null && r.delete(t), $p(e, n);
  }
  var jp;
  jp = function(e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || Fe.current)
        Oe = true;
      else {
        if (!(e.lanes & n) && !(t.flags & 128))
          return Oe = false, e1(e, t, n);
        Oe = !!(e.flags & 131072);
      }
    else
      Oe = false, J && t.flags & 1048576 && Hf(t, ko, t.index);
    switch (t.lanes = 0, t.tag) {
      case 2:
        var r = t.type;
        Ja(e, t), e = t.pendingProps;
        var a = nr(t, xe.current);
        Xn(t, n), a = Xi(null, t, r, e, a, n);
        var o = qi();
        return t.flags |= 1, typeof a == "object" && a !== null && typeof a.render == "function" && a.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Ie(r) ? (o = true, vo(t)) : o = false, t.memoizedState = a.state !== null && a.state !== void 0 ? a.state : null, Wi(t), a.updater = qo, t.stateNode = a, a._reactInternals = t, Cl(t, r, e, n), t = bl(null, t, r, true, o, n)) : (t.tag = 0, J && o && $i(t), Me(null, t, a, n), t = t.child), t;
      case 16:
        r = t.elementType;
        e: {
          switch (Ja(e, t), e = t.pendingProps, a = r._init, r = a(r._payload), t.type = r, a = t.tag = m1(r), e = at(r, e), a) {
            case 0:
              t = Pl(null, t, r, e, n);
              break e;
            case 1:
              t = zu(null, t, r, e, n);
              break e;
            case 11:
              t = $u(null, t, r, e, n);
              break e;
            case 14:
              t = ju(null, t, r, at(r.type, e), n);
              break e;
          }
          throw Error(E(306, r, ""));
        }
        return t;
      case 0:
        return r = t.type, a = t.pendingProps, a = t.elementType === r ? a : at(r, a), Pl(e, t, r, a, n);
      case 1:
        return r = t.type, a = t.pendingProps, a = t.elementType === r ? a : at(r, a), zu(e, t, r, a, n);
      case 3:
        e: {
          if (Tp(t), e === null)
            throw Error(E(387));
          r = t.pendingProps, o = t.memoizedState, a = o.element, Kf(e, t), xo(t, r, null, n);
          var s = t.memoizedState;
          if (r = s.element, o.isDehydrated)
            if (o = {
              element: r,
              isDehydrated: false,
              cache: s.cache,
              pendingSuspenseBoundaries: s.pendingSuspenseBoundaries,
              transitions: s.transitions
            }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
              a = sr(Error(E(423)), t), t = Bu(e, t, r, n, a);
              break e;
            } else if (r !== a) {
              a = sr(Error(E(424)), t), t = Bu(e, t, r, n, a);
              break e;
            } else
              for (je = Kt(t.stateNode.containerInfo.firstChild), ze = t, J = true, st = null, n = Qf(t, null, r, n), t.child = n; n; )
                n.flags = n.flags & -3 | 4096, n = n.sibling;
          else {
            if (rr(), r === a) {
              t = Rt(e, t, n);
              break e;
            }
            Me(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return Xf(t), e === null && xl(t), r = t.type, a = t.pendingProps, o = e !== null ? e.memoizedProps : null, s = a.children, vl(r, a) ? s = null : o !== null && vl(r, o) && (t.flags |= 32), Ep(e, t), Me(e, t, s, n), t.child;
      case 6:
        return e === null && xl(t), null;
      case 13:
        return xp(e, t, n);
      case 4:
        return Yi(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = ar(t, null, r, n) : Me(e, t, r, n), t.child;
      case 11:
        return r = t.type, a = t.pendingProps, a = t.elementType === r ? a : at(r, a), $u(e, t, r, a, n);
      case 7:
        return Me(e, t, t.pendingProps, n), t.child;
      case 8:
        return Me(e, t, t.pendingProps.children, n), t.child;
      case 12:
        return Me(e, t, t.pendingProps.children, n), t.child;
      case 10:
        e: {
          if (r = t.type._context, a = t.pendingProps, o = t.memoizedProps, s = a.value, Q(Eo, r._currentValue), r._currentValue = s, o !== null)
            if (ut(o.value, s)) {
              if (o.children === a.children && !Fe.current) {
                t = Rt(e, t, n);
                break e;
              }
            } else
              for (o = t.child, o !== null && (o.return = t); o !== null; ) {
                var l = o.dependencies;
                if (l !== null) {
                  s = o.child;
                  for (var i = l.firstContext; i !== null; ) {
                    if (i.context === r) {
                      if (o.tag === 1) {
                        i = Ct(-1, n & -n), i.tag = 2;
                        var c = o.updateQueue;
                        if (c !== null) {
                          c = c.shared;
                          var u = c.pending;
                          u === null ? i.next = i : (i.next = u.next, u.next = i), c.pending = i;
                        }
                      }
                      o.lanes |= n, i = o.alternate, i !== null && (i.lanes |= n), Al(o.return, n, t), l.lanes |= n;
                      break;
                    }
                    i = i.next;
                  }
                } else if (o.tag === 10)
                  s = o.type === t.type ? null : o.child;
                else if (o.tag === 18) {
                  if (s = o.return, s === null)
                    throw Error(E(341));
                  s.lanes |= n, l = s.alternate, l !== null && (l.lanes |= n), Al(s, n, t), s = o.sibling;
                } else
                  s = o.child;
                if (s !== null)
                  s.return = o;
                else
                  for (s = o; s !== null; ) {
                    if (s === t) {
                      s = null;
                      break;
                    }
                    if (o = s.sibling, o !== null) {
                      o.return = s.return, s = o;
                      break;
                    }
                    s = s.return;
                  }
                o = s;
              }
          Me(e, t, a.children, n), t = t.child;
        }
        return t;
      case 9:
        return a = t.type, r = t.pendingProps.children, Xn(t, n), a = Ke(a), r = r(a), t.flags |= 1, Me(e, t, r, n), t.child;
      case 14:
        return r = t.type, a = at(r, t.pendingProps), a = at(r.type, a), ju(e, t, r, a, n);
      case 15:
        return Sp(e, t, t.type, t.pendingProps, n);
      case 17:
        return r = t.type, a = t.pendingProps, a = t.elementType === r ? a : at(r, a), Ja(e, t), t.tag = 1, Ie(r) ? (e = true, vo(t)) : e = false, Xn(t, n), yp(t, r, a), Cl(t, r, a, n), bl(null, t, r, true, e, n);
      case 19:
        return Ap(e, t, n);
      case 22:
        return kp(e, t, n);
    }
    throw Error(E(156, t.tag));
  };
  function zp(e, t) {
    return gf(e, t);
  }
  function g1(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function Qe(e, t, n, r) {
    return new g1(e, t, n, r);
  }
  function ic(e) {
    return e = e.prototype, !(!e || !e.isReactComponent);
  }
  function m1(e) {
    if (typeof e == "function")
      return ic(e) ? 1 : 0;
    if (e != null) {
      if (e = e.$$typeof, e === Ci)
        return 11;
      if (e === Ni)
        return 14;
    }
    return 2;
  }
  function en(e, t) {
    var n = e.alternate;
    return n === null ? (n = Qe(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
      lanes: t.lanes,
      firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n;
  }
  function no(e, t, n, r, a, o) {
    var s = 2;
    if (r = e, typeof e == "function")
      ic(e) && (s = 1);
    else if (typeof e == "string")
      s = 5;
    else
      e:
        switch (e) {
          case On:
            return vn(n.children, a, o, t);
          case Mi:
            s = 8, a |= 8;
            break;
          case Xs:
            return e = Qe(12, n, t, a | 2), e.elementType = Xs, e.lanes = o, e;
          case qs:
            return e = Qe(13, n, t, a), e.elementType = qs, e.lanes = o, e;
          case Js:
            return e = Qe(19, n, t, a), e.elementType = Js, e.lanes = o, e;
          case Kd:
            return ts(n, a, o, t);
          default:
            if (typeof e == "object" && e !== null)
              switch (e.$$typeof) {
                case Qd:
                  s = 10;
                  break e;
                case Zd:
                  s = 9;
                  break e;
                case Ci:
                  s = 11;
                  break e;
                case Ni:
                  s = 14;
                  break e;
                case jt:
                  s = 16, r = null;
                  break e;
              }
            throw Error(E(130, e == null ? e : typeof e, ""));
        }
    return t = Qe(s, n, t, a), t.elementType = e, t.type = r, t.lanes = o, t;
  }
  function vn(e, t, n, r) {
    return e = Qe(7, e, r, t), e.lanes = n, e;
  }
  function ts(e, t, n, r) {
    return e = Qe(22, e, r, t), e.elementType = Kd, e.lanes = n, e.stateNode = {
      isHidden: false
    }, e;
  }
  function zs(e, t, n) {
    return e = Qe(6, e, null, t), e.lanes = n, e;
  }
  function Bs(e, t, n) {
    return t = Qe(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      implementation: e.implementation
    }, t;
  }
  function h1(e, t, n, r, a) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Es(0), this.expirationTimes = Es(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Es(0), this.identifierPrefix = r, this.onRecoverableError = a, this.mutableSourceEagerHydrationData = null;
  }
  function cc(e, t, n, r, a, o, s, l, i) {
    return e = new h1(e, t, n, l, i), t === 1 ? (t = 1, o === true && (t |= 8)) : t = 0, o = Qe(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = {
      element: r,
      isDehydrated: n,
      cache: null,
      transitions: null,
      pendingSuspenseBoundaries: null
    }, Wi(o), e;
  }
  function y1(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: Rn,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n
    };
  }
  function Bp(e) {
    if (!e)
      return rn;
    e = e._reactInternals;
    e: {
      if (Mn(e) !== e || e.tag !== 1)
        throw Error(E(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (Ie(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(E(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (Ie(n))
        return Bf(e, n, t);
    }
    return t;
  }
  function Vp(e, t, n, r, a, o, s, l, i) {
    return e = cc(n, r, true, e, a, o, s, l, i), e.context = Bp(null), n = e.current, r = Ce(), a = Jt(n), o = Ct(r, a), o.callback = t ?? null, Xt(n, o, a), e.current.lanes = a, va(e, a, r), De(e, r), e;
  }
  function ns(e, t, n, r) {
    var a = t.current, o = Ce(), s = Jt(a);
    return n = Bp(n), t.context === null ? t.context = n : t.pendingContext = n, t = Ct(o, s), t.payload = {
      element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = Xt(a, t, s), e !== null && (it(e, a, s, o), Ka(e, a, s)), s;
  }
  function _o(e) {
    if (e = e.current, !e.child)
      return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function qu(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function uc(e, t) {
    qu(e, t), (e = e.alternate) && qu(e, t);
  }
  function w1() {
    return null;
  }
  var Hp = typeof reportError == "function" ? reportError : function(e) {
    console.error(e);
  };
  function dc(e) {
    this._internalRoot = e;
  }
  rs.prototype.render = dc.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null)
      throw Error(E(409));
    ns(e, t, null, null);
  };
  rs.prototype.unmount = dc.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
      this._internalRoot = null;
      var t = e.containerInfo;
      xn(function() {
        ns(null, e, null, null);
      }), t[Lt] = null;
    }
  };
  function rs(e) {
    this._internalRoot = e;
  }
  rs.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
      var t = kf();
      e = {
        blockedOn: null,
        target: e,
        priority: t
      };
      for (var n = 0; n < Bt.length && t !== 0 && t < Bt[n].priority; n++)
        ;
      Bt.splice(n, 0, e), n === 0 && Tf(e);
    }
  };
  function fc(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
  }
  function as(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "));
  }
  function Ju() {
  }
  function v1(e, t, n, r, a) {
    if (a) {
      if (typeof r == "function") {
        var o = r;
        r = function() {
          var c = _o(s);
          o.call(c);
        };
      }
      var s = Vp(t, r, e, 0, null, false, false, "", Ju);
      return e._reactRootContainer = s, e[Lt] = s.current, ra(e.nodeType === 8 ? e.parentNode : e), xn(), s;
    }
    for (; a = e.lastChild; )
      e.removeChild(a);
    if (typeof r == "function") {
      var l = r;
      r = function() {
        var c = _o(i);
        l.call(c);
      };
    }
    var i = cc(e, 0, false, null, null, false, false, "", Ju);
    return e._reactRootContainer = i, e[Lt] = i.current, ra(e.nodeType === 8 ? e.parentNode : e), xn(function() {
      ns(t, i, n, r);
    }), i;
  }
  function os(e, t, n, r, a) {
    var o = n._reactRootContainer;
    if (o) {
      var s = o;
      if (typeof a == "function") {
        var l = a;
        a = function() {
          var i = _o(s);
          l.call(i);
        };
      }
      ns(t, s, e, a);
    } else
      s = v1(n, t, e, a, r);
    return _o(s);
  }
  vf = function(e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = _r(t.pendingLanes);
          n !== 0 && (Li(t, n | 1), De(t, oe()), !(U & 6) && (lr = oe() + 500, sn()));
        }
        break;
      case 13:
        xn(function() {
          var r = _t(e, 1);
          if (r !== null) {
            var a = Ce();
            it(r, e, 1, a);
          }
        }), uc(e, 1);
    }
  };
  _i = function(e) {
    if (e.tag === 13) {
      var t = _t(e, 134217728);
      if (t !== null) {
        var n = Ce();
        it(t, e, 134217728, n);
      }
      uc(e, 134217728);
    }
  };
  Sf = function(e) {
    if (e.tag === 13) {
      var t = Jt(e), n = _t(e, t);
      if (n !== null) {
        var r = Ce();
        it(n, e, t, r);
      }
      uc(e, t);
    }
  };
  kf = function() {
    return V;
  };
  Ef = function(e, t) {
    var n = V;
    try {
      return V = e, t();
    } finally {
      V = n;
    }
  };
  cl = function(e, t, n) {
    switch (t) {
      case "input":
        if (nl(e, n), t = n.name, n.type === "radio" && t != null) {
          for (n = e; n.parentNode; )
            n = n.parentNode;
          for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
            var r = n[t];
            if (r !== e && r.form === e.form) {
              var a = Zo(r);
              if (!a)
                throw Error(E(90));
              qd(r), nl(r, a);
            }
          }
        }
        break;
      case "textarea":
        ef(e, n);
        break;
      case "select":
        t = n.value, t != null && Yn(e, !!n.multiple, t, false);
    }
  };
  lf = oc;
  cf = xn;
  var S1 = {
    usingClientEntryPoint: false,
    Events: [
      ka,
      Un,
      Zo,
      of,
      sf,
      oc
    ]
  }, Pr = {
    findFiberByHostInstance: gn,
    bundleType: 0,
    version: "18.3.1",
    rendererPackageName: "react-dom"
  }, k1 = {
    bundleType: Pr.bundleType,
    version: Pr.version,
    rendererPackageName: Pr.rendererPackageName,
    rendererConfig: Pr.rendererConfig,
    overrideHookState: null,
    overrideHookStateDeletePath: null,
    overrideHookStateRenamePath: null,
    overrideProps: null,
    overridePropsDeletePath: null,
    overridePropsRenamePath: null,
    setErrorHandler: null,
    setSuspenseHandler: null,
    scheduleUpdate: null,
    currentDispatcherRef: Ot.ReactCurrentDispatcher,
    findHostInstanceByFiber: function(e) {
      return e = ff(e), e === null ? null : e.stateNode;
    },
    findFiberByHostInstance: Pr.findFiberByHostInstance || w1,
    findHostInstancesForRefresh: null,
    scheduleRefresh: null,
    scheduleRoot: null,
    setRefreshHandler: null,
    getCurrentFiber: null,
    reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Ba = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Ba.isDisabled && Ba.supportsFiber)
      try {
        Go = Ba.inject(k1), yt = Ba;
      } catch {
      }
  }
  Ve.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = S1;
  Ve.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!fc(t))
      throw Error(E(200));
    return y1(e, t, null, n);
  };
  Ve.createRoot = function(e, t) {
    if (!fc(e))
      throw Error(E(299));
    var n = false, r = "", a = Hp;
    return t != null && (t.unstable_strictMode === true && (n = true), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (a = t.onRecoverableError)), t = cc(e, 1, false, null, null, n, false, r, a), e[Lt] = t.current, ra(e.nodeType === 8 ? e.parentNode : e), new dc(t);
  };
  Ve.findDOMNode = function(e) {
    if (e == null)
      return null;
    if (e.nodeType === 1)
      return e;
    var t = e._reactInternals;
    if (t === void 0)
      throw typeof e.render == "function" ? Error(E(188)) : (e = Object.keys(e).join(","), Error(E(268, e)));
    return e = ff(t), e = e === null ? null : e.stateNode, e;
  };
  Ve.flushSync = function(e) {
    return xn(e);
  };
  Ve.hydrate = function(e, t, n) {
    if (!as(t))
      throw Error(E(200));
    return os(null, e, t, true, n);
  };
  Ve.hydrateRoot = function(e, t, n) {
    if (!fc(e))
      throw Error(E(405));
    var r = n != null && n.hydratedSources || null, a = false, o = "", s = Hp;
    if (n != null && (n.unstable_strictMode === true && (a = true), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onRecoverableError !== void 0 && (s = n.onRecoverableError)), t = Vp(t, null, e, 1, n ?? null, a, false, o, s), e[Lt] = t.current, ra(e), r)
      for (e = 0; e < r.length; e++)
        n = r[e], a = n._getVersion, a = a(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [
          n,
          a
        ] : t.mutableSourceEagerHydrationData.push(n, a);
    return new rs(t);
  };
  Ve.render = function(e, t, n) {
    if (!as(t))
      throw Error(E(200));
    return os(null, e, t, false, n);
  };
  Ve.unmountComponentAtNode = function(e) {
    if (!as(e))
      throw Error(E(40));
    return e._reactRootContainer ? (xn(function() {
      os(null, null, e, false, function() {
        e._reactRootContainer = null, e[Lt] = null;
      });
    }), true) : false;
  };
  Ve.unstable_batchedUpdates = oc;
  Ve.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!as(n))
      throw Error(E(200));
    if (e == null || e._reactInternals === void 0)
      throw Error(E(38));
    return os(e, t, n, false, r);
  };
  Ve.version = "18.3.1-next-f1338f8080-20240426";
  function Gp() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Gp);
      } catch (e) {
        console.error(e);
      }
  }
  Gp(), Hd.exports = Ve;
  E1 = Hd.exports;
  T1 = wi(E1);
  function x1(e) {
    this.state = {
      ...this.state,
      ...e
    }, this.listeners.forEach((t) => {
      t(this.state);
    });
  }
  function A1(e) {
    const t = e.useState()[1];
    return e.useEffect(() => (this.listeners.push(t), () => {
      this.listeners = this.listeners.filter((n) => n !== t);
    }), []), [
      this.state,
      this.actions
    ];
  }
  function Wp(e, t) {
    const n = {};
    return Object.keys(t).forEach((r) => {
      typeof t[r] == "function" && (n[r] = t[r].bind(null, e)), typeof t[r] == "object" && (n[r] = Wp(e, t[r]));
    }), n;
  }
  let M1, pc, C1, N1, P1, b1, L1, _1, R1, Nt, O1, F1, I1, D1, ss, U1, $1, Vs;
  M1 = (e, t, n) => {
    const r = {
      state: t,
      listeners: []
    };
    return r.setState = x1.bind(r), r.actions = Wp(r, n), A1.bind(r, e);
  };
  pc = async (e, t) => {
    const n = await fetch(`${Ng}${e}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(t),
      signal: AbortSignal.timeout(1e4)
    });
    if (!n.ok) {
      const a = await n.json().catch(() => null), o = new Error((a == null ? void 0 : a.message) || `HTTP error ${n.status}`);
      throw (a == null ? void 0 : a.success) === false && (o.apiRejected = true), o;
    }
    const r = await n.json();
    if (!r.success) {
      const a = new Error(r.message || "License API error");
      throw a.apiRejected = true, a;
    }
    return r;
  };
  C1 = (e, t) => pc("/license/validate", {
    key: e,
    ...t && {
      activation_id: t
    }
  });
  N1 = (e, t) => pc("/license/activate", {
    key: e,
    label: t
  });
  P1 = (e, t) => pc("/license/deactivate", {
    key: e,
    activation_id: t
  });
  b1 = async () => {
    try {
      const [e, t] = await Promise.all([
        k.get(Bo),
        k.get(Yr)
      ]);
      return {
        licenseKey: e || null,
        me: t || null,
        isActivating: false,
        isDeactivating: false,
        error: null
      };
    } catch {
      return {
        licenseKey: null,
        me: null,
        isActivating: false,
        isDeactivating: false,
        error: null
      };
    }
  };
  L1 = await b1();
  _1 = {
    "Not found": "License key not found. Please double-check your key and try again.",
    "License API error": "Something went wrong. Please try again in a moment.",
    "Failed to fetch": "Could not reach the server. Please check your connection and try again.",
    "signal timed out": "The server took too long to respond. Please try again.",
    "The operation was aborted": "The server took too long to respond. Please try again.",
    "The operation was aborted.": "The server took too long to respond. Please try again."
  };
  R1 = (e) => _1[e] || e;
  Nt = (e, t) => {
    e.setState({
      auth: {
        ...e.state.auth,
        ...t
      }
    });
  };
  O1 = (e) => {
    e.state.auth.error && Nt(e, {
      error: null
    });
  };
  F1 = async (e, t) => {
    if (e.state.auth.isActivating)
      return false;
    Nt(e, {
      isActivating: true,
      error: null
    });
    try {
      const n = crypto.randomUUID(), a = (await N1(t, n)).data;
      return await Promise.all([
        k.set(Bo, t),
        k.set(Yr, a),
        k.remove(ai)
      ]), Nt(e, {
        licenseKey: t,
        me: a,
        isActivating: false,
        error: null
      }), true;
    } catch (n) {
      return Nt(e, {
        isActivating: false,
        error: R1(n.message)
      }), false;
    }
  };
  I1 = async (e) => {
    const { licenseKey: t, me: n } = e.state.auth;
    if (t)
      try {
        const a = (await C1(t, n == null ? void 0 : n.id)).data || {};
        if (a.licenseKey) {
          const o = {
            ...n,
            licenseKey: {
              ...n == null ? void 0 : n.licenseKey,
              ...a.licenseKey
            }
          };
          Nt(e, {
            me: o
          }), await k.set(Yr, o);
        }
        return true;
      } catch (r) {
        return r.apiRejected && (await Promise.all([
          k.remove(Bo),
          k.remove(Yr)
        ]), Nt(e, {
          licenseKey: null,
          me: null,
          isDeactivating: false,
          isActivating: false,
          error: null
        })), false;
      }
  };
  D1 = async (e) => {
    const { licenseKey: t, me: n } = e.state.auth;
    if (t) {
      Nt(e, {
        isDeactivating: true
      });
      try {
        await P1(t, n == null ? void 0 : n.id);
      } catch (r) {
        throw Nt(e, {
          isDeactivating: false
        }), r;
      }
      await Promise.all([
        k.remove(Bo),
        k.remove(Yr)
      ]), Nt(e, {
        licenseKey: null,
        me: null,
        isDeactivating: false,
        isActivating: false,
        error: null
      });
    }
  };
  ss = (e) => {
    var _a2;
    const { status: t, expiresAt: n } = ((_a2 = e.state.auth.me) == null ? void 0 : _a2.licenseKey) || {};
    return t === "granted" && (!n || new Date(n) > /* @__PURE__ */ new Date());
  };
  U1 = await k.get(Ws) == null ? true : await k.get(Ws);
  $1 = async (e) => {
    await e.setState({
      powerButton: !e.state.powerButton
    }), await k.set(Ws, e.state.powerButton);
  };
  $ = (e) => {
    const { authNotebookLM: t } = e;
    return t ? t.accounts && t.activeAccount ? t.accounts[t.activeAccount] || {} : t.token ? t : {} : {};
  };
  Vs = [
    "bg-blue-500",
    "bg-emerald-500",
    "bg-amber-500",
    "bg-rose-500",
    "bg-violet-500",
    "bg-cyan-500",
    "bg-pink-500",
    "bg-indigo-500"
  ];
  RE = (e) => {
    if (!e)
      return Vs[0];
    const t = e.split("").reduce((n, r) => n + r.charCodeAt(0), 0);
    return Vs[t % Vs.length];
  };
  OE = (e) => e ? e[0].toUpperCase() : "?";
  FE = async (e) => {
    e.resetStudioGeneration(), await e.resetNotebookLM(), await e.clearArtifacts(), await e.resetStatsState(), await e.resetPodcastPlayerState(), e.resetDuplicateScan(), e.resetSourceMerge(), e.resetNotebookActions(), e.resetBatchState(), e.resetLinksExtractor(), e.resetPlaylistImport(), e.resetRSSImport(), e.resetOpenTabsImport();
  };
  IE = (e) => {
    if (!e)
      return "";
    const [t, n] = e.split("@");
    if (!n)
      return e;
    const r = Math.min(3, Math.floor(t.length / 2));
    return `${t.slice(0, r) + "***"}@${n}`;
  };
  let Or = null;
  try {
    const e = await k.get(tn);
    if ((e == null ? void 0 : e.accounts) && (e == null ? void 0 : e.activeAccount))
      Or = e;
    else {
      const t = await k.get(ha);
      if ((t == null ? void 0 : t.token) && (t == null ? void 0 : t.email)) {
        Or = {
          accounts: {
            [t.email]: {
              ...t,
              authuser: t.authuser ?? 0,
              lastRefreshed: (/* @__PURE__ */ new Date()).toISOString()
            }
          },
          activeAccount: t.email,
          accountOrder: [
            t.email
          ]
        };
        try {
          await k.set(tn, Or);
        } catch (n) {
          console.error("[NLM Tools] Failed to persist migration:", n);
        }
      } else
        (t == null ? void 0 : t.token) && (Or = t);
    }
  } catch (e) {
    console.error("[NLM Tools] Failed to load auth:", e);
  }
  let j1, z1, gc, B1, V1, mc, Yp, H1, G1, W1, Y1, Q1, K1, Zp, X1, q1, J1, ey, ty, ny, ry, hc, ay, oy, sy, ly, iy, cy, uy, dy, fy, py, gy, my, hy, yy, wy, vy, Sy, ky, Ey, Ty, xy, yc, Kp, Xp, wc, Ay, My, Cy, Ny, Py, by, Ly, _y, Ry, Oy, Fy, Iy, Dy, Uy, $y, jy, zy, By, Vy, ed, Hy, Gy, Wy, td, me, qp, Yy, Qy, ve, Zy, Ky, Jp, e0, Ta, Xy, qy, Jy, ew, tw, Vl, Sc, nw, rw, aw, ow, sw, lw, iw, cw, uw, dw, Va, fw, t0, gw, mw, hw, yw;
  j1 = Or || {};
  z1 = (e) => {
    var _a2;
    return !!((_a2 = $(e.state)) == null ? void 0 : _a2.token);
  };
  gc = async (e, t) => {
    try {
      t && e[t] && await k.set(ha, e[t]);
    } catch (n) {
      console.error("[NLM Tools] Failed to mirror to legacy:", n);
    }
  };
  B1 = async (e, t) => {
    const n = e.state.authNotebookLM || {};
    if (t == null ? void 0 : t.email) {
      const r = {
        ...n.accounts || {}
      };
      r[t.email] = {
        ...t,
        lastRefreshed: (/* @__PURE__ */ new Date()).toISOString()
      };
      const a = n.activeAccount || t.email, o = n.accountOrder ? [
        ...n.accountOrder
      ] : [];
      o.includes(t.email) || o.push(t.email);
      const s = {
        accounts: r,
        activeAccount: a,
        accountOrder: o
      };
      await e.setState({
        authNotebookLM: s
      }), await k.set(tn, s), await gc(r, a);
    } else
      await e.setState({
        authNotebookLM: t
      }), await k.set(ha, t);
  };
  V1 = async (e, t) => {
    var _a2;
    const n = e.state.authNotebookLM;
    if (!((_a2 = n == null ? void 0 : n.accounts) == null ? void 0 : _a2[t]))
      return;
    const r = {
      ...n,
      activeAccount: t
    };
    await e.setState({
      authNotebookLM: r
    }), await k.set(tn, r), await gc(n.accounts, t);
  };
  mc = async (e, t) => {
    const n = e.state.authNotebookLM;
    if (!(n == null ? void 0 : n.accounts))
      return;
    const r = {
      ...n.accounts
    };
    delete r[t];
    const a = (n.accountOrder || []).filter((l) => l !== t);
    let o = n.activeAccount;
    if (o === t && (o = a[0] || null), a.length === 0) {
      await e.setState({
        authNotebookLM: {}
      }), await k.remove(tn), await k.remove(ha);
      return;
    }
    const s = {
      accounts: r,
      activeAccount: o,
      accountOrder: a
    };
    await e.setState({
      authNotebookLM: s
    }), await k.set(tn, s), await gc(r, o);
  };
  Yp = async (e) => {
    const t = e.state.authNotebookLM;
    if ((t == null ? void 0 : t.accounts) && (t == null ? void 0 : t.activeAccount)) {
      await mc(e, t.activeAccount);
      return;
    }
    await e.setState({
      authNotebookLM: {}
    }), await k.remove(ha), await k.remove(tn);
  };
  H1 = async (e) => {
    const t = await k.get(tn);
    (t == null ? void 0 : t.accounts) && (t == null ? void 0 : t.activeAccount) && await e.setState({
      authNotebookLM: t
    });
  };
  G1 = (e) => {
    const t = e.state.authNotebookLM;
    return (t == null ? void 0 : t.accounts) ? (t.accountOrder || Object.keys(t.accounts)).filter((r) => t.accounts[r]).map((r) => ({
      email: r,
      ...t.accounts[r],
      isActive: r === t.activeAccount
    })) : [];
  };
  W1 = [
    {
      code: "af",
      name: "Afrikaans"
    },
    {
      code: "az",
      name: "az\u0259rbaycan (Azerbaijani)"
    },
    {
      code: "ca",
      name: "catal\xE0 (Catalan)"
    },
    {
      code: "cs",
      name: "\u010De\u0161tina (Czech)"
    },
    {
      code: "da",
      name: "dansk (Danish)"
    },
    {
      code: "de",
      name: "Deutsch (German)"
    },
    {
      code: "et",
      name: "eesti (Estonian)"
    },
    {
      code: "en",
      name: "English"
    },
    {
      code: "es",
      name: "espa\xF1ol (Spanish)"
    },
    {
      code: "es-419",
      name: "espa\xF1ol (Spanish - Latin America)"
    },
    {
      code: "eu",
      name: "euskara (Basque)"
    },
    {
      code: "fil",
      name: "Filipino"
    },
    {
      code: "fr",
      name: "fran\xE7ais (French)"
    },
    {
      code: "fr-CA",
      name: "fran\xE7ais (French - Canada)"
    },
    {
      code: "gl",
      name: "galego (Galician)"
    },
    {
      code: "hr",
      name: "hrvatski (Croatian)"
    },
    {
      code: "id",
      name: "Indonesia (Indonesian)"
    },
    {
      code: "is",
      name: "\xEDslenska (Icelandic)"
    },
    {
      code: "it",
      name: "italiano (Italian)"
    },
    {
      code: "sw",
      name: "Kiswahili (Swahili)"
    },
    {
      code: "lv",
      name: "latvie\u0161u (Latvian)"
    },
    {
      code: "lt",
      name: "lietuvi\u0173 (Lithuanian)"
    },
    {
      code: "hu",
      name: "magyar (Hungarian)"
    },
    {
      code: "ms",
      name: "Melayu (Malay)"
    },
    {
      code: "nl",
      name: "Nederlands (Dutch)"
    },
    {
      code: "nb",
      name: "norsk bokm\xE5l (Norwegian Bokm\xE5l)"
    },
    {
      code: "nn",
      name: "norsk nynorsk (Norwegian Nynorsk)"
    },
    {
      code: "pl",
      name: "polski (Polish)"
    },
    {
      code: "pt-BR",
      name: "portugu\xEAs (Portuguese - Brazil)"
    },
    {
      code: "pt-PT",
      name: "portugu\xEAs (Portuguese - Portugal)"
    },
    {
      code: "ro",
      name: "rom\xE2n\u0103 (Romanian)"
    },
    {
      code: "sq",
      name: "shqip (Albanian)"
    },
    {
      code: "sk",
      name: "sloven\u010Dina (Slovak)"
    },
    {
      code: "sl",
      name: "sloven\u0161\u010Dina (Slovenian)"
    },
    {
      code: "fi",
      name: "suomi (Finnish)"
    },
    {
      code: "sv",
      name: "svenska (Swedish)"
    },
    {
      code: "vi",
      name: "Ti\u1EBFng Vi\u1EC7t (Vietnamese)"
    },
    {
      code: "tr",
      name: "T\xFCrk\xE7e (Turkish)"
    },
    {
      code: "el",
      name: "\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC (Greek)"
    },
    {
      code: "be",
      name: "\u0431\u0435\u043B\u0430\u0440\u0443\u0441\u043A\u0430\u044F (Belarusian)"
    },
    {
      code: "bg",
      name: "\u0431\u044A\u043B\u0433\u0430\u0440\u0441\u043A\u0438 (Bulgarian)"
    },
    {
      code: "mk",
      name: "\u043C\u0430\u043A\u0435\u0434\u043E\u043D\u0441\u043A\u0438 (Macedonian)"
    },
    {
      code: "ru",
      name: "\u0440\u0443\u0441\u0441\u043A\u0438\u0439 (Russian)"
    },
    {
      code: "sr",
      name: "\u0441\u0440\u043F\u0441\u043A\u0438 (Serbian)"
    },
    {
      code: "uk",
      name: "\u0443\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430 (Ukrainian)"
    },
    {
      code: "ka",
      name: "\u10E5\u10D0\u10E0\u10D7\u10E3\u10DA\u10D8 (Georgian)"
    },
    {
      code: "hy",
      name: "\u0570\u0561\u0575\u0565\u0580\u0565\u0576 (Armenian)"
    },
    {
      code: "he",
      name: "\u05E2\u05D1\u05E8\u05D9\u05EA (Hebrew)"
    },
    {
      code: "ur",
      name: "\u0627\u0631\u062F\u0648 (Urdu)"
    },
    {
      code: "ar",
      name: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629 (Arabic)"
    },
    {
      code: "fa",
      name: "\u0641\u0627\u0631\u0633\u06CC (Persian)"
    },
    {
      code: "am",
      name: "\u12A0\u121B\u122D\u129B (Amharic)"
    },
    {
      code: "ne",
      name: "\u0928\u0947\u092A\u093E\u0932\u0940 (Nepali)"
    },
    {
      code: "mr",
      name: "\u092E\u0930\u093E\u0920\u0940 (Marathi)"
    },
    {
      code: "hi",
      name: "\u0939\u093F\u0928\u094D\u0926\u0940 (Hindi)"
    },
    {
      code: "bn",
      name: "\u09AC\u09BE\u0982\u09B2\u09BE (Bengali)"
    },
    {
      code: "pa",
      name: "\u0A2A\u0A70\u0A1C\u0A3E\u0A2C\u0A40 (Punjabi)"
    },
    {
      code: "gu",
      name: "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0 (Gujarati)"
    },
    {
      code: "or",
      name: "\u0B13\u0B21\u0B3C\u0B3F\u0B06 (Odia)"
    },
    {
      code: "ta",
      name: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD (Tamil)"
    },
    {
      code: "te",
      name: "\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41 (Telugu)"
    },
    {
      code: "kn",
      name: "\u0C95\u0CA8\u0CCD\u0CA8\u0CA1 (Kannada)"
    },
    {
      code: "ml",
      name: "\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02 (Malayalam)"
    },
    {
      code: "si",
      name: "\u0DC3\u0DD2\u0D82\u0DC4\u0DBD (Sinhala)"
    },
    {
      code: "th",
      name: "\u0E44\u0E17\u0E22 (Thai)"
    },
    {
      code: "ko",
      name: "\uD55C\uAD6D\uC5B4 (Korean)"
    },
    {
      code: "zh-CN",
      name: "\u4E2D\u6587 (Chinese - Simplified)"
    },
    {
      code: "zh-TW",
      name: "\u4E2D\u6587 (Chinese - Traditional)"
    },
    {
      code: "ja",
      name: "\u65E5\u672C\u8A9E (Japanese)"
    }
  ];
  Y1 = [
    {
      code: "af",
      name: "Afrikaans"
    },
    {
      code: "az",
      name: "az\u0259rbaycan"
    },
    {
      code: "ca",
      name: "catal\xE0"
    },
    {
      code: "ceb",
      name: "Cebuano"
    },
    {
      code: "cs",
      name: "\u010De\u0161tina"
    },
    {
      code: "ht",
      name: "cr\xE9ole ha\xEFtien"
    },
    {
      code: "da",
      name: "dansk"
    },
    {
      code: "de",
      name: "Deutsch"
    },
    {
      code: "et",
      name: "eesti"
    },
    {
      code: "en",
      name: "English"
    },
    {
      code: "es",
      name: "espa\xF1ol"
    },
    {
      code: "es-419",
      name: "espa\xF1ol (Latinoam\xE9rica)"
    },
    {
      code: "es-MX",
      name: "espa\xF1ol (M\xE9xico)"
    },
    {
      code: "eu",
      name: "euskara"
    },
    {
      code: "fil",
      name: "Filipino"
    },
    {
      code: "fr",
      name: "fran\xE7ais"
    },
    {
      code: "fr-CA",
      name: "fran\xE7ais (Canada)"
    },
    {
      code: "gl",
      name: "galego"
    },
    {
      code: "hr",
      name: "hrvatski"
    },
    {
      code: "id",
      name: "Indonesia"
    },
    {
      code: "is",
      name: "\xEDslenska"
    },
    {
      code: "it",
      name: "italiano"
    },
    {
      code: "jv",
      name: "Jawa"
    },
    {
      code: "sw",
      name: "Kiswahili"
    },
    {
      code: "la",
      name: "Latin"
    },
    {
      code: "lv",
      name: "latvie\u0161u"
    },
    {
      code: "lt",
      name: "lietuvi\u0173"
    },
    {
      code: "hu",
      name: "magyar"
    },
    {
      code: "ms",
      name: "Melayu"
    },
    {
      code: "nl",
      name: "Nederlands"
    },
    {
      code: "nb",
      name: "norsk bokm\xE5l"
    },
    {
      code: "nn",
      name: "norsk nynorsk"
    },
    {
      code: "pl",
      name: "polski"
    },
    {
      code: "pt-BR",
      name: "portugu\xEAs (Brasil)"
    },
    {
      code: "pt-PT",
      name: "portugu\xEAs (Portugal)"
    },
    {
      code: "ro",
      name: "rom\xE2n\u0103"
    },
    {
      code: "sq",
      name: "shqip"
    },
    {
      code: "sk",
      name: "sloven\u010Dina"
    },
    {
      code: "sl",
      name: "sloven\u0161\u010Dina"
    },
    {
      code: "fi",
      name: "suomi"
    },
    {
      code: "sv",
      name: "svenska"
    },
    {
      code: "vi",
      name: "Ti\u1EBFng Vi\u1EC7t"
    },
    {
      code: "tr",
      name: "T\xFCrk\xE7e"
    },
    {
      code: "el",
      name: "\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC"
    },
    {
      code: "be",
      name: "\u0431\u0435\u043B\u0430\u0440\u0443\u0441\u043A\u0430\u044F"
    },
    {
      code: "bg",
      name: "\u0431\u044A\u043B\u0433\u0430\u0440\u0441\u043A\u0438"
    },
    {
      code: "mk",
      name: "\u043C\u0430\u043A\u0435\u0434\u043E\u043D\u0441\u043A\u0438"
    },
    {
      code: "ru",
      name: "\u0440\u0443\u0441\u0441\u043A\u0438\u0439"
    },
    {
      code: "sr",
      name: "\u0441\u0440\u043F\u0441\u043A\u0438"
    },
    {
      code: "uk",
      name: "\u0443\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430"
    },
    {
      code: "ka",
      name: "\u10E5\u10D0\u10E0\u10D7\u10E3\u10DA\u10D8"
    },
    {
      code: "hy",
      name: "\u0570\u0561\u0575\u0565\u0580\u0565\u0576"
    },
    {
      code: "he",
      name: "\u05E2\u05D1\u05E8\u05D9\u05EA"
    },
    {
      code: "ur",
      name: "\u0627\u0631\u062F\u0648"
    },
    {
      code: "ar",
      name: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629"
    },
    {
      code: "ar-EG",
      name: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629 (\u0627\u0644\u0639\u0627\u0645\u064A\u0629 \u0627\u0644\u0645\u0635\u0631\u064A\u0629)"
    },
    {
      code: "ps",
      name: "\u067E\u069A\u062A\u0648"
    },
    {
      code: "sd",
      name: "\u0633\u0646\u068C\u064A"
    },
    {
      code: "fa",
      name: "\u0641\u0627\u0631\u0633\u06CC"
    },
    {
      code: "am",
      name: "\u12A0\u121B\u122D\u129B"
    },
    {
      code: "kok",
      name: "\u0915\u094B\u0902\u0915\u0923\u0940"
    },
    {
      code: "ne",
      name: "\u0928\u0947\u092A\u093E\u0932\u0940"
    },
    {
      code: "mr",
      name: "\u092E\u0930\u093E\u0920\u0940"
    },
    {
      code: "mai",
      name: "\u092E\u0948\u0925\u093F\u0932\u0940"
    },
    {
      code: "hi",
      name: "\u0939\u093F\u0928\u094D\u0926\u0940"
    },
    {
      code: "bn",
      name: "\u09AC\u09BE\u0982\u09B2\u09BE"
    },
    {
      code: "pa",
      name: "\u0A2A\u0A70\u0A1C\u0A3E\u0A2C\u0A40"
    },
    {
      code: "gu",
      name: "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0"
    },
    {
      code: "or",
      name: "\u0B13\u0B21\u0B3C\u0B3F\u0B06"
    },
    {
      code: "ta",
      name: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD"
    },
    {
      code: "te",
      name: "\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41"
    },
    {
      code: "kn",
      name: "\u0C95\u0CA8\u0CCD\u0CA8\u0CA1"
    },
    {
      code: "ml",
      name: "\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02"
    },
    {
      code: "si",
      name: "\u0DC3\u0DD2\u0D82\u0DC4\u0DBD"
    },
    {
      code: "th",
      name: "\u0E44\u0E17\u0E22"
    },
    {
      code: "my",
      name: "\u1019\u103C\u1014\u103A\u1019\u102C"
    },
    {
      code: "ko",
      name: "\uD55C\uAD6D\uC5B4"
    },
    {
      code: "zh-CN",
      name: "\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09"
    },
    {
      code: "zh-TW",
      name: "\u4E2D\u6587\uFF08\u7E41\u9AD4\uFF09"
    },
    {
      code: "ja",
      name: "\u65E5\u672C\u8A9E"
    }
  ];
  Ro = {
    interfaceLanguages: W1,
    outputLanguages: Y1
  };
  ht = {
    INTERFACE_FAVORITES: Pg,
    OUTPUT_FAVORITES: bg
  };
  ir = {
    INTERFACE: "interface",
    OUTPUT: "output"
  };
  Q1 = (e) => e === ir.INTERFACE ? Ro.interfaceLanguages || [] : Ro.outputLanguages || [];
  Bl = (e, t = ir.INTERFACE) => Q1(t).find((n) => n.code === e) || null;
  DE = (e) => e.name.split("(")[0].trim();
  Qp = async (e = ht.INTERFACE_FAVORITES) => {
    try {
      return await k.get(e) || [];
    } catch (t) {
      return console.error("Failed to get favorite languages:", t), [];
    }
  };
  Z1 = async (e, t = ht.INTERFACE_FAVORITES) => {
    try {
      await k.set(t, e);
    } catch (n) {
      console.error("Failed to save favorite languages:", n);
    }
  };
  UE = async (e, t = ht.INTERFACE_FAVORITES) => {
    const n = await Qp(t);
    return n.includes(e) ? false : (await Z1([
      ...n,
      e
    ], t), true);
  };
  K1 = [
    "en",
    "es",
    "fr",
    "de",
    "pt",
    "ja",
    "ko",
    "zh",
    "vi",
    "hi"
  ];
  Zp = (e = [], t = 4) => {
    var _a2, _b;
    const n = [], r = (a) => {
      if (!a || n.length >= t || n.some((s) => s.code === a))
        return;
      const o = e.find((s) => s.code === a);
      o && n.push(o);
    };
    try {
      const a = (_b = (_a2 = chrome == null ? void 0 : chrome.i18n) == null ? void 0 : _a2.getUILanguage) == null ? void 0 : _b.call(_a2);
      a && (r(a), r(a.split("-")[0]));
    } catch {
    }
    for (const a of K1)
      r(a);
    return n;
  };
  $E = Zp(Ro.interfaceLanguages);
  jE = Zp(Ro.outputLanguages);
  X1 = {
    interfaceLanguage: "en",
    outputLanguage: null,
    interfaceFavorites: [],
    outputFavorites: [],
    switcherPosition: "middle-right",
    switcherOrientation: "vertical",
    switcherVisible: true,
    switcherCollapsed: false,
    tagsVisibleHome: true,
    tagsVisibleDetail: true,
    detailOutputsVisible: true,
    detailActionsVisible: true,
    detailLogoVisible: true,
    tabBehaviorAfterImport: "both",
    openTabsInBackground: true,
    allTagsBarVisible: true,
    allTagsBarOnboardingSeen: false
  };
  q1 = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        interfaceLanguage: t
      }
    });
    try {
      await k.set(oi, t);
    } catch (r) {
      console.error("Failed to save interface language:", r);
    }
    if (!chrome.tabs) {
      const r = new URL(window.location.href);
      r.searchParams.set("hl", t), r.toString() !== window.location.href && (window.location.href = r.toString());
    } else
      chrome.tabs.query({
        url: ["*://notebooklm.google.com/*", "*://notebook.google.com/*"]
      }, (r) => {
        r.forEach((a) => {
          chrome.tabs.sendMessage(a.id, {
            type: "UPDATE_INTERFACE_LANGUAGE",
            languageCode: t
          });
        });
      });
  };
  J1 = async (e) => {
    try {
      const t = await k.get(oi);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          interfaceLanguage: t
        }
      });
    } catch (t) {
      console.error("Failed to load language settings:", t);
    }
  };
  ey = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.interfaceLanguage) || "en";
  };
  ty = async (e) => {
    var _a2;
    try {
      const t = await k.get(ya);
      t !== void 0 && t !== ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.outputLanguage) && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          outputLanguage: t
        }
      });
    } catch (t) {
      console.error("Failed to load output language:", t);
    }
  };
  ny = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        outputLanguage: t
      }
    });
    try {
      await k.set(ya, t);
    } catch (n) {
      console.error("Failed to save output language:", n);
    }
  };
  ry = (e) => {
    var _a2;
    return (_a2 = e.state.languageSettings) == null ? void 0 : _a2.outputLanguage;
  };
  hc = async (e, t, n = "interface") => {
    var _a2;
    try {
      const a = (await Qp(t)).map((i) => Bl(i, n)).filter(Boolean), o = t === ht.INTERFACE_FAVORITES ? "interfaceFavorites" : "outputFavorites", s = ((_a2 = e.state.languageSettings) == null ? void 0 : _a2[o]) || [];
      if (!(s.length !== a.length || s.some((i, c) => {
        var _a3;
        return i.code !== ((_a3 = a[c]) == null ? void 0 : _a3.code);
      })))
        return;
      e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          [o]: a
        }
      });
    } catch (r) {
      console.error("Failed to load favorite languages:", r);
    }
  };
  ay = (e) => hc(e, ht.OUTPUT_FAVORITES, ir.OUTPUT);
  oy = (e) => hc(e, ht.INTERFACE_FAVORITES, ir.INTERFACE);
  sy = (e, t = "interface") => {
    var _a2, _b;
    return t === "interface" ? ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.interfaceFavorites) || [] : ((_b = e.state.languageSettings) == null ? void 0 : _b.outputFavorites) || [];
  };
  ly = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        switcherPosition: t
      }
    });
    try {
      await k.set(si, t);
    } catch (n) {
      console.error("Failed to save switcher position:", n);
    }
  };
  iy = async (e) => {
    try {
      const t = await k.get(si);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          switcherPosition: t
        }
      });
    } catch (t) {
      console.error("Failed to load switcher position:", t);
    }
  };
  cy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.switcherPosition) || "bottom-right";
  };
  uy = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        switcherOrientation: t
      }
    });
    try {
      await k.set(li, t);
    } catch (n) {
      console.error("Failed to save switcher orientation:", n);
    }
  };
  dy = async (e) => {
    try {
      const t = await k.get(li);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          switcherOrientation: t
        }
      });
    } catch (t) {
      console.error("Failed to load switcher orientation:", t);
    }
  };
  fy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.switcherOrientation) || "horizontal";
  };
  py = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        switcherVisible: t
      }
    });
    try {
      await k.set(ii, t);
    } catch (n) {
      console.error("Failed to save switcher visibility:", n);
    }
  };
  gy = async (e) => {
    try {
      const t = await k.get(ii);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          switcherVisible: t
        }
      });
    } catch (t) {
      console.error("Failed to load switcher visibility:", t);
    }
  };
  my = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.switcherVisible) !== false;
  };
  hy = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        switcherCollapsed: t
      }
    });
    try {
      await k.set(ci, t);
    } catch (n) {
      console.error("Failed to save switcher collapsed:", n);
    }
  };
  yy = async (e) => {
    try {
      const t = await k.get(ci);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          switcherCollapsed: t
        }
      });
    } catch (t) {
      console.error("Failed to load switcher collapsed:", t);
    }
  };
  wy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.switcherCollapsed) === true;
  };
  vy = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        tagsVisibleHome: t
      }
    });
    try {
      await k.set(ui, t);
    } catch (n) {
      console.error("Failed to save home tags visibility:", n);
    }
  };
  Sy = async (e) => {
    try {
      const t = await k.get(ui);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          tagsVisibleHome: t
        }
      });
    } catch (t) {
      console.error("Failed to load home tags visibility:", t);
    }
  };
  ky = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.tagsVisibleHome) !== false;
  };
  Ey = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        tagsVisibleDetail: t
      }
    });
    try {
      await k.set(di, t);
    } catch (n) {
      console.error("Failed to save detail tags visibility:", n);
    }
  };
  Ty = async (e) => {
    try {
      const t = await k.get(di);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          tagsVisibleDetail: t
        }
      });
    } catch (t) {
      console.error("Failed to load detail tags visibility:", t);
    }
  };
  xy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.tagsVisibleDetail) !== false;
  };
  yc = (e, t, n) => ({
    set: async (r, a) => {
      r.setState({
        languageSettings: {
          ...r.state.languageSettings,
          [t]: a
        }
      });
      try {
        await k.set(e, a);
      } catch (o) {
        console.error(`Failed to save ${n} visibility:`, o);
      }
    },
    load: async (r) => {
      try {
        const a = await k.get(e);
        a !== void 0 && r.setState({
          languageSettings: {
            ...r.state.languageSettings,
            [t]: a
          }
        });
      } catch (a) {
        console.error(`Failed to load ${n} visibility:`, a);
      }
    },
    get: (r) => {
      var _a2;
      return ((_a2 = r.state.languageSettings) == null ? void 0 : _a2[t]) !== false;
    }
  });
  Kp = yc(hd, "detailOutputsVisible", "outputs");
  Xp = yc(yd, "detailActionsVisible", "actions");
  wc = yc(wd, "detailLogoVisible", "logo");
  Ay = Kp.set;
  My = Kp.load;
  Cy = Xp.set;
  Ny = Xp.load;
  Py = wc.set;
  by = wc.load;
  Ly = (e) => !ss(e) || wc.get(e);
  _y = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        tabBehaviorAfterImport: t
      }
    });
    try {
      await k.set(fi, t);
    } catch (n) {
      console.error("Failed to save tab behavior setting:", n);
    }
  };
  Ry = async (e) => {
    try {
      const t = await k.get(fi);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          tabBehaviorAfterImport: t
        }
      });
    } catch (t) {
      console.error("Failed to load tab behavior setting:", t);
    }
  };
  Oy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.tabBehaviorAfterImport) || "both";
  };
  Fy = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        openTabsInBackground: t
      }
    });
    try {
      await k.set(pi, t);
    } catch (n) {
      console.error("Failed to save open tabs in background setting:", n);
    }
  };
  Iy = async (e) => {
    try {
      const t = await k.get(pi);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          openTabsInBackground: t
        }
      });
    } catch (t) {
      console.error("Failed to load open tabs in background setting:", t);
    }
  };
  Dy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.openTabsInBackground) !== false;
  };
  Uy = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        allTagsBarVisible: t
      }
    });
    try {
      await k.set(gi, t);
    } catch (n) {
      console.error("Failed to save all tags bar visibility:", n);
    }
  };
  $y = async (e) => {
    try {
      const t = await k.get(gi);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          allTagsBarVisible: t
        }
      });
    } catch (t) {
      console.error("Failed to load all tags bar visibility:", t);
    }
  };
  jy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.allTagsBarVisible) !== false;
  };
  zy = async (e, t) => {
    e.setState({
      languageSettings: {
        ...e.state.languageSettings,
        allTagsBarOnboardingSeen: t
      }
    });
    try {
      await k.set(mi, t);
    } catch (n) {
      console.error("Failed to save all tags bar onboarding seen:", n);
    }
  };
  By = async (e) => {
    try {
      const t = await k.get(mi);
      t !== void 0 && e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          allTagsBarOnboardingSeen: t
        }
      });
    } catch (t) {
      console.error("Failed to load all tags bar onboarding seen:", t);
    }
  };
  Vy = (e) => {
    var _a2;
    return ((_a2 = e.state.languageSettings) == null ? void 0 : _a2.allTagsBarOnboardingSeen) === true;
  };
  ed = [
    [
      oi,
      "interfaceLanguage"
    ],
    [
      ya,
      "outputLanguage"
    ],
    [
      si,
      "switcherPosition"
    ],
    [
      ii,
      "switcherVisible"
    ],
    [
      li,
      "switcherOrientation"
    ],
    [
      ci,
      "switcherCollapsed"
    ],
    [
      ui,
      "tagsVisibleHome"
    ],
    [
      di,
      "tagsVisibleDetail"
    ],
    [
      hd,
      "detailOutputsVisible"
    ],
    [
      yd,
      "detailActionsVisible"
    ],
    [
      wd,
      "detailLogoVisible"
    ],
    [
      fi,
      "tabBehaviorAfterImport"
    ],
    [
      pi,
      "openTabsInBackground"
    ],
    [
      gi,
      "allTagsBarVisible"
    ],
    [
      mi,
      "allTagsBarOnboardingSeen"
    ]
  ];
  Hy = async (e) => {
    try {
      const t = await k.getKeys([
        ...ed.map(([r]) => r),
        ht.INTERFACE_FAVORITES,
        ht.OUTPUT_FAVORITES
      ]), n = {};
      for (const [r, a] of ed)
        t[r] !== void 0 && (n[a] = t[r]);
      n.interfaceFavorites = (t[ht.INTERFACE_FAVORITES] || []).map((r) => Bl(r, ir.INTERFACE)).filter(Boolean), n.outputFavorites = (t[ht.OUTPUT_FAVORITES] || []).map((r) => Bl(r, ir.OUTPUT)).filter(Boolean), e.setState({
        languageSettings: {
          ...e.state.languageSettings,
          ...n
        }
      });
    } catch (t) {
      console.error("Failed to load language preferences:", t);
    }
  };
  Gy = "modulepreload";
  Wy = function(e) {
    return "/" + e;
  };
  td = {};
  vc = function(t, n, r) {
    if (!n || n.length === 0)
      return t();
    const a = document.getElementsByTagName("link");
    return Promise.all(n.map((o) => {
      if (o = Wy(o), o in td)
        return;
      td[o] = true;
      const s = o.endsWith(".css"), l = s ? '[rel="stylesheet"]' : "";
      if (!!r)
        for (let u = a.length - 1; u >= 0; u--) {
          const p = a[u];
          if (p.href === o && (!s || p.rel === "stylesheet"))
            return;
        }
      else if (document.querySelector(`link[href="${o}"]${l}`))
        return;
      const c = document.createElement("link");
      if (c.rel = s ? "stylesheet" : Gy, s || (c.as = "script", c.crossOrigin = ""), c.href = o, document.head.appendChild(c), s)
        return new Promise((u, p) => {
          c.addEventListener("load", u), c.addEventListener("error", () => p(new Error(`Unable to preload CSS for ${o}`)));
        });
    })).then(() => t()).catch((o) => {
      const s = new Event("vite:preloadError", {
        cancelable: true
      });
      if (s.payload = o, window.dispatchEvent(s), !s.defaultPrevented)
        throw o;
    });
  };
  me = (e, t, n) => {
    let r = false;
    return async (a) => {
      if (!r && !(a === 403 || a === 7)) {
        r = true;
        try {
          try {
            n && n();
          } catch (o) {
            console.warn("onCancel failed:", o == null ? void 0 : o.message);
          }
          t ? await mc(e, t) : await Yp(e), await e0(e), Lg();
        } finally {
          r = false;
        }
      }
    };
  };
  qp = (e) => e && e.replace(/[<>:"/\\|?*]/g, "-").replace(/\s+/g, " ").trim().slice(0, 100) || "Untitled";
  Yy = (e) => {
    var _a2, _b;
    const t = e.split(`
`);
    let n = null, r = 0;
    if ((_a2 = t[0]) == null ? void 0 : _a2.startsWith("> Source:")) {
      const o = t[0].match(/^> Source:\s*(.+)$/);
      o && (n = o[1].trim(), r = 1, ((_b = t[1]) == null ? void 0 : _b.trim()) === "" && (r = 2));
    }
    const a = t.slice(r).join(`
`);
    return {
      url: n,
      body: a
    };
  };
  Qy = (e) => {
    let t = e.replace(/\.md$/i, "");
    return t = t.replace(/^\d+-/, ""), t.trim() || "Untitled";
  };
  ve = (e) => {
    const t = $(e.state);
    if (!(t == null ? void 0 : t.token))
      return {
        auth: null,
        client: null
      };
    const n = new ge(t.token, {
      ...t,
      onAuthError: me(e, t.email)
    });
    return {
      auth: t,
      client: n
    };
  };
  Zy = async () => {
    try {
      return await k.get(hi) || [];
    } catch {
      return [];
    }
  };
  Ky = {
    projects: await Zy(),
    hasInitialized: false,
    selectedProject: null,
    selectedBatchProject: null,
    query: "",
    batchQuery: ""
  };
  Jp = async (e, t) => {
    const { notebooklm: n } = e.state, r = {
      notebooklm: {
        ...n,
        projects: t,
        selectedProject: n.selectedProject || t[0] || null,
        selectedBatchProject: n.selectedBatchProject || t[0] || null
      }
    };
    await e.setState(r), await k.set(hi, t);
  };
  e0 = async (e) => {
    await e.setState({
      notebooklm: {
        ...e.state.notebooklm,
        projects: [],
        hasInitialized: false,
        selectedProject: null,
        selectedBatchProject: null
      }
    }), await k.set(hi, []);
  };
  Ta = async (e) => {
    const { auth: t, client: n } = ve(e);
    if (!n)
      return [];
    const r = await n.listNotebooks(), a = ce.parseNotebooks(r);
    return await Jp(e, a), await e.setState({
      notebooklm: {
        ...e.state.notebooklm,
        hasInitialized: true
      }
    }), a;
  };
  Xy = async (e, t = "") => {
    var _a2;
    const { client: n } = ve(e);
    return n ? ((_a2 = await n.createNotebook(t)) == null ? void 0 : _a2[2]) ?? null : null;
  };
  qy = async (e, t) => {
    const { client: n } = ve(e);
    n && await n.deleteNotebook(t);
  };
  Jy = async (e, t, n) => {
    const { client: r } = ve(e);
    r && await r.deleteSource(t, n);
  };
  ew = async (e, t, n, r) => {
    const { client: a } = ve(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    return a.mutateSource(t, n, r);
  };
  tw = async (e, t, n) => {
    const { client: r } = ve(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    return r.mutateProject(t, n);
  };
  Vl = async (e, t, n) => {
    const { client: r } = ve(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    return r.refreshSource(t, n);
  };
  Sc = async (e, t, n) => {
    const { client: r } = ve(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    return r.checkSourceFreshness(t, n);
  };
  nw = async (e, t, n) => {
    const { client: r } = ve(e);
    r && await r.addSource(t, n);
  };
  rw = async (e, t) => {
    await e.setState({
      notebooklm: {
        ...e.state.notebooklm,
        selectedProject: t
      }
    });
  };
  aw = async (e, t) => {
    await e.setState({
      notebooklm: {
        ...e.state.notebooklm,
        selectedBatchProject: t
      }
    });
  };
  ow = async (e, t) => {
    await e.setState({
      notebooklm: {
        ...e.state.notebooklm,
        query: t
      }
    });
  };
  sw = async (e, t) => {
    await e.setState({
      notebooklm: {
        ...e.state.notebooklm,
        batchQuery: t
      }
    });
  };
  lw = async (e) => {
    const { notebooklm: t } = e.state, n = $(e.state);
    !t.hasInitialized && (n == null ? void 0 : n.token) && await Ta(e);
  };
  iw = async (e, t) => {
    const { client: n } = ve(e);
    if (!n)
      throw new Error("Not authenticated to NotebookLM");
    await n.changeOutputLanguage(t), await k.set(ya, t);
  };
  cw = async (e, t, n) => {
    const { client: r } = ve(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    const a = await r.loadSource(t, n);
    return ce.parseSourceContent(a);
  };
  uw = async (e, t, n) => {
    var _a2, _b;
    const { client: r } = ve(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    const a = (_b = (_a2 = e.state.notebooklm) == null ? void 0 : _a2.projects) == null ? void 0 : _b.find((u) => u.id === t);
    if (!a)
      throw new Error("Notebook not found");
    const o = a.sources || [], s = new Array(o.length), l = 3;
    let i = 0;
    for (let u = 0; u < o.length; u += l) {
      const p = o.slice(u, u + l);
      (await Promise.allSettled(p.map(async (d, w) => {
        const y = u + w;
        try {
          const S = await r.loadSource(d.id, t), g = ce.parseSourceContent(S);
          return {
            originalIndex: y,
            data: {
              id: d.id,
              title: d.title,
              url: d.url,
              sourceType: d.sourceType,
              content: (g == null ? void 0 : g.content) || ""
            }
          };
        } catch (S) {
          return console.warn(`Failed to export source ${d.id}:`, S), {
            originalIndex: y,
            data: {
              id: d.id,
              title: d.title,
              url: d.url,
              sourceType: d.sourceType,
              content: "",
              error: S.message
            }
          };
        }
      }))).forEach((d) => {
        i++, d.status === "fulfilled" && (s[d.value.originalIndex] = d.value.data);
      }), n && n({
        current: i,
        total: o.length
      });
    }
    return {
      version: "1.0",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      notebook: {
        id: a.id,
        title: a.title,
        emoji: a.emoji
      },
      sources: s
    };
  };
  dw = async (e, t, n, r) => {
    const { client: a } = ve(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    if (!(n == null ? void 0 : n.sources) || !Array.isArray(n.sources))
      throw new Error("Invalid import data");
    const o = {
      success: 0,
      failed: 0,
      errors: []
    }, s = n.sources, l = 3;
    let i = 0;
    for (let c = 0; c < s.length; c += l) {
      const u = s.slice(c, c + l);
      (await Promise.allSettled(u.map(async (f) => f.content && f.content.trim() ? (await a.pastedTextToSource(`# ${f.title}

${f.url ? `**Source:** ${f.url}

---

` : ""}${f.content}`, t, f.title || "Imported Source"), {
        success: true,
        title: f.title
      }) : f.url ? (await a.addUrlsToSource([
        f.url
      ], t), {
        success: true,
        title: f.title
      }) : {
        success: false,
        title: f.title,
        error: "No content or URL"
      }))).forEach((f) => {
        var _a2, _b;
        if (i++, f.status === "fulfilled" && f.value.success)
          o.success++;
        else {
          o.failed++;
          const d = f.status === "rejected" ? (_a2 = f.reason) == null ? void 0 : _a2.message : ((_b = f.value) == null ? void 0 : _b.error) || "Unknown error", w = f.status === "fulfilled" ? f.value.title : "Unknown source";
          o.errors.push({
            source: w,
            error: d
          });
        }
      }), r && r({
        current: i,
        total: s.length
      });
    }
    return o;
  };
  Va = 49e4;
  fw = /* @__PURE__ */ new Set([
    Ht.GOOGLE_SLIDES,
    Ht.IMAGE,
    Ht.VIDEO_FILE,
    Ht.MIND_MAP_NOTE
  ]);
  t0 = /* @__PURE__ */ new Set([
    Ht.URL,
    Ht.WEB_PAGE,
    Ht.YOUTUBE_VIDEO,
    Ht.PDF
  ]);
  pw = (e) => {
    const t = [], n = [], r = [];
    for (const a of e)
      a.url && t0.has(a.sourceType) ? t.push(a) : fw.has(a.sourceType) ? r.push(a) : n.push(a);
    return {
      fullCopy: t,
      textOnly: n,
      nonCopyable: r
    };
  };
  gw = async (e, t, n, r, a) => {
    const { client: o } = ve(e);
    if (!o)
      throw new Error("Not authenticated to NotebookLM");
    const { fullCopy: s, textOnly: l, nonCopyable: i } = pw(r), c = [
      ...s,
      ...l
    ], u = {
      success: 0,
      failed: 0,
      skipped: i.length,
      errors: []
    }, p = 3;
    let f = 0;
    const d = c.length;
    a && a({
      current: 0,
      total: d,
      skipped: u.skipped
    });
    const w = (y) => {
      f++, y.success ? u.success++ : (u.failed++, u.errors.push({
        id: y.id,
        source: y.title,
        error: y.error || "Unknown error"
      })), a && a({
        current: f,
        total: d,
        skipped: u.skipped
      });
    };
    for (let y = 0; y < c.length; y += p) {
      const S = c.slice(y, y + p);
      await Promise.allSettled(S.map(async (g) => {
        var _a2;
        try {
          if (g.youtubeVideoId) {
            await o.addSource(g.youtubeVideoId, n), w({
              success: true,
              id: g.id,
              title: g.title
            });
            return;
          }
          if (g.url && t0.has(g.sourceType)) {
            await o.addUrlsToSource([
              g.url
            ], n), w({
              success: true,
              id: g.id,
              title: g.title
            });
            return;
          }
          const m = await o.loadSource(g.id, t), v = ((_a2 = ce.parseSourceContent(m)) == null ? void 0 : _a2.content) || "";
          if (!v.trim()) {
            w({
              success: false,
              id: g.id,
              title: g.title,
              error: "Empty content"
            });
            return;
          }
          const A = g.title || "Copied Source";
          if (v.length <= Va)
            await o.pastedTextToSource(v, n, A);
          else
            for (let T = 0; T < v.length; T += Va) {
              const N = v.slice(T, T + Va), L = `${A} (${Math.floor(T / Va) + 1})`;
              await o.pastedTextToSource(N, n, L);
            }
          w({
            success: true,
            id: g.id,
            title: g.title
          });
        } catch (m) {
          w({
            success: false,
            id: g.id,
            title: g.title,
            error: m == null ? void 0 : m.message
          });
        }
      }));
    }
    return u;
  };
  mw = async (e, t, n) => {
    var _a2, _b;
    const { client: r } = ve(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    const a = (_b = (_a2 = e.state.notebooklm) == null ? void 0 : _a2.projects) == null ? void 0 : _b.find((p) => p.id === t);
    if (!a)
      throw new Error("Notebook not found");
    const o = a.sources || [], { default: s } = await vc(() => import("./chunk-d45ab30c.js").then((p) => p.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), l = new s(), i = 3;
    let c = 0;
    for (let p = 0; p < o.length; p += i) {
      const f = o.slice(p, p + i);
      (await Promise.allSettled(f.map(async (w, y) => {
        var _a3;
        const S = p + y;
        try {
          const g = await r.loadSource(w.id, t), h = ((_a3 = ce.parseSourceContent(g)) == null ? void 0 : _a3.content) || "";
          let v = "";
          return w.url && (v += `> Source: ${w.url}

`), v += h, {
            originalIndex: S,
            source: w,
            mdContent: v,
            success: true
          };
        } catch (g) {
          return console.warn(`Failed to export source ${w.id}:`, g), {
            originalIndex: S,
            source: w,
            mdContent: `> Error: Failed to load source content

`,
            success: false
          };
        }
      }))).forEach((w) => {
        if (c++, w.status === "fulfilled") {
          const { originalIndex: y, source: S, mdContent: g } = w.value, m = qp(S.title), h = `${y + 1}-${m}.md`;
          l.file(h, g);
        }
      }), n && n({
        current: c,
        total: o.length
      });
    }
    return {
      blob: await l.generateAsync({
        type: "blob"
      }),
      notebook: {
        id: a.id,
        title: a.title,
        emoji: a.emoji
      },
      sourceCount: o.length
    };
  };
  hw = async (e, t, n, r) => {
    const { client: a } = ve(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    if (!(n == null ? void 0 : n.length))
      throw new Error("No sources selected");
    const { default: o } = await vc(() => import("./chunk-d45ab30c.js").then((u) => u.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), s = new o(), l = 3;
    let i = 0;
    for (let u = 0; u < n.length; u += l) {
      const p = n.slice(u, u + l);
      (await Promise.allSettled(p.map(async (d, w) => {
        var _a2;
        const y = u + w;
        try {
          const S = await a.loadSource(d.id, t), m = ((_a2 = ce.parseSourceContent(S)) == null ? void 0 : _a2.content) || "";
          let h = "";
          return d.url && (h += `> Source: ${d.url}

`), h += m, {
            originalIndex: y,
            source: d,
            mdContent: h,
            success: true
          };
        } catch (S) {
          return console.warn(`Failed to export source ${d.id}:`, S), {
            originalIndex: y,
            source: d,
            mdContent: `> Error: Failed to load source content

`,
            success: false
          };
        }
      }))).forEach((d) => {
        if (i++, d.status === "fulfilled") {
          const { originalIndex: w, source: y, mdContent: S } = d.value, g = qp(y.title), m = `${w + 1}-${g}.md`;
          s.file(m, S);
        }
      }), r && r({
        current: i,
        total: n.length
      });
    }
    return {
      blob: await s.generateAsync({
        type: "blob"
      }),
      sourceCount: n.length
    };
  };
  yw = async (e, t, n, r) => {
    const { client: a } = ve(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    const { default: o } = await vc(() => import("./chunk-d45ab30c.js").then((f) => f.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), s = await o.loadAsync(n), l = Object.keys(s.files).filter((f) => f.endsWith(".md") && !s.files[f].dir).sort((f, d) => {
      const w = parseInt(f.split("-")[0], 10) || 0, y = parseInt(d.split("-")[0], 10) || 0;
      return w - y;
    }), i = {
      success: 0,
      failed: 0,
      errors: []
    }, c = l.length, u = 3;
    let p = 0;
    for (let f = 0; f < l.length; f += u) {
      const d = l.slice(f, f + u);
      (await Promise.allSettled(d.map(async (y) => {
        const S = await s.files[y].async("string");
        if (!S || !S.trim())
          return {
            success: false,
            filename: y,
            error: "Empty content"
          };
        const { body: g } = Yy(S), m = Qy(y);
        return g && g.trim() ? (await a.pastedTextToSource(g, t, m), {
          success: true,
          filename: y
        }) : {
          success: false,
          filename: y,
          error: "No content after parsing"
        };
      }))).forEach((y) => {
        var _a2, _b;
        if (p++, y.status === "fulfilled" && y.value.success)
          i.success++;
        else {
          i.failed++;
          const S = y.status === "rejected" ? (_a2 = y.reason) == null ? void 0 : _a2.message : ((_b = y.value) == null ? void 0 : _b.error) || "Unknown error", g = y.status === "fulfilled" ? y.value.filename : "Unknown file";
          i.errors.push({
            source: g,
            error: S
          });
        }
      }), r && r({
        current: p,
        total: c
      });
    }
    return i;
  };
  let ww, vw, Sw, kw, Ew, Tw, xw, Aw, Mw, Hl, Cw, _e, Nw, Pw, bw, Lw, _w;
  ww = (e) => {
    switch (e) {
      case "success":
        return kw;
      case "info":
        return Tw;
      case "warning":
        return Ew;
      case "error":
        return xw;
      default:
        return null;
    }
  };
  vw = Array(12).fill(0);
  Sw = ({ visible: e, className: t }) => M.createElement("div", {
    className: [
      "sonner-loading-wrapper",
      t
    ].filter(Boolean).join(" "),
    "data-visible": e
  }, M.createElement("div", {
    className: "sonner-spinner"
  }, vw.map((n, r) => M.createElement("div", {
    className: "sonner-loading-bar",
    key: `spinner-bar-${r}`
  }))));
  kw = M.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 20 20",
    fill: "currentColor",
    height: "20",
    width: "20"
  }, M.createElement("path", {
    fillRule: "evenodd",
    d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",
    clipRule: "evenodd"
  }));
  Ew = M.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    height: "20",
    width: "20"
  }, M.createElement("path", {
    fillRule: "evenodd",
    d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",
    clipRule: "evenodd"
  }));
  Tw = M.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 20 20",
    fill: "currentColor",
    height: "20",
    width: "20"
  }, M.createElement("path", {
    fillRule: "evenodd",
    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",
    clipRule: "evenodd"
  }));
  xw = M.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 20 20",
    fill: "currentColor",
    height: "20",
    width: "20"
  }, M.createElement("path", {
    fillRule: "evenodd",
    d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",
    clipRule: "evenodd"
  }));
  Aw = M.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, M.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), M.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }));
  Mw = () => {
    let [e, t] = M.useState(document.hidden);
    return M.useEffect(() => {
      let n = () => {
        t(document.hidden);
      };
      return document.addEventListener("visibilitychange", n), () => window.removeEventListener("visibilitychange", n);
    }, []), e;
  };
  Hl = 1;
  Cw = class {
    constructor() {
      this.subscribe = (e) => (this.subscribers.push(e), () => {
        let t = this.subscribers.indexOf(e);
        this.subscribers.splice(t, 1);
      }), this.publish = (e) => {
        this.subscribers.forEach((t) => t(e));
      }, this.addToast = (e) => {
        this.publish(e), this.toasts = [
          ...this.toasts,
          e
        ];
      }, this.create = (e) => {
        var t;
        let { message: n, ...r } = e, a = typeof (e == null ? void 0 : e.id) == "number" || ((t = e.id) == null ? void 0 : t.length) > 0 ? e.id : Hl++, o = this.toasts.find((l) => l.id === a), s = e.dismissible === void 0 ? true : e.dismissible;
        return this.dismissedToasts.has(a) && this.dismissedToasts.delete(a), o ? this.toasts = this.toasts.map((l) => l.id === a ? (this.publish({
          ...l,
          ...e,
          id: a,
          title: n
        }), {
          ...l,
          ...e,
          id: a,
          dismissible: s,
          title: n
        }) : l) : this.addToast({
          title: n,
          ...r,
          dismissible: s,
          id: a
        }), a;
      }, this.dismiss = (e) => (this.dismissedToasts.add(e), e || this.toasts.forEach((t) => {
        this.subscribers.forEach((n) => n({
          id: t.id,
          dismiss: true
        }));
      }), this.subscribers.forEach((t) => t({
        id: e,
        dismiss: true
      })), e), this.message = (e, t) => this.create({
        ...t,
        message: e
      }), this.error = (e, t) => this.create({
        ...t,
        message: e,
        type: "error"
      }), this.success = (e, t) => this.create({
        ...t,
        type: "success",
        message: e
      }), this.info = (e, t) => this.create({
        ...t,
        type: "info",
        message: e
      }), this.warning = (e, t) => this.create({
        ...t,
        type: "warning",
        message: e
      }), this.loading = (e, t) => this.create({
        ...t,
        type: "loading",
        message: e
      }), this.promise = (e, t) => {
        if (!t)
          return;
        let n;
        t.loading !== void 0 && (n = this.create({
          ...t,
          promise: e,
          type: "loading",
          message: t.loading,
          description: typeof t.description != "function" ? t.description : void 0
        }));
        let r = e instanceof Promise ? e : e(), a = n !== void 0, o, s = r.then(async (i) => {
          if (o = [
            "resolve",
            i
          ], M.isValidElement(i))
            a = false, this.create({
              id: n,
              type: "default",
              message: i
            });
          else if (Pw(i) && !i.ok) {
            a = false;
            let c = typeof t.error == "function" ? await t.error(`HTTP error! status: ${i.status}`) : t.error, u = typeof t.description == "function" ? await t.description(`HTTP error! status: ${i.status}`) : t.description;
            this.create({
              id: n,
              type: "error",
              message: c,
              description: u
            });
          } else if (t.success !== void 0) {
            a = false;
            let c = typeof t.success == "function" ? await t.success(i) : t.success, u = typeof t.description == "function" ? await t.description(i) : t.description;
            this.create({
              id: n,
              type: "success",
              message: c,
              description: u
            });
          }
        }).catch(async (i) => {
          if (o = [
            "reject",
            i
          ], t.error !== void 0) {
            a = false;
            let c = typeof t.error == "function" ? await t.error(i) : t.error, u = typeof t.description == "function" ? await t.description(i) : t.description;
            this.create({
              id: n,
              type: "error",
              message: c,
              description: u
            });
          }
        }).finally(() => {
          var i;
          a && (this.dismiss(n), n = void 0), (i = t.finally) == null || i.call(t);
        }), l = () => new Promise((i, c) => s.then(() => o[0] === "reject" ? c(o[1]) : i(o[1])).catch(c));
        return typeof n != "string" && typeof n != "number" ? {
          unwrap: l
        } : Object.assign(n, {
          unwrap: l
        });
      }, this.custom = (e, t) => {
        let n = (t == null ? void 0 : t.id) || Hl++;
        return this.create({
          jsx: e(n),
          id: n,
          ...t
        }), n;
      }, this.getActiveToasts = () => this.toasts.filter((e) => !this.dismissedToasts.has(e.id)), this.subscribers = [], this.toasts = [], this.dismissedToasts = /* @__PURE__ */ new Set();
    }
  };
  _e = new Cw();
  Nw = (e, t) => {
    let n = (t == null ? void 0 : t.id) || Hl++;
    return _e.addToast({
      title: e,
      ...t,
      id: n
    }), n;
  };
  Pw = (e) => e && typeof e == "object" && "ok" in e && typeof e.ok == "boolean" && "status" in e && typeof e.status == "number";
  bw = Nw;
  Lw = () => _e.toasts;
  _w = () => _e.getActiveToasts();
  B = Object.assign(bw, {
    success: _e.success,
    info: _e.info,
    warning: _e.warning,
    error: _e.error,
    custom: _e.custom,
    message: _e.message,
    promise: _e.promise,
    dismiss: _e.dismiss,
    loading: _e.loading
  }, {
    getHistory: Lw,
    getToasts: _w
  });
  function Rw(e, { insertAt: t } = {}) {
    if (!e || typeof document > "u")
      return;
    let n = document.head || document.getElementsByTagName("head")[0], r = document.createElement("style");
    r.type = "text/css", t === "top" && n.firstChild ? n.insertBefore(r, n.firstChild) : n.appendChild(r), r.styleSheet ? r.styleSheet.cssText = e : r.appendChild(document.createTextNode(e));
  }
  Rw(`:where(html[dir="ltr"]),:where([data-sonner-toaster][dir="ltr"]){--toast-icon-margin-start: -3px;--toast-icon-margin-end: 4px;--toast-svg-margin-start: -1px;--toast-svg-margin-end: 0px;--toast-button-margin-start: auto;--toast-button-margin-end: 0;--toast-close-button-start: 0;--toast-close-button-end: unset;--toast-close-button-transform: translate(-35%, -35%)}:where(html[dir="rtl"]),:where([data-sonner-toaster][dir="rtl"]){--toast-icon-margin-start: 4px;--toast-icon-margin-end: -3px;--toast-svg-margin-start: 0px;--toast-svg-margin-end: -1px;--toast-button-margin-start: 0;--toast-button-margin-end: auto;--toast-close-button-start: unset;--toast-close-button-end: 0;--toast-close-button-transform: translate(35%, -35%)}:where([data-sonner-toaster]){position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1: hsl(0, 0%, 99%);--gray2: hsl(0, 0%, 97.3%);--gray3: hsl(0, 0%, 95.1%);--gray4: hsl(0, 0%, 93%);--gray5: hsl(0, 0%, 90.9%);--gray6: hsl(0, 0%, 88.7%);--gray7: hsl(0, 0%, 85.8%);--gray8: hsl(0, 0%, 78%);--gray9: hsl(0, 0%, 56.1%);--gray10: hsl(0, 0%, 52.3%);--gray11: hsl(0, 0%, 43.5%);--gray12: hsl(0, 0%, 9%);--border-radius: 8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:none;z-index:999999999;transition:transform .4s ease}:where([data-sonner-toaster][data-lifted="true"]){transform:translateY(-10px)}@media (hover: none) and (pointer: coarse){:where([data-sonner-toaster][data-lifted="true"]){transform:none}}:where([data-sonner-toaster][data-x-position="right"]){right:var(--offset-right)}:where([data-sonner-toaster][data-x-position="left"]){left:var(--offset-left)}:where([data-sonner-toaster][data-x-position="center"]){left:50%;transform:translate(-50%)}:where([data-sonner-toaster][data-y-position="top"]){top:var(--offset-top)}:where([data-sonner-toaster][data-y-position="bottom"]){bottom:var(--offset-bottom)}:where([data-sonner-toast]){--y: translateY(100%);--lift-amount: calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);filter:blur(0);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:none;overflow-wrap:anywhere}:where([data-sonner-toast][data-styled="true"]){padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px #0000001a;width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}:where([data-sonner-toast]:focus-visible){box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast][data-y-position="top"]){top:0;--y: translateY(-100%);--lift: 1;--lift-amount: calc(1 * var(--gap))}:where([data-sonner-toast][data-y-position="bottom"]){bottom:0;--y: translateY(100%);--lift: -1;--lift-amount: calc(var(--lift) * var(--gap))}:where([data-sonner-toast]) :where([data-description]){font-weight:400;line-height:1.4;color:inherit}:where([data-sonner-toast]) :where([data-title]){font-weight:500;line-height:1.5;color:inherit}:where([data-sonner-toast]) :where([data-icon]){display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}:where([data-sonner-toast][data-promise="true"]) :where([data-icon])>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}:where([data-sonner-toast]) :where([data-icon])>*{flex-shrink:0}:where([data-sonner-toast]) :where([data-icon]) svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}:where([data-sonner-toast]) :where([data-content]){display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;cursor:pointer;outline:none;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}:where([data-sonner-toast]) :where([data-button]):focus-visible{box-shadow:0 0 0 2px #0006}:where([data-sonner-toast]) :where([data-button]):first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}:where([data-sonner-toast]) :where([data-cancel]){color:var(--normal-text);background:rgba(0,0,0,.08)}:where([data-sonner-toast][data-theme="dark"]) :where([data-cancel]){background:rgba(255,255,255,.3)}:where([data-sonner-toast]) :where([data-close-button]){position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast] [data-close-button]{background:var(--gray1)}:where([data-sonner-toast]) :where([data-close-button]):focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast]) :where([data-disabled="true"]){cursor:not-allowed}:where([data-sonner-toast]):hover :where([data-close-button]):hover{background:var(--gray2);border-color:var(--gray5)}:where([data-sonner-toast][data-swiping="true"]):before{content:"";position:absolute;left:-50%;right:-50%;height:100%;z-index:-1}:where([data-sonner-toast][data-y-position="top"][data-swiping="true"]):before{bottom:50%;transform:scaleY(3) translateY(50%)}:where([data-sonner-toast][data-y-position="bottom"][data-swiping="true"]):before{top:50%;transform:scaleY(3) translateY(-50%)}:where([data-sonner-toast][data-swiping="false"][data-removed="true"]):before{content:"";position:absolute;inset:0;transform:scaleY(2)}:where([data-sonner-toast]):after{content:"";position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}:where([data-sonner-toast][data-mounted="true"]){--y: translateY(0);opacity:1}:where([data-sonner-toast][data-expanded="false"][data-front="false"]){--scale: var(--toasts-before) * .05 + 1;--y: translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}:where([data-sonner-toast])>*{transition:opacity .4s}:where([data-sonner-toast][data-expanded="false"][data-front="false"][data-styled="true"])>*{opacity:0}:where([data-sonner-toast][data-visible="false"]){opacity:0;pointer-events:none}:where([data-sonner-toast][data-mounted="true"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}:where([data-sonner-toast][data-removed="true"][data-front="true"][data-swipe-out="false"]){--y: translateY(calc(var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="false"]){--y: translateY(40%);opacity:0;transition:transform .5s,opacity .2s}:where([data-sonner-toast][data-removed="true"][data-front="false"]):before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y, 0px)) translate(var(--swipe-amount-x, 0px));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width: 600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-theme=light]{--normal-bg: #fff;--normal-border: var(--gray4);--normal-text: var(--gray12);--success-bg: hsl(143, 85%, 96%);--success-border: hsl(145, 92%, 91%);--success-text: hsl(140, 100%, 27%);--info-bg: hsl(208, 100%, 97%);--info-border: hsl(221, 91%, 91%);--info-text: hsl(210, 92%, 45%);--warning-bg: hsl(49, 100%, 97%);--warning-border: hsl(49, 91%, 91%);--warning-text: hsl(31, 92%, 45%);--error-bg: hsl(359, 100%, 97%);--error-border: hsl(359, 100%, 94%);--error-text: hsl(360, 100%, 45%)}[data-sonner-toaster][data-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg: #fff;--normal-border: var(--gray3);--normal-text: var(--gray12)}[data-sonner-toaster][data-theme=dark]{--normal-bg: #000;--normal-bg-hover: hsl(0, 0%, 12%);--normal-border: hsl(0, 0%, 20%);--normal-border-hover: hsl(0, 0%, 25%);--normal-text: var(--gray1);--success-bg: hsl(150, 100%, 6%);--success-border: hsl(147, 100%, 12%);--success-text: hsl(150, 86%, 65%);--info-bg: hsl(215, 100%, 6%);--info-border: hsl(223, 100%, 12%);--info-text: hsl(216, 87%, 65%);--warning-bg: hsl(64, 100%, 6%);--warning-border: hsl(60, 100%, 12%);--warning-text: hsl(46, 87%, 65%);--error-bg: hsl(358, 76%, 10%);--error-border: hsl(357, 89%, 16%);--error-text: hsl(358, 100%, 81%)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success],[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info],[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning],[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error],[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size: 16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:nth-child(1){animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}to{opacity:.15}}@media (prefers-reduced-motion){[data-sonner-toast],[data-sonner-toast]>*,.sonner-loading-bar{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}
`);
  function Ha(e) {
    return e.label !== void 0;
  }
  var Ow = 3, Fw = "32px", Iw = "16px", nd = 4e3, Dw = 356, Uw = 14, $w = 20, jw = 200;
  function rt(...e) {
    return e.filter(Boolean).join(" ");
  }
  function zw(e) {
    let [t, n] = e.split("-"), r = [];
    return t && r.push(t), n && r.push(n), r;
  }
  var Bw = (e) => {
    var t, n, r, a, o, s, l, i, c, u, p;
    let { invert: f, toast: d, unstyled: w, interacting: y, setHeights: S, visibleToasts: g, heights: m, index: h, toasts: v, expanded: A, removeToast: T, defaultRichColors: N, closeButton: L, style: W, cancelButtonStyle: I, actionButtonStyle: Se, className: Ae = "", descriptionClassName: dt = "", duration: kt, position: Nn, gap: qe, loadingIcon: Ue, expandByDefault: P, classNames: C, icons: _, closeButtonAriaLabel: Z = "Close toast", pauseWhenPageIsHidden: R } = e, [z, j] = M.useState(null), [de, Le] = M.useState(null), [G, us] = M.useState(false), [vr, xa] = M.useState(false), [Sr, ds] = M.useState(false), [Fc, mg] = M.useState(false), [hg, Ic] = M.useState(false), [yg, fs] = M.useState(0), [wg, Dc] = M.useState(0), kr = M.useRef(d.duration || kt || nd), Uc = M.useRef(null), cn = M.useRef(null), vg = h === 0, Sg = h + 1 <= g, Ge = d.type, Pn = d.dismissible !== false, kg = d.className || "", Eg = d.descriptionClassName || "", Aa = M.useMemo(() => m.findIndex((F) => F.toastId === d.id) || 0, [
      m,
      d.id
    ]), Tg = M.useMemo(() => {
      var F;
      return (F = d.closeButton) != null ? F : L;
    }, [
      d.closeButton,
      L
    ]), $c = M.useMemo(() => d.duration || kt || nd, [
      d.duration,
      kt
    ]), ps = M.useRef(0), bn = M.useRef(0), jc = M.useRef(0), Ln = M.useRef(null), [xg, Ag] = Nn.split("-"), zc = M.useMemo(() => m.reduce((F, H, q) => q >= Aa ? F : F + H.height, 0), [
      m,
      Aa
    ]), Bc = Mw(), Mg = d.invert || f, gs = Ge === "loading";
    bn.current = M.useMemo(() => Aa * qe + zc, [
      Aa,
      zc
    ]), M.useEffect(() => {
      kr.current = $c;
    }, [
      $c
    ]), M.useEffect(() => {
      us(true);
    }, []), M.useEffect(() => {
      let F = cn.current;
      if (F) {
        let H = F.getBoundingClientRect().height;
        return Dc(H), S((q) => [
          {
            toastId: d.id,
            height: H,
            position: d.position
          },
          ...q
        ]), () => S((q) => q.filter((Je) => Je.toastId !== d.id));
      }
    }, [
      S,
      d.id
    ]), M.useLayoutEffect(() => {
      if (!G)
        return;
      let F = cn.current, H = F.style.height;
      F.style.height = "auto";
      let q = F.getBoundingClientRect().height;
      F.style.height = H, Dc(q), S((Je) => Je.find((et) => et.toastId === d.id) ? Je.map((et) => et.toastId === d.id ? {
        ...et,
        height: q
      } : et) : [
        {
          toastId: d.id,
          height: q,
          position: d.position
        },
        ...Je
      ]);
    }, [
      G,
      d.title,
      d.description,
      S,
      d.id
    ]);
    let It = M.useCallback(() => {
      xa(true), fs(bn.current), S((F) => F.filter((H) => H.toastId !== d.id)), setTimeout(() => {
        T(d);
      }, jw);
    }, [
      d,
      T,
      S,
      bn
    ]);
    M.useEffect(() => {
      if (d.promise && Ge === "loading" || d.duration === 1 / 0 || d.type === "loading")
        return;
      let F;
      return A || y || R && Bc ? (() => {
        if (jc.current < ps.current) {
          let H = (/* @__PURE__ */ new Date()).getTime() - ps.current;
          kr.current = kr.current - H;
        }
        jc.current = (/* @__PURE__ */ new Date()).getTime();
      })() : kr.current !== 1 / 0 && (ps.current = (/* @__PURE__ */ new Date()).getTime(), F = setTimeout(() => {
        var H;
        (H = d.onAutoClose) == null || H.call(d, d), It();
      }, kr.current)), () => clearTimeout(F);
    }, [
      A,
      y,
      d,
      Ge,
      R,
      Bc,
      It
    ]), M.useEffect(() => {
      d.delete && It();
    }, [
      It,
      d.delete
    ]);
    function Cg() {
      var F, H, q;
      return _ != null && _.loading ? M.createElement("div", {
        className: rt(C == null ? void 0 : C.loader, (F = d == null ? void 0 : d.classNames) == null ? void 0 : F.loader, "sonner-loader"),
        "data-visible": Ge === "loading"
      }, _.loading) : Ue ? M.createElement("div", {
        className: rt(C == null ? void 0 : C.loader, (H = d == null ? void 0 : d.classNames) == null ? void 0 : H.loader, "sonner-loader"),
        "data-visible": Ge === "loading"
      }, Ue) : M.createElement(Sw, {
        className: rt(C == null ? void 0 : C.loader, (q = d == null ? void 0 : d.classNames) == null ? void 0 : q.loader),
        visible: Ge === "loading"
      });
    }
    return M.createElement("li", {
      tabIndex: 0,
      ref: cn,
      className: rt(Ae, kg, C == null ? void 0 : C.toast, (t = d == null ? void 0 : d.classNames) == null ? void 0 : t.toast, C == null ? void 0 : C.default, C == null ? void 0 : C[Ge], (n = d == null ? void 0 : d.classNames) == null ? void 0 : n[Ge]),
      "data-sonner-toast": "",
      "data-rich-colors": (r = d.richColors) != null ? r : N,
      "data-styled": !(d.jsx || d.unstyled || w),
      "data-mounted": G,
      "data-promise": !!d.promise,
      "data-swiped": hg,
      "data-removed": vr,
      "data-visible": Sg,
      "data-y-position": xg,
      "data-x-position": Ag,
      "data-index": h,
      "data-front": vg,
      "data-swiping": Sr,
      "data-dismissible": Pn,
      "data-type": Ge,
      "data-invert": Mg,
      "data-swipe-out": Fc,
      "data-swipe-direction": de,
      "data-expanded": !!(A || P && G),
      style: {
        "--index": h,
        "--toasts-before": h,
        "--z-index": v.length - h,
        "--offset": `${vr ? yg : bn.current}px`,
        "--initial-height": P ? "auto" : `${wg}px`,
        ...W,
        ...d.style
      },
      onDragEnd: () => {
        ds(false), j(null), Ln.current = null;
      },
      onPointerDown: (F) => {
        gs || !Pn || (Uc.current = /* @__PURE__ */ new Date(), fs(bn.current), F.target.setPointerCapture(F.pointerId), F.target.tagName !== "BUTTON" && (ds(true), Ln.current = {
          x: F.clientX,
          y: F.clientY
        }));
      },
      onPointerUp: () => {
        var F, H, q, Je;
        if (Fc || !Pn)
          return;
        Ln.current = null;
        let et = Number(((F = cn.current) == null ? void 0 : F.style.getPropertyValue("--swipe-amount-x").replace("px", "")) || 0), Dt = Number(((H = cn.current) == null ? void 0 : H.style.getPropertyValue("--swipe-amount-y").replace("px", "")) || 0), un = (/* @__PURE__ */ new Date()).getTime() - ((q = Uc.current) == null ? void 0 : q.getTime()), tt = z === "x" ? et : Dt, Ut = Math.abs(tt) / un;
        if (Math.abs(tt) >= $w || Ut > 0.11) {
          fs(bn.current), (Je = d.onDismiss) == null || Je.call(d, d), Le(z === "x" ? et > 0 ? "right" : "left" : Dt > 0 ? "down" : "up"), It(), mg(true), Ic(false);
          return;
        }
        ds(false), j(null);
      },
      onPointerMove: (F) => {
        var H, q, Je, et;
        if (!Ln.current || !Pn || ((H = window.getSelection()) == null ? void 0 : H.toString().length) > 0)
          return;
        let Dt = F.clientY - Ln.current.y, un = F.clientX - Ln.current.x, tt = (q = e.swipeDirections) != null ? q : zw(Nn);
        !z && (Math.abs(un) > 1 || Math.abs(Dt) > 1) && j(Math.abs(un) > Math.abs(Dt) ? "x" : "y");
        let Ut = {
          x: 0,
          y: 0
        };
        z === "y" ? (tt.includes("top") || tt.includes("bottom")) && (tt.includes("top") && Dt < 0 || tt.includes("bottom") && Dt > 0) && (Ut.y = Dt) : z === "x" && (tt.includes("left") || tt.includes("right")) && (tt.includes("left") && un < 0 || tt.includes("right") && un > 0) && (Ut.x = un), (Math.abs(Ut.x) > 0 || Math.abs(Ut.y) > 0) && Ic(true), (Je = cn.current) == null || Je.style.setProperty("--swipe-amount-x", `${Ut.x}px`), (et = cn.current) == null || et.style.setProperty("--swipe-amount-y", `${Ut.y}px`);
      }
    }, Tg && !d.jsx ? M.createElement("button", {
      "aria-label": Z,
      "data-disabled": gs,
      "data-close-button": true,
      onClick: gs || !Pn ? () => {
      } : () => {
        var F;
        It(), (F = d.onDismiss) == null || F.call(d, d);
      },
      className: rt(C == null ? void 0 : C.closeButton, (a = d == null ? void 0 : d.classNames) == null ? void 0 : a.closeButton)
    }, (o = _ == null ? void 0 : _.close) != null ? o : Aw) : null, d.jsx || x.isValidElement(d.title) ? d.jsx ? d.jsx : typeof d.title == "function" ? d.title() : d.title : M.createElement(M.Fragment, null, Ge || d.icon || d.promise ? M.createElement("div", {
      "data-icon": "",
      className: rt(C == null ? void 0 : C.icon, (s = d == null ? void 0 : d.classNames) == null ? void 0 : s.icon)
    }, d.promise || d.type === "loading" && !d.icon ? d.icon || Cg() : null, d.type !== "loading" ? d.icon || (_ == null ? void 0 : _[Ge]) || ww(Ge) : null) : null, M.createElement("div", {
      "data-content": "",
      className: rt(C == null ? void 0 : C.content, (l = d == null ? void 0 : d.classNames) == null ? void 0 : l.content)
    }, M.createElement("div", {
      "data-title": "",
      className: rt(C == null ? void 0 : C.title, (i = d == null ? void 0 : d.classNames) == null ? void 0 : i.title)
    }, typeof d.title == "function" ? d.title() : d.title), d.description ? M.createElement("div", {
      "data-description": "",
      className: rt(dt, Eg, C == null ? void 0 : C.description, (c = d == null ? void 0 : d.classNames) == null ? void 0 : c.description)
    }, typeof d.description == "function" ? d.description() : d.description) : null), x.isValidElement(d.cancel) ? d.cancel : d.cancel && Ha(d.cancel) ? M.createElement("button", {
      "data-button": true,
      "data-cancel": true,
      style: d.cancelButtonStyle || I,
      onClick: (F) => {
        var H, q;
        Ha(d.cancel) && Pn && ((q = (H = d.cancel).onClick) == null || q.call(H, F), It());
      },
      className: rt(C == null ? void 0 : C.cancelButton, (u = d == null ? void 0 : d.classNames) == null ? void 0 : u.cancelButton)
    }, d.cancel.label) : null, x.isValidElement(d.action) ? d.action : d.action && Ha(d.action) ? M.createElement("button", {
      "data-button": true,
      "data-action": true,
      style: d.actionButtonStyle || Se,
      onClick: (F) => {
        var H, q;
        Ha(d.action) && ((q = (H = d.action).onClick) == null || q.call(H, F), !F.defaultPrevented && It());
      },
      className: rt(C == null ? void 0 : C.actionButton, (p = d == null ? void 0 : d.classNames) == null ? void 0 : p.actionButton)
    }, d.action.label) : null));
  };
  function rd() {
    if (typeof window > "u" || typeof document > "u")
      return "ltr";
    let e = document.documentElement.getAttribute("dir");
    return e === "auto" || !e ? window.getComputedStyle(document.documentElement).direction : e;
  }
  function Vw(e, t) {
    let n = {};
    return [
      e,
      t
    ].forEach((r, a) => {
      let o = a === 1, s = o ? "--mobile-offset" : "--offset", l = o ? Iw : Fw;
      function i(c) {
        [
          "top",
          "right",
          "bottom",
          "left"
        ].forEach((u) => {
          n[`${s}-${u}`] = typeof c == "number" ? `${c}px` : c;
        });
      }
      typeof r == "number" || typeof r == "string" ? i(r) : typeof r == "object" ? [
        "top",
        "right",
        "bottom",
        "left"
      ].forEach((c) => {
        r[c] === void 0 ? n[`${s}-${c}`] = l : n[`${s}-${c}`] = typeof r[c] == "number" ? `${r[c]}px` : r[c];
      }) : i(l);
    }), n;
  }
  zE = x.forwardRef(function(e, t) {
    let { invert: n, position: r = "bottom-right", hotkey: a = [
      "altKey",
      "KeyT"
    ], expand: o, closeButton: s, className: l, offset: i, mobileOffset: c, theme: u = "light", richColors: p, duration: f, style: d, visibleToasts: w = Ow, toastOptions: y, dir: S = rd(), gap: g = Uw, loadingIcon: m, icons: h, containerAriaLabel: v = "Notifications", pauseWhenPageIsHidden: A } = e, [T, N] = M.useState([]), L = M.useMemo(() => Array.from(new Set([
      r
    ].concat(T.filter((R) => R.position).map((R) => R.position)))), [
      T,
      r
    ]), [W, I] = M.useState([]), [Se, Ae] = M.useState(false), [dt, kt] = M.useState(false), [Nn, qe] = M.useState(u !== "system" ? u : typeof window < "u" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"), Ue = M.useRef(null), P = a.join("+").replace(/Key/g, "").replace(/Digit/g, ""), C = M.useRef(null), _ = M.useRef(false), Z = M.useCallback((R) => {
      N((z) => {
        var j;
        return (j = z.find((de) => de.id === R.id)) != null && j.delete || _e.dismiss(R.id), z.filter(({ id: de }) => de !== R.id);
      });
    }, []);
    return M.useEffect(() => _e.subscribe((R) => {
      if (R.dismiss) {
        N((z) => z.map((j) => j.id === R.id ? {
          ...j,
          delete: true
        } : j));
        return;
      }
      setTimeout(() => {
        T1.flushSync(() => {
          N((z) => {
            let j = z.findIndex((de) => de.id === R.id);
            return j !== -1 ? [
              ...z.slice(0, j),
              {
                ...z[j],
                ...R
              },
              ...z.slice(j + 1)
            ] : [
              R,
              ...z
            ];
          });
        });
      });
    }), []), M.useEffect(() => {
      if (u !== "system") {
        qe(u);
        return;
      }
      if (u === "system" && (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? qe("dark") : qe("light")), typeof window > "u")
        return;
      let R = window.matchMedia("(prefers-color-scheme: dark)");
      try {
        R.addEventListener("change", ({ matches: z }) => {
          qe(z ? "dark" : "light");
        });
      } catch {
        R.addListener(({ matches: j }) => {
          try {
            qe(j ? "dark" : "light");
          } catch (de) {
            console.error(de);
          }
        });
      }
    }, [
      u
    ]), M.useEffect(() => {
      T.length <= 1 && Ae(false);
    }, [
      T
    ]), M.useEffect(() => {
      let R = (z) => {
        var j, de;
        a.every((Le) => z[Le] || z.code === Le) && (Ae(true), (j = Ue.current) == null || j.focus()), z.code === "Escape" && (document.activeElement === Ue.current || (de = Ue.current) != null && de.contains(document.activeElement)) && Ae(false);
      };
      return document.addEventListener("keydown", R), () => document.removeEventListener("keydown", R);
    }, [
      a
    ]), M.useEffect(() => {
      if (Ue.current)
        return () => {
          C.current && (C.current.focus({
            preventScroll: true
          }), C.current = null, _.current = false);
        };
    }, [
      Ue.current
    ]), M.createElement("section", {
      ref: t,
      "aria-label": `${v} ${P}`,
      tabIndex: -1,
      "aria-live": "polite",
      "aria-relevant": "additions text",
      "aria-atomic": "false",
      suppressHydrationWarning: true
    }, L.map((R, z) => {
      var j;
      let [de, Le] = R.split("-");
      return T.length ? M.createElement("ol", {
        key: R,
        dir: S === "auto" ? rd() : S,
        tabIndex: -1,
        ref: Ue,
        className: l,
        "data-sonner-toaster": true,
        "data-theme": Nn,
        "data-y-position": de,
        "data-lifted": Se && T.length > 1 && !o,
        "data-x-position": Le,
        style: {
          "--front-toast-height": `${((j = W[0]) == null ? void 0 : j.height) || 0}px`,
          "--width": `${Dw}px`,
          "--gap": `${g}px`,
          ...d,
          ...Vw(i, c)
        },
        onBlur: (G) => {
          _.current && !G.currentTarget.contains(G.relatedTarget) && (_.current = false, C.current && (C.current.focus({
            preventScroll: true
          }), C.current = null));
        },
        onFocus: (G) => {
          G.target instanceof HTMLElement && G.target.dataset.dismissible === "false" || _.current || (_.current = true, C.current = G.relatedTarget);
        },
        onMouseEnter: () => Ae(true),
        onMouseMove: () => Ae(true),
        onMouseLeave: () => {
          dt || Ae(false);
        },
        onDragEnd: () => Ae(false),
        onPointerDown: (G) => {
          G.target instanceof HTMLElement && G.target.dataset.dismissible === "false" || kt(true);
        },
        onPointerUp: () => kt(false)
      }, T.filter((G) => !G.position && z === 0 || G.position === R).map((G, us) => {
        var vr, xa;
        return M.createElement(Bw, {
          key: G.id,
          icons: h,
          index: us,
          toast: G,
          defaultRichColors: p,
          duration: (vr = y == null ? void 0 : y.duration) != null ? vr : f,
          className: y == null ? void 0 : y.className,
          descriptionClassName: y == null ? void 0 : y.descriptionClassName,
          invert: n,
          visibleToasts: w,
          closeButton: (xa = y == null ? void 0 : y.closeButton) != null ? xa : s,
          interacting: dt,
          position: R,
          style: y == null ? void 0 : y.style,
          unstyled: y == null ? void 0 : y.unstyled,
          classNames: y == null ? void 0 : y.classNames,
          cancelButtonStyle: y == null ? void 0 : y.cancelButtonStyle,
          actionButtonStyle: y == null ? void 0 : y.actionButtonStyle,
          removeToast: Z,
          toasts: T.filter((Sr) => Sr.position == G.position),
          heights: W.filter((Sr) => Sr.position == G.position),
          setHeights: I,
          expandByDefault: o,
          gap: g,
          loadingIcon: m,
          expanded: Se,
          pauseWhenPageIsHidden: A,
          swipeDirections: e.swipeDirections
        });
      })) : null;
    }));
  });
  let fa;
  BE = (e, t) => {
    const n = new Set(e);
    return n.has(t) ? n.delete(t) : n.add(t), n;
  };
  VE = (e) => {
    const t = Number(e);
    return isNaN(t) ? e : t;
  };
  HE = (e) => `${Qr.TYPE}:${[
    ...e
  ].join(",")}`;
  n0 = (e) => {
    if (!e)
      return {
        prefix: null,
        types: []
      };
    const t = e.indexOf(":");
    if (t === -1)
      return {
        prefix: null,
        types: []
      };
    const n = e.slice(0, t), r = e.slice(t + 1);
    return n === Qr.TYPE ? {
      prefix: Qr.TYPE,
      types: r.split(",").map(Number).filter((a) => !isNaN(a) && vd.includes(a))
    } : {
      prefix: null,
      types: []
    };
  };
  GE = (e) => _g[e] || {};
  Hw = (e) => ({
    id: Rg,
    label: `${e.length} types`,
    steps: e
  });
  fa = 0.7;
  async function r0(e) {
    if (!e)
      return null;
    try {
      const n = await (await Og()).getProject(e);
      return Sd(n);
    } catch (t) {
      return console.warn("snapshotExistingSourceIds: failed:", t == null ? void 0 : t.message), null;
    }
  }
  function Gw(e) {
    return e.length === 1 ? ao[e[0]] || "artifact" : e.length > 1 ? `${e.length} types` : "";
  }
  function Ww(e, t, n, r) {
    const a = 1 - fa;
    let o = null, s = -1;
    const l = () => clearInterval(i), i = setInterval(() => {
      if (!e.state.studioGeneration.isGenerating) {
        l();
        return;
      }
      const c = e.state.studioGeneration.packProgress;
      if (!c || c.total <= 0)
        return;
      const u = ao[c.currentType] || "artifact", p = `${c.current + 1}/${c.total}`, f = c.retrying ? `${t}Retrying ${u} (${p})...` : `${t}Generating ${u} (${p})...`, d = Math.round(fa * 100 + c.current / c.total * a * 100);
      f === o && d === s || (o = f, s = d, n(e, f, d));
    }, 400);
    return r == null ? void 0 : r.addEventListener("abort", l, {
      once: true
    }), () => {
      l(), r == null ? void 0 : r.removeEventListener("abort", l);
    };
  }
  async function a0(e, t, n, { msgPrefix: r, setProgress: a, dispatchFn: o, existingSourceIds: s = null }) {
    if (!n || !t)
      return;
    const { types: l } = n0(n), i = Gw(l), c = l.length > 1;
    let u = null;
    try {
      a(e, `${r}Generating ${i}...`, Math.round(fa * 100)), c && (u = Ww(e, r, a)), await o(e, t, n, {
        existingSourceIds: s
      }), a(e, "Done \u2014 opening notebook...", 100);
    } catch (p) {
      console.error("Post-add generation failed:", p), a(e, `${i} failed \u2014 opening notebook...`, 100);
    } finally {
      u == null ? void 0 : u();
    }
  }
  WE = (e) => (e == null ? void 0 : e.permissionCode) === oo.OWNER;
  Yw = (e) => (e == null ? void 0 : e.permissionCode) === oo.OWNER || (e == null ? void 0 : e.permissionCode) === oo.EDITOR;
  Qw = (e) => (e == null ? void 0 : e.permissionCode) === oo.VIEWER;
  YE = "Read-only \u2014 you have viewer access";
  QE = "Only the notebook owner can do this";
  class ad extends Error {
    constructor(t = "Aborted") {
      super(t), this.name = "AbortError";
    }
  }
  function o0(e, t) {
    return new Promise((n, r) => {
      if (t == null ? void 0 : t.aborted) {
        r(new ad());
        return;
      }
      const a = () => {
        clearTimeout(o), r(new ad());
      }, o = setTimeout(() => {
        t == null ? void 0 : t.removeEventListener("abort", a), n();
      }, e);
      t == null ? void 0 : t.addEventListener("abort", a, {
        once: true
      });
    });
  }
  async function pa(e, t, n, r) {
    const a = Math.max(1, Math.min(t, e.length));
    let o = 0;
    const s = async () => {
      for (; o < e.length; ) {
        if (r == null ? void 0 : r.aborted)
          return;
        const l = o++;
        try {
          await n(e[l], l);
        } catch {
        }
      }
    };
    await Promise.all(Array.from({
      length: a
    }, s));
  }
  const Zw = 60 * 60 * 1e3, Kw = 3, kc = {
    statsMap: {},
    loadingMap: {},
    isScanning: false,
    scanProgress: {
      current: 0,
      total: 0
    },
    lastScanTime: null
  }, Xw = async (e) => {
    const t = await k.get(Jn);
    return (t == null ? void 0 : t.statsMap) ? (await e.setState({
      artifactStats: {
        ...e.state.artifactStats,
        statsMap: t.statsMap,
        lastScanTime: t.lastScanTime
      }
    }), t.statsMap) : {};
  }, od = async (e, t, n) => {
    var _a2;
    const a = {
      ...((_a2 = await k.get(Jn)) == null ? void 0 : _a2.statsMap) || {},
      ...e.state.artifactStats.statsMap,
      [t]: n
    };
    return await k.set(Jn, {
      statsMap: a,
      lastScanTime: (/* @__PURE__ */ new Date()).toISOString()
    }), a;
  }, Ec = async (e, t, n = null) => {
    var _a2;
    if (n) {
      const s = ce.countArtifactsByType(n), l = await od(e, t, s);
      return await e.setState({
        artifactStats: {
          ...e.state.artifactStats,
          statsMap: l
        }
      }), s;
    }
    const r = $(e.state), a = r == null ? void 0 : r.email, { artifactStats: o } = e.state;
    if (!(r == null ? void 0 : r.token) || o.loadingMap[t])
      return null;
    await e.setState({
      artifactStats: {
        ...e.state.artifactStats,
        loadingMap: {
          ...e.state.artifactStats.loadingMap,
          [t]: true
        }
      }
    });
    try {
      const s = new ge(r.token, {
        ...r,
        onAuthError: me(e, r.email)
      }), l = await Promise.allSettled([
        s.listArtifacts(t),
        s.getNotes(t)
      ]);
      if (l[0].status === "rejected" && console.warn("listArtifacts failed:", l[0].reason), l[1].status === "rejected" && console.warn("getNotes failed:", l[1].reason), l[0].status === "rejected" && l[1].status === "rejected")
        return await e.setState({
          artifactStats: {
            ...e.state.artifactStats,
            loadingMap: {
              ...e.state.artifactStats.loadingMap,
              [t]: false
            }
          }
        }), null;
      const i = l[0].status === "fulfilled" ? l[0].value : null, c = l[1].status === "fulfilled" ? l[1].value : null, u = ce.parseArtifacts(i), p = ce.parseNotesAsArtifacts(c), f = ce.countArtifactsByType([
        ...u,
        ...p
      ]);
      if (((_a2 = $(e.state)) == null ? void 0 : _a2.email) !== a)
        return null;
      const d = await od(e, t, f);
      return await e.setState({
        artifactStats: {
          ...e.state.artifactStats,
          statsMap: d,
          loadingMap: {
            ...e.state.artifactStats.loadingMap,
            [t]: false
          }
        }
      }), f;
    } catch (s) {
      return console.warn(`Failed to scan stats for notebook ${t}:`, s), await e.setState({
        artifactStats: {
          ...e.state.artifactStats,
          loadingMap: {
            ...e.state.artifactStats.loadingMap,
            [t]: false
          }
        }
      }), null;
    }
  }, qw = async (e, { role: t = "all" } = {}) => {
    var _a2, _b;
    const n = $(e.state), r = n == null ? void 0 : n.email;
    if (!(n == null ? void 0 : n.token))
      return {};
    await e.setState({
      artifactStats: {
        ...e.state.artifactStats,
        isScanning: true,
        scanProgress: {
          current: 0,
          total: 0
        }
      }
    });
    try {
      await Ta(e);
      const a = new ge(n.token, {
        ...n,
        onAuthError: me(e, n.email)
      });
      let o = e.state.notebooklm.projects || [];
      t === "mine" ? o = o.filter(Yw) : t === "shared" && (o = o.filter(Qw));
      const s = o.length, i = {
        ...((_a2 = await k.get(Jn)) == null ? void 0 : _a2.statsMap) || {},
        ...e.state.artifactStats.statsMap
      };
      await e.setState({
        artifactStats: {
          ...e.state.artifactStats,
          scanProgress: {
            current: 0,
            total: s
          }
        }
      });
      let c = 0;
      if (await pa(o, Kw, async (p) => {
        var _a3;
        if (((_a3 = $(e.state)) == null ? void 0 : _a3.email) === r)
          try {
            const f = await Promise.allSettled([
              a.listArtifacts(p.id),
              a.getNotes(p.id)
            ]);
            if (f[0].status === "rejected" && console.warn(`listArtifacts failed for ${p.id}:`, f[0].reason), f[1].status === "rejected" && console.warn(`getNotes failed for ${p.id}:`, f[1].reason), !(f[0].status === "rejected" && f[1].status === "rejected")) {
              const d = f[0].status === "fulfilled" ? f[0].value : null, w = f[1].status === "fulfilled" ? f[1].value : null, y = ce.parseArtifacts(d), S = ce.parseNotesAsArtifacts(w);
              i[p.id] = ce.countArtifactsByType([
                ...y,
                ...S
              ]);
            }
          } catch (f) {
            console.warn(`Failed to scan stats for notebook ${p.id}:`, f);
          } finally {
            c++, await e.setState({
              artifactStats: {
                ...e.state.artifactStats,
                scanProgress: {
                  current: c,
                  total: s
                }
              }
            });
          }
      }), ((_b = $(e.state)) == null ? void 0 : _b.email) !== r)
        return {};
      const u = (/* @__PURE__ */ new Date()).toISOString();
      return await e.setState({
        artifactStats: {
          ...e.state.artifactStats,
          statsMap: i,
          isScanning: false,
          scanProgress: {
            current: s,
            total: s
          },
          lastScanTime: u
        }
      }), await k.set(Jn, {
        statsMap: i,
        lastScanTime: u
      }), i;
    } catch (a) {
      return console.error("Failed to scan all stats:", a), await e.setState({
        artifactStats: {
          ...e.state.artifactStats,
          isScanning: false
        }
      }), {};
    }
  }, Jw = (e) => {
    const { lastScanTime: t } = e.state.artifactStats;
    if (!t)
      return true;
    const n = new Date(t).getTime();
    return isNaN(n) ? true : Date.now() - n > Zw;
  }, ev = (e, t) => e.state.artifactStats.statsMap[t] || null, tv = async (e) => {
    await e.setState({
      artifactStats: {
        ...kc
      }
    });
  }, nv = async (e) => {
    await e.setState({
      artifactStats: {
        ...kc
      }
    }), await k.remove(Jn);
  }, s0 = {
    artifactsMap: {},
    loadingMap: {},
    deleteProgress: null,
    isDeleting: false,
    quizContentMap: {}
  }, Tc = async (e, t) => {
    var _a2, _b, _c2;
    const n = $(e.state), r = n == null ? void 0 : n.email, { artifacts: a } = e.state;
    if (!(n == null ? void 0 : n.token) || a.loadingMap[t])
      return null;
    await e.setState({
      artifacts: {
        ...e.state.artifacts,
        loadingMap: {
          ...e.state.artifacts.loadingMap,
          [t]: true
        }
      }
    });
    try {
      const o = new ge(n.token, {
        ...n,
        onAuthError: me(e, n.email)
      }), s = await Promise.allSettled([
        o.listArtifacts(t),
        o.getNotes(t)
      ]);
      if (s[0].status === "rejected" && console.warn("listArtifacts failed:", s[0].reason), s[1].status === "rejected" && console.warn("getNotes failed:", s[1].reason), s[0].status === "rejected" && s[1].status === "rejected")
        return await e.setState({
          artifacts: {
            ...e.state.artifacts,
            loadingMap: {
              ...e.state.artifacts.loadingMap,
              [t]: false
            }
          }
        }), null;
      const l = s[0].status === "fulfilled" ? s[0].value : null, i = s[1].status === "fulfilled" ? s[1].value : null, c = ce.parseArtifacts(l), u = (_b = (_a2 = e.state.notebooklm) == null ? void 0 : _a2.projects) == null ? void 0 : _b.find((d) => d.id === t), p = new Set(((u == null ? void 0 : u.sources) || []).map((d) => d == null ? void 0 : d.id).filter(Boolean)), f = ce.parseNotesAsArtifacts(i, p);
      return c.push(...f), ((_c2 = $(e.state)) == null ? void 0 : _c2.email) !== r ? null : (await e.setState({
        artifacts: {
          ...e.state.artifacts,
          artifactsMap: {
            ...e.state.artifacts.artifactsMap,
            [t]: c
          },
          loadingMap: {
            ...e.state.artifacts.loadingMap,
            [t]: false
          }
        }
      }), c);
    } catch (o) {
      return console.warn(`Failed to fetch artifacts for notebook ${t}:`, o), await e.setState({
        artifacts: {
          ...e.state.artifacts,
          loadingMap: {
            ...e.state.artifacts.loadingMap,
            [t]: false
          }
        }
      }), null;
    }
  }, rv = async (e, t, n) => {
    const r = $(e.state);
    if (r == null ? void 0 : r.token) {
      await e.setState({
        artifacts: {
          ...e.state.artifacts,
          isDeleting: true,
          deleteProgress: {
            current: 0,
            total: t.length
          }
        }
      });
      try {
        const a = new ge(r.token, {
          ...r,
          onAuthError: me(e, r.email)
        }), o = t.filter((c) => c.isNote), s = t.filter((c) => !c.isNote);
        let l = 0;
        for (const c of s)
          await a.deleteArtifact(c.id, n), l++, await e.setState({
            artifacts: {
              ...e.state.artifacts,
              deleteProgress: {
                current: l,
                total: t.length
              }
            }
          });
        o.length > 0 && (await a.deleteNotes(o.map((c) => c.id), n), l += o.length, await e.setState({
          artifacts: {
            ...e.state.artifacts,
            deleteProgress: {
              current: l,
              total: t.length
            }
          }
        }));
        const i = await Tc(e, n);
        i && await Ec(e, n, i);
      } catch (a) {
        throw console.error("Failed to delete artifacts:", a), a;
      } finally {
        await e.setState({
          artifacts: {
            ...e.state.artifacts,
            isDeleting: false,
            deleteProgress: null
          }
        });
      }
    }
  }, av = async (e, t, n, r) => {
    var _a2;
    const a = $(e.state), { artifacts: o } = e.state;
    if (!(a == null ? void 0 : a.token))
      throw new Error("Not authenticated to NotebookLM");
    const s = new ge(a.token, {
      ...a,
      onAuthError: me(e, a.email)
    }), i = (o.artifactsMap[r] || []).find((c) => c.id === t);
    if (i == null ? void 0 : i.isNote) {
      const c = i.rawContent || ((_a2 = i.parsedContent) == null ? void 0 : _a2.text) || "";
      return s.mutateNote(t, c, n, r);
    }
    return s.renameArtifact(t, n, r);
  }, ov = async (e, t, n) => {
    var _a2, _b;
    const r = $(e.state), { artifacts: a } = e.state;
    if (!(r == null ? void 0 : r.token))
      return null;
    if ((_a2 = a.quizContentMap[t]) == null ? void 0 : _a2.data)
      return a.quizContentMap[t].data;
    if ((_b = a.quizContentMap[t]) == null ? void 0 : _b.loading)
      return null;
    await e.setState({
      artifacts: {
        ...e.state.artifacts,
        quizContentMap: {
          ...e.state.artifacts.quizContentMap,
          [t]: {
            data: null,
            loading: true,
            error: null
          }
        }
      }
    });
    try {
      const s = await new ge(r.token, {
        ...r,
        onAuthError: me(e, r.email)
      }).getInteractiveHTML(t, n), l = Fg(s);
      return await e.setState({
        artifacts: {
          ...e.state.artifacts,
          quizContentMap: {
            ...e.state.artifacts.quizContentMap,
            [t]: {
              data: l,
              loading: false,
              error: null
            }
          }
        }
      }), l;
    } catch (o) {
      return console.warn(`Failed to fetch quiz content for artifact ${t}:`, o), await e.setState({
        artifacts: {
          ...e.state.artifacts,
          quizContentMap: {
            ...e.state.artifacts.quizContentMap,
            [t]: {
              data: null,
              loading: false,
              error: o.message
            }
          }
        }
      }), null;
    }
  }, sv = async (e) => {
    await e.setState({
      artifacts: {
        ...s0
      }
    });
  }, Pt = (e, t) => {
    const n = e.state.studioGeneration, r = Object.keys(t);
    r.length > 0 && r.every((a) => n[a] === t[a]) || e.setState({
      studioGeneration: {
        ...n,
        ...t
      }
    });
  }, lv = /^[\w-]{5,100}$/, Oo = (e, t) => {
    var _a2;
    return ((_a2 = $(e.state)) == null ? void 0 : _a2.email) !== t;
  }, Gl = "Account changed \u2014 generation cancelled", iv = "Rate limited, retrying...", cv = "Retrying...", l0 = (e) => /HTTP 429/i.test(e == null ? void 0 : e.message), i0 = (e) => (e == null ? void 0 : e.name) === Ig, c0 = (e) => /timeout|network|HTTP 5\d{2}|HTTP 429/i.test(e == null ? void 0 : e.message) || (e == null ? void 0 : e.name) === "TimeoutError", u0 = (e, t = 1) => l0(e) ? Hc * 6 : Hc * t;
  function uv(e) {
    if (i0(e))
      return "Daily generation limit reached \u2014 your quota will reset tomorrow";
    const t = (e == null ? void 0 : e.message) || "";
    return /HTTP 4(01|00)/.test(t) ? "Authentication expired \u2014 please reconnect your account" : /HTTP 403/.test(t) ? "Access denied \u2014 you may not have permission for this notebook" : /HTTP 429/.test(t) ? "Rate limit reached \u2014 please wait a moment and try again" : /HTTP 5\d{2}/.test(t) ? "NotebookLM server error \u2014 please try again later" : /timeout/i.test(t) ? "Request timed out \u2014 please try again" : /Unsupported artifact type/.test(t) ? "Unsupported artifact type selected" : "Generation failed \u2014 NotebookLM may have updated, check for extension updates";
  }
  const d0 = (e, t) => new Promise((n, r) => {
    const a = setTimeout(() => r(new Error("timeout")), Bg), o = () => {
      clearTimeout(a), r(new DOMException("Aborted", "AbortError"));
    };
    if (t == null ? void 0 : t.aborted)
      return clearTimeout(a), r(new DOMException("Aborted", "AbortError"));
    t == null ? void 0 : t.addEventListener("abort", o, {
      once: true
    }), e.then(n, r).finally(() => {
      clearTimeout(a), t == null ? void 0 : t.removeEventListener("abort", o);
    });
  }), Gn = (e, t) => new Promise((n, r) => {
    if (t == null ? void 0 : t.aborted)
      return r(new DOMException("Aborted", "AbortError"));
    const a = () => {
      clearTimeout(o), r(new DOMException("Aborted", "AbortError"));
    }, o = setTimeout(() => {
      t == null ? void 0 : t.removeEventListener("abort", a), n();
    }, e);
    t == null ? void 0 : t.addEventListener("abort", a, {
      once: true
    });
  });
  function hr(e, t = null, n = null) {
    const r = $(e.state);
    if (!(r == null ? void 0 : r.token))
      throw new Error("Not authenticated");
    const { token: a, email: o, fsid: s, bl: l, authuser: i } = r;
    return {
      client: new ge(a, {
        email: o,
        fsid: s,
        bl: l,
        authuser: i,
        signal: t,
        onAuthError: me(e, o, n)
      }),
      email: o
    };
  }
  async function f0(e, t = null, n = null) {
    var _a2, _b;
    try {
      const r = (_a2 = e.state.languageSettings) == null ? void 0 : _a2.outputLanguage;
      if (r)
        return r;
      const a = await k.get(ya);
      if (a)
        return a;
      if (!((_b = $(e.state)) == null ? void 0 : _b.token))
        return "en";
      const { client: s } = n || hr(e, t || Ed(5e3)), l = await s.getOrCreateAccount(), i = Dg(l);
      return await ny(e, i), i;
    } catch (r) {
      return console.warn('resolveOutputLanguage failed, defaulting to "en":', (r == null ? void 0 : r.message) || r), "en";
    }
  }
  async function Fo(e, t, n, r, { options: a = {}, language: o = null, signal: s = null, clientInfo: l = null, expectedEmail: i = null } = {}) {
    if (typeof t != "string" || !lv.test(t))
      throw new Error("Invalid notebook ID");
    if (!Array.isArray(r) || r.some((u) => typeof u != "string"))
      throw new Error("Invalid source IDs");
    if (!vd.includes(n))
      throw new Error(`Unsupported artifact type: ${n}`);
    if (r.length > Gc)
      throw new Error(`Too many sources (max ${Gc})`);
    if (i && Oo(e, i))
      throw new Error("Account context changed");
    const { client: c } = l || hr(e, s);
    if (n === O.MIND_MAP) {
      const u = Ug(r, a.instructions), p = await c.generateMindMap(u, t);
      if (!Array.isArray(p) || !Array.isArray(p[0]))
        throw new Error("Mind Map generation returned unexpected format");
      const f = p[0][0];
      if (!f || typeof f != "string")
        throw new Error("Mind Map generation returned empty result");
      let d = `Mind Map - ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`;
      try {
        const w = JSON.parse(f);
        (w == null ? void 0 : w.name) && typeof w.name == "string" && (d = w.name.replace($g, "").slice(0, 200));
      } catch (w) {
        console.warn("Mind Map title extraction failed:", w);
      }
      await c.createMindMapNote(f, d, t, r);
    } else {
      const u = jg(n, t, r, a, o);
      await c.createArtifact(u, t);
    }
  }
  async function p0(e, t, n) {
    const r = await dv(e, t, n);
    if (n.aborted)
      return null;
    if (r)
      try {
        await d0(Ec(e, t, r), n);
      } catch (a) {
        if (a.name === "AbortError")
          return null;
        console.warn("Post-gen stats scan failed:", a == null ? void 0 : a.message);
      }
    return r;
  }
  async function dv(e, t, n) {
    for (let r = 0; r <= ms.length; r++)
      try {
        return await d0(Tc(e, t), n);
      } catch (a) {
        if (a.name === "AbortError")
          return null;
        console.warn(`Post-gen artifact fetch attempt ${r + 1} failed:`, a == null ? void 0 : a.message), r < ms.length && await Gn(ms[r], n);
      }
    return null;
  }
  async function g0(e, t, n, r, a, o, { setState: s, cancelGeneration: l }) {
    var _a2;
    const { signal: i } = t, c = (_a2 = $(e.state)) == null ? void 0 : _a2.email, u = hr(e, i, l), p = kd.includes(r) ? void 0 : o.overrideLanguage || await f0(e, i, u);
    try {
      await Fo(e, n, r, a, {
        options: o,
        language: p,
        signal: i,
        clientInfo: u
      });
    } catch (d) {
      if (d.name === "AbortError")
        return;
      if (c0(d))
        s(e, {
          generateError: l0(d) ? iv : cv
        }), await Gn(u0(d), i), s(e, {
          generateError: null
        }), await Fo(e, n, r, a, {
          options: o,
          language: p,
          signal: i,
          clientInfo: u,
          expectedEmail: c
        });
      else
        throw d;
    }
    if (i.aborted)
      return;
    if (Oo(e, c)) {
      B.error(Gl);
      return;
    }
    const f = await p0(e, n, i);
    i.aborted || (f ? B.success("Generation submitted") : B.warning("Generation submitted \u2014 refresh to see new artifacts"));
  }
  async function m0(e, t, n, r, a, { setState: o, cancelGeneration: s }) {
    var _a2, _b;
    const { signal: l } = t;
    o(e, {
      generateError: null,
      packProgress: {
        current: 0,
        total: r.steps.length,
        currentType: null
      }
    });
    let i = 0;
    const c = [], u = (_a2 = $(e.state)) == null ? void 0 : _a2.email;
    let p = {
      current: -1,
      total: -1,
      currentType: null,
      retrying: false
    };
    const f = (h) => {
      h.current === p.current && h.total === p.total && h.currentType === p.currentType && !!h.retrying == !!p.retrying || (p = h, o(e, {
        packProgress: h
      }));
    }, d = hr(e, l, s), w = r.steps.some((h) => !kd.includes(h.type)), y = ((_b = r.steps.find((h) => {
      var _a3;
      return (_a3 = h.options) == null ? void 0 : _a3.overrideLanguage;
    })) == null ? void 0 : _b.options.overrideLanguage) || null, S = w ? y || await f0(e, l, d) : void 0, g = (h, v, A = false) => ({
      current: h,
      total: r.steps.length,
      currentType: v,
      retrying: A
    });
    for (let h = 0; h < r.steps.length && !l.aborted; h++) {
      if (Oo(e, u)) {
        B.error(Gl), t.abort();
        break;
      }
      const v = r.steps[h], A = {
        options: v.options,
        language: S,
        signal: l,
        clientInfo: d,
        expectedEmail: u
      };
      f(g(h, v.type));
      try {
        if (await Fo(e, n, v.type, a, A), Oo(e, u)) {
          B.error(Gl), t.abort();
          break;
        }
        i++, h < r.steps.length - 1 && await Gn(Vc, l);
      } catch (T) {
        if (T.name === "AbortError")
          break;
        if (i0(T)) {
          const N = ao[v.type] || "Unknown";
          c.push(N), B.error(`${N} limit reached \u2014 quota will reset tomorrow`), h < r.steps.length - 1 && await Gn(zg, l);
          continue;
        }
        if (c0(T)) {
          o(e, {
            generateError: null
          }), f(g(h, v.type, true));
          try {
            await Gn(u0(T, 2), l), await Fo(e, n, v.type, a, A), i++, f(g(h, v.type)), h < r.steps.length - 1 && await Gn(Vc, l);
            continue;
          } catch (N) {
            if (N.name === "AbortError")
              break;
            console.error(`Pack step retry failed (${v.type}):`, N == null ? void 0 : N.message);
          }
        } else
          console.error(`Pack step failed (${v.type}):`, T == null ? void 0 : T.message);
        c.push(ao[v.type] || "Unknown");
      }
    }
    if (l.aborted) {
      B.info("Generation cancelled");
      return;
    }
    const m = await p0(e, n, l);
    if (!l.aborted)
      if (i === 0) {
        const h = `${r.label} failed \u2014 no steps completed`;
        o(e, {
          generateError: h
        }), B.error(h);
      } else if (i < r.steps.length) {
        const h = `${r.label} partial (${i}/${r.steps.length}): ${c.join(", ")} failed`;
        o(e, {
          generateError: h
        }), B.warning(h);
      } else
        m ? B.success(`${r.label} complete`) : B.warning(`${r.label} complete \u2014 refresh to see new artifacts`);
  }
  let ls, xc, pv, gv, mv, hv, yv;
  h0 = (e) => window.dispatchEvent(new CustomEvent(Vg, {
    detail: {
      source: e
    }
  }));
  ZE = "A note from the developer";
  KE = (e) => `Hi, I'm Trung \u2014 I build NotebookLM Tools on my own. You've used it ${e} times, and I hope it's saved you real time. If it has, buying a license is the best way to keep this tool alive. Either way, thanks for using it.
\u2014 Trung`;
  ls = async () => await k.get(ai) || {
    counts: {},
    lastDismissed: null
  };
  xc = (e) => k.set(ai, e);
  fv = async (e) => {
    const t = await ls();
    t.counts[e] = (t.counts[e] || 0) + 1;
    const n = [
      xc(t)
    ];
    if (e === "feature_used") {
      const r = await y0();
      n.push(k.set(Td, r + 1));
    }
    await Promise.all(n);
  };
  y0 = async () => await k.get(Td) || 0;
  XE = async () => {
    const [e, t] = await Promise.all([
      y0(),
      k.get(Ys)
    ]), n = Hg.filter((r) => e >= r && !(t || []).includes(r));
    return n.length ? Math.max(...n) : null;
  };
  qE = async (e) => {
    const t = await k.get(Ys) || [];
    t.includes(e) || await k.set(Ys, [
      ...t,
      e
    ]);
  };
  JE = async (e) => {
    if (e === "licensed")
      return false;
    const t = await ls();
    if (t.lastDismissed) {
      const n = new Date(t.lastDismissed), r = Gg * 60 * 60 * 1e3;
      if (Date.now() - n.getTime() < r)
        return false;
    }
    for (const [n, r] of Object.entries(xd)) {
      const a = t.counts[n] || 0;
      if (r.threshold && a >= r.threshold)
        return true;
    }
    return false;
  };
  e2 = async () => {
    const e = await ls();
    e.lastDismissed = (/* @__PURE__ */ new Date()).toISOString(), e.counts = {}, await xc(e);
  };
  t2 = async (e) => {
    if (e())
      return;
    await fv("feature_used");
    const t = await ls(), n = t.counts.feature_used || 0, r = xd.feature_used;
    r && n >= r.threshold && (t.counts.feature_used = 0, await xc(t), h0("auto"));
  };
  pv = "Multi-type generation requires a license";
  gv = {
    isGenerating: false,
    generateError: null,
    selectedType: null,
    selectedSourceIds: null,
    packProgress: null
  };
  mv = (e) => {
    e.state.studioGeneration.generateError && Pt(e, {
      generateError: null
    });
  };
  hv = (e, t) => {
    e.state.studioGeneration.selectedType !== t && Pt(e, {
      selectedType: t
    });
  };
  yv = (e, t) => {
    e.state.studioGeneration.selectedSourceIds !== t && Pt(e, {
      selectedSourceIds: t
    });
  };
  let vt = null;
  const wv = (e) => {
    vt && e && vt.abort(), vt = e;
  }, w0 = () => {
    vt && (vt.abort(), vt = null);
  }, vv = (e) => {
    vt === e && (vt = null);
  }, v0 = (e) => {
    const t = !!vt;
    w0();
    const n = e.state.studioGeneration;
    (t || n.isGenerating || n.generateError || n.packProgress) && Pt(e, {
      isGenerating: false,
      generateError: null,
      packProgress: null
    });
  }, Sv = (e) => {
    const t = e.state.studioGeneration;
    !vt && !t.isGenerating && !t.generateError && !t.packProgress && t.selectedType === null && t.selectedSourceIds === null || (w0(), Pt(e, {
      isGenerating: false,
      generateError: null,
      packProgress: null,
      selectedType: null,
      selectedSourceIds: null
    }));
  };
  function Ac(e) {
    return e.state.studioGeneration.isGenerating ? (B.info("Generation already in progress"), false) : true;
  }
  const kv = {
    setState: Pt,
    cancelGeneration: v0
  };
  async function Mc(e, t, n) {
    const r = new AbortController();
    wv(r), Pt(e, {
      isGenerating: true,
      generateError: null
    });
    try {
      await n(r, kv);
    } catch (a) {
      if (a.name === "AbortError")
        return;
      console.error("Generation failed:", a == null ? void 0 : a.message);
      const o = uv(a);
      Pt(e, {
        generateError: o
      }), B.error(o);
    } finally {
      vv(r), e.state.studioGeneration.isGenerating && Pt(e, {
        isGenerating: false,
        ...t
      });
    }
  }
  const Ev = async (e, t, n, r, a = {}) => {
    if (Ac(e)) {
      if (!r || r.length === 0) {
        B.error("No sources selected");
        return;
      }
      await Mc(e, {
        selectedType: null
      }, (o, s) => g0(e, o, t, n, r, a, s));
    }
  }, Tv = async (e, t, n) => {
    if (!t)
      return [];
    if (!(n == null ? void 0 : n.length))
      return B.error("No sources selected"), [];
    try {
      const { client: r } = hr(e), a = await r.suggestArtifactIdeas(n, t, 10);
      return Wg(a);
    } catch (r) {
      return console.error("suggestShortVideoIdeas failed:", r == null ? void 0 : r.message), B.error("Could not fetch ideas"), [];
    }
  }, xv = async (e, t, n, r) => {
    if (!(!n || !(r == null ? void 0 : r.length))) {
      if (!ss(e)) {
        B.info(pv);
        return;
      }
      Ac(e) && await Mc(e, {
        packProgress: null
      }, (a, o) => m0(e, a, t, n, r, o));
    }
  };
  async function S0(e, t, n, { existingSourceIds: r = null } = {}) {
    var _a2;
    if (!n || !t)
      return;
    const { prefix: a, types: o } = n0(n);
    if (a === Qr.TYPE && o.length > 1 && !ss(e)) {
      h0("multi-type");
      return;
    }
    if (!Ac(e))
      return;
    if (!((_a2 = $(e.state)) == null ? void 0 : _a2.token)) {
      B.error("Not authenticated \u2014 please reconnect your account");
      return;
    }
    await Mc(e, {
      packProgress: null
    }, async (l, i) => {
      const { client: c } = hr(e, l.signal), u = await c.getProject(t), p = Sd(u);
      if (p.length === 0) {
        console.warn("dispatchGeneration: API returned no sources"), B.error("No sources found \u2014 add sources before generating");
        return;
      }
      let f;
      if (r !== null) {
        const d = new Set(r);
        f = p.filter((w) => !d.has(w)), f.length === 0 && (console.warn("dispatchGeneration: no new sources detected, falling back to all sources"), f = p);
      } else
        f = p;
      if (a === Qr.TYPE) {
        if (o.length === 1)
          await g0(e, l, t, o[0], f, {}, i);
        else if (o.length > 1) {
          const d = o.slice(0, hs);
          o.length > hs && B.warning(`Selection capped at ${hs} types`);
          const w = d.map((y) => ({
            type: y,
            options: {}
          }));
          await m0(e, l, t, Hw(w), f, i);
        }
      }
    });
  }
  const Io = {
    isAdding: false,
    addSuccess: false,
    actionType: null,
    error: null,
    progressMessage: null,
    progressPercent: 0,
    currentIndex: 0,
    totalLinks: 0,
    failedLinks: []
  }, k0 = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        isAdding: t
      }
    });
  }, E0 = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        addSuccess: t
      }
    });
  }, Av = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        actionType: t
      }
    });
  }, Do = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        error: t
      }
    }), t && setTimeout(() => Do(e, null), 4e3);
  }, Mv = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        progressMessage: t
      }
    });
  }, Cv = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        progressPercent: t
      }
    });
  }, Nv = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        currentIndex: t
      }
    });
  }, Pv = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        totalLinks: t
      }
    });
  }, T0 = (e, t) => {
    e.setState({
      batchNotebookActions: {
        ...e.state.batchNotebookActions,
        failedLinks: t
      }
    });
  };
  function sd(e, t, n) {
    const r = e.state.batchNotebookActions;
    r.progressMessage === t && r.progressPercent === n || e.setState({
      batchNotebookActions: {
        ...r,
        progressMessage: t,
        progressPercent: n
      }
    });
  }
  const bv = async (e, t, n = null, { concurrency: r = 3, generateConfig: a = null } = {}) => {
    if (!t || t.length === 0)
      return Do(e, "No links to add"), false;
    const o = (a == null ? void 0 : a.selection) ?? null, s = (a == null ? void 0 : a.scope) ?? so.NEW;
    try {
      e.setState({
        batchNotebookActions: {
          ...Io,
          isAdding: true,
          actionType: n ? "existing" : "new",
          totalLinks: t.length
        }
      });
      const l = o && s === so.NEW ? await r0(n) : null;
      let i = n, c = 0;
      const u = [], p = async (f, d) => {
        const w = await Promise.allSettled(f.map(async (m) => {
          try {
            const h = await Ad({
              url: m,
              title: m,
              notebookId: i,
              onProgress: () => {
              }
            });
            return {
              success: true,
              link: m,
              id: h
            };
          } catch (h) {
            return console.error(`Failed to add link: ${m}`, h), {
              success: false,
              link: m,
              error: h.message
            };
          }
        }));
        for (const m of w)
          if (c++, m.status === "fulfilled" && m.value.success)
            d && m.value.id && (i = m.value.id);
          else {
            const h = m.status === "fulfilled" ? m.value.link : "unknown";
            u.push(h);
          }
        const y = e.state.batchNotebookActions, S = `Added ${c} of ${t.length} links`, g = Math.round(o ? c / t.length * fa * 100 : c / t.length * 100);
        y.currentIndex === c && y.progressMessage === S && y.progressPercent === g || e.setState({
          batchNotebookActions: {
            ...y,
            currentIndex: c,
            progressMessage: S,
            progressPercent: g
          }
        });
      };
      if (!n && t.length > 0) {
        await p([
          t[0]
        ], true);
        const f = t.slice(1);
        for (let d = 0; d < f.length; d += r) {
          const w = f.slice(d, d + r);
          await p(w, false);
        }
      } else
        for (let f = 0; f < t.length; f += r) {
          const d = t.slice(f, f + r);
          await p(d, f === 0);
        }
      return u.length > 0 && (T0(e, u), console.warn(`Failed to add ${u.length} links:`, u)), i && o && await a0(e, i, o, {
        msgPrefix: "Sources added. ",
        setProgress: sd,
        dispatchFn: S0,
        existingSourceIds: l
      }), i && await Md(i), E0(e, true), setTimeout(() => {
        e.setState({
          batchNotebookActions: Io
        });
      }, 3e3), i;
    } catch (l) {
      return Do(e, l.message), sd(e, null, 0), false;
    } finally {
      k0(e, false);
    }
  }, Lv = (e) => {
    e.setState({
      batchNotebookActions: Io
    });
  }, _v = (e) => {
    if (!e || typeof e != "string")
      throw new Error("URL is required");
    let t;
    try {
      t = new URL(e);
    } catch {
      throw new Error("Invalid URL format");
    }
    if (![
      "http:",
      "https:"
    ].includes(t.protocol))
      throw new Error("Only HTTP(S) URLs are supported");
    const n = t.hostname.toLowerCase();
    if (n === "localhost" || n === "::1" || /^127\./.test(n))
      throw new Error("Internal network access not permitted");
    const r = [
      /^10\./,
      /^172\.(1[6-9]|2\d|3[01])\./,
      /^192\.168\./,
      /^169\.254\./,
      /^0\./,
      /^255\.255\.255\.255$/,
      /^224\./,
      /^239\./
    ];
    for (const a of r)
      if (a.test(n))
        throw new Error("Internal network access not permitted");
    if ((n.startsWith("[") || n.includes(":")) && (n.startsWith("fc") || n.startsWith("fd") || n.startsWith("fe80")))
      throw new Error("Internal network access not permitted");
    return t.href;
  }, Rv = 3e4, Ov = 5, Fv = async (e, t, n) => {
    const r = [], a = [];
    for (const o of e) {
      const s = n(o).then((l) => (a.splice(a.indexOf(s), 1), l));
      r.push(s), a.push(s), a.length >= t && await Promise.race(a);
    }
    return Promise.all(r);
  }, x0 = {
    isExtracting: false,
    links: [],
    error: null,
    abortController: null
  }, Wl = (e, t) => {
    e.setState({
      linksExtractor: {
        ...e.state.linksExtractor,
        isExtracting: t
      }
    });
  }, Cc = (e, t) => {
    e.setState({
      linksExtractor: {
        ...e.state.linksExtractor,
        links: t
      }
    });
  }, Uo = (e, t) => {
    e.setState({
      linksExtractor: {
        ...e.state.linksExtractor,
        error: t
      }
    });
  }, Iv = (e) => {
    e.setState({
      linksExtractor: {
        ...e.state.linksExtractor,
        links: [],
        error: null
      }
    });
  }, Dv = async (e, t) => {
    var _a2;
    try {
      Wl(e, true), Uo(e, null);
      const r = ((_a2 = (await chrome.scripting.executeScript({
        target: {
          tabId: t
        },
        func: () => Array.from(document.querySelectorAll("a[href]")).map((s) => {
          try {
            return new URL(s.href, window.location.href).href;
          } catch {
            return null;
          }
        }).filter((s) => s && (s.startsWith("http://") || s.startsWith("https://")))
      }))[0]) == null ? void 0 : _a2.result) || [], a = [
        ...new Set(r)
      ];
      return Cc(e, a), a;
    } catch (n) {
      return Uo(e, n.message), [];
    } finally {
      Wl(e, false);
    }
  }, A0 = async (e, t = 0, n = 5, r = null) => {
    if (t > n)
      return [];
    try {
      const a = _v(e), o = Ed(Rv), s = r ? Yg([
        r,
        o
      ]) : null, l = s ? s.signal : o;
      let i;
      try {
        const S = await fetch(a, {
          signal: l
        });
        if (!S.ok)
          throw new Error(`Failed to fetch sitemap: ${S.status}`);
        i = await S.text();
      } finally {
        s == null ? void 0 : s.cleanup();
      }
      const u = new DOMParser().parseFromString(i, "text/xml");
      if (u.querySelector("parsererror"))
        throw new Error("Failed to parse sitemap XML");
      const f = [], d = u.querySelectorAll("sitemap > loc");
      if (d.length > 0) {
        const S = Array.from(d).map((m) => m.textContent.trim());
        (await Fv(S, Ov, (m) => A0(m, t + 1, n, r))).forEach((m) => f.push(...m));
      }
      const w = u.querySelectorAll("urlset > url > loc"), y = Array.from(w).map((S) => S.textContent.trim());
      return f.push(...y), f;
    } catch (a) {
      throw a.name === "AbortError" ? new Error("Request timed out or was cancelled") : (console.error(`Error parsing sitemap ${e}:`, a), a);
    }
  }, Uv = async (e, t) => {
    M0(e);
    const n = new AbortController();
    try {
      e.setState({
        linksExtractor: {
          ...e.state.linksExtractor,
          isExtracting: true,
          error: null,
          abortController: n
        }
      });
      const r = await A0(t, 0, 5, n.signal), a = [
        ...new Set(r)
      ];
      return Cc(e, a), a;
    } catch (r) {
      return r.name !== "AbortError" && Uo(e, r.message), [];
    } finally {
      e.setState({
        linksExtractor: {
          ...e.state.linksExtractor,
          isExtracting: false,
          abortController: null
        }
      });
    }
  }, M0 = (e) => {
    const { abortController: t } = e.state.linksExtractor;
    t && (t.abort(), e.setState({
      linksExtractor: {
        ...e.state.linksExtractor,
        isExtracting: false,
        abortController: null
      }
    }));
  }, $v = (e) => {
    M0(e), e.setState({
      linksExtractor: {
        ...x0,
        abortController: null
      }
    });
  }, Nc = {
    isAdding: false,
    addSuccess: false,
    actionType: null,
    error: null,
    progressMessage: null,
    progressPercent: 0
  }, C0 = (e, t) => {
    e.setState({
      notebookActions: {
        ...e.state.notebookActions,
        isAdding: t
      }
    });
  }, N0 = (e, t) => {
    e.setState({
      notebookActions: {
        ...e.state.notebookActions,
        addSuccess: t
      }
    });
  }, jv = (e, t) => {
    e.setState({
      notebookActions: {
        ...e.state.notebookActions,
        actionType: t
      }
    });
  }, Pc = (e, t) => {
    e.setState({
      notebookActions: {
        ...e.state.notebookActions,
        error: t
      }
    }), t && setTimeout(() => Pc(e, null), 4e3);
  };
  function zv(e, t) {
    e.setState({
      notebookActions: {
        ...Nc,
        isAdding: true,
        actionType: t ? "existing" : "new"
      }
    });
  }
  function Bv(e) {
    e.setState({
      notebookActions: {
        ...e.state.notebookActions,
        progressMessage: null,
        progressPercent: 0
      }
    });
  }
  function Vv(e, t) {
    return t ? Math.round(e * fa) : e;
  }
  function ld(e, t, n) {
    const r = e.state.notebookActions;
    r.progressMessage === t && r.progressPercent === n || e.setState({
      notebookActions: {
        ...r,
        progressMessage: t,
        progressPercent: n
      }
    });
  }
  async function P0(e, t, n, r) {
    const a = (r == null ? void 0 : r.selection) ?? null, o = (r == null ? void 0 : r.scope) ?? so.NEW;
    try {
      zv(e, n);
      const s = a && o === so.NEW ? await r0(n) : null, l = await t({
        notebookId: n,
        onProgress: ({ message: i, progress: c }) => {
          ld(e, i, Vv(c, a));
        }
      });
      return a && await a0(e, l, a, {
        msgPrefix: "Source added. ",
        setProgress: ld,
        dispatchFn: S0,
        existingSourceIds: s
      }), await Md(l), N0(e, true), setTimeout(() => b0(e), 2e3), l;
    } catch (s) {
      return Pc(e, s.message), Bv(e), false;
    } finally {
      C0(e, false);
    }
  }
  let Hv, Gv, b0, L0, _0, $o, R0, O0, F0, I0, Wv, Yv, Yl, D0, Qv, Zv, Kv, St, U0, Xv, qv, Jv, $0, eS, tS, nS, rS, aS, j0, oS, sS, lS, iS, cS, uS, dS, fS, pS, gS, z0, mS, hS, yS, wS, vS, SS, B0, kS, V0, H0, G0, Ql, Hr, W0, Zl, cr, ES, TS, xS, AS, MS, PS, bS, LS, _S, Y, Hs, RS, OS, FS, Y0, IS, Q0, Z0, K0, Kl, Gr, X0, Xl, ur, DS, US, $S, jS, ql, ro, zS, BS, VS, HS, q0, J0, eg, Jl, jo, ei, dr, GS, WS, YS, QS, ZS, KS, ln, fr;
  Hv = (e, t, n = null, { generateConfig: r = null } = {}) => P0(e, (a) => Ad({
    url: t.url,
    title: t.title,
    ...a
  }), n, r);
  Gv = (e, t, n = null, { generateConfig: r = null } = {}) => P0(e, (a) => Qg({
    text: t,
    ...a
  }), n, r);
  b0 = (e) => {
    e.setState({
      notebookActions: Nc
    });
  };
  L0 = {
    tabInfo: null,
    loading: true,
    error: null,
    isInNewTab: false
  };
  _0 = (e, t) => {
    e.setState({
      tabInfo: {
        ...e.state.tabInfo,
        tabInfo: t
      }
    });
  };
  $o = (e, t) => {
    e.setState({
      tabInfo: {
        ...e.state.tabInfo,
        loading: t
      }
    });
  };
  R0 = (e, t) => {
    e.setState({
      tabInfo: {
        ...e.state.tabInfo,
        error: t
      }
    });
  };
  O0 = (e, t) => {
    e.setState({
      tabInfo: {
        ...e.state.tabInfo,
        isInNewTab: t
      }
    });
  };
  F0 = (e) => {
    const t = window.location.href, n = t.includes("popup=true"), r = t.includes("popup.html") && !n;
    O0(e, r);
  };
  I0 = async (e) => {
    var _a2;
    try {
      $o(e, true);
      const [t] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      t && _0(e, {
        id: t.id,
        title: t.title,
        url: t.url,
        favIconUrl: t.favIconUrl,
        status: t.status,
        isNotebookLM: (_a2 = t.url) == null ? void 0 : _a2.includes("notebooklm.google.com")
      });
    } catch (t) {
      R0(e, t.message);
    } finally {
      $o(e, false);
    }
  };
  Wv = (e) => {
    F0(e), e.state.tabInfo.isInNewTab ? $o(e, false) : I0(e);
  };
  Yv = (e) => {
    e.setState({
      tabInfo: L0
    });
  };
  Yl = [
    "gray",
    "red",
    "orange",
    "yellow",
    "green",
    "teal",
    "blue",
    "indigo",
    "purple",
    "pink"
  ];
  D0 = () => `tag_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  Qv = () => Yl[Math.floor(Math.random() * Yl.length)];
  Zv = {
    tags: {},
    notebookTags: {},
    isLoaded: false,
    selectedTagFilter: [],
    showUntagged: false,
    tagSearchQuery: ""
  };
  Kv = async (e) => {
    try {
      const t = await k.get(Cd);
      t ? e.setState({
        ...e.state,
        notebookTags: {
          ...e.state.notebookTags,
          tags: t.tags || {},
          notebookTags: t.notebookTags || {},
          isLoaded: true
        }
      }) : e.setState({
        ...e.state,
        notebookTags: {
          ...e.state.notebookTags,
          isLoaded: true
        }
      });
    } catch (t) {
      console.error("Failed to load tags:", t), e.setState({
        ...e.state,
        notebookTags: {
          ...e.state.notebookTags,
          isLoaded: true
        }
      });
    }
  };
  St = async (e) => {
    const { tags: t, notebookTags: n } = e.state.notebookTags;
    await k.set(Cd, {
      tags: t,
      notebookTags: n
    });
  };
  U0 = async (e, t, n = null) => {
    const r = t.trim();
    if (!r)
      return null;
    const a = Object.values(e.state.notebookTags.tags).find((l) => l.name.toLowerCase() === r.toLowerCase());
    if (a)
      return a;
    const o = {
      id: D0(),
      name: r,
      color: n || Qv(),
      createdAt: Date.now()
    }, s = {
      ...e.state.notebookTags.tags,
      [o.id]: o
    };
    return e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        tags: s
      }
    }), await St(e), o;
  };
  Xv = async (e, t, n) => {
    const r = e.state.notebookTags.tags[t];
    if (!r)
      return null;
    if (n.name) {
      const o = n.name.trim();
      if (Object.values(e.state.notebookTags.tags).find((l) => l.id !== t && l.name.toLowerCase() === o.toLowerCase()))
        return null;
      n.name = o;
    }
    const a = {
      ...r,
      ...n
    };
    return e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        tags: {
          ...e.state.notebookTags.tags,
          [t]: a
        }
      }
    }), await St(e), a;
  };
  qv = async (e, t) => {
    const { tags: n, notebookTags: r } = e.state.notebookTags, a = {
      ...n
    };
    delete a[t];
    const o = {};
    for (const [i, c] of Object.entries(r)) {
      const u = c.filter((p) => p !== t);
      u.length > 0 && (o[i] = u);
    }
    const l = (e.state.notebookTags.selectedTagFilter || []).filter((i) => i !== t);
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        tags: a,
        notebookTags: o,
        selectedTagFilter: l
      }
    }), await St(e);
  };
  Jv = async (e, t, n) => {
    const { tags: r, notebookTags: a, selectedTagFilter: o } = e.state.notebookTags;
    if (!r[t] || !r[n])
      return;
    const s = {
      ...a
    };
    for (const u of Object.keys(s)) {
      const p = s[u];
      if (p.includes(t)) {
        const f = p.filter((d) => d !== t);
        f.includes(n) || f.push(n), s[u] = f;
      }
    }
    const { [t]: l, ...i } = r, c = o.filter((u) => u !== t);
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        tags: i,
        notebookTags: s,
        selectedTagFilter: c
      }
    }), await St(e);
  };
  $0 = async (e, t, n) => {
    const { notebookTags: r } = e.state.notebookTags, a = r[t] || [];
    if (a.includes(n))
      return;
    const o = {
      ...r,
      [t]: [
        ...a,
        n
      ]
    };
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        notebookTags: o
      }
    }), await St(e);
  };
  eS = async (e, t, n) => {
    const { notebookTags: r } = e.state.notebookTags, o = (r[t] || []).filter((l) => l !== n), s = {
      ...r
    };
    o.length > 0 ? s[t] = o : delete s[t], e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        notebookTags: s
      }
    }), await St(e);
  };
  tS = async (e, t, n) => {
    const { notebookTags: r } = e.state.notebookTags, a = {
      ...r
    };
    n.length > 0 ? a[t] = n : delete a[t], e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        notebookTags: a
      }
    }), await St(e);
  };
  nS = async (e, t, n) => {
    const { notebookTags: r } = e.state.notebookTags, a = {
      ...r
    };
    for (const o of t) {
      const s = a[o] || [];
      a[o] = [
        .../* @__PURE__ */ new Set([
          ...s,
          ...n
        ])
      ];
    }
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        notebookTags: a
      }
    }), await St(e);
  };
  rS = async (e, t, n) => {
    const { notebookTags: r } = e.state.notebookTags, a = {
      ...r
    };
    for (const o of t)
      n.length > 0 ? a[o] = [
        ...n
      ] : delete a[o];
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        notebookTags: a
      }
    }), await St(e);
  };
  aS = (e, t) => {
    const { tags: n, notebookTags: r } = e.state.notebookTags;
    return (r[t] || []).map((o) => n[o]).filter(Boolean);
  };
  j0 = (e) => Object.values(e.state.notebookTags.tags).sort((t, n) => t.name.localeCompare(n.name));
  oS = (e, t) => {
    const n = j0(e);
    if (!t.trim())
      return n;
    const r = t.toLowerCase();
    return n.filter((a) => a.name.toLowerCase().includes(r));
  };
  sS = (e, t) => {
    const n = Array.isArray(t) ? t : t ? [
      t
    ] : [];
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        selectedTagFilter: n,
        showUntagged: false
      }
    });
  };
  lS = (e, t) => {
    const n = e.state.notebookTags.selectedTagFilter || [], r = n.includes(t) ? n.filter((a) => a !== t) : [
      ...n,
      t
    ];
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        selectedTagFilter: r,
        showUntagged: false
      }
    });
  };
  iS = (e, t) => {
    const { showUntagged: n } = e.state.notebookTags;
    if (n === t)
      return;
    const r = {
      showUntagged: t
    };
    t && (r.selectedTagFilter = []), e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        ...r
      }
    });
  };
  cS = (e) => {
    const { selectedTagFilter: t, showUntagged: n } = e.state.notebookTags;
    t.length === 0 && !n || e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        selectedTagFilter: [],
        showUntagged: false
      }
    });
  };
  uS = (e, t) => {
    e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        tagSearchQuery: t
      }
    });
  };
  dS = (e) => {
    const { notebookTags: t } = e.state.notebookTags, n = {};
    for (const r of Object.values(t))
      for (const a of r)
        n[a] = (n[a] || 0) + 1;
    return n;
  };
  fS = async (e, t, n, r = null) => {
    const a = await U0(e, n, r);
    return a && await $0(e, t, a.id), a;
  };
  pS = (e) => {
    const { tags: t, notebookTags: n } = e.state.notebookTags, r = Object.values(t).map(({ id: a, name: o, color: s }) => ({
      id: a,
      name: o,
      color: s
    }));
    return {
      version: "1.0",
      type: "notebooklm-tags",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      tags: r,
      notebookTags: n
    };
  };
  gS = async (e, t) => {
    if (!t || t.type !== "notebooklm-tags" || !t.tags)
      throw new Error("Invalid backup file format");
    const { tags: n, notebookTags: r } = e.state.notebookTags, a = new Set(Object.values(n).map((u) => u.name.toLowerCase())), o = Array.isArray(t.tags) ? t.tags : Object.values(t.tags), s = {
      ...n
    }, l = {};
    let i = 0;
    for (const u of o) {
      const p = u.id;
      if (a.has(u.name.toLowerCase())) {
        const d = Object.values(n).find((w) => w.name.toLowerCase() === u.name.toLowerCase());
        d && (l[p] = d.id);
        continue;
      }
      const f = D0();
      l[p] = f, s[f] = {
        id: f,
        name: u.name,
        color: u.color,
        createdAt: Date.now()
      }, a.add(u.name.toLowerCase()), i++;
    }
    const c = {
      ...r
    };
    for (const [u, p] of Object.entries(t.notebookTags || {})) {
      const f = p.map((d) => l[d]).filter(Boolean);
      if (f.length > 0) {
        const d = c[u] || [], w = [
          .../* @__PURE__ */ new Set([
            ...d,
            ...f
          ])
        ];
        c[u] = w;
      }
    }
    return e.setState({
      ...e.state,
      notebookTags: {
        ...e.state.notebookTags,
        tags: s,
        notebookTags: c
      }
    }), await St(e), i;
  };
  n2 = Yl;
  z0 = (e) => {
    if (!e)
      return null;
    try {
      const t = new URL(e);
      if (t.hostname.replace("www.", "") !== "youtube.com")
        return null;
      const r = t.searchParams.get("list");
      return r && r.startsWith("PL") || r ? r : null;
    } catch {
      return null;
    }
  };
  r2 = (e) => z0(e) !== null;
  a2 = (e) => `https://www.youtube.com/watch?v=${e}`;
  mS = (e) => `https://www.youtube.com/playlist?list=${e}`;
  hS = async (e) => {
    try {
      const t = await fetch(e, {
        headers: {
          "Accept-Language": "en-US,en;q=0.9"
        }
      });
      if (!t.ok)
        throw new Error(`Failed to fetch playlist: ${t.status}`);
      const n = await t.text();
      return yS(n);
    } catch (t) {
      throw console.error("Error fetching playlist:", t), new Error(t.message || "Failed to fetch playlist");
    }
  };
  yS = (e) => {
    var _a2, _b, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j, _k2, _l2;
    const t = e.match(/var ytInitialData\s*=\s*({.+?});<\/script>/);
    if (!t)
      throw new Error("Could not find playlist data in page");
    let n;
    try {
      n = JSON.parse(t[1]);
    } catch {
      throw new Error("Failed to parse playlist data");
    }
    const a = (_j = (_i2 = (_h2 = (_g2 = (_f2 = (_e2 = (_d2 = (_c2 = (_b = (_a2 = n == null ? void 0 : n.contents) == null ? void 0 : _a2.twoColumnBrowseResultsRenderer) == null ? void 0 : _b.tabs) == null ? void 0 : _c2[0]) == null ? void 0 : _d2.tabRenderer) == null ? void 0 : _e2.content) == null ? void 0 : _f2.sectionListRenderer) == null ? void 0 : _g2.contents) == null ? void 0 : _h2[0]) == null ? void 0 : _i2.itemSectionRenderer) == null ? void 0 : _j.contents, o = ((_l2 = (_k2 = a == null ? void 0 : a[0]) == null ? void 0 : _k2.playlistVideoListRenderer) == null ? void 0 : _l2.contents) || a;
    if (!o)
      throw new Error("Could not find videos in playlist");
    const s = wS(n == null ? void 0 : n.header), l = o.map((i) => {
      var _a3;
      return i.playlistVideoRenderer ? vS(i.playlistVideoRenderer) : ((_a3 = i.lockupViewModel) == null ? void 0 : _a3.contentType) === "LOCKUP_CONTENT_TYPE_VIDEO" ? SS(i.lockupViewModel) : null;
    }).filter(Boolean);
    return {
      playlistInfo: s,
      videos: l
    };
  };
  wS = (e) => {
    var _a2, _b, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j, _k2, _l2, _m2, _n2, _o2, _p2, _q, _r2, _s2, _t2, _u2, _v2, _w2, _x, _y2, _z, _A, _B, _C, _D;
    const t = e == null ? void 0 : e.pageHeaderRenderer;
    if (t) {
      const r = (_a2 = t == null ? void 0 : t.content) == null ? void 0 : _a2.pageHeaderViewModel, o = ((_c2 = (_b = r == null ? void 0 : r.metadata) == null ? void 0 : _b.contentMetadataViewModel) == null ? void 0 : _c2.metadataRows) || [], s = (t == null ? void 0 : t.pageTitle) || ((_f2 = (_e2 = (_d2 = r == null ? void 0 : r.title) == null ? void 0 : _d2.dynamicTextViewModel) == null ? void 0 : _e2.text) == null ? void 0 : _f2.content) || "Unknown Playlist";
      let l = "Unknown";
      const i = (_h2 = (_g2 = o[0]) == null ? void 0 : _g2.metadataParts) == null ? void 0 : _h2[0];
      ((_k2 = (_j = (_i2 = i == null ? void 0 : i.avatarStack) == null ? void 0 : _i2.avatarStackViewModel) == null ? void 0 : _j.text) == null ? void 0 : _k2.content) && (l = i.avatarStack.avatarStackViewModel.text.content.replace(/^by\s+/i, ""));
      let c = 0;
      const u = ((_l2 = o[1]) == null ? void 0 : _l2.metadataParts) || [];
      for (const d of u) {
        const y = (((_m2 = d == null ? void 0 : d.text) == null ? void 0 : _m2.content) || "").match(/(\d+)\s*videos?/i);
        if (y) {
          c = parseInt(y[1], 10);
          break;
        }
      }
      const p = ((_p2 = (_o2 = (_n2 = r == null ? void 0 : r.heroImage) == null ? void 0 : _n2.contentPreviewImageViewModel) == null ? void 0 : _o2.image) == null ? void 0 : _p2.sources) || [], f = ((_q = p[p.length - 1]) == null ? void 0 : _q.url) || ((_r2 = p[0]) == null ? void 0 : _r2.url);
      return {
        title: s,
        videoCount: c,
        channelName: l,
        thumbnailUrl: f
      };
    }
    const n = e == null ? void 0 : e.playlistHeaderRenderer;
    return {
      title: ((_s2 = n == null ? void 0 : n.title) == null ? void 0 : _s2.simpleText) || "Unknown Playlist",
      videoCount: parseInt(((_v2 = (_u2 = (_t2 = n == null ? void 0 : n.numVideosText) == null ? void 0 : _t2.runs) == null ? void 0 : _u2[0]) == null ? void 0 : _v2.text) || "0"),
      channelName: ((_y2 = (_x = (_w2 = n == null ? void 0 : n.ownerText) == null ? void 0 : _w2.runs) == null ? void 0 : _x[0]) == null ? void 0 : _y2.text) || "Unknown",
      thumbnailUrl: (_D = (_C = (_B = (_A = (_z = n == null ? void 0 : n.playlistHeaderBanner) == null ? void 0 : _z.heroPlaylistThumbnailRenderer) == null ? void 0 : _A.thumbnail) == null ? void 0 : _B.thumbnails) == null ? void 0 : _C[0]) == null ? void 0 : _D.url
    };
  };
  vS = (e) => {
    var _a2, _b, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j, _k2, _l2, _m2, _n2;
    const t = e.videoId, n = ((_c2 = (_b = (_a2 = e.title) == null ? void 0 : _a2.runs) == null ? void 0 : _b[0]) == null ? void 0 : _c2.text) || "Unknown Title", r = (_f2 = (_e2 = (_d2 = e.thumbnail) == null ? void 0 : _d2.thumbnails) == null ? void 0 : _e2[0]) == null ? void 0 : _f2.url, a = ((_i2 = (_h2 = (_g2 = e.shortBylineText) == null ? void 0 : _g2.runs) == null ? void 0 : _h2[0]) == null ? void 0 : _i2.text) || "Unknown Channel", o = ((_j = e.lengthText) == null ? void 0 : _j.simpleText) || "", s = B0(o), l = e.isPlayable !== false, i = ((_k2 = e.videoInfo) == null ? void 0 : _k2.runs) || [], c = l && ((_l2 = i[0]) == null ? void 0 : _l2.text) || "", u = l && ((_m2 = i[2]) == null ? void 0 : _m2.text) || "", p = l ? null : ((_n2 = i[0]) == null ? void 0 : _n2.text) || "Video unavailable";
    return {
      id: t,
      title: n,
      duration: o || "--:--",
      durationSeconds: s,
      thumbnailUrl: r,
      channelName: a,
      isAvailable: l,
      unavailableReason: p,
      viewCountText: c,
      uploadDateText: u
    };
  };
  SS = (e) => {
    var _a2, _b, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j, _k2, _l2, _m2, _n2, _o2, _p2, _q, _r2, _s2, _t2, _u2, _v2, _w2;
    const t = e.contentId, n = (_a2 = e.metadata) == null ? void 0 : _a2.lockupMetadataViewModel, r = ((_b = n == null ? void 0 : n.title) == null ? void 0 : _b.content) || "Unknown Title", a = (_c2 = e.contentImage) == null ? void 0 : _c2.thumbnailViewModel, o = (_f2 = (_e2 = (_d2 = a == null ? void 0 : a.image) == null ? void 0 : _d2.sources) == null ? void 0 : _e2[0]) == null ? void 0 : _f2.url, s = ((_h2 = (_g2 = n == null ? void 0 : n.metadata) == null ? void 0 : _g2.contentMetadataViewModel) == null ? void 0 : _h2.metadataRows) || [], l = ((_l2 = (_k2 = (_j = (_i2 = s[0]) == null ? void 0 : _i2.metadataParts) == null ? void 0 : _j[0]) == null ? void 0 : _k2.text) == null ? void 0 : _l2.content) || "Unknown Channel", i = ((_p2 = (_o2 = (_n2 = (_m2 = s[1]) == null ? void 0 : _m2.metadataParts) == null ? void 0 : _n2[0]) == null ? void 0 : _o2.text) == null ? void 0 : _p2.content) || "", c = ((_t2 = (_s2 = (_r2 = (_q = s[1]) == null ? void 0 : _q.metadataParts) == null ? void 0 : _r2[1]) == null ? void 0 : _s2.text) == null ? void 0 : _t2.content) || "";
    let u = "";
    for (const p of (a == null ? void 0 : a.overlays) || []) {
      const d = (_w2 = (_v2 = (((_u2 = p.thumbnailBottomOverlayViewModel) == null ? void 0 : _u2.badges) || []).find((w) => {
        var _a3;
        return (_a3 = w.thumbnailBadgeViewModel) == null ? void 0 : _a3.text;
      })) == null ? void 0 : _v2.thumbnailBadgeViewModel) == null ? void 0 : _w2.text;
      if (d) {
        u = d;
        break;
      }
    }
    return {
      id: t,
      title: r,
      duration: u || "--:--",
      durationSeconds: B0(u),
      thumbnailUrl: o,
      channelName: l,
      isAvailable: true,
      unavailableReason: null,
      viewCountText: i,
      uploadDateText: c
    };
  };
  B0 = (e) => {
    if (!e)
      return 0;
    const t = e.split(":").map(Number);
    return t.length === 3 ? t[0] * 3600 + t[1] * 60 + t[2] : t.length === 2 ? t[0] * 60 + t[1] : 0;
  };
  kS = 5e3;
  V0 = (e) => e.filter((t) => t.isAvailable).map((t) => t.id);
  H0 = {
    playlistUrl: "",
    isParsing: false,
    parseError: null,
    playlistInfo: null,
    videos: [],
    selectedVideoIds: []
  };
  G0 = (e, t) => {
    e.setState({
      playlistImport: {
        ...e.state.playlistImport,
        playlistUrl: t
      }
    });
  };
  Ql = (e, t) => {
    e.setState({
      playlistImport: {
        ...e.state.playlistImport,
        isParsing: t
      }
    });
  };
  Hr = (e, t) => {
    e.setState({
      playlistImport: {
        ...e.state.playlistImport,
        parseError: t
      }
    }), t && setTimeout(() => Hr(e, null), kS);
  };
  W0 = (e, t) => {
    e.setState({
      playlistImport: {
        ...e.state.playlistImport,
        playlistInfo: t
      }
    });
  };
  Zl = (e, t) => {
    e.setState({
      playlistImport: {
        ...e.state.playlistImport,
        videos: t
      }
    });
  };
  cr = (e, t) => {
    e.setState({
      playlistImport: {
        ...e.state.playlistImport,
        selectedVideoIds: t
      }
    });
  };
  ES = (e, t) => {
    const { selectedVideoIds: n } = e.state.playlistImport, r = n.includes(t) ? n.filter((a) => a !== t) : [
      ...n,
      t
    ];
    cr(e, r);
  };
  TS = (e) => {
    const { videos: t } = e.state.playlistImport;
    cr(e, V0(t));
  };
  xS = (e) => {
    cr(e, []);
  };
  AS = async (e, t) => {
    const n = z0(t);
    if (!n) {
      Hr(e, "Invalid playlist URL");
      return;
    }
    try {
      Ql(e, true), Hr(e, null), Zl(e, []), cr(e, []);
      const r = mS(n);
      G0(e, r);
      const a = await hS(r);
      W0(e, a.playlistInfo), Zl(e, a.videos), cr(e, V0(a.videos));
    } catch (r) {
      Hr(e, r.message || "Failed to parse playlist");
    } finally {
      Ql(e, false);
    }
  };
  MS = (e) => {
    e.setState({
      playlistImport: H0
    });
  };
  o2 = (e) => {
    if (!e)
      return false;
    try {
      const t = new URL(e), n = t.pathname.toLowerCase(), r = t.hostname.toLowerCase();
      if ([
        /\/feed\/?$/,
        /\/rss\/?$/,
        /\/atom\/?$/,
        /\/feed\.xml$/,
        /\/rss\.xml$/,
        /\/atom\.xml$/,
        /\/index\.xml$/,
        /\.rss$/,
        /\.atom$/,
        /\/feeds?\//
      ].some((s) => s.test(n)))
        return true;
      const o = t.searchParams.get("format");
      return !!(o && [
        "rss",
        "atom",
        "feed",
        "xml"
      ].includes(o.toLowerCase()) || r.startsWith("feeds.") || r.startsWith("rss."));
    } catch {
      return false;
    }
  };
  CS = (e) => {
    if (!e)
      return "";
    let t = e.trim();
    return !t.startsWith("http://") && !t.startsWith("https://") && (t = "https://" + t), t;
  };
  NS = (e) => {
    try {
      return new URL(e), true;
    } catch {
      return false;
    }
  };
  PS = async (e) => {
    try {
      const t = await fetch(e, {
        headers: {
          Accept: "application/rss+xml, application/atom+xml, application/xml, text/xml"
        }
      });
      if (!t.ok)
        throw new Error(`Failed to fetch feed: ${t.status}`);
      const n = await t.text();
      return bS(n, e);
    } catch (t) {
      throw console.error("Error fetching feed:", t), t.message.includes("Failed to fetch") ? new Error("Could not fetch feed. Check URL or CORS policy.") : new Error(t.message || "Failed to fetch feed");
    }
  };
  bS = (e, t) => {
    const r = new DOMParser().parseFromString(e, "text/xml");
    if (r.querySelector("parsererror"))
      throw new Error("Invalid feed format");
    const o = r.querySelector("rss"), s = r.querySelector("feed");
    if (o)
      return LS(r, t);
    if (s)
      return _S(r, t);
    throw new Error("Unknown feed format. Expected RSS or Atom.");
  };
  LS = (e, t) => {
    const n = e.querySelector("channel");
    if (!n)
      throw new Error("Invalid RSS feed: no channel element");
    const r = {
      title: Y(n, "title") || "Unknown Feed",
      description: Y(n, "description") || "",
      link: Y(n, "link") || t,
      feedUrl: t,
      imageUrl: Y(n, "image > url") || RS(n),
      lastUpdated: Y(n, "lastBuildDate") || Y(n, "pubDate")
    }, a = n.querySelectorAll("item"), o = Array.from(a).map((s, l) => ({
      id: Y(s, "guid") || Y(s, "link") || `article-${l}`,
      title: Y(s, "title") || "Untitled",
      description: Y0(Y(s, "description") || ""),
      url: Y(s, "link") || "",
      author: Y(s, "author") || Y(s, "dc\\:creator") || "",
      publishDate: Y(s, "pubDate"),
      thumbnailUrl: OS(s),
      isAvailable: true
    }));
    return {
      feedInfo: r,
      articles: o
    };
  };
  _S = (e, t) => {
    const n = e.querySelector("feed");
    if (!n)
      throw new Error("Invalid Atom feed: no feed element");
    const r = {
      title: Y(n, "title") || "Unknown Feed",
      description: Y(n, "subtitle") || "",
      link: Hs(n, "alternate") || t,
      feedUrl: t,
      imageUrl: Y(n, "icon") || Y(n, "logo"),
      lastUpdated: Y(n, "updated")
    }, a = n.querySelectorAll("entry"), o = Array.from(a).map((s, l) => ({
      id: Y(s, "id") || `article-${l}`,
      title: Y(s, "title") || "Untitled",
      description: Y0(Y(s, "summary") || Y(s, "content") || ""),
      url: Hs(s, "alternate") || Hs(s) || "",
      author: Y(s, "author > name") || "",
      publishDate: Y(s, "published") || Y(s, "updated"),
      thumbnailUrl: FS(s),
      isAvailable: true
    }));
    return {
      feedInfo: r,
      articles: o
    };
  };
  Y = (e, t) => {
    var _a2, _b;
    return ((_b = (_a2 = e.querySelector(t)) == null ? void 0 : _a2.textContent) == null ? void 0 : _b.trim()) || null;
  };
  Hs = (e, t) => {
    const n = e.querySelectorAll("link");
    for (const r of n) {
      const a = r.getAttribute("rel") || "alternate";
      if (!t || a === t)
        return r.getAttribute("href");
    }
    return null;
  };
  RS = (e) => {
    const t = e.querySelector("itunes\\:image, image[href]");
    return t ? t.getAttribute("href") : null;
  };
  OS = (e) => {
    var _a2;
    const t = e.querySelector("media\\:thumbnail");
    if (t)
      return t.getAttribute("url");
    const n = e.querySelector("media\\:content");
    if (n && n.getAttribute("medium") === "image")
      return n.getAttribute("url");
    const r = e.querySelector("enclosure");
    return r && ((_a2 = r.getAttribute("type")) == null ? void 0 : _a2.startsWith("image/")) ? r.getAttribute("url") : null;
  };
  FS = (e) => {
    const t = e.querySelector("media\\:thumbnail");
    if (t)
      return t.getAttribute("url");
    const n = e.querySelectorAll("link");
    for (const r of n)
      if ((r.getAttribute("type") || "").startsWith("image/"))
        return r.getAttribute("href");
    return null;
  };
  Y0 = (e) => {
    if (!e)
      return "";
    const t = e.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "").replace(/<[^>]*>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/\s+/g, " ").trim();
    return t.slice(0, 200) + (t.length > 200 ? "..." : "");
  };
  IS = 5e3;
  Q0 = (e) => e.filter((t) => t.isAvailable).map((t) => t.id);
  Z0 = {
    feedUrl: "",
    isParsing: false,
    parseError: null,
    feedInfo: null,
    articles: [],
    selectedArticleIds: [],
    isDetecting: false,
    detectionError: null
  };
  K0 = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        feedUrl: t
      }
    });
  };
  Kl = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        isParsing: t
      }
    });
  };
  Gr = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        parseError: t
      }
    }), t && setTimeout(() => Gr(e, null), IS);
  };
  X0 = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        feedInfo: t
      }
    });
  };
  Xl = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        articles: t
      }
    });
  };
  ur = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        selectedArticleIds: t
      }
    });
  };
  DS = (e, t) => {
    const { selectedArticleIds: n } = e.state.rssImport, r = n.includes(t) ? n.filter((a) => a !== t) : [
      ...n,
      t
    ];
    ur(e, r);
  };
  US = (e) => {
    const { articles: t } = e.state.rssImport;
    ur(e, Q0(t));
  };
  $S = (e) => {
    ur(e, []);
  };
  jS = async (e, t) => {
    const n = CS(t);
    if (!NS(n)) {
      Gr(e, "Invalid feed URL");
      return;
    }
    try {
      Kl(e, true), Gr(e, null), Xl(e, []), ur(e, []), K0(e, n);
      const r = await PS(n);
      X0(e, r.feedInfo), Xl(e, r.articles), ur(e, Q0(r.articles));
    } catch (r) {
      Gr(e, r.message || "Failed to parse feed");
    } finally {
      Kl(e, false);
    }
  };
  ql = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        isDetecting: t
      }
    });
  };
  ro = (e, t) => {
    e.setState({
      rssImport: {
        ...e.state.rssImport,
        detectionError: t
      }
    });
  };
  zS = async (e, t) => {
    var _a2;
    try {
      ql(e, true), ro(e, null);
      const r = ((_a2 = (await chrome.scripting.executeScript({
        target: {
          tabId: t
        },
        func: () => Array.from(document.querySelectorAll('link[rel="alternate"][type="application/rss+xml"], link[rel="alternate"][type="application/atom+xml"]')).map((o) => {
          try {
            const s = o.getAttribute("href");
            return s ? new URL(s, window.location.href).href : null;
          } catch {
            return null;
          }
        }).filter(Boolean)
      }))[0]) == null ? void 0 : _a2.result) || [];
      return r.length === 0 ? (ro(e, "No RSS feed found on this page"), null) : r[0];
    } catch (n) {
      return ro(e, n.message), null;
    } finally {
      ql(e, false);
    }
  };
  BS = (e) => {
    e.setState({
      rssImport: Z0
    });
  };
  VS = 5e3;
  HS = [
    "chrome://",
    "chrome-extension://",
    "about:",
    "edge://",
    "brave://",
    "opera://",
    "vivaldi://",
    "moz-extension://"
  ];
  q0 = (e) => e ? !HS.some((t) => e.startsWith(t)) : false;
  J0 = (e) => e.filter((t) => q0(t.url)).map((t) => t.id);
  eg = {
    isFetching: false,
    fetchError: null,
    tabs: [],
    selectedTabIds: []
  };
  Jl = (e, t) => {
    e.setState({
      openTabsImport: {
        ...e.state.openTabsImport,
        isFetching: t
      }
    });
  };
  jo = (e, t) => {
    e.setState({
      openTabsImport: {
        ...e.state.openTabsImport,
        fetchError: t
      }
    }), t && setTimeout(() => jo(e, null), VS);
  };
  ei = (e, t) => {
    e.setState({
      openTabsImport: {
        ...e.state.openTabsImport,
        tabs: t
      }
    });
  };
  dr = (e, t) => {
    e.setState({
      openTabsImport: {
        ...e.state.openTabsImport,
        selectedTabIds: t
      }
    });
  };
  GS = (e, t) => {
    const { selectedTabIds: n } = e.state.openTabsImport, r = n.includes(t) ? n.filter((a) => a !== t) : [
      ...n,
      t
    ];
    dr(e, r);
  };
  WS = (e) => {
    const { tabs: t } = e.state.openTabsImport;
    dr(e, J0(t));
  };
  YS = (e) => {
    dr(e, []);
  };
  QS = async (e) => {
    try {
      Jl(e, true), jo(e, null), ei(e, []), dr(e, []);
      const n = (await chrome.tabs.query({
        currentWindow: true
      })).map((r) => ({
        id: r.id,
        url: r.url,
        title: r.title || r.url,
        favIconUrl: r.favIconUrl,
        isValid: q0(r.url)
      }));
      ei(e, n), dr(e, J0(n));
    } catch (t) {
      jo(e, t.message || "Failed to fetch open tabs");
    } finally {
      Jl(e, false);
    }
  };
  ZS = (e) => {
    e.setState({
      openTabsImport: eg
    });
  };
  KS = 3;
  ln = `${Nd}_PODCAST_PROGRESS`;
  fr = `${Nd}_PODCAST_CACHE`;
  let zo = 0, Ne = null;
  const id = 5e3;
  let cd = 0;
  let bc, XS, qS, JS, Lc, e5, t5, n5, r5, a5, ud, o5, s5, l5, i5, _c, c5, u5, d5, f5, p5, ti, tg, g5, m5, ng, ga, h5, rg, y5, w5, v5, S5, k5, dd, E5, fd, pd, T5, x5, Wn, ag, M5, xt, og, sg, C5, ni, ri, lg, ig, N5, P5, b5, L5, _5, ae, R5, cg, O5;
  bc = {
    playlist: [],
    loading: false,
    error: null,
    scanProgress: {
      current: 0,
      total: 0
    },
    currentIndex: -1,
    isPlaying: false,
    isTransitioning: false,
    progressMap: {}
  };
  XS = async (e) => {
    const t = await k.get(ln) || {};
    return await e.setState({
      podcastPlayer: {
        ...e.state.podcastPlayer,
        progressMap: t
      }
    }), t;
  };
  qS = async (e, { limit: t = null } = {}) => {
    var _a2;
    const n = $(e.state), r = n == null ? void 0 : n.email;
    if (!(n == null ? void 0 : n.token))
      return await e.setState({
        podcastPlayer: {
          ...e.state.podcastPlayer,
          error: "Not authenticated with NotebookLM",
          loading: false
        }
      }), [];
    await e.setState({
      podcastPlayer: {
        ...e.state.podcastPlayer,
        loading: true,
        error: null,
        scanProgress: {
          current: 0,
          total: 0
        }
      }
    });
    const a = e.state.podcastPlayer.playlist || [];
    try {
      await Ta(e);
      const o = new ge(n.token, {
        ...n,
        onAuthError: me(e, n.email)
      }), s = e.state.notebooklm.projects || [];
      let l = s;
      t && t > 0 && (l = s.slice(0, t));
      const i = l.length;
      await e.setState({
        podcastPlayer: {
          ...e.state.podcastPlayer,
          scanProgress: {
            current: 0,
            total: i
          }
        }
      });
      const c = [];
      for (let g = 0; g < l.length; g++) {
        const m = l[g];
        await e.setState({
          podcastPlayer: {
            ...e.state.podcastPlayer,
            scanProgress: {
              current: g + 1,
              total: i
            }
          }
        });
        try {
          const h = await o.listArtifacts(m.id), A = ce.parseArtifacts(h).filter((T) => T.type === 1 && T.isReady);
          for (const T of A)
            c.push({
              id: T.id,
              notebookId: m.id,
              notebookTitle: m.title,
              notebookEmoji: m.emoji || "\u{1F4D3}",
              permissionCode: m.permissionCode ?? null,
              title: T.title || "Audio Overview",
              audioUrl: T.audioUrl,
              downloadUrl: T.downloadUrl,
              duration: T.duration || 0,
              createdAt: T.createdAt,
              isReady: T.isReady
            });
        } catch (h) {
          console.warn(`Failed to fetch artifacts for notebook ${m.id}:`, h);
        }
      }
      const u = new Map(c.map((g) => [
        g.id,
        g
      ])), p = new Set(s.map((g) => g.id)), f = new Set(l.map((g) => g.id)), d = new Map(s.map((g) => [
        g.id,
        g
      ])), w = [], y = /* @__PURE__ */ new Set();
      for (const g of a) {
        if (!p.has(g.notebookId))
          continue;
        if (!f.has(g.notebookId)) {
          const h = d.get(g.notebookId);
          w.push({
            ...g,
            notebookTitle: h.title,
            notebookEmoji: h.emoji || "\u{1F4D3}",
            permissionCode: h.permissionCode ?? g.permissionCode ?? null
          }), y.add(g.id);
          continue;
        }
        const m = u.get(g.id);
        m && (w.push(m), y.add(g.id));
      }
      for (const g of c)
        y.has(g.id) || w.push(g);
      if (w.sort((g, m) => new Date(m.createdAt) - new Date(g.createdAt)), ((_a2 = $(e.state)) == null ? void 0 : _a2.email) !== r)
        return a;
      const S = await k.get(ln) || {};
      return await e.setState({
        podcastPlayer: {
          ...e.state.podcastPlayer,
          playlist: w,
          loading: false,
          scanProgress: {
            current: i,
            total: i
          },
          progressMap: S
        }
      }), await k.set(fr, {
        lastScan: (/* @__PURE__ */ new Date()).toISOString(),
        playlist: w
      }), w;
    } catch (o) {
      return console.error("Failed to scan notebooks:", o), await e.setState({
        podcastPlayer: {
          ...e.state.podcastPlayer,
          error: o.message || "Failed to scan notebooks",
          loading: false
        }
      }), [];
    }
  };
  JS = async (e) => {
    var _a2;
    const t = await k.get(fr), n = await k.get(ln) || {};
    return ((_a2 = t == null ? void 0 : t.playlist) == null ? void 0 : _a2.length) ? (await e.setState({
      podcastPlayer: {
        ...e.state.podcastPlayer,
        playlist: t.playlist,
        progressMap: n
      }
    }), t.playlist) : [];
  };
  Lc = async (e, t) => {
    const { podcastPlayer: n } = e.state, r = ++cd;
    t < 0 || t >= n.playlist.length || n.isTransitioning || (await e.setState({
      podcastPlayer: {
        ...n,
        isTransitioning: true
      }
    }), await new Promise((a) => setTimeout(a, 50)), r === cd && await e.setState({
      podcastPlayer: {
        ...e.state.podcastPlayer,
        currentIndex: t,
        isPlaying: true,
        isTransitioning: false
      }
    }));
  };
  e5 = async (e) => {
    await e.setState({
      podcastPlayer: {
        ...e.state.podcastPlayer,
        isPlaying: false
      }
    });
  };
  t5 = async (e) => {
    const { podcastPlayer: t } = e.state;
    t.currentIndex >= 0 && await e.setState({
      podcastPlayer: {
        ...t,
        isPlaying: true
      }
    });
  };
  n5 = async (e, t = false) => {
    const { podcastPlayer: n } = e.state;
    if (n.isTransitioning)
      return;
    let r;
    return t ? r = a5(e, n.currentIndex) : r = n.currentIndex + 1, r >= 0 && r < n.playlist.length ? (await Lc(e, r), {
      played: true
    }) : (await e.setState({
      podcastPlayer: {
        ...n,
        currentIndex: -1,
        isPlaying: false
      }
    }), {
      played: false,
      noMoreUnlistened: t
    });
  };
  r5 = async (e) => {
    const { podcastPlayer: t } = e.state;
    if (t.isTransitioning)
      return;
    const n = t.currentIndex - 1;
    n >= 0 && await Lc(e, n);
  };
  a5 = (e, t) => {
    var _a2;
    const { playlist: n, progressMap: r } = e.state.podcastPlayer, a = n.length;
    for (let o = 1; o <= a; o++) {
      const s = (t + o) % a, l = n[s];
      if (!((_a2 = r[l.id]) == null ? void 0 : _a2.isListened))
        return s;
    }
    return -1;
  };
  ud = async (e) => {
    await k.set(ln, e), zo = Date.now(), Ne = null;
  };
  o5 = async (e) => {
    const { podcastPlayer: t } = e.state;
    Ne && (clearTimeout(Ne), Ne = null), await k.set(ln, t.progressMap), zo = Date.now();
  };
  s5 = async (e, t, n) => {
    const { podcastPlayer: r } = e.state, a = r.progressMap[t] || {}, o = n >= 0.9, s = {
      ...a,
      progress: n,
      lastPlayedAt: (/* @__PURE__ */ new Date()).toISOString(),
      isListened: a.isListened || o
    }, l = {
      ...r.progressMap,
      [t]: s
    };
    await e.setState({
      podcastPlayer: {
        ...r,
        progressMap: l
      }
    });
    const i = Date.now();
    i - zo >= id ? await ud(l) : Ne || (Ne = setTimeout(() => {
      ud(e.state.podcastPlayer.progressMap);
    }, id - (i - zo)));
  };
  l5 = async (e, t) => {
    const { podcastPlayer: n } = e.state, r = $(e.state), a = n.playlist.find((o) => o.id === t);
    if (!a || !(r == null ? void 0 : r.token))
      return null;
    try {
      const s = await new ge(r.token, {
        ...r,
        onAuthError: me(e, r.email)
      }).listArtifacts(a.notebookId), i = ce.parseArtifacts(s).find((u) => u.id === t);
      if (!(i == null ? void 0 : i.audioUrl))
        return null;
      const c = n.playlist.map((u) => u.id === t ? {
        ...u,
        audioUrl: i.audioUrl,
        downloadUrl: i.downloadUrl
      } : u);
      return await e.setState({
        podcastPlayer: {
          ...n,
          playlist: c
        }
      }), await k.set(fr, {
        lastScan: (/* @__PURE__ */ new Date()).toISOString(),
        playlist: c
      }), i.audioUrl;
    } catch (o) {
      return console.error("Failed to refresh audio URL:", o), null;
    }
  };
  i5 = async (e, t) => {
    var _a2;
    const { podcastPlayer: n } = e.state, r = $(e.state);
    if (!(r == null ? void 0 : r.token))
      return null;
    const a = new Set(t), o = n.playlist.filter((S) => a.has(S.id)), s = new ge(r.token, {
      ...r,
      onAuthError: me(e, r.email)
    }), l = /* @__PURE__ */ new Set();
    await pa(o, KS, async (S) => {
      try {
        await s.deleteArtifact(S.id, S.notebookId), l.add(S.id);
      } catch (g) {
        console.error(`Failed to delete podcast: ${S.title}`, g);
      }
    }), Ne && (clearTimeout(Ne), Ne = null);
    const { playlist: i, currentIndex: c, progressMap: u } = e.state.podcastPlayer, p = i.filter((S) => !l.has(S.id)), f = (_a2 = i[c]) == null ? void 0 : _a2.id, d = f && !l.has(f) ? p.findIndex((S) => S.id === f) : -1, w = {
      ...u
    };
    l.forEach((S) => delete w[S]), await e.setState({
      podcastPlayer: {
        ...e.state.podcastPlayer,
        playlist: p,
        currentIndex: d,
        isPlaying: d >= 0 ? e.state.podcastPlayer.isPlaying : false,
        progressMap: w
      }
    }), await k.set(ln, w);
    const y = await k.get(fr);
    return await k.set(fr, {
      lastScan: y == null ? void 0 : y.lastScan,
      playlist: p
    }), {
      deleted: l.size,
      failed: t.length - l.size
    };
  };
  _c = async (e, t, n) => {
    const { podcastPlayer: r } = e.state, a = {
      ...r.progressMap
    }, o = (/* @__PURE__ */ new Date()).toISOString();
    for (const s of t) {
      const l = a[s] || {};
      a[s] = {
        ...l,
        progress: n ? 1 : 0,
        lastPlayedAt: o,
        isListened: n
      };
    }
    await e.setState({
      podcastPlayer: {
        ...r,
        progressMap: a
      }
    }), await k.set(ln, a);
  };
  c5 = async (e, t) => _c(e, [
    t
  ], true);
  u5 = async (e, t) => {
    var _a2;
    const n = !((_a2 = e.state.podcastPlayer.progressMap[t]) == null ? void 0 : _a2.isListened);
    return _c(e, [
      t
    ], n);
  };
  d5 = async (e) => {
    Ne && (clearTimeout(Ne), Ne = null), await e.setState({
      podcastPlayer: {
        ...bc
      }
    });
  };
  f5 = async (e) => {
    Ne && (clearTimeout(Ne), Ne = null), await e.setState({
      podcastPlayer: {
        ...bc
      }
    }), await k.remove(ln), await k.remove(fr);
  };
  p5 = (e, t) => {
    const { podcastPlayer: n } = e.state;
    return n.progressMap[t] || {
      progress: 0,
      isListened: false
    };
  };
  ti = 49e4;
  tg = {
    isMerging: false,
    mergeSuccess: false,
    error: null,
    progress: {
      current: 0,
      total: 0,
      phase: null,
      message: null
    },
    mergeOptions: {
      deleteOriginals: false,
      mergedTitle: "Merged Sources"
    },
    fetchedContents: [],
    mergedContent: null,
    contentSize: 0,
    exceedsLimit: false
  };
  g5 = (e, t) => {
    e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        isMerging: t
      }
    });
  };
  m5 = (e, t) => {
    e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        mergeSuccess: t
      }
    });
  };
  ng = (e, t) => {
    e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        error: t
      }
    }), t && setTimeout(() => ng(e, null), 4e3);
  };
  ga = (e, t) => {
    e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        progress: {
          ...e.state.sourceMerge.progress,
          ...t
        }
      }
    });
  };
  h5 = (e, t) => {
    e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        mergeOptions: {
          ...e.state.sourceMerge.mergeOptions,
          ...t
        }
      }
    });
  };
  rg = (e, t) => {
    e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        fetchedContents: t
      }
    });
  };
  y5 = async (e, t, n) => {
    var _a2;
    const r = $(e.state), a = r == null ? void 0 : r.email;
    if (!(r == null ? void 0 : r.token))
      throw new Error("Not authenticated to NotebookLM");
    const o = new ge(r.token, {
      ...r,
      onAuthError: me(e, r.email)
    }), s = [];
    for (let l = 0; l < t.length; l++) {
      const i = t[l];
      ga(e, {
        phase: "fetching",
        current: l + 1,
        total: t.length,
        message: `Fetching "${i.title}"...`
      });
      try {
        const c = await o.loadSource(i.id, n), u = ce.parseSourceContent(c);
        s.push({
          id: i.id,
          title: i.title || "Untitled Source",
          url: i.url || null,
          content: (u == null ? void 0 : u.content) || "",
          error: null
        });
      } catch (c) {
        console.warn(`Failed to fetch source ${i.id}:`, c), s.push({
          id: i.id,
          title: i.title || "Untitled Source",
          url: i.url || null,
          content: "",
          error: c.message
        });
      }
    }
    return ((_a2 = $(e.state)) == null ? void 0 : _a2.email) !== a ? [] : (rg(e, s), s);
  };
  w5 = (e) => {
    const { fetchedContents: t, mergeOptions: n } = e.state.sourceMerge, a = t.map((l) => {
      const i = `## Source: ${l.title}`, c = l.url ? `URL: ${l.url}` : "Type: Pasted Text", u = l.content || "(No content available)";
      return `${i}
${c}

${u}`;
    }).join(`

---

`), o = a.length, s = o > ti;
    return e.setState({
      sourceMerge: {
        ...e.state.sourceMerge,
        mergedContent: a,
        contentSize: o,
        exceedsLimit: s
      }
    }), {
      mergedContent: a,
      contentSize: o,
      exceedsLimit: s
    };
  };
  v5 = async (e, t) => {
    const n = $(e.state), { sourceMerge: r } = e.state, { mergedContent: a, mergeOptions: o } = r;
    if (!(n == null ? void 0 : n.token))
      throw new Error("Not authenticated to NotebookLM");
    if (!a)
      throw new Error("No content to merge");
    const s = new ge(n.token, {
      ...n,
      onAuthError: me(e, n.email)
    }), l = [];
    for (let i = 0; i < a.length; i += ti)
      l.push(a.slice(i, i + ti));
    for (let i = 0; i < l.length; i++) {
      const c = l.length > 1 ? `${o.mergedTitle} (${i + 1}/${l.length})` : o.mergedTitle;
      ga(e, {
        phase: "uploading",
        current: i + 1,
        total: l.length,
        message: l.length > 1 ? `Creating source ${i + 1}/${l.length}...` : "Creating merged source..."
      }), await s.pastedTextToSource(l[i], t, c);
    }
    return true;
  };
  S5 = async (e, t, n) => {
    const r = $(e.state), a = 3;
    if (!(r == null ? void 0 : r.token))
      throw new Error("Not authenticated to NotebookLM");
    const o = new ge(r.token, {
      ...r,
      onAuthError: me(e, r.email)
    });
    let s = 0;
    for (let l = 0; l < t.length; l += a) {
      const i = t.slice(l, l + a);
      ga(e, {
        phase: "deleting",
        current: s,
        total: t.length,
        message: `Removing sources ${s + 1}-${Math.min(s + i.length, t.length)}/${t.length}...`
      }), (await Promise.allSettled(i.map((u) => o.deleteSource(u, n)))).forEach((u, p) => {
        u.status === "rejected" && console.warn(`Failed to delete source ${i[p]}:`, u.reason);
      }), s += i.length;
    }
    return ga(e, {
      phase: "deleting",
      current: s,
      total: t.length,
      message: `Removed ${s} sources`
    }), true;
  };
  k5 = (e) => {
    e.setState({
      sourceMerge: tg
    });
  };
  dd = (e) => e ? e.toLowerCase().trim().replace(/\s*\(\d+\)\s*$/, "").replace(/\s*-\s*copy\s*$/i, "").replace(/\s+copy\s*$/i, "").replace(/\s*\[duplicate\]\s*$/i, "").replace(/\s+/g, " ").trim() : "";
  E5 = (e, t) => {
    if (e.length === 0)
      return t.length;
    if (t.length === 0)
      return e.length;
    const n = [];
    for (let r = 0; r <= t.length; r++)
      n[r] = [
        r
      ];
    for (let r = 0; r <= e.length; r++)
      n[0][r] = r;
    for (let r = 1; r <= t.length; r++)
      for (let a = 1; a <= e.length; a++)
        t.charAt(r - 1) === e.charAt(a - 1) ? n[r][a] = n[r - 1][a - 1] : n[r][a] = Math.min(n[r - 1][a - 1] + 1, n[r][a - 1] + 1, n[r - 1][a] + 1);
    return n[t.length][e.length];
  };
  fd = (e, t) => {
    const n = dd(e), r = dd(t);
    if (!n || !r)
      return 0;
    if (n === r)
      return 1;
    const a = Math.max(n.length, r.length);
    return 1 - E5(n, r) / a;
  };
  pd = (e, t = 2) => {
    if (!e)
      return /* @__PURE__ */ new Set();
    const n = e.toLowerCase().replace(/[^\w\s]/g, " ").split(/\s+/).filter((a) => a.length > 0);
    if (n.length < t)
      return new Set(n);
    const r = /* @__PURE__ */ new Set();
    for (let a = 0; a <= n.length - t; a++)
      r.add(n.slice(a, a + t).join(" "));
    return r;
  };
  T5 = (e, t) => {
    if (e.size === 0 && t.size === 0)
      return 1;
    if (e.size === 0 || t.size === 0)
      return 0;
    let n = 0;
    for (const r of e)
      t.has(r) && n++;
    return n / (e.size + t.size - n);
  };
  x5 = (e, t) => {
    const n = pd(e, 3), r = pd(t, 3);
    return T5(n, r);
  };
  A5 = (e, t = {}) => {
    const { titleThreshold: n = 0.85, includeExactUrlMatches: r = true, contentMap: a = null, contentThreshold: o = 0.7 } = t;
    if (!e || e.length < 2)
      return [];
    const s = [], l = /* @__PURE__ */ new Set(), i = (u) => {
      if (u.youtubeVideoId)
        return `youtube:${u.youtubeVideoId}`;
      if (u.url)
        try {
          const p = new URL(u.url.trim().toLowerCase());
          return p.protocol = "https:", p.hostname = p.hostname.replace(/^www\./, ""), p.hash = "", p.href.replace(/\/$/, "");
        } catch {
          return u.url.trim().toLowerCase();
        }
      return null;
    };
    if (r) {
      const u = {};
      e.forEach((p) => {
        const f = i(p);
        f && (u[f] || (u[f] = []), u[f].push(p));
      }), Object.entries(u).forEach(([p, f]) => {
        if (f.length > 1) {
          const d = f.sort((w, y) => new Date(w.createdAt) - new Date(y.createdAt));
          s.push({
            id: `url-${s.length}`,
            sources: d,
            matchType: p.startsWith("youtube:") ? "youtube_id" : "url",
            similarity: 1,
            representativeId: d[0].id
          }), d.forEach((w) => l.add(w.id));
        }
      });
    }
    const c = e.filter((u) => !l.has(u.id));
    for (let u = 0; u < c.length; u++) {
      if (l.has(c[u].id))
        continue;
      const p = [
        c[u]
      ], f = c[u].title;
      for (let d = u + 1; d < c.length; d++) {
        if (l.has(c[d].id))
          continue;
        fd(f, c[d].title) >= n && p.push(c[d]);
      }
      if (p.length > 1) {
        const d = p.sort((y, S) => new Date(y.createdAt) - new Date(S.createdAt)), w = p.slice(1).reduce((y, S) => y + fd(f, S.title), 0) / (p.length - 1);
        s.push({
          id: `title-${s.length}`,
          sources: d,
          matchType: "title",
          similarity: w,
          representativeId: d[0].id
        }), d.forEach((y) => l.add(y.id));
      }
    }
    if (a) {
      const u = e.filter((p) => !l.has(p.id) && a[p.id]);
      for (let p = 0; p < u.length; p++) {
        if (l.has(u[p].id))
          continue;
        const f = [
          u[p]
        ], d = a[u[p].id];
        for (let w = p + 1; w < u.length; w++) {
          if (l.has(u[w].id))
            continue;
          const y = a[u[w].id];
          if (!y)
            continue;
          x5(d, y) >= o && f.push(u[w]);
        }
        if (f.length > 1) {
          const w = f.sort((y, S) => new Date(y.createdAt) - new Date(S.createdAt));
          s.push({
            id: `content-${s.length}`,
            sources: w,
            matchType: "content",
            similarity: o,
            representativeId: w[0].id
          }), w.forEach((y) => l.add(y.id));
        }
      }
    }
    return s;
  };
  Wn = 3;
  ag = {
    isScanning: false,
    progress: {
      phase: null,
      current: 0,
      total: 0,
      message: null
    },
    scanOptions: {
      matchMode: "fast",
      titleThreshold: 0.85,
      includeExactUrlMatches: true,
      contentThreshold: 0.7
    },
    duplicateGroups: [],
    selectedGroups: {},
    fetchedContents: {},
    isExecuting: false,
    executionResults: {
      deleted: 0,
      failed: 0
    }
  };
  M5 = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        scanOptions: {
          ...e.state.duplicateScan.scanOptions,
          ...t
        }
      }
    });
  };
  xt = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        progress: {
          ...e.state.duplicateScan.progress,
          ...t
        }
      }
    });
  };
  og = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        duplicateGroups: t
      }
    });
  };
  sg = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        selectedGroups: t
      }
    });
  };
  C5 = (e, t, n) => {
    const r = e.state.duplicateScan.selectedGroups;
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        selectedGroups: {
          ...r,
          [t]: {
            ...r[t],
            ...n
          }
        }
      }
    });
  };
  ni = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        isScanning: t
      }
    });
  };
  ri = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        isExecuting: t
      }
    });
  };
  lg = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        executionResults: {
          ...e.state.duplicateScan.executionResults,
          ...t
        }
      }
    });
  };
  ig = (e, t) => {
    e.setState({
      duplicateScan: {
        ...e.state.duplicateScan,
        fetchedContents: t
      }
    });
  };
  N5 = async (e, t, n) => {
    var _a2;
    const { scanOptions: r } = e.state.duplicateScan, a = $(e.state), o = a == null ? void 0 : a.email;
    ni(e, true), xt(e, {
      phase: "scanning",
      current: 0,
      total: t.length,
      message: "Analyzing sources..."
    });
    try {
      let s = null;
      if (r.matchMode === "deep") {
        if (!(a == null ? void 0 : a.token))
          throw new Error("Not authenticated to NotebookLM");
        const c = new ge(a.token, {
          ...a,
          onAuthError: me(e, a.email)
        });
        s = {}, xt(e, {
          phase: "fetching_content",
          current: 0,
          total: t.length,
          message: "Fetching source content..."
        });
        for (let u = 0; u < t.length; u += Wn) {
          const p = t.slice(u, u + Wn);
          (await Promise.allSettled(p.map(async (d) => {
            const w = await c.loadSource(d.id, n), y = ce.parseSourceContent(w);
            return {
              id: d.id,
              content: (y == null ? void 0 : y.content) || ""
            };
          }))).forEach((d) => {
            d.status === "fulfilled" && d.value.content && (s[d.value.id] = d.value.content);
          }), xt(e, {
            current: Math.min(u + Wn, t.length),
            message: `Fetching content ${Math.min(u + Wn, t.length)}/${t.length}...`
          });
        }
        ig(e, s);
      }
      xt(e, {
        phase: "comparing",
        current: t.length,
        total: t.length,
        message: "Comparing sources..."
      });
      const l = A5(t, {
        titleThreshold: r.titleThreshold,
        includeExactUrlMatches: r.includeExactUrlMatches,
        contentMap: r.matchMode === "deep" ? s : null,
        contentThreshold: r.contentThreshold
      });
      if (((_a2 = $(e.state)) == null ? void 0 : _a2.email) !== o)
        return [];
      og(e, l);
      const i = {};
      return l.forEach((c) => {
        i[c.id] = {
          action: "delete",
          keepSourceId: c.representativeId
        };
      }), sg(e, i), l;
    } finally {
      ni(e, false), xt(e, {
        phase: null,
        message: null
      });
    }
  };
  P5 = async (e, t) => {
    const { duplicateGroups: n, selectedGroups: r } = e.state.duplicateScan, a = $(e.state);
    if (!(a == null ? void 0 : a.token))
      throw new Error("Not authenticated to NotebookLM");
    const o = new ge(a.token, {
      ...a,
      onAuthError: me(e, a.email)
    }), s = [];
    if (n.forEach((c) => {
      const u = r[c.id];
      (u == null ? void 0 : u.action) === "delete" && u.keepSourceId && c.sources.forEach((p) => {
        p.id !== u.keepSourceId && s.push(p.id);
      });
    }), s.length === 0)
      return {
        deleted: 0,
        failed: 0
      };
    ri(e, true), xt(e, {
      phase: "deleting",
      current: 0,
      total: s.length,
      message: "Deleting duplicates..."
    });
    let l = 0, i = 0;
    try {
      for (let c = 0; c < s.length; c += Wn) {
        const u = s.slice(c, c + Wn);
        (await Promise.allSettled(u.map((f) => o.deleteSource(f, t)))).forEach((f) => {
          f.status === "fulfilled" ? l++ : (i++, console.warn("Failed to delete source:", f.reason));
        }), xt(e, {
          current: c + u.length,
          message: `Deleting ${c + u.length}/${s.length}...`
        });
      }
      return lg(e, {
        deleted: l,
        failed: i
      }), {
        deleted: l,
        failed: i
      };
    } finally {
      ri(e, false), xt(e, {
        phase: null,
        message: null
      });
    }
  };
  b5 = (e) => {
    const { duplicateGroups: t, selectedGroups: n } = e.state.duplicateScan;
    let r = 0, a = 0;
    const o = [];
    return t.forEach((s) => {
      const l = n[s.id];
      if ((l == null ? void 0 : l.action) === "delete" && l.keepSourceId) {
        const i = s.sources.find((c) => c.id === l.keepSourceId);
        i && (o.push(i), a++, r += s.sources.length - 1);
      } else
        a += s.sources.length;
    }), {
      toDelete: r,
      toKeep: a,
      keptSources: o
    };
  };
  L5 = (e) => {
    e.setState({
      duplicateScan: ag
    });
  };
  _5 = () => `folder_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
  ae = /* @__PURE__ */ new Set([
    "__proto__",
    "constructor",
    "prototype"
  ]);
  R5 = (e) => e.replace(/[\u0000-\u001F\u007F-\u009F\u200B-\u200F\u2028-\u202E\uFEFF]/g, "");
  cg = (e, t) => typeof e != "string" ? null : R5(e.trim().slice(0, t)) || null;
  O5 = (e) => {
    let t = {}, n = {};
    if (e.folders && typeof e.folders == "object" && !Array.isArray(e.folders)) {
      const r = Object.values(e.folders)[0];
      if (r && typeof r.id == "string" && typeof r.name == "string") {
        const o = {};
        for (const [l, i] of Object.entries(e.folders))
          ae.has(l) || i && typeof i.id == "string" && typeof i.name == "string" && (o[l] = i);
        const s = e.sourceFolderMap || {};
        for (const [l, i] of Object.entries(s))
          if (!ae.has(l) && !(!i || typeof i != "object"))
            for (const c of new Set(Object.values(i)))
              o[c] && (t[l] || (t[l] = {}), t[l][c] = o[c]);
      } else
        for (const [o, s] of Object.entries(e.folders)) {
          if (ae.has(o))
            continue;
          if (!s || typeof s != "object" || Array.isArray(s)) {
            console.warn("Stripped invalid notebook folders entry:", o);
            continue;
          }
          const l = {};
          for (const [i, c] of Object.entries(s))
            ae.has(i) || (c && typeof c.id == "string" && typeof c.name == "string" ? l[i] = {
              ...c,
              createdAt: typeof c.createdAt == "number" ? c.createdAt : Date.now()
            } : console.warn("Stripped invalid folder entry:", o, i));
          Object.keys(l).length > 0 && (t[o] = l);
        }
    } else
      e.folders && console.warn("Invalid folders format, resetting to empty");
    if (e.sourceFolderMap && typeof e.sourceFolderMap == "object" && !Array.isArray(e.sourceFolderMap)) {
      for (const [r, a] of Object.entries(e.sourceFolderMap))
        if (!ae.has(r))
          if (a && typeof a == "object" && !Array.isArray(a)) {
            const o = {};
            for (const [s, l] of Object.entries(a))
              !ae.has(s) && typeof l == "string" && (o[s] = l);
            n[r] = o;
          } else
            console.warn("Stripped invalid sourceFolderMap entry:", r);
    } else
      e.sourceFolderMap && console.warn("Invalid sourceFolderMap format, resetting to empty");
    for (const r of Object.keys(t)) {
      const a = Object.entries(t[r]);
      a.length > lo && (console.warn("Source folders: trimmed folders to MAX_FOLDER_COUNT for notebook", r), t[r] = Object.fromEntries(a.slice(0, lo)));
    }
    for (const r of Object.keys(n)) {
      const a = Object.entries(n[r]);
      a.length > er && (console.warn("Source folders: trimmed sourceFolderMap to MAX_SOURCE_FOLDER_MAPPINGS for notebook", r), n[r] = Object.fromEntries(a.slice(0, er)));
    }
    return {
      folders: t,
      sourceFolderMap: n
    };
  };
  let Gs = Promise.resolve();
  const Ft = (e) => (Gs = Gs.catch((t) => console.error("Source folders mutex chain error:", t)).then(e), Gs);
  let yn = null, Wr = null, pn = null;
  const gd = () => {
    if (yn && (clearTimeout(yn), yn = null), Wr) {
      const e = Wr, t = pn;
      Wr = null, pn = null;
      try {
        const { folders: n, sourceFolderMap: r } = e.state.sourceFolders;
        chrome.storage.local.set({
          [yi]: {
            folders: n,
            sourceFolderMap: r
          }
        });
      } catch (n) {
        console.error("Failed to flush source folders:", n);
      }
      t == null ? void 0 : t.forEach((n) => n());
    }
  }, Rc = (e, t = 300) => new Promise((n) => {
    yn && clearTimeout(yn), Wr = e, pn || (pn = []), pn.push(n), yn = setTimeout(async () => {
      yn = null, Wr = null;
      const r = pn;
      pn = null, await Cn(e), r.forEach((a) => a());
    }, t);
  }), Cn = async (e) => {
    try {
      const { folders: t, sourceFolderMap: n } = e.state.sourceFolders;
      await k.set(yi, {
        folders: t,
        sourceFolderMap: n
      });
    } catch (t) {
      console.error("Failed to persist source folders:", t), B.error("Failed to save folder changes");
    }
  };
  typeof document < "u" && (document.addEventListener("visibilitychange", () => {
    document.hidden && gd();
  }), window.addEventListener("beforeunload", gd));
  const F5 = {
    folders: {},
    sourceFolderMap: {},
    isLoaded: false
  }, I5 = (e) => Ft(async () => {
    try {
      const t = await k.get(yi);
      if (t) {
        const { folders: n, sourceFolderMap: r } = O5(t);
        e.setState({
          ...e.state,
          sourceFolders: {
            ...e.state.sourceFolders,
            folders: n,
            sourceFolderMap: r,
            isLoaded: true
          }
        }), await Cn(e);
      } else
        e.setState({
          ...e.state,
          sourceFolders: {
            ...e.state.sourceFolders,
            isLoaded: true
          }
        });
    } catch (t) {
      console.error("Failed to load source folders:", t), e.setState({
        ...e.state,
        sourceFolders: {
          ...e.state.sourceFolders,
          isLoaded: true
        }
      });
    }
  }), D5 = (e, t, n) => Ft(async () => {
    try {
      if (typeof t != "string" || ae.has(t))
        return null;
      const r = e.state.sourceFolders.folders[t] || {};
      if (Object.keys(r).length >= lo)
        return B.error(`Maximum of ${lo} folders reached`), {
          error: "limit"
        };
      const a = cg(n, Pd);
      if (!a)
        return B.error("Folder name cannot be empty"), null;
      const o = Object.values(r).find((l) => l.name.toLowerCase() === a.toLowerCase());
      if (o)
        return {
          folder: o,
          isNew: false
        };
      const s = {
        id: _5(),
        name: a,
        createdAt: Date.now()
      };
      return e.setState({
        ...e.state,
        sourceFolders: {
          ...e.state.sourceFolders,
          folders: {
            ...e.state.sourceFolders.folders,
            [t]: {
              ...r,
              [s.id]: s
            }
          }
        }
      }), await Cn(e), {
        folder: s,
        isNew: true
      };
    } catch (r) {
      return console.error("Failed to create folder:", r), B.error("Failed to create folder"), null;
    }
  }), U5 = (e, t, n, r) => Ft(async () => {
    try {
      if (typeof t != "string" || ae.has(t) || typeof n != "string" || ae.has(n) || !r || typeof r != "object" || r.name !== void 0 && typeof r.name != "string")
        return null;
      const a = e.state.sourceFolders.folders[t] || {}, o = a[n];
      if (!o)
        return null;
      const s = {};
      if (r.name !== void 0) {
        const i = cg(r.name, Pd);
        if (!i || Object.values(a).find((u) => u.id !== n && u.name.toLowerCase() === i.toLowerCase()))
          return null;
        s.name = i;
      }
      const l = {
        ...o,
        ...s
      };
      return e.setState({
        ...e.state,
        sourceFolders: {
          ...e.state.sourceFolders,
          folders: {
            ...e.state.sourceFolders.folders,
            [t]: {
              ...a,
              [n]: l
            }
          }
        }
      }), await Cn(e), l;
    } catch (a) {
      return console.error("Failed to update folder:", a), B.error("Failed to update folder"), null;
    }
  }), $5 = (e, t, n) => Ft(async () => {
    var _a2;
    try {
      if (typeof t != "string" || ae.has(t) || typeof n != "string" || ae.has(n))
        return null;
      const { folders: r, sourceFolderMap: a } = e.state.sourceFolders;
      if (!((_a2 = r[t]) == null ? void 0 : _a2[n]))
        return null;
      const o = {
        ...r[t] || {}
      };
      delete o[n];
      const s = {
        ...r
      };
      Object.keys(o).length > 0 ? s[t] = o : delete s[t];
      const l = a[t];
      let i = {
        ...a
      };
      if (l) {
        const c = {};
        for (const [u, p] of Object.entries(l))
          p !== n && (c[u] = p);
        Object.keys(c).length > 0 ? i[t] = c : delete i[t];
      }
      return e.setState({
        ...e.state,
        sourceFolders: {
          ...e.state.sourceFolders,
          folders: s,
          sourceFolderMap: i
        }
      }), await Cn(e), true;
    } catch (r) {
      return console.error("Failed to delete folder:", r), B.error("Failed to delete folder"), false;
    }
  }), j5 = (e, t, n, r) => Ft(async () => {
    if (typeof t != "string" || typeof n != "string" || typeof r != "string" || ae.has(t) || ae.has(n) || ae.has(r))
      return;
    if (!(e.state.sourceFolders.folders[t] || {})[r]) {
      B.error("Target folder not found");
      return;
    }
    const { sourceFolderMap: o } = e.state.sourceFolders, s = {
      ...o[t] || {}
    };
    if (s[n] !== r) {
      if (!s[n] && Object.keys(s).length >= er) {
        B.error(`Source folder mapping limit reached (${er})`);
        return;
      }
      s[n] = r, e.setState({
        ...e.state,
        sourceFolders: {
          ...e.state.sourceFolders,
          sourceFolderMap: {
            ...o,
            [t]: s
          }
        }
      }), await Rc(e);
    }
  }), z5 = (e, t, n) => Ft(async () => {
    if (typeof t != "string" || typeof n != "string" || ae.has(t) || ae.has(n))
      return;
    const { sourceFolderMap: r } = e.state.sourceFolders, a = {
      ...r[t] || {}
    };
    delete a[n];
    const o = {
      ...r
    };
    Object.keys(a).length > 0 ? o[t] = a : delete o[t], e.setState({
      ...e.state,
      sourceFolders: {
        ...e.state.sourceFolders,
        sourceFolderMap: o
      }
    }), await Rc(e);
  }), B5 = (e, t, n, r) => Ft(async () => {
    if (typeof t != "string" || !Array.isArray(n) || n.length === 0 || ae.has(t) || ae.has(r))
      return;
    if (!(e.state.sourceFolders.folders[t] || {})[r]) {
      B.error("Target folder not found");
      return;
    }
    const { sourceFolderMap: o } = e.state.sourceFolders, s = {
      ...o[t] || {}
    };
    let l = false, i = Object.keys(s).length, c = 0;
    for (const u of n)
      if (typeof u == "string" && !ae.has(u) && s[u] !== r) {
        if (!s[u] && i >= er) {
          c++;
          continue;
        }
        s[u] || i++, s[u] = r, l = true;
      }
    c > 0 && B.error(`${c} source${c > 1 ? "s" : ""} skipped (mapping limit: ${er})`), l && (e.setState({
      ...e.state,
      sourceFolders: {
        ...e.state.sourceFolders,
        sourceFolderMap: {
          ...o,
          [t]: s
        }
      }
    }), await Cn(e));
  }), V5 = (e, t, n) => Ft(async () => {
    if (typeof t != "string" || !Array.isArray(n) || n.length === 0 || ae.has(t))
      return;
    const { sourceFolderMap: r } = e.state.sourceFolders, a = {
      ...r[t] || {}
    };
    let o = false;
    for (const l of n)
      typeof l == "string" && !ae.has(l) && a[l] && (delete a[l], o = true);
    if (!o)
      return;
    const s = {
      ...r
    };
    Object.keys(a).length > 0 ? s[t] = a : delete s[t], e.setState({
      ...e.state,
      sourceFolders: {
        ...e.state.sourceFolders,
        sourceFolderMap: s
      }
    }), await Cn(e);
  }), H5 = (e, t, n) => Ft(async () => {
    if (!Array.isArray(n) || typeof t != "string" || ae.has(t))
      return;
    const { sourceFolderMap: r } = e.state.sourceFolders, a = r[t];
    if (!a)
      return;
    const o = new Set(n), s = e.state.sourceFolders.folders[t] || {}, l = {};
    let i = false;
    for (const [c, u] of Object.entries(a))
      o.has(c) && s[u] ? l[c] = u : i = true;
    if (i) {
      const c = {
        ...r
      };
      Object.keys(l).length > 0 ? c[t] = l : delete c[t], e.setState({
        ...e.state,
        sourceFolders: {
          ...e.state.sourceFolders,
          sourceFolderMap: c
        }
      }), await Rc(e);
    }
  }), G5 = (e) => {
    const { folders: t, sourceFolderMap: n } = e.state.sourceFolders;
    return {
      version: "2.0",
      type: "notebooklm-source-folders",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      folders: t,
      sourceFolderMap: n
    };
  };
  function ug(e) {
    const t = {}, n = {}, r = Array.isArray(e == null ? void 0 : e[1]) ? e[1] : Array.isArray(e == null ? void 0 : e[0]) ? e[0] : [];
    for (const o of r) {
      if (!Array.isArray(o))
        continue;
      const s = typeof o[0] == "string" ? o[0] : "", l = o[1], i = typeof o[2] == "string" ? o[2] : null, c = typeof o[3] == "string" ? o[3] : "";
      if (i && (t[i] = {
        id: i,
        name: s,
        emoji: c,
        createdAt: 0
      }, Array.isArray(l)))
        for (const u of l) {
          const p = Array.isArray(u) ? u[0] : u;
          typeof p == "string" && (n[p] || (n[p] = []), n[p].push(i));
        }
    }
    const a = {};
    for (const [o, s] of Object.entries(n))
      a[o] = [
        ...s
      ].sort();
    return {
      folders: t,
      sourceFolderMap: a
    };
  }
  const W5 = {
    foldersMap: {},
    sourceFolderMapMap: {},
    loadingMap: {},
    requestedMap: {},
    modeMap: {},
    modesLoaded: false
  }, is = (e) => Array.isArray(e) ? e : e != null ? [
    e
  ] : [], yr = (e) => {
    const t = $(e.state);
    return (t == null ? void 0 : t.token) ? new ge(t.token, {
      ...t,
      onAuthError: me(e, t.email)
    }) : null;
  }, ct = (e, t, n) => {
    const r = e.state.notebookLabels, a = {
      ...r
    };
    for (const [o, s] of Object.entries(n))
      a[o] = {
        ...r[o],
        [t]: s
      };
    return e.setState({
      notebookLabels: a
    });
  }, Y5 = async (e, t, n) => {
    const r = {
      ...e.state.notebookLabels.modeMap,
      [t]: n
    };
    await e.setState({
      notebookLabels: {
        ...e.state.notebookLabels,
        modeMap: r
      }
    });
    try {
      await k.set(bd, r);
    } catch (a) {
      console.error("[NLM Tools] Failed to persist label view mode:", a);
    }
  }, Q5 = async (e) => {
    if (e.state.notebookLabels.modesLoaded)
      return;
    let t = {};
    try {
      const n = await k.get(bd);
      n && typeof n == "object" && (t = n);
    } catch (n) {
      console.error("[NLM Tools] Failed to load label view modes:", n);
    }
    await e.setState({
      notebookLabels: {
        ...e.state.notebookLabels,
        modeMap: {
          ...t,
          ...e.state.notebookLabels.modeMap
        },
        modesLoaded: true
      }
    });
  }, cs = async (e, t, n) => {
    var _a2;
    const r = $(e.state), a = r == null ? void 0 : r.email;
    if (!(r == null ? void 0 : r.token))
      throw new Error("Not authenticated to NotebookLM");
    await ct(e, t, {
      loadingMap: true
    });
    try {
      const o = new ge(r.token, {
        ...r,
        onAuthError: me(e, r.email)
      }), s = await n(o), { folders: l, sourceFolderMap: i } = ug(s);
      return ((_a2 = $(e.state)) == null ? void 0 : _a2.email) !== a ? null : (await ct(e, t, {
        foldersMap: l,
        sourceFolderMapMap: i,
        loadingMap: false,
        requestedMap: true
      }), {
        folders: l,
        sourceFolderMap: i
      });
    } catch (o) {
      throw await ct(e, t, {
        loadingMap: false
      }), o;
    }
  }, Z5 = (e, t) => cs(e, t, (n) => n.getLabels(t)), K5 = (e, t) => cs(e, t, (n) => n.listLabels(t, [])), X5 = (e, t) => cs(e, t, (n) => n.listLabels(t, [
    0
  ])), q5 = (e, t) => cs(e, t, (n) => n.listLabels(t, [
    1
  ])), J5 = async (e, t, n, r = "") => {
    const a = yr(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    const o = (n || "").trim();
    if (!o)
      return null;
    const s = e.state.notebookLabels.foldersMap[t] || {}, l = Object.values(s).find((f) => f.name.toLowerCase() === o.toLowerCase());
    if (l)
      return {
        folder: l,
        isNew: false
      };
    const i = await a.createLabel(t, o, r), { folders: c, sourceFolderMap: u } = ug(i);
    return await ct(e, t, {
      foldersMap: c,
      sourceFolderMapMap: u,
      requestedMap: true
    }), {
      folder: Object.values(c).find((f) => f.name.toLowerCase() === o.toLowerCase()) || null,
      isNew: true
    };
  }, ek = async (e, t, n, r) => {
    const a = yr(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    const o = (r || "").trim();
    if (!o)
      return null;
    const s = e.state.notebookLabels.foldersMap[t] || {}, l = s[n];
    if (!l || Object.values(s).find((u) => u.id !== n && u.name.toLowerCase() === o.toLowerCase()))
      return null;
    await a.renameLabel(t, n, o);
    const c = {
      ...l,
      name: o
    };
    return await ct(e, t, {
      foldersMap: {
        ...s,
        [n]: c
      }
    }), c;
  }, tk = async (e, t, n, r) => {
    const a = yr(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    const o = e.state.notebookLabels.sourceFolderMapMap[t] || {}, s = is(o[n]);
    if (!s.includes(r)) {
      await ct(e, t, {
        sourceFolderMapMap: {
          ...o,
          [n]: [
            ...s,
            r
          ]
        }
      });
      try {
        await a.moveSourceToLabel(t, r, n);
      } catch (l) {
        const i = {
          ...e.state.notebookLabels.sourceFolderMapMap[t] || {}
        };
        throw s.length ? i[n] = s : delete i[n], await ct(e, t, {
          sourceFolderMapMap: i
        }), l;
      }
    }
  }, nk = async (e, t, n, r) => {
    const a = yr(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    const o = e.state.notebookLabels.sourceFolderMapMap[t] || {}, s = is(o[n]);
    if (!s.includes(r))
      return;
    const l = s.filter((c) => c !== r), i = {
      ...o
    };
    l.length ? i[n] = l : delete i[n], await ct(e, t, {
      sourceFolderMapMap: i
    });
    try {
      await a.removeSourceFromLabel(t, r, n);
    } catch (c) {
      const u = {
        ...e.state.notebookLabels.sourceFolderMapMap[t] || {}
      };
      throw u[n] = s, await ct(e, t, {
        sourceFolderMapMap: u
      }), c;
    }
  }, rk = async (e, t, n, r) => {
    const a = yr(e);
    if (!a)
      throw new Error("Not authenticated to NotebookLM");
    if (!Array.isArray(n) || n.length === 0)
      return;
    const o = [], s = [];
    for (const l of n)
      try {
        await a.moveSourceToLabel(t, r, l), s.push(l);
      } catch (i) {
        console.error("Failed to add source to label:", i), o.push(l);
      }
    if (s.length) {
      const l = {
        ...e.state.notebookLabels.sourceFolderMapMap[t] || {}
      };
      for (const i of s) {
        const c = is(l[i]);
        c.includes(r) || (l[i] = [
          ...c,
          r
        ]);
      }
      await ct(e, t, {
        sourceFolderMapMap: l
      });
    }
    if (o.length) {
      const l = new Error(`Failed to add ${o.length} source${o.length > 1 ? "s" : ""}`);
      throw l.failed = o, l;
    }
  }, ak = async (e, t, n) => {
    const r = yr(e);
    if (!r)
      throw new Error("Not authenticated to NotebookLM");
    const a = Array.isArray(n) ? n : [
      n
    ];
    if (a.length === 0)
      return false;
    await r.deleteLabels(t, a);
    const o = new Set(a), s = {
      ...e.state.notebookLabels.foldersMap[t] || {}
    };
    for (const c of a)
      delete s[c];
    const l = e.state.notebookLabels.sourceFolderMapMap[t] || {}, i = {};
    for (const [c, u] of Object.entries(l)) {
      const p = is(u).filter((f) => !o.has(f));
      p.length && (i[c] = p);
    }
    return await ct(e, t, {
      foldersMap: s,
      sourceFolderMapMap: i
    }), true;
  }, ok = {
    themeMode: "system"
  }, sk = async (e, t) => {
    e.setState({
      ...e.state,
      themeSettings: {
        ...e.state.themeSettings,
        themeMode: t
      }
    });
    try {
      await k.set(Ld, t);
    } catch (n) {
      console.error("Failed to save theme mode:", n);
    }
  }, lk = async (e) => {
    try {
      const t = await k.get(Ld);
      t && e.setState({
        ...e.state,
        themeSettings: {
          ...e.state.themeSettings,
          themeMode: t
        }
      });
    } catch (t) {
      console.error("Failed to load theme mode:", t);
    }
  }, ik = (e) => e.state.themeSettings.themeMode, dg = /^\/[a-z0-9-]{2,20}$/, ck = (e) => Array.isArray(e) ? e.filter((t) => t && typeof t.id == "string" && typeof t.title == "string" && typeof t.text == "string" && typeof t.category == "string").map((t) => ({
    id: t.id,
    category: t.category.slice(0, ie.CATEGORY_MAX_LENGTH),
    shortcode: t.shortcode || "",
    title: t.title.slice(0, ie.TITLE_MAX_LENGTH),
    text: t.text.slice(0, ie.TEXT_MAX_LENGTH),
    pinned: !!t.pinned
  })) : e && typeof e == "object" && Array.isArray(e.customPrompts) ? e.customPrompts.filter((t) => t && typeof t.id == "string" && typeof t.title == "string" && typeof t.text == "string" && typeof t.category == "string").map((t) => ({
    id: t.id,
    category: t.category.slice(0, ie.CATEGORY_MAX_LENGTH),
    shortcode: t.shortcode || "",
    title: t.title.slice(0, ie.TITLE_MAX_LENGTH),
    text: t.text.slice(0, ie.TEXT_MAX_LENGTH),
    pinned: false
  })) : null, wr = async (e) => {
    const { prompts: t } = e.state.promptsManager;
    await k.set(Qs, t);
  }, uk = async (e) => {
    try {
      const t = await k.get(Qs), n = ck(t);
      n ? (e.setState({
        ...e.state,
        promptsManager: {
          ...e.state.promptsManager,
          prompts: n,
          isLoaded: true
        }
      }), t && !Array.isArray(t) && await k.set(Qs, n)) : e.setState({
        ...e.state,
        promptsManager: {
          ...e.state.promptsManager,
          prompts: [],
          isLoaded: true
        }
      });
    } catch (t) {
      console.warn("Failed to load prompts:", t), e.setState({
        ...e.state,
        promptsManager: {
          ...e.state.promptsManager,
          prompts: [],
          isLoaded: true
        }
      });
    }
  }, dk = async (e) => {
    try {
      const t = await k.get(Vo);
      let n = {};
      if (t && typeof t == "object" && !Array.isArray(t))
        for (const [r, a] of Object.entries(t))
          typeof r == "string" && a && typeof a == "object" && typeof a.count == "number" && a.count >= 0 && (n[r] = {
            count: Math.floor(a.count),
            lastUsedAt: typeof a.lastUsedAt == "number" ? a.lastUsedAt : null
          });
      e.setState({
        ...e.state,
        promptsManager: {
          ...e.state.promptsManager,
          usageData: n
        }
      });
    } catch (t) {
      console.warn("Failed to load usage data:", t);
    }
  }, fk = (e, t) => e.state.promptsManager.usageData[t] || {
    count: 0,
    lastUsedAt: null
  }, pk = {
    prompts: [],
    usageData: {},
    isLoaded: false
  }, fg = (e, t) => e.state.promptsManager.prompts.filter((n) => n.id !== t && n.shortcode).map((n) => n.shortcode), gk = (e, t, n) => {
    if (!t)
      return null;
    const r = t.startsWith("/") ? t : `/${t}`;
    return dg.test(r) ? fg(e, n).includes(r) ? "This shortcode is already in use" : null : "Shortcode must be 2-20 lowercase letters, numbers, or hyphens";
  }, mk = async (e, { category: t, shortcode: n, title: r, text: a }) => {
    if (!(r == null ? void 0 : r.trim()) || !(a == null ? void 0 : a.trim()) || !(t == null ? void 0 : t.trim()))
      throw new Error("Title, text, and category are required");
    if (e.state.promptsManager.prompts.length >= ie.MAX_PROMPTS)
      throw new Error(`Prompt limit reached (max ${ie.MAX_PROMPTS})`);
    const o = n ? n.startsWith("/") ? n : `/${n}` : "", l = {
      id: crypto.randomUUID(),
      category: t.trim().slice(0, ie.CATEGORY_MAX_LENGTH),
      shortcode: o || "",
      title: r.trim().slice(0, ie.TITLE_MAX_LENGTH),
      text: a.trim().slice(0, ie.TEXT_MAX_LENGTH),
      pinned: false
    }, i = e.state.promptsManager, c = [
      ...i.prompts,
      l
    ];
    e.setState({
      ...e.state,
      promptsManager: {
        ...i,
        prompts: c
      }
    });
    try {
      await wr(e);
    } catch (u) {
      throw e.setState({
        ...e.state,
        promptsManager: i
      }), u;
    }
    return l;
  }, hk = async (e, t, { category: n, shortcode: r, title: a, text: o }) => {
    if (!(a == null ? void 0 : a.trim()) || !(o == null ? void 0 : o.trim()) || !(n == null ? void 0 : n.trim()))
      throw new Error("Title, text, and category are required");
    const s = r ? r.startsWith("/") ? r : `/${r}` : "", l = e.state.promptsManager, i = l.prompts.map((c) => c.id === t ? {
      ...c,
      category: n.trim().slice(0, ie.CATEGORY_MAX_LENGTH),
      shortcode: s || "",
      title: a.trim().slice(0, ie.TITLE_MAX_LENGTH),
      text: o.trim().slice(0, ie.TEXT_MAX_LENGTH)
    } : c);
    e.setState({
      ...e.state,
      promptsManager: {
        ...l,
        prompts: i
      }
    });
    try {
      await wr(e);
    } catch (c) {
      throw e.setState({
        ...e.state,
        promptsManager: l
      }), c;
    }
  }, yk = async (e, t) => {
    const n = e.state.promptsManager;
    if (!n.prompts.some((o) => o.id === t))
      return;
    const r = n.prompts.filter((o) => o.id !== t), a = {
      ...n.usageData
    };
    delete a[t], e.setState({
      ...e.state,
      promptsManager: {
        ...n,
        prompts: r,
        usageData: a
      }
    });
    try {
      await wr(e), await k.set(Vo, a);
    } catch (o) {
      throw e.setState({
        ...e.state,
        promptsManager: n
      }), o;
    }
  }, wk = async (e, t) => {
    if (t.length === 0)
      return;
    const n = e.state.promptsManager, r = n.prompts.filter((o) => !t.includes(o.id)), a = {
      ...n.usageData
    };
    t.forEach((o) => delete a[o]), e.setState({
      ...e.state,
      promptsManager: {
        ...n,
        prompts: r,
        usageData: a
      }
    });
    try {
      await wr(e), await k.set(Vo, a);
    } catch (o) {
      throw e.setState({
        ...e.state,
        promptsManager: n
      }), o;
    }
  }, vk = async (e, t) => {
    const n = e.state.promptsManager, r = n.prompts.map((a) => a.id === t ? {
      ...a,
      pinned: !a.pinned
    } : a);
    e.setState({
      ...e.state,
      promptsManager: {
        ...n,
        prompts: r
      }
    });
    try {
      await wr(e);
    } catch (a) {
      throw e.setState({
        ...e.state,
        promptsManager: n
      }), a;
    }
  }, Sk = (e) => e.state.promptsManager.prompts, kk = [
    {
      category: "Quick Start",
      shortcode: "/tldr",
      title: "TL;DR",
      text: "TL;DR"
    },
    {
      category: "Quick Start",
      shortcode: "/5q",
      title: "Essential questions",
      text: "Generate 5 essential questions that, when answered, capture the core meaning of all sources"
    },
    {
      category: "Quick Start",
      shortcode: "/wow",
      title: "Surprising insights",
      text: "What are the most surprising or interesting pieces of information in these sources? Include key quotes."
    }
  ], Ek = (e) => ({
    version: 1,
    type: "notebooklm-prompts",
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    prompts: e.state.promptsManager.prompts,
    usageData: e.state.promptsManager.usageData || {}
  }), Tk = async (e, t) => {
    var _a2, _b;
    if (!t || t.type !== "notebooklm-prompts" || !Array.isArray(t.prompts) || t.version !== void 0 && t.version > 1)
      return {
        imported: 0,
        skipped: 0,
        error: "Invalid or unsupported prompts backup file"
      };
    const n = e.state.promptsManager.prompts.length, r = Math.max(0, ie.MAX_PROMPTS - n);
    if (r === 0)
      return {
        imported: 0,
        skipped: t.prompts.length,
        duplicated: 0,
        error: `Prompt limit reached (max ${ie.MAX_PROMPTS})`
      };
    const a = t.prompts.slice(0, r), o = new Set(fg(e)), s = new Set(e.state.promptsManager.prompts.map((f) => `${f.title}\0${f.text}`)), l = [];
    let i = 0, c = 0;
    const u = {};
    for (const f of a) {
      if (!((_a2 = f.title) == null ? void 0 : _a2.trim()) || !((_b = f.text) == null ? void 0 : _b.trim())) {
        i++;
        continue;
      }
      const d = `${String(f.title).trim()}\0${String(f.text).trim()}`;
      if (s.has(d)) {
        c++;
        continue;
      }
      const w = (typeof f.shortcode == "string" ? f.shortcode : "").trim();
      let y = w ? w.startsWith("/") ? w.toLowerCase() : `/${w}`.toLowerCase() : "";
      y && !dg.test(y) && (y = ""), y && o.has(y) && (y = "");
      const S = crypto.randomUUID();
      f.id && (u[f.id] = S), l.push({
        id: S,
        category: (typeof f.category == "string" ? f.category.trim() : "Custom").slice(0, ie.CATEGORY_MAX_LENGTH),
        shortcode: y,
        title: String(f.title).trim().slice(0, ie.TITLE_MAX_LENGTH),
        text: String(f.text).trim().slice(0, ie.TEXT_MAX_LENGTH),
        pinned: !!f.pinned
      }), y && o.add(y);
    }
    if (l.length > 0) {
      const f = e.state.promptsManager, d = [
        ...f.prompts,
        ...l
      ], w = {
        ...f.usageData
      };
      if (t.usageData && typeof t.usageData == "object" && !Array.isArray(t.usageData))
        for (const [y, S] of Object.entries(t.usageData)) {
          const g = u[y];
          g && S && typeof S == "object" && !Array.isArray(S) && typeof S.count == "number" && S.count >= 0 && (w[g] = {
            count: Math.floor(S.count),
            lastUsedAt: typeof S.lastUsedAt == "number" ? S.lastUsedAt : null
          });
        }
      e.setState({
        ...e.state,
        promptsManager: {
          ...f,
          prompts: d,
          usageData: w
        }
      });
      try {
        await wr(e), await k.set(Vo, w);
      } catch (y) {
        return e.setState({
          ...e.state,
          promptsManager: f
        }), {
          imported: 0,
          skipped: 0,
          error: `Failed to save imported prompts: ${y.message}`
        };
      }
    }
    const p = t.prompts.length - a.length;
    return {
      imported: l.length,
      skipped: i,
      duplicated: c,
      capped: p
    };
  }, xk = () => ({
    version: 1,
    type: "notebooklm-prompts",
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    prompts: kk.map((e) => ({
      id: crypto.randomUUID(),
      category: e.category,
      shortcode: e.shortcode || "",
      title: e.title,
      text: e.text,
      pinned: false
    })),
    usageData: {}
  }), Ak = 30 * 60 * 1e3, Mk = 24 * 60 * 60 * 1e3;
  s2 = async function(e) {
    try {
      const n = (await k.get(Zs) || {})[e] || null;
      return !n || typeof n.results != "object" || n.results === null || Array.isArray(n.results) ? null : n;
    } catch {
      return null;
    }
  };
  l2 = function(e) {
    if (!(e == null ? void 0 : e.lastCheckTime))
      return true;
    const t = new Date(e.lastCheckTime).getTime();
    return !Number.isFinite(t) || t > Date.now() ? true : Date.now() - t > Ak;
  };
  async function Oc(e) {
    var _a2;
    const t = Object.entries(e || {});
    if (t.length)
      try {
        const n = await k.get(Zs) || {}, r = Date.now();
        for (const o of Object.keys(n)) {
          if (e[o])
            continue;
          const s = n[o], l = (s == null ? void 0 : s.lastCheckTime) ? new Date(s.lastCheckTime).getTime() : NaN;
          (!Number.isFinite(l) || r - l > Mk) && delete n[o];
        }
        const a = (/* @__PURE__ */ new Date()).toISOString();
        for (const [o, s] of t) {
          const l = ((_a2 = n[o]) == null ? void 0 : _a2.results) || {};
          n[o] = {
            results: {
              ...l,
              ...s
            },
            lastCheckTime: a
          };
        }
        await k.set(Zs, n);
      } catch (n) {
        console.warn("Failed to save freshness cache:", n);
      }
  }
  i2 = async function(e, t) {
    await Oc({
      [e]: t
    });
  };
  let pg, Ck, Nk, Pk, bk, Lk, _k, ma, Rk, Ok, Fk, Ik, Dk;
  pg = 6;
  Ck = 3;
  Nk = 6 * 60 * 1e3;
  Pk = 3e3;
  bk = 15e3;
  Lk = 6;
  _k = 1500;
  ma = (e) => {
    const t = (e == null ? void 0 : e.message) || "";
    return t.includes("HTTP 401") || t.includes("HTTP 400") || t.includes("RPC error code 16") || t.includes("Not authenticated");
  };
  Rk = async (e, t, n) => {
    try {
      return await Vl(e, t.sourceId, t.notebookId);
    } catch (r) {
      if (ma(r) || (n == null ? void 0 : n.aborted))
        throw r;
      return await o0(_k, n), await Vl(e, t.sourceId, t.notebookId);
    }
  };
  Ok = async (e, { notebookIds: t = null, onProgress: n, signal: r } = {}) => {
    var _a2;
    try {
      await Ta(e);
    } catch (p) {
      if (ma(p))
        return {
          total: 0,
          stale: [],
          staleNotebookCount: 0,
          authError: true,
          cancelled: false
        };
    }
    const a = ((_a2 = e.state.notebooklm) == null ? void 0 : _a2.projects) || [], o = t ? a.filter((p) => t.includes(p.id)) : a, s = Zg(o), l = [], i = {};
    let c = 0, u = false;
    return await pa(s, pg, async (p) => {
      if ((r == null ? void 0 : r.aborted) || u)
        return;
      let f = null;
      try {
        const d = await Sc(e, p.sourceId, p.notebookId);
        f = _d(d);
      } catch (d) {
        if (r == null ? void 0 : r.aborted)
          return;
        if (ma(d)) {
          u = true;
          return;
        }
      }
      f !== "fresh" && l.push(p), f && (i[p.notebookId] || (i[p.notebookId] = {}), i[p.notebookId][p.sourceId] = f), c++, n == null ? void 0 : n({
        phase: "checking",
        done: c,
        total: s.length,
        notebookTitle: p.notebookTitle
      });
    }, r), !(r == null ? void 0 : r.aborted) && !u && await Oc(i), {
      total: s.length,
      stale: l,
      staleNotebookCount: new Set(l.map((p) => p.notebookId)).size,
      authError: u,
      cancelled: !!(r == null ? void 0 : r.aborted)
    };
  };
  Fk = async (e, t, { onProgress: n, signal: r } = {}) => {
    const a = {
      synced: 0,
      processing: 0,
      failed: 0,
      failures: [],
      authError: false,
      cancelled: false
    };
    if (!(t == null ? void 0 : t.length))
      return a;
    const o = [];
    let s = 0;
    await pa(t, Ck, async (p) => {
      if (!((r == null ? void 0 : r.aborted) || a.authError))
        try {
          await Rk(e, p, r), o.push(p);
        } catch (f) {
          if (r == null ? void 0 : r.aborted)
            return;
          if (ma(f)) {
            a.authError = true;
            return;
          }
          a.failed++, a.failures.push({
            ...p,
            error: (f == null ? void 0 : f.message) || "Refresh failed"
          });
        } finally {
          s++, n == null ? void 0 : n({
            phase: "syncing",
            done: s,
            total: t.length,
            notebookTitle: p.notebookTitle
          });
        }
    }, r);
    const l = {};
    let i = o.map((p) => ({
      item: p,
      attempts: 0
    }));
    const c = Date.now() + Nk;
    let u = Pk;
    for (; i.length && !(r == null ? void 0 : r.aborted) && !a.authError && Date.now() < c && (await o0(u, r).catch(() => {
    }), !(r == null ? void 0 : r.aborted)); ) {
      const p = [];
      await pa(i, pg, async (f) => {
        if ((r == null ? void 0 : r.aborted) || a.authError) {
          p.push(f);
          return;
        }
        try {
          const d = await Sc(e, f.item.sourceId, f.item.notebookId);
          if (_d(d) === "fresh") {
            a.synced++;
            const { notebookId: w, sourceId: y } = f.item;
            l[w] || (l[w] = {}), l[w][y] = "fresh";
            return;
          }
        } catch (d) {
          if (ma(d)) {
            a.authError = true, p.push(f);
            return;
          }
        }
        f.attempts++, f.attempts < Lk ? p.push(f) : a.processing++;
      }, r), i = p, n == null ? void 0 : n({
        phase: "verifying",
        done: a.synced,
        total: o.length,
        remaining: i.length
      }), u = Math.min(Math.round(u * 1.4), bk);
    }
    return a.processing += i.length, (r == null ? void 0 : r.aborted) && (a.cancelled = true), await Oc(l), a;
  };
  Ik = {
    powerButton: U1,
    auth: L1,
    authNotebookLM: j1,
    notebooklm: Ky,
    batchNotebookActions: Io,
    linksExtractor: x0,
    notebookActions: Nc,
    tabInfo: L0,
    languageSettings: X1,
    notebookTags: Zv,
    sourceFolders: F5,
    notebookLabels: W5,
    playlistImport: H0,
    rssImport: Z0,
    openTabsImport: eg,
    podcastPlayer: bc,
    sourceMerge: tg,
    duplicateScan: ag,
    artifactStats: kc,
    artifacts: s0,
    studioGeneration: gv,
    themeSettings: ok,
    promptsManager: pk
  };
  Dk = {
    togglePowerButton: $1,
    setAuthNotebookLM: B1,
    disconnectNotebookLM: Yp,
    isNotebookLMAuthenticated: z1,
    switchActiveAccount: V1,
    disconnectAccount: mc,
    getAccountList: G1,
    syncAuthFromStorage: H1,
    setNotebookLMProjects: Jp,
    resetNotebookLM: e0,
    fetchNotebookLMProjects: Ta,
    createNotebookLMProject: Xy,
    deleteNotebookLMProject: qy,
    deleteSourceNotebookLM: Jy,
    renameSourceNotebookLM: ew,
    renameNotebookLM: tw,
    refreshSourceNotebookLM: Vl,
    checkSourceFreshnessNotebookLM: Sc,
    addSourceNotebookLM: nw,
    setSelectedProject: rw,
    setSelectedBatchProject: aw,
    setQuery: ow,
    setBatchQuery: sw,
    initializeNotebookProjects: lw,
    changeOutputLanguage: iw,
    getNotebookSourceContent: cw,
    exportNotebookSources: uw,
    importNotebookSources: dw,
    exportNotebookSourcesAsZip: mw,
    downloadSelectedSourcesAsZip: hw,
    importNotebookSourcesFromZip: yw,
    copySelectedSourcesToNotebook: gw,
    setBatchIsAdding: k0,
    setBatchAddSuccess: E0,
    setBatchActionType: Av,
    setBatchError: Do,
    setBatchProgressMessage: Mv,
    setBatchProgressPercent: Cv,
    setCurrentIndex: Nv,
    setTotalLinks: Pv,
    setFailedLinks: T0,
    addLinksToNotebook: bv,
    resetBatchState: Lv,
    setLinksIsExtracting: Wl,
    setLinks: Cc,
    setLinksError: Uo,
    resetLinks: Iv,
    extractLinks: Dv,
    extractFromSitemap: Uv,
    resetLinksExtractor: $v,
    setNotebookIsAdding: C0,
    setNotebookAddSuccess: N0,
    setNotebookActionType: jv,
    setNotebookError: Pc,
    addToNotebook: Hv,
    addTextContentToNotebook: Gv,
    resetNotebookActions: b0,
    setTabInfo: _0,
    setLoading: $o,
    setTabError: R0,
    setIsInNewTab: O0,
    checkContext: F0,
    getCurrentTab: I0,
    initializeTabInfo: Wv,
    resetTabInfo: Yv,
    setInterfaceLanguage: q1,
    loadLanguageSettings: J1,
    getInterfaceLanguage: ey,
    loadOutputLanguage: ty,
    getOutputLanguage: ry,
    loadFavoriteLanguages: hc,
    loadOutputFavorites: ay,
    loadInterfaceFavorites: oy,
    getFavorites: sy,
    setSwitcherPosition: ly,
    loadSwitcherPosition: iy,
    getSwitcherPosition: cy,
    setSwitcherOrientation: uy,
    loadSwitcherOrientation: dy,
    getSwitcherOrientation: fy,
    setSwitcherVisible: py,
    loadSwitcherVisible: gy,
    getSwitcherVisible: my,
    setSwitcherCollapsed: hy,
    loadSwitcherCollapsed: yy,
    getSwitcherCollapsed: wy,
    setTagsVisibleHome: vy,
    loadTagsVisibleHome: Sy,
    getTagsVisibleHome: ky,
    setTagsVisibleDetail: Ey,
    loadTagsVisibleDetail: Ty,
    getTagsVisibleDetail: xy,
    setDetailOutputsVisible: Ay,
    loadDetailOutputsVisible: My,
    setDetailActionsVisible: Cy,
    loadDetailActionsVisible: Ny,
    setDetailLogoVisible: Py,
    loadDetailLogoVisible: by,
    getEffectiveDetailLogoVisible: Ly,
    setTabBehaviorAfterImport: _y,
    loadTabBehaviorAfterImport: Ry,
    getTabBehaviorAfterImport: Oy,
    setOpenTabsInBackground: Fy,
    loadOpenTabsInBackground: Iy,
    getOpenTabsInBackground: Dy,
    setAllTagsBarVisible: Uy,
    loadAllTagsBarVisible: $y,
    getAllTagsBarVisible: jy,
    setAllTagsBarOnboardingSeen: zy,
    loadAllTagsBarOnboardingSeen: By,
    getAllTagsBarOnboardingSeen: Vy,
    loadAllLanguagePreferences: Hy,
    loadTags: Kv,
    createTag: U0,
    updateTag: Xv,
    deleteTag: qv,
    mergeTags: Jv,
    addTagToNotebook: $0,
    removeTagFromNotebook: eS,
    setNotebookTags: tS,
    bulkAddTagsToNotebooks: nS,
    bulkSetTagsForNotebooks: rS,
    getNotebookTags: aS,
    getAllTags: j0,
    searchTags: oS,
    setTagFilter: sS,
    toggleTagFilter: lS,
    setShowUntagged: iS,
    clearAllFilters: cS,
    setTagSearchQuery: uS,
    getTagUsageCounts: dS,
    quickAddTag: fS,
    exportTags: pS,
    importTags: gS,
    loadSourceFolders: I5,
    createFolder: D5,
    updateFolder: U5,
    deleteFolder: $5,
    moveSourceToFolder: j5,
    removeSourceFromFolder: z5,
    bulkMoveToFolder: B5,
    bulkRemoveFromFolder: V5,
    cleanupOrphanedSources: H5,
    exportSourceFolders: G5,
    setLabelViewMode: Y5,
    loadLabelViewModes: Q5,
    fetchLabels: Z5,
    loadLabels: K5,
    organizeUnlabeledNotebookLabels: X5,
    reorganizeNotebookLabels: q5,
    createNotebookLabel: J5,
    renameNotebookLabel: ek,
    moveSourceToNotebookLabel: tk,
    removeSourceFromNotebookLabel: nk,
    bulkMoveSourcesToNotebookLabel: rk,
    deleteNotebookLabels: ak,
    setPlaylistUrl: G0,
    setIsParsing: Ql,
    setParseError: Hr,
    setPlaylistInfo: W0,
    setVideos: Zl,
    setSelectedVideoIds: cr,
    toggleVideoSelection: ES,
    selectAllVideos: TS,
    deselectAllVideos: xS,
    parsePlaylist: AS,
    resetPlaylistImport: MS,
    setFeedUrl: K0,
    setRSSIsParsing: Kl,
    setRSSParseError: Gr,
    setFeedInfo: X0,
    setArticles: Xl,
    setSelectedArticleIds: ur,
    toggleArticleSelection: DS,
    selectAllArticles: US,
    deselectAllArticles: $S,
    parseFeed: jS,
    resetRSSImport: BS,
    setRSSIsDetecting: ql,
    setRSSDetectionError: ro,
    detectFeedFromTab: zS,
    setOpenTabsIsFetching: Jl,
    setOpenTabsFetchError: jo,
    setOpenTabs: ei,
    setSelectedTabIds: dr,
    toggleTabSelection: GS,
    selectAllTabs: WS,
    deselectAllTabs: YS,
    fetchOpenTabs: QS,
    resetOpenTabsImport: ZS,
    loadProgressMap: XS,
    scanAllNotebooks: qS,
    loadFromCache: JS,
    playAudio: Lc,
    pauseAudio: e5,
    resumeAudio: t5,
    playNext: n5,
    playPrevious: r5,
    updateProgress: s5,
    forceProgressSave: o5,
    refreshAudioUrl: l5,
    markAsListened: c5,
    toggleListened: u5,
    deletePodcasts: i5,
    setListenedBulk: _c,
    clearPodcastPlayer: f5,
    resetPodcastPlayerState: d5,
    getAudioProgress: p5,
    setIsMerging: g5,
    setMergeSuccess: m5,
    setMergeError: ng,
    setMergeProgress: ga,
    setMergeOptions: h5,
    setFetchedContents: rg,
    fetchSourceContents: y5,
    generateMergedContent: w5,
    executeMerge: v5,
    deleteOriginalSources: S5,
    resetSourceMerge: k5,
    setScanOptions: M5,
    setScanProgress: xt,
    setDuplicateGroups: og,
    setSelectedGroups: sg,
    updateGroupSelection: C5,
    setIsScanning: ni,
    setIsExecuting: ri,
    setExecutionResults: lg,
    setDuplicateFetchedContents: ig,
    scanForDuplicates: N5,
    executeDuplicateDeletion: P5,
    getDeletionSummary: b5,
    resetDuplicateScan: L5,
    loadStatsFromCache: Xw,
    scanNotebookStats: Ec,
    scanAllStats: qw,
    isCacheStale: Jw,
    getNotebookStats: ev,
    clearStats: nv,
    resetStatsState: tv,
    fetchArtifacts: Tc,
    bulkDeleteArtifacts: rv,
    renameArtifactNotebookLM: av,
    fetchQuizContent: ov,
    clearArtifacts: sv,
    cancelGeneration: v0,
    resetStudioGeneration: Sv,
    clearGenerateError: mv,
    setSelectedType: hv,
    setSelectedSourceIds: yv,
    generateArtifact: Ev,
    generatePack: xv,
    suggestShortVideoIdeas: Tv,
    checkSourcesFreshness: Ok,
    refreshSourcesBulk: Fk,
    setThemeMode: sk,
    loadThemeMode: lk,
    getThemeMode: ik,
    loadPrompts: uk,
    savePrompt: mk,
    updatePrompt: hk,
    deletePrompt: yk,
    bulkDeletePrompts: wk,
    togglePinPrompt: vk,
    loadUsageData: dk,
    getPromptUsage: fk,
    getAllPrompts: Sk,
    validateShortcode: gk,
    exportPromptsJson: Ek,
    importPromptsJson: Tk,
    generateSampleJson: xk,
    activateLicenseKey: F1,
    validateCurrentLicense: I1,
    deactivateLicenseKey: D1,
    isLicensed: ss,
    clearAuthError: O1
  };
  c2 = M1(M, Ik, Dk);
  function Uk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M9.664 1.319a.75.75 0 0 1 .672 0 41.059 41.059 0 0 1 8.198 5.424.75.75 0 0 1-.254 1.285 31.372 31.372 0 0 0-7.86 3.83.75.75 0 0 1-.84 0 31.508 31.508 0 0 0-2.08-1.287V9.394c0-.244.116-.463.302-.592a35.504 35.504 0 0 1 3.305-2.033.75.75 0 0 0-.714-1.319 37 37 0 0 0-3.446 2.12A2.216 2.216 0 0 0 6 9.393v.38a31.293 31.293 0 0 0-4.28-1.746.75.75 0 0 1-.254-1.285 41.059 41.059 0 0 1 8.198-5.424ZM6 11.459a29.848 29.848 0 0 0-2.455-1.158 41.029 41.029 0 0 0-.39 3.114.75.75 0 0 0 .419.74c.528.256 1.046.53 1.554.82-.21.324-.455.63-.739.914a.75.75 0 1 0 1.06 1.06c.37-.369.69-.77.96-1.193a26.61 26.61 0 0 1 3.095 2.348.75.75 0 0 0 .992 0 26.547 26.547 0 0 1 5.93-3.95.75.75 0 0 0 .42-.739 41.053 41.053 0 0 0-.39-3.114 29.925 29.925 0 0 0-5.199 2.801 2.25 2.25 0 0 1-2.514 0c-.41-.275-.826-.541-1.25-.797a6.985 6.985 0 0 1-1.084 3.45 26.503 26.503 0 0 0-1.281-.78A5.487 5.487 0 0 0 6 12v-.54Z",
      clipRule: "evenodd"
    }));
  }
  const $k = x.forwardRef(Uk), md = $k;
  function jk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M15.312 11.424a5.5 5.5 0 0 1-9.201 2.466l-.312-.311h2.433a.75.75 0 0 0 0-1.5H3.989a.75.75 0 0 0-.75.75v4.242a.75.75 0 0 0 1.5 0v-2.43l.31.31a7 7 0 0 0 11.712-3.138.75.75 0 0 0-1.449-.39Zm1.23-3.723a.75.75 0 0 0 .219-.53V2.929a.75.75 0 0 0-1.5 0V5.36l-.31-.31A7 7 0 0 0 3.239 8.188a.75.75 0 1 0 1.448.389A5.5 5.5 0 0 1 13.89 6.11l.311.31h-2.432a.75.75 0 0 0 0 1.5h4.243a.75.75 0 0 0 .53-.219Z",
      clipRule: "evenodd"
    }));
  }
  let zk;
  zk = x.forwardRef(jk);
  u2 = zk;
  function Bk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M4.25 5.5a.75.75 0 0 0-.75.75v8.5c0 .414.336.75.75.75h8.5a.75.75 0 0 0 .75-.75v-4a.75.75 0 0 1 1.5 0v4A2.25 2.25 0 0 1 12.75 17h-8.5A2.25 2.25 0 0 1 2 14.75v-8.5A2.25 2.25 0 0 1 4.25 4h5a.75.75 0 0 1 0 1.5h-5Z",
      clipRule: "evenodd"
    }), x.createElement("path", {
      fillRule: "evenodd",
      d: "M6.194 12.753a.75.75 0 0 0 1.06.053L16.5 4.44v2.81a.75.75 0 0 0 1.5 0v-4.5a.75.75 0 0 0-.75-.75h-4.5a.75.75 0 0 0 0 1.5h2.553l-9.056 8.194a.75.75 0 0 0-.053 1.06Z",
      clipRule: "evenodd"
    }));
  }
  let Vk;
  Vk = x.forwardRef(Bk);
  d2 = Vk;
  function Hk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M15.5 2A1.5 1.5 0 0 0 14 3.5v13a1.5 1.5 0 0 0 1.5 1.5h1a1.5 1.5 0 0 0 1.5-1.5v-13A1.5 1.5 0 0 0 16.5 2h-1ZM9.5 6A1.5 1.5 0 0 0 8 7.5v9A1.5 1.5 0 0 0 9.5 18h1a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 10.5 6h-1ZM3.5 10A1.5 1.5 0 0 0 2 11.5v5A1.5 1.5 0 0 0 3.5 18h1A1.5 1.5 0 0 0 6 16.5v-5A1.5 1.5 0 0 0 4.5 10h-1Z"
    }));
  }
  let Gk;
  Gk = x.forwardRef(Hk);
  Wk = Gk;
  function Yk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z",
      clipRule: "evenodd"
    }));
  }
  let Qk;
  Qk = x.forwardRef(Yk);
  f2 = Qk;
  function Zk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M7.84 1.804A1 1 0 0 1 8.82 1h2.36a1 1 0 0 1 .98.804l.331 1.652a6.993 6.993 0 0 1 1.929 1.115l1.598-.54a1 1 0 0 1 1.186.447l1.18 2.044a1 1 0 0 1-.205 1.251l-1.267 1.113a7.047 7.047 0 0 1 0 2.228l1.267 1.113a1 1 0 0 1 .206 1.25l-1.18 2.045a1 1 0 0 1-1.187.447l-1.598-.54a6.993 6.993 0 0 1-1.929 1.115l-.33 1.652a1 1 0 0 1-.98.804H8.82a1 1 0 0 1-.98-.804l-.331-1.652a6.993 6.993 0 0 1-1.929-1.115l-1.598.54a1 1 0 0 1-1.186-.447l-1.18-2.044a1 1 0 0 1 .205-1.251l1.267-1.114a7.05 7.05 0 0 1 0-2.227L1.821 7.773a1 1 0 0 1-.206-1.25l1.18-2.045a1 1 0 0 1 1.187-.447l1.598.54A6.992 6.992 0 0 1 7.51 3.456l.33-1.652ZM10 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
      clipRule: "evenodd"
    }));
  }
  let Kk;
  Kk = x.forwardRef(Zk);
  p2 = Kk;
  function Xk({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M4.5 2A1.5 1.5 0 0 0 3 3.5v13A1.5 1.5 0 0 0 4.5 18h11a1.5 1.5 0 0 0 1.5-1.5V7.621a1.5 1.5 0 0 0-.44-1.06l-4.12-4.122A1.5 1.5 0 0 0 11.378 2H4.5Zm2.25 8.5a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Zm0 3a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Z",
      clipRule: "evenodd"
    }));
  }
  let qk;
  qk = x.forwardRef(Xk);
  Jk = qk;
  function eE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M16.555 5.412a8.028 8.028 0 0 0-3.503-2.81 14.899 14.899 0 0 1 1.663 4.472 8.547 8.547 0 0 0 1.84-1.662ZM13.326 7.825a13.43 13.43 0 0 0-2.413-5.773 8.087 8.087 0 0 0-1.826 0 13.43 13.43 0 0 0-2.413 5.773A8.473 8.473 0 0 0 10 8.5c1.18 0 2.304-.24 3.326-.675ZM6.514 9.376A9.98 9.98 0 0 0 10 10c1.226 0 2.4-.22 3.486-.624a13.54 13.54 0 0 1-.351 3.759A13.54 13.54 0 0 1 10 13.5c-1.079 0-2.128-.127-3.134-.366a13.538 13.538 0 0 1-.352-3.758ZM5.285 7.074a14.9 14.9 0 0 1 1.663-4.471 8.028 8.028 0 0 0-3.503 2.81c.529.638 1.149 1.199 1.84 1.66ZM17.334 6.798a7.973 7.973 0 0 1 .614 4.115 13.47 13.47 0 0 1-3.178 1.72 15.093 15.093 0 0 0 .174-3.939 10.043 10.043 0 0 0 2.39-1.896ZM2.666 6.798a10.042 10.042 0 0 0 2.39 1.896 15.196 15.196 0 0 0 .174 3.94 13.472 13.472 0 0 1-3.178-1.72 7.973 7.973 0 0 1 .615-4.115ZM10 15c.898 0 1.778-.079 2.633-.23a13.473 13.473 0 0 1-1.72 3.178 8.099 8.099 0 0 1-1.826 0 13.47 13.47 0 0 1-1.72-3.178c.855.151 1.735.23 2.633.23ZM14.357 14.357a14.912 14.912 0 0 1-1.305 3.04 8.027 8.027 0 0 0 4.345-4.345c-.953.542-1.971.981-3.04 1.305ZM6.948 17.397a8.027 8.027 0 0 1-4.345-4.345c.953.542 1.971.981 3.04 1.305a14.912 14.912 0 0 0 1.305 3.04Z"
    }));
  }
  let tE;
  tE = x.forwardRef(eE);
  g2 = tE;
  function nE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z",
      clipRule: "evenodd"
    }));
  }
  let rE;
  rE = x.forwardRef(nE);
  m2 = rE;
  function aE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M7 4a3 3 0 0 1 6 0v6a3 3 0 1 1-6 0V4Z"
    }), x.createElement("path", {
      d: "M5.5 9.643a.75.75 0 0 0-1.5 0V10c0 3.06 2.29 5.585 5.25 5.954V17.5h-1.5a.75.75 0 0 0 0 1.5h4.5a.75.75 0 0 0 0-1.5h-1.5v-1.546A6.001 6.001 0 0 0 16 10v-.357a.75.75 0 0 0-1.5 0V10a4.5 4.5 0 0 1-9 0v-.357Z"
    }));
  }
  const oE = x.forwardRef(aE), sE = oE;
  function lE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "m5.433 13.917 1.262-3.155A4 4 0 0 1 7.58 9.42l6.92-6.918a2.121 2.121 0 0 1 3 3l-6.92 6.918c-.383.383-.84.685-1.343.886l-3.154 1.262a.5.5 0 0 1-.65-.65Z"
    }), x.createElement("path", {
      d: "M3.5 5.75c0-.69.56-1.25 1.25-1.25H10A.75.75 0 0 0 10 3H4.75A2.75 2.75 0 0 0 2 5.75v9.5A2.75 2.75 0 0 0 4.75 18h9.5A2.75 2.75 0 0 0 17 15.25V10a.75.75 0 0 0-1.5 0v5.25c0 .69-.56 1.25-1.25 1.25h-9.5c-.69 0-1.25-.56-1.25-1.25v-9.5Z"
    }));
  }
  const iE = x.forwardRef(lE), cE = iE;
  function uE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M10.75 4.75a.75.75 0 0 0-1.5 0v4.5h-4.5a.75.75 0 0 0 0 1.5h4.5v4.5a.75.75 0 0 0 1.5 0v-4.5h4.5a.75.75 0 0 0 0-1.5h-4.5v-4.5Z"
    }));
  }
  let dE;
  dE = x.forwardRef(uE);
  h2 = dE;
  function fE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M1 2.75A.75.75 0 0 1 1.75 2h16.5a.75.75 0 0 1 0 1.5H18v8.75A2.75 2.75 0 0 1 15.25 15h-1.072l.798 3.06a.75.75 0 0 1-1.452.38L13.41 18H6.59l-.114.44a.75.75 0 0 1-1.452-.38L5.823 15H4.75A2.75 2.75 0 0 1 2 12.25V3.5h-.25A.75.75 0 0 1 1 2.75ZM7.373 15l-.391 1.5h6.037l-.392-1.5H7.373ZM13.25 5a.75.75 0 0 1 .75.75v5.5a.75.75 0 0 1-1.5 0v-5.5a.75.75 0 0 1 .75-.75Zm-6.5 4a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 6.75 9Zm4-1.25a.75.75 0 0 0-1.5 0v3.5a.75.75 0 0 0 1.5 0v-3.5Z",
      clipRule: "evenodd"
    }));
  }
  let pE;
  pE = x.forwardRef(fE);
  gE = pE;
  function mE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M5.127 3.502 5.25 3.5h9.5c.041 0 .082 0 .123.002A2.251 2.251 0 0 0 12.75 2h-5.5a2.25 2.25 0 0 0-2.123 1.502ZM1 10.25A2.25 2.25 0 0 1 3.25 8h13.5A2.25 2.25 0 0 1 19 10.25v5.5A2.25 2.25 0 0 1 16.75 18H3.25A2.25 2.25 0 0 1 1 15.75v-5.5ZM3.25 6.5c-.04 0-.082 0-.123.002A2.25 2.25 0 0 1 5.25 5h9.5c.98 0 1.814.627 2.123 1.502a3.819 3.819 0 0 0-.123-.002H3.25Z"
    }));
  }
  const hE = x.forwardRef(mE), yE = hE;
  function wE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M15.98 1.804a1 1 0 0 0-1.96 0l-.24 1.192a1 1 0 0 1-.784.785l-1.192.238a1 1 0 0 0 0 1.962l1.192.238a1 1 0 0 1 .785.785l.238 1.192a1 1 0 0 0 1.962 0l.238-1.192a1 1 0 0 1 .785-.785l1.192-.238a1 1 0 0 0 0-1.962l-1.192-.238a1 1 0 0 1-.785-.785l-.238-1.192ZM6.949 5.684a1 1 0 0 0-1.898 0l-.683 2.051a1 1 0 0 1-.633.633l-2.051.683a1 1 0 0 0 0 1.898l2.051.684a1 1 0 0 1 .633.632l.683 2.051a1 1 0 0 0 1.898 0l.683-2.051a1 1 0 0 1 .633-.633l2.051-.683a1 1 0 0 0 0-1.898l-2.051-.683a1 1 0 0 1-.633-.633L6.95 5.684ZM13.949 13.684a1 1 0 0 0-1.898 0l-.184.551a1 1 0 0 1-.632.633l-.551.183a1 1 0 0 0 0 1.898l.551.183a1 1 0 0 1 .633.633l.183.551a1 1 0 0 0 1.898 0l.184-.551a1 1 0 0 1 .632-.633l.551-.183a1 1 0 0 0 0-1.898l-.551-.184a1 1 0 0 1-.633-.632l-.183-.551Z"
    }));
  }
  let vE;
  vE = x.forwardRef(wE);
  y2 = vE;
  function SE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      fillRule: "evenodd",
      d: "M.99 5.24A2.25 2.25 0 0 1 3.25 3h13.5A2.25 2.25 0 0 1 19 5.25l.01 9.5A2.25 2.25 0 0 1 16.76 17H3.26A2.267 2.267 0 0 1 1 14.74l-.01-9.5Zm8.26 9.52v-.625a.75.75 0 0 0-.75-.75H3.25a.75.75 0 0 0-.75.75v.615c0 .414.336.75.75.75h5.373a.75.75 0 0 0 .627-.74Zm1.5 0a.75.75 0 0 0 .627.74h5.373a.75.75 0 0 0 .75-.75v-.615a.75.75 0 0 0-.75-.75H11.5a.75.75 0 0 0-.75.75v.625Zm6.75-3.63v-.625a.75.75 0 0 0-.75-.75H11.5a.75.75 0 0 0-.75.75v.625c0 .414.336.75.75.75h5.25a.75.75 0 0 0 .75-.75Zm-8.25 0v-.625a.75.75 0 0 0-.75-.75H3.25a.75.75 0 0 0-.75.75v.625c0 .414.336.75.75.75H8.5a.75.75 0 0 0 .75-.75ZM17.5 7.5v-.625a.75.75 0 0 0-.75-.75H11.5a.75.75 0 0 0-.75.75V7.5c0 .414.336.75.75.75h5.25a.75.75 0 0 0 .75-.75Zm-8.25 0v-.625a.75.75 0 0 0-.75-.75H3.25a.75.75 0 0 0-.75.75V7.5c0 .414.336.75.75.75H8.5a.75.75 0 0 0 .75-.75Z",
      clipRule: "evenodd"
    }));
  }
  let kE;
  kE = x.forwardRef(SE);
  EE = kE;
  function TE({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M3.25 4A2.25 2.25 0 0 0 1 6.25v7.5A2.25 2.25 0 0 0 3.25 16h7.5A2.25 2.25 0 0 0 13 13.75v-7.5A2.25 2.25 0 0 0 10.75 4h-7.5ZM19 4.75a.75.75 0 0 0-1.28-.53l-3 3a.75.75 0 0 0-.22.53v4.5c0 .199.079.39.22.53l3 3a.75.75 0 0 0 1.28-.53V4.75Z"
    }));
  }
  let xE;
  xE = x.forwardRef(TE);
  AE = xE;
  function ME({ title: e, titleId: t, ...n }, r) {
    return x.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? x.createElement("title", {
      id: t
    }, e) : null, x.createElement("path", {
      d: "M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z"
    }));
  }
  let CE;
  CE = x.forwardRef(ME);
  w2 = CE;
  var gg = {
    exports: {}
  };
  (function(e) {
    (function() {
      var t = {}.hasOwnProperty;
      function n() {
        for (var o = "", s = 0; s < arguments.length; s++) {
          var l = arguments[s];
          l && (o = a(o, r(l)));
        }
        return o;
      }
      function r(o) {
        if (typeof o == "string" || typeof o == "number")
          return o;
        if (typeof o != "object")
          return "";
        if (Array.isArray(o))
          return n.apply(null, o);
        if (o.toString !== Object.prototype.toString && !o.toString.toString().includes("[native code]"))
          return o.toString();
        var s = "";
        for (var l in o)
          t.call(o, l) && o[l] && (s = a(s, l));
        return s;
      }
      function a(o, s) {
        return s ? o ? o + " " + s : o + s : o;
      }
      e.exports ? (n.default = n, e.exports = n) : window.classNames = n;
    })();
  })(gg);
  var NE = gg.exports;
  v2 = wi(NE);
  PE = ({ className: e }) => ft.jsxs("svg", {
    className: e,
    fill: "currentColor",
    viewBox: "0 0 20 20",
    children: [
      ft.jsx("circle", {
        cx: "10",
        cy: "10",
        r: "3"
      }),
      ft.jsx("circle", {
        cx: "4",
        cy: "4",
        r: "2"
      }),
      ft.jsx("circle", {
        cx: "16",
        cy: "4",
        r: "2"
      }),
      ft.jsx("circle", {
        cx: "4",
        cy: "16",
        r: "2"
      }),
      ft.jsx("circle", {
        cx: "16",
        cy: "16",
        r: "2"
      }),
      ft.jsx("line", {
        x1: "7",
        y1: "8",
        x2: "5",
        y2: "5",
        stroke: "currentColor",
        strokeWidth: "1.5"
      }),
      ft.jsx("line", {
        x1: "13",
        y1: "8",
        x2: "15",
        y2: "5",
        stroke: "currentColor",
        strokeWidth: "1.5"
      }),
      ft.jsx("line", {
        x1: "7",
        y1: "12",
        x2: "5",
        y2: "15",
        stroke: "currentColor",
        strokeWidth: "1.5"
      }),
      ft.jsx("line", {
        x1: "13",
        y1: "12",
        x2: "15",
        y2: "15",
        stroke: "currentColor",
        strokeWidth: "1.5"
      })
    ]
  });
  S2 = {
    [O.AUDIO]: sE,
    [O.REPORT]: Jk,
    [O.VIDEO]: AE,
    [O.QUIZ_OR_FLASHCARDS]: md,
    [O.QUIZ]: md,
    [O.FLASHCARDS]: yE,
    [O.MIND_MAP]: PE,
    [O.INFOGRAPHIC]: Wk,
    [O.SLIDE_DECK]: gE,
    [O.DATA_TABLE]: EE,
    [O.NOTE]: cE
  };
  k2 = {
    [O.AUDIO]: "Audio",
    [O.REPORT]: "Reports",
    [O.VIDEO]: "Videos",
    [O.QUIZ_OR_FLASHCARDS]: "Quizzes",
    [O.QUIZ]: "Quizzes",
    [O.FLASHCARDS]: "Flashcards",
    [O.MIND_MAP]: "Mind Maps",
    [O.INFOGRAPHIC]: "Infographics",
    [O.SLIDE_DECK]: "Slide Decks",
    [O.DATA_TABLE]: "Data Tables",
    [O.NOTE]: "Notes"
  };
  E2 = {
    [O.AUDIO]: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    [O.VIDEO]: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300",
    [O.MIND_MAP]: "bg-pink-100 text-pink-700 dark:bg-pink-950 dark:text-pink-300",
    [O.REPORT]: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
    [O.QUIZ_OR_FLASHCARDS]: "bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300",
    [O.QUIZ]: "bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300",
    [O.FLASHCARDS]: "bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300",
    [O.INFOGRAPHIC]: "bg-pink-100 text-pink-700 dark:bg-pink-950 dark:text-pink-300",
    [O.SLIDE_DECK]: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
    [O.DATA_TABLE]: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    [O.NOTE]: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300"
  };
  T2 = {
    [O.AUDIO]: {
      light: "bg-blue-100 text-blue-700",
      dark: "bg-blue-950 text-blue-300"
    },
    [O.VIDEO]: {
      light: "bg-green-100 text-green-700",
      dark: "bg-green-950 text-green-300"
    },
    [O.MIND_MAP]: {
      light: "bg-pink-100 text-pink-700",
      dark: "bg-pink-950 text-pink-300"
    },
    [O.REPORT]: {
      light: "bg-amber-100 text-amber-700",
      dark: "bg-amber-950 text-amber-300"
    },
    [O.QUIZ_OR_FLASHCARDS]: {
      light: "bg-cyan-100 text-cyan-700",
      dark: "bg-cyan-950 text-cyan-300"
    },
    [O.QUIZ]: {
      light: "bg-cyan-100 text-cyan-700",
      dark: "bg-cyan-950 text-cyan-300"
    },
    [O.FLASHCARDS]: {
      light: "bg-violet-100 text-violet-700",
      dark: "bg-violet-950 text-violet-300"
    },
    [O.INFOGRAPHIC]: {
      light: "bg-pink-100 text-pink-700",
      dark: "bg-pink-950 text-pink-300"
    },
    [O.SLIDE_DECK]: {
      light: "bg-amber-100 text-amber-700",
      dark: "bg-amber-950 text-amber-300"
    },
    [O.DATA_TABLE]: {
      light: "bg-blue-100 text-blue-700",
      dark: "bg-blue-950 text-blue-300"
    },
    [O.NOTE]: {
      light: "bg-gray-100 text-gray-600",
      dark: "bg-gray-800 text-gray-300"
    }
  };
})();
export {
  zE as $,
  S2 as A,
  JE as B,
  p2 as C,
  e2 as D,
  RE as E,
  OE as F,
  g2 as G,
  Bl as H,
  IE as I,
  B as J,
  FE as K,
  E2 as L,
  m2 as M,
  n0 as N,
  BE as O,
  h2 as P,
  HE as Q,
  T1 as R,
  ht as S,
  n2 as T,
  t2 as U,
  a2 as V,
  r2 as W,
  w2 as X,
  o2 as Y,
  CS as Z,
  NS as _,
  __tla,
  T2 as a,
  Jk as a0,
  Qp as a1,
  Z1 as a2,
  DE as a3,
  UE as a4,
  $E as a5,
  jE as a6,
  Wk as a7,
  vc as a8,
  Yw as a9,
  WE as aa,
  YE as ab,
  QE as ac,
  Qw as ad,
  EE as ae,
  pw as af,
  gE as ag,
  AE as ah,
  PE as ai,
  ir as aj,
  GE as ak,
  Hw as al,
  VE as am,
  k2 as b,
  v2 as c,
  y2 as d,
  d2 as e,
  s2 as f,
  A5 as g,
  u2 as h,
  l2 as i,
  ft as j,
  f2 as k,
  Ro as l,
  M as m,
  E1 as n,
  y0 as o,
  h0 as p,
  $ as q,
  x as r,
  i2 as s,
  _E as t,
  c2 as u,
  ZE as v,
  KE as w,
  fv as x,
  XE as y,
  qE as z
};
