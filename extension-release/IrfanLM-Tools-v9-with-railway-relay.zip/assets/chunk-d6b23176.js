import { r as a, u as W, j as n, c, G as kn, C as An, X as rn, S as jn, l as Cn, A as On, a as tt, b as rt, d as et, e as ot, g as at, s as Nn, f as it, i as st, h as Sn, P as zn, T as G, M as ct, k as lt, R as H, m as K, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { I as dt, O as gt, S as pt, a as bt, b as wt, c as ht, N as Tn, R as mt, d as wn, T as yt, D as ut, e as xt, f as vt, g as ft, A as kt, h as jt, i as Ct, P as cn, j as bn, k as ln } from "./chunk-68adfa56.js";
import { T as X, __tla as __tla_1 } from "./chunk-95b0b380.js";
import { D as Nt, __tla as __tla_2 } from "./chunk-bd7b16ee.js";
import { T as Mn, __tla as __tla_3 } from "./chunk-b5767d08.js";
import { I as St, __tla as __tla_4 } from "./chunk-d4733473.js";
import { g as zt, E as Tt, __tla as __tla_5 } from "./chunk-4ab815d8.js";
import "./chunk-725317a4.js";
Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  function Et({ title: e, titleId: r, ...t }, o) {
    return a.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": r
    }, t), e ? a.createElement("title", {
      id: r
    }, e) : null, a.createElement("path", {
      fillRule: "evenodd",
      d: "M4.72 9.47a.75.75 0 0 0 0 1.06l4.25 4.25a.75.75 0 1 0 1.06-1.06L6.31 10l3.72-3.72a.75.75 0 1 0-1.06-1.06L4.72 9.47Zm9.25-4.25L9.72 9.47a.75.75 0 0 0 0 1.06l4.25 4.25a.75.75 0 1 0 1.06-1.06L11.31 10l3.72-3.72a.75.75 0 0 0-1.06-1.06Z",
      clipRule: "evenodd"
    }));
  }
  const Lt = a.forwardRef(Et), It = Lt;
  function Rt({ title: e, titleId: r, ...t }, o) {
    return a.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": r
    }, t), e ? a.createElement("title", {
      id: r
    }, e) : null, a.createElement("path", {
      fillRule: "evenodd",
      d: "M9.47 4.72a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 1 1-1.06 1.06L10 6.31l-3.72 3.72a.75.75 0 1 1-1.06-1.06l4.25-4.25Zm-4.25 9.25 4.25-4.25a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 1 1-1.06 1.06L10 11.31l-3.72 3.72a.75.75 0 0 1-1.06-1.06Z",
      clipRule: "evenodd"
    }));
  }
  const At = a.forwardRef(Rt), Ot = At, Q = () => {
    const [e, r] = a.useState(() => document.body.classList.contains("dark-theme"));
    return a.useEffect(() => {
      const t = () => {
        r(document.body.classList.contains("dark-theme"));
      };
      t();
      const o = new MutationObserver((l) => {
        for (const m of l)
          m.attributeName === "class" && t();
      });
      return o.observe(document.body, {
        attributes: true,
        attributeFilter: [
          "class"
        ]
      }), () => o.disconnect();
    }, []), e;
  };
  function Mt() {
    const e = Q(), [r, t] = W(), { interfaceLanguage: o, interfaceFavorites: l, outputFavorites: m, outputLanguage: v, switcherPosition: i, switcherOrientation: y, switcherVisible: u, switcherCollapsed: g } = r.languageSettings, [N, j] = a.useState(false), [k, x] = a.useState(null), E = t.isNotebookLMAuthenticated();
    a.useEffect(() => {
      t.loadLanguageSettings(), t.loadInterfaceFavorites(), t.loadOutputFavorites(), t.loadOutputLanguage(), t.loadSwitcherPosition(), t.loadSwitcherOrientation(), t.loadSwitcherVisible(), t.loadSwitcherCollapsed();
      const h = (f, F) => {
        F === "local" && (f[jn.INTERFACE_FAVORITES] && t.loadInterfaceFavorites(), f[jn.OUTPUT_FAVORITES] && t.loadOutputFavorites(), f[dt] && t.loadLanguageSettings(), f[gt] && t.loadOutputLanguage(), f[pt] && t.loadSwitcherPosition(), f[bt] && t.loadSwitcherOrientation(), f[wt] && t.loadSwitcherVisible(), f[ht] && t.loadSwitcherCollapsed());
      };
      return chrome.storage.onChanged.addListener(h), () => chrome.storage.onChanged.removeListener(h);
    }, []);
    const z = () => {
      window.open(chrome.runtime.getURL("popup.html#/settings?tab=language"), "_blank");
    }, p = (h, f = "success") => {
      x({
        message: h,
        type: f
      }), setTimeout(() => x(null), 2e3);
    }, S = () => {
      t.setSwitcherVisible(false), p("Language switcher hidden. Re-enable in extension settings.");
    }, I = (h) => {
      t.setInterfaceLanguage(h);
      const f = Cn.interfaceLanguages.find((F) => F.code === h);
      p(`Interface: ${(f == null ? void 0 : f.name) || h}`);
    }, b = async (h) => {
      if (!E) {
        p("Connect to NotebookLM first", "error");
        return;
      }
      if (!N) {
        j(true);
        try {
          await t.changeOutputLanguage(h), await t.loadOutputLanguage();
          const f = Cn.outputLanguages.find((F) => F.code === h);
          p(`Output: ${(f == null ? void 0 : f.name) || h || "Default"}`), setTimeout(() => {
            window.location.reload();
          }, 500);
        } catch (f) {
          console.error("Failed to change output language:", f), p("Failed to change output language", "error");
        } finally {
          j(false);
        }
      }
    }, d = l.slice(0, 5), w = m.slice(0, 5), T = d.length > 0, R = w.length > 0, P = T || R, U = () => {
      switch (i) {
        case "top-left":
          return "top-2 left-2";
        case "top-right":
          return "top-2 right-2";
        case "bottom-left":
          return "bottom-2 left-2";
        case "bottom-right":
          return "bottom-2 right-2";
        case "middle-left":
          return "top-1/2 -translate-y-1/2 left-2";
        case "middle-right":
          return "top-1/2 -translate-y-1/2 right-2";
        default:
          return "bottom-2 right-2";
      }
    }, L = y === "vertical", J = (o == null ? void 0 : o.toUpperCase()) || "EN", B = L ? Ot : It;
    return u ? n.jsxs(n.Fragment, {
      children: [
        k && n.jsx("div", {
          className: "fixed top-2 right-2 z-[99999]",
          children: n.jsx("div", {
            className: c("px-2 py-1 rounded shadow-lg text-xs text-white", k.type === "error" ? "bg-red-600" : e ? "bg-gray-700" : "bg-gray-900"),
            children: k.message
          })
        }),
        g ? n.jsx("div", {
          className: `fixed z-[9999] font-sans opacity-60 hover:opacity-100 ${U()}`,
          children: n.jsxs("button", {
            onClick: () => t.setSwitcherCollapsed(false),
            className: c("relative flex items-center justify-center w-8 h-8 rounded-full shadow-lg border", e ? "bg-gray-800 border-gray-700 text-blue-400 hover:bg-gray-700" : "bg-white border-gray-200 text-blue-600 hover:bg-gray-50"),
            title: "Expand language switcher",
            children: [
              n.jsx(kn, {
                className: "w-4 h-4"
              }),
              n.jsx("span", {
                className: c("absolute -bottom-0.5 -right-0.5 text-[8px] font-bold leading-none px-0.5 rounded", e ? "bg-gray-700 text-gray-300" : "bg-gray-100 text-gray-600"),
                children: J
              })
            ]
          })
        }) : P ? n.jsx("div", {
          className: `fixed z-[9999] font-sans opacity-60 hover:opacity-100 ${U()}`,
          children: n.jsxs("div", {
            className: c("border rounded-lg shadow-sm p-1.5 flex", L ? "flex-col gap-1.5" : "items-center gap-2", e ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"),
            children: [
              T && n.jsxs("div", {
                className: `flex ${L ? "flex-col gap-1" : "items-center gap-0.5"}`,
                children: [
                  n.jsx("span", {
                    className: c("text-xs", L ? "text-center pb-0.5" : "px-1", e ? "text-gray-400" : "text-gray-500"),
                    children: "UI"
                  }),
                  n.jsx("div", {
                    className: `flex ${L ? "flex-col" : "items-center"} gap-0.5`,
                    children: d.map((h) => {
                      const f = o === h.code;
                      return n.jsx("button", {
                        onClick: () => !f && I(h.code),
                        title: h.name,
                        className: c("px-1.5 py-0.5 text-xs rounded", f ? "bg-blue-600 text-white" : e ? "bg-gray-700 text-gray-300 hover:bg-blue-900/30 hover:text-blue-400" : "bg-gray-100 text-gray-700 hover:bg-blue-50 hover:text-blue-600", L && "text-center"),
                        children: h.code.toUpperCase()
                      }, h.code);
                    })
                  })
                ]
              }),
              T && R && n.jsx("div", {
                className: c(L ? "h-px w-full" : "w-px h-4", e ? "bg-gray-700" : "bg-gray-200")
              }),
              R && n.jsxs("div", {
                className: `flex ${L ? "flex-col gap-1" : "items-center gap-0.5"}`,
                children: [
                  n.jsx("span", {
                    className: c("text-xs", L ? "text-center pb-0.5" : "px-1", e ? "text-gray-400" : "text-gray-500"),
                    children: "OUT"
                  }),
                  E ? n.jsx("div", {
                    className: `flex ${L ? "flex-col" : "items-center"} gap-0.5`,
                    children: w.map((h) => {
                      var _a;
                      const f = v === h.code, F = h.code === null, _ = N;
                      return n.jsx("button", {
                        onClick: () => !_ && b(h.code),
                        disabled: _,
                        title: h.name || "Default",
                        className: c("px-1.5 py-0.5 text-xs rounded", f ? "bg-blue-600 text-white" : _ ? e ? "bg-gray-700 text-gray-500 cursor-not-allowed" : "bg-gray-100 text-gray-400 cursor-not-allowed" : e ? "bg-gray-700 text-gray-300 hover:bg-blue-900/30 hover:text-blue-400" : "bg-gray-100 text-gray-700 hover:bg-blue-50 hover:text-blue-600", L && "text-center"),
                        children: F ? "DEF" : ((_a = h.code) == null ? void 0 : _a.toUpperCase()) || "N/A"
                      }, h.code || "default");
                    })
                  }) : n.jsx("div", {
                    className: c("px-1.5 py-0.5 rounded text-xs", L && "text-center", e ? "bg-amber-900/40 text-amber-400" : "bg-amber-50 text-amber-700"),
                    children: "Connect"
                  })
                ]
              }),
              n.jsx("div", {
                className: c(L ? "h-px w-full" : "w-px h-4", e ? "bg-gray-700" : "bg-gray-200")
              }),
              n.jsxs("div", {
                className: c("flex gap-0.5", L ? "flex-row justify-center" : "items-center"),
                children: [
                  n.jsx("button", {
                    onClick: () => t.setSwitcherCollapsed(true),
                    className: c("p-1 rounded", e ? "text-gray-500 hover:text-gray-300 hover:bg-gray-700" : "text-gray-400 hover:text-gray-600 hover:bg-gray-50"),
                    title: "Minimize",
                    children: n.jsx(B, {
                      className: "w-3 h-3"
                    })
                  }),
                  n.jsx("button", {
                    onClick: z,
                    className: c("p-1 rounded", e ? "text-gray-500 hover:text-gray-300 hover:bg-gray-700" : "text-gray-400 hover:text-gray-600 hover:bg-gray-50"),
                    title: "Open settings",
                    children: n.jsx(An, {
                      className: "w-3.5 h-3.5"
                    })
                  }),
                  n.jsx("button", {
                    onClick: S,
                    className: c("p-1 rounded", e ? "text-gray-500 hover:text-gray-300 hover:bg-gray-700" : "text-gray-400 hover:text-gray-600 hover:bg-gray-50"),
                    title: "Hide switcher",
                    children: n.jsx(rn, {
                      className: "w-3.5 h-3.5"
                    })
                  })
                ]
              })
            ]
          })
        }) : n.jsx("div", {
          className: `fixed z-[9999] font-sans opacity-60 hover:opacity-100 ${U()}`,
          children: n.jsxs("div", {
            className: c("border rounded shadow-lg p-1.5 max-w-[160px]", e ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"),
            children: [
              n.jsxs("div", {
                className: "flex items-center gap-1 mb-1",
                children: [
                  n.jsx(kn, {
                    className: c("w-3.5 h-3.5", e ? "text-blue-400" : "text-blue-500")
                  }),
                  n.jsx("span", {
                    className: c("text-xs font-medium", e ? "text-gray-200" : "text-gray-700"),
                    children: "Quick Language Switcher"
                  })
                ]
              }),
              n.jsx("div", {
                className: c("text-xs mb-1.5 leading-snug", e ? "text-gray-400" : "text-gray-500"),
                children: "Switch languages with one click"
              }),
              n.jsxs("div", {
                className: "flex gap-1",
                children: [
                  n.jsx("button", {
                    onClick: z,
                    className: "flex-1 px-1.5 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded",
                    children: "Open Settings"
                  }),
                  n.jsx("button", {
                    onClick: S,
                    className: c("px-1.5 py-1 text-xs font-medium rounded border", e ? "border-gray-600 text-gray-300 hover:bg-gray-700" : "border-gray-300 text-gray-600 hover:bg-gray-50"),
                    children: "Hide"
                  })
                ]
              })
            ]
          })
        })
      ]
    }) : null;
  }
  function Pt() {
    return W(), n.jsx("div", {
      children: n.jsx(Mt, {})
    });
  }
  const Dt = Object.keys(On).map(Number);
  function Ft({ stats: e, isLoading: r, isDarkMode: t }) {
    if (r && !e)
      return n.jsxs("span", {
        className: c("inline-flex items-center gap-1 text-xs", t ? "text-gray-500" : "text-gray-400"),
        children: [
          n.jsx("span", {
            className: c("w-2 h-2 rounded-full animate-pulse", t ? "bg-gray-600" : "bg-gray-300")
          }),
          "Outputs\u2026"
        ]
      });
    if (!e || !e.total)
      return null;
    const o = Dt.filter((l) => e[l] > 0);
    return o.length === 0 ? null : n.jsx("div", {
      className: "flex items-center gap-1.5 flex-wrap",
      children: o.map((l) => {
        var _a;
        const m = On[l], v = e[l], i = rt[l], y = ((_a = tt[l]) == null ? void 0 : _a[t ? "dark" : "light"]) || (t ? "bg-gray-700 text-gray-200" : "bg-gray-100 text-gray-700");
        return n.jsxs("span", {
          title: `${v} ${i}`,
          className: c("inline-flex items-center gap-1 px-2 py-0.5 text-xs rounded-full", y),
          children: [
            n.jsx(m, {
              className: "w-3 h-3 flex-shrink-0"
            }),
            n.jsxs("span", {
              className: "whitespace-nowrap",
              children: [
                v,
                " ",
                i
              ]
            })
          ]
        }, l);
      })
    });
  }
  function dn(e, r) {
    const t = r ? `?action=${r}` : "", o = chrome.runtime.getURL(`popup.html#/notebook/${e}${t}`);
    window.open(o, "_blank");
  }
  function _t({ notebookId: e, duplicateCount: r = 0, isDarkMode: t }) {
    const o = "inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-full border", l = c(o, t ? "text-gray-300 border-gray-600 hover:bg-gray-700" : "text-gray-600 border-gray-300 hover:bg-gray-100"), m = r > 0, v = m ? c(o, t ? "text-amber-400 border-amber-700 bg-amber-900/30 hover:bg-amber-900/50" : "text-amber-600 border-amber-300 bg-amber-50 hover:bg-amber-100") : l;
    return n.jsxs("div", {
      className: "flex items-center gap-1.5 flex-wrap",
      children: [
        n.jsxs("button", {
          type: "button",
          onClick: () => dn(e, Tn.GENERATE),
          className: l,
          title: "Generate outputs (reports, quizzes, mind maps\u2026) for this notebook",
          children: [
            n.jsx(et, {
              className: "w-3 h-3"
            }),
            "Generate"
          ]
        }),
        n.jsxs("button", {
          type: "button",
          onClick: () => dn(e, Tn.DUPLICATES),
          className: v,
          title: m ? `${r} likely duplicate group${r === 1 ? "" : "s"} \u2014 review & clean up` : "Scan this notebook for duplicate sources",
          children: [
            n.jsx(Nt, {
              className: "w-3 h-3"
            }),
            m ? `${r} duplicates` : "Find duplicates"
          ]
        }),
        n.jsxs("button", {
          type: "button",
          onClick: () => dn(e),
          className: l,
          title: "Open this notebook in NotebookLM Tools",
          children: [
            n.jsx(ot, {
              className: "w-3 h-3"
            }),
            "Open"
          ]
        })
      ]
    });
  }
  const En = () => G[Math.floor(Math.random() * G.length)];
  function Ln() {
    const e = window.location.pathname.match(/\/notebook\/([a-f0-9-]+)/i);
    return e ? e[1] : null;
  }
  function Ut() {
    var _a, _b;
    const [e, r] = W(), t = Q(), { tagsVisibleDetail: o, detailOutputsVisible: l, detailActionsVisible: m } = e.languageSettings, { notebooklm: v } = e, [i, y] = a.useState(Ln()), [u, g] = a.useState(false), [N, j] = a.useState(""), [k, x] = a.useState(() => En()), E = a.useRef(null), [z, p] = a.useState({}), [S, I] = a.useState(false), [b, d] = a.useState(false), [w, T] = a.useState({
      current: 0,
      total: 0,
      currentSource: ""
    }), [R, P] = a.useState(null), [U, L] = a.useState(false), [J, B] = a.useState(null), h = a.useRef(0), f = a.useRef([]), _ = ((_b = (_a = v == null ? void 0 : v.projects) == null ? void 0 : _a.find((s) => s.id === i)) == null ? void 0 : _b.sources) || [], D = _.filter((s) => mt.includes(s.sourceType)), nn = Object.values(z).filter((s) => s === "stale").length, $n = e.artifactStats.statsMap[i], Vn = e.artifactStats.loadingMap[i], qn = a.useMemo(() => m && _.length > 1 ? at(_).length : 0, [
      _,
      m
    ]);
    a.useEffect(() => {
      r.loadTags(), r.loadTagsVisibleDetail(), r.loadDetailOutputsVisible(), r.loadDetailActionsVisible(), r.loadDetailLogoVisible(), r.initializeNotebookProjects();
      const s = () => {
        f.current.forEach(clearTimeout), f.current = [], h.current++;
        const M = Ln();
        y(M), p({}), I(false), d(false), P(null), L(false), B(null), T({
          current: 0,
          total: 0,
          currentSource: ""
        });
      }, C = {
        [wn]: r.loadTags,
        [yt]: r.loadTagsVisibleDetail,
        [ut]: r.loadDetailOutputsVisible,
        [xt]: r.loadDetailActionsVisible,
        [vt]: r.loadDetailLogoVisible,
        [ft]: r.fetchNotebookLMProjects,
        [kt]: r.loadStatsFromCache
      }, O = (M, $) => {
        if ($ === "local")
          for (const A of Object.keys(C))
            M[A] && C[A]();
      };
      return window.addEventListener("popstate", s), chrome.storage.onChanged.addListener(O), () => {
        f.current.forEach(clearTimeout), f.current = [], h.current = -1, window.removeEventListener("popstate", s), chrome.storage.onChanged.removeListener(O);
      };
    }, []);
    const tn = a.useCallback(async () => {
      if (!i || D.length === 0)
        return;
      const s = h.current;
      I(true), L(false), p({}), P(null);
      const C = 5, O = {};
      try {
        for (let M = 0; M < D.length; M += C) {
          if (h.current !== s)
            return;
          const $ = D.slice(M, M + C);
          if (await Promise.all($.map(async (A) => {
            var _a2, _b2;
            try {
              const Y = ((_b2 = (_a2 = await r.checkSourceFreshnessNotebookLM(A.id, i)) == null ? void 0 : _a2[0]) == null ? void 0 : _b2[1]) === false;
              O[A.id] = Y ? "stale" : "fresh";
            } catch {
              O[A.id] = null;
            }
          })), h.current !== s)
            return;
          p((A) => ({
            ...A,
            ...O
          }));
        }
        if (h.current !== s)
          return;
        await Nn(i, O), B((/* @__PURE__ */ new Date()).toISOString());
      } finally {
        h.current === s && I(false);
      }
    }, [
      i,
      D,
      r
    ]), mn = a.useCallback(async () => {
      if (!i)
        return;
      const s = h.current, C = await it(i);
      h.current === s && (C && !st(C) ? (p(C.results), L(true), B(C.lastCheckTime)) : tn());
    }, [
      i,
      tn
    ]);
    a.useEffect(() => {
      D.length > 0 && i && !S && !b && D.filter((C) => z[C.id] === void 0).length > 0 && Object.keys(z).length === 0 && mn();
    }, [
      D.length,
      i,
      mn
    ]), a.useEffect(() => {
      if (!i)
        return;
      let s = false;
      return (async () => (r.getNotebookStats(i) || await r.loadStatsFromCache(), !s && r.isNotebookLMAuthenticated() && r.scanNotebookStats(i)))(), () => {
        s = true;
      };
    }, [
      i,
      r
    ]);
    const Hn = a.useCallback(async () => {
      if (!i) {
        P({
          success: 0,
          failed: 0,
          error: "Could not find notebook ID"
        });
        return;
      }
      const s = D.filter((A) => z[A.id] === "stale");
      if (s.length === 0)
        return;
      const C = h.current;
      d(true), P(null);
      let O = 0, M = 0;
      const $ = {
        ...z
      };
      for (let A = 0; A < s.length; A++) {
        if (h.current !== C) {
          d(false);
          return;
        }
        const V = s[A];
        T({
          current: A + 1,
          total: s.length,
          currentSource: V.title || "Unknown source"
        });
        try {
          await r.refreshSourceNotebookLM(V.id, i), O++, $[V.id] = "fresh", p((Y) => ({
            ...Y,
            [V.id]: "fresh"
          }));
        } catch (Y) {
          console.error(`Failed to refresh source ${V.title}:`, Y), M++;
        }
      }
      if (h.current !== C) {
        d(false);
        return;
      }
      if (O > 0) {
        if (T({
          current: s.length,
          total: s.length,
          currentSource: ""
        }), await Nn(i, $), h.current !== C) {
          d(false);
          return;
        }
        f.current.push(setTimeout(() => {
          window.location.reload();
        }, 1e3)), f.current.push(setTimeout(() => {
          d(false);
        }, 5e3));
      } else
        P({
          success: O,
          failed: M
        }), d(false);
    }, [
      i,
      D,
      z,
      r
    ]), Yn = a.useCallback(() => {
      p({}), L(false), B(null), P(null), tn();
    }, [
      tn
    ]);
    a.useEffect(() => {
      const s = (C) => {
        E.current && ((C.composedPath ? C.composedPath() : [
          C.target
        ]).includes(E.current) || (g(false), j("")));
      };
      if (u) {
        const C = setTimeout(() => {
          document.addEventListener("click", s);
        }, 0);
        return () => {
          clearTimeout(C), document.removeEventListener("click", s);
        };
      }
    }, [
      u
    ]);
    const en = i ? r.getNotebookTags(i) : [], yn = r.getAllTags(), Gn = new Set(en.map((s) => s.id)), on = yn.filter((s) => !Gn.has(s.id) && s.name.toLowerCase().includes(N.toLowerCase())), an = N.trim() && !yn.some((s) => s.name.toLowerCase() === N.trim().toLowerCase()), Xn = (s) => {
      const C = chrome.runtime.getURL(`popup.html#/notebooklm?tag=${s.id}`);
      window.open(C, "_blank");
    }, Wn = async (s) => {
      await r.removeTagFromNotebook(i, s.id);
    }, Kn = async (s) => {
      await r.addTagToNotebook(i, s.id), j(""), g(false);
    }, un = async () => {
      N.trim() && (await r.quickAddTag(i, N.trim(), k), j(""), x(En()), g(false));
    }, Qn = () => {
      const C = (G.indexOf(k) + 1) % G.length;
      x(G[C]);
    }, sn = S || nn > 0 || (R == null ? void 0 : R.failed) > 0 || U, xn = r.getEffectiveDetailLogoVisible(), Zn = i && (o || sn || l || m), Jn = sn || o || xn;
    if (!Zn)
      return null;
    const vn = "IrfanLM Tools", fn = chrome.runtime.getURL("img/logo-96.png"), nt = () => {
      window.open(chrome.runtime.getURL("popup.html#/settings?tab=account"), "_blank");
    };
    return n.jsxs(n.Fragment, {
      children: [
        n.jsxs("div", {
          className: c("font-sans border rounded-lg shadow-sm mx-4 my-2 px-4 py-2", t ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"),
          children: [
            n.jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                sn && n.jsxs("div", {
                  className: "flex-shrink-0",
                  children: [
                    S && n.jsxs("span", {
                      className: c("inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-full", t ? "bg-gray-700 text-gray-400" : "bg-gray-100 text-gray-500"),
                      children: [
                        n.jsxs("svg", {
                          className: "animate-spin w-3 h-3",
                          xmlns: "http://www.w3.org/2000/svg",
                          fill: "none",
                          viewBox: "0 0 24 24",
                          children: [
                            n.jsx("circle", {
                              className: "opacity-25",
                              cx: "12",
                              cy: "12",
                              r: "10",
                              stroke: "currentColor",
                              strokeWidth: "4"
                            }),
                            n.jsx("path", {
                              className: "opacity-75",
                              fill: "currentColor",
                              d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            })
                          ]
                        }),
                        "Checking..."
                      ]
                    }),
                    !S && nn > 0 && n.jsxs("button", {
                      onClick: Hn,
                      className: c("inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full", t ? "text-amber-400 bg-amber-900/30 hover:bg-amber-900/50" : "text-amber-600 bg-amber-50 hover:bg-amber-100"),
                      children: [
                        n.jsx(Sn, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Sync ",
                        nn,
                        " ",
                        nn === 1 ? "source" : "sources"
                      ]
                    }),
                    (R == null ? void 0 : R.failed) > 0 && n.jsxs("button", {
                      onClick: () => P(null),
                      className: c("inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full", t ? "text-red-400 bg-red-900/30 hover:bg-red-900/50" : "text-red-600 bg-red-50 hover:bg-red-100"),
                      children: [
                        n.jsx(rn, {
                          className: "w-3.5 h-3.5"
                        }),
                        R.failed,
                        " failed"
                      ]
                    }),
                    U && !S && n.jsxs("button", {
                      onClick: Yn,
                      className: c("inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-full", t ? "text-gray-400 bg-gray-700 hover:bg-gray-600" : "text-gray-500 bg-gray-100 hover:bg-gray-200"),
                      children: [
                        n.jsx(Sn, {
                          className: "w-3 h-3"
                        }),
                        J ? `Checked ${new Date(J).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit"
                        })}` : "Re-check"
                      ]
                    })
                  ]
                }),
                o && n.jsxs("div", {
                  className: "flex items-center gap-2 flex-wrap flex-1",
                  children: [
                    n.jsxs("div", {
                      className: c("flex items-center gap-1", t ? "text-gray-400" : "text-gray-500"),
                      children: [
                        n.jsx(Mn, {
                          className: "w-3.5 h-3.5"
                        }),
                        n.jsx("span", {
                          className: "text-xs font-medium",
                          children: "Tags:"
                        })
                      ]
                    }),
                    en.map((s) => n.jsx(X, {
                      tag: s,
                      size: "xs",
                      showRemove: true,
                      isDarkMode: t,
                      onClick: () => Xn(s),
                      onRemove: Wn
                    }, s.id)),
                    n.jsxs("div", {
                      className: "relative",
                      ref: E,
                      children: [
                        n.jsxs("button", {
                          onClick: () => g(!u),
                          className: c("inline-flex items-center gap-0.5 px-2 py-0.5 text-xs font-medium rounded-full border border-dashed", u ? t ? "text-blue-400 bg-blue-900/30 border-blue-600" : "text-blue-600 bg-blue-50 border-blue-300" : t ? "text-gray-400 hover:text-gray-200 hover:bg-gray-700 border-gray-600" : "text-gray-500 hover:text-gray-700 hover:bg-gray-100 border-gray-300"),
                          children: [
                            u ? n.jsx(rn, {
                              className: "w-3 h-3"
                            }) : n.jsx(zn, {
                              className: "w-3 h-3"
                            }),
                            n.jsx("span", {
                              children: u ? "Close" : "Add"
                            })
                          ]
                        }),
                        u && n.jsxs("div", {
                          className: c("absolute top-full left-0 mt-1 z-10 border rounded-lg shadow-lg p-2 w-48", t ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"),
                          children: [
                            n.jsx("input", {
                              type: "text",
                              value: N,
                              onChange: (s) => j(s.target.value),
                              onKeyDown: (s) => {
                                s.key === "Enter" && an ? un() : s.key === "Escape" && (g(false), j(""));
                              },
                              placeholder: "Search or create...",
                              className: c("w-full px-2 py-1 text-xs border rounded focus:outline-none focus:ring-1 focus:ring-blue-500 mb-2", t ? "bg-gray-700 border-gray-600 text-gray-200 placeholder-gray-400" : "border-gray-200"),
                              autoFocus: true
                            }),
                            on.length > 0 && n.jsx("div", {
                              className: "max-h-32 overflow-y-auto space-y-0.5 mb-1",
                              children: on.slice(0, 5).map((s) => n.jsx("button", {
                                onClick: () => Kn(s),
                                className: c("w-full px-1.5 py-1 text-left rounded flex items-center", t ? "hover:bg-gray-700" : "hover:bg-gray-50"),
                                children: n.jsx(X, {
                                  tag: s,
                                  size: "xs",
                                  isDarkMode: t
                                })
                              }, s.id))
                            }),
                            an && n.jsxs("button", {
                              onClick: un,
                              className: c("w-full px-1.5 py-1 text-left rounded flex items-center gap-1 text-xs border-t pt-1.5 mt-1", t ? "hover:bg-gray-700 text-gray-300 border-gray-700" : "hover:bg-gray-50 text-gray-600 border-gray-100"),
                              children: [
                                n.jsx(zn, {
                                  className: "w-3 h-3 flex-shrink-0"
                                }),
                                n.jsx("span", {
                                  className: "flex-shrink-0",
                                  children: "Create"
                                }),
                                n.jsx("span", {
                                  onClick: (s) => {
                                    s.stopPropagation(), Qn();
                                  },
                                  className: "cursor-pointer",
                                  title: "Click to change color",
                                  children: n.jsx(X, {
                                    tag: {
                                      name: N.trim(),
                                      color: k
                                    },
                                    size: "xs",
                                    isDarkMode: t
                                  })
                                })
                              ]
                            }),
                            on.length === 0 && !an && N && n.jsx("p", {
                              className: c("text-xs text-center py-1", t ? "text-gray-500" : "text-gray-400"),
                              children: "No matching tags"
                            })
                          ]
                        })
                      ]
                    }),
                    en.length === 0 && !u && n.jsx("span", {
                      className: c("text-xs", t ? "text-gray-500" : "text-gray-400"),
                      children: "No tags yet"
                    })
                  ]
                }),
                xn && n.jsxs("button", {
                  type: "button",
                  onClick: nt,
                  title: "Manage in NLMTools settings",
                  className: c("flex items-center gap-1 ml-auto flex-shrink-0", t ? "text-gray-400 hover:text-gray-200" : "text-gray-400 hover:text-gray-600"),
                  children: [
                    n.jsx("img", {
                      src: fn,
                      alt: "",
                      className: "w-3.5 h-3.5 rounded-sm"
                    }),
                    n.jsx("span", {
                      className: "text-[10px] font-medium",
                      children: "NLMTools.com"
                    }),
                    n.jsx(An, {
                      className: "w-3 h-3 opacity-70"
                    })
                  ]
                })
              ]
            }),
            (l || m) && n.jsxs("div", {
              className: c("flex items-center gap-4 flex-wrap", Jn && `mt-2 pt-2 border-t ${t ? "border-gray-700" : "border-gray-100"}`),
              children: [
                l && n.jsx(Ft, {
                  stats: $n,
                  isLoading: Vn,
                  isDarkMode: t
                }),
                n.jsx("div", {
                  className: "flex-1"
                }),
                m && n.jsx(_t, {
                  notebookId: i,
                  duplicateCount: qn,
                  isDarkMode: t
                })
              ]
            })
          ]
        }),
        b && n.jsx("div", {
          className: "fixed inset-0 z-[99999] flex items-center justify-center bg-black/60 backdrop-blur-sm",
          children: n.jsxs("div", {
            className: c("rounded-xl shadow-2xl p-6 max-w-md w-full mx-4 text-center", t ? "bg-gray-800" : "bg-white"),
            children: [
              n.jsxs("div", {
                className: c("flex items-center justify-center gap-2 mb-4 pb-4 border-b", t ? "border-gray-700" : "border-gray-100"),
                children: [
                  n.jsx("img", {
                    src: fn,
                    alt: vn,
                    className: "w-6 h-6"
                  }),
                  n.jsx("span", {
                    className: c("text-sm font-semibold", t ? "text-gray-200" : "text-gray-700"),
                    children: vn
                  })
                ]
              }),
              n.jsx("div", {
                className: "mb-4",
                children: n.jsxs("svg", {
                  className: c("animate-spin h-12 w-12 mx-auto", t ? "text-blue-400" : "text-blue-600"),
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  children: [
                    n.jsx("circle", {
                      className: "opacity-25",
                      cx: "12",
                      cy: "12",
                      r: "10",
                      stroke: "currentColor",
                      strokeWidth: "4"
                    }),
                    n.jsx("path", {
                      className: "opacity-75",
                      fill: "currentColor",
                      d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    })
                  ]
                })
              }),
              n.jsx("h3", {
                className: c("text-lg font-semibold mb-2", t ? "text-gray-100" : "text-gray-900"),
                children: "Refreshing Sources"
              }),
              n.jsxs("p", {
                className: c("text-sm mb-1", t ? "text-gray-400" : "text-gray-600"),
                children: [
                  "Processing ",
                  w.current,
                  " of ",
                  w.total,
                  "..."
                ]
              }),
              w.currentSource && n.jsxs("p", {
                className: c("text-xs truncate", t ? "text-gray-500" : "text-gray-400"),
                title: w.currentSource,
                children: [
                  '"',
                  w.currentSource,
                  '"'
                ]
              })
            ]
          })
        })
      ]
    });
  }
  function Bt({ notebookId: e }) {
    const [r, t] = W(), o = Q(), { tagsVisibleHome: l } = r.languageSettings;
    a.useEffect(() => {
      r.notebookTags.isLoaded || t.loadTags(), t.loadTagsVisibleHome();
      const y = (u, g) => {
        g === "local" && (u[wn] && t.loadTags(), u[jt] && t.loadTagsVisibleHome());
      };
      return chrome.storage.onChanged.addListener(y), () => chrome.storage.onChanged.removeListener(y);
    }, []);
    const m = e ? t.getNotebookTags(e) : [], v = (y, u) => {
      y.preventDefault(), y.stopPropagation(), y.nativeEvent.stopImmediatePropagation();
      const g = chrome.runtime.getURL(`popup.html#/notebooklm?tag=${u.id}`);
      window.open(g, "_blank");
    }, i = (y) => {
      y.stopPropagation(), y.nativeEvent.stopImmediatePropagation();
    };
    return !l || m.length === 0 ? null : n.jsx("div", {
      className: "font-sans flex items-center gap-1 flex-wrap py-1",
      onClick: i,
      onMouseDown: i,
      children: m.map((y) => n.jsx("span", {
        onClick: (u) => v(u, y),
        onMouseDown: i,
        className: "cursor-pointer",
        children: n.jsx(X, {
          tag: y,
          size: "xs",
          isDarkMode: o
        })
      }, y.id))
    });
  }
  function $t() {
    const [e, r] = W(), t = Q(), [o, l] = a.useState(0), [m, v] = a.useState(""), i = a.useRef(null), { notebookTags: y, languageSettings: u, notebooklm: g } = e, { allTagsBarVisible: N } = u, { projects: j } = g;
    a.useEffect(() => {
      y.isLoaded || r.loadTags(), g.hasInitialized || r.fetchNotebookLMProjects(), r.loadAllTagsBarVisible();
      const b = (d, w) => {
        w === "local" && (d[wn] && r.loadTags(), d[Ct] && r.loadAllTagsBarVisible());
      };
      return chrome.storage.onChanged.addListener(b), () => chrome.storage.onChanged.removeListener(b);
    }, []), a.useEffect(() => {
      const b = new Set(Object.keys(y.notebookTags).filter((w) => {
        var _a;
        return ((_a = y.notebookTags[w]) == null ? void 0 : _a.length) > 0;
      })), d = j.filter((w) => !b.has(w.id)).length;
      l(d);
    }, [
      y.notebookTags,
      j
    ]);
    const k = r.getAllTags(), x = r.getTagUsageCounts(), E = a.useMemo(() => {
      if (!m.trim())
        return k;
      const b = m.toLowerCase();
      return k.filter((d) => d.name.toLowerCase().includes(b));
    }, [
      k,
      m
    ]), z = (b, d) => {
      b.preventDefault(), b.stopPropagation();
      const w = chrome.runtime.getURL(`popup.html#/notebooklm?tag=${d.id}`);
      window.open(w, "_blank");
    }, p = (b) => {
      b.preventDefault(), b.stopPropagation();
      const d = chrome.runtime.getURL("popup.html#/notebooklm?untagged=true");
      window.open(d, "_blank");
    }, S = (b) => {
      var _a;
      b.key === "Escape" && (v(""), (_a = i.current) == null ? void 0 : _a.blur());
    }, I = (b) => {
      b.preventDefault(), b.stopPropagation();
      const d = chrome.runtime.getURL("popup.html#/tags");
      window.open(d, "_blank");
    };
    return !N || k.length === 0 ? null : n.jsxs("div", {
      className: c("font-sans border rounded-lg shadow-sm m-2 px-4 py-2", t ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"),
      children: [
        n.jsxs("div", {
          className: "flex items-center justify-between mb-4",
          children: [
            n.jsxs("div", {
              className: c("flex items-center gap-1", t ? "text-gray-400" : "text-gray-500"),
              children: [
                n.jsx(Mn, {
                  className: "w-3.5 h-3.5"
                }),
                n.jsx("span", {
                  className: "text-xs font-medium",
                  children: "Tags:"
                }),
                n.jsx("span", {
                  className: c("px-1.5 py-0 text-[10px] font-medium rounded-full", t ? "bg-gray-700 text-gray-300" : "bg-gray-100 text-gray-600"),
                  children: k.length
                })
              ]
            }),
            n.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                n.jsxs("div", {
                  className: c("flex items-center gap-1 px-2 py-0.5 rounded border", t ? "border-gray-600 bg-gray-700/50" : "border-gray-200 bg-gray-50", "focus-within:ring-1 focus-within:ring-blue-400/50 focus-within:border-blue-400"),
                  children: [
                    n.jsx(ct, {
                      className: c("w-3 h-3 flex-shrink-0", "text-gray-400")
                    }),
                    n.jsx("input", {
                      ref: i,
                      type: "text",
                      value: m,
                      onChange: (b) => v(b.target.value),
                      onKeyDown: S,
                      placeholder: "Search...",
                      className: c("w-36 py-0 text-[10px] bg-transparent border-none focus:outline-none placeholder:text-gray-400", t ? "text-gray-200" : "text-gray-700")
                    }),
                    m && n.jsx("button", {
                      onClick: () => v(""),
                      className: c("p-0.5 rounded flex-shrink-0", t ? "hover:bg-gray-600" : "hover:bg-gray-200"),
                      children: n.jsx(rn, {
                        className: "w-3 h-3"
                      })
                    })
                  ]
                }),
                n.jsxs("button", {
                  onClick: I,
                  className: c("flex items-center gap-0.5 px-2 py-0.5 text-[10px] font-medium rounded", t ? "text-gray-400 hover:bg-gray-700 hover:text-gray-200" : "text-gray-500 hover:bg-gray-100 hover:text-gray-700"),
                  children: [
                    "View All",
                    n.jsx(lt, {
                      className: "w-3 h-3"
                    })
                  ]
                })
              ]
            })
          ]
        }),
        n.jsxs("div", {
          className: "flex flex-wrap items-center gap-1.5",
          children: [
            o > 0 && !m && n.jsxs("button", {
              onClick: p,
              className: c("inline-flex items-center gap-1 px-1.5 py-0 text-[10px] font-medium rounded-full border", t ? "bg-gray-700 text-gray-300 border-gray-600 hover:bg-gray-600" : "bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200"),
              children: [
                n.jsx(St, {
                  className: "w-3 h-3"
                }),
                n.jsx("span", {
                  children: "Untagged"
                }),
                n.jsxs("span", {
                  className: "opacity-60",
                  children: [
                    "(",
                    o,
                    ")"
                  ]
                })
              ]
            }),
            E.map((b) => n.jsxs("button", {
              onClick: (d) => z(d, b),
              className: "inline-flex items-center gap-0.5 hover:opacity-80",
              children: [
                n.jsx(X, {
                  tag: b,
                  size: "xs",
                  isDarkMode: t
                }),
                n.jsxs("span", {
                  className: c("text-[10px] opacity-60", t ? "text-gray-400" : "text-gray-500"),
                  children: [
                    "(",
                    x[b.id] || 0,
                    ")"
                  ]
                })
              ]
            }, b.id)),
            m && E.length === 0 && n.jsxs("span", {
              className: c("text-xs", t ? "text-gray-500" : "text-gray-400"),
              children: [
                'No tags match "',
                m,
                '"'
              ]
            })
          ]
        })
      ]
    });
  }
  let In = Promise.resolve();
  function Vt(e) {
    In = In.then(() => new Promise((r) => {
      chrome.storage.local.get([
        cn
      ], (t) => {
        var _a;
        if (chrome.runtime.lastError) {
          r();
          return;
        }
        const o = (t == null ? void 0 : t[cn]) || {};
        o[e] = {
          count: (((_a = o[e]) == null ? void 0 : _a.count) || 0) + 1,
          lastUsedAt: Date.now()
        }, chrome.storage.local.set({
          [cn]: o
        }, () => {
          r();
        });
      });
    })).catch(() => {
    });
  }
  function qt({ enabledPrompts: e }) {
    const [r, t] = a.useState(false), [o, l] = a.useState(""), [m, v] = a.useState(null), i = a.useRef(null), y = a.useRef(-1), u = a.useRef(null), g = a.useCallback(() => {
      t(false), l(""), v(null), y.current = -1;
    }, []), N = a.useCallback((k) => {
      const x = k.getBoundingClientRect(), E = x.top, z = window.innerHeight - x.bottom, p = Math.min(x.width, 400);
      let S = Math.max(8, x.left);
      S + p > window.innerWidth - 8 && (S = window.innerWidth - p - 8);
      const I = Math.max(60, Math.min(300, Math.max(E, z) - 16)), b = {
        left: S,
        width: p,
        maxHeight: I
      };
      return E >= z && E > 120 ? b.bottom = window.innerHeight - x.top + 4 : b.top = x.bottom + 4, b;
    }, []), j = a.useCallback((k) => {
      if (!(k == null ? void 0 : k.text)) {
        g();
        return;
      }
      const x = i.current, E = y.current;
      if (!x || !x.isConnected || E < 0) {
        g();
        return;
      }
      try {
        const z = x.value, p = x.selectionStart, S = z.substring(0, E), I = z.substring(p), b = S + k.text + I;
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(x, b), x.dispatchEvent(new Event("input", {
          bubbles: true
        })), x.dispatchEvent(new Event("change", {
          bubbles: true
        }));
        const w = E + k.text.length;
        x.setSelectionRange(w, w), x.focus(), Vt(k.id);
      } catch (z) {
        console.warn("Prompt insertion failed:", z);
      }
      g();
    }, [
      g
    ]);
    return a.useEffect(() => {
      const k = (p) => {
        var _a;
        const S = p.target;
        if (!((_a = S == null ? void 0 : S.matches) == null ? void 0 : _a.call(S, bn)))
          return;
        u.current && (clearTimeout(u.current), u.current = null);
        const I = S.value, b = S.selectionStart;
        if (b == null)
          return;
        const d = I.substring(0, b), w = d.lastIndexOf("/");
        if (w === -1) {
          g();
          return;
        }
        if (w > 0) {
          const R = d[w - 1];
          if (R !== " " && R !== `
` && R !== "	") {
            g();
            return;
          }
        }
        const T = d.substring(w + 1);
        if (T.length > 50 || T.includes(" ")) {
          g();
          return;
        }
        i.current = S, y.current = w, l(T), v(N(S)), t(true);
      }, x = (p) => {
        var _a, _b;
        if (r && ((_b = (_a = p.target) == null ? void 0 : _a.matches) == null ? void 0 : _b.call(_a, bn)))
          switch (p.key) {
            case "Escape":
              p.preventDefault(), p.stopPropagation(), g();
              break;
            case "ArrowDown":
            case "ArrowUp":
              p.preventDefault();
              break;
          }
      }, E = () => {
        r && g();
      }, z = (p) => {
        p.target === i.current && (u.current = setTimeout(() => {
          r && g();
        }, 150));
      };
      return document.addEventListener("input", k, true), document.addEventListener("keydown", x, true), window.addEventListener("resize", E), document.addEventListener("focusout", z, true), () => {
        document.removeEventListener("input", k, true), document.removeEventListener("keydown", x, true), window.removeEventListener("resize", E), document.removeEventListener("focusout", z, true), u.current && clearTimeout(u.current);
      };
    }, [
      r,
      g,
      N
    ]), {
      isOpen: r,
      filterText: o,
      position: m,
      closeDropdown: g,
      handleSelect: j,
      activeTextareaRef: i,
      slashIndexRef: y
    };
  }
  function Ht({ grouped: e, filtered: r, isLoaded: t, isDarkMode: o, highlightedIndex: l, highlightedRef: m, setHighlightedIndex: v, handleSelect: i }) {
    let y = 0;
    return r.length === 0 ? n.jsxs("div", {
      className: `px-3 py-4 text-center ${o ? "text-slate-400" : "text-gray-500"}`,
      children: [
        n.jsx("p", {
          className: "text-xs font-medium",
          children: t ? "No matching prompts" : "Loading prompts..."
        }),
        t && n.jsx("p", {
          className: `text-[10px] mt-0.5 ${o ? "text-slate-500" : "text-gray-400"}`,
          children: "Try a different shortcode"
        })
      ]
    }) : e.map((u) => n.jsxs("div", {
      children: [
        n.jsx("div", {
          className: `px-3 py-1 text-[10px] font-semibold uppercase tracking-wider border-b ${u.category === "Pinned" ? o ? "bg-slate-800 text-amber-400 border-slate-700" : "bg-amber-50 text-amber-600 border-gray-100" : o ? "bg-slate-800 text-slate-400 border-slate-700" : "bg-gray-50 text-gray-500 border-gray-100"}`,
          children: u.category
        }),
        u.items.map((g) => {
          const N = y++, j = N === l, k = g.text && g.text.length > 80 ? g.text.slice(0, 80) + "\u2026" : g.text || "";
          return n.jsxs("button", {
            ref: j ? m : null,
            onMouseDown: (x) => {
              x.preventDefault(), i(g);
            },
            onMouseEnter: () => v(N),
            role: "option",
            "aria-selected": j,
            "aria-label": g.shortcode ? `${g.shortcode} \u2014 ${g.title}` : g.title,
            className: `w-full flex flex-col gap-0.5 px-3 py-1.5 text-left border-l-2 ${j ? o ? "bg-slate-700 border-l-blue-400" : "bg-blue-50 border-l-blue-500" : "border-l-transparent"}`,
            children: [
              n.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  n.jsx("span", {
                    className: `text-xs font-mono w-16 shrink-0 ${o ? "text-blue-400" : "text-blue-600"}`,
                    children: g.shortcode || ""
                  }),
                  n.jsx("span", {
                    className: "text-xs font-medium truncate",
                    children: g.title
                  })
                ]
              }),
              k && n.jsx("span", {
                className: `text-[10px] truncate pl-[72px] ${o ? "text-slate-500" : "text-gray-400"}`,
                children: k
              })
            ]
          }, g.id);
        })
      ]
    }, u.category));
  }
  function Yt(e, r) {
    if (!r)
      return e;
    const t = r.toLowerCase(), o = "/" + t, l = e.filter((i) => i.shortcode === o), m = e.filter((i) => {
      var _a;
      return ((_a = i.shortcode) == null ? void 0 : _a.startsWith(o)) && i.shortcode !== o;
    }), v = e.filter((i) => {
      var _a;
      return !((_a = i.shortcode) == null ? void 0 : _a.startsWith(o)) && (i.title.toLowerCase().includes(t) || i.text.toLowerCase().includes(t));
    });
    return [
      ...l,
      ...m,
      ...v
    ];
  }
  function Gt({ hostElement: e }) {
    const r = Q(), [t, o] = a.useState([]), [l, m] = a.useState(false), [v, i] = a.useState(0), y = a.useRef(null), u = a.useCallback(async () => {
      try {
        const d = await new Promise((w) => {
          chrome.storage.local.get([
            ln
          ], (T) => {
            if (chrome.runtime.lastError) {
              w(void 0);
              return;
            }
            w(T[ln]);
          });
        });
        Array.isArray(d) ? o(d) : d && !Array.isArray(d) && Array.isArray(d.customPrompts) ? o(d.customPrompts) : o([]);
      } catch {
        o([]);
      } finally {
        m(true);
      }
    }, []);
    a.useEffect(() => {
      u();
      const d = (w) => {
        w[ln] && u();
      };
      return chrome.storage.onChanged.addListener(d), () => chrome.storage.onChanged.removeListener(d);
    }, [
      u
    ]);
    const { isOpen: g, filterText: N, position: j, closeDropdown: k, handleSelect: x, activeTextareaRef: E, slashIndexRef: z } = qt({
      enabledPrompts: t
    }), p = a.useMemo(() => Yt(t, N), [
      t,
      N
    ]), S = a.useMemo(() => {
      const d = p.filter((R) => R.pinned), w = p.filter((R) => !R.pinned), T = [];
      return d.length > 0 && T.push({
        category: "Pinned",
        items: d
      }), T.push(...zt(w)), T;
    }, [
      p
    ]);
    a.useEffect(() => {
      i(0);
    }, [
      N
    ]), a.useEffect(() => {
      y.current && y.current.scrollIntoView({
        block: "nearest"
      });
    }, [
      v
    ]), a.useEffect(() => {
      if (!g)
        return;
      const d = (w) => {
        var _a, _b;
        if ((_b = (_a = w.target) == null ? void 0 : _a.matches) == null ? void 0 : _b.call(_a, bn))
          switch (w.key) {
            case "ArrowDown":
              w.preventDefault(), i((T) => (T + 1) % Math.max(1, p.length));
              break;
            case "ArrowUp":
              w.preventDefault(), i((T) => T <= 0 ? Math.max(0, p.length - 1) : T - 1);
              break;
            case "Enter":
            case "Tab":
              w.preventDefault(), w.stopPropagation(), w.stopImmediatePropagation(), p[v] && x(p[v]);
              break;
          }
      };
      return document.addEventListener("keydown", d, true), () => document.removeEventListener("keydown", d, true);
    }, [
      g,
      p,
      v,
      x
    ]);
    const I = g && l && (p.length > 0 || t.length > 0);
    if (a.useEffect(() => {
      if (e == null ? void 0 : e.isConnected)
        try {
          I ? e.showPopover() : e.hidePopover();
        } catch {
        }
    }, [
      I,
      e
    ]), !g || !j || p.length === 0 && t.length === 0 && l)
      return null;
    const b = {
      position: "fixed",
      left: j.left,
      width: j.width,
      maxHeight: j.maxHeight,
      ...j.bottom != null ? {
        bottom: j.bottom
      } : {
        top: j.top
      }
    };
    return n.jsxs("div", {
      style: b,
      className: `rounded-lg border shadow-lg overflow-hidden flex flex-col ${r ? "bg-slate-800 border-slate-600 text-slate-100" : "bg-white border-gray-200 text-gray-900"}`,
      children: [
        n.jsxs("div", {
          className: `px-3 py-1.5 border-b text-xs font-mono ${r ? "bg-slate-900 border-slate-700 text-slate-400" : "bg-gray-50 border-gray-100 text-gray-400"}`,
          children: [
            "/",
            N
          ]
        }),
        n.jsx("div", {
          className: "overflow-y-auto",
          role: "listbox",
          "aria-label": "Prompt suggestions",
          style: {
            maxHeight: j.maxHeight - 56
          },
          children: n.jsx(Ht, {
            grouped: S,
            filtered: p,
            isLoaded: l,
            isDarkMode: r,
            highlightedIndex: v,
            highlightedRef: y,
            setHighlightedIndex: i,
            handleSelect: x
          })
        }),
        n.jsxs("div", {
          className: `px-3 py-1 border-t text-xs flex gap-3 ${r ? "bg-slate-900 border-slate-700 text-slate-500" : "bg-gray-50 border-gray-100 text-gray-400"}`,
          children: [
            n.jsxs("span", {
              children: [
                n.jsx("kbd", {
                  className: "font-mono",
                  children: "\u2191\u2193"
                }),
                " navigate"
              ]
            }),
            n.jsxs("span", {
              children: [
                n.jsx("kbd", {
                  className: "font-mono",
                  children: "\u21B5"
                }),
                " select"
              ]
            }),
            n.jsxs("span", {
              children: [
                n.jsx("kbd", {
                  className: "font-mono",
                  children: "esc"
                }),
                " close"
              ]
            })
          ]
        })
      ]
    });
  }
  const Z = `*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

/*
! tailwindcss v3.4.18 | MIT License | https://tailwindcss.com
*/

/*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box;
  /* 1 */
  border-width: 0;
  /* 2 */
  border-style: solid;
  /* 2 */
  border-color: #e5e7eb;
  /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5;
  /* 1 */
  -webkit-text-size-adjust: 100%;
  /* 2 */
  -moz-tab-size: 4;
  /* 3 */
  -o-tab-size: 4;
     tab-size: 4;
  /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  /* 4 */
  font-feature-settings: normal;
  /* 5 */
  font-variation-settings: normal;
  /* 6 */
  -webkit-tap-highlight-color: transparent;
  /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0;
  /* 1 */
  line-height: inherit;
  /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0;
  /* 1 */
  color: inherit;
  /* 2 */
  border-top-width: 1px;
  /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  /* 1 */
  font-feature-settings: normal;
  /* 2 */
  font-variation-settings: normal;
  /* 3 */
  font-size: 1em;
  /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0;
  /* 1 */
  border-color: inherit;
  /* 2 */
  border-collapse: collapse;
  /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit;
  /* 1 */
  font-feature-settings: inherit;
  /* 1 */
  font-variation-settings: inherit;
  /* 1 */
  font-size: 100%;
  /* 1 */
  font-weight: inherit;
  /* 1 */
  line-height: inherit;
  /* 1 */
  letter-spacing: inherit;
  /* 1 */
  color: inherit;
  /* 1 */
  margin: 0;
  /* 2 */
  padding: 0;
  /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button;
  /* 1 */
  background-color: transparent;
  /* 2 */
  background-image: none;
  /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield;
  /* 1 */
  outline-offset: -2px;
  /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button;
  /* 1 */
  font: inherit;
  /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/

dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1;
  /* 1 */
  color: #9ca3af;
  /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1;
  /* 1 */
  color: #9ca3af;
  /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/

:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block;
  /* 1 */
  vertical-align: middle;
  /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */

[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}

[type='text'],input:where(:not([type])),[type='email'],[type='url'],[type='password'],[type='number'],[type='date'],[type='datetime-local'],[type='month'],[type='search'],[type='tel'],[type='time'],[type='week'],[multiple],textarea,select {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  border-radius: 0px;
  padding-top: 0.5rem;
  padding-right: 0.75rem;
  padding-bottom: 0.5rem;
  padding-left: 0.75rem;
  font-size: 1rem;
  line-height: 1.5rem;
  --tw-shadow: 0 0 #0000;
}

[type='text']:focus, input:where(:not([type])):focus, [type='email']:focus, [type='url']:focus, [type='password']:focus, [type='number']:focus, [type='date']:focus, [type='datetime-local']:focus, [type='month']:focus, [type='search']:focus, [type='tel']:focus, [type='time']:focus, [type='week']:focus, [multiple]:focus, textarea:focus, select:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  border-color: #2563eb;
}

input::-moz-placeholder, textarea::-moz-placeholder {
  color: #6b7280;
  opacity: 1;
}

input::placeholder,textarea::placeholder {
  color: #6b7280;
  opacity: 1;
}

::-webkit-datetime-edit-fields-wrapper {
  padding: 0;
}

::-webkit-date-and-time-value {
  min-height: 1.5em;
  text-align: inherit;
}

::-webkit-datetime-edit {
  display: inline-flex;
}

::-webkit-datetime-edit,::-webkit-datetime-edit-year-field,::-webkit-datetime-edit-month-field,::-webkit-datetime-edit-day-field,::-webkit-datetime-edit-hour-field,::-webkit-datetime-edit-minute-field,::-webkit-datetime-edit-second-field,::-webkit-datetime-edit-millisecond-field,::-webkit-datetime-edit-meridiem-field {
  padding-top: 0;
  padding-bottom: 0;
}

select {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
  background-position: right 0.5rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
}

[multiple],[size]:where(select:not([size="1"])) {
  background-image: initial;
  background-position: initial;
  background-repeat: unset;
  background-size: initial;
  padding-right: 0.75rem;
  -webkit-print-color-adjust: unset;
          print-color-adjust: unset;
}

[type='checkbox'],[type='radio'] {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  padding: 0;
  -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
  display: inline-block;
  vertical-align: middle;
  background-origin: border-box;
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
  flex-shrink: 0;
  height: 1rem;
  width: 1rem;
  color: #2563eb;
  background-color: #fff;
  border-color: #6b7280;
  border-width: 1px;
  --tw-shadow: 0 0 #0000;
}

[type='checkbox'] {
  border-radius: 0px;
}

[type='radio'] {
  border-radius: 100%;
}

[type='checkbox']:focus,[type='radio']:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
  --tw-ring-inset: var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width: 2px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: #2563eb;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
}

[type='checkbox']:checked,[type='radio']:checked {
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

[type='checkbox']:checked {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e");
}

@media (forced-colors: active)  {
  [type='checkbox']:checked {
    -webkit-appearance: auto;
       -moz-appearance: auto;
            appearance: auto;
  }
}

[type='radio']:checked {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
}

@media (forced-colors: active)  {
  [type='radio']:checked {
    -webkit-appearance: auto;
       -moz-appearance: auto;
            appearance: auto;
  }
}

[type='checkbox']:checked:hover,[type='checkbox']:checked:focus,[type='radio']:checked:hover,[type='radio']:checked:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='checkbox']:indeterminate {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3e%3cpath stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3e%3c/svg%3e");
  border-color: transparent;
  background-color: currentColor;
  background-size: 100% 100%;
  background-position: center;
  background-repeat: no-repeat;
}

@media (forced-colors: active)  {
  [type='checkbox']:indeterminate {
    -webkit-appearance: auto;
       -moz-appearance: auto;
            appearance: auto;
  }
}

[type='checkbox']:indeterminate:hover,[type='checkbox']:indeterminate:focus {
  border-color: transparent;
  background-color: currentColor;
}

[type='file'] {
  background: unset;
  border-color: inherit;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-size: unset;
  line-height: inherit;
}

[type='file']:focus {
  outline: 1px solid ButtonText;
  outline: 1px auto -webkit-focus-ring-color;
}

.dark {
  color-scheme: dark;
}

.dark input:not([type='checkbox']):not([type='radio']),
  .dark select,
  .dark textarea {
  background-color: #1e293b;
  border-color: #334155;
  color: #e2e8f0;
}

.container {
  width: 100%;
}

@media (min-width: 640px) {
  .container {
    max-width: 640px;
  }
}

@media (min-width: 768px) {
  .container {
    max-width: 768px;
  }
}

@media (min-width: 1024px) {
  .container {
    max-width: 1024px;
  }
}

@media (min-width: 1280px) {
  .container {
    max-width: 1280px;
  }
}

@media (min-width: 1536px) {
  .container {
    max-width: 1536px;
  }
}

.prose {
  color: var(--tw-prose-body);
  max-width: 65ch;
}

.prose :where(p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}

.prose :where([class~="lead"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-lead);
  font-size: 1.25em;
  line-height: 1.6;
  margin-top: 1.2em;
  margin-bottom: 1.2em;
}

.prose :where(a):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-links);
  text-decoration: underline;
  font-weight: 500;
}

.prose :where(strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-bold);
  font-weight: 600;
}

.prose :where(a strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(blockquote strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(thead th strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: decimal;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}

.prose :where(ol[type="A"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-alpha;
}

.prose :where(ol[type="a"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-alpha;
}

.prose :where(ol[type="A" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-alpha;
}

.prose :where(ol[type="a" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-alpha;
}

.prose :where(ol[type="I"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-roman;
}

.prose :where(ol[type="i"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-roman;
}

.prose :where(ol[type="I" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-roman;
}

.prose :where(ol[type="i" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-roman;
}

.prose :where(ol[type="1"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: decimal;
}

.prose :where(ul):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: disc;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}

.prose :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
  font-weight: 400;
  color: var(--tw-prose-counters);
}

.prose :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
  color: var(--tw-prose-bullets);
}

.prose :where(dt):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.25em;
}

.prose :where(hr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-color: var(--tw-prose-hr);
  border-top-width: 1px;
  margin-top: 3em;
  margin-bottom: 3em;
}

.prose :where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 500;
  font-style: italic;
  color: var(--tw-prose-quotes);
  border-inline-start-width: 0.25rem;
  border-inline-start-color: var(--tw-prose-quote-borders);
  quotes: "\\201C""\\201D""\\2018""\\2019";
  margin-top: 1.6em;
  margin-bottom: 1.6em;
  padding-inline-start: 1em;
}

.prose :where(blockquote p:first-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: open-quote;
}

.prose :where(blockquote p:last-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: close-quote;
}

.prose :where(h1):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 800;
  font-size: 2.25em;
  margin-top: 0;
  margin-bottom: 0.8888889em;
  line-height: 1.1111111;
}

.prose :where(h1 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 900;
  color: inherit;
}

.prose :where(h2):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 700;
  font-size: 1.5em;
  margin-top: 2em;
  margin-bottom: 1em;
  line-height: 1.3333333;
}

.prose :where(h2 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 800;
  color: inherit;
}

.prose :where(h3):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  font-size: 1.25em;
  margin-top: 1.6em;
  margin-bottom: 0.6em;
  line-height: 1.6;
}

.prose :where(h3 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 700;
  color: inherit;
}

.prose :where(h4):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
  line-height: 1.5;
}

.prose :where(h4 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 700;
  color: inherit;
}

.prose :where(img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}

.prose :where(picture):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  display: block;
  margin-top: 2em;
  margin-bottom: 2em;
}

.prose :where(video):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}

.prose :where(kbd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 500;
  font-family: inherit;
  color: var(--tw-prose-kbd);
  box-shadow: 0 0 0 1px var(--tw-prose-kbd-shadows), 0 3px 0 var(--tw-prose-kbd-shadows);
  font-size: 0.875em;
  border-radius: 0.3125rem;
  padding-top: 0.1875em;
  padding-inline-end: 0.375em;
  padding-bottom: 0.1875em;
  padding-inline-start: 0.375em;
}

.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-code);
  font-weight: 600;
  font-size: 0.875em;
}

.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: "\`";
}

.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: "\`";
}

.prose :where(a code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(h1 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(h2 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
  font-size: 0.875em;
}

.prose :where(h3 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
  font-size: 0.9em;
}

.prose :where(h4 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(blockquote code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(thead th code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}

.prose :where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-pre-code);
  background-color: var(--tw-prose-pre-bg);
  overflow-x: auto;
  font-weight: 400;
  font-size: 0.875em;
  line-height: 1.7142857;
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
  border-radius: 0.375rem;
  padding-top: 0.8571429em;
  padding-inline-end: 1.1428571em;
  padding-bottom: 0.8571429em;
  padding-inline-start: 1.1428571em;
}

.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  background-color: transparent;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-weight: inherit;
  color: inherit;
  font-size: inherit;
  font-family: inherit;
  line-height: inherit;
}

.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: none;
}

.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: none;
}

.prose :where(table):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  width: 100%;
  table-layout: auto;
  margin-top: 2em;
  margin-bottom: 2em;
  font-size: 0.875em;
  line-height: 1.7142857;
}

.prose :where(thead):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-th-borders);
}

.prose :where(thead th):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  vertical-align: bottom;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}

.prose :where(tbody tr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-td-borders);
}

.prose :where(tbody tr:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 0;
}

.prose :where(tbody td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  vertical-align: baseline;
}

.prose :where(tfoot):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-top-width: 1px;
  border-top-color: var(--tw-prose-th-borders);
}

.prose :where(tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  vertical-align: top;
}

.prose :where(th, td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  text-align: start;
}

.prose :where(figure > *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}

.prose :where(figcaption):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-captions);
  font-size: 0.875em;
  line-height: 1.4285714;
  margin-top: 0.8571429em;
}

.prose {
  --tw-prose-body: #374151;
  --tw-prose-headings: #111827;
  --tw-prose-lead: #4b5563;
  --tw-prose-links: #111827;
  --tw-prose-bold: #111827;
  --tw-prose-counters: #6b7280;
  --tw-prose-bullets: #d1d5db;
  --tw-prose-hr: #e5e7eb;
  --tw-prose-quotes: #111827;
  --tw-prose-quote-borders: #e5e7eb;
  --tw-prose-captions: #6b7280;
  --tw-prose-kbd: #111827;
  --tw-prose-kbd-shadows: rgb(17 24 39 / 10%);
  --tw-prose-code: #111827;
  --tw-prose-pre-code: #e5e7eb;
  --tw-prose-pre-bg: #1f2937;
  --tw-prose-th-borders: #d1d5db;
  --tw-prose-td-borders: #e5e7eb;
  --tw-prose-invert-body: #d1d5db;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #9ca3af;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #9ca3af;
  --tw-prose-invert-bullets: #4b5563;
  --tw-prose-invert-hr: #374151;
  --tw-prose-invert-quotes: #f3f4f6;
  --tw-prose-invert-quote-borders: #374151;
  --tw-prose-invert-captions: #9ca3af;
  --tw-prose-invert-kbd: #fff;
  --tw-prose-invert-kbd-shadows: rgb(255 255 255 / 10%);
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d1d5db;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #4b5563;
  --tw-prose-invert-td-borders: #374151;
  font-size: 1rem;
  line-height: 1.75;
}

.prose :where(picture > img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}

.prose :where(li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5em;
  margin-bottom: 0.5em;
}

.prose :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.375em;
}

.prose :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.375em;
}

.prose :where(.prose > ul > li p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}

.prose :where(.prose > ul > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
}

.prose :where(.prose > ul > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.25em;
}

.prose :where(.prose > ol > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
}

.prose :where(.prose > ol > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.25em;
}

.prose :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}

.prose :where(dl):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}

.prose :where(dd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5em;
  padding-inline-start: 1.625em;
}

.prose :where(hr + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose :where(h2 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose :where(h3 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose :where(h4 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose :where(thead th:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}

.prose :where(thead th:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}

.prose :where(tbody td, tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-top: 0.5714286em;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}

.prose :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}

.prose :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}

.prose :where(figure):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}

.prose :where(.prose > :first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose :where(.prose > :last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 0;
}

.prose-sm {
  font-size: 0.875rem;
  line-height: 1.7142857;
}

.prose-sm :where(p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
  margin-bottom: 1.1428571em;
}

.prose-sm :where([class~="lead"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 1.2857143em;
  line-height: 1.5555556;
  margin-top: 0.8888889em;
  margin-bottom: 0.8888889em;
}

.prose-sm :where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.3333333em;
  margin-bottom: 1.3333333em;
  padding-inline-start: 1.1111111em;
}

.prose-sm :where(h1):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 2.1428571em;
  margin-top: 0;
  margin-bottom: 0.8em;
  line-height: 1.2;
}

.prose-sm :where(h2):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 1.4285714em;
  margin-top: 1.6em;
  margin-bottom: 0.8em;
  line-height: 1.4;
}

.prose-sm :where(h3):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 1.2857143em;
  margin-top: 1.5555556em;
  margin-bottom: 0.4444444em;
  line-height: 1.5555556;
}

.prose-sm :where(h4):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.4285714em;
  margin-bottom: 0.5714286em;
  line-height: 1.4285714;
}

.prose-sm :where(img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
}

.prose-sm :where(picture):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
}

.prose-sm :where(picture > img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}

.prose-sm :where(video):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
}

.prose-sm :where(kbd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.8571429em;
  border-radius: 0.3125rem;
  padding-top: 0.1428571em;
  padding-inline-end: 0.3571429em;
  padding-bottom: 0.1428571em;
  padding-inline-start: 0.3571429em;
}

.prose-sm :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.8571429em;
}

.prose-sm :where(h2 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.9em;
}

.prose-sm :where(h3 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.8888889em;
}

.prose-sm :where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.8571429em;
  line-height: 1.6666667;
  margin-top: 1.6666667em;
  margin-bottom: 1.6666667em;
  border-radius: 0.25rem;
  padding-top: 0.6666667em;
  padding-inline-end: 1em;
  padding-bottom: 0.6666667em;
  padding-inline-start: 1em;
}

.prose-sm :where(ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
  margin-bottom: 1.1428571em;
  padding-inline-start: 1.5714286em;
}

.prose-sm :where(ul):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
  margin-bottom: 1.1428571em;
  padding-inline-start: 1.5714286em;
}

.prose-sm :where(li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.2857143em;
  margin-bottom: 0.2857143em;
}

.prose-sm :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.4285714em;
}

.prose-sm :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.4285714em;
}

.prose-sm :where(.prose-sm > ul > li p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5714286em;
  margin-bottom: 0.5714286em;
}

.prose-sm :where(.prose-sm > ul > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
}

.prose-sm :where(.prose-sm > ul > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.1428571em;
}

.prose-sm :where(.prose-sm > ol > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
}

.prose-sm :where(.prose-sm > ol > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.1428571em;
}

.prose-sm :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5714286em;
  margin-bottom: 0.5714286em;
}

.prose-sm :where(dl):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
  margin-bottom: 1.1428571em;
}

.prose-sm :where(dt):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.1428571em;
}

.prose-sm :where(dd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.2857143em;
  padding-inline-start: 1.5714286em;
}

.prose-sm :where(hr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2.8571429em;
  margin-bottom: 2.8571429em;
}

.prose-sm :where(hr + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose-sm :where(h2 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose-sm :where(h3 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose-sm :where(h4 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose-sm :where(table):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.8571429em;
  line-height: 1.5;
}

.prose-sm :where(thead th):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 1em;
  padding-bottom: 0.6666667em;
  padding-inline-start: 1em;
}

.prose-sm :where(thead th:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}

.prose-sm :where(thead th:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}

.prose-sm :where(tbody td, tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-top: 0.6666667em;
  padding-inline-end: 1em;
  padding-bottom: 0.6666667em;
  padding-inline-start: 1em;
}

.prose-sm :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}

.prose-sm :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}

.prose-sm :where(figure):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
}

.prose-sm :where(figure > *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}

.prose-sm :where(figcaption):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-size: 0.8571429em;
  line-height: 1.3333333;
  margin-top: 0.6666667em;
}

.prose-sm :where(.prose-sm > :first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}

.prose-sm :where(.prose-sm > :last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 0;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.pointer-events-none {
  pointer-events: none;
}

.visible {
  visibility: visible;
}

.collapse {
  visibility: collapse;
}

.static {
  position: static;
}

.fixed {
  position: fixed;
}

.absolute {
  position: absolute;
}

.relative {
  position: relative;
}

.sticky {
  position: sticky;
}

.inset-0 {
  inset: 0px;
}

.inset-y-0 {
  top: 0px;
  bottom: 0px;
}

.-bottom-0\\.5 {
  bottom: -0.125rem;
}

.-right-0\\.5 {
  right: -0.125rem;
}

.bottom-0 {
  bottom: 0px;
}

.bottom-1\\.5 {
  bottom: 0.375rem;
}

.bottom-2 {
  bottom: 0.5rem;
}

.bottom-full {
  bottom: 100%;
}

.left-0 {
  left: 0px;
}

.left-1\\.5 {
  left: 0.375rem;
}

.left-1\\/2 {
  left: 50%;
}

.left-2 {
  left: 0.5rem;
}

.left-2\\.5 {
  left: 0.625rem;
}

.left-3 {
  left: 0.75rem;
}

.right-0 {
  right: 0px;
}

.right-0\\.5 {
  right: 0.125rem;
}

.right-1 {
  right: 0.25rem;
}

.right-1\\.5 {
  right: 0.375rem;
}

.right-2 {
  right: 0.5rem;
}

.right-3 {
  right: 0.75rem;
}

.top-0 {
  top: 0px;
}

.top-0\\.5 {
  top: 0.125rem;
}

.top-1 {
  top: 0.25rem;
}

.top-1\\.5 {
  top: 0.375rem;
}

.top-1\\/2 {
  top: 50%;
}

.top-2 {
  top: 0.5rem;
}

.top-3 {
  top: 0.75rem;
}

.top-full {
  top: 100%;
}

.z-10 {
  z-index: 10;
}

.z-20 {
  z-index: 20;
}

.z-50 {
  z-index: 50;
}

.z-\\[99999\\] {
  z-index: 99999;
}

.z-\\[9999\\] {
  z-index: 9999;
}

.-m-1 {
  margin: -0.25rem;
}

.m-2 {
  margin: 0.5rem;
}

.-mx-1\\.5 {
  margin-left: -0.375rem;
  margin-right: -0.375rem;
}

.mx-1 {
  margin-left: 0.25rem;
  margin-right: 0.25rem;
}

.mx-2 {
  margin-left: 0.5rem;
  margin-right: 0.5rem;
}

.mx-4 {
  margin-left: 1rem;
  margin-right: 1rem;
}

.mx-auto {
  margin-left: auto;
  margin-right: auto;
}

.my-2 {
  margin-top: 0.5rem;
  margin-bottom: 0.5rem;
}

.-mb-px {
  margin-bottom: -1px;
}

.-mt-0\\.5 {
  margin-top: -0.125rem;
}

.-mt-1\\.5 {
  margin-top: -0.375rem;
}

.mb-0\\.5 {
  margin-bottom: 0.125rem;
}

.mb-1 {
  margin-bottom: 0.25rem;
}

.mb-1\\.5 {
  margin-bottom: 0.375rem;
}

.mb-2 {
  margin-bottom: 0.5rem;
}

.mb-3 {
  margin-bottom: 0.75rem;
}

.mb-4 {
  margin-bottom: 1rem;
}

.ml-0\\.5 {
  margin-left: 0.125rem;
}

.ml-1 {
  margin-left: 0.25rem;
}

.ml-1\\.5 {
  margin-left: 0.375rem;
}

.ml-2 {
  margin-left: 0.5rem;
}

.ml-3 {
  margin-left: 0.75rem;
}

.ml-6 {
  margin-left: 1.5rem;
}

.ml-\\[22px\\] {
  margin-left: 22px;
}

.ml-auto {
  margin-left: auto;
}

.mr-0\\.5 {
  margin-right: 0.125rem;
}

.mr-1\\.5 {
  margin-right: 0.375rem;
}

.mt-0\\.5 {
  margin-top: 0.125rem;
}

.mt-1 {
  margin-top: 0.25rem;
}

.mt-1\\.5 {
  margin-top: 0.375rem;
}

.mt-2 {
  margin-top: 0.5rem;
}

.mt-3 {
  margin-top: 0.75rem;
}

.mt-4 {
  margin-top: 1rem;
}

.mt-5 {
  margin-top: 1.25rem;
}

.mt-px {
  margin-top: 1px;
}

.line-clamp-1 {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}

.line-clamp-2 {
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.block {
  display: block;
}

.inline-block {
  display: inline-block;
}

.inline {
  display: inline;
}

.flex {
  display: flex;
}

.inline-flex {
  display: inline-flex;
}

.\\!table {
  display: table !important;
}

.table {
  display: table;
}

.grid {
  display: grid;
}

.contents {
  display: contents;
}

.hidden {
  display: none;
}

.aspect-video {
  aspect-ratio: 16 / 9;
}

.h-0\\.5 {
  height: 0.125rem;
}

.h-1 {
  height: 0.25rem;
}

.h-1\\.5 {
  height: 0.375rem;
}

.h-10 {
  height: 2.5rem;
}

.h-12 {
  height: 3rem;
}

.h-2 {
  height: 0.5rem;
}

.h-2\\.5 {
  height: 0.625rem;
}

.h-24 {
  height: 6rem;
}

.h-3 {
  height: 0.75rem;
}

.h-3\\.5 {
  height: 0.875rem;
}

.h-4 {
  height: 1rem;
}

.h-48 {
  height: 12rem;
}

.h-5 {
  height: 1.25rem;
}

.h-6 {
  height: 1.5rem;
}

.h-64 {
  height: 16rem;
}

.h-7 {
  height: 1.75rem;
}

.h-8 {
  height: 2rem;
}

.h-\\[400px\\] {
  height: 400px;
}

.h-\\[calc\\(100vh-40px\\)\\] {
  height: calc(100vh - 40px);
}

.h-full {
  height: 100%;
}

.h-px {
  height: 1px;
}

.h-screen {
  height: 100vh;
}

.max-h-24 {
  max-height: 6rem;
}

.max-h-32 {
  max-height: 8rem;
}

.max-h-40 {
  max-height: 10rem;
}

.max-h-48 {
  max-height: 12rem;
}

.max-h-56 {
  max-height: 14rem;
}

.max-h-64 {
  max-height: 16rem;
}

.max-h-80 {
  max-height: 20rem;
}

.max-h-\\[60vh\\] {
  max-height: 60vh;
}

.max-h-\\[90vh\\] {
  max-height: 90vh;
}

.max-h-\\[95vh\\] {
  max-height: 95vh;
}

.max-h-\\[calc\\(100vh-16rem\\)\\] {
  max-height: calc(100vh - 16rem);
}

.max-h-full {
  max-height: 100%;
}

.min-h-\\[200px\\] {
  min-height: 200px;
}

.min-h-\\[28px\\] {
  min-height: 28px;
}

.min-h-\\[60vh\\] {
  min-height: 60vh;
}

.w-1 {
  width: 0.25rem;
}

.w-1\\.5 {
  width: 0.375rem;
}

.w-10 {
  width: 2.5rem;
}

.w-12 {
  width: 3rem;
}

.w-14 {
  width: 3.5rem;
}

.w-16 {
  width: 4rem;
}

.w-2 {
  width: 0.5rem;
}

.w-2\\.5 {
  width: 0.625rem;
}

.w-2\\/3 {
  width: 66.666667%;
}

.w-20 {
  width: 5rem;
}

.w-24 {
  width: 6rem;
}

.w-28 {
  width: 7rem;
}

.w-3 {
  width: 0.75rem;
}

.w-3\\.5 {
  width: 0.875rem;
}

.w-3\\/5 {
  width: 60%;
}

.w-32 {
  width: 8rem;
}

.w-36 {
  width: 9rem;
}

.w-4 {
  width: 1rem;
}

.w-4\\/5 {
  width: 80%;
}

.w-44 {
  width: 11rem;
}

.w-48 {
  width: 12rem;
}

.w-5 {
  width: 1.25rem;
}

.w-52 {
  width: 13rem;
}

.w-56 {
  width: 14rem;
}

.w-6 {
  width: 1.5rem;
}

.w-60 {
  width: 15rem;
}

.w-64 {
  width: 16rem;
}

.w-7 {
  width: 1.75rem;
}

.w-8 {
  width: 2rem;
}

.w-9 {
  width: 2.25rem;
}

.w-\\[4\\.5rem\\] {
  width: 4.5rem;
}

.w-\\[var\\(--input-width\\)\\] {
  width: var(--input-width);
}

.w-full {
  width: 100%;
}

.w-px {
  width: 1px;
}

.w-screen {
  width: 100vw;
}

.min-w-0 {
  min-width: 0;
}

.min-w-\\[1rem\\] {
  min-width: 1rem;
}

.min-w-\\[3rem\\] {
  min-width: 3rem;
}

.min-w-full {
  min-width: 100%;
}

.min-w-popup {
  min-width: 640px;
}

.max-w-4xl {
  max-width: 56rem;
}

.max-w-\\[100px\\] {
  max-width: 100px;
}

.max-w-\\[110px\\] {
  max-width: 110px;
}

.max-w-\\[120px\\] {
  max-width: 120px;
}

.max-w-\\[140px\\] {
  max-width: 140px;
}

.max-w-\\[150px\\] {
  max-width: 150px;
}

.max-w-\\[160px\\] {
  max-width: 160px;
}

.max-w-\\[180px\\] {
  max-width: 180px;
}

.max-w-\\[200px\\] {
  max-width: 200px;
}

.max-w-\\[250px\\] {
  max-width: 250px;
}

.max-w-\\[280px\\] {
  max-width: 280px;
}

.max-w-\\[300px\\] {
  max-width: 300px;
}

.max-w-\\[50px\\] {
  max-width: 50px;
}

.max-w-\\[80px\\] {
  max-width: 80px;
}

.max-w-\\[8rem\\] {
  max-width: 8rem;
}

.max-w-\\[95vw\\] {
  max-width: 95vw;
}

.max-w-full {
  max-width: 100%;
}

.max-w-lg {
  max-width: 32rem;
}

.max-w-md {
  max-width: 28rem;
}

.max-w-none {
  max-width: none;
}

.max-w-sm {
  max-width: 24rem;
}

.max-w-xs {
  max-width: 20rem;
}

.flex-1 {
  flex: 1 1 0%;
}

.flex-shrink-0 {
  flex-shrink: 0;
}

.shrink-0 {
  flex-shrink: 0;
}

.flex-grow {
  flex-grow: 1;
}

.-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-x-0 {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-x-1 {
  --tw-translate-x: 0.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-x-4 {
  --tw-translate-x: 1rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-x-5 {
  --tw-translate-x: 1.25rem;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.rotate-180 {
  --tw-rotate: 180deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

@keyframes pulse {
  50% {
    opacity: .5;
  }
}

.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.animate-spin {
  animation: spin 1s linear infinite;
}

.cursor-default {
  cursor: default;
}

.cursor-grab {
  cursor: grab;
}

.cursor-not-allowed {
  cursor: not-allowed;
}

.cursor-pointer {
  cursor: pointer;
}

.cursor-zoom-in {
  cursor: zoom-in;
}

.cursor-zoom-out {
  cursor: zoom-out;
}

.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}

.resize-none {
  resize: none;
}

.resize {
  resize: both;
}

.list-inside {
  list-style-position: inside;
}

.list-disc {
  list-style-type: disc;
}

.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}

.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.grid-cols-3 {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.grid-cols-\\[1fr_auto_auto\\] {
  grid-template-columns: 1fr auto auto;
}

.flex-row {
  flex-direction: row;
}

.flex-col {
  flex-direction: column;
}

.flex-wrap {
  flex-wrap: wrap;
}

.items-start {
  align-items: flex-start;
}

.items-center {
  align-items: center;
}

.justify-end {
  justify-content: flex-end;
}

.justify-center {
  justify-content: center;
}

.justify-between {
  justify-content: space-between;
}

.gap-0\\.5 {
  gap: 0.125rem;
}

.gap-1 {
  gap: 0.25rem;
}

.gap-1\\.5 {
  gap: 0.375rem;
}

.gap-2 {
  gap: 0.5rem;
}

.gap-2\\.5 {
  gap: 0.625rem;
}

.gap-3 {
  gap: 0.75rem;
}

.gap-4 {
  gap: 1rem;
}

.gap-x-3 {
  -moz-column-gap: 0.75rem;
       column-gap: 0.75rem;
}

.gap-y-1 {
  row-gap: 0.25rem;
}

.gap-y-1\\.5 {
  row-gap: 0.375rem;
}

.space-x-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(0.125rem * var(--tw-space-x-reverse));
  margin-left: calc(0.125rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(0.25rem * var(--tw-space-x-reverse));
  margin-left: calc(0.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(0.5rem * var(--tw-space-x-reverse));
  margin-left: calc(0.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-y-0\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.125rem * var(--tw-space-y-reverse));
}

.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));
}

.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}

.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.5rem * var(--tw-space-y-reverse));
}

.space-y-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.75rem * var(--tw-space-y-reverse));
}

.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(1rem * var(--tw-space-y-reverse));
}

.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}

.divide-gray-100 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(243 244 246 / var(--tw-divide-opacity, 1));
}

.divide-gray-200 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(229 231 235 / var(--tw-divide-opacity, 1));
}

.divide-neutral-100 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(245 245 245 / var(--tw-divide-opacity, 1));
}

.divide-neutral-200 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(229 229 229 / var(--tw-divide-opacity, 1));
}

.justify-self-center {
  justify-self: center;
}

.overflow-auto {
  overflow: auto;
}

.overflow-hidden {
  overflow: hidden;
}

.overflow-x-auto {
  overflow-x: auto;
}

.overflow-y-auto {
  overflow-y: auto;
}

.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.whitespace-nowrap {
  white-space: nowrap;
}

.whitespace-pre-line {
  white-space: pre-line;
}

.whitespace-pre-wrap {
  white-space: pre-wrap;
}

.break-words {
  overflow-wrap: break-word;
}

.rounded {
  border-radius: 0.25rem;
}

.rounded-full {
  border-radius: 9999px;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.rounded-md {
  border-radius: 0.375rem;
}

.rounded-sm {
  border-radius: 0.125rem;
}

.rounded-xl {
  border-radius: 0.75rem;
}

.rounded-l-md {
  border-top-left-radius: 0.375rem;
  border-bottom-left-radius: 0.375rem;
}

.rounded-r-md {
  border-top-right-radius: 0.375rem;
  border-bottom-right-radius: 0.375rem;
}

.rounded-r-sm {
  border-top-right-radius: 0.125rem;
  border-bottom-right-radius: 0.125rem;
}

.border {
  border-width: 1px;
}

.border-0 {
  border-width: 0px;
}

.border-2 {
  border-width: 2px;
}

.border-b {
  border-bottom-width: 1px;
}

.border-b-2 {
  border-bottom-width: 2px;
}

.border-l {
  border-left-width: 1px;
}

.border-l-2 {
  border-left-width: 2px;
}

.border-l-4 {
  border-left-width: 4px;
}

.border-t {
  border-top-width: 1px;
}

.border-dashed {
  border-style: dashed;
}

.border-none {
  border-style: none;
}

.border-amber-100 {
  --tw-border-opacity: 1;
  border-color: rgb(254 243 199 / var(--tw-border-opacity, 1));
}

.border-amber-200 {
  --tw-border-opacity: 1;
  border-color: rgb(253 230 138 / var(--tw-border-opacity, 1));
}

.border-amber-300 {
  --tw-border-opacity: 1;
  border-color: rgb(252 211 77 / var(--tw-border-opacity, 1));
}

.border-amber-700 {
  --tw-border-opacity: 1;
  border-color: rgb(180 83 9 / var(--tw-border-opacity, 1));
}

.border-blue-100 {
  --tw-border-opacity: 1;
  border-color: rgb(219 234 254 / var(--tw-border-opacity, 1));
}

.border-blue-200 {
  --tw-border-opacity: 1;
  border-color: rgb(191 219 254 / var(--tw-border-opacity, 1));
}

.border-blue-300 {
  --tw-border-opacity: 1;
  border-color: rgb(147 197 253 / var(--tw-border-opacity, 1));
}

.border-blue-500 {
  --tw-border-opacity: 1;
  border-color: rgb(59 130 246 / var(--tw-border-opacity, 1));
}

.border-blue-600 {
  --tw-border-opacity: 1;
  border-color: rgb(37 99 235 / var(--tw-border-opacity, 1));
}

.border-blue-700 {
  --tw-border-opacity: 1;
  border-color: rgb(29 78 216 / var(--tw-border-opacity, 1));
}

.border-current {
  border-color: currentColor;
}

.border-emerald-200 {
  --tw-border-opacity: 1;
  border-color: rgb(167 243 208 / var(--tw-border-opacity, 1));
}

.border-gray-100 {
  --tw-border-opacity: 1;
  border-color: rgb(243 244 246 / var(--tw-border-opacity, 1));
}

.border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(229 231 235 / var(--tw-border-opacity, 1));
}

.border-gray-300 {
  --tw-border-opacity: 1;
  border-color: rgb(209 213 219 / var(--tw-border-opacity, 1));
}

.border-gray-400 {
  --tw-border-opacity: 1;
  border-color: rgb(156 163 175 / var(--tw-border-opacity, 1));
}

.border-gray-600 {
  --tw-border-opacity: 1;
  border-color: rgb(75 85 99 / var(--tw-border-opacity, 1));
}

.border-gray-700 {
  --tw-border-opacity: 1;
  border-color: rgb(55 65 81 / var(--tw-border-opacity, 1));
}

.border-gray-900 {
  --tw-border-opacity: 1;
  border-color: rgb(17 24 39 / var(--tw-border-opacity, 1));
}

.border-green-100 {
  --tw-border-opacity: 1;
  border-color: rgb(220 252 231 / var(--tw-border-opacity, 1));
}

.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}

.border-green-300 {
  --tw-border-opacity: 1;
  border-color: rgb(134 239 172 / var(--tw-border-opacity, 1));
}

.border-green-500 {
  --tw-border-opacity: 1;
  border-color: rgb(34 197 94 / var(--tw-border-opacity, 1));
}

.border-green-600 {
  --tw-border-opacity: 1;
  border-color: rgb(22 163 74 / var(--tw-border-opacity, 1));
}

.border-green-700 {
  --tw-border-opacity: 1;
  border-color: rgb(21 128 61 / var(--tw-border-opacity, 1));
}

.border-indigo-200 {
  --tw-border-opacity: 1;
  border-color: rgb(199 210 254 / var(--tw-border-opacity, 1));
}

.border-indigo-300 {
  --tw-border-opacity: 1;
  border-color: rgb(165 180 252 / var(--tw-border-opacity, 1));
}

.border-indigo-700 {
  --tw-border-opacity: 1;
  border-color: rgb(67 56 202 / var(--tw-border-opacity, 1));
}

.border-neutral-100 {
  --tw-border-opacity: 1;
  border-color: rgb(245 245 245 / var(--tw-border-opacity, 1));
}

.border-neutral-200 {
  --tw-border-opacity: 1;
  border-color: rgb(229 229 229 / var(--tw-border-opacity, 1));
}

.border-neutral-300 {
  --tw-border-opacity: 1;
  border-color: rgb(212 212 212 / var(--tw-border-opacity, 1));
}

.border-neutral-900 {
  --tw-border-opacity: 1;
  border-color: rgb(23 23 23 / var(--tw-border-opacity, 1));
}

.border-orange-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 215 170 / var(--tw-border-opacity, 1));
}

.border-orange-300 {
  --tw-border-opacity: 1;
  border-color: rgb(253 186 116 / var(--tw-border-opacity, 1));
}

.border-orange-700 {
  --tw-border-opacity: 1;
  border-color: rgb(194 65 12 / var(--tw-border-opacity, 1));
}

.border-pink-200 {
  --tw-border-opacity: 1;
  border-color: rgb(251 207 232 / var(--tw-border-opacity, 1));
}

.border-pink-300 {
  --tw-border-opacity: 1;
  border-color: rgb(249 168 212 / var(--tw-border-opacity, 1));
}

.border-pink-700 {
  --tw-border-opacity: 1;
  border-color: rgb(190 24 93 / var(--tw-border-opacity, 1));
}

.border-purple-200 {
  --tw-border-opacity: 1;
  border-color: rgb(233 213 255 / var(--tw-border-opacity, 1));
}

.border-purple-300 {
  --tw-border-opacity: 1;
  border-color: rgb(216 180 254 / var(--tw-border-opacity, 1));
}

.border-purple-500 {
  --tw-border-opacity: 1;
  border-color: rgb(168 85 247 / var(--tw-border-opacity, 1));
}

.border-purple-700 {
  --tw-border-opacity: 1;
  border-color: rgb(126 34 206 / var(--tw-border-opacity, 1));
}

.border-red-100 {
  --tw-border-opacity: 1;
  border-color: rgb(254 226 226 / var(--tw-border-opacity, 1));
}

.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}

.border-red-300 {
  --tw-border-opacity: 1;
  border-color: rgb(252 165 165 / var(--tw-border-opacity, 1));
}

.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}

.border-red-700 {
  --tw-border-opacity: 1;
  border-color: rgb(185 28 28 / var(--tw-border-opacity, 1));
}

.border-slate-100 {
  --tw-border-opacity: 1;
  border-color: rgb(241 245 249 / var(--tw-border-opacity, 1));
}

.border-slate-200 {
  --tw-border-opacity: 1;
  border-color: rgb(226 232 240 / var(--tw-border-opacity, 1));
}

.border-slate-200\\/80 {
  border-color: rgb(226 232 240 / 0.8);
}

.border-slate-300 {
  --tw-border-opacity: 1;
  border-color: rgb(203 213 225 / var(--tw-border-opacity, 1));
}

.border-slate-600 {
  --tw-border-opacity: 1;
  border-color: rgb(71 85 105 / var(--tw-border-opacity, 1));
}

.border-slate-700 {
  --tw-border-opacity: 1;
  border-color: rgb(51 65 85 / var(--tw-border-opacity, 1));
}

.border-teal-200 {
  --tw-border-opacity: 1;
  border-color: rgb(153 246 228 / var(--tw-border-opacity, 1));
}

.border-teal-300 {
  --tw-border-opacity: 1;
  border-color: rgb(94 234 212 / var(--tw-border-opacity, 1));
}

.border-teal-700 {
  --tw-border-opacity: 1;
  border-color: rgb(15 118 110 / var(--tw-border-opacity, 1));
}

.border-transparent {
  border-color: transparent;
}

.border-white {
  --tw-border-opacity: 1;
  border-color: rgb(255 255 255 / var(--tw-border-opacity, 1));
}

.border-yellow-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 240 138 / var(--tw-border-opacity, 1));
}

.border-yellow-300 {
  --tw-border-opacity: 1;
  border-color: rgb(253 224 71 / var(--tw-border-opacity, 1));
}

.border-yellow-700 {
  --tw-border-opacity: 1;
  border-color: rgb(161 98 7 / var(--tw-border-opacity, 1));
}

.border-l-blue-400 {
  --tw-border-opacity: 1;
  border-left-color: rgb(96 165 250 / var(--tw-border-opacity, 1));
}

.border-l-blue-500 {
  --tw-border-opacity: 1;
  border-left-color: rgb(59 130 246 / var(--tw-border-opacity, 1));
}

.border-l-green-400 {
  --tw-border-opacity: 1;
  border-left-color: rgb(74 222 128 / var(--tw-border-opacity, 1));
}

.border-l-red-400 {
  --tw-border-opacity: 1;
  border-left-color: rgb(248 113 113 / var(--tw-border-opacity, 1));
}

.border-l-transparent {
  border-left-color: transparent;
}

.border-t-transparent {
  border-top-color: transparent;
}

.bg-amber-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 243 199 / var(--tw-bg-opacity, 1));
}

.bg-amber-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(253 230 138 / var(--tw-bg-opacity, 1));
}

.bg-amber-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}

.bg-amber-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(245 158 11 / var(--tw-bg-opacity, 1));
}

.bg-amber-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(217 119 6 / var(--tw-bg-opacity, 1));
}

.bg-amber-900\\/30 {
  background-color: rgb(120 53 15 / 0.3);
}

.bg-amber-900\\/40 {
  background-color: rgb(120 53 15 / 0.4);
}

.bg-amber-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(69 26 3 / var(--tw-bg-opacity, 1));
}

.bg-black {
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
}

.bg-black\\/25 {
  background-color: rgb(0 0 0 / 0.25);
}

.bg-black\\/30 {
  background-color: rgb(0 0 0 / 0.3);
}

.bg-black\\/50 {
  background-color: rgb(0 0 0 / 0.5);
}

.bg-black\\/60 {
  background-color: rgb(0 0 0 / 0.6);
}

.bg-black\\/80 {
  background-color: rgb(0 0 0 / 0.8);
}

.bg-blue-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}

.bg-blue-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(191 219 254 / var(--tw-bg-opacity, 1));
}

.bg-blue-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(147 197 253 / var(--tw-bg-opacity, 1));
}

.bg-blue-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(96 165 250 / var(--tw-bg-opacity, 1));
}

.bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}

.bg-blue-50\\/50 {
  background-color: rgb(239 246 255 / 0.5);
}

.bg-blue-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(59 130 246 / var(--tw-bg-opacity, 1));
}

.bg-blue-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(37 99 235 / var(--tw-bg-opacity, 1));
}

.bg-blue-900\\/30 {
  background-color: rgb(30 58 138 / 0.3);
}

.bg-blue-900\\/40 {
  background-color: rgb(30 58 138 / 0.4);
}

.bg-blue-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(23 37 84 / var(--tw-bg-opacity, 1));
}

.bg-cyan-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(207 250 254 / var(--tw-bg-opacity, 1));
}

.bg-cyan-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(6 182 212 / var(--tw-bg-opacity, 1));
}

.bg-cyan-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(8 51 68 / var(--tw-bg-opacity, 1));
}

.bg-emerald-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(209 250 229 / var(--tw-bg-opacity, 1));
}

.bg-emerald-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(167 243 208 / var(--tw-bg-opacity, 1));
}

.bg-emerald-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(236 253 245 / var(--tw-bg-opacity, 1));
}

.bg-emerald-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(16 185 129 / var(--tw-bg-opacity, 1));
}

.bg-emerald-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(5 150 105 / var(--tw-bg-opacity, 1));
}

.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}

.bg-gray-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(229 231 235 / var(--tw-bg-opacity, 1));
}

.bg-gray-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(209 213 219 / var(--tw-bg-opacity, 1));
}

.bg-gray-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(156 163 175 / var(--tw-bg-opacity, 1));
}

.bg-gray-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1));
}

.bg-gray-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(75 85 99 / var(--tw-bg-opacity, 1));
}

.bg-gray-700 {
  --tw-bg-opacity: 1;
  background-color: rgb(55 65 81 / var(--tw-bg-opacity, 1));
}

.bg-gray-700\\/50 {
  background-color: rgb(55 65 81 / 0.5);
}

.bg-gray-800 {
  --tw-bg-opacity: 1;
  background-color: rgb(31 41 55 / var(--tw-bg-opacity, 1));
}

.bg-gray-900 {
  --tw-bg-opacity: 1;
  background-color: rgb(17 24 39 / var(--tw-bg-opacity, 1));
}

.bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}

.bg-green-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(74 222 128 / var(--tw-bg-opacity, 1));
}

.bg-green-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}

.bg-green-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));
}

.bg-green-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));
}

.bg-green-900\\/40 {
  background-color: rgb(20 83 45 / 0.4);
}

.bg-green-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(5 46 22 / var(--tw-bg-opacity, 1));
}

.bg-indigo-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(224 231 255 / var(--tw-bg-opacity, 1));
}

.bg-indigo-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(129 140 248 / var(--tw-bg-opacity, 1));
}

.bg-indigo-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(238 242 255 / var(--tw-bg-opacity, 1));
}

.bg-indigo-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(99 102 241 / var(--tw-bg-opacity, 1));
}

.bg-indigo-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(79 70 229 / var(--tw-bg-opacity, 1));
}

.bg-indigo-900\\/40 {
  background-color: rgb(49 46 129 / 0.4);
}

.bg-neutral-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(245 245 245 / var(--tw-bg-opacity, 1));
}

.bg-neutral-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(229 229 229 / var(--tw-bg-opacity, 1));
}

.bg-neutral-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(212 212 212 / var(--tw-bg-opacity, 1));
}

.bg-neutral-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
}

.bg-neutral-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(115 115 115 / var(--tw-bg-opacity, 1));
}

.bg-neutral-800 {
  --tw-bg-opacity: 1;
  background-color: rgb(38 38 38 / var(--tw-bg-opacity, 1));
}

.bg-neutral-900 {
  --tw-bg-opacity: 1;
  background-color: rgb(23 23 23 / var(--tw-bg-opacity, 1));
}

.bg-orange-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 237 213 / var(--tw-bg-opacity, 1));
}

.bg-orange-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(251 146 60 / var(--tw-bg-opacity, 1));
}

.bg-orange-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 247 237 / var(--tw-bg-opacity, 1));
}

.bg-orange-900\\/40 {
  background-color: rgb(124 45 18 / 0.4);
}

.bg-pink-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(252 231 243 / var(--tw-bg-opacity, 1));
}

.bg-pink-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(244 114 182 / var(--tw-bg-opacity, 1));
}

.bg-pink-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(253 242 248 / var(--tw-bg-opacity, 1));
}

.bg-pink-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(236 72 153 / var(--tw-bg-opacity, 1));
}

.bg-pink-900\\/40 {
  background-color: rgb(131 24 67 / 0.4);
}

.bg-pink-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(80 7 36 / var(--tw-bg-opacity, 1));
}

.bg-purple-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(243 232 255 / var(--tw-bg-opacity, 1));
}

.bg-purple-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(192 132 252 / var(--tw-bg-opacity, 1));
}

.bg-purple-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(250 245 255 / var(--tw-bg-opacity, 1));
}

.bg-purple-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(168 85 247 / var(--tw-bg-opacity, 1));
}

.bg-purple-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(147 51 234 / var(--tw-bg-opacity, 1));
}

.bg-purple-900\\/40 {
  background-color: rgb(88 28 135 / 0.4);
}

.bg-red-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}

.bg-red-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}

.bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}

.bg-red-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity, 1));
}

.bg-red-900\\/30 {
  background-color: rgb(127 29 29 / 0.3);
}

.bg-red-900\\/40 {
  background-color: rgb(127 29 29 / 0.4);
}

.bg-rose-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(255 228 230 / var(--tw-bg-opacity, 1));
}

.bg-rose-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(244 63 94 / var(--tw-bg-opacity, 1));
}

.bg-slate-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(241 245 249 / var(--tw-bg-opacity, 1));
}

.bg-slate-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(226 232 240 / var(--tw-bg-opacity, 1));
}

.bg-slate-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(248 250 252 / var(--tw-bg-opacity, 1));
}

.bg-slate-700 {
  --tw-bg-opacity: 1;
  background-color: rgb(51 65 85 / var(--tw-bg-opacity, 1));
}

.bg-slate-800 {
  --tw-bg-opacity: 1;
  background-color: rgb(30 41 59 / var(--tw-bg-opacity, 1));
}

.bg-slate-900 {
  --tw-bg-opacity: 1;
  background-color: rgb(15 23 42 / var(--tw-bg-opacity, 1));
}

.bg-teal-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(204 251 241 / var(--tw-bg-opacity, 1));
}

.bg-teal-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(45 212 191 / var(--tw-bg-opacity, 1));
}

.bg-teal-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 250 / var(--tw-bg-opacity, 1));
}

.bg-teal-900\\/40 {
  background-color: rgb(19 78 74 / 0.4);
}

.bg-transparent {
  background-color: transparent;
}

.bg-violet-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(237 233 254 / var(--tw-bg-opacity, 1));
}

.bg-violet-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(139 92 246 / var(--tw-bg-opacity, 1));
}

.bg-violet-950 {
  --tw-bg-opacity: 1;
  background-color: rgb(46 16 101 / var(--tw-bg-opacity, 1));
}

.bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
}

.bg-white\\/20 {
  background-color: rgb(255 255 255 / 0.2);
}

.bg-white\\/30 {
  background-color: rgb(255 255 255 / 0.3);
}

.bg-white\\/60 {
  background-color: rgb(255 255 255 / 0.6);
}

.bg-yellow-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 249 195 / var(--tw-bg-opacity, 1));
}

.bg-yellow-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 240 138 / var(--tw-bg-opacity, 1));
}

.bg-yellow-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(250 204 21 / var(--tw-bg-opacity, 1));
}

.bg-yellow-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}

.bg-yellow-900\\/40 {
  background-color: rgb(113 63 18 / 0.4);
}

.bg-gradient-to-t {
  background-image: linear-gradient(to top, var(--tw-gradient-stops));
}

.from-black\\/60 {
  --tw-gradient-from: rgb(0 0 0 / 0.6) var(--tw-gradient-from-position);
  --tw-gradient-to: rgb(0 0 0 / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.to-transparent {
  --tw-gradient-to: transparent var(--tw-gradient-to-position);
}

.object-contain {
  -o-object-fit: contain;
     object-fit: contain;
}

.object-cover {
  -o-object-fit: cover;
     object-fit: cover;
}

.p-0\\.5 {
  padding: 0.125rem;
}

.p-1 {
  padding: 0.25rem;
}

.p-1\\.5 {
  padding: 0.375rem;
}

.p-2 {
  padding: 0.5rem;
}

.p-2\\.5 {
  padding: 0.625rem;
}

.p-3 {
  padding: 0.75rem;
}

.p-4 {
  padding: 1rem;
}

.p-5 {
  padding: 1.25rem;
}

.p-6 {
  padding: 1.5rem;
}

.p-8 {
  padding: 2rem;
}

.px-0\\.5 {
  padding-left: 0.125rem;
  padding-right: 0.125rem;
}

.px-1 {
  padding-left: 0.25rem;
  padding-right: 0.25rem;
}

.px-1\\.5 {
  padding-left: 0.375rem;
  padding-right: 0.375rem;
}

.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}

.px-2\\.5 {
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}

.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}

.py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}

.py-0\\.5 {
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
}

.py-1 {
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
}

.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}

.py-10 {
  padding-top: 2.5rem;
  padding-bottom: 2.5rem;
}

.py-12 {
  padding-top: 3rem;
  padding-bottom: 3rem;
}

.py-16 {
  padding-top: 4rem;
  padding-bottom: 4rem;
}

.py-2 {
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}

.py-2\\.5 {
  padding-top: 0.625rem;
  padding-bottom: 0.625rem;
}

.py-3 {
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}

.py-4 {
  padding-top: 1rem;
  padding-bottom: 1rem;
}

.py-6 {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}

.py-8 {
  padding-top: 2rem;
  padding-bottom: 2rem;
}

.pb-0\\.5 {
  padding-bottom: 0.125rem;
}

.pb-1 {
  padding-bottom: 0.25rem;
}

.pb-2 {
  padding-bottom: 0.5rem;
}

.pb-2\\.5 {
  padding-bottom: 0.625rem;
}

.pb-28 {
  padding-bottom: 7rem;
}

.pb-3 {
  padding-bottom: 0.75rem;
}

.pb-4 {
  padding-bottom: 1rem;
}

.pl-2 {
  padding-left: 0.5rem;
}

.pl-2\\.5 {
  padding-left: 0.625rem;
}

.pl-3 {
  padding-left: 0.75rem;
}

.pl-5 {
  padding-left: 1.25rem;
}

.pl-6 {
  padding-left: 1.5rem;
}

.pl-7 {
  padding-left: 1.75rem;
}

.pl-8 {
  padding-left: 2rem;
}

.pl-\\[72px\\] {
  padding-left: 72px;
}

.pr-1\\.5 {
  padding-right: 0.375rem;
}

.pr-2 {
  padding-right: 0.5rem;
}

.pr-3 {
  padding-right: 0.75rem;
}

.pr-7 {
  padding-right: 1.75rem;
}

.pr-8 {
  padding-right: 2rem;
}

.pt-1 {
  padding-top: 0.25rem;
}

.pt-1\\.5 {
  padding-top: 0.375rem;
}

.pt-2 {
  padding-top: 0.5rem;
}

.pt-3 {
  padding-top: 0.75rem;
}

.pt-4 {
  padding-top: 1rem;
}

.text-left {
  text-align: left;
}

.text-center {
  text-align: center;
}

.text-right {
  text-align: right;
}

.align-top {
  vertical-align: top;
}

.font-mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

.font-sans {
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}

.text-2xl {
  font-size: 1.5rem;
  line-height: 2rem;
}

.text-\\[10px\\] {
  font-size: 10px;
}

.text-\\[11px\\] {
  font-size: 11px;
}

.text-\\[7px\\] {
  font-size: 7px;
}

.text-\\[8px\\] {
  font-size: 8px;
}

.text-\\[9px\\] {
  font-size: 9px;
}

.text-base {
  font-size: 1rem;
  line-height: 1.5rem;
}

.text-lg {
  font-size: 1.125rem;
  line-height: 1.75rem;
}

.text-sm {
  font-size: 0.875rem;
  line-height: 1.25rem;
}

.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}

.font-bold {
  font-weight: 700;
}

.font-light {
  font-weight: 300;
}

.font-medium {
  font-weight: 500;
}

.font-normal {
  font-weight: 400;
}

.font-semibold {
  font-weight: 600;
}

.uppercase {
  text-transform: uppercase;
}

.lowercase {
  text-transform: lowercase;
}

.normal-case {
  text-transform: none;
}

.italic {
  font-style: italic;
}

.tabular-nums {
  --tw-numeric-spacing: tabular-nums;
  font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
}

.leading-6 {
  line-height: 1.5rem;
}

.leading-none {
  line-height: 1;
}

.leading-relaxed {
  line-height: 1.625;
}

.leading-snug {
  line-height: 1.375;
}

.leading-tight {
  line-height: 1.25;
}

.tracking-tight {
  letter-spacing: -0.025em;
}

.tracking-wide {
  letter-spacing: 0.025em;
}

.tracking-wider {
  letter-spacing: 0.05em;
}

.text-amber-300 {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}

.text-amber-400 {
  --tw-text-opacity: 1;
  color: rgb(251 191 36 / var(--tw-text-opacity, 1));
}

.text-amber-500 {
  --tw-text-opacity: 1;
  color: rgb(245 158 11 / var(--tw-text-opacity, 1));
}

.text-amber-600 {
  --tw-text-opacity: 1;
  color: rgb(217 119 6 / var(--tw-text-opacity, 1));
}

.text-amber-700 {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}

.text-amber-800 {
  --tw-text-opacity: 1;
  color: rgb(146 64 14 / var(--tw-text-opacity, 1));
}

.text-amber-900 {
  --tw-text-opacity: 1;
  color: rgb(120 53 15 / var(--tw-text-opacity, 1));
}

.text-blue-100 {
  --tw-text-opacity: 1;
  color: rgb(219 234 254 / var(--tw-text-opacity, 1));
}

.text-blue-300 {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}

.text-blue-400 {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}

.text-blue-500 {
  --tw-text-opacity: 1;
  color: rgb(59 130 246 / var(--tw-text-opacity, 1));
}

.text-blue-600 {
  --tw-text-opacity: 1;
  color: rgb(37 99 235 / var(--tw-text-opacity, 1));
}

.text-blue-700 {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}

.text-blue-800 {
  --tw-text-opacity: 1;
  color: rgb(30 64 175 / var(--tw-text-opacity, 1));
}

.text-blue-900 {
  --tw-text-opacity: 1;
  color: rgb(30 58 138 / var(--tw-text-opacity, 1));
}

.text-cyan-300 {
  --tw-text-opacity: 1;
  color: rgb(103 232 249 / var(--tw-text-opacity, 1));
}

.text-cyan-700 {
  --tw-text-opacity: 1;
  color: rgb(14 116 144 / var(--tw-text-opacity, 1));
}

.text-emerald-500 {
  --tw-text-opacity: 1;
  color: rgb(16 185 129 / var(--tw-text-opacity, 1));
}

.text-emerald-600 {
  --tw-text-opacity: 1;
  color: rgb(5 150 105 / var(--tw-text-opacity, 1));
}

.text-emerald-700 {
  --tw-text-opacity: 1;
  color: rgb(4 120 87 / var(--tw-text-opacity, 1));
}

.text-emerald-900 {
  --tw-text-opacity: 1;
  color: rgb(6 78 59 / var(--tw-text-opacity, 1));
}

.text-gray-100 {
  --tw-text-opacity: 1;
  color: rgb(243 244 246 / var(--tw-text-opacity, 1));
}

.text-gray-200 {
  --tw-text-opacity: 1;
  color: rgb(229 231 235 / var(--tw-text-opacity, 1));
}

.text-gray-300 {
  --tw-text-opacity: 1;
  color: rgb(209 213 219 / var(--tw-text-opacity, 1));
}

.text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}

.text-gray-500 {
  --tw-text-opacity: 1;
  color: rgb(107 114 128 / var(--tw-text-opacity, 1));
}

.text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(75 85 99 / var(--tw-text-opacity, 1));
}

.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}

.text-gray-800 {
  --tw-text-opacity: 1;
  color: rgb(31 41 55 / var(--tw-text-opacity, 1));
}

.text-gray-900 {
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity, 1));
}

.text-green-300 {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}

.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}

.text-green-600 {
  --tw-text-opacity: 1;
  color: rgb(22 163 74 / var(--tw-text-opacity, 1));
}

.text-green-700 {
  --tw-text-opacity: 1;
  color: rgb(21 128 61 / var(--tw-text-opacity, 1));
}

.text-green-800 {
  --tw-text-opacity: 1;
  color: rgb(22 101 52 / var(--tw-text-opacity, 1));
}

.text-green-900 {
  --tw-text-opacity: 1;
  color: rgb(20 83 45 / var(--tw-text-opacity, 1));
}

.text-indigo-300 {
  --tw-text-opacity: 1;
  color: rgb(165 180 252 / var(--tw-text-opacity, 1));
}

.text-indigo-600 {
  --tw-text-opacity: 1;
  color: rgb(79 70 229 / var(--tw-text-opacity, 1));
}

.text-indigo-700 {
  --tw-text-opacity: 1;
  color: rgb(67 56 202 / var(--tw-text-opacity, 1));
}

.text-indigo-800 {
  --tw-text-opacity: 1;
  color: rgb(55 48 163 / var(--tw-text-opacity, 1));
}

.text-inherit {
  color: inherit;
}

.text-neutral-400 {
  --tw-text-opacity: 1;
  color: rgb(163 163 163 / var(--tw-text-opacity, 1));
}

.text-neutral-500 {
  --tw-text-opacity: 1;
  color: rgb(115 115 115 / var(--tw-text-opacity, 1));
}

.text-neutral-600 {
  --tw-text-opacity: 1;
  color: rgb(82 82 82 / var(--tw-text-opacity, 1));
}

.text-neutral-700 {
  --tw-text-opacity: 1;
  color: rgb(64 64 64 / var(--tw-text-opacity, 1));
}

.text-neutral-800 {
  --tw-text-opacity: 1;
  color: rgb(38 38 38 / var(--tw-text-opacity, 1));
}

.text-neutral-900 {
  --tw-text-opacity: 1;
  color: rgb(23 23 23 / var(--tw-text-opacity, 1));
}

.text-orange-300 {
  --tw-text-opacity: 1;
  color: rgb(253 186 116 / var(--tw-text-opacity, 1));
}

.text-orange-500 {
  --tw-text-opacity: 1;
  color: rgb(249 115 22 / var(--tw-text-opacity, 1));
}

.text-orange-600 {
  --tw-text-opacity: 1;
  color: rgb(234 88 12 / var(--tw-text-opacity, 1));
}

.text-orange-700 {
  --tw-text-opacity: 1;
  color: rgb(194 65 12 / var(--tw-text-opacity, 1));
}

.text-orange-800 {
  --tw-text-opacity: 1;
  color: rgb(154 52 18 / var(--tw-text-opacity, 1));
}

.text-pink-300 {
  --tw-text-opacity: 1;
  color: rgb(249 168 212 / var(--tw-text-opacity, 1));
}

.text-pink-700 {
  --tw-text-opacity: 1;
  color: rgb(190 24 93 / var(--tw-text-opacity, 1));
}

.text-pink-800 {
  --tw-text-opacity: 1;
  color: rgb(157 23 77 / var(--tw-text-opacity, 1));
}

.text-purple-300 {
  --tw-text-opacity: 1;
  color: rgb(216 180 254 / var(--tw-text-opacity, 1));
}

.text-purple-500 {
  --tw-text-opacity: 1;
  color: rgb(168 85 247 / var(--tw-text-opacity, 1));
}

.text-purple-700 {
  --tw-text-opacity: 1;
  color: rgb(126 34 206 / var(--tw-text-opacity, 1));
}

.text-purple-800 {
  --tw-text-opacity: 1;
  color: rgb(107 33 168 / var(--tw-text-opacity, 1));
}

.text-red-300 {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}

.text-red-400 {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}

.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}

.text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}

.text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity, 1));
}

.text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity, 1));
}

.text-rose-700 {
  --tw-text-opacity: 1;
  color: rgb(190 18 60 / var(--tw-text-opacity, 1));
}

.text-sky-600 {
  --tw-text-opacity: 1;
  color: rgb(2 132 199 / var(--tw-text-opacity, 1));
}

.text-slate-100 {
  --tw-text-opacity: 1;
  color: rgb(241 245 249 / var(--tw-text-opacity, 1));
}

.text-slate-300 {
  --tw-text-opacity: 1;
  color: rgb(203 213 225 / var(--tw-text-opacity, 1));
}

.text-slate-400 {
  --tw-text-opacity: 1;
  color: rgb(148 163 184 / var(--tw-text-opacity, 1));
}

.text-slate-500 {
  --tw-text-opacity: 1;
  color: rgb(100 116 139 / var(--tw-text-opacity, 1));
}

.text-slate-600 {
  --tw-text-opacity: 1;
  color: rgb(71 85 105 / var(--tw-text-opacity, 1));
}

.text-slate-700 {
  --tw-text-opacity: 1;
  color: rgb(51 65 85 / var(--tw-text-opacity, 1));
}

.text-slate-800 {
  --tw-text-opacity: 1;
  color: rgb(30 41 59 / var(--tw-text-opacity, 1));
}

.text-slate-900 {
  --tw-text-opacity: 1;
  color: rgb(15 23 42 / var(--tw-text-opacity, 1));
}

.text-teal-300 {
  --tw-text-opacity: 1;
  color: rgb(94 234 212 / var(--tw-text-opacity, 1));
}

.text-teal-700 {
  --tw-text-opacity: 1;
  color: rgb(15 118 110 / var(--tw-text-opacity, 1));
}

.text-teal-800 {
  --tw-text-opacity: 1;
  color: rgb(17 94 89 / var(--tw-text-opacity, 1));
}

.text-violet-300 {
  --tw-text-opacity: 1;
  color: rgb(196 181 253 / var(--tw-text-opacity, 1));
}

.text-violet-700 {
  --tw-text-opacity: 1;
  color: rgb(109 40 217 / var(--tw-text-opacity, 1));
}

.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}

.text-yellow-300 {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}

.text-yellow-500 {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}

.text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity, 1));
}

.text-yellow-800 {
  --tw-text-opacity: 1;
  color: rgb(133 77 14 / var(--tw-text-opacity, 1));
}

.underline {
  text-decoration-line: underline;
}

.placeholder-gray-400::-moz-placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(156 163 175 / var(--tw-placeholder-opacity, 1));
}

.placeholder-gray-400::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(156 163 175 / var(--tw-placeholder-opacity, 1));
}

.placeholder-neutral-400::-moz-placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(163 163 163 / var(--tw-placeholder-opacity, 1));
}

.placeholder-neutral-400::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(163 163 163 / var(--tw-placeholder-opacity, 1));
}

.placeholder-slate-400::-moz-placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(148 163 184 / var(--tw-placeholder-opacity, 1));
}

.placeholder-slate-400::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(148 163 184 / var(--tw-placeholder-opacity, 1));
}

.accent-gray-900 {
  accent-color: #111827;
}

.opacity-0 {
  opacity: 0;
}

.opacity-100 {
  opacity: 1;
}

.opacity-25 {
  opacity: 0.25;
}

.opacity-30 {
  opacity: 0.3;
}

.opacity-40 {
  opacity: 0.4;
}

.opacity-50 {
  opacity: 0.5;
}

.opacity-60 {
  opacity: 0.6;
}

.opacity-70 {
  opacity: 0.7;
}

.opacity-75 {
  opacity: 0.75;
}

.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-2xl {
  --tw-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-\\[0_1px_0_0_rgb\\(229\\2c 231\\2c 235\\)\\] {
  --tw-shadow: 0 1px 0 0 rgb(229,231,235);
  --tw-shadow-colored: 0 1px 0 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.ring-0 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-1 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-2 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-inset {
  --tw-ring-inset: inset;
}

.ring-black {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(0 0 0 / var(--tw-ring-opacity, 1));
}

.ring-black\\/5 {
  --tw-ring-color: rgb(0 0 0 / 0.05);
}

.ring-blue-400 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(96 165 250 / var(--tw-ring-opacity, 1));
}

.ring-blue-500 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(59 130 246 / var(--tw-ring-opacity, 1));
}

.ring-current {
  --tw-ring-color: currentColor;
}

.ring-gray-400 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(156 163 175 / var(--tw-ring-opacity, 1));
}

.ring-neutral-300 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(212 212 212 / var(--tw-ring-opacity, 1));
}

.ring-neutral-900 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(23 23 23 / var(--tw-ring-opacity, 1));
}

.ring-opacity-5 {
  --tw-ring-opacity: 0.05;
}

.ring-offset-1 {
  --tw-ring-offset-width: 1px;
}

.ring-offset-2 {
  --tw-ring-offset-width: 2px;
}

.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.backdrop-blur-sm {
  --tw-backdrop-blur: blur(4px);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}

.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-opacity {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-shadow {
  transition-property: box-shadow;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.duration-150 {
  transition-duration: 150ms;
}

.duration-200 {
  transition-duration: 200ms;
}

.duration-300 {
  transition-duration: 300ms;
}

.ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-4px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dark\\:prose-invert:is(.dark *) {
  --tw-prose-body: var(--tw-prose-invert-body);
  --tw-prose-headings: var(--tw-prose-invert-headings);
  --tw-prose-lead: var(--tw-prose-invert-lead);
  --tw-prose-links: var(--tw-prose-invert-links);
  --tw-prose-bold: var(--tw-prose-invert-bold);
  --tw-prose-counters: var(--tw-prose-invert-counters);
  --tw-prose-bullets: var(--tw-prose-invert-bullets);
  --tw-prose-hr: var(--tw-prose-invert-hr);
  --tw-prose-quotes: var(--tw-prose-invert-quotes);
  --tw-prose-quote-borders: var(--tw-prose-invert-quote-borders);
  --tw-prose-captions: var(--tw-prose-invert-captions);
  --tw-prose-kbd: var(--tw-prose-invert-kbd);
  --tw-prose-kbd-shadows: var(--tw-prose-invert-kbd-shadows);
  --tw-prose-code: var(--tw-prose-invert-code);
  --tw-prose-pre-code: var(--tw-prose-invert-pre-code);
  --tw-prose-pre-bg: var(--tw-prose-invert-pre-bg);
  --tw-prose-th-borders: var(--tw-prose-invert-th-borders);
  --tw-prose-td-borders: var(--tw-prose-invert-td-borders);
}

.file\\:mr-2::file-selector-button {
  margin-right: 0.5rem;
}

.file\\:rounded-md::file-selector-button {
  border-radius: 0.375rem;
}

.file\\:border-0::file-selector-button {
  border-width: 0px;
}

.file\\:bg-gray-100::file-selector-button {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}

.file\\:bg-neutral-100::file-selector-button {
  --tw-bg-opacity: 1;
  background-color: rgb(245 245 245 / var(--tw-bg-opacity, 1));
}

.file\\:px-3::file-selector-button {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

.file\\:py-1\\.5::file-selector-button {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}

.file\\:text-xs::file-selector-button {
  font-size: 0.75rem;
  line-height: 1rem;
}

.file\\:font-medium::file-selector-button {
  font-weight: 500;
}

.file\\:text-gray-700::file-selector-button {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}

.file\\:text-neutral-700::file-selector-button {
  --tw-text-opacity: 1;
  color: rgb(64 64 64 / var(--tw-text-opacity, 1));
}

.placeholder\\:text-gray-400::-moz-placeholder {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}

.placeholder\\:text-gray-400::placeholder {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}

.placeholder\\:text-neutral-400::-moz-placeholder {
  --tw-text-opacity: 1;
  color: rgb(163 163 163 / var(--tw-text-opacity, 1));
}

.placeholder\\:text-neutral-400::placeholder {
  --tw-text-opacity: 1;
  color: rgb(163 163 163 / var(--tw-text-opacity, 1));
}

.first\\:mt-0:first-child {
  margin-top: 0px;
}

.even\\:bg-gray-50:nth-child(even) {
  --tw-bg-opacity: 1;
  background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1));
}

.even\\:bg-neutral-50\\/30:nth-child(even) {
  background-color: rgb(250 250 250 / 0.3);
}

.focus-within\\:border-blue-400:focus-within {
  --tw-border-opacity: 1;
  border-color: rgb(96 165 250 / var(--tw-border-opacity, 1));
}

.focus-within\\:ring-1:focus-within {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus-within\\:ring-blue-400\\/50:focus-within {
  --tw-ring-color: rgb(96 165 250 / 0.5);
}

.hover\\:border-blue-500:hover {
  --tw-border-opacity: 1;
  border-color: rgb(59 130 246 / var(--tw-border-opacity, 1));
}

.hover\\:border-gray-300:hover {
  --tw-border-opacity: 1;
  border-color: rgb(209 213 219 / var(--tw-border-opacity, 1));
}

.hover\\:border-gray-400:hover {
  --tw-border-opacity: 1;
  border-color: rgb(156 163 175 / var(--tw-border-opacity, 1));
}

.hover\\:border-neutral-400:hover {
  --tw-border-opacity: 1;
  border-color: rgb(163 163 163 / var(--tw-border-opacity, 1));
}

.hover\\:bg-amber-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(254 243 199 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-amber-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(255 251 235 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-amber-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(180 83 9 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-amber-900\\/50:hover {
  background-color: rgb(120 53 15 / 0.5);
}

.hover\\:bg-black\\/10:hover {
  background-color: rgb(0 0 0 / 0.1);
}

.hover\\:bg-black\\/80:hover {
  background-color: rgb(0 0 0 / 0.8);
}

.hover\\:bg-blue-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(219 234 254 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-blue-400:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(96 165 250 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-blue-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(239 246 255 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-blue-50\\/50:hover {
  background-color: rgb(239 246 255 / 0.5);
}

.hover\\:bg-blue-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(37 99 235 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-blue-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(29 78 216 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-blue-900\\/30:hover {
  background-color: rgb(30 58 138 / 0.3);
}

.hover\\:bg-emerald-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(209 250 229 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-emerald-200:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(167 243 208 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-emerald-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(4 120 87 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-gray-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-gray-200:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(229 231 235 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-gray-200\\/60:hover {
  background-color: rgb(229 231 235 / 0.6);
}

.hover\\:bg-gray-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-gray-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(75 85 99 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-gray-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(55 65 81 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-gray-800:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(31 41 55 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-green-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-green-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-indigo-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(67 56 202 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-neutral-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(245 245 245 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-neutral-200:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(229 229 229 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-neutral-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-neutral-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(82 82 82 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-neutral-800:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(38 38 38 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-purple-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(126 34 206 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-red-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(254 226 226 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-red-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-red-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-red-900\\/50:hover {
  background-color: rgb(127 29 29 / 0.5);
}

.hover\\:bg-slate-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(241 245 249 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-slate-200:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(226 232 240 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-slate-800:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(30 41 59 / var(--tw-bg-opacity, 1));
}

.hover\\:bg-yellow-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(254 252 232 / var(--tw-bg-opacity, 1));
}

.hover\\:text-amber-500:hover {
  --tw-text-opacity: 1;
  color: rgb(245 158 11 / var(--tw-text-opacity, 1));
}

.hover\\:text-amber-700:hover {
  --tw-text-opacity: 1;
  color: rgb(180 83 9 / var(--tw-text-opacity, 1));
}

.hover\\:text-blue-400:hover {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}

.hover\\:text-blue-600:hover {
  --tw-text-opacity: 1;
  color: rgb(37 99 235 / var(--tw-text-opacity, 1));
}

.hover\\:text-blue-700:hover {
  --tw-text-opacity: 1;
  color: rgb(29 78 216 / var(--tw-text-opacity, 1));
}

.hover\\:text-blue-900:hover {
  --tw-text-opacity: 1;
  color: rgb(30 58 138 / var(--tw-text-opacity, 1));
}

.hover\\:text-emerald-700:hover {
  --tw-text-opacity: 1;
  color: rgb(4 120 87 / var(--tw-text-opacity, 1));
}

.hover\\:text-emerald-800:hover {
  --tw-text-opacity: 1;
  color: rgb(6 95 70 / var(--tw-text-opacity, 1));
}

.hover\\:text-gray-200:hover {
  --tw-text-opacity: 1;
  color: rgb(229 231 235 / var(--tw-text-opacity, 1));
}

.hover\\:text-gray-300:hover {
  --tw-text-opacity: 1;
  color: rgb(209 213 219 / var(--tw-text-opacity, 1));
}

.hover\\:text-gray-600:hover {
  --tw-text-opacity: 1;
  color: rgb(75 85 99 / var(--tw-text-opacity, 1));
}

.hover\\:text-gray-700:hover {
  --tw-text-opacity: 1;
  color: rgb(55 65 81 / var(--tw-text-opacity, 1));
}

.hover\\:text-gray-800:hover {
  --tw-text-opacity: 1;
  color: rgb(31 41 55 / var(--tw-text-opacity, 1));
}

.hover\\:text-gray-900:hover {
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity, 1));
}

.hover\\:text-green-500:hover {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}

.hover\\:text-green-600:hover {
  --tw-text-opacity: 1;
  color: rgb(22 163 74 / var(--tw-text-opacity, 1));
}

.hover\\:text-neutral-600:hover {
  --tw-text-opacity: 1;
  color: rgb(82 82 82 / var(--tw-text-opacity, 1));
}

.hover\\:text-neutral-700:hover {
  --tw-text-opacity: 1;
  color: rgb(64 64 64 / var(--tw-text-opacity, 1));
}

.hover\\:text-neutral-800:hover {
  --tw-text-opacity: 1;
  color: rgb(38 38 38 / var(--tw-text-opacity, 1));
}

.hover\\:text-neutral-900:hover {
  --tw-text-opacity: 1;
  color: rgb(23 23 23 / var(--tw-text-opacity, 1));
}

.hover\\:text-red-500:hover {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}

.hover\\:text-red-600:hover {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}

.hover\\:text-slate-600:hover {
  --tw-text-opacity: 1;
  color: rgb(71 85 105 / var(--tw-text-opacity, 1));
}

.hover\\:text-slate-700:hover {
  --tw-text-opacity: 1;
  color: rgb(51 65 85 / var(--tw-text-opacity, 1));
}

.hover\\:text-slate-800:hover {
  --tw-text-opacity: 1;
  color: rgb(30 41 59 / var(--tw-text-opacity, 1));
}

.hover\\:underline:hover {
  text-decoration-line: underline;
}

.hover\\:opacity-100:hover {
  opacity: 1;
}

.hover\\:opacity-80:hover {
  opacity: 0.8;
}

.hover\\:brightness-95:hover {
  --tw-brightness: brightness(.95);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.hover\\:file\\:bg-gray-200::file-selector-button:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(229 231 235 / var(--tw-bg-opacity, 1));
}

.hover\\:file\\:bg-neutral-200::file-selector-button:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(229 229 229 / var(--tw-bg-opacity, 1));
}

.focus\\:border-blue-500:focus {
  --tw-border-opacity: 1;
  border-color: rgb(59 130 246 / var(--tw-border-opacity, 1));
}

.focus\\:border-emerald-500:focus {
  --tw-border-opacity: 1;
  border-color: rgb(16 185 129 / var(--tw-border-opacity, 1));
}

.focus\\:border-gray-900:focus {
  --tw-border-opacity: 1;
  border-color: rgb(17 24 39 / var(--tw-border-opacity, 1));
}

.focus\\:border-neutral-900:focus {
  --tw-border-opacity: 1;
  border-color: rgb(23 23 23 / var(--tw-border-opacity, 1));
}

.focus\\:border-red-500:focus {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}

.focus\\:border-transparent:focus {
  border-color: transparent;
}

.focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.focus\\:ring-0:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\\:ring-inset:focus {
  --tw-ring-inset: inset;
}

.focus\\:ring-blue-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(59 130 246 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-emerald-200:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(167 243 208 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-emerald-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(16 185 129 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-gray-900:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(17 24 39 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-green-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(34 197 94 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-neutral-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(115 115 115 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-neutral-900:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(23 23 23 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-neutral-900\\/20:focus {
  --tw-ring-color: rgb(23 23 23 / 0.2);
}

.focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-slate-200:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(226 232 240 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-slate-400:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(148 163 184 / var(--tw-ring-opacity, 1));
}

.focus\\:ring-offset-1:focus {
  --tw-ring-offset-width: 1px;
}

.focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}

.focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus-visible\\:ring-purple-500:focus-visible {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(168 85 247 / var(--tw-ring-opacity, 1));
}

.active\\:cursor-grabbing:active {
  cursor: grabbing;
}

.active\\:bg-emerald-200:active {
  --tw-bg-opacity: 1;
  background-color: rgb(167 243 208 / var(--tw-bg-opacity, 1));
}

.active\\:bg-slate-200:active {
  --tw-bg-opacity: 1;
  background-color: rgb(226 232 240 / var(--tw-bg-opacity, 1));
}

.active\\:bg-slate-300:active {
  --tw-bg-opacity: 1;
  background-color: rgb(203 213 225 / var(--tw-bg-opacity, 1));
}

.disabled\\:cursor-not-allowed:disabled {
  cursor: not-allowed;
}

.disabled\\:bg-gray-50:disabled {
  --tw-bg-opacity: 1;
  background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1));
}

.disabled\\:bg-neutral-50:disabled {
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
}

.disabled\\:text-gray-500:disabled {
  --tw-text-opacity: 1;
  color: rgb(107 114 128 / var(--tw-text-opacity, 1));
}

.disabled\\:opacity-30:disabled {
  opacity: 0.3;
}

.disabled\\:opacity-40:disabled {
  opacity: 0.4;
}

.disabled\\:opacity-50:disabled {
  opacity: 0.5;
}

.disabled\\:opacity-60:disabled {
  opacity: 0.6;
}

.disabled\\:opacity-70:disabled {
  opacity: 0.7;
}

.disabled\\:hover\\:bg-neutral-500:hover:disabled {
  --tw-bg-opacity: 1;
  background-color: rgb(115 115 115 / var(--tw-bg-opacity, 1));
}

.disabled\\:hover\\:bg-transparent:hover:disabled {
  background-color: transparent;
}

.disabled\\:hover\\:text-gray-400:hover:disabled {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}

.disabled\\:hover\\:text-neutral-400:hover:disabled {
  --tw-text-opacity: 1;
  color: rgb(163 163 163 / var(--tw-text-opacity, 1));
}

.group:hover .group-hover\\:text-neutral-600 {
  --tw-text-opacity: 1;
  color: rgb(82 82 82 / var(--tw-text-opacity, 1));
}

.group:hover .group-hover\\:text-neutral-900 {
  --tw-text-opacity: 1;
  color: rgb(23 23 23 / var(--tw-text-opacity, 1));
}

.group\\/badge:hover .group-hover\\/badge\\:opacity-100 {
  opacity: 1;
}

.group\\/fld:hover .group-hover\\/fld\\:opacity-100 {
  opacity: 1;
}

.group\\/link:hover .group-hover\\/link\\:opacity-100 {
  opacity: 1;
}

.group\\/row:hover .group-hover\\/row\\:opacity-100 {
  opacity: 1;
}

.group\\/src:hover .group-hover\\/src\\:opacity-100 {
  opacity: 1;
}

.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}

.group:hover .group-hover\\:opacity-50 {
  opacity: 0.5;
}

.data-\\[focus\\]\\:bg-gray-900[data-focus] {
  --tw-bg-opacity: 1;
  background-color: rgb(17 24 39 / var(--tw-bg-opacity, 1));
}

.data-\\[selected\\]\\:bg-white[data-selected] {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
}

.data-\\[focus\\]\\:text-white[data-focus] {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}

.data-\\[selected\\]\\:text-gray-900[data-selected] {
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity, 1));
}

.data-\\[selected\\]\\:text-neutral-900[data-selected] {
  --tw-text-opacity: 1;
  color: rgb(23 23 23 / var(--tw-text-opacity, 1));
}

.data-\\[selected\\]\\:shadow-sm[data-selected] {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.prose-headings\\:mb-1 :is(:where(h1, h2, h3, h4, h5, h6, th):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  margin-bottom: 0.25rem;
}

.prose-headings\\:mt-3 :is(:where(h1, h2, h3, h4, h5, h6, th):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  margin-top: 0.75rem;
}

.prose-p\\:my-1 :is(:where(p):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  margin-top: 0.25rem;
  margin-bottom: 0.25rem;
}

.prose-p\\:text-xs :is(:where(p):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.prose-a\\:text-blue-600 :is(:where(a):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  --tw-text-opacity: 1;
  color: rgb(37 99 235 / var(--tw-text-opacity, 1));
}

.prose-blockquote\\:text-xs :is(:where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.prose-code\\:text-xs :is(:where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.prose-pre\\:text-xs :is(:where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.prose-li\\:text-xs :is(:where(li):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.prose-th\\:text-xs :is(:where(th):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.prose-td\\:text-xs :is(:where(td):not(:where([class~="not-prose"],[class~="not-prose"] *))) {
  font-size: 0.75rem;
  line-height: 1rem;
}

.dark\\:divide-neutral-700:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(64 64 64 / var(--tw-divide-opacity, 1));
}

.dark\\:divide-slate-700:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(51 65 85 / var(--tw-divide-opacity, 1));
}

.dark\\:divide-slate-800:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(30 41 59 / var(--tw-divide-opacity, 1));
}

.dark\\:border-amber-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(146 64 14 / var(--tw-border-opacity, 1));
}

.dark\\:border-amber-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(120 53 15 / var(--tw-border-opacity, 1));
}

.dark\\:border-blue-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(37 99 235 / var(--tw-border-opacity, 1));
}

.dark\\:border-blue-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(29 78 216 / var(--tw-border-opacity, 1));
}

.dark\\:border-blue-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(30 64 175 / var(--tw-border-opacity, 1));
}

.dark\\:border-blue-800\\/50:is(.dark *) {
  border-color: rgb(30 64 175 / 0.5);
}

.dark\\:border-blue-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(30 58 138 / var(--tw-border-opacity, 1));
}

.dark\\:border-emerald-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(6 95 70 / var(--tw-border-opacity, 1));
}

.dark\\:border-gray-500:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(107 114 128 / var(--tw-border-opacity, 1));
}

.dark\\:border-gray-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(75 85 99 / var(--tw-border-opacity, 1));
}

.dark\\:border-green-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 163 74 / var(--tw-border-opacity, 1));
}

.dark\\:border-green-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(21 128 61 / var(--tw-border-opacity, 1));
}

.dark\\:border-green-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(22 101 52 / var(--tw-border-opacity, 1));
}

.dark\\:border-green-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(20 83 45 / var(--tw-border-opacity, 1));
}

.dark\\:border-indigo-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(79 70 229 / var(--tw-border-opacity, 1));
}

.dark\\:border-indigo-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(67 56 202 / var(--tw-border-opacity, 1));
}

.dark\\:border-indigo-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(55 48 163 / var(--tw-border-opacity, 1));
}

.dark\\:border-neutral-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(82 82 82 / var(--tw-border-opacity, 1));
}

.dark\\:border-neutral-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(64 64 64 / var(--tw-border-opacity, 1));
}

.dark\\:border-orange-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(234 88 12 / var(--tw-border-opacity, 1));
}

.dark\\:border-orange-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(194 65 12 / var(--tw-border-opacity, 1));
}

.dark\\:border-pink-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(219 39 119 / var(--tw-border-opacity, 1));
}

.dark\\:border-pink-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(190 24 93 / var(--tw-border-opacity, 1));
}

.dark\\:border-purple-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(147 51 234 / var(--tw-border-opacity, 1));
}

.dark\\:border-purple-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(126 34 206 / var(--tw-border-opacity, 1));
}

.dark\\:border-red-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(220 38 38 / var(--tw-border-opacity, 1));
}

.dark\\:border-red-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(185 28 28 / var(--tw-border-opacity, 1));
}

.dark\\:border-red-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(153 27 27 / var(--tw-border-opacity, 1));
}

.dark\\:border-red-900:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(127 29 29 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-100:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(241 245 249 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-200:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(226 232 240 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(203 213 225 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-400:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(148 163 184 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-500:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(100 116 139 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(71 85 105 / var(--tw-border-opacity, 1));
}

.dark\\:border-slate-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(51 65 85 / var(--tw-border-opacity, 1));
}

.dark\\:border-teal-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(13 148 136 / var(--tw-border-opacity, 1));
}

.dark\\:border-teal-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(15 118 110 / var(--tw-border-opacity, 1));
}

.dark\\:border-yellow-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(202 138 4 / var(--tw-border-opacity, 1));
}

.dark\\:border-yellow-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(161 98 7 / var(--tw-border-opacity, 1));
}

.dark\\:border-l-green-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-left-color: rgb(22 163 74 / var(--tw-border-opacity, 1));
}

.dark\\:border-l-red-600:is(.dark *) {
  --tw-border-opacity: 1;
  border-left-color: rgb(220 38 38 / var(--tw-border-opacity, 1));
}

.dark\\:bg-amber-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(120 53 15 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-amber-900\\/20:is(.dark *) {
  background-color: rgb(120 53 15 / 0.2);
}

.dark\\:bg-amber-900\\/40:is(.dark *) {
  background-color: rgb(120 53 15 / 0.4);
}

.dark\\:bg-amber-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(69 26 3 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-amber-950\\/40:is(.dark *) {
  background-color: rgb(69 26 3 / 0.4);
}

.dark\\:bg-blue-400:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(96 165 250 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-blue-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 58 138 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-blue-900\\/40:is(.dark *) {
  background-color: rgb(30 58 138 / 0.4);
}

.dark\\:bg-blue-900\\/60:is(.dark *) {
  background-color: rgb(30 58 138 / 0.6);
}

.dark\\:bg-blue-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(23 37 84 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-blue-950\\/20:is(.dark *) {
  background-color: rgb(23 37 84 / 0.2);
}

.dark\\:bg-blue-950\\/30:is(.dark *) {
  background-color: rgb(23 37 84 / 0.3);
}

.dark\\:bg-cyan-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(8 51 68 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-emerald-800:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(6 95 70 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-emerald-900\\/30:is(.dark *) {
  background-color: rgb(6 78 59 / 0.3);
}

.dark\\:bg-emerald-900\\/40:is(.dark *) {
  background-color: rgb(6 78 59 / 0.4);
}

.dark\\:bg-emerald-950\\/30:is(.dark *) {
  background-color: rgb(2 44 34 / 0.3);
}

.dark\\:bg-gray-100:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-gray-600:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(75 85 99 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-gray-700:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(55 65 81 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-gray-800:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(31 41 55 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-gray-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(17 24 39 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-green-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(20 83 45 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-green-900\\/30:is(.dark *) {
  background-color: rgb(20 83 45 / 0.3);
}

.dark\\:bg-green-900\\/40:is(.dark *) {
  background-color: rgb(20 83 45 / 0.4);
}

.dark\\:bg-green-900\\/60:is(.dark *) {
  background-color: rgb(20 83 45 / 0.6);
}

.dark\\:bg-green-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(5 46 22 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-indigo-900\\/40:is(.dark *) {
  background-color: rgb(49 46 129 / 0.4);
}

.dark\\:bg-indigo-900\\/60:is(.dark *) {
  background-color: rgb(49 46 129 / 0.6);
}

.dark\\:bg-indigo-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 27 75 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-indigo-950\\/40:is(.dark *) {
  background-color: rgb(30 27 75 / 0.4);
}

.dark\\:bg-neutral-600:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(82 82 82 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-neutral-700:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(64 64 64 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-orange-900\\/40:is(.dark *) {
  background-color: rgb(124 45 18 / 0.4);
}

.dark\\:bg-orange-900\\/60:is(.dark *) {
  background-color: rgb(124 45 18 / 0.6);
}

.dark\\:bg-orange-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(67 20 7 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-pink-900\\/40:is(.dark *) {
  background-color: rgb(131 24 67 / 0.4);
}

.dark\\:bg-pink-900\\/60:is(.dark *) {
  background-color: rgb(131 24 67 / 0.6);
}

.dark\\:bg-pink-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(80 7 36 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-purple-900\\/40:is(.dark *) {
  background-color: rgb(88 28 135 / 0.4);
}

.dark\\:bg-purple-900\\/60:is(.dark *) {
  background-color: rgb(88 28 135 / 0.6);
}

.dark\\:bg-purple-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(59 7 100 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-red-900\\/40:is(.dark *) {
  background-color: rgb(127 29 29 / 0.4);
}

.dark\\:bg-red-900\\/60:is(.dark *) {
  background-color: rgb(127 29 29 / 0.6);
}

.dark\\:bg-red-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(69 10 10 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-rose-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(76 5 25 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(226 232 240 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-400:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(148 163 184 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-500:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(100 116 139 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-600:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(71 85 105 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-700:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(51 65 85 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-700\\/30:is(.dark *) {
  background-color: rgb(51 65 85 / 0.3);
}

.dark\\:bg-slate-700\\/50:is(.dark *) {
  background-color: rgb(51 65 85 / 0.5);
}

.dark\\:bg-slate-800:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 41 59 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-slate-800\\/50:is(.dark *) {
  background-color: rgb(30 41 59 / 0.5);
}

.dark\\:bg-slate-800\\/60:is(.dark *) {
  background-color: rgb(30 41 59 / 0.6);
}

.dark\\:bg-slate-800\\/80:is(.dark *) {
  background-color: rgb(30 41 59 / 0.8);
}

.dark\\:bg-slate-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(15 23 42 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-teal-900\\/40:is(.dark *) {
  background-color: rgb(19 78 74 / 0.4);
}

.dark\\:bg-teal-900\\/60:is(.dark *) {
  background-color: rgb(19 78 74 / 0.6);
}

.dark\\:bg-teal-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(4 47 46 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-violet-950:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(46 16 101 / var(--tw-bg-opacity, 1));
}

.dark\\:bg-yellow-900\\/40:is(.dark *) {
  background-color: rgb(113 63 18 / 0.4);
}

.dark\\:bg-yellow-900\\/50:is(.dark *) {
  background-color: rgb(113 63 18 / 0.5);
}

.dark\\:bg-yellow-900\\/60:is(.dark *) {
  background-color: rgb(113 63 18 / 0.6);
}

.dark\\:text-amber-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 243 199 / var(--tw-text-opacity, 1));
}

.dark\\:text-amber-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 230 138 / var(--tw-text-opacity, 1));
}

.dark\\:text-amber-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}

.dark\\:text-amber-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(251 191 36 / var(--tw-text-opacity, 1));
}

.dark\\:text-blue-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(219 234 254 / var(--tw-text-opacity, 1));
}

.dark\\:text-blue-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(191 219 254 / var(--tw-text-opacity, 1));
}

.dark\\:text-blue-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}

.dark\\:text-blue-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}

.dark\\:text-blue-400\\/70:is(.dark *) {
  color: rgb(96 165 250 / 0.7);
}

.dark\\:text-cyan-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(103 232 249 / var(--tw-text-opacity, 1));
}

.dark\\:text-emerald-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(209 250 229 / var(--tw-text-opacity, 1));
}

.dark\\:text-emerald-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(110 231 183 / var(--tw-text-opacity, 1));
}

.dark\\:text-emerald-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(52 211 153 / var(--tw-text-opacity, 1));
}

.dark\\:text-gray-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(243 244 246 / var(--tw-text-opacity, 1));
}

.dark\\:text-gray-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(229 231 235 / var(--tw-text-opacity, 1));
}

.dark\\:text-gray-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(209 213 219 / var(--tw-text-opacity, 1));
}

.dark\\:text-gray-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(156 163 175 / var(--tw-text-opacity, 1));
}

.dark\\:text-gray-900:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(17 24 39 / var(--tw-text-opacity, 1));
}

.dark\\:text-green-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(220 252 231 / var(--tw-text-opacity, 1));
}

.dark\\:text-green-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(187 247 208 / var(--tw-text-opacity, 1));
}

.dark\\:text-green-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(134 239 172 / var(--tw-text-opacity, 1));
}

.dark\\:text-green-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}

.dark\\:text-indigo-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(199 210 254 / var(--tw-text-opacity, 1));
}

.dark\\:text-indigo-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(165 180 252 / var(--tw-text-opacity, 1));
}

.dark\\:text-indigo-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(129 140 248 / var(--tw-text-opacity, 1));
}

.dark\\:text-neutral-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(245 245 245 / var(--tw-text-opacity, 1));
}

.dark\\:text-neutral-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(229 229 229 / var(--tw-text-opacity, 1));
}

.dark\\:text-neutral-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(212 212 212 / var(--tw-text-opacity, 1));
}

.dark\\:text-neutral-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(163 163 163 / var(--tw-text-opacity, 1));
}

.dark\\:text-neutral-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(115 115 115 / var(--tw-text-opacity, 1));
}

.dark\\:text-orange-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 215 170 / var(--tw-text-opacity, 1));
}

.dark\\:text-orange-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 186 116 / var(--tw-text-opacity, 1));
}

.dark\\:text-pink-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(251 207 232 / var(--tw-text-opacity, 1));
}

.dark\\:text-pink-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(249 168 212 / var(--tw-text-opacity, 1));
}

.dark\\:text-purple-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(233 213 255 / var(--tw-text-opacity, 1));
}

.dark\\:text-purple-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(216 180 254 / var(--tw-text-opacity, 1));
}

.dark\\:text-red-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 202 202 / var(--tw-text-opacity, 1));
}

.dark\\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}

.dark\\:text-red-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}

.dark\\:text-red-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}

.dark\\:text-rose-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 164 175 / var(--tw-text-opacity, 1));
}

.dark\\:text-sky-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(56 189 248 / var(--tw-text-opacity, 1));
}

.dark\\:text-slate-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(241 245 249 / var(--tw-text-opacity, 1));
}

.dark\\:text-slate-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(226 232 240 / var(--tw-text-opacity, 1));
}

.dark\\:text-slate-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(203 213 225 / var(--tw-text-opacity, 1));
}

.dark\\:text-slate-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(148 163 184 / var(--tw-text-opacity, 1));
}

.dark\\:text-slate-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(100 116 139 / var(--tw-text-opacity, 1));
}

.dark\\:text-slate-600:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(71 85 105 / var(--tw-text-opacity, 1));
}

.dark\\:text-teal-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(153 246 228 / var(--tw-text-opacity, 1));
}

.dark\\:text-teal-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(94 234 212 / var(--tw-text-opacity, 1));
}

.dark\\:text-violet-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(196 181 253 / var(--tw-text-opacity, 1));
}

.dark\\:text-yellow-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(254 240 138 / var(--tw-text-opacity, 1));
}

.dark\\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}

.dark\\:placeholder-slate-500:is(.dark *)::-moz-placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(100 116 139 / var(--tw-placeholder-opacity, 1));
}

.dark\\:placeholder-slate-500:is(.dark *)::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(100 116 139 / var(--tw-placeholder-opacity, 1));
}

.dark\\:accent-gray-100:is(.dark *) {
  accent-color: #f3f4f6;
}

.dark\\:shadow-slate-900\\/30:is(.dark *) {
  --tw-shadow-color: rgb(15 23 42 / 0.3);
  --tw-shadow: var(--tw-shadow-colored);
}

.dark\\:shadow-slate-900\\/50:is(.dark *) {
  --tw-shadow-color: rgb(15 23 42 / 0.5);
  --tw-shadow: var(--tw-shadow-colored);
}

.dark\\:ring-slate-300:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(203 213 225 / var(--tw-ring-opacity, 1));
}

.dark\\:ring-slate-600:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(71 85 105 / var(--tw-ring-opacity, 1));
}

.dark\\:ring-slate-700:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(51 65 85 / var(--tw-ring-opacity, 1));
}

.dark\\:file\\:bg-slate-700:is(.dark *)::file-selector-button {
  --tw-bg-opacity: 1;
  background-color: rgb(51 65 85 / var(--tw-bg-opacity, 1));
}

.file\\:dark\\:bg-slate-700:is(.dark *)::file-selector-button {
  --tw-bg-opacity: 1;
  background-color: rgb(51 65 85 / var(--tw-bg-opacity, 1));
}

.dark\\:file\\:text-slate-300:is(.dark *)::file-selector-button {
  --tw-text-opacity: 1;
  color: rgb(203 213 225 / var(--tw-text-opacity, 1));
}

.file\\:dark\\:text-neutral-300:is(.dark *)::file-selector-button {
  --tw-text-opacity: 1;
  color: rgb(212 212 212 / var(--tw-text-opacity, 1));
}

.dark\\:placeholder\\:text-slate-500:is(.dark *)::-moz-placeholder {
  --tw-text-opacity: 1;
  color: rgb(100 116 139 / var(--tw-text-opacity, 1));
}

.dark\\:placeholder\\:text-slate-500:is(.dark *)::placeholder {
  --tw-text-opacity: 1;
  color: rgb(100 116 139 / var(--tw-text-opacity, 1));
}

.dark\\:even\\:bg-slate-800\\/50:nth-child(even):is(.dark *) {
  background-color: rgb(30 41 59 / 0.5);
}

.dark\\:even\\:bg-slate-900\\/50:nth-child(even):is(.dark *) {
  background-color: rgb(15 23 42 / 0.5);
}

.dark\\:hover\\:border-gray-500:hover:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(107 114 128 / var(--tw-border-opacity, 1));
}

.dark\\:hover\\:border-slate-500:hover:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(100 116 139 / var(--tw-border-opacity, 1));
}

.dark\\:hover\\:border-slate-600:hover:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(71 85 105 / var(--tw-border-opacity, 1));
}

.dark\\:hover\\:bg-amber-950:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(69 26 3 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-blue-500:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(59 130 246 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-blue-900:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 58 138 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-blue-950:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(23 37 84 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-blue-950\\/50:hover:is(.dark *) {
  background-color: rgb(23 37 84 / 0.5);
}

.dark\\:hover\\:bg-emerald-800\\/40:hover:is(.dark *) {
  background-color: rgb(6 95 70 / 0.4);
}

.dark\\:hover\\:bg-emerald-900\\/30:hover:is(.dark *) {
  background-color: rgb(6 78 59 / 0.3);
}

.dark\\:hover\\:bg-emerald-900\\/50:hover:is(.dark *) {
  background-color: rgb(6 78 59 / 0.5);
}

.dark\\:hover\\:bg-gray-200:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(229 231 235 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-green-900:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(20 83 45 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-green-950:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(5 46 22 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-red-950:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(69 10 10 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-slate-500:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(100 116 139 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-slate-600:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(71 85 105 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-slate-600\\/40:hover:is(.dark *) {
  background-color: rgb(71 85 105 / 0.4);
}

.dark\\:hover\\:bg-slate-700:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(51 65 85 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-slate-700\\/40:hover:is(.dark *) {
  background-color: rgb(51 65 85 / 0.4);
}

.dark\\:hover\\:bg-slate-700\\/50:hover:is(.dark *) {
  background-color: rgb(51 65 85 / 0.5);
}

.dark\\:hover\\:bg-slate-800:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 41 59 / var(--tw-bg-opacity, 1));
}

.dark\\:hover\\:bg-white\\/10:hover:is(.dark *) {
  background-color: rgb(255 255 255 / 0.1);
}

.dark\\:hover\\:text-amber-300:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 211 77 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-amber-400:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(251 191 36 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-blue-100:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(219 234 254 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-blue-300:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-blue-400:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-emerald-300:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(110 231 183 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-green-400:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-neutral-100:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(245 245 245 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-neutral-200:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(229 229 229 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-neutral-300:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(212 212 212 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-red-300:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-red-400:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-slate-100:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(241 245 249 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-slate-200:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(226 232 240 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:text-slate-300:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(203 213 225 / var(--tw-text-opacity, 1));
}

.dark\\:hover\\:brightness-110:hover:is(.dark *) {
  --tw-brightness: brightness(1.1);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.dark\\:hover\\:file\\:bg-slate-600:is(.dark *)::file-selector-button:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(71 85 105 / var(--tw-bg-opacity, 1));
}

.dark\\:focus\\:border-gray-100:focus:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(243 244 246 / var(--tw-border-opacity, 1));
}

.dark\\:focus\\:border-slate-400:focus:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(148 163 184 / var(--tw-border-opacity, 1));
}

.dark\\:focus\\:ring-blue-400:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(96 165 250 / var(--tw-ring-opacity, 1));
}

.dark\\:focus\\:ring-emerald-600:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(5 150 105 / var(--tw-ring-opacity, 1));
}

.dark\\:focus\\:ring-gray-100:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(243 244 246 / var(--tw-ring-opacity, 1));
}

.dark\\:focus\\:ring-slate-100:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(241 245 249 / var(--tw-ring-opacity, 1));
}

.dark\\:focus\\:ring-slate-400:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(148 163 184 / var(--tw-ring-opacity, 1));
}

.dark\\:focus\\:ring-slate-400\\/20:focus:is(.dark *) {
  --tw-ring-color: rgb(148 163 184 / 0.2);
}

.dark\\:focus\\:ring-slate-600:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(71 85 105 / var(--tw-ring-opacity, 1));
}

.dark\\:active\\:bg-emerald-500:active:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(16 185 129 / var(--tw-bg-opacity, 1));
}

.dark\\:active\\:bg-slate-500:active:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(100 116 139 / var(--tw-bg-opacity, 1));
}

.dark\\:active\\:bg-slate-600:active:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(71 85 105 / var(--tw-bg-opacity, 1));
}

.dark\\:disabled\\:bg-slate-800:disabled:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 41 59 / var(--tw-bg-opacity, 1));
}

.dark\\:disabled\\:bg-slate-900:disabled:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(15 23 42 / var(--tw-bg-opacity, 1));
}

.dark\\:disabled\\:text-slate-500:disabled:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(100 116 139 / var(--tw-text-opacity, 1));
}

.group:hover .dark\\:group-hover\\:text-slate-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(241 245 249 / var(--tw-text-opacity, 1));
}

.group:hover .dark\\:group-hover\\:text-slate-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(203 213 225 / var(--tw-text-opacity, 1));
}

.dark\\:data-\\[focus\\]\\:bg-slate-600[data-focus]:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(71 85 105 / var(--tw-bg-opacity, 1));
}

.dark\\:data-\\[selected\\]\\:bg-slate-800[data-selected]:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(30 41 59 / var(--tw-bg-opacity, 1));
}

.dark\\:data-\\[selected\\]\\:text-slate-100[data-selected]:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(241 245 249 / var(--tw-text-opacity, 1));
}

.dark\\:data-\\[selected\\]\\:shadow-slate-900\\/30[data-selected]:is(.dark *) {
  --tw-shadow-color: rgb(15 23 42 / 0.3);
  --tw-shadow: var(--tw-shadow-colored);
}

.dark\\:prose-a\\:text-blue-400 :is(:where(a):not(:where([class~="not-prose"],[class~="not-prose"] *))):is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}

@media (min-width: 480px) {
  .min-\\[480px\\]\\:inline {
    display: inline;
  }

  .min-\\[480px\\]\\:justify-start {
    justify-content: flex-start;
  }

  .min-\\[480px\\]\\:gap-1 {
    gap: 0.25rem;
  }

  .min-\\[480px\\]\\:px-2 {
    padding-left: 0.5rem;
    padding-right: 0.5rem;
  }

  .min-\\[480px\\]\\:py-1\\.5 {
    padding-top: 0.375rem;
    padding-bottom: 0.375rem;
  }
}

@media (min-width: 640px) {
  .sm\\:block {
    display: block;
  }

  .sm\\:inline {
    display: inline;
  }

  .sm\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .sm\\:flex-row {
    flex-direction: row;
  }

  .sm\\:items-center {
    align-items: center;
  }

  .sm\\:justify-between {
    justify-content: space-between;
  }
}

@media (min-width: 1024px) {
  .lg\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}
`, q = /* @__PURE__ */ new Map();
  function gn(e) {
    const r = q.get(e);
    if (r) {
      try {
        r.element.isConnected && (H.unmountComponentAtNode(r.container), r.element.remove());
      } catch (t) {
        console.warn("Cleanup failed for", e, t);
      }
      q.delete(e);
    } else {
      const t = document.getElementById(e);
      t && t.remove();
    }
  }
  const hn = document.createElement("div");
  hn.id = "notebooklm-tools-root";
  document.body.append(hn);
  const Pn = hn.attachShadow({
    mode: "open"
  }), Dn = document.createElement("div");
  Pn.appendChild(Dn);
  const Fn = document.createElement("style");
  Fn.textContent = Z;
  Pn.appendChild(Fn);
  H.render(n.jsx(K.StrictMode, {
    children: n.jsx(Pt, {})
  }), Dn);
  let Rn = false;
  function Xt() {
    const e = document.querySelector("notebook-header") || document.querySelector('[class*="notebook-header"]');
    return e || (window.location.pathname.match(/\/notebook\//) && !Rn && (Rn = true, console.warn("[NLM Tools] notebook-header not found \u2014 toolbar not injected")), null);
  }
  function _n() {
    const e = Xt();
    if (!e || document.getElementById("notebooklm-tags-root"))
      return;
    const r = document.createElement("div");
    r.id = "notebooklm-tags-root", e.after(r);
    const t = r.attachShadow({
      mode: "open"
    }), o = document.createElement("div");
    t.appendChild(o);
    const l = document.createElement("style");
    l.textContent = Z, t.appendChild(l), H.render(n.jsx(K.StrictMode, {
      children: n.jsx(Ut, {})
    }), o), q.set("notebooklm-tags-root", {
      element: r,
      container: o
    });
  }
  function Un() {
    document.querySelectorAll("project-button").forEach((r) => {
      var _a;
      if (r.querySelector(".notebooklm-card-tags"))
        return;
      const t = r.querySelector('[id^="project-"][id$="-title"]');
      if (!t)
        return;
      const o = (_a = t.id.match(/project-(.+)-title/)) == null ? void 0 : _a[1];
      if (!o)
        return;
      const l = document.createElement("div");
      l.className = "notebooklm-card-tags", l.dataset.notebookId = o, r.appendChild(l);
      const m = l.attachShadow({
        mode: "open"
      }), v = document.createElement("div");
      m.appendChild(v);
      const i = document.createElement("style");
      i.textContent = Z, m.appendChild(i);
      const y = `notebooklm-card-tags-${o}`;
      H.render(n.jsx(K.StrictMode, {
        children: n.jsx(Bt, {
          notebookId: o
        })
      }), v), q.set(y, {
        element: l,
        container: v
      });
    });
  }
  function Bn() {
    if (window.location.pathname.match(/\/notebook\//) || document.getElementById("notebooklm-all-tags-bar-root"))
      return;
    const e = document.querySelector(".project-actions-container");
    if (!e)
      return;
    const r = document.createElement("div");
    r.id = "notebooklm-all-tags-bar-root", e.parentNode.insertBefore(r, e);
    const t = r.attachShadow({
      mode: "open"
    }), o = document.createElement("div");
    t.appendChild(o);
    const l = document.createElement("style");
    l.textContent = Z, t.appendChild(l), H.render(n.jsx(K.StrictMode, {
      children: n.jsx($t, {})
    }), o), q.set("notebooklm-all-tags-bar-root", {
      element: r,
      container: o
    });
  }
  function Wt() {
    if (document.getElementById("notebooklm-prompts-root"))
      return;
    const e = document.createElement("div");
    e.id = "notebooklm-prompts-root", e.setAttribute("popover", "manual"), document.body.append(e);
    const r = e.attachShadow({
      mode: "open"
    }), t = document.createElement("div");
    r.appendChild(t);
    const o = document.createElement("style");
    o.textContent = Z, r.appendChild(o), H.render(n.jsx(K.StrictMode, {
      children: n.jsx(Tt, {
        children: n.jsx(Gt, {
          hostElement: e
        })
      })
    }), t), q.set("notebooklm-prompts-root", {
      element: e,
      container: t
    });
  }
  _n();
  Un();
  Bn();
  let pn = false;
  const Kt = new MutationObserver(() => {
    pn || (pn = true, requestAnimationFrame(() => {
      pn = false, window.location.pathname.match(/\/notebook\/([a-f0-9-]+)/i) ? (_n(), Wt(), gn("notebooklm-all-tags-bar-root")) : (gn("notebooklm-tags-root"), gn("notebooklm-prompts-root"), Un(), Bn());
    }));
  });
  Kt.observe(document.body, {
    childList: true,
    subtree: true
  });
});
