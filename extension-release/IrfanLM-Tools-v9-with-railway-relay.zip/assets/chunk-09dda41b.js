import { r as y, j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { u as j, __tla as __tla_1 } from "./chunk-93ad41a0.js";
import { P as b, __tla as __tla_2 } from "./chunk-cfcef7af.js";
import { P as k, __tla as __tla_3 } from "./chunk-2a4ab792.js";
import { A as N, __tla as __tla_4 } from "./chunk-57988b21.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let D;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  D = function({ content: s, artifact: a }) {
    var _a;
    const l = y.useRef(null), { isPlaying: i, playbackRate: n, progress: c, formattedTime: x, formattedDuration: u, toggle: m, seek: p, cycleSpeed: f } = j(l), o = (s == null ? void 0 : s.audioUrl) || (a == null ? void 0 : a.audioUrl), d = (s == null ? void 0 : s.downloadUrl) || (a == null ? void 0 : a.downloadUrl);
    if (!o)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "No audio URL available."
      });
    const h = (t) => {
      const r = t.currentTarget.getBoundingClientRect(), g = t.clientX - r.left;
      p(g / r.width);
    };
    return e.jsxs("div", {
      className: "space-y-2",
      children: [
        e.jsxs("audio", {
          ref: l,
          preload: "metadata",
          className: "hidden",
          children: [
            e.jsx("source", {
              src: o,
              type: "audio/mpeg"
            }),
            (_a = s == null ? void 0 : s.urls) == null ? void 0 : _a.map((t, r) => e.jsx("source", {
              src: t.url,
              type: t.format ? `audio/${t.format}` : void 0
            }, r))
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("button", {
              type: "button",
              onClick: m,
              className: "flex items-center justify-center w-7 h-7 rounded-full bg-blue-500 text-white hover:bg-blue-600 shrink-0",
              children: i ? e.jsx(b, {
                className: "w-4 h-4"
              }) : e.jsx(k, {
                className: "w-4 h-4"
              })
            }),
            e.jsx("div", {
              className: "flex-1 bg-gray-200 dark:bg-slate-700 h-1 rounded-full cursor-pointer",
              onClick: h,
              children: e.jsx("div", {
                className: "bg-blue-500 h-full rounded-full",
                style: {
                  width: `${c}%`
                }
              })
            }),
            e.jsxs("span", {
              className: "text-xs text-gray-500 dark:text-slate-400 shrink-0",
              children: [
                x,
                " / ",
                u
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            e.jsxs("button", {
              type: "button",
              onClick: f,
              className: "bg-gray-100 dark:bg-slate-700 text-xs px-1.5 py-0.5 rounded text-gray-700 dark:text-slate-300",
              children: [
                n,
                "x"
              ]
            }),
            d && e.jsx("a", {
              href: d,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200",
              children: e.jsx(N, {
                className: "w-4 h-4"
              })
            })
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  D as default
};
