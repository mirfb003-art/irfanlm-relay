import { r as m, j as e, u as L, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as O, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { P as A, L as k, __tla as __tla_2 } from "./chunk-abc94b21.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_3 } from "./chunk-1784b260.js";
import { __tla as __tla_4 } from "./chunk-2a4ab792.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let H;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  function E({ selected: r, correct: l, wrong: t }) {
    return l ? e.jsx("svg", {
      className: "w-4 h-4 flex-shrink-0 text-green-600 dark:text-green-400",
      fill: "currentColor",
      viewBox: "0 0 20 20",
      children: e.jsx("path", {
        fillRule: "evenodd",
        d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
        clipRule: "evenodd"
      })
    }) : t ? e.jsx("svg", {
      className: "w-4 h-4 flex-shrink-0 text-red-600 dark:text-red-400",
      fill: "none",
      viewBox: "0 0 20 20",
      stroke: "currentColor",
      strokeWidth: "2",
      children: e.jsx("path", {
        d: "M6 6l8 8M14 6l-8 8"
      })
    }) : e.jsx("span", {
      className: `w-4 h-4 rounded-full border-2 flex-shrink-0 flex items-center justify-center ${r ? "border-blue-500 bg-blue-500" : "border-gray-300 dark:border-slate-500"}`,
      children: r && e.jsx("span", {
        className: "w-1.5 h-1.5 rounded-full bg-white"
      })
    });
  }
  function M({ questions: r, onReviewAll: l }) {
    var _a, _b;
    const [t, d] = m.useState(0), [i, u] = m.useState(null), [o, f] = m.useState(false), [c, b] = m.useState({});
    if (!(r == null ? void 0 : r.length))
      return null;
    const x = r.length, v = Object.keys(c).length, w = v === x && t >= x, a = m.useCallback((n) => {
      d(n);
      const s = c[n];
      s ? (u(s.selected), f(true)) : (u(null), f(false));
    }, [
      c
    ]);
    m.useEffect(() => {
      const n = (s) => {
        [
          "INPUT",
          "TEXTAREA"
        ].includes(s.target.tagName) || (s.key === "ArrowLeft" && t > 0 && a(t - 1), s.key === "ArrowRight" && t < x && a(t + 1));
      };
      return window.addEventListener("keydown", n), () => window.removeEventListener("keydown", n);
    }, [
      t,
      x,
      a
    ]);
    const N = () => {
      var _a2;
      const s = (_a2 = r[t].answerOptions) == null ? void 0 : _a2.findIndex((h) => h.isCorrect);
      f(true), b((h) => ({
        ...h,
        [t]: {
          selected: i,
          correct: i === s
        }
      }));
    }, j = () => a(t + 1), p = () => a(t - 1), z = () => {
      d(0), u(null), f(false), b({});
    };
    if (w) {
      const n = Object.values(c).filter((C) => C.correct).length, s = Math.round(n / x * 100), h = s > 70 ? "text-green-600 dark:text-green-400" : s > 40 ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400";
      return e.jsxs("div", {
        className: "text-center py-6 space-y-3",
        children: [
          e.jsxs("p", {
            className: `text-sm font-semibold ${h}`,
            children: [
              "Score: ",
              n,
              " / ",
              x,
              " (",
              s,
              "%)"
            ]
          }),
          e.jsxs("div", {
            className: "flex items-center justify-center gap-2",
            children: [
              e.jsx("button", {
                onClick: z,
                className: "px-3 py-1.5 text-xs font-medium text-white bg-purple-600 rounded-md hover:bg-purple-700",
                children: "Try again"
              }),
              e.jsx("button", {
                onClick: l,
                className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                children: "Review all"
              })
            ]
          })
        ]
      });
    }
    const g = r[t];
    if (!g)
      return null;
    const R = (_a = g.answerOptions) == null ? void 0 : _a.findIndex((n) => n.isCorrect);
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsx(A, {
          value: v,
          max: x,
          color: "bg-purple-500"
        }),
        e.jsxs("div", {
          className: "border-l-4 border-purple-500 rounded-lg p-4 bg-white dark:bg-slate-800",
          children: [
            e.jsxs("p", {
              className: "text-[10px] text-gray-400 dark:text-slate-500 mb-1",
              children: [
                "Question ",
                t + 1,
                " of ",
                x
              ]
            }),
            e.jsx("p", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100",
              children: e.jsx(k, {
                children: g.question
              })
            })
          ]
        }),
        e.jsx("div", {
          className: "space-y-2",
          children: (_b = g.answerOptions) == null ? void 0 : _b.map((n, s) => {
            const h = i === s, C = s === R, S = o && h && !C, Q = o && C;
            let y = "w-full text-left flex items-center gap-2 border rounded-lg p-3 text-xs";
            return o ? Q ? y += " border-green-500 bg-green-50 dark:bg-green-950" : S ? y += " border-red-500 bg-red-50 dark:bg-red-950" : y += " border-gray-200 dark:border-slate-700" : h ? y += " border-blue-500 bg-blue-50 dark:bg-blue-950" : y += " border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700", e.jsxs("button", {
              className: y,
              onClick: () => !o && u(s),
              disabled: o,
              children: [
                e.jsx(E, {
                  selected: h && !o,
                  correct: Q,
                  wrong: S
                }),
                e.jsx("span", {
                  children: e.jsx(k, {
                    children: n.text
                  })
                })
              ]
            }, s);
          })
        }),
        o && g.hint && e.jsx("p", {
          className: "text-[11px] italic text-gray-500 dark:text-slate-400",
          children: e.jsx(k, {
            children: g.hint
          })
        }),
        e.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            e.jsx("button", {
              onClick: p,
              disabled: t === 0,
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed",
              children: "Previous"
            }),
            o ? e.jsx("button", {
              onClick: j,
              className: "px-3 py-1.5 text-xs font-medium text-white bg-purple-600 rounded-md hover:bg-purple-700",
              children: "Next"
            }) : e.jsx("button", {
              onClick: N,
              disabled: i === null,
              className: "px-3 py-1.5 text-xs font-medium text-white bg-purple-600 rounded-md hover:bg-purple-700 disabled:opacity-40 disabled:cursor-not-allowed",
              children: "Check Answer"
            })
          ]
        })
      ]
    });
  }
  function q({ questions: r }) {
    return e.jsx("div", {
      className: "space-y-4",
      children: r.map((l, t) => {
        var _a;
        return e.jsxs("div", {
          className: "border border-gray-200 dark:border-slate-700 rounded-lg p-3",
          children: [
            e.jsxs("p", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100 mb-2",
              children: [
                "Question ",
                t + 1,
                " of ",
                r.length,
                ": ",
                e.jsx(k, {
                  children: l.question
                })
              ]
            }),
            e.jsx("div", {
              className: "space-y-1.5",
              children: (_a = l.answerOptions) == null ? void 0 : _a.map((d, i) => e.jsxs("div", {
                className: `flex items-start gap-2 px-2 py-1.5 rounded text-xs ${d.isCorrect ? "bg-green-50 dark:bg-green-950 text-green-800 dark:text-green-200" : "text-gray-700 dark:text-slate-300"}`,
                children: [
                  d.isCorrect ? e.jsx("svg", {
                    className: "w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-green-600 dark:text-green-400",
                    fill: "currentColor",
                    viewBox: "0 0 20 20",
                    children: e.jsx("path", {
                      fillRule: "evenodd",
                      d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                      clipRule: "evenodd"
                    })
                  }) : e.jsx("span", {
                    className: "w-3.5 h-3.5 mt-0.5 flex-shrink-0"
                  }),
                  e.jsx("span", {
                    children: e.jsx(k, {
                      children: d.text
                    })
                  })
                ]
              }, i))
            }),
            l.hint && e.jsxs("p", {
              className: "mt-2 text-[11px] italic text-gray-500 dark:text-slate-400",
              children: [
                "Hint: ",
                e.jsx(k, {
                  children: l.hint
                })
              ]
            })
          ]
        }, t);
      })
    });
  }
  function I({ viewMode: r, setViewMode: l }) {
    const t = (d, i) => {
      const u = r === d;
      return e.jsx("button", {
        onClick: () => l(d),
        className: `px-2 py-0.5 text-xs font-medium rounded ${u ? "bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200"}`,
        children: i
      }, d);
    };
    return e.jsxs("div", {
      className: "flex items-center gap-1",
      children: [
        t("study", "Study"),
        t("review", "Review")
      ]
    });
  }
  H = function({ content: r, artifact: l, notebookId: t }) {
    const [d, i] = L(), [u, o] = m.useState("study"), { quizContentMap: f } = d.artifacts, c = l == null ? void 0 : l.id, b = c ? f[c] : null, x = b == null ? void 0 : b.data, v = b == null ? void 0 : b.loading, w = b == null ? void 0 : b.error, a = !!(r == null ? void 0 : r.content);
    m.useEffect(() => {
      !a && c && t && !b && i.fetchQuizContent(c, t);
    }, [
      c,
      t,
      a
    ]);
    const N = x == null ? void 0 : x.quiz;
    let j = null;
    if (a)
      try {
        const g = typeof r.content == "string" ? JSON.parse(r.content) : r.content;
        (g == null ? void 0 : g.quiz) && (j = g.quiz);
      } catch {
      }
    const p = N || j, z = (p == null ? void 0 : p.length) ? `${p.length} Questions` : "Quiz";
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("span", {
              className: "inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200",
              children: z
            }),
            p && e.jsx(I, {
              viewMode: u,
              setViewMode: o
            })
          ]
        }),
        a && !j && e.jsx("p", {
          className: "text-xs text-gray-500 dark:text-slate-400",
          children: "Could not parse quiz content."
        }),
        !a && v && e.jsx("div", {
          className: "flex items-center justify-center py-8",
          children: e.jsx(O, {
            text: "Loading quiz content..."
          })
        }),
        !a && w && e.jsxs("div", {
          className: "text-center py-6 space-y-2",
          children: [
            e.jsxs("p", {
              className: "text-xs text-red-600 dark:text-red-400",
              children: [
                "Failed to load content: ",
                w
              ]
            }),
            e.jsx("button", {
              onClick: () => i.fetchQuizContent(c, t),
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
              children: "Retry"
            })
          ]
        }),
        !a && x && !N && e.jsx("p", {
          className: "text-xs text-gray-500 dark:text-slate-400",
          children: "Could not parse quiz content from the response."
        }),
        p && u === "study" && e.jsx(M, {
          questions: p,
          onReviewAll: () => o("review")
        }),
        p && u === "review" && e.jsx(q, {
          questions: p
        })
      ]
    });
  };
});
export {
  __tla,
  H as default
};
