var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { m as a, j as n, __tla as __tla_0 } from "./chunk-b41980cc.js";
let c, o, d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  o = function(t) {
    if (!Array.isArray(t))
      return [];
    const r = /* @__PURE__ */ new Map();
    for (const s of t) {
      const e = s.category || "Custom";
      r.has(e) || r.set(e, {
        category: e,
        items: []
      }), r.get(e).items.push(s);
    }
    return [
      ...r.values()
    ];
  };
  d = function(t) {
    const r = t.filter((e) => e.pinned), s = t.filter((e) => !e.pinned);
    return {
      pinned: r,
      grouped: o(s)
    };
  };
  c = class extends a.Component {
    constructor() {
      super(...arguments);
      __publicField(this, "state", {
        hasError: false
      });
    }
    static getDerivedStateFromError() {
      return {
        hasError: true
      };
    }
    componentDidCatch(r, s) {
      console.error("ErrorBoundary caught:", r, s);
    }
    render() {
      return this.state.hasError ? n.jsxs("div", {
        className: "flex flex-col items-center justify-center gap-2 rounded border border-dashed border-gray-300 p-4 dark:border-gray-600",
        children: [
          n.jsx("p", {
            className: "text-xs text-gray-500 dark:text-gray-400",
            children: "Something went wrong"
          }),
          n.jsx("button", {
            type: "button",
            className: "text-xs text-blue-600 hover:underline dark:text-blue-400",
            onClick: () => this.setState({
              hasError: false
            }),
            children: "Try Again"
          })
        ]
      }) : this.props.children;
    }
  };
});
export {
  c as E,
  __tla,
  o as g,
  d as s
};
