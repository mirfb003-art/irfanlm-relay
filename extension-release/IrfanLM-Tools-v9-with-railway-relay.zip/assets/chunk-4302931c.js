import { H as r, A as t, c as o, a as s, T as i, __tla as __tla_0 } from "./chunk-2a4ab792.js";
import { j as e, m, __tla as __tla_1 } from "./chunk-b41980cc.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  function p() {
    return e.jsx(r, {
      children: e.jsx(t, {})
    });
  }
  o.createRoot(document.getElementById("app")).render(e.jsx(m.StrictMode, {
    children: e.jsx(s, {
      children: e.jsx(i, {
        children: e.jsx(p, {})
      })
    })
  }));
});
