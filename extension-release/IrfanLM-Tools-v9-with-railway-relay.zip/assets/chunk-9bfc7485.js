import { g as q, c as ee } from "./chunk-725317a4.js";
var B = { exports: {} };
const re = (e) => typeof crypto < "u" && typeof crypto.getRandomValues == "function" ? () => {
  const r = crypto.getRandomValues(new Uint8Array(1))[0];
  return (r >= e ? r % e : r).toString(e);
} : () => Math.floor(Math.random() * e).toString(e), J = (e = 7, r = false) => Array.from({ length: e }, re(r ? 16 : 36)).join("");
B.exports = J;
B.exports.default = J;
var se = B.exports;
const j = q(se);
var de = () => `uid::${j(7)}`, V = (e, r = ["endpointName", "fingerprint"]) => typeof e == "object" && e !== null && r.every((n) => n in e), fe = (e) => {
  if (!V(e))
    throw new TypeError("Invalid connection args");
  return JSON.stringify(e);
}, xe = (e) => {
  try {
    const r = JSON.parse(e);
    return V(r) ? r : null;
  } catch {
    return null;
  }
}, pe = () => {
  let e = [];
  return { add: (...r) => {
    e = [...e, ...r];
  }, remove: (r) => {
    e = typeof r == "string" ? e.filter((n) => n.message.transactionId !== r) : e.filter((n) => !r.includes(n));
  }, entries: () => e };
}, be = class {
  static toBackground(e, r) {
    return e.postMessage(r);
  }
  static toExtensionContext(e, r) {
    return e.postMessage(r);
  }
}, z = { exports: {} };
(function(e, r) {
  (function(n, u) {
    u(e);
  })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : ee, function(n) {
    if (typeof globalThis != "object" || typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id)
      throw new Error("This script should only be loaded in a browser extension.");
    if (typeof globalThis.browser > "u" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
      const u = "The message port closed before a response was received.", x = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)", b = (i) => {
        const a = { alarms: { clear: { minArgs: 0, maxArgs: 1 }, clearAll: { minArgs: 0, maxArgs: 0 }, get: { minArgs: 0, maxArgs: 1 }, getAll: { minArgs: 0, maxArgs: 0 } }, bookmarks: { create: { minArgs: 1, maxArgs: 1 }, get: { minArgs: 1, maxArgs: 1 }, getChildren: { minArgs: 1, maxArgs: 1 }, getRecent: { minArgs: 1, maxArgs: 1 }, getSubTree: { minArgs: 1, maxArgs: 1 }, getTree: { minArgs: 0, maxArgs: 0 }, move: { minArgs: 2, maxArgs: 2 }, remove: { minArgs: 1, maxArgs: 1 }, removeTree: { minArgs: 1, maxArgs: 1 }, search: { minArgs: 1, maxArgs: 1 }, update: { minArgs: 2, maxArgs: 2 } }, browserAction: { disable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: true }, enable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: true }, getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 }, getBadgeText: { minArgs: 1, maxArgs: 1 }, getPopup: { minArgs: 1, maxArgs: 1 }, getTitle: { minArgs: 1, maxArgs: 1 }, openPopup: { minArgs: 0, maxArgs: 0 }, setBadgeBackgroundColor: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, setBadgeText: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, setIcon: { minArgs: 1, maxArgs: 1 }, setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true } }, browsingData: { remove: { minArgs: 2, maxArgs: 2 }, removeCache: { minArgs: 1, maxArgs: 1 }, removeCookies: { minArgs: 1, maxArgs: 1 }, removeDownloads: { minArgs: 1, maxArgs: 1 }, removeFormData: { minArgs: 1, maxArgs: 1 }, removeHistory: { minArgs: 1, maxArgs: 1 }, removeLocalStorage: { minArgs: 1, maxArgs: 1 }, removePasswords: { minArgs: 1, maxArgs: 1 }, removePluginData: { minArgs: 1, maxArgs: 1 }, settings: { minArgs: 0, maxArgs: 0 } }, commands: { getAll: { minArgs: 0, maxArgs: 0 } }, contextMenus: { remove: { minArgs: 1, maxArgs: 1 }, removeAll: { minArgs: 0, maxArgs: 0 }, update: { minArgs: 2, maxArgs: 2 } }, cookies: { get: { minArgs: 1, maxArgs: 1 }, getAll: { minArgs: 1, maxArgs: 1 }, getAllCookieStores: { minArgs: 0, maxArgs: 0 }, remove: { minArgs: 1, maxArgs: 1 }, set: { minArgs: 1, maxArgs: 1 } }, devtools: { inspectedWindow: { eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: false } }, panels: { create: { minArgs: 3, maxArgs: 3, singleCallbackArg: true }, elements: { createSidebarPane: { minArgs: 1, maxArgs: 1 } } } }, downloads: { cancel: { minArgs: 1, maxArgs: 1 }, download: { minArgs: 1, maxArgs: 1 }, erase: { minArgs: 1, maxArgs: 1 }, getFileIcon: { minArgs: 1, maxArgs: 2 }, open: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, pause: { minArgs: 1, maxArgs: 1 }, removeFile: { minArgs: 1, maxArgs: 1 }, resume: { minArgs: 1, maxArgs: 1 }, search: { minArgs: 1, maxArgs: 1 }, show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true } }, extension: { isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 }, isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 } }, history: { addUrl: { minArgs: 1, maxArgs: 1 }, deleteAll: { minArgs: 0, maxArgs: 0 }, deleteRange: { minArgs: 1, maxArgs: 1 }, deleteUrl: { minArgs: 1, maxArgs: 1 }, getVisits: { minArgs: 1, maxArgs: 1 }, search: { minArgs: 1, maxArgs: 1 } }, i18n: { detectLanguage: { minArgs: 1, maxArgs: 1 }, getAcceptLanguages: { minArgs: 0, maxArgs: 0 } }, identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } }, idle: { queryState: { minArgs: 1, maxArgs: 1 } }, management: { get: { minArgs: 1, maxArgs: 1 }, getAll: { minArgs: 0, maxArgs: 0 }, getSelf: { minArgs: 0, maxArgs: 0 }, setEnabled: { minArgs: 2, maxArgs: 2 }, uninstallSelf: { minArgs: 0, maxArgs: 1 } }, notifications: { clear: { minArgs: 1, maxArgs: 1 }, create: { minArgs: 1, maxArgs: 2 }, getAll: { minArgs: 0, maxArgs: 0 }, getPermissionLevel: { minArgs: 0, maxArgs: 0 }, update: { minArgs: 2, maxArgs: 2 } }, pageAction: { getPopup: { minArgs: 1, maxArgs: 1 }, getTitle: { minArgs: 1, maxArgs: 1 }, hide: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, setIcon: { minArgs: 1, maxArgs: 1 }, setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true }, show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: true } }, permissions: { contains: { minArgs: 1, maxArgs: 1 }, getAll: { minArgs: 0, maxArgs: 0 }, remove: { minArgs: 1, maxArgs: 1 }, request: { minArgs: 1, maxArgs: 1 } }, runtime: { getBackgroundPage: { minArgs: 0, maxArgs: 0 }, getPlatformInfo: { minArgs: 0, maxArgs: 0 }, openOptionsPage: { minArgs: 0, maxArgs: 0 }, requestUpdateCheck: { minArgs: 0, maxArgs: 0 }, sendMessage: { minArgs: 1, maxArgs: 3 }, sendNativeMessage: { minArgs: 2, maxArgs: 2 }, setUninstallURL: { minArgs: 1, maxArgs: 1 } }, sessions: { getDevices: { minArgs: 0, maxArgs: 1 }, getRecentlyClosed: { minArgs: 0, maxArgs: 1 }, restore: { minArgs: 0, maxArgs: 1 } }, storage: { local: { clear: { minArgs: 0, maxArgs: 0 }, get: { minArgs: 0, maxArgs: 1 }, getBytesInUse: { minArgs: 0, maxArgs: 1 }, remove: { minArgs: 1, maxArgs: 1 }, set: { minArgs: 1, maxArgs: 1 } }, managed: { get: { minArgs: 0, maxArgs: 1 }, getBytesInUse: { minArgs: 0, maxArgs: 1 } }, sync: { clear: { minArgs: 0, maxArgs: 0 }, get: { minArgs: 0, maxArgs: 1 }, getBytesInUse: { minArgs: 0, maxArgs: 1 }, remove: { minArgs: 1, maxArgs: 1 }, set: { minArgs: 1, maxArgs: 1 } } }, tabs: { captureVisibleTab: { minArgs: 0, maxArgs: 2 }, create: { minArgs: 1, maxArgs: 1 }, detectLanguage: { minArgs: 0, maxArgs: 1 }, discard: { minArgs: 0, maxArgs: 1 }, duplicate: { minArgs: 1, maxArgs: 1 }, executeScript: { minArgs: 1, maxArgs: 2 }, get: { minArgs: 1, maxArgs: 1 }, getCurrent: { minArgs: 0, maxArgs: 0 }, getZoom: { minArgs: 0, maxArgs: 1 }, getZoomSettings: { minArgs: 0, maxArgs: 1 }, goBack: { minArgs: 0, maxArgs: 1 }, goForward: { minArgs: 0, maxArgs: 1 }, highlight: { minArgs: 1, maxArgs: 1 }, insertCSS: { minArgs: 1, maxArgs: 2 }, move: { minArgs: 2, maxArgs: 2 }, query: { minArgs: 1, maxArgs: 1 }, reload: { minArgs: 0, maxArgs: 2 }, remove: { minArgs: 1, maxArgs: 1 }, removeCSS: { minArgs: 1, maxArgs: 2 }, sendMessage: { minArgs: 2, maxArgs: 3 }, setZoom: { minArgs: 1, maxArgs: 2 }, setZoomSettings: { minArgs: 1, maxArgs: 2 }, update: { minArgs: 1, maxArgs: 2 } }, topSites: { get: { minArgs: 0, maxArgs: 0 } }, webNavigation: { getAllFrames: { minArgs: 1, maxArgs: 1 }, getFrame: { minArgs: 1, maxArgs: 1 } }, webRequest: { handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 } }, windows: { create: { minArgs: 0, maxArgs: 1 }, get: { minArgs: 1, maxArgs: 2 }, getAll: { minArgs: 0, maxArgs: 1 }, getCurrent: { minArgs: 0, maxArgs: 1 }, getLastFocused: { minArgs: 0, maxArgs: 1 }, remove: { minArgs: 1, maxArgs: 1 }, update: { minArgs: 2, maxArgs: 2 } } };
        if (Object.keys(a).length === 0)
          throw new Error("api-metadata.json has not been included in browser-polyfill");
        class m extends WeakMap {
          constructor(t, g = void 0) {
            super(g), this.createItem = t;
          }
          get(t) {
            return this.has(t) || this.set(t, this.createItem(t)), super.get(t);
          }
        }
        const p = (s) => s && typeof s == "object" && typeof s.then == "function", h = (s, t) => (...g) => {
          i.runtime.lastError ? s.reject(new Error(i.runtime.lastError.message)) : t.singleCallbackArg || g.length <= 1 && t.singleCallbackArg !== false ? s.resolve(g[0]) : s.resolve(g);
        }, v = (s) => s == 1 ? "argument" : "arguments", C = (s, t) => function(l, ...d) {
          if (d.length < t.minArgs)
            throw new Error(`Expected at least ${t.minArgs} ${v(t.minArgs)} for ${s}(), got ${d.length}`);
          if (d.length > t.maxArgs)
            throw new Error(`Expected at most ${t.maxArgs} ${v(t.maxArgs)} for ${s}(), got ${d.length}`);
          return new Promise((w, _) => {
            if (t.fallbackToNoCallback)
              try {
                l[s](...d, h({ resolve: w, reject: _ }, t));
              } catch (o) {
                console.warn(`${s} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, o), l[s](...d), t.fallbackToNoCallback = false, t.noCallback = true, w();
              }
            else
              t.noCallback ? (l[s](...d), w()) : l[s](...d, h({ resolve: w, reject: _ }, t));
          });
        }, f = (s, t, g) => new Proxy(t, { apply(l, d, w) {
          return g.call(d, s, ...w);
        } });
        let c = Function.call.bind(Object.prototype.hasOwnProperty);
        const k = (s, t = {}, g = {}) => {
          let l = /* @__PURE__ */ Object.create(null), d = { has(_, o) {
            return o in s || o in l;
          }, get(_, o, E) {
            if (o in l)
              return l[o];
            if (!(o in s))
              return;
            let A = s[o];
            if (typeof A == "function")
              if (typeof t[o] == "function")
                A = f(s, s[o], t[o]);
              else if (c(g, o)) {
                let P = C(o, g[o]);
                A = f(s, s[o], P);
              } else
                A = A.bind(s);
            else if (typeof A == "object" && A !== null && (c(t, o) || c(g, o)))
              A = k(A, t[o], g[o]);
            else if (c(g, "*"))
              A = k(A, t[o], g["*"]);
            else
              return Object.defineProperty(l, o, { configurable: true, enumerable: true, get() {
                return s[o];
              }, set(P) {
                s[o] = P;
              } }), A;
            return l[o] = A, A;
          }, set(_, o, E, A) {
            return o in l ? l[o] = E : s[o] = E, true;
          }, defineProperty(_, o, E) {
            return Reflect.defineProperty(l, o, E);
          }, deleteProperty(_, o) {
            return Reflect.deleteProperty(l, o);
          } }, w = Object.create(s);
          return new Proxy(w, d);
        }, y = (s) => ({ addListener(t, g, ...l) {
          t.addListener(s.get(g), ...l);
        }, hasListener(t, g) {
          return t.hasListener(s.get(g));
        }, removeListener(t, g) {
          t.removeListener(s.get(g));
        } }), N = new m((s) => typeof s != "function" ? s : function(g) {
          const l = k(g, {}, { getContent: { minArgs: 0, maxArgs: 0 } });
          s(l);
        });
        let M = false;
        const I = new m((s) => typeof s != "function" ? s : function(g, l, d) {
          let w = false, _, o = new Promise((O) => {
            _ = function(S) {
              M || (console.warn(x, new Error().stack), M = true), w = true, O(S);
            };
          }), E;
          try {
            E = s(g, l, _);
          } catch (O) {
            E = Promise.reject(O);
          }
          const A = E !== true && p(E);
          if (E !== true && !A && !w)
            return false;
          const P = (O) => {
            O.then((S) => {
              d(S);
            }, (S) => {
              let D;
              S && (S instanceof Error || typeof S.message == "string") ? D = S.message : D = "An unexpected error occurred", d({ __mozWebExtensionPolyfillReject__: true, message: D });
            }).catch((S) => {
              console.error("Failed to send onMessage rejected reply", S);
            });
          };
          return P(A ? E : o), true;
        }), Q = ({ reject: s, resolve: t }, g) => {
          i.runtime.lastError ? i.runtime.lastError.message === u ? t() : s(new Error(i.runtime.lastError.message)) : g && g.__mozWebExtensionPolyfillReject__ ? s(new Error(g.message)) : t(g);
        }, L = (s, t, g, ...l) => {
          if (l.length < t.minArgs)
            throw new Error(`Expected at least ${t.minArgs} ${v(t.minArgs)} for ${s}(), got ${l.length}`);
          if (l.length > t.maxArgs)
            throw new Error(`Expected at most ${t.maxArgs} ${v(t.maxArgs)} for ${s}(), got ${l.length}`);
          return new Promise((d, w) => {
            const _ = Q.bind(null, { resolve: d, reject: w });
            l.push(_), g.sendMessage(...l);
          });
        }, X = { devtools: { network: { onRequestFinished: y(N) } }, runtime: { onMessage: y(I), onMessageExternal: y(I), sendMessage: L.bind(null, "sendMessage", { minArgs: 1, maxArgs: 3 }) }, tabs: { sendMessage: L.bind(null, "sendMessage", { minArgs: 2, maxArgs: 3 }) } }, R = { clear: { minArgs: 1, maxArgs: 1 }, get: { minArgs: 1, maxArgs: 1 }, set: { minArgs: 1, maxArgs: 1 } };
        return a.privacy = { network: { "*": R }, services: { "*": R }, websites: { "*": R } }, k(i, X, a);
      };
      n.exports = b(chrome);
    } else
      n.exports = globalThis.browser;
  });
})(z);
var te = z.exports;
const he = q(te);
var ne = Object.defineProperty, ae = Object.defineProperties, oe = Object.getOwnPropertyDescriptors, W = Object.getOwnPropertySymbols, ie = Object.prototype.hasOwnProperty, ge = Object.prototype.propertyIsEnumerable, U = (e, r, n) => r in e ? ne(e, r, { enumerable: true, configurable: true, writable: true, value: n }) : e[r] = n, G = (e, r) => {
  for (var n in r || (r = {}))
    ie.call(r, n) && U(e, n, r[n]);
  if (W)
    for (var n of W(r))
      ge.call(r, n) && U(e, n, r[n]);
  return e;
}, Z = (e, r) => ae(e, oe(r)), me = /^((?:background$)|devtools|popup|options|content-script|window)(?:@(\d+)(?:\.(\d+))?)?$/, H = (e) => {
  const [, r, n, u] = e.match(me) || [];
  return { context: r, tabId: +n, frameId: u ? +u : void 0 };
}, ye = ({ context: e, tabId: r, frameId: n }) => ["background", "popup", "options"].includes(e) ? e : `${e}@${r}${n ? `.${n}` : ""}`;
const le = [{ property: "name", enumerable: false }, { property: "message", enumerable: false }, { property: "stack", enumerable: false }, { property: "code", enumerable: true }], F = Symbol(".toJSON was called"), ce = (e) => {
  e[F] = true;
  const r = e.toJSON();
  return delete e[F], r;
}, K = ({ from: e, seen: r, to_: n, forceEnumerable: u, maxDepth: x, depth: b }) => {
  const i = n || (Array.isArray(e) ? [] : {});
  if (r.push(e), b >= x)
    return i;
  if (typeof e.toJSON == "function" && e[F] !== true)
    return ce(e);
  for (const [a, m] of Object.entries(e)) {
    if (typeof Buffer == "function" && Buffer.isBuffer(m)) {
      i[a] = "[object Buffer]";
      continue;
    }
    if (m !== null && typeof m == "object" && typeof m.pipe == "function") {
      i[a] = "[object Stream]";
      continue;
    }
    if (typeof m != "function") {
      if (!m || typeof m != "object") {
        i[a] = m;
        continue;
      }
      if (!r.includes(e[a])) {
        b++, i[a] = K({ from: e[a], seen: [...r], forceEnumerable: u, maxDepth: x, depth: b });
        continue;
      }
      i[a] = "[Circular]";
    }
  }
  for (const { property: a, enumerable: m } of le)
    typeof e[a] == "string" && Object.defineProperty(i, a, { value: e[a], enumerable: u ? true : m, configurable: true, writable: true });
  return i;
};
function Ae(e, r = {}) {
  const { maxDepth: n = Number.POSITIVE_INFINITY } = r;
  return typeof e == "object" && e !== null ? K({ from: e, seen: [], forceEnumerable: true, maxDepth: n, depth: 0 }) : typeof e == "function" ? `[Function: ${e.name || "anonymous"}]` : e;
}
let Y = () => ({ events: {}, emit(e, ...r) {
  (this.events[e] || []).forEach((n) => n(...r));
}, on(e, r) {
  return (this.events[e] = this.events[e] || []).push(r), () => this.events[e] = (this.events[e] || []).filter((n) => n !== r);
} });
var we = (e, r, n) => {
  const u = j(), x = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), i = (a) => {
    if (a.destination.context === e && !a.destination.frameId && !a.destination.tabId) {
      n == null ? void 0 : n(a);
      const { transactionId: m, messageID: p, messageType: h } = a, v = () => {
        const f = x.get(m);
        if (f) {
          const { err: c, data: k } = a;
          if (c) {
            const y = c, N = self[y.name], M = new (typeof N == "function" ? N : Error)(y.message);
            for (const I in y)
              M[I] = y[I];
            f.reject(M);
          } else
            f.resolve(k);
          x.delete(m);
        }
      }, C = async () => {
        let f, c, k = false;
        try {
          const y = b.get(p);
          if (typeof y == "function")
            f = await y({ sender: a.origin, id: p, data: a.data, timestamp: a.timestamp });
          else
            throw k = true, new Error(`[webext-bridge] No handler registered in '${e}' to accept messages with id '${p}'`);
        } catch (y) {
          c = y;
        } finally {
          if (c && (a.err = Ae(c)), i(Z(G({}, a), { messageType: "reply", data: f, origin: { context: e, tabId: null }, destination: a.origin, hops: [] })), c && !k)
            throw f;
        }
      };
      switch (h) {
        case "reply":
          return v();
        case "message":
          return C();
      }
    }
    return a.hops.push(`${e}::${u}`), r(a);
  };
  return { handleMessage: i, endTransaction: (a) => {
    const m = x.get(a);
    m == null ? void 0 : m.reject("Transaction was ended before it could complete"), x.delete(a);
  }, sendMessage: (a, m, p = "background") => {
    const h = typeof p == "string" ? H(p) : p, v = "Bridge#sendMessage ->";
    if (!h.context)
      throw new TypeError(`${v} Destination must be any one of known destinations`);
    return new Promise((C, f) => {
      const c = { messageID: a, data: m, destination: h, messageType: "message", transactionId: j(), origin: { context: e, tabId: null }, hops: [], timestamp: Date.now() };
      x.set(c.transactionId, { resolve: C, reject: f });
      try {
        i(c);
      } catch (k) {
        x.delete(c.transactionId), f(k);
      }
    });
  }, onMessage: (a, m) => (b.set(a, m), () => b.delete(a)) };
}, T = class {
  constructor(e, r) {
    this.endpointRuntime = e, this.streamInfo = r, this.emitter = Y(), this.isClosed = false, this.handleStreamClose = () => {
      this.isClosed || (this.isClosed = true, this.emitter.emit("closed", true), this.emitter.events = {});
    }, T.initDone || (e.onMessage("__crx_bridge_stream_transfer__", (n) => {
      const { streamId: u, streamTransfer: x, action: b } = n.data, i = T.openStreams.get(u);
      i && !i.isClosed && (b === "transfer" && i.emitter.emit("message", x), b === "close" && (T.openStreams.delete(u), i.handleStreamClose()));
    }), T.initDone = true), T.openStreams.set(this.streamInfo.streamId, this);
  }
  get info() {
    return this.streamInfo;
  }
  send(e) {
    if (this.isClosed)
      throw new Error("Attempting to send a message over closed stream. Use stream.onClose(<callback>) to keep an eye on stream status");
    this.endpointRuntime.sendMessage("__crx_bridge_stream_transfer__", { streamId: this.streamInfo.streamId, streamTransfer: e, action: "transfer" }, this.streamInfo.endpoint);
  }
  close(e) {
    e && this.send(e), this.handleStreamClose(), this.endpointRuntime.sendMessage("__crx_bridge_stream_transfer__", { streamId: this.streamInfo.streamId, streamTransfer: null, action: "close" }, this.streamInfo.endpoint);
  }
  onMessage(e) {
    return this.getDisposable("message", e);
  }
  onClose(e) {
    return this.getDisposable("closed", e);
  }
  getDisposable(e, r) {
    const n = this.emitter.on(e, r);
    return Object.assign(n, { dispose: n, close: n });
  }
}, $ = T;
$.initDone = false;
$.openStreams = /* @__PURE__ */ new Map();
var ve = (e) => {
  const r = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), u = Y();
  e.onMessage("__crx_bridge_stream_open__", (i) => new Promise((a) => {
    const { sender: m, data: p } = i, { channel: h } = p;
    let v = false, C = () => {
    };
    const f = () => {
      const c = n.get(h);
      typeof c == "function" ? (c(new $(e, Z(G({}, p), { endpoint: m }))), v && C(), a(true)) : v || (v = true, C = u.on("did-change-stream-callbacks", f));
    };
    f();
  }));
  async function x(i, a) {
    if (r.has(i))
      throw new Error("webext-bridge: A Stream is already open at this channel");
    const m = typeof a == "string" ? H(a) : a, p = { streamId: j(), channel: i, endpoint: m }, h = new $(e, p);
    return h.onClose(() => r.delete(i)), await e.sendMessage("__crx_bridge_stream_open__", p, m), r.set(i, h), h;
  }
  function b(i, a) {
    if (n.has(i))
      throw new Error("webext-bridge: This channel has already been claimed. Stream allows only one-on-one communication");
    n.set(i, a), u.emit("did-change-stream-callbacks");
  }
  return { openStream: x, onOpenStreamChannel: b };
};
export {
  be as P,
  G as _,
  ve as a,
  de as b,
  we as c,
  he as d,
  xe as e,
  ye as f,
  pe as g,
  Z as h,
  fe as i,
  H as p
};
