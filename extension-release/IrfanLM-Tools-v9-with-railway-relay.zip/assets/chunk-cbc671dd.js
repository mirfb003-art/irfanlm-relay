import { r as l, j as a, h as d, c as x, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { a3 as o } from "./chunk-68adfa56.js";
import { U as p, __tla as __tla_1 } from "./chunk-1784b260.js";
import { m as u, __tla as __tla_2 } from "./chunk-2a4ab792.js";
let S, k;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  function f({ title: t, titleId: e, ...r }, n) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: n,
      "aria-labelledby": e
    }, r), t ? l.createElement("title", {
      id: e
    }, t) : null, l.createElement("path", {
      fillRule: "evenodd",
      d: "M9.661 2.237a.531.531 0 0 1 .678 0 11.947 11.947 0 0 0 7.078 2.749.5.5 0 0 1 .479.425c.069.52.104 1.05.104 1.59 0 5.162-3.26 9.563-7.834 11.256a.48.48 0 0 1-.332 0C5.26 16.564 2 12.163 2 7c0-.538.035-1.069.104-1.589a.5.5 0 0 1 .48-.425 11.947 11.947 0 0 0 7.077-2.75Zm4.196 5.954a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z",
      clipRule: "evenodd"
    }));
  }
  const b = l.forwardRef(f), E = b;
  S = function({ className: t, text: e }) {
    return a.jsxs("div", {
      className: "flex flex-col items-center justify-center",
      children: [
        a.jsx(d, {
          className: x("animate-spin text-neutral-500 dark:text-neutral-400", t || "w-5 h-5")
        }),
        e && a.jsx("p", {
          className: "mt-2 text-xs text-neutral-500 dark:text-neutral-400 font-medium",
          children: e
        })
      ]
    });
  };
  const w = {
    [o.OWNER]: {
      label: "Owner",
      Icon: E,
      color: "bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300"
    },
    [o.EDITOR]: {
      label: "Editor",
      Icon: p,
      color: "bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300"
    },
    [o.VIEWER]: {
      label: "Viewer",
      Icon: u,
      color: "bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-400"
    }
  }, s = {
    sm: {
      wrapper: "text-[11px]",
      icon: "w-2.5 h-2.5"
    },
    md: {
      wrapper: "text-xs",
      icon: "w-3 h-3"
    }
  };
  k = function({ code: t, size: e = "md" }) {
    const r = w[t];
    if (!r)
      return null;
    const n = s[e] || s.md, { label: c, Icon: i, color: m } = r;
    return a.jsxs("span", {
      className: `inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded font-medium ${n.wrapper} ${m}`,
      children: [
        a.jsx(i, {
          className: n.icon
        }),
        c
      ]
    });
  };
});
export {
  S as L,
  k as R,
  __tla
};
