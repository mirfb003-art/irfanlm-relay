import { r as d, j as m, m as O, n as Ee, c as _e, k as Sr, u as Cr, P as Je, T as Oe, J as Qe, a0 as Ot, G as wn, ag as Rr, ae as br, ah as yr, ai as Er, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { f as Dr, v as _r, D as Fr, L as Mr, P as kr, s as Ir, i as Pr, z as $r, Q as Nr, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { T as ye, __tla as __tla_2 } from "./chunk-95b0b380.js";
import { X as F, aK as Or } from "./chunk-68adfa56.js";
let Bo, ol, Hr, ll, il, Jo, ti, Xo, Qs, Js, Vn, al, sl;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  function Ar({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      d: "M3 3.5A1.5 1.5 0 0 1 4.5 2h6.879a1.5 1.5 0 0 1 1.06.44l4.122 4.12A1.5 1.5 0 0 1 17 7.622V16.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 3 16.5v-13Z"
    }));
  }
  const Vr = d.forwardRef(Ar), et = Vr;
  function Lr({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      d: "M10 3a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM10 8.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM11.5 15.5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0Z"
    }));
  }
  const jr = d.forwardRef(Lr), Tr = jr;
  function zr({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      d: "M3.75 3A1.75 1.75 0 0 0 2 4.75v3.26a3.235 3.235 0 0 1 1.75-.51h12.5c.644 0 1.245.188 1.75.51V6.75A1.75 1.75 0 0 0 16.25 5h-4.836a.25.25 0 0 1-.177-.073L9.823 3.513A1.75 1.75 0 0 0 8.586 3H3.75ZM3.75 9A1.75 1.75 0 0 0 2 10.75v4.5c0 .966.784 1.75 1.75 1.75h12.5A1.75 1.75 0 0 0 18 15.25v-4.5A1.75 1.75 0 0 0 16.25 9H3.75Z"
    }));
  }
  let Gr;
  Gr = d.forwardRef(zr);
  Hr = Gr;
  function fe(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  function U(e, t) {
    return (n) => {
      t.setState((r) => ({
        ...r,
        [e]: fe(n, r[e])
      }));
    };
  }
  function ft(e) {
    return e instanceof Function;
  }
  function Br(e) {
    return Array.isArray(e) && e.every((t) => typeof t == "number");
  }
  function Ur(e, t) {
    const n = [], r = (o) => {
      o.forEach((i) => {
        n.push(i);
        const s = t(i);
        s != null && s.length && r(s);
      });
    };
    return r(e), n;
  }
  function y(e, t, n) {
    let r = [], o;
    return (i) => {
      let s;
      n.key && n.debug && (s = Date.now());
      const l = e(i);
      if (!(l.length !== r.length || l.some((g, p) => r[p] !== g)))
        return o;
      r = l;
      let c;
      if (n.key && n.debug && (c = Date.now()), o = t(...l), n == null || n.onChange == null || n.onChange(o), n.key && n.debug && n != null && n.debug()) {
        const g = Math.round((Date.now() - s) * 100) / 100, p = Math.round((Date.now() - c) * 100) / 100, f = p / 16, u = (v, h) => {
          for (v = String(v); v.length < h; )
            v = " " + v;
          return v;
        };
        console.info(`%c\u23F1 ${u(p, 5)} /${u(g, 5)} ms`, `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * f, 120))}deg 100% 31%);`, n == null ? void 0 : n.key);
      }
      return o;
    };
  }
  function E(e, t, n, r) {
    return {
      debug: () => {
        var o;
        return (o = e == null ? void 0 : e.debugAll) != null ? o : e[t];
      },
      key: false,
      onChange: r
    };
  }
  function qr(e, t, n, r) {
    const o = () => {
      var s;
      return (s = i.getValue()) != null ? s : e.options.renderFallbackValue;
    }, i = {
      id: `${t.id}_${n.id}`,
      row: t,
      column: n,
      getValue: () => t.getValue(r),
      renderValue: o,
      getContext: y(() => [
        e,
        n,
        t,
        i
      ], (s, l, a, c) => ({
        table: s,
        column: l,
        row: a,
        cell: c,
        getValue: c.getValue,
        renderValue: c.renderValue
      }), E(e.options, "debugCells"))
    };
    return e._features.forEach((s) => {
      s.createCell == null || s.createCell(i, n, t, e);
    }, {}), i;
  }
  function Xr(e, t, n, r) {
    var o, i;
    const l = {
      ...e._getDefaultColumnDef(),
      ...t
    }, a = l.accessorKey;
    let c = (o = (i = l.id) != null ? i : a ? typeof String.prototype.replaceAll == "function" ? a.replaceAll(".", "_") : a.replace(/\./g, "_") : void 0) != null ? o : typeof l.header == "string" ? l.header : void 0, g;
    if (l.accessorFn ? g = l.accessorFn : a && (a.includes(".") ? g = (f) => {
      let u = f;
      for (const h of a.split(".")) {
        var v;
        u = (v = u) == null ? void 0 : v[h];
      }
      return u;
    } : g = (f) => f[l.accessorKey]), !c)
      throw new Error();
    let p = {
      id: `${String(c)}`,
      accessorFn: g,
      parent: r,
      depth: n,
      columnDef: l,
      columns: [],
      getFlatColumns: y(() => [
        true
      ], () => {
        var f;
        return [
          p,
          ...(f = p.columns) == null ? void 0 : f.flatMap((u) => u.getFlatColumns())
        ];
      }, E(e.options, "debugColumns")),
      getLeafColumns: y(() => [
        e._getOrderColumnsFn()
      ], (f) => {
        var u;
        if ((u = p.columns) != null && u.length) {
          let v = p.columns.flatMap((h) => h.getLeafColumns());
          return f(v);
        }
        return [
          p
        ];
      }, E(e.options, "debugColumns"))
    };
    for (const f of e._features)
      f.createColumn == null || f.createColumn(p, e);
    return p;
  }
  const T = "debugHeaders";
  function Sn(e, t, n) {
    var r;
    let i = {
      id: (r = n.id) != null ? r : t.id,
      column: t,
      index: n.index,
      isPlaceholder: !!n.isPlaceholder,
      placeholderId: n.placeholderId,
      depth: n.depth,
      subHeaders: [],
      colSpan: 0,
      rowSpan: 0,
      headerGroup: null,
      getLeafHeaders: () => {
        const s = [], l = (a) => {
          a.subHeaders && a.subHeaders.length && a.subHeaders.map(l), s.push(a);
        };
        return l(i), s;
      },
      getContext: () => ({
        table: e,
        header: i,
        column: t
      })
    };
    return e._features.forEach((s) => {
      s.createHeader == null || s.createHeader(i, e);
    }), i;
  }
  const Kr = {
    createTable: (e) => {
      e.getHeaderGroups = y(() => [
        e.getAllColumns(),
        e.getVisibleLeafColumns(),
        e.getState().columnPinning.left,
        e.getState().columnPinning.right
      ], (t, n, r, o) => {
        var i, s;
        const l = (i = r == null ? void 0 : r.map((p) => n.find((f) => f.id === p)).filter(Boolean)) != null ? i : [], a = (s = o == null ? void 0 : o.map((p) => n.find((f) => f.id === p)).filter(Boolean)) != null ? s : [], c = n.filter((p) => !(r != null && r.includes(p.id)) && !(o != null && o.includes(p.id)));
        return tt(t, [
          ...l,
          ...c,
          ...a
        ], e);
      }, E(e.options, T)), e.getCenterHeaderGroups = y(() => [
        e.getAllColumns(),
        e.getVisibleLeafColumns(),
        e.getState().columnPinning.left,
        e.getState().columnPinning.right
      ], (t, n, r, o) => (n = n.filter((i) => !(r != null && r.includes(i.id)) && !(o != null && o.includes(i.id))), tt(t, n, e, "center")), E(e.options, T)), e.getLeftHeaderGroups = y(() => [
        e.getAllColumns(),
        e.getVisibleLeafColumns(),
        e.getState().columnPinning.left
      ], (t, n, r) => {
        var o;
        const i = (o = r == null ? void 0 : r.map((s) => n.find((l) => l.id === s)).filter(Boolean)) != null ? o : [];
        return tt(t, i, e, "left");
      }, E(e.options, T)), e.getRightHeaderGroups = y(() => [
        e.getAllColumns(),
        e.getVisibleLeafColumns(),
        e.getState().columnPinning.right
      ], (t, n, r) => {
        var o;
        const i = (o = r == null ? void 0 : r.map((s) => n.find((l) => l.id === s)).filter(Boolean)) != null ? o : [];
        return tt(t, i, e, "right");
      }, E(e.options, T)), e.getFooterGroups = y(() => [
        e.getHeaderGroups()
      ], (t) => [
        ...t
      ].reverse(), E(e.options, T)), e.getLeftFooterGroups = y(() => [
        e.getLeftHeaderGroups()
      ], (t) => [
        ...t
      ].reverse(), E(e.options, T)), e.getCenterFooterGroups = y(() => [
        e.getCenterHeaderGroups()
      ], (t) => [
        ...t
      ].reverse(), E(e.options, T)), e.getRightFooterGroups = y(() => [
        e.getRightHeaderGroups()
      ], (t) => [
        ...t
      ].reverse(), E(e.options, T)), e.getFlatHeaders = y(() => [
        e.getHeaderGroups()
      ], (t) => t.map((n) => n.headers).flat(), E(e.options, T)), e.getLeftFlatHeaders = y(() => [
        e.getLeftHeaderGroups()
      ], (t) => t.map((n) => n.headers).flat(), E(e.options, T)), e.getCenterFlatHeaders = y(() => [
        e.getCenterHeaderGroups()
      ], (t) => t.map((n) => n.headers).flat(), E(e.options, T)), e.getRightFlatHeaders = y(() => [
        e.getRightHeaderGroups()
      ], (t) => t.map((n) => n.headers).flat(), E(e.options, T)), e.getCenterLeafHeaders = y(() => [
        e.getCenterFlatHeaders()
      ], (t) => t.filter((n) => {
        var r;
        return !((r = n.subHeaders) != null && r.length);
      }), E(e.options, T)), e.getLeftLeafHeaders = y(() => [
        e.getLeftFlatHeaders()
      ], (t) => t.filter((n) => {
        var r;
        return !((r = n.subHeaders) != null && r.length);
      }), E(e.options, T)), e.getRightLeafHeaders = y(() => [
        e.getRightFlatHeaders()
      ], (t) => t.filter((n) => {
        var r;
        return !((r = n.subHeaders) != null && r.length);
      }), E(e.options, T)), e.getLeafHeaders = y(() => [
        e.getLeftHeaderGroups(),
        e.getCenterHeaderGroups(),
        e.getRightHeaderGroups()
      ], (t, n, r) => {
        var o, i, s, l, a, c;
        return [
          ...(o = (i = t[0]) == null ? void 0 : i.headers) != null ? o : [],
          ...(s = (l = n[0]) == null ? void 0 : l.headers) != null ? s : [],
          ...(a = (c = r[0]) == null ? void 0 : c.headers) != null ? a : []
        ].map((g) => g.getLeafHeaders()).flat();
      }, E(e.options, T));
    }
  };
  function tt(e, t, n, r) {
    var o, i;
    let s = 0;
    const l = function(f, u) {
      u === void 0 && (u = 1), s = Math.max(s, u), f.filter((v) => v.getIsVisible()).forEach((v) => {
        var h;
        (h = v.columns) != null && h.length && l(v.columns, u + 1);
      }, 0);
    };
    l(e);
    let a = [];
    const c = (f, u) => {
      const v = {
        depth: u,
        id: [
          r,
          `${u}`
        ].filter(Boolean).join("_"),
        headers: []
      }, h = [];
      f.forEach((w) => {
        const x = [
          ...h
        ].reverse()[0], S = w.column.depth === v.depth;
        let C, M = false;
        if (S && w.column.parent ? C = w.column.parent : (C = w.column, M = true), x && (x == null ? void 0 : x.column) === C)
          x.subHeaders.push(w);
        else {
          const b = Sn(n, C, {
            id: [
              r,
              u,
              C.id,
              w == null ? void 0 : w.id
            ].filter(Boolean).join("_"),
            isPlaceholder: M,
            placeholderId: M ? `${h.filter((R) => R.column === C).length}` : void 0,
            depth: u,
            index: h.length
          });
          b.subHeaders.push(w), h.push(b);
        }
        v.headers.push(w), w.headerGroup = v;
      }), a.push(v), u > 0 && c(h, u - 1);
    }, g = t.map((f, u) => Sn(n, f, {
      depth: s,
      index: u
    }));
    c(g, s - 1), a.reverse();
    const p = (f) => f.filter((v) => v.column.getIsVisible()).map((v) => {
      let h = 0, w = 0, x = [
        0
      ];
      v.subHeaders && v.subHeaders.length ? (x = [], p(v.subHeaders).forEach((C) => {
        let { colSpan: M, rowSpan: b } = C;
        h += M, x.push(b);
      })) : h = 1;
      const S = Math.min(...x);
      return w = w + S, v.colSpan = h, v.rowSpan = w, {
        colSpan: h,
        rowSpan: w
      };
    });
    return p((o = (i = a[0]) == null ? void 0 : i.headers) != null ? o : []), a;
  }
  const Bt = (e, t, n, r, o, i, s) => {
    let l = {
      id: t,
      index: r,
      original: n,
      depth: o,
      parentId: s,
      _valuesCache: {},
      _uniqueValuesCache: {},
      getValue: (a) => {
        if (l._valuesCache.hasOwnProperty(a))
          return l._valuesCache[a];
        const c = e.getColumn(a);
        if (c != null && c.accessorFn)
          return l._valuesCache[a] = c.accessorFn(l.original, r), l._valuesCache[a];
      },
      getUniqueValues: (a) => {
        if (l._uniqueValuesCache.hasOwnProperty(a))
          return l._uniqueValuesCache[a];
        const c = e.getColumn(a);
        if (c != null && c.accessorFn)
          return c.columnDef.getUniqueValues ? (l._uniqueValuesCache[a] = c.columnDef.getUniqueValues(l.original, r), l._uniqueValuesCache[a]) : (l._uniqueValuesCache[a] = [
            l.getValue(a)
          ], l._uniqueValuesCache[a]);
      },
      renderValue: (a) => {
        var c;
        return (c = l.getValue(a)) != null ? c : e.options.renderFallbackValue;
      },
      subRows: i ?? [],
      getLeafRows: () => Ur(l.subRows, (a) => a.subRows),
      getParentRow: () => l.parentId ? e.getRow(l.parentId, true) : void 0,
      getParentRows: () => {
        let a = [], c = l;
        for (; ; ) {
          const g = c.getParentRow();
          if (!g)
            break;
          a.push(g), c = g;
        }
        return a.reverse();
      },
      getAllCells: y(() => [
        e.getAllLeafColumns()
      ], (a) => a.map((c) => qr(e, l, c, c.id)), E(e.options, "debugRows")),
      _getAllCellsByColumnId: y(() => [
        l.getAllCells()
      ], (a) => a.reduce((c, g) => (c[g.column.id] = g, c), {}), E(e.options, "debugRows"))
    };
    for (let a = 0; a < e._features.length; a++) {
      const c = e._features[a];
      c == null || c.createRow == null || c.createRow(l, e);
    }
    return l;
  }, Yr = {
    createColumn: (e, t) => {
      e._getFacetedRowModel = t.options.getFacetedRowModel && t.options.getFacetedRowModel(t, e.id), e.getFacetedRowModel = () => e._getFacetedRowModel ? e._getFacetedRowModel() : t.getPreFilteredRowModel(), e._getFacetedUniqueValues = t.options.getFacetedUniqueValues && t.options.getFacetedUniqueValues(t, e.id), e.getFacetedUniqueValues = () => e._getFacetedUniqueValues ? e._getFacetedUniqueValues() : /* @__PURE__ */ new Map(), e._getFacetedMinMaxValues = t.options.getFacetedMinMaxValues && t.options.getFacetedMinMaxValues(t, e.id), e.getFacetedMinMaxValues = () => {
        if (e._getFacetedMinMaxValues)
          return e._getFacetedMinMaxValues();
      };
    }
  }, Ln = (e, t, n) => {
    var r, o;
    const i = n == null || (r = n.toString()) == null ? void 0 : r.toLowerCase();
    return !!(!((o = e.getValue(t)) == null || (o = o.toString()) == null || (o = o.toLowerCase()) == null) && o.includes(i));
  };
  Ln.autoRemove = (e) => J(e);
  const jn = (e, t, n) => {
    var r;
    return !!(!((r = e.getValue(t)) == null || (r = r.toString()) == null) && r.includes(n));
  };
  jn.autoRemove = (e) => J(e);
  const Tn = (e, t, n) => {
    var r;
    return ((r = e.getValue(t)) == null || (r = r.toString()) == null ? void 0 : r.toLowerCase()) === (n == null ? void 0 : n.toLowerCase());
  };
  Tn.autoRemove = (e) => J(e);
  const zn = (e, t, n) => {
    var r;
    return (r = e.getValue(t)) == null ? void 0 : r.includes(n);
  };
  zn.autoRemove = (e) => J(e);
  const Gn = (e, t, n) => !n.some((r) => {
    var o;
    return !((o = e.getValue(t)) != null && o.includes(r));
  });
  Gn.autoRemove = (e) => J(e) || !(e != null && e.length);
  const Hn = (e, t, n) => n.some((r) => {
    var o;
    return (o = e.getValue(t)) == null ? void 0 : o.includes(r);
  });
  Hn.autoRemove = (e) => J(e) || !(e != null && e.length);
  const Bn = (e, t, n) => e.getValue(t) === n;
  Bn.autoRemove = (e) => J(e);
  const Un = (e, t, n) => e.getValue(t) == n;
  Un.autoRemove = (e) => J(e);
  const Ut = (e, t, n) => {
    let [r, o] = n;
    const i = e.getValue(t);
    return i >= r && i <= o;
  };
  Ut.resolveFilterValue = (e) => {
    let [t, n] = e, r = typeof t != "number" ? parseFloat(t) : t, o = typeof n != "number" ? parseFloat(n) : n, i = t === null || Number.isNaN(r) ? -1 / 0 : r, s = n === null || Number.isNaN(o) ? 1 / 0 : o;
    if (i > s) {
      const l = i;
      i = s, s = l;
    }
    return [
      i,
      s
    ];
  };
  Ut.autoRemove = (e) => J(e) || J(e[0]) && J(e[1]);
  const oe = {
    includesString: Ln,
    includesStringSensitive: jn,
    equalsString: Tn,
    arrIncludes: zn,
    arrIncludesAll: Gn,
    arrIncludesSome: Hn,
    equals: Bn,
    weakEquals: Un,
    inNumberRange: Ut
  };
  function J(e) {
    return e == null || e === "";
  }
  const Wr = {
    getDefaultColumnDef: () => ({
      filterFn: "auto"
    }),
    getInitialState: (e) => ({
      columnFilters: [],
      ...e
    }),
    getDefaultOptions: (e) => ({
      onColumnFiltersChange: U("columnFilters", e),
      filterFromLeafRows: false,
      maxLeafRowFilterDepth: 100
    }),
    createColumn: (e, t) => {
      e.getAutoFilterFn = () => {
        const n = t.getCoreRowModel().flatRows[0], r = n == null ? void 0 : n.getValue(e.id);
        return typeof r == "string" ? oe.includesString : typeof r == "number" ? oe.inNumberRange : typeof r == "boolean" || r !== null && typeof r == "object" ? oe.equals : Array.isArray(r) ? oe.arrIncludes : oe.weakEquals;
      }, e.getFilterFn = () => {
        var n, r;
        return ft(e.columnDef.filterFn) ? e.columnDef.filterFn : e.columnDef.filterFn === "auto" ? e.getAutoFilterFn() : (n = (r = t.options.filterFns) == null ? void 0 : r[e.columnDef.filterFn]) != null ? n : oe[e.columnDef.filterFn];
      }, e.getCanFilter = () => {
        var n, r, o;
        return ((n = e.columnDef.enableColumnFilter) != null ? n : true) && ((r = t.options.enableColumnFilters) != null ? r : true) && ((o = t.options.enableFilters) != null ? o : true) && !!e.accessorFn;
      }, e.getIsFiltered = () => e.getFilterIndex() > -1, e.getFilterValue = () => {
        var n;
        return (n = t.getState().columnFilters) == null || (n = n.find((r) => r.id === e.id)) == null ? void 0 : n.value;
      }, e.getFilterIndex = () => {
        var n, r;
        return (n = (r = t.getState().columnFilters) == null ? void 0 : r.findIndex((o) => o.id === e.id)) != null ? n : -1;
      }, e.setFilterValue = (n) => {
        t.setColumnFilters((r) => {
          const o = e.getFilterFn(), i = r == null ? void 0 : r.find((g) => g.id === e.id), s = fe(n, i ? i.value : void 0);
          if (Cn(o, s, e)) {
            var l;
            return (l = r == null ? void 0 : r.filter((g) => g.id !== e.id)) != null ? l : [];
          }
          const a = {
            id: e.id,
            value: s
          };
          if (i) {
            var c;
            return (c = r == null ? void 0 : r.map((g) => g.id === e.id ? a : g)) != null ? c : [];
          }
          return r != null && r.length ? [
            ...r,
            a
          ] : [
            a
          ];
        });
      };
    },
    createRow: (e, t) => {
      e.columnFilters = {}, e.columnFiltersMeta = {};
    },
    createTable: (e) => {
      e.setColumnFilters = (t) => {
        const n = e.getAllLeafColumns(), r = (o) => {
          var i;
          return (i = fe(t, o)) == null ? void 0 : i.filter((s) => {
            const l = n.find((a) => a.id === s.id);
            if (l) {
              const a = l.getFilterFn();
              if (Cn(a, s.value, l))
                return false;
            }
            return true;
          });
        };
        e.options.onColumnFiltersChange == null || e.options.onColumnFiltersChange(r);
      }, e.resetColumnFilters = (t) => {
        var n, r;
        e.setColumnFilters(t ? [] : (n = (r = e.initialState) == null ? void 0 : r.columnFilters) != null ? n : []);
      }, e.getPreFilteredRowModel = () => e.getCoreRowModel(), e.getFilteredRowModel = () => (!e._getFilteredRowModel && e.options.getFilteredRowModel && (e._getFilteredRowModel = e.options.getFilteredRowModel(e)), e.options.manualFiltering || !e._getFilteredRowModel ? e.getPreFilteredRowModel() : e._getFilteredRowModel());
    }
  };
  function Cn(e, t, n) {
    return (e && e.autoRemove ? e.autoRemove(t, n) : false) || typeof t > "u" || typeof t == "string" && !t;
  }
  const Zr = (e, t, n) => n.reduce((r, o) => {
    const i = o.getValue(e);
    return r + (typeof i == "number" ? i : 0);
  }, 0), Jr = (e, t, n) => {
    let r;
    return n.forEach((o) => {
      const i = o.getValue(e);
      i != null && (r > i || r === void 0 && i >= i) && (r = i);
    }), r;
  }, Qr = (e, t, n) => {
    let r;
    return n.forEach((o) => {
      const i = o.getValue(e);
      i != null && (r < i || r === void 0 && i >= i) && (r = i);
    }), r;
  }, eo = (e, t, n) => {
    let r, o;
    return n.forEach((i) => {
      const s = i.getValue(e);
      s != null && (r === void 0 ? s >= s && (r = o = s) : (r > s && (r = s), o < s && (o = s)));
    }), [
      r,
      o
    ];
  }, to = (e, t) => {
    let n = 0, r = 0;
    if (t.forEach((o) => {
      let i = o.getValue(e);
      i != null && (i = +i) >= i && (++n, r += i);
    }), n)
      return r / n;
  }, no = (e, t) => {
    if (!t.length)
      return;
    const n = t.map((i) => i.getValue(e));
    if (!Br(n))
      return;
    if (n.length === 1)
      return n[0];
    const r = Math.floor(n.length / 2), o = n.sort((i, s) => i - s);
    return n.length % 2 !== 0 ? o[r] : (o[r - 1] + o[r]) / 2;
  }, ro = (e, t) => Array.from(new Set(t.map((n) => n.getValue(e))).values()), oo = (e, t) => new Set(t.map((n) => n.getValue(e))).size, io = (e, t) => t.length, yt = {
    sum: Zr,
    min: Jr,
    max: Qr,
    extent: eo,
    mean: to,
    median: no,
    unique: ro,
    uniqueCount: oo,
    count: io
  }, so = {
    getDefaultColumnDef: () => ({
      aggregatedCell: (e) => {
        var t, n;
        return (t = (n = e.getValue()) == null || n.toString == null ? void 0 : n.toString()) != null ? t : null;
      },
      aggregationFn: "auto"
    }),
    getInitialState: (e) => ({
      grouping: [],
      ...e
    }),
    getDefaultOptions: (e) => ({
      onGroupingChange: U("grouping", e),
      groupedColumnMode: "reorder"
    }),
    createColumn: (e, t) => {
      e.toggleGrouping = () => {
        t.setGrouping((n) => n != null && n.includes(e.id) ? n.filter((r) => r !== e.id) : [
          ...n ?? [],
          e.id
        ]);
      }, e.getCanGroup = () => {
        var n, r;
        return ((n = e.columnDef.enableGrouping) != null ? n : true) && ((r = t.options.enableGrouping) != null ? r : true) && (!!e.accessorFn || !!e.columnDef.getGroupingValue);
      }, e.getIsGrouped = () => {
        var n;
        return (n = t.getState().grouping) == null ? void 0 : n.includes(e.id);
      }, e.getGroupedIndex = () => {
        var n;
        return (n = t.getState().grouping) == null ? void 0 : n.indexOf(e.id);
      }, e.getToggleGroupingHandler = () => {
        const n = e.getCanGroup();
        return () => {
          n && e.toggleGrouping();
        };
      }, e.getAutoAggregationFn = () => {
        const n = t.getCoreRowModel().flatRows[0], r = n == null ? void 0 : n.getValue(e.id);
        if (typeof r == "number")
          return yt.sum;
        if (Object.prototype.toString.call(r) === "[object Date]")
          return yt.extent;
      }, e.getAggregationFn = () => {
        var n, r;
        if (!e)
          throw new Error();
        return ft(e.columnDef.aggregationFn) ? e.columnDef.aggregationFn : e.columnDef.aggregationFn === "auto" ? e.getAutoAggregationFn() : (n = (r = t.options.aggregationFns) == null ? void 0 : r[e.columnDef.aggregationFn]) != null ? n : yt[e.columnDef.aggregationFn];
      };
    },
    createTable: (e) => {
      e.setGrouping = (t) => e.options.onGroupingChange == null ? void 0 : e.options.onGroupingChange(t), e.resetGrouping = (t) => {
        var n, r;
        e.setGrouping(t ? [] : (n = (r = e.initialState) == null ? void 0 : r.grouping) != null ? n : []);
      }, e.getPreGroupedRowModel = () => e.getFilteredRowModel(), e.getGroupedRowModel = () => (!e._getGroupedRowModel && e.options.getGroupedRowModel && (e._getGroupedRowModel = e.options.getGroupedRowModel(e)), e.options.manualGrouping || !e._getGroupedRowModel ? e.getPreGroupedRowModel() : e._getGroupedRowModel());
    },
    createRow: (e, t) => {
      e.getIsGrouped = () => !!e.groupingColumnId, e.getGroupingValue = (n) => {
        if (e._groupingValuesCache.hasOwnProperty(n))
          return e._groupingValuesCache[n];
        const r = t.getColumn(n);
        return r != null && r.columnDef.getGroupingValue ? (e._groupingValuesCache[n] = r.columnDef.getGroupingValue(e.original), e._groupingValuesCache[n]) : e.getValue(n);
      }, e._groupingValuesCache = {};
    },
    createCell: (e, t, n, r) => {
      e.getIsGrouped = () => t.getIsGrouped() && t.id === n.groupingColumnId, e.getIsPlaceholder = () => !e.getIsGrouped() && t.getIsGrouped(), e.getIsAggregated = () => {
        var o;
        return !e.getIsGrouped() && !e.getIsPlaceholder() && !!((o = n.subRows) != null && o.length);
      };
    }
  };
  function lo(e, t, n) {
    if (!(t != null && t.length) || !n)
      return e;
    const r = e.filter((i) => !t.includes(i.id));
    return n === "remove" ? r : [
      ...t.map((i) => e.find((s) => s.id === i)).filter(Boolean),
      ...r
    ];
  }
  const ao = {
    getInitialState: (e) => ({
      columnOrder: [],
      ...e
    }),
    getDefaultOptions: (e) => ({
      onColumnOrderChange: U("columnOrder", e)
    }),
    createColumn: (e, t) => {
      e.getIndex = y((n) => [
        Ae(t, n)
      ], (n) => n.findIndex((r) => r.id === e.id), E(t.options, "debugColumns")), e.getIsFirstColumn = (n) => {
        var r;
        return ((r = Ae(t, n)[0]) == null ? void 0 : r.id) === e.id;
      }, e.getIsLastColumn = (n) => {
        var r;
        const o = Ae(t, n);
        return ((r = o[o.length - 1]) == null ? void 0 : r.id) === e.id;
      };
    },
    createTable: (e) => {
      e.setColumnOrder = (t) => e.options.onColumnOrderChange == null ? void 0 : e.options.onColumnOrderChange(t), e.resetColumnOrder = (t) => {
        var n;
        e.setColumnOrder(t ? [] : (n = e.initialState.columnOrder) != null ? n : []);
      }, e._getOrderColumnsFn = y(() => [
        e.getState().columnOrder,
        e.getState().grouping,
        e.options.groupedColumnMode
      ], (t, n, r) => (o) => {
        let i = [];
        if (!(t != null && t.length))
          i = o;
        else {
          const s = [
            ...t
          ], l = [
            ...o
          ];
          for (; l.length && s.length; ) {
            const a = s.shift(), c = l.findIndex((g) => g.id === a);
            c > -1 && i.push(l.splice(c, 1)[0]);
          }
          i = [
            ...i,
            ...l
          ];
        }
        return lo(i, n, r);
      }, E(e.options, "debugTable"));
    }
  }, Et = () => ({
    left: [],
    right: []
  }), uo = {
    getInitialState: (e) => ({
      columnPinning: Et(),
      ...e
    }),
    getDefaultOptions: (e) => ({
      onColumnPinningChange: U("columnPinning", e)
    }),
    createColumn: (e, t) => {
      e.pin = (n) => {
        const r = e.getLeafColumns().map((o) => o.id).filter(Boolean);
        t.setColumnPinning((o) => {
          var i, s;
          if (n === "right") {
            var l, a;
            return {
              left: ((l = o == null ? void 0 : o.left) != null ? l : []).filter((p) => !(r != null && r.includes(p))),
              right: [
                ...((a = o == null ? void 0 : o.right) != null ? a : []).filter((p) => !(r != null && r.includes(p))),
                ...r
              ]
            };
          }
          if (n === "left") {
            var c, g;
            return {
              left: [
                ...((c = o == null ? void 0 : o.left) != null ? c : []).filter((p) => !(r != null && r.includes(p))),
                ...r
              ],
              right: ((g = o == null ? void 0 : o.right) != null ? g : []).filter((p) => !(r != null && r.includes(p)))
            };
          }
          return {
            left: ((i = o == null ? void 0 : o.left) != null ? i : []).filter((p) => !(r != null && r.includes(p))),
            right: ((s = o == null ? void 0 : o.right) != null ? s : []).filter((p) => !(r != null && r.includes(p)))
          };
        });
      }, e.getCanPin = () => e.getLeafColumns().some((r) => {
        var o, i, s;
        return ((o = r.columnDef.enablePinning) != null ? o : true) && ((i = (s = t.options.enableColumnPinning) != null ? s : t.options.enablePinning) != null ? i : true);
      }), e.getIsPinned = () => {
        const n = e.getLeafColumns().map((l) => l.id), { left: r, right: o } = t.getState().columnPinning, i = n.some((l) => r == null ? void 0 : r.includes(l)), s = n.some((l) => o == null ? void 0 : o.includes(l));
        return i ? "left" : s ? "right" : false;
      }, e.getPinnedIndex = () => {
        var n, r;
        const o = e.getIsPinned();
        return o ? (n = (r = t.getState().columnPinning) == null || (r = r[o]) == null ? void 0 : r.indexOf(e.id)) != null ? n : -1 : 0;
      };
    },
    createRow: (e, t) => {
      e.getCenterVisibleCells = y(() => [
        e._getAllVisibleCells(),
        t.getState().columnPinning.left,
        t.getState().columnPinning.right
      ], (n, r, o) => {
        const i = [
          ...r ?? [],
          ...o ?? []
        ];
        return n.filter((s) => !i.includes(s.column.id));
      }, E(t.options, "debugRows")), e.getLeftVisibleCells = y(() => [
        e._getAllVisibleCells(),
        t.getState().columnPinning.left
      ], (n, r) => (r ?? []).map((i) => n.find((s) => s.column.id === i)).filter(Boolean).map((i) => ({
        ...i,
        position: "left"
      })), E(t.options, "debugRows")), e.getRightVisibleCells = y(() => [
        e._getAllVisibleCells(),
        t.getState().columnPinning.right
      ], (n, r) => (r ?? []).map((i) => n.find((s) => s.column.id === i)).filter(Boolean).map((i) => ({
        ...i,
        position: "right"
      })), E(t.options, "debugRows"));
    },
    createTable: (e) => {
      e.setColumnPinning = (t) => e.options.onColumnPinningChange == null ? void 0 : e.options.onColumnPinningChange(t), e.resetColumnPinning = (t) => {
        var n, r;
        return e.setColumnPinning(t ? Et() : (n = (r = e.initialState) == null ? void 0 : r.columnPinning) != null ? n : Et());
      }, e.getIsSomeColumnsPinned = (t) => {
        var n;
        const r = e.getState().columnPinning;
        if (!t) {
          var o, i;
          return !!((o = r.left) != null && o.length || (i = r.right) != null && i.length);
        }
        return !!((n = r[t]) != null && n.length);
      }, e.getLeftLeafColumns = y(() => [
        e.getAllLeafColumns(),
        e.getState().columnPinning.left
      ], (t, n) => (n ?? []).map((r) => t.find((o) => o.id === r)).filter(Boolean), E(e.options, "debugColumns")), e.getRightLeafColumns = y(() => [
        e.getAllLeafColumns(),
        e.getState().columnPinning.right
      ], (t, n) => (n ?? []).map((r) => t.find((o) => o.id === r)).filter(Boolean), E(e.options, "debugColumns")), e.getCenterLeafColumns = y(() => [
        e.getAllLeafColumns(),
        e.getState().columnPinning.left,
        e.getState().columnPinning.right
      ], (t, n, r) => {
        const o = [
          ...n ?? [],
          ...r ?? []
        ];
        return t.filter((i) => !o.includes(i.id));
      }, E(e.options, "debugColumns"));
    }
  };
  function co(e) {
    return e || (typeof document < "u" ? document : null);
  }
  const nt = {
    size: 150,
    minSize: 20,
    maxSize: Number.MAX_SAFE_INTEGER
  }, Dt = () => ({
    startOffset: null,
    startSize: null,
    deltaOffset: null,
    deltaPercentage: null,
    isResizingColumn: false,
    columnSizingStart: []
  }), go = {
    getDefaultColumnDef: () => nt,
    getInitialState: (e) => ({
      columnSizing: {},
      columnSizingInfo: Dt(),
      ...e
    }),
    getDefaultOptions: (e) => ({
      columnResizeMode: "onEnd",
      columnResizeDirection: "ltr",
      onColumnSizingChange: U("columnSizing", e),
      onColumnSizingInfoChange: U("columnSizingInfo", e)
    }),
    createColumn: (e, t) => {
      e.getSize = () => {
        var n, r, o;
        const i = t.getState().columnSizing[e.id];
        return Math.min(Math.max((n = e.columnDef.minSize) != null ? n : nt.minSize, (r = i ?? e.columnDef.size) != null ? r : nt.size), (o = e.columnDef.maxSize) != null ? o : nt.maxSize);
      }, e.getStart = y((n) => [
        n,
        Ae(t, n),
        t.getState().columnSizing
      ], (n, r) => r.slice(0, e.getIndex(n)).reduce((o, i) => o + i.getSize(), 0), E(t.options, "debugColumns")), e.getAfter = y((n) => [
        n,
        Ae(t, n),
        t.getState().columnSizing
      ], (n, r) => r.slice(e.getIndex(n) + 1).reduce((o, i) => o + i.getSize(), 0), E(t.options, "debugColumns")), e.resetSize = () => {
        t.setColumnSizing((n) => {
          let { [e.id]: r, ...o } = n;
          return o;
        });
      }, e.getCanResize = () => {
        var n, r;
        return ((n = e.columnDef.enableResizing) != null ? n : true) && ((r = t.options.enableColumnResizing) != null ? r : true);
      }, e.getIsResizing = () => t.getState().columnSizingInfo.isResizingColumn === e.id;
    },
    createHeader: (e, t) => {
      e.getSize = () => {
        let n = 0;
        const r = (o) => {
          if (o.subHeaders.length)
            o.subHeaders.forEach(r);
          else {
            var i;
            n += (i = o.column.getSize()) != null ? i : 0;
          }
        };
        return r(e), n;
      }, e.getStart = () => {
        if (e.index > 0) {
          const n = e.headerGroup.headers[e.index - 1];
          return n.getStart() + n.getSize();
        }
        return 0;
      }, e.getResizeHandler = (n) => {
        const r = t.getColumn(e.column.id), o = r == null ? void 0 : r.getCanResize();
        return (i) => {
          if (!r || !o || (i.persist == null || i.persist(), _t(i) && i.touches && i.touches.length > 1))
            return;
          const s = e.getSize(), l = e ? e.getLeafHeaders().map((x) => [
            x.column.id,
            x.column.getSize()
          ]) : [
            [
              r.id,
              r.getSize()
            ]
          ], a = _t(i) ? Math.round(i.touches[0].clientX) : i.clientX, c = {}, g = (x, S) => {
            typeof S == "number" && (t.setColumnSizingInfo((C) => {
              var M, b;
              const R = t.options.columnResizeDirection === "rtl" ? -1 : 1, D = (S - ((M = C == null ? void 0 : C.startOffset) != null ? M : 0)) * R, k = Math.max(D / ((b = C == null ? void 0 : C.startSize) != null ? b : 0), -0.999999);
              return C.columnSizingStart.forEach((P) => {
                let [N, $] = P;
                c[N] = Math.round(Math.max($ + $ * k, 0) * 100) / 100;
              }), {
                ...C,
                deltaOffset: D,
                deltaPercentage: k
              };
            }), (t.options.columnResizeMode === "onChange" || x === "end") && t.setColumnSizing((C) => ({
              ...C,
              ...c
            })));
          }, p = (x) => g("move", x), f = (x) => {
            g("end", x), t.setColumnSizingInfo((S) => ({
              ...S,
              isResizingColumn: false,
              startOffset: null,
              startSize: null,
              deltaOffset: null,
              deltaPercentage: null,
              columnSizingStart: []
            }));
          }, u = co(n), v = {
            moveHandler: (x) => p(x.clientX),
            upHandler: (x) => {
              u == null ? void 0 : u.removeEventListener("mousemove", v.moveHandler), u == null ? void 0 : u.removeEventListener("mouseup", v.upHandler), f(x.clientX);
            }
          }, h = {
            moveHandler: (x) => (x.cancelable && (x.preventDefault(), x.stopPropagation()), p(x.touches[0].clientX), false),
            upHandler: (x) => {
              var S;
              u == null ? void 0 : u.removeEventListener("touchmove", h.moveHandler), u == null ? void 0 : u.removeEventListener("touchend", h.upHandler), x.cancelable && (x.preventDefault(), x.stopPropagation()), f((S = x.touches[0]) == null ? void 0 : S.clientX);
            }
          }, w = fo() ? {
            passive: false
          } : false;
          _t(i) ? (u == null ? void 0 : u.addEventListener("touchmove", h.moveHandler, w), u == null ? void 0 : u.addEventListener("touchend", h.upHandler, w)) : (u == null ? void 0 : u.addEventListener("mousemove", v.moveHandler, w), u == null ? void 0 : u.addEventListener("mouseup", v.upHandler, w)), t.setColumnSizingInfo((x) => ({
            ...x,
            startOffset: a,
            startSize: s,
            deltaOffset: 0,
            deltaPercentage: 0,
            columnSizingStart: l,
            isResizingColumn: r.id
          }));
        };
      };
    },
    createTable: (e) => {
      e.setColumnSizing = (t) => e.options.onColumnSizingChange == null ? void 0 : e.options.onColumnSizingChange(t), e.setColumnSizingInfo = (t) => e.options.onColumnSizingInfoChange == null ? void 0 : e.options.onColumnSizingInfoChange(t), e.resetColumnSizing = (t) => {
        var n;
        e.setColumnSizing(t ? {} : (n = e.initialState.columnSizing) != null ? n : {});
      }, e.resetHeaderSizeInfo = (t) => {
        var n;
        e.setColumnSizingInfo(t ? Dt() : (n = e.initialState.columnSizingInfo) != null ? n : Dt());
      }, e.getTotalSize = () => {
        var t, n;
        return (t = (n = e.getHeaderGroups()[0]) == null ? void 0 : n.headers.reduce((r, o) => r + o.getSize(), 0)) != null ? t : 0;
      }, e.getLeftTotalSize = () => {
        var t, n;
        return (t = (n = e.getLeftHeaderGroups()[0]) == null ? void 0 : n.headers.reduce((r, o) => r + o.getSize(), 0)) != null ? t : 0;
      }, e.getCenterTotalSize = () => {
        var t, n;
        return (t = (n = e.getCenterHeaderGroups()[0]) == null ? void 0 : n.headers.reduce((r, o) => r + o.getSize(), 0)) != null ? t : 0;
      }, e.getRightTotalSize = () => {
        var t, n;
        return (t = (n = e.getRightHeaderGroups()[0]) == null ? void 0 : n.headers.reduce((r, o) => r + o.getSize(), 0)) != null ? t : 0;
      };
    }
  };
  let rt = null;
  function fo() {
    if (typeof rt == "boolean")
      return rt;
    let e = false;
    try {
      const t = {
        get passive() {
          return e = true, false;
        }
      }, n = () => {
      };
      window.addEventListener("test", n, t), window.removeEventListener("test", n);
    } catch {
      e = false;
    }
    return rt = e, rt;
  }
  function _t(e) {
    return e.type === "touchstart";
  }
  const po = {
    getInitialState: (e) => ({
      columnVisibility: {},
      ...e
    }),
    getDefaultOptions: (e) => ({
      onColumnVisibilityChange: U("columnVisibility", e)
    }),
    createColumn: (e, t) => {
      e.toggleVisibility = (n) => {
        e.getCanHide() && t.setColumnVisibility((r) => ({
          ...r,
          [e.id]: n ?? !e.getIsVisible()
        }));
      }, e.getIsVisible = () => {
        var n, r;
        const o = e.columns;
        return (n = o.length ? o.some((i) => i.getIsVisible()) : (r = t.getState().columnVisibility) == null ? void 0 : r[e.id]) != null ? n : true;
      }, e.getCanHide = () => {
        var n, r;
        return ((n = e.columnDef.enableHiding) != null ? n : true) && ((r = t.options.enableHiding) != null ? r : true);
      }, e.getToggleVisibilityHandler = () => (n) => {
        e.toggleVisibility == null || e.toggleVisibility(n.target.checked);
      };
    },
    createRow: (e, t) => {
      e._getAllVisibleCells = y(() => [
        e.getAllCells(),
        t.getState().columnVisibility
      ], (n) => n.filter((r) => r.column.getIsVisible()), E(t.options, "debugRows")), e.getVisibleCells = y(() => [
        e.getLeftVisibleCells(),
        e.getCenterVisibleCells(),
        e.getRightVisibleCells()
      ], (n, r, o) => [
        ...n,
        ...r,
        ...o
      ], E(t.options, "debugRows"));
    },
    createTable: (e) => {
      const t = (n, r) => y(() => [
        r(),
        r().filter((o) => o.getIsVisible()).map((o) => o.id).join("_")
      ], (o) => o.filter((i) => i.getIsVisible == null ? void 0 : i.getIsVisible()), E(e.options, "debugColumns"));
      e.getVisibleFlatColumns = t("getVisibleFlatColumns", () => e.getAllFlatColumns()), e.getVisibleLeafColumns = t("getVisibleLeafColumns", () => e.getAllLeafColumns()), e.getLeftVisibleLeafColumns = t("getLeftVisibleLeafColumns", () => e.getLeftLeafColumns()), e.getRightVisibleLeafColumns = t("getRightVisibleLeafColumns", () => e.getRightLeafColumns()), e.getCenterVisibleLeafColumns = t("getCenterVisibleLeafColumns", () => e.getCenterLeafColumns()), e.setColumnVisibility = (n) => e.options.onColumnVisibilityChange == null ? void 0 : e.options.onColumnVisibilityChange(n), e.resetColumnVisibility = (n) => {
        var r;
        e.setColumnVisibility(n ? {} : (r = e.initialState.columnVisibility) != null ? r : {});
      }, e.toggleAllColumnsVisible = (n) => {
        var r;
        n = (r = n) != null ? r : !e.getIsAllColumnsVisible(), e.setColumnVisibility(e.getAllLeafColumns().reduce((o, i) => ({
          ...o,
          [i.id]: n || !(i.getCanHide != null && i.getCanHide())
        }), {}));
      }, e.getIsAllColumnsVisible = () => !e.getAllLeafColumns().some((n) => !(n.getIsVisible != null && n.getIsVisible())), e.getIsSomeColumnsVisible = () => e.getAllLeafColumns().some((n) => n.getIsVisible == null ? void 0 : n.getIsVisible()), e.getToggleAllColumnsVisibilityHandler = () => (n) => {
        var r;
        e.toggleAllColumnsVisible((r = n.target) == null ? void 0 : r.checked);
      };
    }
  };
  function Ae(e, t) {
    return t ? t === "center" ? e.getCenterVisibleLeafColumns() : t === "left" ? e.getLeftVisibleLeafColumns() : e.getRightVisibleLeafColumns() : e.getVisibleLeafColumns();
  }
  const ho = {
    createTable: (e) => {
      e._getGlobalFacetedRowModel = e.options.getFacetedRowModel && e.options.getFacetedRowModel(e, "__global__"), e.getGlobalFacetedRowModel = () => e.options.manualFiltering || !e._getGlobalFacetedRowModel ? e.getPreFilteredRowModel() : e._getGlobalFacetedRowModel(), e._getGlobalFacetedUniqueValues = e.options.getFacetedUniqueValues && e.options.getFacetedUniqueValues(e, "__global__"), e.getGlobalFacetedUniqueValues = () => e._getGlobalFacetedUniqueValues ? e._getGlobalFacetedUniqueValues() : /* @__PURE__ */ new Map(), e._getGlobalFacetedMinMaxValues = e.options.getFacetedMinMaxValues && e.options.getFacetedMinMaxValues(e, "__global__"), e.getGlobalFacetedMinMaxValues = () => {
        if (e._getGlobalFacetedMinMaxValues)
          return e._getGlobalFacetedMinMaxValues();
      };
    }
  }, mo = {
    getInitialState: (e) => ({
      globalFilter: void 0,
      ...e
    }),
    getDefaultOptions: (e) => ({
      onGlobalFilterChange: U("globalFilter", e),
      globalFilterFn: "auto",
      getColumnCanGlobalFilter: (t) => {
        var n;
        const r = (n = e.getCoreRowModel().flatRows[0]) == null || (n = n._getAllCellsByColumnId()[t.id]) == null ? void 0 : n.getValue();
        return typeof r == "string" || typeof r == "number";
      }
    }),
    createColumn: (e, t) => {
      e.getCanGlobalFilter = () => {
        var n, r, o, i;
        return ((n = e.columnDef.enableGlobalFilter) != null ? n : true) && ((r = t.options.enableGlobalFilter) != null ? r : true) && ((o = t.options.enableFilters) != null ? o : true) && ((i = t.options.getColumnCanGlobalFilter == null ? void 0 : t.options.getColumnCanGlobalFilter(e)) != null ? i : true) && !!e.accessorFn;
      };
    },
    createTable: (e) => {
      e.getGlobalAutoFilterFn = () => oe.includesString, e.getGlobalFilterFn = () => {
        var t, n;
        const { globalFilterFn: r } = e.options;
        return ft(r) ? r : r === "auto" ? e.getGlobalAutoFilterFn() : (t = (n = e.options.filterFns) == null ? void 0 : n[r]) != null ? t : oe[r];
      }, e.setGlobalFilter = (t) => {
        e.options.onGlobalFilterChange == null || e.options.onGlobalFilterChange(t);
      }, e.resetGlobalFilter = (t) => {
        e.setGlobalFilter(t ? void 0 : e.initialState.globalFilter);
      };
    }
  }, vo = {
    getInitialState: (e) => ({
      expanded: {},
      ...e
    }),
    getDefaultOptions: (e) => ({
      onExpandedChange: U("expanded", e),
      paginateExpandedRows: true
    }),
    createTable: (e) => {
      let t = false, n = false;
      e._autoResetExpanded = () => {
        var r, o;
        if (!t) {
          e._queue(() => {
            t = true;
          });
          return;
        }
        if ((r = (o = e.options.autoResetAll) != null ? o : e.options.autoResetExpanded) != null ? r : !e.options.manualExpanding) {
          if (n)
            return;
          n = true, e._queue(() => {
            e.resetExpanded(), n = false;
          });
        }
      }, e.setExpanded = (r) => e.options.onExpandedChange == null ? void 0 : e.options.onExpandedChange(r), e.toggleAllRowsExpanded = (r) => {
        r ?? !e.getIsAllRowsExpanded() ? e.setExpanded(true) : e.setExpanded({});
      }, e.resetExpanded = (r) => {
        var o, i;
        e.setExpanded(r ? {} : (o = (i = e.initialState) == null ? void 0 : i.expanded) != null ? o : {});
      }, e.getCanSomeRowsExpand = () => e.getPrePaginationRowModel().flatRows.some((r) => r.getCanExpand()), e.getToggleAllRowsExpandedHandler = () => (r) => {
        r.persist == null || r.persist(), e.toggleAllRowsExpanded();
      }, e.getIsSomeRowsExpanded = () => {
        const r = e.getState().expanded;
        return r === true || Object.values(r).some(Boolean);
      }, e.getIsAllRowsExpanded = () => {
        const r = e.getState().expanded;
        return typeof r == "boolean" ? r === true : !(!Object.keys(r).length || e.getRowModel().flatRows.some((o) => !o.getIsExpanded()));
      }, e.getExpandedDepth = () => {
        let r = 0;
        return (e.getState().expanded === true ? Object.keys(e.getRowModel().rowsById) : Object.keys(e.getState().expanded)).forEach((i) => {
          const s = i.split(".");
          r = Math.max(r, s.length);
        }), r;
      }, e.getPreExpandedRowModel = () => e.getSortedRowModel(), e.getExpandedRowModel = () => (!e._getExpandedRowModel && e.options.getExpandedRowModel && (e._getExpandedRowModel = e.options.getExpandedRowModel(e)), e.options.manualExpanding || !e._getExpandedRowModel ? e.getPreExpandedRowModel() : e._getExpandedRowModel());
    },
    createRow: (e, t) => {
      e.toggleExpanded = (n) => {
        t.setExpanded((r) => {
          var o;
          const i = r === true ? true : !!(r != null && r[e.id]);
          let s = {};
          if (r === true ? Object.keys(t.getRowModel().rowsById).forEach((l) => {
            s[l] = true;
          }) : s = r, n = (o = n) != null ? o : !i, !i && n)
            return {
              ...s,
              [e.id]: true
            };
          if (i && !n) {
            const { [e.id]: l, ...a } = s;
            return a;
          }
          return r;
        });
      }, e.getIsExpanded = () => {
        var n;
        const r = t.getState().expanded;
        return !!((n = t.options.getIsRowExpanded == null ? void 0 : t.options.getIsRowExpanded(e)) != null ? n : r === true || (r == null ? void 0 : r[e.id]));
      }, e.getCanExpand = () => {
        var n, r, o;
        return (n = t.options.getRowCanExpand == null ? void 0 : t.options.getRowCanExpand(e)) != null ? n : ((r = t.options.enableExpanding) != null ? r : true) && !!((o = e.subRows) != null && o.length);
      }, e.getIsAllParentsExpanded = () => {
        let n = true, r = e;
        for (; n && r.parentId; )
          r = t.getRow(r.parentId, true), n = r.getIsExpanded();
        return n;
      }, e.getToggleExpandedHandler = () => {
        const n = e.getCanExpand();
        return () => {
          n && e.toggleExpanded();
        };
      };
    }
  }, At = 0, Vt = 10, Ft = () => ({
    pageIndex: At,
    pageSize: Vt
  }), xo = {
    getInitialState: (e) => ({
      ...e,
      pagination: {
        ...Ft(),
        ...e == null ? void 0 : e.pagination
      }
    }),
    getDefaultOptions: (e) => ({
      onPaginationChange: U("pagination", e)
    }),
    createTable: (e) => {
      let t = false, n = false;
      e._autoResetPageIndex = () => {
        var r, o;
        if (!t) {
          e._queue(() => {
            t = true;
          });
          return;
        }
        if ((r = (o = e.options.autoResetAll) != null ? o : e.options.autoResetPageIndex) != null ? r : !e.options.manualPagination) {
          if (n)
            return;
          n = true, e._queue(() => {
            e.resetPageIndex(), n = false;
          });
        }
      }, e.setPagination = (r) => {
        const o = (i) => fe(r, i);
        return e.options.onPaginationChange == null ? void 0 : e.options.onPaginationChange(o);
      }, e.resetPagination = (r) => {
        var o;
        e.setPagination(r ? Ft() : (o = e.initialState.pagination) != null ? o : Ft());
      }, e.setPageIndex = (r) => {
        e.setPagination((o) => {
          let i = fe(r, o.pageIndex);
          const s = typeof e.options.pageCount > "u" || e.options.pageCount === -1 ? Number.MAX_SAFE_INTEGER : e.options.pageCount - 1;
          return i = Math.max(0, Math.min(i, s)), {
            ...o,
            pageIndex: i
          };
        });
      }, e.resetPageIndex = (r) => {
        var o, i;
        e.setPageIndex(r ? At : (o = (i = e.initialState) == null || (i = i.pagination) == null ? void 0 : i.pageIndex) != null ? o : At);
      }, e.resetPageSize = (r) => {
        var o, i;
        e.setPageSize(r ? Vt : (o = (i = e.initialState) == null || (i = i.pagination) == null ? void 0 : i.pageSize) != null ? o : Vt);
      }, e.setPageSize = (r) => {
        e.setPagination((o) => {
          const i = Math.max(1, fe(r, o.pageSize)), s = o.pageSize * o.pageIndex, l = Math.floor(s / i);
          return {
            ...o,
            pageIndex: l,
            pageSize: i
          };
        });
      }, e.setPageCount = (r) => e.setPagination((o) => {
        var i;
        let s = fe(r, (i = e.options.pageCount) != null ? i : -1);
        return typeof s == "number" && (s = Math.max(-1, s)), {
          ...o,
          pageCount: s
        };
      }), e.getPageOptions = y(() => [
        e.getPageCount()
      ], (r) => {
        let o = [];
        return r && r > 0 && (o = [
          ...new Array(r)
        ].fill(null).map((i, s) => s)), o;
      }, E(e.options, "debugTable")), e.getCanPreviousPage = () => e.getState().pagination.pageIndex > 0, e.getCanNextPage = () => {
        const { pageIndex: r } = e.getState().pagination, o = e.getPageCount();
        return o === -1 ? true : o === 0 ? false : r < o - 1;
      }, e.previousPage = () => e.setPageIndex((r) => r - 1), e.nextPage = () => e.setPageIndex((r) => r + 1), e.firstPage = () => e.setPageIndex(0), e.lastPage = () => e.setPageIndex(e.getPageCount() - 1), e.getPrePaginationRowModel = () => e.getExpandedRowModel(), e.getPaginationRowModel = () => (!e._getPaginationRowModel && e.options.getPaginationRowModel && (e._getPaginationRowModel = e.options.getPaginationRowModel(e)), e.options.manualPagination || !e._getPaginationRowModel ? e.getPrePaginationRowModel() : e._getPaginationRowModel()), e.getPageCount = () => {
        var r;
        return (r = e.options.pageCount) != null ? r : Math.ceil(e.getRowCount() / e.getState().pagination.pageSize);
      }, e.getRowCount = () => {
        var r;
        return (r = e.options.rowCount) != null ? r : e.getPrePaginationRowModel().rows.length;
      };
    }
  }, Mt = () => ({
    top: [],
    bottom: []
  }), wo = {
    getInitialState: (e) => ({
      rowPinning: Mt(),
      ...e
    }),
    getDefaultOptions: (e) => ({
      onRowPinningChange: U("rowPinning", e)
    }),
    createRow: (e, t) => {
      e.pin = (n, r, o) => {
        const i = r ? e.getLeafRows().map((a) => {
          let { id: c } = a;
          return c;
        }) : [], s = o ? e.getParentRows().map((a) => {
          let { id: c } = a;
          return c;
        }) : [], l = /* @__PURE__ */ new Set([
          ...s,
          e.id,
          ...i
        ]);
        t.setRowPinning((a) => {
          var c, g;
          if (n === "bottom") {
            var p, f;
            return {
              top: ((p = a == null ? void 0 : a.top) != null ? p : []).filter((h) => !(l != null && l.has(h))),
              bottom: [
                ...((f = a == null ? void 0 : a.bottom) != null ? f : []).filter((h) => !(l != null && l.has(h))),
                ...Array.from(l)
              ]
            };
          }
          if (n === "top") {
            var u, v;
            return {
              top: [
                ...((u = a == null ? void 0 : a.top) != null ? u : []).filter((h) => !(l != null && l.has(h))),
                ...Array.from(l)
              ],
              bottom: ((v = a == null ? void 0 : a.bottom) != null ? v : []).filter((h) => !(l != null && l.has(h)))
            };
          }
          return {
            top: ((c = a == null ? void 0 : a.top) != null ? c : []).filter((h) => !(l != null && l.has(h))),
            bottom: ((g = a == null ? void 0 : a.bottom) != null ? g : []).filter((h) => !(l != null && l.has(h)))
          };
        });
      }, e.getCanPin = () => {
        var n;
        const { enableRowPinning: r, enablePinning: o } = t.options;
        return typeof r == "function" ? r(e) : (n = r ?? o) != null ? n : true;
      }, e.getIsPinned = () => {
        const n = [
          e.id
        ], { top: r, bottom: o } = t.getState().rowPinning, i = n.some((l) => r == null ? void 0 : r.includes(l)), s = n.some((l) => o == null ? void 0 : o.includes(l));
        return i ? "top" : s ? "bottom" : false;
      }, e.getPinnedIndex = () => {
        var n, r;
        const o = e.getIsPinned();
        if (!o)
          return -1;
        const i = (n = o === "top" ? t.getTopRows() : t.getBottomRows()) == null ? void 0 : n.map((s) => {
          let { id: l } = s;
          return l;
        });
        return (r = i == null ? void 0 : i.indexOf(e.id)) != null ? r : -1;
      };
    },
    createTable: (e) => {
      e.setRowPinning = (t) => e.options.onRowPinningChange == null ? void 0 : e.options.onRowPinningChange(t), e.resetRowPinning = (t) => {
        var n, r;
        return e.setRowPinning(t ? Mt() : (n = (r = e.initialState) == null ? void 0 : r.rowPinning) != null ? n : Mt());
      }, e.getIsSomeRowsPinned = (t) => {
        var n;
        const r = e.getState().rowPinning;
        if (!t) {
          var o, i;
          return !!((o = r.top) != null && o.length || (i = r.bottom) != null && i.length);
        }
        return !!((n = r[t]) != null && n.length);
      }, e._getPinnedRows = (t, n, r) => {
        var o;
        return ((o = e.options.keepPinnedRows) == null || o ? (n ?? []).map((s) => {
          const l = e.getRow(s, true);
          return l.getIsAllParentsExpanded() ? l : null;
        }) : (n ?? []).map((s) => t.find((l) => l.id === s))).filter(Boolean).map((s) => ({
          ...s,
          position: r
        }));
      }, e.getTopRows = y(() => [
        e.getRowModel().rows,
        e.getState().rowPinning.top
      ], (t, n) => e._getPinnedRows(t, n, "top"), E(e.options, "debugRows")), e.getBottomRows = y(() => [
        e.getRowModel().rows,
        e.getState().rowPinning.bottom
      ], (t, n) => e._getPinnedRows(t, n, "bottom"), E(e.options, "debugRows")), e.getCenterRows = y(() => [
        e.getRowModel().rows,
        e.getState().rowPinning.top,
        e.getState().rowPinning.bottom
      ], (t, n, r) => {
        const o = /* @__PURE__ */ new Set([
          ...n ?? [],
          ...r ?? []
        ]);
        return t.filter((i) => !o.has(i.id));
      }, E(e.options, "debugRows"));
    }
  }, So = {
    getInitialState: (e) => ({
      rowSelection: {},
      ...e
    }),
    getDefaultOptions: (e) => ({
      onRowSelectionChange: U("rowSelection", e),
      enableRowSelection: true,
      enableMultiRowSelection: true,
      enableSubRowSelection: true
    }),
    createTable: (e) => {
      e.setRowSelection = (t) => e.options.onRowSelectionChange == null ? void 0 : e.options.onRowSelectionChange(t), e.resetRowSelection = (t) => {
        var n;
        return e.setRowSelection(t ? {} : (n = e.initialState.rowSelection) != null ? n : {});
      }, e.toggleAllRowsSelected = (t) => {
        e.setRowSelection((n) => {
          t = typeof t < "u" ? t : !e.getIsAllRowsSelected();
          const r = {
            ...n
          }, o = e.getPreGroupedRowModel().flatRows;
          return t ? o.forEach((i) => {
            i.getCanSelect() && (r[i.id] = true);
          }) : o.forEach((i) => {
            delete r[i.id];
          }), r;
        });
      }, e.toggleAllPageRowsSelected = (t) => e.setRowSelection((n) => {
        const r = typeof t < "u" ? t : !e.getIsAllPageRowsSelected(), o = {
          ...n
        };
        return e.getRowModel().rows.forEach((i) => {
          Lt(o, i.id, r, true, e);
        }), o;
      }), e.getPreSelectedRowModel = () => e.getCoreRowModel(), e.getSelectedRowModel = y(() => [
        e.getState().rowSelection,
        e.getCoreRowModel()
      ], (t, n) => Object.keys(t).length ? kt(e, n) : {
        rows: [],
        flatRows: [],
        rowsById: {}
      }, E(e.options, "debugTable")), e.getFilteredSelectedRowModel = y(() => [
        e.getState().rowSelection,
        e.getFilteredRowModel()
      ], (t, n) => Object.keys(t).length ? kt(e, n) : {
        rows: [],
        flatRows: [],
        rowsById: {}
      }, E(e.options, "debugTable")), e.getGroupedSelectedRowModel = y(() => [
        e.getState().rowSelection,
        e.getSortedRowModel()
      ], (t, n) => Object.keys(t).length ? kt(e, n) : {
        rows: [],
        flatRows: [],
        rowsById: {}
      }, E(e.options, "debugTable")), e.getIsAllRowsSelected = () => {
        const t = e.getFilteredRowModel().flatRows, { rowSelection: n } = e.getState();
        let r = !!(t.length && Object.keys(n).length);
        return r && t.some((o) => o.getCanSelect() && !n[o.id]) && (r = false), r;
      }, e.getIsAllPageRowsSelected = () => {
        const t = e.getPaginationRowModel().flatRows.filter((o) => o.getCanSelect()), { rowSelection: n } = e.getState();
        let r = !!t.length;
        return r && t.some((o) => !n[o.id]) && (r = false), r;
      }, e.getIsSomeRowsSelected = () => {
        var t;
        const n = Object.keys((t = e.getState().rowSelection) != null ? t : {}).length;
        return n > 0 && n < e.getFilteredRowModel().flatRows.length;
      }, e.getIsSomePageRowsSelected = () => {
        const t = e.getPaginationRowModel().flatRows;
        return e.getIsAllPageRowsSelected() ? false : t.filter((n) => n.getCanSelect()).some((n) => n.getIsSelected() || n.getIsSomeSelected());
      }, e.getToggleAllRowsSelectedHandler = () => (t) => {
        e.toggleAllRowsSelected(t.target.checked);
      }, e.getToggleAllPageRowsSelectedHandler = () => (t) => {
        e.toggleAllPageRowsSelected(t.target.checked);
      };
    },
    createRow: (e, t) => {
      e.toggleSelected = (n, r) => {
        const o = e.getIsSelected();
        t.setRowSelection((i) => {
          var s;
          if (n = typeof n < "u" ? n : !o, e.getCanSelect() && o === n)
            return i;
          const l = {
            ...i
          };
          return Lt(l, e.id, n, (s = r == null ? void 0 : r.selectChildren) != null ? s : true, t), l;
        });
      }, e.getIsSelected = () => {
        const { rowSelection: n } = t.getState();
        return qt(e, n);
      }, e.getIsSomeSelected = () => {
        const { rowSelection: n } = t.getState();
        return jt(e, n) === "some";
      }, e.getIsAllSubRowsSelected = () => {
        const { rowSelection: n } = t.getState();
        return jt(e, n) === "all";
      }, e.getCanSelect = () => {
        var n;
        return typeof t.options.enableRowSelection == "function" ? t.options.enableRowSelection(e) : (n = t.options.enableRowSelection) != null ? n : true;
      }, e.getCanSelectSubRows = () => {
        var n;
        return typeof t.options.enableSubRowSelection == "function" ? t.options.enableSubRowSelection(e) : (n = t.options.enableSubRowSelection) != null ? n : true;
      }, e.getCanMultiSelect = () => {
        var n;
        return typeof t.options.enableMultiRowSelection == "function" ? t.options.enableMultiRowSelection(e) : (n = t.options.enableMultiRowSelection) != null ? n : true;
      }, e.getToggleSelectedHandler = () => {
        const n = e.getCanSelect();
        return (r) => {
          var o;
          n && e.toggleSelected((o = r.target) == null ? void 0 : o.checked);
        };
      };
    }
  }, Lt = (e, t, n, r, o) => {
    var i;
    const s = o.getRow(t, true);
    n ? (s.getCanMultiSelect() || Object.keys(e).forEach((l) => delete e[l]), s.getCanSelect() && (e[t] = true)) : delete e[t], r && (i = s.subRows) != null && i.length && s.getCanSelectSubRows() && s.subRows.forEach((l) => Lt(e, l.id, n, r, o));
  };
  function kt(e, t) {
    const n = e.getState().rowSelection, r = [], o = {}, i = function(s, l) {
      return s.map((a) => {
        var c;
        const g = qt(a, n);
        if (g && (r.push(a), o[a.id] = a), (c = a.subRows) != null && c.length && (a = {
          ...a,
          subRows: i(a.subRows)
        }), g)
          return a;
      }).filter(Boolean);
    };
    return {
      rows: i(t.rows),
      flatRows: r,
      rowsById: o
    };
  }
  function qt(e, t) {
    var n;
    return (n = t[e.id]) != null ? n : false;
  }
  function jt(e, t, n) {
    var r;
    if (!((r = e.subRows) != null && r.length))
      return false;
    let o = true, i = false;
    return e.subRows.forEach((s) => {
      if (!(i && !o) && (s.getCanSelect() && (qt(s, t) ? i = true : o = false), s.subRows && s.subRows.length)) {
        const l = jt(s, t);
        l === "all" ? i = true : (l === "some" && (i = true), o = false);
      }
    }), o ? "all" : i ? "some" : false;
  }
  const Tt = /([0-9]+)/gm, Co = (e, t, n) => qn(pe(e.getValue(n)).toLowerCase(), pe(t.getValue(n)).toLowerCase()), Ro = (e, t, n) => qn(pe(e.getValue(n)), pe(t.getValue(n))), bo = (e, t, n) => Xt(pe(e.getValue(n)).toLowerCase(), pe(t.getValue(n)).toLowerCase()), yo = (e, t, n) => Xt(pe(e.getValue(n)), pe(t.getValue(n))), Eo = (e, t, n) => {
    const r = e.getValue(n), o = t.getValue(n);
    return r > o ? 1 : r < o ? -1 : 0;
  }, Do = (e, t, n) => Xt(e.getValue(n), t.getValue(n));
  function Xt(e, t) {
    return e === t ? 0 : e > t ? 1 : -1;
  }
  function pe(e) {
    return typeof e == "number" ? isNaN(e) || e === 1 / 0 || e === -1 / 0 ? "" : String(e) : typeof e == "string" ? e : "";
  }
  function qn(e, t) {
    const n = e.split(Tt).filter(Boolean), r = t.split(Tt).filter(Boolean);
    for (; n.length && r.length; ) {
      const o = n.shift(), i = r.shift(), s = parseInt(o, 10), l = parseInt(i, 10), a = [
        s,
        l
      ].sort();
      if (isNaN(a[0])) {
        if (o > i)
          return 1;
        if (i > o)
          return -1;
        continue;
      }
      if (isNaN(a[1]))
        return isNaN(s) ? -1 : 1;
      if (s > l)
        return 1;
      if (l > s)
        return -1;
    }
    return n.length - r.length;
  }
  const Ne = {
    alphanumeric: Co,
    alphanumericCaseSensitive: Ro,
    text: bo,
    textCaseSensitive: yo,
    datetime: Eo,
    basic: Do
  }, _o = {
    getInitialState: (e) => ({
      sorting: [],
      ...e
    }),
    getDefaultColumnDef: () => ({
      sortingFn: "auto",
      sortUndefined: 1
    }),
    getDefaultOptions: (e) => ({
      onSortingChange: U("sorting", e),
      isMultiSortEvent: (t) => t.shiftKey
    }),
    createColumn: (e, t) => {
      e.getAutoSortingFn = () => {
        const n = t.getFilteredRowModel().flatRows.slice(10);
        let r = false;
        for (const o of n) {
          const i = o == null ? void 0 : o.getValue(e.id);
          if (Object.prototype.toString.call(i) === "[object Date]")
            return Ne.datetime;
          if (typeof i == "string" && (r = true, i.split(Tt).length > 1))
            return Ne.alphanumeric;
        }
        return r ? Ne.text : Ne.basic;
      }, e.getAutoSortDir = () => {
        const n = t.getFilteredRowModel().flatRows[0];
        return typeof (n == null ? void 0 : n.getValue(e.id)) == "string" ? "asc" : "desc";
      }, e.getSortingFn = () => {
        var n, r;
        if (!e)
          throw new Error();
        return ft(e.columnDef.sortingFn) ? e.columnDef.sortingFn : e.columnDef.sortingFn === "auto" ? e.getAutoSortingFn() : (n = (r = t.options.sortingFns) == null ? void 0 : r[e.columnDef.sortingFn]) != null ? n : Ne[e.columnDef.sortingFn];
      }, e.toggleSorting = (n, r) => {
        const o = e.getNextSortingOrder(), i = typeof n < "u" && n !== null;
        t.setSorting((s) => {
          const l = s == null ? void 0 : s.find((u) => u.id === e.id), a = s == null ? void 0 : s.findIndex((u) => u.id === e.id);
          let c = [], g, p = i ? n : o === "desc";
          if (s != null && s.length && e.getCanMultiSort() && r ? l ? g = "toggle" : g = "add" : s != null && s.length && a !== s.length - 1 ? g = "replace" : l ? g = "toggle" : g = "replace", g === "toggle" && (i || o || (g = "remove")), g === "add") {
            var f;
            c = [
              ...s,
              {
                id: e.id,
                desc: p
              }
            ], c.splice(0, c.length - ((f = t.options.maxMultiSortColCount) != null ? f : Number.MAX_SAFE_INTEGER));
          } else
            g === "toggle" ? c = s.map((u) => u.id === e.id ? {
              ...u,
              desc: p
            } : u) : g === "remove" ? c = s.filter((u) => u.id !== e.id) : c = [
              {
                id: e.id,
                desc: p
              }
            ];
          return c;
        });
      }, e.getFirstSortDir = () => {
        var n, r;
        return ((n = (r = e.columnDef.sortDescFirst) != null ? r : t.options.sortDescFirst) != null ? n : e.getAutoSortDir() === "desc") ? "desc" : "asc";
      }, e.getNextSortingOrder = (n) => {
        var r, o;
        const i = e.getFirstSortDir(), s = e.getIsSorted();
        return s ? s !== i && ((r = t.options.enableSortingRemoval) == null || r) && (!(n && (o = t.options.enableMultiRemove) != null) || o) ? false : s === "desc" ? "asc" : "desc" : i;
      }, e.getCanSort = () => {
        var n, r;
        return ((n = e.columnDef.enableSorting) != null ? n : true) && ((r = t.options.enableSorting) != null ? r : true) && !!e.accessorFn;
      }, e.getCanMultiSort = () => {
        var n, r;
        return (n = (r = e.columnDef.enableMultiSort) != null ? r : t.options.enableMultiSort) != null ? n : !!e.accessorFn;
      }, e.getIsSorted = () => {
        var n;
        const r = (n = t.getState().sorting) == null ? void 0 : n.find((o) => o.id === e.id);
        return r ? r.desc ? "desc" : "asc" : false;
      }, e.getSortIndex = () => {
        var n, r;
        return (n = (r = t.getState().sorting) == null ? void 0 : r.findIndex((o) => o.id === e.id)) != null ? n : -1;
      }, e.clearSorting = () => {
        t.setSorting((n) => n != null && n.length ? n.filter((r) => r.id !== e.id) : []);
      }, e.getToggleSortingHandler = () => {
        const n = e.getCanSort();
        return (r) => {
          n && (r.persist == null || r.persist(), e.toggleSorting == null || e.toggleSorting(void 0, e.getCanMultiSort() ? t.options.isMultiSortEvent == null ? void 0 : t.options.isMultiSortEvent(r) : false));
        };
      };
    },
    createTable: (e) => {
      e.setSorting = (t) => e.options.onSortingChange == null ? void 0 : e.options.onSortingChange(t), e.resetSorting = (t) => {
        var n, r;
        e.setSorting(t ? [] : (n = (r = e.initialState) == null ? void 0 : r.sorting) != null ? n : []);
      }, e.getPreSortedRowModel = () => e.getGroupedRowModel(), e.getSortedRowModel = () => (!e._getSortedRowModel && e.options.getSortedRowModel && (e._getSortedRowModel = e.options.getSortedRowModel(e)), e.options.manualSorting || !e._getSortedRowModel ? e.getPreSortedRowModel() : e._getSortedRowModel());
    }
  }, Fo = [
    Kr,
    po,
    ao,
    uo,
    Yr,
    Wr,
    ho,
    mo,
    _o,
    so,
    vo,
    xo,
    wo,
    So,
    go
  ];
  function Mo(e) {
    var t, n;
    const r = [
      ...Fo,
      ...(t = e._features) != null ? t : []
    ];
    let o = {
      _features: r
    };
    const i = o._features.reduce((f, u) => Object.assign(f, u.getDefaultOptions == null ? void 0 : u.getDefaultOptions(o)), {}), s = (f) => o.options.mergeOptions ? o.options.mergeOptions(i, f) : {
      ...i,
      ...f
    };
    let a = {
      ...{},
      ...(n = e.initialState) != null ? n : {}
    };
    o._features.forEach((f) => {
      var u;
      a = (u = f.getInitialState == null ? void 0 : f.getInitialState(a)) != null ? u : a;
    });
    const c = [];
    let g = false;
    const p = {
      _features: r,
      options: {
        ...i,
        ...e
      },
      initialState: a,
      _queue: (f) => {
        c.push(f), g || (g = true, Promise.resolve().then(() => {
          for (; c.length; )
            c.shift()();
          g = false;
        }).catch((u) => setTimeout(() => {
          throw u;
        })));
      },
      reset: () => {
        o.setState(o.initialState);
      },
      setOptions: (f) => {
        const u = fe(f, o.options);
        o.options = s(u);
      },
      getState: () => o.options.state,
      setState: (f) => {
        o.options.onStateChange == null || o.options.onStateChange(f);
      },
      _getRowId: (f, u, v) => {
        var h;
        return (h = o.options.getRowId == null ? void 0 : o.options.getRowId(f, u, v)) != null ? h : `${v ? [
          v.id,
          u
        ].join(".") : u}`;
      },
      getCoreRowModel: () => (o._getCoreRowModel || (o._getCoreRowModel = o.options.getCoreRowModel(o)), o._getCoreRowModel()),
      getRowModel: () => o.getPaginationRowModel(),
      getRow: (f, u) => {
        let v = (u ? o.getPrePaginationRowModel() : o.getRowModel()).rowsById[f];
        if (!v && (v = o.getCoreRowModel().rowsById[f], !v))
          throw new Error();
        return v;
      },
      _getDefaultColumnDef: y(() => [
        o.options.defaultColumn
      ], (f) => {
        var u;
        return f = (u = f) != null ? u : {}, {
          header: (v) => {
            const h = v.header.column.columnDef;
            return h.accessorKey ? h.accessorKey : h.accessorFn ? h.id : null;
          },
          cell: (v) => {
            var h, w;
            return (h = (w = v.renderValue()) == null || w.toString == null ? void 0 : w.toString()) != null ? h : null;
          },
          ...o._features.reduce((v, h) => Object.assign(v, h.getDefaultColumnDef == null ? void 0 : h.getDefaultColumnDef()), {}),
          ...f
        };
      }, E(e, "debugColumns")),
      _getColumnDefs: () => o.options.columns,
      getAllColumns: y(() => [
        o._getColumnDefs()
      ], (f) => {
        const u = function(v, h, w) {
          return w === void 0 && (w = 0), v.map((x) => {
            const S = Xr(o, x, w, h), C = x;
            return S.columns = C.columns ? u(C.columns, S, w + 1) : [], S;
          });
        };
        return u(f);
      }, E(e, "debugColumns")),
      getAllFlatColumns: y(() => [
        o.getAllColumns()
      ], (f) => f.flatMap((u) => u.getFlatColumns()), E(e, "debugColumns")),
      _getAllFlatColumnsById: y(() => [
        o.getAllFlatColumns()
      ], (f) => f.reduce((u, v) => (u[v.id] = v, u), {}), E(e, "debugColumns")),
      getAllLeafColumns: y(() => [
        o.getAllColumns(),
        o._getOrderColumnsFn()
      ], (f, u) => {
        let v = f.flatMap((h) => h.getLeafColumns());
        return u(v);
      }, E(e, "debugColumns")),
      getColumn: (f) => o._getAllFlatColumnsById()[f]
    };
    Object.assign(o, p);
    for (let f = 0; f < o._features.length; f++) {
      const u = o._features[f];
      u == null || u.createTable == null || u.createTable(o);
    }
    return o;
  }
  function ko() {
    return (e) => y(() => [
      e.options.data
    ], (t) => {
      const n = {
        rows: [],
        flatRows: [],
        rowsById: {}
      }, r = function(o, i, s) {
        i === void 0 && (i = 0);
        const l = [];
        for (let c = 0; c < o.length; c++) {
          const g = Bt(e, e._getRowId(o[c], c, s), o[c], c, i, void 0, s == null ? void 0 : s.id);
          if (n.flatRows.push(g), n.rowsById[g.id] = g, l.push(g), e.options.getSubRows) {
            var a;
            g.originalSubRows = e.options.getSubRows(o[c], c), (a = g.originalSubRows) != null && a.length && (g.subRows = r(g.originalSubRows, i + 1, g));
          }
        }
        return l;
      };
      return n.rows = r(t), n;
    }, E(e.options, "debugTable", "getRowModel", () => e._autoResetPageIndex()));
  }
  function Io() {
    return (e) => y(() => [
      e.getState().expanded,
      e.getPreExpandedRowModel(),
      e.options.paginateExpandedRows
    ], (t, n, r) => !n.rows.length || t !== true && !Object.keys(t ?? {}).length || !r ? n : Xn(n), E(e.options, "debugTable"));
  }
  function Xn(e) {
    const t = [], n = (r) => {
      var o;
      t.push(r), (o = r.subRows) != null && o.length && r.getIsExpanded() && r.subRows.forEach(n);
    };
    return e.rows.forEach(n), {
      rows: t,
      flatRows: e.flatRows,
      rowsById: e.rowsById
    };
  }
  function Po(e, t, n) {
    return n.options.filterFromLeafRows ? $o(e, t, n) : No(e, t, n);
  }
  function $o(e, t, n) {
    var r;
    const o = [], i = {}, s = (r = n.options.maxLeafRowFilterDepth) != null ? r : 100, l = function(a, c) {
      c === void 0 && (c = 0);
      const g = [];
      for (let f = 0; f < a.length; f++) {
        var p;
        let u = a[f];
        const v = Bt(n, u.id, u.original, u.index, u.depth, void 0, u.parentId);
        if (v.columnFilters = u.columnFilters, (p = u.subRows) != null && p.length && c < s) {
          if (v.subRows = l(u.subRows, c + 1), u = v, t(u) && !v.subRows.length) {
            g.push(u), i[u.id] = u, o.push(u);
            continue;
          }
          if (t(u) || v.subRows.length) {
            g.push(u), i[u.id] = u, o.push(u);
            continue;
          }
        } else
          u = v, t(u) && (g.push(u), i[u.id] = u, o.push(u));
      }
      return g;
    };
    return {
      rows: l(e),
      flatRows: o,
      rowsById: i
    };
  }
  function No(e, t, n) {
    var r;
    const o = [], i = {}, s = (r = n.options.maxLeafRowFilterDepth) != null ? r : 100, l = function(a, c) {
      c === void 0 && (c = 0);
      const g = [];
      for (let f = 0; f < a.length; f++) {
        let u = a[f];
        if (t(u)) {
          var p;
          if ((p = u.subRows) != null && p.length && c < s) {
            const h = Bt(n, u.id, u.original, u.index, u.depth, void 0, u.parentId);
            h.subRows = l(u.subRows, c + 1), u = h;
          }
          g.push(u), o.push(u), i[u.id] = u;
        }
      }
      return g;
    };
    return {
      rows: l(e),
      flatRows: o,
      rowsById: i
    };
  }
  function Oo() {
    return (e) => y(() => [
      e.getPreFilteredRowModel(),
      e.getState().columnFilters,
      e.getState().globalFilter
    ], (t, n, r) => {
      if (!t.rows.length || !(n != null && n.length) && !r) {
        for (let f = 0; f < t.flatRows.length; f++)
          t.flatRows[f].columnFilters = {}, t.flatRows[f].columnFiltersMeta = {};
        return t;
      }
      const o = [], i = [];
      (n ?? []).forEach((f) => {
        var u;
        const v = e.getColumn(f.id);
        if (!v)
          return;
        const h = v.getFilterFn();
        h && o.push({
          id: f.id,
          filterFn: h,
          resolvedValue: (u = h.resolveFilterValue == null ? void 0 : h.resolveFilterValue(f.value)) != null ? u : f.value
        });
      });
      const s = (n ?? []).map((f) => f.id), l = e.getGlobalFilterFn(), a = e.getAllLeafColumns().filter((f) => f.getCanGlobalFilter());
      r && l && a.length && (s.push("__global__"), a.forEach((f) => {
        var u;
        i.push({
          id: f.id,
          filterFn: l,
          resolvedValue: (u = l.resolveFilterValue == null ? void 0 : l.resolveFilterValue(r)) != null ? u : r
        });
      }));
      let c, g;
      for (let f = 0; f < t.flatRows.length; f++) {
        const u = t.flatRows[f];
        if (u.columnFilters = {}, o.length)
          for (let v = 0; v < o.length; v++) {
            c = o[v];
            const h = c.id;
            u.columnFilters[h] = c.filterFn(u, h, c.resolvedValue, (w) => {
              u.columnFiltersMeta[h] = w;
            });
          }
        if (i.length) {
          for (let v = 0; v < i.length; v++) {
            g = i[v];
            const h = g.id;
            if (g.filterFn(u, h, g.resolvedValue, (w) => {
              u.columnFiltersMeta[h] = w;
            })) {
              u.columnFilters.__global__ = true;
              break;
            }
          }
          u.columnFilters.__global__ !== true && (u.columnFilters.__global__ = false);
        }
      }
      const p = (f) => {
        for (let u = 0; u < s.length; u++)
          if (f.columnFilters[s[u]] === false)
            return false;
        return true;
      };
      return Po(t.rows, p, e);
    }, E(e.options, "debugTable", "getFilteredRowModel", () => e._autoResetPageIndex()));
  }
  function Ao(e) {
    return (t) => y(() => [
      t.getState().pagination,
      t.getPrePaginationRowModel(),
      t.options.paginateExpandedRows ? void 0 : t.getState().expanded
    ], (n, r) => {
      if (!r.rows.length)
        return r;
      const { pageSize: o, pageIndex: i } = n;
      let { rows: s, flatRows: l, rowsById: a } = r;
      const c = o * i, g = c + o;
      s = s.slice(c, g);
      let p;
      t.options.paginateExpandedRows ? p = {
        rows: s,
        flatRows: l,
        rowsById: a
      } : p = Xn({
        rows: s,
        flatRows: l,
        rowsById: a
      }), p.flatRows = [];
      const f = (u) => {
        p.flatRows.push(u), u.subRows.length && u.subRows.forEach(f);
      };
      return p.rows.forEach(f), p;
    }, E(t.options, "debugTable"));
  }
  function Vo() {
    return (e) => y(() => [
      e.getState().sorting,
      e.getPreSortedRowModel()
    ], (t, n) => {
      if (!n.rows.length || !(t != null && t.length))
        return n;
      const r = e.getState().sorting, o = [], i = r.filter((a) => {
        var c;
        return (c = e.getColumn(a.id)) == null ? void 0 : c.getCanSort();
      }), s = {};
      i.forEach((a) => {
        const c = e.getColumn(a.id);
        c && (s[a.id] = {
          sortUndefined: c.columnDef.sortUndefined,
          invertSorting: c.columnDef.invertSorting,
          sortingFn: c.getSortingFn()
        });
      });
      const l = (a) => {
        const c = a.map((g) => ({
          ...g
        }));
        return c.sort((g, p) => {
          for (let u = 0; u < i.length; u += 1) {
            var f;
            const v = i[u], h = s[v.id], w = h.sortUndefined, x = (f = v == null ? void 0 : v.desc) != null ? f : false;
            let S = 0;
            if (w) {
              const C = g.getValue(v.id), M = p.getValue(v.id), b = C === void 0, R = M === void 0;
              if (b || R) {
                if (w === "first")
                  return b ? -1 : 1;
                if (w === "last")
                  return b ? 1 : -1;
                S = b && R ? 0 : b ? w : -w;
              }
            }
            if (S === 0 && (S = h.sortingFn(g, p, v.id)), S !== 0)
              return x && (S *= -1), h.invertSorting && (S *= -1), S;
          }
          return g.index - p.index;
        }), c.forEach((g) => {
          var p;
          o.push(g), (p = g.subRows) != null && p.length && (g.subRows = l(g.subRows));
        }), c;
      };
      return {
        rows: l(n.rows),
        flatRows: o,
        rowsById: n.rowsById
      };
    }, E(e.options, "debugTable", "getSortedRowModel", () => e._autoResetPageIndex()));
  }
  function it(e, t) {
    return e ? Lo(e) ? d.createElement(e, t) : e : null;
  }
  function Lo(e) {
    return jo(e) || typeof e == "function" || To(e);
  }
  function jo(e) {
    return typeof e == "function" && (() => {
      const t = Object.getPrototypeOf(e);
      return t.prototype && t.prototype.isReactComponent;
    })();
  }
  function To(e) {
    return typeof e == "object" && typeof e.$$typeof == "symbol" && [
      "react.memo",
      "react.forward_ref"
    ].includes(e.$$typeof.description);
  }
  function zo(e) {
    const t = {
      state: {},
      onStateChange: () => {
      },
      renderFallbackValue: null,
      ...e
    }, [n] = d.useState(() => ({
      current: Mo(t)
    })), [r, o] = d.useState(() => n.current.initialState);
    return n.current.setOptions((i) => ({
      ...i,
      ...e,
      state: {
        ...r,
        ...e.state
      },
      onStateChange: (s) => {
        o(s), e.onStateChange == null || e.onStateChange(s);
      }
    })), n.current;
  }
  function Go({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M3.22 7.595a.75.75 0 0 0 0 1.06l3.25 3.25a.75.75 0 0 0 1.06-1.06l-2.72-2.72 2.72-2.72a.75.75 0 0 0-1.06-1.06l-3.25 3.25Zm8.25-3.25-3.25 3.25a.75.75 0 0 0 0 1.06l3.25 3.25a.75.75 0 1 0 1.06-1.06l-2.72-2.72 2.72-2.72a.75.75 0 0 0-1.06-1.06Z",
      clipRule: "evenodd"
    }));
  }
  let Ho;
  Ho = d.forwardRef(Go);
  Bo = Ho;
  function Uo({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M12.78 7.595a.75.75 0 0 1 0 1.06l-3.25 3.25a.75.75 0 0 1-1.06-1.06l2.72-2.72-2.72-2.72a.75.75 0 0 1 1.06-1.06l3.25 3.25Zm-8.25-3.25 3.25 3.25a.75.75 0 0 1 0 1.06l-3.25 3.25a.75.75 0 0 1-1.06-1.06l2.72-2.72-2.72-2.72a.75.75 0 0 1 1.06-1.06Z",
      clipRule: "evenodd"
    }));
  }
  let qo;
  qo = d.forwardRef(Uo);
  Xo = qo;
  function Ko({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M4.22 6.22a.75.75 0 0 1 1.06 0L8 8.94l2.72-2.72a.75.75 0 1 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0L4.22 7.28a.75.75 0 0 1 0-1.06Z",
      clipRule: "evenodd"
    }));
  }
  const Yo = d.forwardRef(Ko), Rn = Yo;
  function Wo({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M9.78 4.22a.75.75 0 0 1 0 1.06L7.06 8l2.72 2.72a.75.75 0 1 1-1.06 1.06L5.47 8.53a.75.75 0 0 1 0-1.06l3.25-3.25a.75.75 0 0 1 1.06 0Z",
      clipRule: "evenodd"
    }));
  }
  let Zo;
  Zo = d.forwardRef(Wo);
  Jo = Zo;
  function Qo({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M6.22 4.22a.75.75 0 0 1 1.06 0l3.25 3.25a.75.75 0 0 1 0 1.06l-3.25 3.25a.75.75 0 0 1-1.06-1.06L8.94 8 6.22 5.28a.75.75 0 0 1 0-1.06Z",
      clipRule: "evenodd"
    }));
  }
  let ei;
  ei = d.forwardRef(Qo);
  ti = ei;
  function ni({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M11.78 9.78a.75.75 0 0 1-1.06 0L8 7.06 5.28 9.78a.75.75 0 0 1-1.06-1.06l3.25-3.25a.75.75 0 0 1 1.06 0l3.25 3.25a.75.75 0 0 1 0 1.06Z",
      clipRule: "evenodd"
    }));
  }
  const ri = d.forwardRef(ni), oi = ri;
  function ii({ title: e, titleId: t, ...n }, r) {
    return d.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 16 16",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? d.createElement("title", {
      id: t
    }, e) : null, d.createElement("path", {
      fillRule: "evenodd",
      d: "M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z",
      clipRule: "evenodd"
    }));
  }
  const si = d.forwardRef(ii), li = si;
  function ai({ column: e, table: t }) {
    const n = e.columnDef.filterType ?? "text", r = e.getFilterValue();
    return n === "number" ? m.jsxs("div", {
      className: "flex space-x-0.5",
      children: [
        m.jsx("input", {
          type: "number",
          value: (r == null ? void 0 : r[0]) ?? "",
          onChange: (o) => e.setFilterValue((i) => [
            o.target.value,
            i == null ? void 0 : i[1]
          ]),
          placeholder: "Min",
          "aria-label": `Minimum ${e.id}`,
          className: "block w-16 rounded-md border-0 py-0.5 px-2 text-neutral-900 dark:text-slate-100 shadow-sm ring-1 ring-inset ring-neutral-300 dark:ring-slate-600 placeholder:text-neutral-400 dark:placeholder:text-slate-500 focus:ring-2 focus:ring-inset focus:ring-neutral-900 dark:focus:ring-slate-400 text-xs leading-6 dark:bg-slate-900"
        }),
        m.jsx("input", {
          type: "number",
          value: (r == null ? void 0 : r[1]) ?? "",
          onChange: (o) => e.setFilterValue((i) => [
            i == null ? void 0 : i[0],
            o.target.value
          ]),
          placeholder: "Max",
          "aria-label": `Maximum ${e.id}`,
          className: "block w-16 rounded-md border-0 py-0.5 px-2 text-neutral-900 dark:text-slate-100 shadow-sm ring-1 ring-inset ring-neutral-300 dark:ring-slate-600 placeholder:text-neutral-400 dark:placeholder:text-slate-500 focus:ring-2 focus:ring-inset focus:ring-neutral-900 dark:focus:ring-slate-400 text-xs leading-6 dark:bg-slate-900"
        })
      ]
    }) : m.jsxs("div", {
      className: "relative",
      children: [
        m.jsx("div", {
          className: "absolute inset-y-0 left-0 flex items-center pl-2 pointer-events-none",
          children: m.jsx(li, {
            className: "w-4 h-4 text-neutral-400 dark:text-slate-500",
            "aria-hidden": "true"
          })
        }),
        m.jsx("input", {
          type: "text",
          value: r ?? "",
          onChange: (o) => e.setFilterValue(o.target.value),
          placeholder: "Search...",
          "aria-label": `Filter ${e.id}`,
          className: "block w-full rounded-md border-0 py-0.5 pl-7 text-neutral-900 dark:text-slate-100 ring-1 ring-inset ring-neutral-300 dark:ring-slate-600 placeholder:text-neutral-400 dark:placeholder:text-slate-500 focus:ring-2 focus:ring-inset focus:ring-neutral-900 dark:focus:ring-slate-400 text-xs leading-6 dark:bg-slate-900"
        })
      ]
    });
  }
  const pt = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u";
  function Fe(e) {
    const t = Object.prototype.toString.call(e);
    return t === "[object Window]" || t === "[object global]";
  }
  function Kt(e) {
    return "nodeType" in e;
  }
  function z(e) {
    var t, n;
    return e ? Fe(e) ? e : Kt(e) && (t = (n = e.ownerDocument) == null ? void 0 : n.defaultView) != null ? t : window : window;
  }
  function Yt(e) {
    const { Document: t } = z(e);
    return e instanceof t;
  }
  function He(e) {
    return Fe(e) ? false : e instanceof z(e).HTMLElement;
  }
  function Kn(e) {
    return e instanceof z(e).SVGElement;
  }
  function Me(e) {
    return e ? Fe(e) ? e.document : Kt(e) ? Yt(e) ? e : He(e) || Kn(e) ? e.ownerDocument : document : document : document;
  }
  const ie = pt ? d.useLayoutEffect : d.useEffect;
  function ht(e) {
    const t = d.useRef(e);
    return ie(() => {
      t.current = e;
    }), d.useCallback(function() {
      for (var n = arguments.length, r = new Array(n), o = 0; o < n; o++)
        r[o] = arguments[o];
      return t.current == null ? void 0 : t.current(...r);
    }, []);
  }
  function ui() {
    const e = d.useRef(null), t = d.useCallback((r, o) => {
      e.current = setInterval(r, o);
    }, []), n = d.useCallback(() => {
      e.current !== null && (clearInterval(e.current), e.current = null);
    }, []);
    return [
      t,
      n
    ];
  }
  function Te(e, t) {
    t === void 0 && (t = [
      e
    ]);
    const n = d.useRef(e);
    return ie(() => {
      n.current !== e && (n.current = e);
    }, t), n;
  }
  function Be(e, t) {
    const n = d.useRef();
    return d.useMemo(() => {
      const r = e(n.current);
      return n.current = r, r;
    }, [
      ...t
    ]);
  }
  function lt(e) {
    const t = ht(e), n = d.useRef(null), r = d.useCallback((o) => {
      o !== n.current && (t == null ? void 0 : t(o, n.current)), n.current = o;
    }, []);
    return [
      n,
      r
    ];
  }
  function at(e) {
    const t = d.useRef();
    return d.useEffect(() => {
      t.current = e;
    }, [
      e
    ]), t.current;
  }
  let It = {};
  function mt(e, t) {
    return d.useMemo(() => {
      if (t)
        return t;
      const n = It[e] == null ? 0 : It[e] + 1;
      return It[e] = n, e + "-" + n;
    }, [
      e,
      t
    ]);
  }
  function Yn(e) {
    return function(t) {
      for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++)
        r[o - 1] = arguments[o];
      return r.reduce((i, s) => {
        const l = Object.entries(s);
        for (const [a, c] of l) {
          const g = i[a];
          g != null && (i[a] = g + e * c);
        }
        return i;
      }, {
        ...t
      });
    };
  }
  const De = Yn(1), ut = Yn(-1);
  function ci(e) {
    return "clientX" in e && "clientY" in e;
  }
  function Wt(e) {
    if (!e)
      return false;
    const { KeyboardEvent: t } = z(e.target);
    return t && e instanceof t;
  }
  function di(e) {
    if (!e)
      return false;
    const { TouchEvent: t } = z(e.target);
    return t && e instanceof t;
  }
  function ct(e) {
    if (di(e)) {
      if (e.touches && e.touches.length) {
        const { clientX: t, clientY: n } = e.touches[0];
        return {
          x: t,
          y: n
        };
      } else if (e.changedTouches && e.changedTouches.length) {
        const { clientX: t, clientY: n } = e.changedTouches[0];
        return {
          x: t,
          y: n
        };
      }
    }
    return ci(e) ? {
      x: e.clientX,
      y: e.clientY
    } : null;
  }
  const ze = Object.freeze({
    Translate: {
      toString(e) {
        if (!e)
          return;
        const { x: t, y: n } = e;
        return "translate3d(" + (t ? Math.round(t) : 0) + "px, " + (n ? Math.round(n) : 0) + "px, 0)";
      }
    },
    Scale: {
      toString(e) {
        if (!e)
          return;
        const { scaleX: t, scaleY: n } = e;
        return "scaleX(" + t + ") scaleY(" + n + ")";
      }
    },
    Transform: {
      toString(e) {
        if (e)
          return [
            ze.Translate.toString(e),
            ze.Scale.toString(e)
          ].join(" ");
      }
    },
    Transition: {
      toString(e) {
        let { property: t, duration: n, easing: r } = e;
        return t + " " + n + "ms " + r;
      }
    }
  }), bn = "a,frame,iframe,input:not([type=hidden]):not(:disabled),select:not(:disabled),textarea:not(:disabled),button:not(:disabled),*[tabindex]";
  function gi(e) {
    return e.matches(bn) ? e : e.querySelector(bn);
  }
  const fi = {
    display: "none"
  };
  function pi(e) {
    let { id: t, value: n } = e;
    return O.createElement("div", {
      id: t,
      style: fi
    }, n);
  }
  function hi(e) {
    let { id: t, announcement: n, ariaLiveType: r = "assertive" } = e;
    const o = {
      position: "fixed",
      top: 0,
      left: 0,
      width: 1,
      height: 1,
      margin: -1,
      border: 0,
      padding: 0,
      overflow: "hidden",
      clip: "rect(0 0 0 0)",
      clipPath: "inset(100%)",
      whiteSpace: "nowrap"
    };
    return O.createElement("div", {
      id: t,
      style: o,
      role: "status",
      "aria-live": r,
      "aria-atomic": true
    }, n);
  }
  function mi() {
    const [e, t] = d.useState("");
    return {
      announce: d.useCallback((r) => {
        r != null && t(r);
      }, []),
      announcement: e
    };
  }
  const Wn = d.createContext(null);
  function vi(e) {
    const t = d.useContext(Wn);
    d.useEffect(() => {
      if (!t)
        throw new Error("useDndMonitor must be used within a children of <DndContext>");
      return t(e);
    }, [
      e,
      t
    ]);
  }
  function xi() {
    const [e] = d.useState(() => /* @__PURE__ */ new Set()), t = d.useCallback((r) => (e.add(r), () => e.delete(r)), [
      e
    ]);
    return [
      d.useCallback((r) => {
        let { type: o, event: i } = r;
        e.forEach((s) => {
          var l;
          return (l = s[o]) == null ? void 0 : l.call(s, i);
        });
      }, [
        e
      ]),
      t
    ];
  }
  const wi = {
    draggable: `
    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  `
  }, Si = {
    onDragStart(e) {
      let { active: t } = e;
      return "Picked up draggable item " + t.id + ".";
    },
    onDragOver(e) {
      let { active: t, over: n } = e;
      return n ? "Draggable item " + t.id + " was moved over droppable area " + n.id + "." : "Draggable item " + t.id + " is no longer over a droppable area.";
    },
    onDragEnd(e) {
      let { active: t, over: n } = e;
      return n ? "Draggable item " + t.id + " was dropped over droppable area " + n.id : "Draggable item " + t.id + " was dropped.";
    },
    onDragCancel(e) {
      let { active: t } = e;
      return "Dragging was cancelled. Draggable item " + t.id + " was dropped.";
    }
  };
  function Ci(e) {
    let { announcements: t = Si, container: n, hiddenTextDescribedById: r, screenReaderInstructions: o = wi } = e;
    const { announce: i, announcement: s } = mi(), l = mt("DndLiveRegion"), [a, c] = d.useState(false);
    if (d.useEffect(() => {
      c(true);
    }, []), vi(d.useMemo(() => ({
      onDragStart(p) {
        let { active: f } = p;
        i(t.onDragStart({
          active: f
        }));
      },
      onDragMove(p) {
        let { active: f, over: u } = p;
        t.onDragMove && i(t.onDragMove({
          active: f,
          over: u
        }));
      },
      onDragOver(p) {
        let { active: f, over: u } = p;
        i(t.onDragOver({
          active: f,
          over: u
        }));
      },
      onDragEnd(p) {
        let { active: f, over: u } = p;
        i(t.onDragEnd({
          active: f,
          over: u
        }));
      },
      onDragCancel(p) {
        let { active: f, over: u } = p;
        i(t.onDragCancel({
          active: f,
          over: u
        }));
      }
    }), [
      i,
      t
    ])), !a)
      return null;
    const g = O.createElement(O.Fragment, null, O.createElement(pi, {
      id: r,
      value: o.draggable
    }), O.createElement(hi, {
      id: l,
      announcement: s
    }));
    return n ? Ee.createPortal(g, n) : g;
  }
  var A;
  (function(e) {
    e.DragStart = "dragStart", e.DragMove = "dragMove", e.DragEnd = "dragEnd", e.DragCancel = "dragCancel", e.DragOver = "dragOver", e.RegisterDroppable = "registerDroppable", e.SetDroppableDisabled = "setDroppableDisabled", e.UnregisterDroppable = "unregisterDroppable";
  })(A || (A = {}));
  function dt() {
  }
  function yn(e, t) {
    return d.useMemo(() => ({
      sensor: e,
      options: t ?? {}
    }), [
      e,
      t
    ]);
  }
  function Ri() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return d.useMemo(() => [
      ...t
    ].filter((r) => r != null), [
      ...t
    ]);
  }
  const Q = Object.freeze({
    x: 0,
    y: 0
  });
  function bi(e, t) {
    const n = ct(e);
    if (!n)
      return "0 0";
    const r = {
      x: (n.x - t.left) / t.width * 100,
      y: (n.y - t.top) / t.height * 100
    };
    return r.x + "% " + r.y + "%";
  }
  function yi(e, t) {
    let { data: { value: n } } = e, { data: { value: r } } = t;
    return r - n;
  }
  function Ei(e, t) {
    if (!e || e.length === 0)
      return null;
    const [n] = e;
    return t ? n[t] : n;
  }
  function Di(e, t) {
    const n = Math.max(t.top, e.top), r = Math.max(t.left, e.left), o = Math.min(t.left + t.width, e.left + e.width), i = Math.min(t.top + t.height, e.top + e.height), s = o - r, l = i - n;
    if (r < o && n < i) {
      const a = t.width * t.height, c = e.width * e.height, g = s * l, p = g / (a + c - g);
      return Number(p.toFixed(4));
    }
    return 0;
  }
  const _i = (e) => {
    let { collisionRect: t, droppableRects: n, droppableContainers: r } = e;
    const o = [];
    for (const i of r) {
      const { id: s } = i, l = n.get(s);
      if (l) {
        const a = Di(l, t);
        a > 0 && o.push({
          id: s,
          data: {
            droppableContainer: i,
            value: a
          }
        });
      }
    }
    return o.sort(yi);
  };
  function Fi(e, t, n) {
    return {
      ...e,
      scaleX: t && n ? t.width / n.width : 1,
      scaleY: t && n ? t.height / n.height : 1
    };
  }
  function Zn(e, t) {
    return e && t ? {
      x: e.left - t.left,
      y: e.top - t.top
    } : Q;
  }
  function Mi(e) {
    return function(n) {
      for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++)
        o[i - 1] = arguments[i];
      return o.reduce((s, l) => ({
        ...s,
        top: s.top + e * l.y,
        bottom: s.bottom + e * l.y,
        left: s.left + e * l.x,
        right: s.right + e * l.x
      }), {
        ...n
      });
    };
  }
  const ki = Mi(1);
  function Jn(e) {
    if (e.startsWith("matrix3d(")) {
      const t = e.slice(9, -1).split(/, /);
      return {
        x: +t[12],
        y: +t[13],
        scaleX: +t[0],
        scaleY: +t[5]
      };
    } else if (e.startsWith("matrix(")) {
      const t = e.slice(7, -1).split(/, /);
      return {
        x: +t[4],
        y: +t[5],
        scaleX: +t[0],
        scaleY: +t[3]
      };
    }
    return null;
  }
  function Ii(e, t, n) {
    const r = Jn(t);
    if (!r)
      return e;
    const { scaleX: o, scaleY: i, x: s, y: l } = r, a = e.left - s - (1 - o) * parseFloat(n), c = e.top - l - (1 - i) * parseFloat(n.slice(n.indexOf(" ") + 1)), g = o ? e.width / o : e.width, p = i ? e.height / i : e.height;
    return {
      width: g,
      height: p,
      top: c,
      right: a + g,
      bottom: c + p,
      left: a
    };
  }
  const Pi = {
    ignoreTransform: false
  };
  function Ue(e, t) {
    t === void 0 && (t = Pi);
    let n = e.getBoundingClientRect();
    if (t.ignoreTransform) {
      const { transform: c, transformOrigin: g } = z(e).getComputedStyle(e);
      c && (n = Ii(n, c, g));
    }
    const { top: r, left: o, width: i, height: s, bottom: l, right: a } = n;
    return {
      top: r,
      left: o,
      width: i,
      height: s,
      bottom: l,
      right: a
    };
  }
  function En(e) {
    return Ue(e, {
      ignoreTransform: true
    });
  }
  function $i(e) {
    const t = e.innerWidth, n = e.innerHeight;
    return {
      top: 0,
      left: 0,
      right: t,
      bottom: n,
      width: t,
      height: n
    };
  }
  function Ni(e, t) {
    return t === void 0 && (t = z(e).getComputedStyle(e)), t.position === "fixed";
  }
  function Oi(e, t) {
    t === void 0 && (t = z(e).getComputedStyle(e));
    const n = /(auto|scroll|overlay)/;
    return [
      "overflow",
      "overflowX",
      "overflowY"
    ].some((o) => {
      const i = t[o];
      return typeof i == "string" ? n.test(i) : false;
    });
  }
  function Zt(e, t) {
    const n = [];
    function r(o) {
      if (t != null && n.length >= t || !o)
        return n;
      if (Yt(o) && o.scrollingElement != null && !n.includes(o.scrollingElement))
        return n.push(o.scrollingElement), n;
      if (!He(o) || Kn(o) || n.includes(o))
        return n;
      const i = z(e).getComputedStyle(o);
      return o !== e && Oi(o, i) && n.push(o), Ni(o, i) ? n : r(o.parentNode);
    }
    return e ? r(e) : n;
  }
  function Qn(e) {
    const [t] = Zt(e, 1);
    return t ?? null;
  }
  function Pt(e) {
    return !pt || !e ? null : Fe(e) ? e : Kt(e) ? Yt(e) || e === Me(e).scrollingElement ? window : He(e) ? e : null : null;
  }
  function er(e) {
    return Fe(e) ? e.scrollX : e.scrollLeft;
  }
  function tr(e) {
    return Fe(e) ? e.scrollY : e.scrollTop;
  }
  function zt(e) {
    return {
      x: er(e),
      y: tr(e)
    };
  }
  var V;
  (function(e) {
    e[e.Forward = 1] = "Forward", e[e.Backward = -1] = "Backward";
  })(V || (V = {}));
  function nr(e) {
    return !pt || !e ? false : e === document.scrollingElement;
  }
  function rr(e) {
    const t = {
      x: 0,
      y: 0
    }, n = nr(e) ? {
      height: window.innerHeight,
      width: window.innerWidth
    } : {
      height: e.clientHeight,
      width: e.clientWidth
    }, r = {
      x: e.scrollWidth - n.width,
      y: e.scrollHeight - n.height
    }, o = e.scrollTop <= t.y, i = e.scrollLeft <= t.x, s = e.scrollTop >= r.y, l = e.scrollLeft >= r.x;
    return {
      isTop: o,
      isLeft: i,
      isBottom: s,
      isRight: l,
      maxScroll: r,
      minScroll: t
    };
  }
  const Ai = {
    x: 0.2,
    y: 0.2
  };
  function Vi(e, t, n, r, o) {
    let { top: i, left: s, right: l, bottom: a } = n;
    r === void 0 && (r = 10), o === void 0 && (o = Ai);
    const { isTop: c, isBottom: g, isLeft: p, isRight: f } = rr(e), u = {
      x: 0,
      y: 0
    }, v = {
      x: 0,
      y: 0
    }, h = {
      height: t.height * o.y,
      width: t.width * o.x
    };
    return !c && i <= t.top + h.height ? (u.y = V.Backward, v.y = r * Math.abs((t.top + h.height - i) / h.height)) : !g && a >= t.bottom - h.height && (u.y = V.Forward, v.y = r * Math.abs((t.bottom - h.height - a) / h.height)), !f && l >= t.right - h.width ? (u.x = V.Forward, v.x = r * Math.abs((t.right - h.width - l) / h.width)) : !p && s <= t.left + h.width && (u.x = V.Backward, v.x = r * Math.abs((t.left + h.width - s) / h.width)), {
      direction: u,
      speed: v
    };
  }
  function Li(e) {
    if (e === document.scrollingElement) {
      const { innerWidth: i, innerHeight: s } = window;
      return {
        top: 0,
        left: 0,
        right: i,
        bottom: s,
        width: i,
        height: s
      };
    }
    const { top: t, left: n, right: r, bottom: o } = e.getBoundingClientRect();
    return {
      top: t,
      left: n,
      right: r,
      bottom: o,
      width: e.clientWidth,
      height: e.clientHeight
    };
  }
  function or(e) {
    return e.reduce((t, n) => De(t, zt(n)), Q);
  }
  function ji(e) {
    return e.reduce((t, n) => t + er(n), 0);
  }
  function Ti(e) {
    return e.reduce((t, n) => t + tr(n), 0);
  }
  function ir(e, t) {
    if (t === void 0 && (t = Ue), !e)
      return;
    const { top: n, left: r, bottom: o, right: i } = t(e);
    Qn(e) && (o <= 0 || i <= 0 || n >= window.innerHeight || r >= window.innerWidth) && e.scrollIntoView({
      block: "center",
      inline: "center"
    });
  }
  const zi = [
    [
      "x",
      [
        "left",
        "right"
      ],
      ji
    ],
    [
      "y",
      [
        "top",
        "bottom"
      ],
      Ti
    ]
  ];
  class Jt {
    constructor(t, n) {
      this.rect = void 0, this.width = void 0, this.height = void 0, this.top = void 0, this.bottom = void 0, this.right = void 0, this.left = void 0;
      const r = Zt(n), o = or(r);
      this.rect = {
        ...t
      }, this.width = t.width, this.height = t.height;
      for (const [i, s, l] of zi)
        for (const a of s)
          Object.defineProperty(this, a, {
            get: () => {
              const c = l(r), g = o[i] - c;
              return this.rect[a] + g;
            },
            enumerable: true
          });
      Object.defineProperty(this, "rect", {
        enumerable: false
      });
    }
  }
  class Ve {
    constructor(t) {
      this.target = void 0, this.listeners = [], this.removeAll = () => {
        this.listeners.forEach((n) => {
          var r;
          return (r = this.target) == null ? void 0 : r.removeEventListener(...n);
        });
      }, this.target = t;
    }
    add(t, n, r) {
      var o;
      (o = this.target) == null || o.addEventListener(t, n, r), this.listeners.push([
        t,
        n,
        r
      ]);
    }
  }
  function Gi(e) {
    const { EventTarget: t } = z(e);
    return e instanceof t ? e : Me(e);
  }
  function $t(e, t) {
    const n = Math.abs(e.x), r = Math.abs(e.y);
    return typeof t == "number" ? Math.sqrt(n ** 2 + r ** 2) > t : "x" in t && "y" in t ? n > t.x && r > t.y : "x" in t ? n > t.x : "y" in t ? r > t.y : false;
  }
  var K;
  (function(e) {
    e.Click = "click", e.DragStart = "dragstart", e.Keydown = "keydown", e.ContextMenu = "contextmenu", e.Resize = "resize", e.SelectionChange = "selectionchange", e.VisibilityChange = "visibilitychange";
  })(K || (K = {}));
  function Dn(e) {
    e.preventDefault();
  }
  function Hi(e) {
    e.stopPropagation();
  }
  var I;
  (function(e) {
    e.Space = "Space", e.Down = "ArrowDown", e.Right = "ArrowRight", e.Left = "ArrowLeft", e.Up = "ArrowUp", e.Esc = "Escape", e.Enter = "Enter", e.Tab = "Tab";
  })(I || (I = {}));
  const sr = {
    start: [
      I.Space,
      I.Enter
    ],
    cancel: [
      I.Esc
    ],
    end: [
      I.Space,
      I.Enter,
      I.Tab
    ]
  }, Bi = (e, t) => {
    let { currentCoordinates: n } = t;
    switch (e.code) {
      case I.Right:
        return {
          ...n,
          x: n.x + 25
        };
      case I.Left:
        return {
          ...n,
          x: n.x - 25
        };
      case I.Down:
        return {
          ...n,
          y: n.y + 25
        };
      case I.Up:
        return {
          ...n,
          y: n.y - 25
        };
    }
  };
  class Qt {
    constructor(t) {
      this.props = void 0, this.autoScrollEnabled = false, this.referenceCoordinates = void 0, this.listeners = void 0, this.windowListeners = void 0, this.props = t;
      const { event: { target: n } } = t;
      this.props = t, this.listeners = new Ve(Me(n)), this.windowListeners = new Ve(z(n)), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleCancel = this.handleCancel.bind(this), this.attach();
    }
    attach() {
      this.handleStart(), this.windowListeners.add(K.Resize, this.handleCancel), this.windowListeners.add(K.VisibilityChange, this.handleCancel), setTimeout(() => this.listeners.add(K.Keydown, this.handleKeyDown));
    }
    handleStart() {
      const { activeNode: t, onStart: n } = this.props, r = t.node.current;
      r && ir(r), n(Q);
    }
    handleKeyDown(t) {
      if (Wt(t)) {
        const { active: n, context: r, options: o } = this.props, { keyboardCodes: i = sr, coordinateGetter: s = Bi, scrollBehavior: l = "smooth" } = o, { code: a } = t;
        if (i.end.includes(a)) {
          this.handleEnd(t);
          return;
        }
        if (i.cancel.includes(a)) {
          this.handleCancel(t);
          return;
        }
        const { collisionRect: c } = r.current, g = c ? {
          x: c.left,
          y: c.top
        } : Q;
        this.referenceCoordinates || (this.referenceCoordinates = g);
        const p = s(t, {
          active: n,
          context: r.current,
          currentCoordinates: g
        });
        if (p) {
          const f = ut(p, g), u = {
            x: 0,
            y: 0
          }, { scrollableAncestors: v } = r.current;
          for (const h of v) {
            const w = t.code, { isTop: x, isRight: S, isLeft: C, isBottom: M, maxScroll: b, minScroll: R } = rr(h), D = Li(h), k = {
              x: Math.min(w === I.Right ? D.right - D.width / 2 : D.right, Math.max(w === I.Right ? D.left : D.left + D.width / 2, p.x)),
              y: Math.min(w === I.Down ? D.bottom - D.height / 2 : D.bottom, Math.max(w === I.Down ? D.top : D.top + D.height / 2, p.y))
            }, P = w === I.Right && !S || w === I.Left && !C, N = w === I.Down && !M || w === I.Up && !x;
            if (P && k.x !== p.x) {
              const $ = h.scrollLeft + f.x, q = w === I.Right && $ <= b.x || w === I.Left && $ >= R.x;
              if (q && !f.y) {
                h.scrollTo({
                  left: $,
                  behavior: l
                });
                return;
              }
              q ? u.x = h.scrollLeft - $ : u.x = w === I.Right ? h.scrollLeft - b.x : h.scrollLeft - R.x, u.x && h.scrollBy({
                left: -u.x,
                behavior: l
              });
              break;
            } else if (N && k.y !== p.y) {
              const $ = h.scrollTop + f.y, q = w === I.Down && $ <= b.y || w === I.Up && $ >= R.y;
              if (q && !f.x) {
                h.scrollTo({
                  top: $,
                  behavior: l
                });
                return;
              }
              q ? u.y = h.scrollTop - $ : u.y = w === I.Down ? h.scrollTop - b.y : h.scrollTop - R.y, u.y && h.scrollBy({
                top: -u.y,
                behavior: l
              });
              break;
            }
          }
          this.handleMove(t, De(ut(p, this.referenceCoordinates), u));
        }
      }
    }
    handleMove(t, n) {
      const { onMove: r } = this.props;
      t.preventDefault(), r(n);
    }
    handleEnd(t) {
      const { onEnd: n } = this.props;
      t.preventDefault(), this.detach(), n();
    }
    handleCancel(t) {
      const { onCancel: n } = this.props;
      t.preventDefault(), this.detach(), n();
    }
    detach() {
      this.listeners.removeAll(), this.windowListeners.removeAll();
    }
  }
  Qt.activators = [
    {
      eventName: "onKeyDown",
      handler: (e, t, n) => {
        let { keyboardCodes: r = sr, onActivation: o } = t, { active: i } = n;
        const { code: s } = e.nativeEvent;
        if (r.start.includes(s)) {
          const l = i.activatorNode.current;
          return l && e.target !== l ? false : (e.preventDefault(), o == null ? void 0 : o({
            event: e.nativeEvent
          }), true);
        }
        return false;
      }
    }
  ];
  function _n(e) {
    return !!(e && "distance" in e);
  }
  function Fn(e) {
    return !!(e && "delay" in e);
  }
  class en {
    constructor(t, n, r) {
      var o;
      r === void 0 && (r = Gi(t.event.target)), this.props = void 0, this.events = void 0, this.autoScrollEnabled = true, this.document = void 0, this.activated = false, this.initialCoordinates = void 0, this.timeoutId = null, this.listeners = void 0, this.documentListeners = void 0, this.windowListeners = void 0, this.props = t, this.events = n;
      const { event: i } = t, { target: s } = i;
      this.props = t, this.events = n, this.document = Me(s), this.documentListeners = new Ve(this.document), this.listeners = new Ve(r), this.windowListeners = new Ve(z(s)), this.initialCoordinates = (o = ct(i)) != null ? o : Q, this.handleStart = this.handleStart.bind(this), this.handleMove = this.handleMove.bind(this), this.handleEnd = this.handleEnd.bind(this), this.handleCancel = this.handleCancel.bind(this), this.handleKeydown = this.handleKeydown.bind(this), this.removeTextSelection = this.removeTextSelection.bind(this), this.attach();
    }
    attach() {
      const { events: t, props: { options: { activationConstraint: n, bypassActivationConstraint: r } } } = this;
      if (this.listeners.add(t.move.name, this.handleMove, {
        passive: false
      }), this.listeners.add(t.end.name, this.handleEnd), t.cancel && this.listeners.add(t.cancel.name, this.handleCancel), this.windowListeners.add(K.Resize, this.handleCancel), this.windowListeners.add(K.DragStart, Dn), this.windowListeners.add(K.VisibilityChange, this.handleCancel), this.windowListeners.add(K.ContextMenu, Dn), this.documentListeners.add(K.Keydown, this.handleKeydown), n) {
        if (r != null && r({
          event: this.props.event,
          activeNode: this.props.activeNode,
          options: this.props.options
        }))
          return this.handleStart();
        if (Fn(n)) {
          this.timeoutId = setTimeout(this.handleStart, n.delay), this.handlePending(n);
          return;
        }
        if (_n(n)) {
          this.handlePending(n);
          return;
        }
      }
      this.handleStart();
    }
    detach() {
      this.listeners.removeAll(), this.windowListeners.removeAll(), setTimeout(this.documentListeners.removeAll, 50), this.timeoutId !== null && (clearTimeout(this.timeoutId), this.timeoutId = null);
    }
    handlePending(t, n) {
      const { active: r, onPending: o } = this.props;
      o(r, t, this.initialCoordinates, n);
    }
    handleStart() {
      const { initialCoordinates: t } = this, { onStart: n } = this.props;
      t && (this.activated = true, this.documentListeners.add(K.Click, Hi, {
        capture: true
      }), this.removeTextSelection(), this.documentListeners.add(K.SelectionChange, this.removeTextSelection), n(t));
    }
    handleMove(t) {
      var n;
      const { activated: r, initialCoordinates: o, props: i } = this, { onMove: s, options: { activationConstraint: l } } = i;
      if (!o)
        return;
      const a = (n = ct(t)) != null ? n : Q, c = ut(o, a);
      if (!r && l) {
        if (_n(l)) {
          if (l.tolerance != null && $t(c, l.tolerance))
            return this.handleCancel();
          if ($t(c, l.distance))
            return this.handleStart();
        }
        if (Fn(l) && $t(c, l.tolerance))
          return this.handleCancel();
        this.handlePending(l, c);
        return;
      }
      t.cancelable && t.preventDefault(), s(a);
    }
    handleEnd() {
      const { onAbort: t, onEnd: n } = this.props;
      this.detach(), this.activated || t(this.props.active), n();
    }
    handleCancel() {
      const { onAbort: t, onCancel: n } = this.props;
      this.detach(), this.activated || t(this.props.active), n();
    }
    handleKeydown(t) {
      t.code === I.Esc && this.handleCancel();
    }
    removeTextSelection() {
      var t;
      (t = this.document.getSelection()) == null || t.removeAllRanges();
    }
  }
  const Ui = {
    cancel: {
      name: "pointercancel"
    },
    move: {
      name: "pointermove"
    },
    end: {
      name: "pointerup"
    }
  };
  class tn extends en {
    constructor(t) {
      const { event: n } = t, r = Me(n.target);
      super(t, Ui, r);
    }
  }
  tn.activators = [
    {
      eventName: "onPointerDown",
      handler: (e, t) => {
        let { nativeEvent: n } = e, { onActivation: r } = t;
        return !n.isPrimary || n.button !== 0 ? false : (r == null ? void 0 : r({
          event: n
        }), true);
      }
    }
  ];
  const qi = {
    move: {
      name: "mousemove"
    },
    end: {
      name: "mouseup"
    }
  };
  var Gt;
  (function(e) {
    e[e.RightClick = 2] = "RightClick";
  })(Gt || (Gt = {}));
  class Xi extends en {
    constructor(t) {
      super(t, qi, Me(t.event.target));
    }
  }
  Xi.activators = [
    {
      eventName: "onMouseDown",
      handler: (e, t) => {
        let { nativeEvent: n } = e, { onActivation: r } = t;
        return n.button === Gt.RightClick ? false : (r == null ? void 0 : r({
          event: n
        }), true);
      }
    }
  ];
  const Nt = {
    cancel: {
      name: "touchcancel"
    },
    move: {
      name: "touchmove"
    },
    end: {
      name: "touchend"
    }
  };
  class Ki extends en {
    constructor(t) {
      super(t, Nt);
    }
    static setup() {
      return window.addEventListener(Nt.move.name, t, {
        capture: false,
        passive: false
      }), function() {
        window.removeEventListener(Nt.move.name, t);
      };
      function t() {
      }
    }
  }
  Ki.activators = [
    {
      eventName: "onTouchStart",
      handler: (e, t) => {
        let { nativeEvent: n } = e, { onActivation: r } = t;
        const { touches: o } = n;
        return o.length > 1 ? false : (r == null ? void 0 : r({
          event: n
        }), true);
      }
    }
  ];
  var Le;
  (function(e) {
    e[e.Pointer = 0] = "Pointer", e[e.DraggableRect = 1] = "DraggableRect";
  })(Le || (Le = {}));
  var gt;
  (function(e) {
    e[e.TreeOrder = 0] = "TreeOrder", e[e.ReversedTreeOrder = 1] = "ReversedTreeOrder";
  })(gt || (gt = {}));
  function Yi(e) {
    let { acceleration: t, activator: n = Le.Pointer, canScroll: r, draggingRect: o, enabled: i, interval: s = 5, order: l = gt.TreeOrder, pointerCoordinates: a, scrollableAncestors: c, scrollableAncestorRects: g, delta: p, threshold: f } = e;
    const u = Zi({
      delta: p,
      disabled: !i
    }), [v, h] = ui(), w = d.useRef({
      x: 0,
      y: 0
    }), x = d.useRef({
      x: 0,
      y: 0
    }), S = d.useMemo(() => {
      switch (n) {
        case Le.Pointer:
          return a ? {
            top: a.y,
            bottom: a.y,
            left: a.x,
            right: a.x
          } : null;
        case Le.DraggableRect:
          return o;
      }
    }, [
      n,
      o,
      a
    ]), C = d.useRef(null), M = d.useCallback(() => {
      const R = C.current;
      if (!R)
        return;
      const D = w.current.x * x.current.x, k = w.current.y * x.current.y;
      R.scrollBy(D, k);
    }, []), b = d.useMemo(() => l === gt.TreeOrder ? [
      ...c
    ].reverse() : c, [
      l,
      c
    ]);
    d.useEffect(() => {
      if (!i || !c.length || !S) {
        h();
        return;
      }
      for (const R of b) {
        if ((r == null ? void 0 : r(R)) === false)
          continue;
        const D = c.indexOf(R), k = g[D];
        if (!k)
          continue;
        const { direction: P, speed: N } = Vi(R, k, S, t, f);
        for (const $ of [
          "x",
          "y"
        ])
          u[$][P[$]] || (N[$] = 0, P[$] = 0);
        if (N.x > 0 || N.y > 0) {
          h(), C.current = R, v(M, s), w.current = N, x.current = P;
          return;
        }
      }
      w.current = {
        x: 0,
        y: 0
      }, x.current = {
        x: 0,
        y: 0
      }, h();
    }, [
      t,
      M,
      r,
      h,
      i,
      s,
      JSON.stringify(S),
      JSON.stringify(u),
      v,
      c,
      b,
      g,
      JSON.stringify(f)
    ]);
  }
  const Wi = {
    x: {
      [V.Backward]: false,
      [V.Forward]: false
    },
    y: {
      [V.Backward]: false,
      [V.Forward]: false
    }
  };
  function Zi(e) {
    let { delta: t, disabled: n } = e;
    const r = at(t);
    return Be((o) => {
      if (n || !r || !o)
        return Wi;
      const i = {
        x: Math.sign(t.x - r.x),
        y: Math.sign(t.y - r.y)
      };
      return {
        x: {
          [V.Backward]: o.x[V.Backward] || i.x === -1,
          [V.Forward]: o.x[V.Forward] || i.x === 1
        },
        y: {
          [V.Backward]: o.y[V.Backward] || i.y === -1,
          [V.Forward]: o.y[V.Forward] || i.y === 1
        }
      };
    }, [
      n,
      t,
      r
    ]);
  }
  function Ji(e, t) {
    const n = t != null ? e.get(t) : void 0, r = n ? n.node.current : null;
    return Be((o) => {
      var i;
      return t == null ? null : (i = r ?? o) != null ? i : null;
    }, [
      r,
      t
    ]);
  }
  function Qi(e, t) {
    return d.useMemo(() => e.reduce((n, r) => {
      const { sensor: o } = r, i = o.activators.map((s) => ({
        eventName: s.eventName,
        handler: t(s.handler, r)
      }));
      return [
        ...n,
        ...i
      ];
    }, []), [
      e,
      t
    ]);
  }
  var Ge;
  (function(e) {
    e[e.Always = 0] = "Always", e[e.BeforeDragging = 1] = "BeforeDragging", e[e.WhileDragging = 2] = "WhileDragging";
  })(Ge || (Ge = {}));
  var Ht;
  (function(e) {
    e.Optimized = "optimized";
  })(Ht || (Ht = {}));
  const Mn = /* @__PURE__ */ new Map();
  function es(e, t) {
    let { dragging: n, dependencies: r, config: o } = t;
    const [i, s] = d.useState(null), { frequency: l, measure: a, strategy: c } = o, g = d.useRef(e), p = w(), f = Te(p), u = d.useCallback(function(x) {
      x === void 0 && (x = []), !f.current && s((S) => S === null ? x : S.concat(x.filter((C) => !S.includes(C))));
    }, [
      f
    ]), v = d.useRef(null), h = Be((x) => {
      if (p && !n)
        return Mn;
      if (!x || x === Mn || g.current !== e || i != null) {
        const S = /* @__PURE__ */ new Map();
        for (let C of e) {
          if (!C)
            continue;
          if (i && i.length > 0 && !i.includes(C.id) && C.rect.current) {
            S.set(C.id, C.rect.current);
            continue;
          }
          const M = C.node.current, b = M ? new Jt(a(M), M) : null;
          C.rect.current = b, b && S.set(C.id, b);
        }
        return S;
      }
      return x;
    }, [
      e,
      i,
      n,
      p,
      a
    ]);
    return d.useEffect(() => {
      g.current = e;
    }, [
      e
    ]), d.useEffect(() => {
      p || u();
    }, [
      n,
      p
    ]), d.useEffect(() => {
      i && i.length > 0 && s(null);
    }, [
      JSON.stringify(i)
    ]), d.useEffect(() => {
      p || typeof l != "number" || v.current !== null || (v.current = setTimeout(() => {
        u(), v.current = null;
      }, l));
    }, [
      l,
      p,
      u,
      ...r
    ]), {
      droppableRects: h,
      measureDroppableContainers: u,
      measuringScheduled: i != null
    };
    function w() {
      switch (c) {
        case Ge.Always:
          return false;
        case Ge.BeforeDragging:
          return n;
        default:
          return !n;
      }
    }
  }
  function nn(e, t) {
    return Be((n) => e ? n || (typeof t == "function" ? t(e) : e) : null, [
      t,
      e
    ]);
  }
  function ts(e, t) {
    return nn(e, t);
  }
  function ns(e) {
    let { callback: t, disabled: n } = e;
    const r = ht(t), o = d.useMemo(() => {
      if (n || typeof window > "u" || typeof window.MutationObserver > "u")
        return;
      const { MutationObserver: i } = window;
      return new i(r);
    }, [
      r,
      n
    ]);
    return d.useEffect(() => () => o == null ? void 0 : o.disconnect(), [
      o
    ]), o;
  }
  function vt(e) {
    let { callback: t, disabled: n } = e;
    const r = ht(t), o = d.useMemo(() => {
      if (n || typeof window > "u" || typeof window.ResizeObserver > "u")
        return;
      const { ResizeObserver: i } = window;
      return new i(r);
    }, [
      n
    ]);
    return d.useEffect(() => () => o == null ? void 0 : o.disconnect(), [
      o
    ]), o;
  }
  function rs(e) {
    return new Jt(Ue(e), e);
  }
  function kn(e, t, n) {
    t === void 0 && (t = rs);
    const [r, o] = d.useState(null);
    function i() {
      o((a) => {
        if (!e)
          return null;
        if (e.isConnected === false) {
          var c;
          return (c = a ?? n) != null ? c : null;
        }
        const g = t(e);
        return JSON.stringify(a) === JSON.stringify(g) ? a : g;
      });
    }
    const s = ns({
      callback(a) {
        if (e)
          for (const c of a) {
            const { type: g, target: p } = c;
            if (g === "childList" && p instanceof HTMLElement && p.contains(e)) {
              i();
              break;
            }
          }
      }
    }), l = vt({
      callback: i
    });
    return ie(() => {
      i(), e ? (l == null ? void 0 : l.observe(e), s == null ? void 0 : s.observe(document.body, {
        childList: true,
        subtree: true
      })) : (l == null ? void 0 : l.disconnect(), s == null ? void 0 : s.disconnect());
    }, [
      e
    ]), r;
  }
  function os(e) {
    const t = nn(e);
    return Zn(e, t);
  }
  const In = [];
  function is(e) {
    const t = d.useRef(e), n = Be((r) => e ? r && r !== In && e && t.current && e.parentNode === t.current.parentNode ? r : Zt(e) : In, [
      e
    ]);
    return d.useEffect(() => {
      t.current = e;
    }, [
      e
    ]), n;
  }
  function ss(e) {
    const [t, n] = d.useState(null), r = d.useRef(e), o = d.useCallback((i) => {
      const s = Pt(i.target);
      s && n((l) => l ? (l.set(s, zt(s)), new Map(l)) : null);
    }, []);
    return d.useEffect(() => {
      const i = r.current;
      if (e !== i) {
        s(i);
        const l = e.map((a) => {
          const c = Pt(a);
          return c ? (c.addEventListener("scroll", o, {
            passive: true
          }), [
            c,
            zt(c)
          ]) : null;
        }).filter((a) => a != null);
        n(l.length ? new Map(l) : null), r.current = e;
      }
      return () => {
        s(e), s(i);
      };
      function s(l) {
        l.forEach((a) => {
          const c = Pt(a);
          c == null ? void 0 : c.removeEventListener("scroll", o);
        });
      }
    }, [
      o,
      e
    ]), d.useMemo(() => e.length ? t ? Array.from(t.values()).reduce((i, s) => De(i, s), Q) : or(e) : Q, [
      e,
      t
    ]);
  }
  function Pn(e, t) {
    t === void 0 && (t = []);
    const n = d.useRef(null);
    return d.useEffect(() => {
      n.current = null;
    }, t), d.useEffect(() => {
      const r = e !== Q;
      r && !n.current && (n.current = e), !r && n.current && (n.current = null);
    }, [
      e
    ]), n.current ? ut(e, n.current) : Q;
  }
  function ls(e) {
    d.useEffect(() => {
      if (!pt)
        return;
      const t = e.map((n) => {
        let { sensor: r } = n;
        return r.setup == null ? void 0 : r.setup();
      });
      return () => {
        for (const n of t)
          n == null ? void 0 : n();
      };
    }, e.map((t) => {
      let { sensor: n } = t;
      return n;
    }));
  }
  function as(e, t) {
    return d.useMemo(() => e.reduce((n, r) => {
      let { eventName: o, handler: i } = r;
      return n[o] = (s) => {
        i(s, t);
      }, n;
    }, {}), [
      e,
      t
    ]);
  }
  function lr(e) {
    return d.useMemo(() => e ? $i(e) : null, [
      e
    ]);
  }
  const $n = [];
  function us(e, t) {
    t === void 0 && (t = Ue);
    const [n] = e, r = lr(n ? z(n) : null), [o, i] = d.useState($n);
    function s() {
      i(() => e.length ? e.map((a) => nr(a) ? r : new Jt(t(a), a)) : $n);
    }
    const l = vt({
      callback: s
    });
    return ie(() => {
      l == null ? void 0 : l.disconnect(), s(), e.forEach((a) => l == null ? void 0 : l.observe(a));
    }, [
      e
    ]), o;
  }
  function ar(e) {
    if (!e)
      return null;
    if (e.children.length > 1)
      return e;
    const t = e.children[0];
    return He(t) ? t : e;
  }
  function cs(e) {
    let { measure: t } = e;
    const [n, r] = d.useState(null), o = d.useCallback((c) => {
      for (const { target: g } of c)
        if (He(g)) {
          r((p) => {
            const f = t(g);
            return p ? {
              ...p,
              width: f.width,
              height: f.height
            } : f;
          });
          break;
        }
    }, [
      t
    ]), i = vt({
      callback: o
    }), s = d.useCallback((c) => {
      const g = ar(c);
      i == null ? void 0 : i.disconnect(), g && (i == null ? void 0 : i.observe(g)), r(g ? t(g) : null);
    }, [
      t,
      i
    ]), [l, a] = lt(s);
    return d.useMemo(() => ({
      nodeRef: l,
      rect: n,
      setRef: a
    }), [
      n,
      l,
      a
    ]);
  }
  const ds = [
    {
      sensor: tn,
      options: {}
    },
    {
      sensor: Qt,
      options: {}
    }
  ], gs = {
    current: {}
  }, st = {
    draggable: {
      measure: En
    },
    droppable: {
      measure: En,
      strategy: Ge.WhileDragging,
      frequency: Ht.Optimized
    },
    dragOverlay: {
      measure: Ue
    }
  };
  class je extends Map {
    get(t) {
      var n;
      return t != null && (n = super.get(t)) != null ? n : void 0;
    }
    toArray() {
      return Array.from(this.values());
    }
    getEnabled() {
      return this.toArray().filter((t) => {
        let { disabled: n } = t;
        return !n;
      });
    }
    getNodeFor(t) {
      var n, r;
      return (n = (r = this.get(t)) == null ? void 0 : r.node.current) != null ? n : void 0;
    }
  }
  const fs = {
    activatorEvent: null,
    active: null,
    activeNode: null,
    activeNodeRect: null,
    collisions: null,
    containerNodeRect: null,
    draggableNodes: /* @__PURE__ */ new Map(),
    droppableRects: /* @__PURE__ */ new Map(),
    droppableContainers: new je(),
    over: null,
    dragOverlay: {
      nodeRef: {
        current: null
      },
      rect: null,
      setRef: dt
    },
    scrollableAncestors: [],
    scrollableAncestorRects: [],
    measuringConfiguration: st,
    measureDroppableContainers: dt,
    windowRect: null,
    measuringScheduled: false
  }, ur = {
    activatorEvent: null,
    activators: [],
    active: null,
    activeNodeRect: null,
    ariaDescribedById: {
      draggable: ""
    },
    dispatch: dt,
    draggableNodes: /* @__PURE__ */ new Map(),
    over: null,
    measureDroppableContainers: dt
  }, qe = d.createContext(ur), cr = d.createContext(fs);
  function ps() {
    return {
      draggable: {
        active: null,
        initialCoordinates: {
          x: 0,
          y: 0
        },
        nodes: /* @__PURE__ */ new Map(),
        translate: {
          x: 0,
          y: 0
        }
      },
      droppable: {
        containers: new je()
      }
    };
  }
  function hs(e, t) {
    switch (t.type) {
      case A.DragStart:
        return {
          ...e,
          draggable: {
            ...e.draggable,
            initialCoordinates: t.initialCoordinates,
            active: t.active
          }
        };
      case A.DragMove:
        return e.draggable.active == null ? e : {
          ...e,
          draggable: {
            ...e.draggable,
            translate: {
              x: t.coordinates.x - e.draggable.initialCoordinates.x,
              y: t.coordinates.y - e.draggable.initialCoordinates.y
            }
          }
        };
      case A.DragEnd:
      case A.DragCancel:
        return {
          ...e,
          draggable: {
            ...e.draggable,
            active: null,
            initialCoordinates: {
              x: 0,
              y: 0
            },
            translate: {
              x: 0,
              y: 0
            }
          }
        };
      case A.RegisterDroppable: {
        const { element: n } = t, { id: r } = n, o = new je(e.droppable.containers);
        return o.set(r, n), {
          ...e,
          droppable: {
            ...e.droppable,
            containers: o
          }
        };
      }
      case A.SetDroppableDisabled: {
        const { id: n, key: r, disabled: o } = t, i = e.droppable.containers.get(n);
        if (!i || r !== i.key)
          return e;
        const s = new je(e.droppable.containers);
        return s.set(n, {
          ...i,
          disabled: o
        }), {
          ...e,
          droppable: {
            ...e.droppable,
            containers: s
          }
        };
      }
      case A.UnregisterDroppable: {
        const { id: n, key: r } = t, o = e.droppable.containers.get(n);
        if (!o || r !== o.key)
          return e;
        const i = new je(e.droppable.containers);
        return i.delete(n), {
          ...e,
          droppable: {
            ...e.droppable,
            containers: i
          }
        };
      }
      default:
        return e;
    }
  }
  function ms(e) {
    let { disabled: t } = e;
    const { active: n, activatorEvent: r, draggableNodes: o } = d.useContext(qe), i = at(r), s = at(n == null ? void 0 : n.id);
    return d.useEffect(() => {
      if (!t && !r && i && s != null) {
        if (!Wt(i) || document.activeElement === i.target)
          return;
        const l = o.get(s);
        if (!l)
          return;
        const { activatorNode: a, node: c } = l;
        if (!a.current && !c.current)
          return;
        requestAnimationFrame(() => {
          for (const g of [
            a.current,
            c.current
          ]) {
            if (!g)
              continue;
            const p = gi(g);
            if (p) {
              p.focus();
              break;
            }
          }
        });
      }
    }, [
      r,
      t,
      o,
      s,
      i
    ]), null;
  }
  function dr(e, t) {
    let { transform: n, ...r } = t;
    return e != null && e.length ? e.reduce((o, i) => i({
      transform: o,
      ...r
    }), n) : n;
  }
  function vs(e) {
    return d.useMemo(() => ({
      draggable: {
        ...st.draggable,
        ...e == null ? void 0 : e.draggable
      },
      droppable: {
        ...st.droppable,
        ...e == null ? void 0 : e.droppable
      },
      dragOverlay: {
        ...st.dragOverlay,
        ...e == null ? void 0 : e.dragOverlay
      }
    }), [
      e == null ? void 0 : e.draggable,
      e == null ? void 0 : e.droppable,
      e == null ? void 0 : e.dragOverlay
    ]);
  }
  function xs(e) {
    let { activeNode: t, measure: n, initialRect: r, config: o = true } = e;
    const i = d.useRef(false), { x: s, y: l } = typeof o == "boolean" ? {
      x: o,
      y: o
    } : o;
    ie(() => {
      if (!s && !l || !t) {
        i.current = false;
        return;
      }
      if (i.current || !r)
        return;
      const c = t == null ? void 0 : t.node.current;
      if (!c || c.isConnected === false)
        return;
      const g = n(c), p = Zn(g, r);
      if (s || (p.x = 0), l || (p.y = 0), i.current = true, Math.abs(p.x) > 0 || Math.abs(p.y) > 0) {
        const f = Qn(c);
        f && f.scrollBy({
          top: p.y,
          left: p.x
        });
      }
    }, [
      t,
      s,
      l,
      r,
      n
    ]);
  }
  const xt = d.createContext({
    ...Q,
    scaleX: 1,
    scaleY: 1
  });
  var ge;
  (function(e) {
    e[e.Uninitialized = 0] = "Uninitialized", e[e.Initializing = 1] = "Initializing", e[e.Initialized = 2] = "Initialized";
  })(ge || (ge = {}));
  const ws = d.memo(function(t) {
    var n, r, o, i;
    let { id: s, accessibility: l, autoScroll: a = true, children: c, sensors: g = ds, collisionDetection: p = _i, measuring: f, modifiers: u, ...v } = t;
    const h = d.useReducer(hs, void 0, ps), [w, x] = h, [S, C] = xi(), [M, b] = d.useState(ge.Uninitialized), R = M === ge.Initialized, { draggable: { active: D, nodes: k, translate: P }, droppable: { containers: N } } = w, $ = D != null ? k.get(D) : null, q = d.useRef({
      initial: null,
      translated: null
    }), Y = d.useMemo(() => {
      var j;
      return D != null ? {
        id: D,
        data: (j = $ == null ? void 0 : $.data) != null ? j : gs,
        rect: q
      } : null;
    }, [
      D,
      $
    ]), _ = d.useRef(null), [se, Xe] = d.useState(null), [ne, rn] = d.useState(null), he = Te(v, Object.values(v)), wt = mt("DndDescribedBy", s), on = d.useMemo(() => N.getEnabled(), [
      N
    ]), me = vs(f), { droppableRects: we, measureDroppableContainers: Ke, measuringScheduled: sn } = es(on, {
      dragging: R,
      dependencies: [
        P.x,
        P.y
      ],
      config: me.droppable
    }), W = Ji(k, D), ln = d.useMemo(() => ne ? ct(ne) : null, [
      ne
    ]), an = wr(), un = ts(W, me.draggable.measure);
    xs({
      activeNode: D != null ? k.get(D) : null,
      config: an.layoutShiftCompensation,
      initialRect: un,
      measure: me.draggable.measure
    });
    const Z = kn(W, me.draggable.measure, un), St = kn(W ? W.parentElement : null), ve = d.useRef({
      activatorEvent: null,
      active: null,
      activeNode: W,
      collisionRect: null,
      collisions: null,
      droppableRects: we,
      draggableNodes: k,
      draggingNode: null,
      draggingNodeRect: null,
      droppableContainers: N,
      over: null,
      scrollableAncestors: [],
      scrollAdjustedTranslate: null
    }), cn = N.getNodeFor((n = ve.current.over) == null ? void 0 : n.id), xe = cs({
      measure: me.dragOverlay.measure
    }), Ye = (r = xe.nodeRef.current) != null ? r : W, Se = R ? (o = xe.rect) != null ? o : Z : null, dn = !!(xe.nodeRef.current && xe.rect), gn = os(dn ? null : Z), Ct = lr(Ye ? z(Ye) : null), le = is(R ? cn ?? W : null), We = us(le), Ze = dr(u, {
      transform: {
        x: P.x - gn.x,
        y: P.y - gn.y,
        scaleX: 1,
        scaleY: 1
      },
      activatorEvent: ne,
      active: Y,
      activeNodeRect: Z,
      containerNodeRect: St,
      draggingNodeRect: Se,
      over: ve.current.over,
      overlayNodeRect: xe.rect,
      scrollableAncestors: le,
      scrollableAncestorRects: We,
      windowRect: Ct
    }), fn = ln ? De(ln, P) : null, pn = ss(le), gr = Pn(pn), fr = Pn(pn, [
      Z
    ]), Ce = De(Ze, gr), Re = Se ? ki(Se, Ze) : null, ke = Y && Re ? p({
      active: Y,
      collisionRect: Re,
      droppableRects: we,
      droppableContainers: on,
      pointerCoordinates: fn
    }) : null, hn = Ei(ke, "id"), [ae, mn] = d.useState(null), pr = dn ? Ze : De(Ze, fr), hr = Fi(pr, (i = ae == null ? void 0 : ae.rect) != null ? i : null, Z), Rt = d.useRef(null), vn = d.useCallback((j, G) => {
      let { sensor: H, options: ue } = G;
      if (_.current == null)
        return;
      const X = k.get(_.current);
      if (!X)
        return;
      const B = j.nativeEvent, ee = new H({
        active: _.current,
        activeNode: X,
        event: B,
        options: ue,
        context: ve,
        onAbort(L) {
          if (!k.get(L))
            return;
          const { onDragAbort: te } = he.current, re = {
            id: L
          };
          te == null ? void 0 : te(re), S({
            type: "onDragAbort",
            event: re
          });
        },
        onPending(L, ce, te, re) {
          if (!k.get(L))
            return;
          const { onDragPending: Pe } = he.current, de = {
            id: L,
            constraint: ce,
            initialCoordinates: te,
            offset: re
          };
          Pe == null ? void 0 : Pe(de), S({
            type: "onDragPending",
            event: de
          });
        },
        onStart(L) {
          const ce = _.current;
          if (ce == null)
            return;
          const te = k.get(ce);
          if (!te)
            return;
          const { onDragStart: re } = he.current, Ie = {
            activatorEvent: B,
            active: {
              id: ce,
              data: te.data,
              rect: q
            }
          };
          Ee.unstable_batchedUpdates(() => {
            re == null ? void 0 : re(Ie), b(ge.Initializing), x({
              type: A.DragStart,
              initialCoordinates: L,
              active: ce
            }), S({
              type: "onDragStart",
              event: Ie
            }), Xe(Rt.current), rn(B);
          });
        },
        onMove(L) {
          x({
            type: A.DragMove,
            coordinates: L
          });
        },
        onEnd: be(A.DragEnd),
        onCancel: be(A.DragCancel)
      });
      Rt.current = ee;
      function be(L) {
        return async function() {
          const { active: te, collisions: re, over: Ie, scrollAdjustedTranslate: Pe } = ve.current;
          let de = null;
          if (te && Pe) {
            const { cancelDrop: $e } = he.current;
            de = {
              activatorEvent: B,
              active: te,
              collisions: re,
              delta: Pe,
              over: Ie
            }, L === A.DragEnd && typeof $e == "function" && await Promise.resolve($e(de)) && (L = A.DragCancel);
          }
          _.current = null, Ee.unstable_batchedUpdates(() => {
            x({
              type: L
            }), b(ge.Uninitialized), mn(null), Xe(null), rn(null), Rt.current = null;
            const $e = L === A.DragEnd ? "onDragEnd" : "onDragCancel";
            if (de) {
              const bt = he.current[$e];
              bt == null ? void 0 : bt(de), S({
                type: $e,
                event: de
              });
            }
          });
        };
      }
    }, [
      k
    ]), mr = d.useCallback((j, G) => (H, ue) => {
      const X = H.nativeEvent, B = k.get(ue);
      if (_.current !== null || !B || X.dndKit || X.defaultPrevented)
        return;
      const ee = {
        active: B
      };
      j(H, G.options, ee) === true && (X.dndKit = {
        capturedBy: G.sensor
      }, _.current = ue, vn(H, G));
    }, [
      k,
      vn
    ]), xn = Qi(g, mr);
    ls(g), ie(() => {
      Z && M === ge.Initializing && b(ge.Initialized);
    }, [
      Z,
      M
    ]), d.useEffect(() => {
      const { onDragMove: j } = he.current, { active: G, activatorEvent: H, collisions: ue, over: X } = ve.current;
      if (!G || !H)
        return;
      const B = {
        active: G,
        activatorEvent: H,
        collisions: ue,
        delta: {
          x: Ce.x,
          y: Ce.y
        },
        over: X
      };
      Ee.unstable_batchedUpdates(() => {
        j == null ? void 0 : j(B), S({
          type: "onDragMove",
          event: B
        });
      });
    }, [
      Ce.x,
      Ce.y
    ]), d.useEffect(() => {
      const { active: j, activatorEvent: G, collisions: H, droppableContainers: ue, scrollAdjustedTranslate: X } = ve.current;
      if (!j || _.current == null || !G || !X)
        return;
      const { onDragOver: B } = he.current, ee = ue.get(hn), be = ee && ee.rect.current ? {
        id: ee.id,
        rect: ee.rect.current,
        data: ee.data,
        disabled: ee.disabled
      } : null, L = {
        active: j,
        activatorEvent: G,
        collisions: H,
        delta: {
          x: X.x,
          y: X.y
        },
        over: be
      };
      Ee.unstable_batchedUpdates(() => {
        mn(be), B == null ? void 0 : B(L), S({
          type: "onDragOver",
          event: L
        });
      });
    }, [
      hn
    ]), ie(() => {
      ve.current = {
        activatorEvent: ne,
        active: Y,
        activeNode: W,
        collisionRect: Re,
        collisions: ke,
        droppableRects: we,
        draggableNodes: k,
        draggingNode: Ye,
        draggingNodeRect: Se,
        droppableContainers: N,
        over: ae,
        scrollableAncestors: le,
        scrollAdjustedTranslate: Ce
      }, q.current = {
        initial: Se,
        translated: Re
      };
    }, [
      Y,
      W,
      ke,
      Re,
      k,
      Ye,
      Se,
      we,
      N,
      ae,
      le,
      Ce
    ]), Yi({
      ...an,
      delta: P,
      draggingRect: Re,
      pointerCoordinates: fn,
      scrollableAncestors: le,
      scrollableAncestorRects: We
    });
    const vr = d.useMemo(() => ({
      active: Y,
      activeNode: W,
      activeNodeRect: Z,
      activatorEvent: ne,
      collisions: ke,
      containerNodeRect: St,
      dragOverlay: xe,
      draggableNodes: k,
      droppableContainers: N,
      droppableRects: we,
      over: ae,
      measureDroppableContainers: Ke,
      scrollableAncestors: le,
      scrollableAncestorRects: We,
      measuringConfiguration: me,
      measuringScheduled: sn,
      windowRect: Ct
    }), [
      Y,
      W,
      Z,
      ne,
      ke,
      St,
      xe,
      k,
      N,
      we,
      ae,
      Ke,
      le,
      We,
      me,
      sn,
      Ct
    ]), xr = d.useMemo(() => ({
      activatorEvent: ne,
      activators: xn,
      active: Y,
      activeNodeRect: Z,
      ariaDescribedById: {
        draggable: wt
      },
      dispatch: x,
      draggableNodes: k,
      over: ae,
      measureDroppableContainers: Ke
    }), [
      ne,
      xn,
      Y,
      Z,
      x,
      wt,
      k,
      ae,
      Ke
    ]);
    return O.createElement(Wn.Provider, {
      value: C
    }, O.createElement(qe.Provider, {
      value: xr
    }, O.createElement(cr.Provider, {
      value: vr
    }, O.createElement(xt.Provider, {
      value: hr
    }, c)), O.createElement(ms, {
      disabled: (l == null ? void 0 : l.restoreFocus) === false
    })), O.createElement(Ci, {
      ...l,
      hiddenTextDescribedById: wt
    }));
    function wr() {
      const j = (se == null ? void 0 : se.autoScrollEnabled) === false, G = typeof a == "object" ? a.enabled === false : a === false, H = R && !j && !G;
      return typeof a == "object" ? {
        ...a,
        enabled: H
      } : {
        enabled: H
      };
    }
  }), Ss = d.createContext(null), Nn = "button", Cs = "Draggable";
  function Rs(e) {
    let { id: t, data: n, disabled: r = false, attributes: o } = e;
    const i = mt(Cs), { activators: s, activatorEvent: l, active: a, activeNodeRect: c, ariaDescribedById: g, draggableNodes: p, over: f } = d.useContext(qe), { role: u = Nn, roleDescription: v = "draggable", tabIndex: h = 0 } = o ?? {}, w = (a == null ? void 0 : a.id) === t, x = d.useContext(w ? xt : Ss), [S, C] = lt(), [M, b] = lt(), R = as(s, t), D = Te(n);
    ie(() => (p.set(t, {
      id: t,
      key: i,
      node: S,
      activatorNode: M,
      data: D
    }), () => {
      const P = p.get(t);
      P && P.key === i && p.delete(t);
    }), [
      p,
      t
    ]);
    const k = d.useMemo(() => ({
      role: u,
      tabIndex: h,
      "aria-disabled": r,
      "aria-pressed": w && u === Nn ? true : void 0,
      "aria-roledescription": v,
      "aria-describedby": g.draggable
    }), [
      r,
      u,
      h,
      w,
      v,
      g.draggable
    ]);
    return {
      active: a,
      activatorEvent: l,
      activeNodeRect: c,
      attributes: k,
      isDragging: w,
      listeners: r ? void 0 : R,
      node: S,
      over: f,
      setNodeRef: C,
      setActivatorNodeRef: b,
      transform: x
    };
  }
  function bs() {
    return d.useContext(cr);
  }
  const ys = "Droppable", Es = {
    timeout: 25
  };
  function Ds(e) {
    let { data: t, disabled: n = false, id: r, resizeObserverConfig: o } = e;
    const i = mt(ys), { active: s, dispatch: l, over: a, measureDroppableContainers: c } = d.useContext(qe), g = d.useRef({
      disabled: n
    }), p = d.useRef(false), f = d.useRef(null), u = d.useRef(null), { disabled: v, updateMeasurementsFor: h, timeout: w } = {
      ...Es,
      ...o
    }, x = Te(h ?? r), S = d.useCallback(() => {
      if (!p.current) {
        p.current = true;
        return;
      }
      u.current != null && clearTimeout(u.current), u.current = setTimeout(() => {
        c(Array.isArray(x.current) ? x.current : [
          x.current
        ]), u.current = null;
      }, w);
    }, [
      w
    ]), C = vt({
      callback: S,
      disabled: v || !s
    }), M = d.useCallback((k, P) => {
      C && (P && (C.unobserve(P), p.current = false), k && C.observe(k));
    }, [
      C
    ]), [b, R] = lt(M), D = Te(t);
    return d.useEffect(() => {
      !C || !b.current || (C.disconnect(), p.current = false, C.observe(b.current));
    }, [
      b,
      C
    ]), d.useEffect(() => (l({
      type: A.RegisterDroppable,
      element: {
        id: r,
        key: i,
        disabled: n,
        node: b,
        rect: f,
        data: D
      }
    }), () => l({
      type: A.UnregisterDroppable,
      key: i,
      id: r
    })), [
      r
    ]), d.useEffect(() => {
      n !== g.current.disabled && (l({
        type: A.SetDroppableDisabled,
        id: r,
        key: i,
        disabled: n
      }), g.current.disabled = n);
    }, [
      r,
      i,
      n,
      l
    ]), {
      active: s,
      rect: f,
      isOver: (a == null ? void 0 : a.id) === r,
      node: b,
      over: a,
      setNodeRef: R
    };
  }
  function _s(e) {
    let { animation: t, children: n } = e;
    const [r, o] = d.useState(null), [i, s] = d.useState(null), l = at(n);
    return !n && !r && l && o(l), ie(() => {
      if (!i)
        return;
      const a = r == null ? void 0 : r.key, c = r == null ? void 0 : r.props.id;
      if (a == null || c == null) {
        o(null);
        return;
      }
      Promise.resolve(t(c, i)).then(() => {
        o(null);
      });
    }, [
      t,
      r,
      i
    ]), O.createElement(O.Fragment, null, n, r ? d.cloneElement(r, {
      ref: s
    }) : null);
  }
  const Fs = {
    x: 0,
    y: 0,
    scaleX: 1,
    scaleY: 1
  };
  function Ms(e) {
    let { children: t } = e;
    return O.createElement(qe.Provider, {
      value: ur
    }, O.createElement(xt.Provider, {
      value: Fs
    }, t));
  }
  const ks = {
    position: "fixed",
    touchAction: "none"
  }, Is = (e) => Wt(e) ? "transform 250ms ease" : void 0, Ps = d.forwardRef((e, t) => {
    let { as: n, activatorEvent: r, adjustScale: o, children: i, className: s, rect: l, style: a, transform: c, transition: g = Is } = e;
    if (!l)
      return null;
    const p = o ? c : {
      ...c,
      scaleX: 1,
      scaleY: 1
    }, f = {
      ...ks,
      width: l.width,
      height: l.height,
      top: l.top,
      left: l.left,
      transform: ze.Transform.toString(p),
      transformOrigin: o && r ? bi(r, l) : void 0,
      transition: typeof g == "function" ? g(r) : g,
      ...a
    };
    return O.createElement(n, {
      className: s,
      style: f,
      ref: t
    }, i);
  }), $s = (e) => (t) => {
    let { active: n, dragOverlay: r } = t;
    const o = {}, { styles: i, className: s } = e;
    if (i != null && i.active)
      for (const [l, a] of Object.entries(i.active))
        a !== void 0 && (o[l] = n.node.style.getPropertyValue(l), n.node.style.setProperty(l, a));
    if (i != null && i.dragOverlay)
      for (const [l, a] of Object.entries(i.dragOverlay))
        a !== void 0 && r.node.style.setProperty(l, a);
    return s != null && s.active && n.node.classList.add(s.active), s != null && s.dragOverlay && r.node.classList.add(s.dragOverlay), function() {
      for (const [a, c] of Object.entries(o))
        n.node.style.setProperty(a, c);
      s != null && s.active && n.node.classList.remove(s.active);
    };
  }, Ns = (e) => {
    let { transform: { initial: t, final: n } } = e;
    return [
      {
        transform: ze.Transform.toString(t)
      },
      {
        transform: ze.Transform.toString(n)
      }
    ];
  }, Os = {
    duration: 250,
    easing: "ease",
    keyframes: Ns,
    sideEffects: $s({
      styles: {
        active: {
          opacity: "0"
        }
      }
    })
  };
  function As(e) {
    let { config: t, draggableNodes: n, droppableContainers: r, measuringConfiguration: o } = e;
    return ht((i, s) => {
      if (t === null)
        return;
      const l = n.get(i);
      if (!l)
        return;
      const a = l.node.current;
      if (!a)
        return;
      const c = ar(s);
      if (!c)
        return;
      const { transform: g } = z(s).getComputedStyle(s), p = Jn(g);
      if (!p)
        return;
      const f = typeof t == "function" ? t : Vs(t);
      return ir(a, o.draggable.measure), f({
        active: {
          id: i,
          data: l.data,
          node: a,
          rect: o.draggable.measure(a)
        },
        draggableNodes: n,
        dragOverlay: {
          node: s,
          rect: o.dragOverlay.measure(c)
        },
        droppableContainers: r,
        measuringConfiguration: o,
        transform: p
      });
    });
  }
  function Vs(e) {
    const { duration: t, easing: n, sideEffects: r, keyframes: o } = {
      ...Os,
      ...e
    };
    return (i) => {
      let { active: s, dragOverlay: l, transform: a, ...c } = i;
      if (!t)
        return;
      const g = {
        x: l.rect.left - s.rect.left,
        y: l.rect.top - s.rect.top
      }, p = {
        scaleX: a.scaleX !== 1 ? s.rect.width * a.scaleX / l.rect.width : 1,
        scaleY: a.scaleY !== 1 ? s.rect.height * a.scaleY / l.rect.height : 1
      }, f = {
        x: a.x - g.x,
        y: a.y - g.y,
        ...p
      }, u = o({
        ...c,
        active: s,
        dragOverlay: l,
        transform: {
          initial: a,
          final: f
        }
      }), [v] = u, h = u[u.length - 1];
      if (JSON.stringify(v) === JSON.stringify(h))
        return;
      const w = r == null ? void 0 : r({
        active: s,
        dragOverlay: l,
        ...c
      }), x = l.node.animate(u, {
        duration: t,
        easing: n,
        fill: "forwards"
      });
      return new Promise((S) => {
        x.onfinish = () => {
          w == null ? void 0 : w(), S();
        };
      });
    };
  }
  let On = 0;
  function Ls(e) {
    return d.useMemo(() => {
      if (e != null)
        return On++, On;
    }, [
      e
    ]);
  }
  const js = O.memo((e) => {
    let { adjustScale: t = false, children: n, dropAnimation: r, style: o, transition: i, modifiers: s, wrapperElement: l = "div", className: a, zIndex: c = 999 } = e;
    const { activatorEvent: g, active: p, activeNodeRect: f, containerNodeRect: u, draggableNodes: v, droppableContainers: h, dragOverlay: w, over: x, measuringConfiguration: S, scrollableAncestors: C, scrollableAncestorRects: M, windowRect: b } = bs(), R = d.useContext(xt), D = Ls(p == null ? void 0 : p.id), k = dr(s, {
      activatorEvent: g,
      active: p,
      activeNodeRect: f,
      containerNodeRect: u,
      draggingNodeRect: w.rect,
      over: x,
      overlayNodeRect: w.rect,
      scrollableAncestors: C,
      scrollableAncestorRects: M,
      transform: R,
      windowRect: b
    }), P = nn(f), N = As({
      config: r,
      draggableNodes: v,
      droppableContainers: h,
      measuringConfiguration: S
    }), $ = P ? w.setRef : void 0;
    return O.createElement(Ms, null, O.createElement(_s, {
      animation: N
    }, p && D ? O.createElement(Ps, {
      key: D,
      id: p.id,
      ref: $,
      as: l,
      activatorEvent: g,
      adjustScale: t,
      className: a,
      transition: i,
      rect: P,
      style: {
        zIndex: c,
        ...o
      },
      transform: k
    }, n) : null));
  });
  function Ts({ row: e, onRowClick: t, enableRowSelection: n, isSelected: r }) {
    const { attributes: o, listeners: i, setNodeRef: s, transform: l, isDragging: a } = Rs({
      id: e.original.id,
      data: {
        sourceId: e.original.id,
        title: e.original.title
      }
    }), c = l ? {
      transform: `translate3d(${l.x}px, ${l.y}px, 0)`
    } : void 0;
    return m.jsx("tr", {
      ref: s,
      style: c,
      "aria-roledescription": "draggable source",
      ...o,
      ...i,
      className: _e("group cursor-grab active:cursor-grabbing", a ? "opacity-30" : "hover:bg-neutral-50 dark:hover:bg-slate-700", r ? "bg-neutral-50 dark:bg-slate-700" : "even:bg-neutral-50/30 dark:even:bg-slate-800/50"),
      onClick: (g) => {
        a || (t ? t(e.original) : n && e.toggleSelected());
      },
      children: e.getVisibleCells().map((g) => m.jsx("td", {
        className: "px-3 py-2.5 text-xs text-neutral-600 dark:text-slate-400 group-hover:text-neutral-900 dark:group-hover:text-slate-100 align-top",
        children: it(g.column.columnDef.cell, g.getContext())
      }, g.id))
    });
  }
  const zs = d.memo(Ts), Gs = d.forwardRef(function({ row: t, table: n, rowSelection: r, onEditFolder: o, onDeleteFolder: i, isOver: s }, l) {
    const { _folder: a, _sourceCount: c } = t.original, g = t.getIsExpanded(), p = n.getVisibleLeafColumns().length;
    r = r || n.getState().rowSelection;
    const f = d.useMemo(() => (t.original.subRows || []).map((x) => x.id), [
      t.original.subRows
    ]), u = d.useMemo(() => f.filter((x) => r[x]).length, [
      f,
      r
    ]), v = f.length > 0 && u === f.length, h = u > 0 && u < f.length, w = d.useCallback((x) => {
      x.stopPropagation(), n.setRowSelection((S) => {
        const C = {
          ...S
        };
        if (f.length > 0 && f.every((b) => S[b]))
          for (const b of f)
            delete C[b];
        else
          for (const b of f)
            C[b] = true;
        return C;
      });
    }, [
      n,
      f
    ]);
    return m.jsx("tr", {
      ref: l,
      role: "row",
      tabIndex: 0,
      "aria-expanded": g,
      "aria-dropeffect": s ? "move" : "none",
      "aria-label": `${(a == null ? void 0 : a.name) || "Ungrouped"} folder, ${c} sources, ${g ? "expanded" : "collapsed"}`,
      className: _e("bg-neutral-50 dark:bg-slate-900 cursor-pointer hover:bg-neutral-100 dark:hover:bg-slate-800", s && "ring-2 ring-inset ring-blue-400 bg-blue-50 dark:bg-blue-950"),
      onClick: () => t.toggleExpanded(),
      onKeyDown: (x) => {
        x.target.type !== "checkbox" && (x.key === "Enter" || x.key === " ") && (x.preventDefault(), t.toggleExpanded());
      },
      children: m.jsx("td", {
        colSpan: p,
        className: "px-3 py-2",
        children: m.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            m.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                m.jsx("input", {
                  ref: (x) => {
                    x && (x.indeterminate = h);
                  },
                  type: "checkbox",
                  className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-gray-900 focus:ring-1 cursor-pointer",
                  checked: v,
                  "aria-checked": h ? "mixed" : v,
                  onChange: w,
                  onClick: (x) => x.stopPropagation(),
                  "aria-label": `Select all sources in ${(a == null ? void 0 : a.name) || "Ungrouped"} folder`
                }),
                g ? m.jsx(Dr, {
                  className: "w-3.5 h-3.5 text-neutral-500 dark:text-slate-400"
                }) : m.jsx(Sr, {
                  className: "w-3.5 h-3.5 text-neutral-500 dark:text-slate-400"
                }),
                m.jsx(Hr, {
                  className: "w-3.5 h-3.5 text-neutral-400 dark:text-slate-500"
                }),
                m.jsx("span", {
                  title: a ? a.name : "Ungrouped",
                  className: _e("text-xs truncate max-w-[200px]", a ? "font-medium text-neutral-800 dark:text-slate-200" : "italic text-neutral-500 dark:text-slate-400"),
                  children: a ? a.name : "Ungrouped"
                }),
                m.jsxs("span", {
                  className: "text-xs text-neutral-400 dark:text-slate-500",
                  children: [
                    "(",
                    c,
                    ")"
                  ]
                })
              ]
            }),
            a && m.jsxs(_r, {
              className: "relative",
              children: [
                m.jsx(Fr, {
                  "aria-label": `Options for folder ${a.name}`,
                  onClick: (x) => x.stopPropagation(),
                  className: "p-1 rounded hover:bg-neutral-200 dark:hover:bg-slate-700 text-neutral-400 dark:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400",
                  children: m.jsx(Tr, {
                    className: "w-3.5 h-3.5",
                    "aria-hidden": "true"
                  })
                }),
                m.jsx(Mr, {
                  anchor: "bottom end",
                  className: "z-20 w-36 rounded-md bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 ring-1 ring-black/5 dark:ring-slate-700",
                  children: ({ close: x }) => m.jsxs("div", {
                    className: "py-1",
                    role: "menu",
                    children: [
                      m.jsx("button", {
                        role: "menuitem",
                        onClick: (S) => {
                          S.stopPropagation(), x(), o(a);
                        },
                        className: "w-full text-left px-3 py-1.5 text-xs text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                        children: "Edit"
                      }),
                      m.jsx("button", {
                        role: "menuitem",
                        onClick: (S) => {
                          S.stopPropagation(), x(), i(a);
                        },
                        className: "w-full text-left px-3 py-1.5 text-xs text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950",
                        children: "Delete"
                      })
                    ]
                  })
                })
              ]
            })
          ]
        })
      })
    }, t.id);
  }), Hs = d.memo(Gs);
  function Bs({ row: e, table: t, rowSelection: n, onEditFolder: r, onDeleteFolder: o }) {
    var _a;
    const i = e.original._folder ? e.original._folder.id : "ungrouped", { setNodeRef: s, isOver: l } = Ds({
      id: `drop_${i}`,
      data: {
        folderId: i,
        folderName: ((_a = e.original._folder) == null ? void 0 : _a.name) ?? "Ungrouped"
      }
    });
    return m.jsx(Hs, {
      ref: s,
      row: e,
      table: t,
      rowSelection: n,
      onEditFolder: r,
      onDeleteFolder: o,
      isOver: l
    });
  }
  const Us = d.memo(Bs), qs = {
    activationConstraint: {
      distance: 10
    }
  };
  function Xs({ children: e, onDragEnd: t }) {
    const [n, r] = d.useState(null), o = Ri(yn(tn, qs), yn(Qt)), i = d.useCallback((l) => {
      r(l.active.data.current);
    }, []), s = d.useCallback((l) => {
      var _a;
      r(null);
      const { active: a, over: c } = l;
      if (!c || !t)
        return;
      const g = a.id, p = (_a = c.data.current) == null ? void 0 : _a.folderId;
      p && t({
        sourceId: g,
        folderId: p
      });
    }, [
      t
    ]);
    return m.jsxs(ws, {
      sensors: o,
      onDragStart: i,
      onDragEnd: s,
      accessibility: {
        announcements: {
          onDragStart: ({ active: l }) => "Picked up source. Use arrow keys to move.",
          onDragOver: ({ over: l }) => {
            var _a, _b;
            return l ? `Dragging over ${((_b = (_a = l.data) == null ? void 0 : _a.current) == null ? void 0 : _b.folderName) ?? "a folder"}.` : "";
          },
          onDragEnd: ({ active: l, over: a }) => {
            var _a, _b;
            return a ? `Moved source to ${((_b = (_a = a.data) == null ? void 0 : _a.current) == null ? void 0 : _b.folderName) ?? "folder"}.` : "Drop cancelled.";
          },
          onDragCancel: () => "Drag cancelled."
        },
        screenReaderInstructions: {
          draggable: "To drag a source, press Space or Enter, then use arrow keys to move between folders. Press Space or Enter again to drop, or Escape to cancel."
        }
      },
      children: [
        e,
        m.jsx(js, {
          dropAnimation: null,
          children: n ? m.jsx("div", {
            className: "px-3 py-2 text-xs font-medium bg-white dark:bg-slate-700 dark:text-slate-100 border border-neutral-300 dark:border-slate-500 rounded shadow-lg dark:shadow-slate-900/50 max-w-[200px] truncate",
            children: n.title || "Source"
          }) : null
        })
      ]
    });
  }
  const ot = ({ onClick: e, disabled: t, icon: n, "aria-label": r }) => m.jsx("button", {
    className: "inline-flex items-center justify-center w-6 h-6 text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed",
    onClick: e,
    disabled: t,
    "aria-label": r,
    children: m.jsx(n, {
      className: "w-3.5 h-3.5"
    })
  });
  function Ks({ table: e }) {
    return m.jsxs("div", {
      className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between px-1",
      children: [
        m.jsxs("div", {
          className: "flex items-center gap-3",
          children: [
            m.jsxs("div", {
              className: "flex items-center gap-1",
              children: [
                m.jsx(ot, {
                  icon: Bo,
                  onClick: () => e.firstPage(),
                  disabled: !e.getCanPreviousPage(),
                  "aria-label": "First page"
                }),
                m.jsx(ot, {
                  icon: Jo,
                  onClick: () => e.previousPage(),
                  disabled: !e.getCanPreviousPage(),
                  "aria-label": "Previous page"
                }),
                m.jsxs("span", {
                  className: "mx-2 text-xs text-neutral-600 dark:text-slate-400 font-medium",
                  children: [
                    "Page",
                    " ",
                    m.jsx("span", {
                      className: "text-neutral-900 dark:text-slate-100",
                      children: e.getState().pagination.pageIndex + 1
                    }),
                    " ",
                    "of ",
                    m.jsx("span", {
                      className: "text-neutral-900 dark:text-slate-100",
                      children: e.getPageCount()
                    })
                  ]
                }),
                m.jsx(ot, {
                  icon: ti,
                  onClick: () => e.nextPage(),
                  disabled: !e.getCanNextPage(),
                  "aria-label": "Next page"
                }),
                m.jsx(ot, {
                  icon: Xo,
                  onClick: () => e.lastPage(),
                  disabled: !e.getCanNextPage(),
                  "aria-label": "Last page"
                })
              ]
            }),
            m.jsx("div", {
              className: "h-4 w-px bg-neutral-200 dark:bg-slate-700 hidden sm:block"
            }),
            m.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                m.jsx("span", {
                  className: "text-xs text-neutral-500 dark:text-slate-400 hidden sm:inline",
                  children: "Go to"
                }),
                m.jsx("input", {
                  type: "number",
                  min: 1,
                  max: e.getPageCount(),
                  defaultValue: e.getState().pagination.pageIndex + 1,
                  onChange: (t) => {
                    const n = t.target.value ? Number(t.target.value) - 1 : 0;
                    e.setPageIndex(n);
                  },
                  className: "w-12 px-1.5 py-1 text-xs text-neutral-900 dark:text-slate-100 border border-neutral-300 dark:border-slate-600 rounded focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 dark:bg-slate-900",
                  "aria-label": "Go to page"
                }, e.getState().pagination.pageIndex)
              ]
            }),
            m.jsx("select", {
              className: "px-2 py-1 w-[4.5rem] text-xs text-neutral-900 dark:text-slate-100 border border-neutral-300 dark:border-slate-600 rounded focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 bg-white dark:bg-slate-900 cursor-pointer",
              value: e.getState().pagination.pageSize,
              onChange: (t) => e.setPageSize(Number(t.target.value)),
              "aria-label": "Items per page",
              children: [
                10,
                20,
                30,
                50,
                100
              ].map((t) => m.jsx("option", {
                value: t,
                children: t
              }, t))
            })
          ]
        }),
        m.jsxs("div", {
          className: "text-xs text-neutral-500 dark:text-slate-400 font-medium",
          children: [
            "Showing",
            " ",
            m.jsx("span", {
              className: "text-neutral-900 dark:text-slate-100",
              children: e.getRowModel().rows.length
            }),
            " ",
            "of ",
            m.jsx("span", {
              className: "text-neutral-900 dark:text-slate-100",
              children: e.getRowCount()
            }),
            " ",
            "results"
          ]
        })
      ]
    });
  }
  const Ys = (e) => {
    const t = e.column.getIsSorted();
    return t === "asc" ? "ascending" : t === "desc" ? "descending" : e.column.getCanSort() ? "none" : void 0;
  };
  function Ws({ data: e, columns: t, enableRowSelection: n = false, onRowSelectionChange: r, rowSelection: o = {}, initialSorting: i = [], getRowId: s = (w) => w.id, onRowClick: l, enableGrouping: a = false, expanded: c, onExpandedChange: g, renderGroupRow: p, getSubRows: f, onDragEnd: u, onEditFolder: v, onDeleteFolder: h }) {
    const [w, x] = d.useState({
      pageIndex: 0,
      pageSize: 50
    }), S = zo({
      columns: t,
      data: e,
      getCoreRowModel: ko(),
      getSortedRowModel: Vo(),
      getFilteredRowModel: Oo(),
      getPaginationRowModel: Ao(),
      ...a && {
        getExpandedRowModel: Io()
      },
      autoResetPageIndex: true,
      onPaginationChange: x,
      enableRowSelection: a ? (b) => {
        var _a;
        return !((_a = b.original) == null ? void 0 : _a._isGroupRow);
      } : n,
      onRowSelectionChange: r,
      getRowId: s,
      ...a && {
        getSubRows: f
      },
      ...a && {
        filterFromLeafRows: true
      },
      ...a && {
        onExpandedChange: g
      },
      state: {
        pagination: w,
        ...n && {
          rowSelection: o
        },
        ...a && {
          expanded: c
        }
      },
      initialState: {
        sorting: i
      }
    }), C = () => {
      const b = S.getRowModel().rows;
      return b.length === 0 ? m.jsx("tr", {
        children: m.jsx("td", {
          colSpan: t.length,
          className: "px-3 py-8 text-center text-xs text-neutral-500 dark:text-slate-400",
          children: "No results found"
        })
      }) : b.map((R) => {
        var _a;
        return a && ((_a = R.original) == null ? void 0 : _a._isGroupRow) ? u ? m.jsx(Us, {
          row: R,
          table: S,
          rowSelection: o,
          onEditFolder: v,
          onDeleteFolder: h
        }, R.id) : p ? p({
          row: R,
          table: S
        }) : null : a && u ? m.jsx(zs, {
          row: R,
          onRowClick: l,
          enableRowSelection: n,
          isSelected: R.getIsSelected()
        }, R.id) : m.jsx("tr", {
          className: _e("group", l || n ? "cursor-pointer hover:bg-neutral-50 dark:hover:bg-slate-700" : "hover:bg-neutral-50 dark:hover:bg-slate-700", R.getIsSelected() ? "bg-neutral-50 dark:bg-slate-700" : "even:bg-neutral-50/30 dark:even:bg-slate-800/50"),
          onClick: () => {
            l ? l(R.original) : n && R.toggleSelected();
          },
          children: R.getVisibleCells().map((D) => m.jsx("td", {
            className: "px-3 py-2.5 text-xs text-neutral-600 dark:text-slate-400 group-hover:text-neutral-900 dark:group-hover:text-slate-100 align-top",
            children: it(D.column.columnDef.cell, D.getContext())
          }, D.id))
        }, R.id);
      });
    }, M = m.jsxs("table", {
      className: "min-w-full divide-y divide-neutral-200 dark:divide-neutral-700",
      children: [
        m.jsx("caption", {
          className: "sr-only",
          children: "Source files table"
        }),
        m.jsx("thead", {
          className: "bg-neutral-50 dark:bg-slate-900",
          children: S.getHeaderGroups().map((b) => m.jsx("tr", {
            children: b.headers.map((R) => m.jsx("th", {
              colSpan: R.colSpan,
              scope: "col",
              "aria-sort": Ys(R),
              style: {
                width: R.getSize() !== 150 ? R.getSize() : void 0
              },
              className: "px-3 py-3 text-xs font-semibold text-left text-neutral-700 dark:text-slate-300 uppercase tracking-wider select-none relative group",
              children: m.jsxs("div", {
                className: "flex flex-col gap-2",
                children: [
                  R.column.getCanSort() ? m.jsxs("div", {
                    role: "button",
                    tabIndex: 0,
                    className: "flex items-center gap-1 cursor-pointer hover:text-neutral-900 dark:hover:text-slate-100",
                    onClick: R.column.getToggleSortingHandler(),
                    onKeyDown: (D) => {
                      (D.key === "Enter" || D.key === " ") && (D.preventDefault(), R.column.getToggleSortingHandler()(D));
                    },
                    children: [
                      m.jsx("span", {
                        children: it(R.column.columnDef.header, R.getContext())
                      }),
                      m.jsx("span", {
                        className: "flex-shrink-0 w-3.5 h-3.5 text-neutral-400 dark:text-slate-500 group-hover:text-neutral-600 dark:group-hover:text-slate-300",
                        children: {
                          asc: m.jsx(oi, {}),
                          desc: m.jsx(Rn, {})
                        }[R.column.getIsSorted()] ?? m.jsx(Rn, {
                          className: "opacity-0 group-hover:opacity-50"
                        })
                      })
                    ]
                  }) : m.jsx("div", {
                    className: "flex items-center gap-1",
                    children: m.jsx("span", {
                      children: it(R.column.columnDef.header, R.getContext())
                    })
                  }),
                  R.column.getCanFilter() ? m.jsx("div", {
                    className: "pt-1",
                    children: m.jsx(ai, {
                      column: R.column,
                      table: S
                    })
                  }) : null
                ]
              })
            }, R.id))
          }, b.id))
        }),
        m.jsx("tbody", {
          className: "bg-white dark:bg-slate-800 divide-y divide-neutral-200 dark:divide-neutral-700",
          children: C()
        })
      ]
    });
    return m.jsxs("div", {
      className: "space-y-4",
      children: [
        m.jsxs("div", {
          className: "overflow-hidden border border-neutral-200 dark:border-slate-700 rounded-lg shadow-sm dark:shadow-slate-900/30 bg-white dark:bg-slate-800",
          children: [
            m.jsx("div", {
              className: "overflow-x-auto",
              children: a && u ? m.jsx(Xs, {
                onDragEnd: u,
                children: M
              }) : M
            }),
            m.jsxs("div", {
              className: "sr-only",
              "aria-live": "polite",
              children: [
                S.getRowModel().rows.length,
                " rows displayed"
              ]
            })
          ]
        }),
        m.jsx(Ks, {
          table: S
        })
      ]
    });
  }
  let An;
  ol = d.memo(Ws);
  An = () => Oe[Math.floor(Math.random() * Oe.length)];
  il = function({ notebookId: e, compact: t = false, mode: n }) {
    const r = t || n === "compact", [o, i] = Cr(), [s, l] = d.useState(false), [a, c] = d.useState(""), [g, p] = d.useState(false), [f, u] = d.useState({
      top: 0,
      left: 0
    }), [v, h] = d.useState(() => An()), w = d.useRef(null), x = d.useRef(null), S = d.useRef(null), C = i.getNotebookTags(e), M = i.getAllTags(), b = new Set(C.map((_) => _.id)), R = M.filter((_) => !b.has(_.id) && _.name.toLowerCase().includes(a.toLowerCase())), D = a.trim() && !M.some((_) => _.name.toLowerCase() === a.trim().toLowerCase());
    d.useEffect(() => {
      const _ = (se) => {
        x.current && !x.current.contains(se.target) && (l(false), c(""));
      };
      return document.addEventListener("mousedown", _), () => document.removeEventListener("mousedown", _);
    }, []), d.useEffect(() => {
      if (s && w.current && w.current.focus(), s && S.current) {
        const _ = S.current.getBoundingClientRect();
        u({
          top: _.bottom + 4,
          left: _.left
        });
      }
    }, [
      s
    ]);
    const k = async (_) => {
      await i.addTagToNotebook(e, _.id), c("");
    }, P = async (_) => {
      await i.removeTagFromNotebook(e, _.id);
    }, N = async () => {
      if (!(!a.trim() || g)) {
        p(true);
        try {
          await i.quickAddTag(e, a.trim(), v) && (c(""), h(An()));
        } finally {
          p(false);
        }
      }
    }, $ = (_) => {
      _.stopPropagation();
      const Xe = (Oe.indexOf(v) + 1) % Oe.length;
      h(Oe[Xe]);
    }, q = (_) => {
      _.key === "Enter" ? (_.preventDefault(), D ? N() : R.length > 0 && k(R[0])) : _.key === "Escape" && (l(false), c(""));
    }, Y = s && m.jsxs("div", {
      ref: x,
      className: "fixed z-[9999] w-48 bg-white dark:bg-slate-800 rounded-md shadow-lg dark:shadow-slate-900/30 border border-gray-200 dark:border-slate-700 py-1",
      style: {
        top: f.top,
        left: f.left
      },
      children: [
        m.jsx("div", {
          className: "px-2 pb-1",
          children: m.jsx("input", {
            ref: w,
            type: "text",
            value: a,
            onChange: (_) => c(_.target.value),
            onKeyDown: q,
            placeholder: "Search or create...",
            className: "w-full px-2 py-1 text-xs border border-gray-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-900 dark:text-slate-100"
          })
        }),
        m.jsxs("div", {
          className: "max-h-32 overflow-y-auto",
          children: [
            R.map((_) => m.jsx("button", {
              onClick: () => k(_),
              className: "w-full px-2 py-1 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2",
              children: m.jsx(ye, {
                tag: _,
                size: "xs"
              })
            }, _.id)),
            D && m.jsxs("button", {
              onClick: N,
              disabled: g,
              className: "w-full px-2 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-1.5 text-xs text-gray-600 dark:text-slate-400 border-t border-gray-100 dark:border-slate-700",
              children: [
                m.jsx(Je, {
                  className: "w-3 h-3 flex-shrink-0"
                }),
                m.jsx("span", {
                  className: "flex-shrink-0",
                  children: "Create"
                }),
                m.jsx("span", {
                  onClick: $,
                  className: "cursor-pointer",
                  title: "Click to change color",
                  children: m.jsx(ye, {
                    tag: {
                      name: a.trim(),
                      color: v
                    },
                    size: "xs"
                  })
                })
              ]
            }),
            R.length === 0 && !D && m.jsx("div", {
              className: "px-2 py-2 text-xs text-gray-500 dark:text-slate-400 text-center",
              children: a ? "No matching tags" : "No available tags"
            })
          ]
        })
      ]
    });
    if (r) {
      const _ = C.length > 0;
      return m.jsxs(m.Fragment, {
        children: [
          m.jsxs("div", {
            className: "flex flex-wrap gap-1 items-center",
            children: [
              C.map((se) => m.jsx(ye, {
                tag: se,
                size: "xs",
                showRemove: true,
                onRemove: P
              }, se.id)),
              m.jsxs("button", {
                ref: S,
                onClick: () => l(!s),
                className: _e("inline-flex items-center gap-0.5 text-[10px] font-medium rounded-full border border-dashed", s ? "px-1.5 py-0.5 text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-700 border-gray-400 dark:border-slate-500" : _ ? "px-1.5 py-0.5 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 border-gray-300 dark:border-gray-600" : "px-2 py-0.5 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 border-gray-400 dark:border-slate-500"),
                children: [
                  m.jsx(Je, {
                    className: "w-3 h-3"
                  }),
                  !_ && m.jsx("span", {
                    children: "Add tag"
                  })
                ]
              })
            ]
          }),
          Ee.createPortal(Y, document.body)
        ]
      });
    }
    return m.jsxs("div", {
      ref: x,
      className: "relative",
      children: [
        m.jsxs("div", {
          className: "flex flex-wrap gap-1.5 items-center min-h-[28px]",
          children: [
            C.map((_) => m.jsx(ye, {
              tag: _,
              size: "sm",
              showRemove: true,
              onRemove: P
            }, _.id)),
            m.jsxs("button", {
              onClick: () => l(!s),
              className: _e("inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-full border border-dashed", s ? "text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-700 border-gray-400 dark:border-slate-500" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 border-gray-300 dark:border-gray-600"),
              children: [
                m.jsx(Je, {
                  className: "w-3 h-3"
                }),
                m.jsx("span", {
                  children: "Add tag"
                })
              ]
            })
          ]
        }),
        s && m.jsxs("div", {
          className: "absolute z-50 mt-2 w-56 bg-white dark:bg-slate-800 rounded-md shadow-lg dark:shadow-slate-900/30 border border-gray-200 dark:border-slate-700 py-2",
          children: [
            m.jsx("div", {
              className: "px-3 pb-2",
              children: m.jsx("input", {
                ref: w,
                type: "text",
                value: a,
                onChange: (_) => c(_.target.value),
                onKeyDown: q,
                placeholder: "Search or create tag...",
                className: "w-full px-2.5 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-900 dark:text-slate-100"
              })
            }),
            m.jsxs("div", {
              className: "max-h-40 overflow-y-auto",
              children: [
                R.map((_) => m.jsx("button", {
                  onClick: () => k(_),
                  className: "w-full px-3 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2",
                  children: m.jsx(ye, {
                    tag: _,
                    size: "sm"
                  })
                }, _.id)),
                D && m.jsxs("button", {
                  onClick: N,
                  disabled: g,
                  className: "w-full px-3 py-2 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-1.5 text-xs text-gray-700 dark:text-slate-300 border-t border-gray-100 dark:border-slate-700 mt-1",
                  children: [
                    m.jsx(Je, {
                      className: "w-3.5 h-3.5 flex-shrink-0"
                    }),
                    m.jsx("span", {
                      className: "flex-shrink-0",
                      children: "Create"
                    }),
                    m.jsx("span", {
                      onClick: $,
                      className: "cursor-pointer",
                      title: "Click to change color",
                      children: m.jsx(ye, {
                        tag: {
                          name: a.trim(),
                          color: v
                        },
                        size: "sm"
                      })
                    })
                  ]
                }),
                R.length === 0 && !D && a && m.jsx("div", {
                  className: "px-3 py-3 text-xs text-gray-500 dark:text-slate-400 text-center",
                  children: "No matching tags found"
                }),
                M.length === 0 && !a && m.jsx("div", {
                  className: "px-3 py-3 text-xs text-gray-500 dark:text-slate-400 text-center",
                  children: "Type to create your first tag"
                })
              ]
            })
          ]
        })
      ]
    });
  };
  sl = function({ renameAction: e, refreshAction: t, setIsLoading: n, setSelectedRows: r, itemLabel: o = "item" }) {
    const [i, s] = d.useState(null), l = d.useCallback((p) => {
      s([
        p
      ]);
    }, []), a = d.useCallback((p) => {
      if (p.length === 0) {
        Qe.error(`No ${o}s selected`);
        return;
      }
      s(p);
    }, [
      o
    ]), c = d.useCallback(async (p) => {
      n && n(true);
      try {
        const u = [];
        for (let w = 0; w < p.length; w += 3) {
          const x = p.slice(w, w + 3), S = await Promise.allSettled(x.map(({ id: C, newTitle: M }) => e(C, M)));
          u.push(...S);
        }
        t && await t();
        const v = new Set(p.filter((w, x) => u[x].status === "rejected").map((w) => w.id));
        r && (v.size > 0 ? r((w) => {
          const x = {};
          for (const S of Object.keys(w))
            v.has(S) && (x[S] = true);
          return x;
        }) : r({}));
        const h = u.filter((w) => w.status === "rejected").length;
        h > 0 ? Qe.warning(`${p.length - h} renamed, ${h} failed`) : Qe.success(`${p.length} ${o}${p.length > 1 ? "s" : ""} renamed`);
      } catch (f) {
        throw console.error(`Failed to rename ${o}s:`, f), Qe.error(`Failed to rename ${o}s`), f;
      } finally {
        n && n(false);
      }
    }, [
      e,
      t,
      n,
      r,
      o
    ]), g = d.useCallback(() => s(null), []);
    return {
      pendingRenameItems: i,
      handleRename: l,
      handleBulkRename: a,
      confirmRename: c,
      closeRenameDialog: g
    };
  };
  let Zs;
  Zs = ({ className: e }) => m.jsx("svg", {
    className: e,
    fill: "currentColor",
    viewBox: "0 0 20 20",
    children: m.jsx("path", {
      fillRule: "evenodd",
      d: "M4.5 2A1.5 1.5 0 003 3.5v13A1.5 1.5 0 004.5 18h11a1.5 1.5 0 001.5-1.5V7.621a1.5 1.5 0 00-.44-1.06l-4.12-4.122A1.5 1.5 0 0011.379 2H4.5zm2.25 4a.75.75 0 000 1.5h4.5a.75.75 0 000-1.5h-4.5zm0 3a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-6.5zm0 3a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-6.5z",
      clipRule: "evenodd"
    })
  });
  Js = {
    [F.UNSPECIFIED]: Ot,
    [F.URL]: wn,
    [F.TEXT]: Ot,
    [F.WEB_PAGE]: wn,
    [F.YOUTUBE_VIDEO]: kr,
    [F.GOOGLE_DRIVE]: et,
    [F.GOOGLE_DOC]: et,
    [F.GOOGLE_SLIDES]: Rr,
    [F.GOOGLE_SHEETS]: br,
    [F.PDF]: et,
    [F.PDF_FROM_DRIVE]: et,
    [F.TEXT_NOTE]: Zs,
    [F.VIDEO_FILE]: yr,
    [F.IMAGE]: Ir,
    [F.MIND_MAP_NOTE]: Er
  };
  Vn = {
    [F.UNSPECIFIED]: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300",
    [F.URL]: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    [F.TEXT]: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
    [F.WEB_PAGE]: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    [F.YOUTUBE_VIDEO]: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300",
    [F.GOOGLE_DRIVE]: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    [F.GOOGLE_DOC]: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
    [F.GOOGLE_SLIDES]: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
    [F.GOOGLE_SHEETS]: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300",
    [F.PDF]: "bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300",
    [F.PDF_FROM_DRIVE]: "bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300",
    [F.TEXT_NOTE]: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
    [F.VIDEO_FILE]: "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300",
    [F.IMAGE]: "bg-pink-100 text-pink-700 dark:bg-pink-950 dark:text-pink-300",
    [F.MIND_MAP_NOTE]: "bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"
  };
  Qs = {
    [F.UNSPECIFIED]: "Unknown",
    [F.URL]: "Web",
    [F.TEXT]: "Text",
    [F.WEB_PAGE]: "Web",
    [F.YOUTUBE_VIDEO]: "YouTube",
    [F.GOOGLE_DRIVE]: "Drive",
    [F.GOOGLE_DOC]: "Docs",
    [F.GOOGLE_SLIDES]: "Slides",
    [F.GOOGLE_SHEETS]: "Sheets",
    [F.PDF]: "PDF",
    [F.PDF_FROM_DRIVE]: "PDF",
    [F.TEXT_NOTE]: "Note",
    [F.VIDEO_FILE]: "Video",
    [F.IMAGE]: "Image",
    [F.MIND_MAP_NOTE]: "Mind Map"
  };
  ll = function({ sourceType: e }) {
    const t = Js[e] || Ot, n = Vn[e] || Vn[F.UNSPECIFIED], r = Qs[e] || "Unknown", o = Or[e] || "Unknown";
    return m.jsxs("span", {
      className: `inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-medium ${n}`,
      title: o,
      children: [
        m.jsx(t, {
          className: "h-2.5 w-2.5"
        }),
        m.jsx("span", {
          children: r
        })
      ]
    });
  };
  al = function({ isOpen: e, onClose: t, onConfirm: n, sources: r }) {
    const [o, i] = d.useState(false);
    if (d.useEffect(() => {
      e && i(false);
    }, [
      e
    ]), !r || r.length === 0)
      return null;
    const s = r.length, l = s === 1 ? "Remove this source?" : `Remove ${s} sources?`, a = s === 1 ? `"${r[0].title || "Untitled"}" will be permanently removed.` : `${s} sources will be permanently removed.`, c = async () => {
      i(true);
      try {
        await n(r), t();
      } catch {
        i(false);
      }
    };
    return m.jsxs(Pr, {
      open: e,
      onClose: o ? () => {
      } : t,
      className: "relative z-50",
      children: [
        m.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        m.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: m.jsxs($r, {
            className: "w-full max-w-sm space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              m.jsx(Nr, {
                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                children: l
              }),
              m.jsx("p", {
                className: "text-xs text-gray-500 dark:text-slate-400",
                children: a
              }),
              m.jsxs("div", {
                className: "flex justify-end gap-2 pt-2",
                children: [
                  m.jsx("button", {
                    type: "button",
                    onClick: t,
                    disabled: o,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  m.jsx("button", {
                    type: "button",
                    onClick: c,
                    disabled: o,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50",
                    children: o ? "Removing..." : "Remove"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  Bo as C,
  ol as D,
  Hr as F,
  ll as S,
  il as T,
  __tla,
  Jo as a,
  ti as b,
  Xo as c,
  Qs as d,
  Js as e,
  Vn as f,
  al as g,
  sl as u
};
