import { r as l, j as e, a3 as y, u as p, G as v, a5 as w, S as h, l as b, J as m, a6 as L, C as S, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { a5 as A, a6 as j, a7 as I, a8 as T, a9 as E, r as C, b as O, d as F, aa as R, ab as U, ac as M, k as G, ad as B, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { I as _, O as V } from "./chunk-68adfa56.js";
import { B as $, __tla as __tla_2 } from "./chunk-5518d26c.js";
import { U as P, __tla as __tla_3 } from "./chunk-1784b260.js";
import { A as D, __tla as __tla_4 } from "./chunk-5a4465c9.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
import { __tla as __tla_5 } from "./chunk-de7ca15a.js";
import { __tla as __tla_6 } from "./chunk-57988b21.js";
import { __tla as __tla_7 } from "./chunk-234b1720.js";
let xe;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })()
]).then(async () => {
  function Z({ title: r, titleId: a, ...t }, s) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: s,
      "aria-labelledby": a
    }, t), r ? l.createElement("title", {
      id: a
    }, r) : null, l.createElement("path", {
      d: "M3.505 2.365A41.369 41.369 0 0 1 9 2c1.863 0 3.697.124 5.495.365 1.247.167 2.18 1.108 2.435 2.268a4.45 4.45 0 0 0-.577-.069 43.141 43.141 0 0 0-4.706 0C9.229 4.696 7.5 6.727 7.5 8.998v2.24c0 1.413.67 2.735 1.76 3.562l-2.98 2.98A.75.75 0 0 1 5 17.25v-3.443c-.501-.048-1-.106-1.495-.172C2.033 13.438 1 12.162 1 10.72V5.28c0-1.441 1.033-2.717 2.505-2.914Z"
    }), l.createElement("path", {
      d: "M14 6c-.762 0-1.52.02-2.271.062C10.157 6.148 9 7.472 9 8.998v2.24c0 1.519 1.147 2.839 2.71 2.935.214.013.428.024.642.034.2.009.385.09.518.224l2.35 2.35a.75.75 0 0 0 1.28-.531v-2.07c1.453-.195 2.5-1.463 2.5-2.915V8.998c0-1.526-1.157-2.85-2.729-2.936A41.645 41.645 0 0 0 14 6Z"
    }));
  }
  const H = l.forwardRef(Z), f = H;
  function K({ title: r, titleId: a, ...t }, s) {
    return l.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: s,
      "aria-labelledby": a
    }, t), r ? l.createElement("title", {
      id: a
    }, r) : null, l.createElement("path", {
      fillRule: "evenodd",
      d: "M3.5 2A1.5 1.5 0 0 0 2 3.5V15a3 3 0 1 0 6 0V3.5A1.5 1.5 0 0 0 6.5 2h-3Zm11.753 6.99L9.5 14.743V6.257l1.51-1.51a1.5 1.5 0 0 1 2.122 0l2.121 2.121a1.5 1.5 0 0 1 0 2.122ZM8.364 18H16.5a1.5 1.5 0 0 0 1.5-1.5v-3a1.5 1.5 0 0 0-1.5-1.5h-2.136l-6 6ZM5 16a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z",
      clipRule: "evenodd"
    }));
  }
  const q = l.forwardRef(K), z = q;
  function k({ favorites: r, allFavorites: a, currentLanguage: t, onLanguageChange: s, isChanging: c = false, suggestions: d, favoriteKey: n }) {
    if (r.length === 0)
      return e.jsxs("div", {
        className: "mb-3 pb-3 border-b border-gray-200 dark:border-slate-700",
        children: [
          e.jsx("p", {
            className: "text-xs text-gray-400 dark:text-slate-500",
            children: "Click a language below to add it to favorites"
          }),
          d && e.jsx(A, {
            suggestions: d,
            favoriteKey: n
          })
        ]
      });
    const g = a.length > 5;
    return e.jsxs("div", {
      className: "mb-3 pb-3 border-b border-gray-200 dark:border-slate-700",
      children: [
        e.jsxs("div", {
          className: "flex flex-wrap gap-1.5",
          children: [
            r.map((o) => {
              var _a;
              const i = t === o.code, u = o.code === null;
              return e.jsx("button", {
                type: "button",
                onClick: () => s(o.code),
                disabled: i || c,
                className: `
                px-2.5 py-1.5 text-xs rounded border
                ${i ? "bg-blue-600 border-blue-600 text-white font-medium cursor-default" : c ? "bg-gray-100 border-gray-300 text-gray-400 cursor-not-allowed dark:bg-slate-700 dark:border-gray-600 dark:text-slate-500" : "bg-white border-gray-300 text-gray-700 hover:border-gray-400 hover:bg-gray-50 dark:bg-slate-800 dark:border-gray-600 dark:text-slate-300 dark:hover:border-gray-500 dark:hover:bg-slate-700"}
              `,
                title: o.name,
                children: e.jsxs("div", {
                  className: "flex items-center gap-1",
                  children: [
                    e.jsx("span", {
                      children: "\u2B50"
                    }),
                    e.jsx("span", {
                      className: "font-medium",
                      children: u ? "DEFAULT" : ((_a = o.code) == null ? void 0 : _a.toUpperCase()) || "N/A"
                    }),
                    e.jsx("span", {
                      className: "text-xs opacity-75 truncate max-w-[80px]",
                      children: y(o)
                    })
                  ]
                })
              }, o.code || "default");
            }),
            g && e.jsxs("button", {
              type: "button",
              disabled: true,
              className: "px-2.5 py-1.5 text-xs rounded border border-dashed border-gray-300 text-gray-400 cursor-default dark:border-gray-600 dark:text-slate-500",
              title: `${a.length - 5} more favorites`,
              children: [
                "+",
                a.length - 5
              ]
            })
          ]
        }),
        e.jsx("p", {
          className: "mt-2 text-xs text-gray-500 dark:text-slate-400",
          children: c ? "Changing language..." : "Click to switch \xB7 add more below"
        })
      ]
    });
  }
  function N({ title: r, items: a }) {
    return e.jsx("div", {
      className: "bg-blue-50 border border-blue-200 rounded p-2.5 dark:bg-blue-950 dark:border-blue-800",
      children: e.jsxs("div", {
        className: "flex items-start gap-2",
        children: [
          e.jsx("svg", {
            className: "w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5",
            fill: "currentColor",
            viewBox: "0 0 20 20",
            children: e.jsx("path", {
              fillRule: "evenodd",
              d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
              clipRule: "evenodd"
            })
          }),
          e.jsxs("div", {
            className: "text-xs text-blue-900 dark:text-blue-300",
            children: [
              e.jsx("p", {
                className: "font-medium mb-1",
                children: r
              }),
              e.jsx("ul", {
                className: "space-y-0.5 list-disc list-inside",
                children: a.map((t, s) => e.jsx("li", {
                  children: t
                }, s))
              })
            ]
          })
        ]
      })
    });
  }
  function J() {
    const [r, a] = p(), { interfaceLanguage: t, interfaceFavorites: s } = r.languageSettings;
    l.useEffect(() => {
      a.loadLanguageSettings(), a.loadInterfaceFavorites();
      const n = (g, o) => {
        o === "local" && (g[h.INTERFACE_FAVORITES] && a.loadInterfaceFavorites(), g[_] && a.loadLanguageSettings());
      };
      return chrome.storage.onChanged.addListener(n), () => chrome.storage.onChanged.removeListener(n);
    }, []);
    const c = (n) => {
      a.setInterfaceLanguage(n);
      const g = b.interfaceLanguages.find((o) => o.code === n);
      m.success(`Interface: ${(g == null ? void 0 : g.name) || n}`);
    }, d = s.slice(0, 5);
    return e.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: e.jsxs("div", {
        className: "p-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-1.5 mb-3",
            children: [
              e.jsx(v, {
                className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
              }),
              e.jsx("h2", {
                className: "font-medium text-gray-900 dark:text-slate-100",
                children: "Language Settings"
              })
            ]
          }),
          e.jsx(k, {
            favorites: d,
            allFavorites: s,
            currentLanguage: t,
            onLanguageChange: c,
            suggestions: w,
            favoriteKey: h.INTERFACE_FAVORITES
          }),
          e.jsxs("div", {
            className: "space-y-3",
            children: [
              e.jsx(j, {
                languages: b.interfaceLanguages,
                value: t,
                label: "Interface Language"
              }),
              e.jsx(N, {
                title: "How it works",
                items: [
                  "UI language changes NotebookLM interface",
                  "Star (\u2B50) up to 5 for quick switcher access",
                  "Favorites appear in language switcher widget"
                ]
              })
            ]
          })
        ]
      })
    });
  }
  function Q() {
    const [r, a] = p(), { outputFavorites: t, outputLanguage: s } = r.languageSettings, [c, d] = l.useState(false), n = a.isNotebookLMAuthenticated();
    l.useEffect(() => {
      a.loadOutputLanguage(), a.loadOutputFavorites();
      const i = (u, x) => {
        x === "local" && (u[h.OUTPUT_FAVORITES] && a.loadOutputFavorites(), u[V] && a.loadOutputLanguage());
      };
      return chrome.storage.onChanged.addListener(i), () => chrome.storage.onChanged.removeListener(i);
    }, []);
    const g = async (i) => {
      if (!n) {
        m.error("Connect to NotebookLM first");
        return;
      }
      if (!c) {
        d(true);
        try {
          await a.changeOutputLanguage(i), await a.loadOutputLanguage();
          const u = b.outputLanguages.find((x) => x.code === i);
          m.success(`Output: ${(u == null ? void 0 : u.name) || i || "Default"}`), chrome.tabs.query({
            active: true,
            currentWindow: true
          }, (x) => {
            var _a;
            ((_a = x[0]) == null ? void 0 : _a.id) && chrome.tabs.reload(x[0].id);
          });
        } catch (u) {
          console.error("Failed to change output language:", u), m.error("Failed to change output language");
        } finally {
          d(false);
        }
      }
    }, o = t.slice(0, 5);
    return n ? e.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: e.jsxs("div", {
        className: "p-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-1.5 mb-3",
            children: [
              e.jsx(f, {
                className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
              }),
              e.jsx("h2", {
                className: "font-medium text-gray-900 dark:text-slate-100",
                children: "Output Language"
              })
            ]
          }),
          e.jsx(k, {
            favorites: o,
            allFavorites: t,
            currentLanguage: s,
            onLanguageChange: g,
            isChanging: c,
            suggestions: L,
            favoriteKey: h.OUTPUT_FAVORITES
          }),
          e.jsxs("div", {
            className: "space-y-3",
            children: [
              e.jsx(j, {
                languages: b.outputLanguages,
                value: s,
                label: "Output Language",
                favoriteKey: h.OUTPUT_FAVORITES
              }),
              e.jsx(N, {
                title: "How it works",
                items: [
                  "OUT language changes AI response language",
                  "Star (\u2B50) up to 5 for quick switcher widget",
                  'Select "Default" to use UI language'
                ]
              })
            ]
          })
        ]
      })
    }) : e.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: e.jsxs("div", {
        className: "p-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-1.5 mb-2",
            children: [
              e.jsx(f, {
                className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
              }),
              e.jsx("h2", {
                className: "font-medium text-gray-900 dark:text-slate-100",
                children: "Output Language"
              })
            ]
          }),
          e.jsx("p", {
            className: "text-xs text-gray-500 dark:text-slate-400",
            children: "Connect to NotebookLM to change output language"
          })
        ]
      })
    });
  }
  const W = [
    {
      value: "system",
      label: "System",
      description: "Follow your OS preference",
      Icon: I
    },
    {
      value: "light",
      label: "Light",
      description: "Always use light theme",
      Icon: T
    },
    {
      value: "dark",
      label: "Dark",
      description: "Always use dark theme",
      Icon: E
    }
  ];
  function X() {
    const [r, a] = p(), { themeMode: t } = r.themeSettings;
    return e.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: e.jsxs("div", {
        className: "p-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-1.5 mb-3",
            children: [
              e.jsx(z, {
                className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
              }),
              e.jsx("h2", {
                className: "font-medium text-gray-900 dark:text-slate-100",
                children: "Theme"
              })
            ]
          }),
          e.jsxs("div", {
            children: [
              e.jsx("label", {
                className: "text-xs text-gray-600 dark:text-slate-400 mb-2 block",
                children: "Choose your preferred appearance"
              }),
              e.jsx("div", {
                className: "grid grid-cols-3 gap-2",
                children: W.map(({ value: s, label: c, description: d, Icon: n }) => e.jsxs("button", {
                  onClick: () => a.setThemeMode(s),
                  className: `px-3 py-2 text-left rounded border ${t === s ? "bg-blue-600 text-white border-blue-600" : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-blue-500"}`,
                  children: [
                    e.jsx(n, {
                      className: `w-4 h-4 mb-1 ${t === s ? "text-white" : "text-gray-500 dark:text-slate-400"}`
                    }),
                    e.jsx("div", {
                      className: "text-xs font-medium",
                      children: c
                    }),
                    e.jsx("div", {
                      className: `text-xs ${t === s ? "text-blue-100" : "text-gray-500 dark:text-slate-400"}`,
                      children: d
                    })
                  ]
                }, s))
              })
            ]
          })
        ]
      })
    });
  }
  const Y = [
    {
      name: "General",
      icon: S,
      content: e.jsxs("div", {
        className: "space-y-3",
        children: [
          e.jsx(X, {}),
          e.jsx(U, {})
        ]
      })
    },
    {
      name: "Language",
      icon: v,
      content: e.jsxs("div", {
        className: "space-y-3",
        children: [
          e.jsx(M, {}),
          e.jsx(J, {}),
          e.jsx(Q, {})
        ]
      })
    },
    {
      name: "Account",
      icon: P,
      content: e.jsxs("div", {
        className: "space-y-3",
        children: [
          e.jsx(G, {}),
          e.jsx(B, {})
        ]
      })
    },
    {
      name: "Backup",
      icon: D,
      content: e.jsx($, {})
    }
  ], ee = {
    general: 0,
    language: 1,
    account: 2,
    backup: 3
  };
  xe = function() {
    const [r] = C(), a = r.get("tab"), t = ee[a] ?? 0;
    return e.jsxs(O, {
      children: [
        e.jsx(F, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "Settings"
          })
        }),
        e.jsx("div", {
          className: "p-3",
          children: e.jsx(R, {
            tabs: Y,
            defaultIndex: t
          })
        })
      ]
    });
  };
});
export {
  __tla,
  xe as default
};
