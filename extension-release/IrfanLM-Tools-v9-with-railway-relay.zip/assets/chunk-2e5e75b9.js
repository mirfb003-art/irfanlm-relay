import { j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { M as r, __tla as __tla_1 } from "./chunk-e0aab7c8.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
let s;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  s = function({ content: t }) {
    return (t == null ? void 0 : t.text) ? e.jsx(r, {
      text: t.text
    }) : e.jsx("p", {
      className: "text-xs text-gray-500 dark:text-slate-400",
      children: "No note content available."
    });
  };
});
export {
  __tla,
  s as default
};
