import { r, j as e, u as ne, c as Y, X as le, n as Rt, A as pe, a0 as Ce, b as ke, L as Ve, q as Je, a9 as re, aa as ve, e as J, ab as _t, ac as At, a8 as U, J as v, M as Se, ad as Ft, U as Z, ae as $t, h as Qe, P as He, m as K, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { F as Ze, f as Bt, g as de, h as oe, i as Ut, z as zt, Q as Vt, u as Qt, j as Ht, b as Zt, d as Gt, k as Yt, l as Kt, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { D as Wt, T as et, F as tt, C as st, a as at, b as rt, c as lt, S as Xt, d as qt, e as Jt, f as es, u as ts, g as ss, __tla as __tla_2 } from "./chunk-4c77bdf2.js";
import { R as ot, L as as, __tla as __tla_3 } from "./chunk-cbc671dd.js";
import { T as fe, __tla as __tla_4 } from "./chunk-95b0b380.js";
import { I as Ge, __tla as __tla_5 } from "./chunk-d4733473.js";
import { aE as ee, aF as rs, a3 as je } from "./chunk-68adfa56.js";
import { P as we, __tla as __tla_6 } from "./chunk-3daa5dc5.js";
import { f as nt } from "./chunk-10b7446f.js";
import { g as ls } from "./chunk-378f9272.js";
import { T as Ne, __tla as __tla_7 } from "./chunk-b5767d08.js";
import { A as Ye, __tla as __tla_8 } from "./chunk-57988b21.js";
import { A as os, __tla as __tla_9 } from "./chunk-234b1720.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
import { __tla as __tla_10 } from "./chunk-1784b260.js";
let Ys;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_10;
    } catch {
    }
  })()
]).then(async () => {
  function ns({ title: a, titleId: s, ...i }, o) {
    return r.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": s
    }, i), a ? r.createElement("title", {
      id: s
    }, a) : null, r.createElement("path", {
      fillRule: "evenodd",
      d: "M4.25 2A2.25 2.25 0 0 0 2 4.25v11.5A2.25 2.25 0 0 0 4.25 18h11.5A2.25 2.25 0 0 0 18 15.75V4.25A2.25 2.25 0 0 0 15.75 2H4.25ZM15 5.75a.75.75 0 0 0-1.5 0v8.5a.75.75 0 0 0 1.5 0v-8.5Zm-8.5 6a.75.75 0 0 0-1.5 0v2.5a.75.75 0 0 0 1.5 0v-2.5ZM8.584 9a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0v-4.5a.75.75 0 0 1 .75-.75Zm3.58-1.25a.75.75 0 0 0-1.5 0v6.5a.75.75 0 0 0 1.5 0v-6.5Z",
      clipRule: "evenodd"
    }));
  }
  const ds = r.forwardRef(ns), is = ds;
  function cs({ title: a, titleId: s, ...i }, o) {
    return r.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": s
    }, i), a ? r.createElement("title", {
      id: s
    }, a) : null, r.createElement("path", {
      d: "M2 4.5A2.5 2.5 0 0 1 4.5 2h11a2.5 2.5 0 0 1 0 5h-11A2.5 2.5 0 0 1 2 4.5ZM2.75 9.083a.75.75 0 0 0 0 1.5h14.5a.75.75 0 0 0 0-1.5H2.75ZM2.75 12.663a.75.75 0 0 0 0 1.5h14.5a.75.75 0 0 0 0-1.5H2.75ZM2.75 16.25a.75.75 0 0 0 0 1.5h14.5a.75.75 0 1 0 0-1.5H2.75Z"
    }));
  }
  const xs = r.forwardRef(cs), ye = xs;
  function us({ data: a, columns: s, enableRowSelection: i = false, onRowSelectionChange: o, rowSelection: d = {}, onRowClick: n }) {
    return e.jsx(Wt, {
      data: a,
      columns: s,
      enableRowSelection: i,
      onRowSelectionChange: o,
      rowSelection: d,
      initialSorting: [
        {
          id: "updatedAt",
          desc: true
        }
      ],
      onRowClick: n
    });
  }
  function gs() {
    const [a, s] = ne(), { notebookTags: i, notebooklm: o } = a, d = i.showUntagged, [n, h] = r.useState(false), [x, g] = r.useState(""), [b, f] = r.useState({
      top: 0,
      left: 0
    }), p = r.useRef(null), C = r.useRef(null), S = r.useRef(null), w = s.getAllTags(), u = s.getTagUsageCounts(), y = i.selectedTagFilter || [], T = r.useMemo(() => w.filter((m) => y.includes(m.id)), [
      w,
      y
    ]), D = r.useMemo(() => w.filter((m) => !y.includes(m.id)), [
      w,
      y
    ]), L = T.filter((m) => m.name.toLowerCase().includes(x.toLowerCase())), c = D.filter((m) => m.name.toLowerCase().includes(x.toLowerCase())), I = r.useMemo(() => ((o == null ? void 0 : o.projects) || []).filter((W) => (i.notebookTags[W.id] || []).length === 0).length, [
      o == null ? void 0 : o.projects,
      i.notebookTags
    ]);
    r.useEffect(() => {
      const m = (W) => {
        p.current && !p.current.contains(W.target) && (h(false), g(""));
      };
      return document.addEventListener("mousedown", m), () => document.removeEventListener("mousedown", m);
    }, []), r.useEffect(() => {
      if (n && C.current && C.current.focus(), n && S.current) {
        const m = S.current.getBoundingClientRect();
        f({
          top: m.bottom + 4,
          left: m.right - 224
        });
      }
    }, [
      n
    ]);
    const R = (m) => {
      s.toggleTagFilter(m);
    }, N = () => {
      s.setShowUntagged(!d), g("");
    }, j = (m) => {
      m.stopPropagation(), s.clearAllFilters();
    };
    if (!i.isLoaded)
      return e.jsxs("button", {
        disabled: true,
        className: "flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-slate-800 text-gray-400 dark:text-slate-500 opacity-50 cursor-not-allowed",
        children: [
          e.jsx(Ze, {
            className: "w-3.5 h-3.5"
          }),
          e.jsx("span", {
            children: "Loading..."
          })
        ]
      });
    if (w.length === 0 && I === 0)
      return null;
    const P = y.length > 0 || d, O = n && e.jsxs("div", {
      ref: p,
      className: "fixed z-[9999] w-56 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 border border-gray-200 dark:border-slate-700 py-2",
      style: {
        top: b.top,
        left: b.left
      },
      children: [
        e.jsx("div", {
          className: "px-2 pb-2",
          children: e.jsx("input", {
            ref: C,
            type: "text",
            value: x,
            onChange: (m) => g(m.target.value),
            placeholder: "Search tags...",
            className: "w-full px-2.5 py-1.5 text-xs border border-gray-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-900 dark:text-slate-100"
          })
        }),
        e.jsxs("div", {
          className: "max-h-64 overflow-y-auto",
          children: [
            I > 0 && (!x || "untagged".includes(x.toLowerCase())) && e.jsx("div", {
              className: "border-b border-gray-100 dark:border-slate-700 pb-1 mb-1",
              children: e.jsxs("button", {
                onClick: N,
                className: Y("w-full px-3 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2", d && "bg-blue-50 dark:bg-blue-950"),
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: d,
                    onChange: () => {
                    },
                    className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-1 cursor-pointer"
                  }),
                  e.jsxs("div", {
                    className: "flex-1 flex items-center justify-between gap-2",
                    children: [
                      e.jsxs("span", {
                        className: "flex items-center gap-1 text-xs text-gray-600 dark:text-slate-300",
                        children: [
                          e.jsx(Ge, {
                            className: "w-3 h-3"
                          }),
                          "Untagged"
                        ]
                      }),
                      e.jsx("span", {
                        className: "text-[10px] text-gray-400 dark:text-slate-500 tabular-nums",
                        children: I
                      })
                    ]
                  })
                ]
              })
            }),
            L.length > 0 && e.jsxs("div", {
              className: "mb-1",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between px-3 py-1.5 bg-gray-50 dark:bg-slate-900 border-b border-gray-100 dark:border-slate-700",
                  children: [
                    e.jsxs("span", {
                      className: "text-[10px] font-medium text-gray-500 dark:text-slate-400 uppercase tracking-wide",
                      children: [
                        "Selected (",
                        T.length,
                        ")"
                      ]
                    }),
                    e.jsx("button", {
                      onClick: j,
                      className: "text-[10px] text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300",
                      children: "Clear all"
                    })
                  ]
                }),
                L.map((m) => e.jsxs("button", {
                  onClick: () => R(m.id),
                  className: "w-full px-3 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 bg-blue-50 dark:bg-blue-950",
                  children: [
                    e.jsx("input", {
                      type: "checkbox",
                      checked: true,
                      onChange: () => {
                      },
                      className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-1 cursor-pointer"
                    }),
                    e.jsxs("div", {
                      className: "flex-1 flex items-center justify-between gap-2",
                      children: [
                        e.jsx(fe, {
                          tag: m,
                          size: "sm"
                        }),
                        e.jsx("span", {
                          className: "text-[10px] text-gray-400 dark:text-slate-500 tabular-nums",
                          children: u[m.id] || 0
                        })
                      ]
                    }),
                    e.jsx(le, {
                      className: "w-3 h-3 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 flex-shrink-0"
                    })
                  ]
                }, m.id))
              ]
            }),
            c.length > 0 && e.jsxs("div", {
              children: [
                P && e.jsx("div", {
                  className: "px-3 py-1.5 bg-gray-50 dark:bg-slate-900 border-b border-gray-100 dark:border-slate-700",
                  children: e.jsx("span", {
                    className: "text-[10px] font-medium text-gray-500 dark:text-slate-400 uppercase tracking-wide",
                    children: "All Tags"
                  })
                }),
                c.map((m) => e.jsxs("button", {
                  onClick: () => R(m.id),
                  className: "w-full px-3 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2",
                  children: [
                    e.jsx("input", {
                      type: "checkbox",
                      checked: false,
                      onChange: () => {
                      },
                      className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-1 cursor-pointer"
                    }),
                    e.jsxs("div", {
                      className: "flex-1 flex items-center justify-between gap-2",
                      children: [
                        e.jsx(fe, {
                          tag: m,
                          size: "sm"
                        }),
                        e.jsx("span", {
                          className: "text-[10px] text-gray-400 dark:text-slate-500 tabular-nums",
                          children: u[m.id] || 0
                        })
                      ]
                    })
                  ]
                }, m.id))
              ]
            }),
            L.length === 0 && c.length === 0 && e.jsx("div", {
              className: "px-3 py-3 text-xs text-gray-500 dark:text-slate-400 text-center",
              children: x ? "No matching tags" : "No tags yet. Create tags from the Tags manager."
            })
          ]
        })
      ]
    });
    return e.jsxs(e.Fragment, {
      children: [
        e.jsxs("button", {
          ref: S,
          onClick: () => h(!n),
          className: Y("flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md border transition-colors", P ? "bg-gray-100 dark:bg-slate-700 border-gray-300 dark:border-gray-600 text-gray-800 dark:text-slate-200" : "bg-white dark:bg-slate-800 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-700"),
          children: [
            e.jsx(Ze, {
              className: "w-3.5 h-3.5 flex-shrink-0"
            }),
            P ? e.jsxs(e.Fragment, {
              children: [
                e.jsx("div", {
                  className: "flex items-center gap-1 max-w-[140px] overflow-hidden",
                  children: d ? e.jsxs("span", {
                    className: "flex items-center gap-1 text-xs",
                    children: [
                      e.jsx(Ge, {
                        className: "w-3 h-3"
                      }),
                      "Untagged"
                    ]
                  }) : e.jsxs(e.Fragment, {
                    children: [
                      T.slice(0, 2).map((m) => e.jsx(fe, {
                        tag: m,
                        size: "xs"
                      }, m.id)),
                      T.length > 2 && e.jsxs("span", {
                        className: "text-[10px] text-gray-500 dark:text-slate-400 flex-shrink-0",
                        children: [
                          "+",
                          T.length - 2
                        ]
                      })
                    ]
                  })
                }),
                e.jsx("button", {
                  onClick: j,
                  className: "p-0.5 rounded hover:bg-gray-200 dark:hover:bg-slate-600 flex-shrink-0",
                  children: e.jsx(le, {
                    className: "w-3 h-3"
                  })
                })
              ]
            }) : e.jsxs(e.Fragment, {
              children: [
                e.jsx("span", {
                  children: "Filter by tag"
                }),
                e.jsx(Bt, {
                  className: "w-3.5 h-3.5"
                })
              ]
            })
          ]
        }),
        Rt.createPortal(O, document.body)
      ]
    });
  }
  function Te({ notebookId: a, showTotal: s = false, compact: i = false }) {
    const [o] = ne(), { artifactStats: d } = o, n = d.statsMap[a];
    if (d.loadingMap[a])
      return e.jsx("span", {
        className: "inline-flex items-center gap-1 text-xs text-neutral-400",
        children: e.jsx("span", {
          className: "w-2 h-2 rounded-full bg-neutral-300 animate-pulse"
        })
      });
    if (!n)
      return e.jsx("span", {
        className: "inline-flex items-center gap-0.5 px-1 py-0.5 rounded bg-neutral-100 dark:bg-slate-700 text-neutral-400 dark:text-neutral-500 text-[10px]",
        title: "Stats not scanned",
        children: "--"
      });
    if (n.total === 0)
      return null;
    const x = Object.keys(pe).map(Number).filter((g) => n[g] > 0);
    if (s)
      return e.jsxs("span", {
        className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300 text-xs",
        title: `${n.total} output${n.total !== 1 ? "s" : ""}`,
        children: [
          e.jsx(Ce, {
            className: "h-2.5 w-2.5"
          }),
          n.total
        ]
      });
    if (i && x.length > 2) {
      const g = x.slice(0, 2), b = x.length - 2, f = x.slice(2).map((p) => `${n[p]} ${ke[p]}`).join(", ");
      return e.jsxs("span", {
        className: "inline-flex items-center gap-1",
        children: [
          g.map((p) => {
            const C = pe[p], S = ke[p], w = n[p];
            return e.jsxs("span", {
              className: "relative group/badge",
              children: [
                e.jsxs("span", {
                  className: `inline-flex items-center gap-0.5 px-1 py-0.5 rounded ${Ve[p]}`,
                  children: [
                    e.jsx(C, {
                      className: "h-2.5 w-2.5"
                    }),
                    e.jsx("span", {
                      className: "text-[10px] font-medium",
                      children: w
                    })
                  ]
                }),
                e.jsxs("span", {
                  className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-1.5 py-0.5 text-[10px] text-white bg-neutral-800 rounded whitespace-nowrap opacity-0 group-hover/badge:opacity-100 pointer-events-none z-10",
                  children: [
                    w,
                    " ",
                    S,
                    w !== 1 ? "s" : ""
                  ]
                })
              ]
            }, p);
          }),
          e.jsxs("span", {
            className: "relative group/badge",
            children: [
              e.jsxs("span", {
                className: "px-1 py-0.5 rounded bg-neutral-100 dark:bg-slate-700 text-neutral-600 dark:text-neutral-300 text-[10px] font-medium",
                children: [
                  "+",
                  b
                ]
              }),
              e.jsx("span", {
                className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-1.5 py-0.5 text-[10px] text-white bg-neutral-800 rounded whitespace-nowrap opacity-0 group-hover/badge:opacity-100 pointer-events-none z-10",
                children: f
              })
            ]
          })
        ]
      });
    }
    return e.jsx("span", {
      className: "inline-flex items-center gap-1",
      children: x.map((g) => {
        const b = pe[g], f = ke[g], p = n[g];
        return e.jsxs("span", {
          className: "relative group/badge",
          children: [
            e.jsxs("span", {
              className: `inline-flex items-center gap-0.5 px-1 py-0.5 rounded ${Ve[g]}`,
              children: [
                e.jsx(b, {
                  className: "h-2.5 w-2.5"
                }),
                e.jsx("span", {
                  className: "text-[10px] font-medium",
                  children: p
                })
              ]
            }),
            e.jsxs("span", {
              className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-1.5 py-0.5 text-[10px] text-white bg-neutral-800 rounded whitespace-nowrap opacity-0 group-hover/badge:opacity-100 pointer-events-none z-10",
              children: [
                p,
                " ",
                f,
                p !== 1 ? "s" : ""
              ]
            })
          ]
        }, g);
      })
    });
  }
  const hs = (a) => a >= 16 ? "bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300" : a >= 6 ? "bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300" : "bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300";
  function ms({ notebook: a, isSelected: s, isSelecting: i, onSelect: o, onDelete: d, onRename: n }) {
    var _a, _b, _c, _d, _e, _f;
    const [h] = ne(), x = (_a = Je(h)) == null ? void 0 : _a.authuser, g = Object.keys(((_c = (_b = h.sourceFolders) == null ? void 0 : _b.folders) == null ? void 0 : _c[a.id]) || {}).length, b = re(a), f = ve(a), p = async (u) => {
      u.stopPropagation(), navigator.clipboard.writeText(a.title);
      const { default: y } = await U(() => import("./chunk-20599fbc.js"), []);
      y({
        particleCount: 50,
        spread: 50,
        origin: {
          y: 0.6
        }
      }), v.success("Title copied");
    }, C = (u) => {
      u.stopPropagation(), d == null ? void 0 : d(a);
    }, S = (u) => {
      u.stopPropagation(), n == null ? void 0 : n(a);
    }, w = () => {
      i ? o == null ? void 0 : o(a.id) : window.location.hash = `/notebook/${a.id}`;
    };
    return e.jsxs("div", {
      onClick: w,
      className: Y("bg-white dark:bg-slate-800 border rounded-lg p-3 flex flex-col gap-2 transition-colors cursor-pointer", s ? "border-neutral-900 dark:border-slate-300 ring-1 ring-neutral-900 dark:ring-slate-300" : "border-neutral-200 dark:border-slate-700 hover:border-neutral-400 dark:hover:border-slate-500"),
      children: [
        e.jsxs("div", {
          className: "flex items-start gap-2",
          children: [
            e.jsx("input", {
              type: "checkbox",
              className: "h-3.5 w-3.5 mt-0.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 focus:ring-1 transition-colors cursor-pointer flex-shrink-0",
              checked: s,
              onChange: () => o == null ? void 0 : o(a.id),
              onClick: (u) => u.stopPropagation()
            }),
            e.jsx("div", {
              className: "flex-1 min-w-0",
              children: e.jsxs("span", {
                className: "line-clamp-2 font-medium text-xs text-neutral-900 dark:text-slate-100",
                children: [
                  a.emoji,
                  " ",
                  a.title
                ]
              })
            }),
            e.jsx("button", {
              onClick: p,
              className: "p-1 rounded-full bg-neutral-100 dark:bg-slate-700 hover:bg-neutral-200 dark:hover:bg-slate-600 flex-shrink-0",
              title: "Copy title",
              children: e.jsx("svg", {
                className: "w-2.5 h-2.5 text-neutral-600 dark:text-slate-400",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: e.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                })
              })
            })
          ]
        }),
        e.jsx("div", {
          onClick: (u) => u.stopPropagation(),
          children: e.jsx(et, {
            notebookId: a.id,
            compact: true
          })
        }),
        e.jsxs("div", {
          className: "flex flex-wrap items-center gap-1.5 text-xs text-neutral-500 dark:text-slate-400",
          children: [
            e.jsxs("span", {
              className: Y("inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded", hs(((_d = a.sources) == null ? void 0 : _d.length) || 0)),
              children: [
                e.jsx(Ce, {
                  className: "w-3 h-3"
                }),
                ((_e = a.sources) == null ? void 0 : _e.length) || 0,
                " source",
                (((_f = a.sources) == null ? void 0 : _f.length) || 0) !== 1 ? "s" : ""
              ]
            }),
            g > 0 && e.jsxs("span", {
              className: "inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300",
              children: [
                e.jsx(tt, {
                  className: "w-3 h-3"
                }),
                g,
                " folder",
                g !== 1 ? "s" : ""
              ]
            }),
            e.jsx(ot, {
              code: a.permissionCode
            }),
            e.jsx("span", {
              className: "whitespace-nowrap",
              children: new Date(a.updatedAt).toLocaleString(void 0, {
                year: "numeric",
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit"
              })
            })
          ]
        }),
        e.jsx(Te, {
          notebookId: a.id
        }),
        e.jsxs("div", {
          className: "flex items-center gap-2 pt-1 border-t border-neutral-100 dark:border-slate-700",
          children: [
            e.jsxs("a", {
              href: ee(a.id, x),
              target: "_blank",
              rel: "noopener noreferrer",
              onClick: (u) => u.stopPropagation(),
              className: "flex items-center gap-1 text-xs text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100",
              title: "Open in NotebookLM",
              children: [
                e.jsx(de, {
                  className: "h-3 w-3"
                }),
                e.jsx("span", {
                  children: "NotebookLM"
                }),
                e.jsx(J, {
                  className: "h-2.5 w-2.5"
                })
              ]
            }),
            e.jsxs("a", {
              href: `#/notebook/${a.id}`,
              onClick: (u) => u.stopPropagation(),
              className: "flex items-center gap-1 text-xs text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100",
              title: "Manage sources",
              children: [
                e.jsx(ye, {
                  className: "h-3 w-3"
                }),
                e.jsx("span", {
                  children: "Sources"
                })
              ]
            }),
            e.jsx("div", {
              className: "flex-1"
            }),
            e.jsx("button", {
              onClick: S,
              disabled: !b,
              className: "p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-700 text-neutral-400 dark:text-slate-500 hover:text-neutral-700 dark:hover:text-slate-300 disabled:opacity-40 disabled:hover:bg-transparent disabled:cursor-not-allowed",
              title: b ? "Rename notebook" : _t,
              children: e.jsx(we, {
                className: "h-3.5 w-3.5"
              })
            }),
            e.jsx("button", {
              onClick: C,
              disabled: !f,
              className: "p-1 rounded hover:bg-red-50 dark:hover:bg-red-950 text-neutral-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition-colors disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-neutral-400 disabled:cursor-not-allowed",
              title: f ? "Delete notebook" : At,
              children: e.jsx(oe, {
                className: "h-3.5 w-3.5"
              })
            })
          ]
        })
      ]
    });
  }
  function bs({ data: a, selectedRows: s, onRowSelectionChange: i, onDelete: o, onRename: d }) {
    const n = Object.values(s).some(Boolean), [h, x] = r.useState({
      pageIndex: 0,
      pageSize: 24
    });
    r.useEffect(() => {
      x((c) => ({
        ...c,
        pageIndex: 0
      }));
    }, [
      a
    ]);
    const g = Math.ceil(a.length / h.pageSize), b = h.pageIndex > 0, f = h.pageIndex < g - 1, p = r.useMemo(() => {
      const c = h.pageIndex * h.pageSize;
      return a.slice(c, c + h.pageSize);
    }, [
      a,
      h.pageIndex,
      h.pageSize
    ]), C = (c) => {
      i == null ? void 0 : i((I) => ({
        ...I,
        [c]: !I[c]
      }));
    }, S = () => x((c) => ({
      ...c,
      pageIndex: 0
    })), w = () => x((c) => ({
      ...c,
      pageIndex: c.pageIndex - 1
    })), u = () => x((c) => ({
      ...c,
      pageIndex: c.pageIndex + 1
    })), y = () => x((c) => ({
      ...c,
      pageIndex: g - 1
    })), T = (c) => x((I) => ({
      ...I,
      pageIndex: Math.max(0, Math.min(c, g - 1))
    })), D = (c) => x({
      pageIndex: 0,
      pageSize: c
    }), L = ({ onClick: c, disabled: I, icon: R }) => e.jsx("button", {
      className: "inline-flex items-center justify-center w-6 h-6 text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors",
      onClick: c,
      disabled: I,
      children: e.jsx(R, {
        className: "w-3.5 h-3.5"
      })
    });
    return e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsx("div", {
          className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
          children: p.map((c) => e.jsx(ms, {
            notebook: c,
            isSelected: !!s[c.id],
            isSelecting: n,
            onSelect: C,
            onDelete: o,
            onRename: d
          }, c.id))
        }),
        a.length === 0 && e.jsx("div", {
          className: "text-center py-8 text-xs text-neutral-500 dark:text-slate-400",
          children: "No results found"
        }),
        g > 1 && e.jsxs("div", {
          className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between px-1",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-1",
                  children: [
                    e.jsx(L, {
                      icon: st,
                      onClick: S,
                      disabled: !b
                    }),
                    e.jsx(L, {
                      icon: at,
                      onClick: w,
                      disabled: !b
                    }),
                    e.jsxs("span", {
                      className: "mx-2 text-xs text-neutral-600 dark:text-slate-400 font-medium",
                      children: [
                        "Page",
                        " ",
                        e.jsx("span", {
                          className: "text-neutral-900 dark:text-slate-100",
                          children: h.pageIndex + 1
                        }),
                        " ",
                        "of ",
                        e.jsx("span", {
                          className: "text-neutral-900 dark:text-slate-100",
                          children: g
                        })
                      ]
                    }),
                    e.jsx(L, {
                      icon: rt,
                      onClick: u,
                      disabled: !f
                    }),
                    e.jsx(L, {
                      icon: lt,
                      onClick: y,
                      disabled: !f
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "h-4 w-px bg-neutral-200 dark:bg-slate-700 hidden sm:block"
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("span", {
                      className: "text-xs text-neutral-500 dark:text-slate-400 hidden sm:inline",
                      children: "Go to"
                    }),
                    e.jsx("input", {
                      type: "number",
                      min: 1,
                      max: g,
                      defaultValue: h.pageIndex + 1,
                      onChange: (c) => {
                        const I = c.target.value ? Number(c.target.value) - 1 : 0;
                        T(I);
                      },
                      className: "w-12 px-1.5 py-1 text-xs text-neutral-900 dark:text-slate-100 border border-neutral-300 dark:border-slate-600 rounded focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 bg-white dark:bg-slate-800 transition-shadow"
                    }, h.pageIndex)
                  ]
                }),
                e.jsx("select", {
                  className: "px-2 py-1 w-[4.5rem] text-xs text-neutral-900 dark:text-slate-100 border border-neutral-300 dark:border-slate-600 rounded focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 bg-white dark:bg-slate-800 transition-shadow cursor-pointer",
                  value: h.pageSize,
                  onChange: (c) => D(Number(c.target.value)),
                  children: [
                    24,
                    48,
                    72,
                    96
                  ].map((c) => e.jsx("option", {
                    value: c,
                    children: c
                  }, c))
                })
              ]
            }),
            e.jsxs("div", {
              className: "text-xs text-neutral-500 dark:text-slate-400 font-medium",
              children: [
                "Showing",
                " ",
                e.jsx("span", {
                  className: "text-neutral-900 dark:text-slate-100",
                  children: p.length
                }),
                " of",
                " ",
                e.jsx("span", {
                  className: "text-neutral-900 dark:text-slate-100",
                  children: a.length
                }),
                " results"
              ]
            })
          ]
        })
      ]
    });
  }
  const ps = [
    {
      key: "all",
      label: "All"
    },
    {
      key: "notebooks",
      label: "Notebooks"
    },
    {
      key: "sources",
      label: "Sources"
    }
  ];
  function ks({ query: a, setQuery: s, activeTab: i, setActiveTab: o, notebookCount: d, sourceCount: n, totalNotebooks: h, onClose: x }) {
    const g = r.useRef(null), b = r.useRef(null);
    r.useEffect(() => {
      var _a;
      return (_a = g.current) == null ? void 0 : _a.focus(), () => {
        b.current && clearTimeout(b.current);
      };
    }, []);
    const f = r.useCallback((u) => {
      const y = u.target.value;
      b.current && clearTimeout(b.current), b.current = setTimeout(() => s(y), 150);
    }, [
      s
    ]), p = (u) => {
      u.key === "Escape" && (u.preventDefault(), b.current && clearTimeout(b.current), x());
    }, C = () => {
      b.current && clearTimeout(b.current), g.current && (g.current.value = ""), x();
    }, S = d + n, w = {
      all: S,
      notebooks: d,
      sources: n
    };
    return e.jsxs("div", {
      className: "space-y-2",
      children: [
        e.jsxs("div", {
          role: "search",
          "aria-label": "Search across all notebooks",
          className: "relative",
          children: [
            e.jsx(Se, {
              className: "absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400 dark:text-slate-500 pointer-events-none",
              "aria-hidden": "true"
            }),
            e.jsx("input", {
              ref: g,
              type: "text",
              defaultValue: a,
              onChange: f,
              onKeyDown: p,
              placeholder: `Search across all ${h || 0} notebooks...`,
              className: "w-full pl-8 pr-8 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-neutral-900/20 dark:focus:ring-slate-400/20 focus:border-neutral-900 dark:focus:border-slate-400 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100",
              "aria-label": "Search notebooks and sources"
            }),
            a && e.jsx("button", {
              onClick: C,
              className: "absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-slate-500 hover:text-neutral-600 dark:hover:text-slate-300",
              "aria-label": "Clear search",
              children: e.jsx(le, {
                className: "h-3.5 w-3.5"
              })
            })
          ]
        }),
        (a == null ? void 0 : a.trim()) && e.jsxs(e.Fragment, {
          children: [
            e.jsx("div", {
              role: "tablist",
              "aria-label": "Search result categories",
              className: "flex p-0.5 bg-neutral-100 dark:bg-slate-700 rounded-md",
              children: ps.map((u) => e.jsxs("button", {
                role: "tab",
                "aria-selected": i === u.key,
                "aria-controls": `tabpanel-${u.key}`,
                onClick: () => o(u.key),
                className: `flex-1 px-2 py-1.5 rounded text-xs font-medium ${i === u.key ? "bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30" : "text-neutral-600 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-200"}`,
                children: [
                  u.label,
                  " (",
                  w[u.key],
                  ")"
                ]
              }, u.key))
            }),
            e.jsxs("div", {
              className: "sr-only",
              "aria-live": "polite",
              children: [
                S,
                " results found: ",
                d,
                " notebooks, ",
                n,
                " sources"
              ]
            })
          ]
        })
      ]
    });
  }
  function dt({ onDelete: a, canDelete: s, disabledReason: i, item: o, label: d }) {
    return a ? e.jsxs("button", {
      type: "button",
      onClick: (n) => {
        n.preventDefault(), n.stopPropagation(), a(o);
      },
      disabled: !s,
      title: s ? d : i || "Cannot delete",
      className: "flex-shrink-0 inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed",
      children: [
        e.jsx(oe, {
          className: "h-2.5 w-2.5"
        }),
        "Delete"
      ]
    }) : null;
  }
  const it = (a, s) => {
    if (!(s == null ? void 0 : s.trim()) || !a)
      return a || "Untitled";
    const i = s.toLowerCase(), o = a.toLowerCase().indexOf(i);
    return o === -1 ? a : e.jsxs(e.Fragment, {
      children: [
        a.slice(0, o),
        e.jsx("mark", {
          className: "bg-yellow-200 dark:bg-yellow-900/50 text-inherit rounded-sm px-0.5",
          children: a.slice(o, o + s.length)
        }),
        a.slice(o + s.length)
      ]
    });
  };
  function Ke({ notebook: a, query: s, authuser: i, onDelete: o, canDelete: d, disabledReason: n }) {
    var _a;
    return e.jsxs("div", {
      className: "flex items-center gap-2 py-2 px-3 hover:bg-neutral-50 dark:hover:bg-slate-700/50 rounded-md",
      children: [
        e.jsxs("a", {
          href: `#/notebook/${a.id}`,
          className: "flex items-center gap-2 flex-1 min-w-0 cursor-pointer",
          children: [
            e.jsx("span", {
              className: "text-base flex-shrink-0",
              children: a.emoji || "\u{1F4D3}"
            }),
            e.jsxs("div", {
              className: "flex-1 min-w-0",
              children: [
                e.jsx("div", {
                  className: "text-xs font-medium text-neutral-900 dark:text-slate-100 truncate",
                  children: it(a.title || "Untitled notebook", s)
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2 text-[10px] text-neutral-400 dark:text-slate-500",
                  children: [
                    e.jsxs("span", {
                      children: [
                        ((_a = a.sources) == null ? void 0 : _a.length) || 0,
                        " sources"
                      ]
                    }),
                    e.jsx(Te, {
                      notebookId: a.id,
                      showTotal: true
                    })
                  ]
                })
              ]
            }),
            e.jsx("span", {
              className: "text-[10px] text-neutral-400 dark:text-slate-500 tabular-nums flex-shrink-0",
              children: nt(a.createdAt)
            })
          ]
        }),
        e.jsxs("a", {
          href: ee(a.id, i),
          target: "_blank",
          rel: "noopener noreferrer",
          title: "Open in NotebookLM",
          className: "flex-shrink-0 flex items-center gap-1 text-xs text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100",
          children: [
            e.jsx(de, {
              className: "h-3 w-3"
            }),
            e.jsx("span", {
              children: "NotebookLM"
            }),
            e.jsx(J, {
              className: "h-2.5 w-2.5"
            })
          ]
        }),
        e.jsx(dt, {
          onDelete: o,
          canDelete: d,
          disabledReason: n,
          item: a,
          label: "Delete notebook"
        })
      ]
    });
  }
  function We({ source: a, query: s, authuser: i, onDelete: o, canDelete: d, disabledReason: n }) {
    const h = a.url ? ls(a.url) : null;
    return e.jsxs("div", {
      className: "flex flex-col gap-0.5 py-2 px-3 hover:bg-neutral-50 dark:hover:bg-slate-700/50 rounded-md",
      tabIndex: 0,
      onKeyDown: (x) => {
        (x.key === "Enter" || x.key === " ") && (x.preventDefault(), window.location.hash = `/notebook/${a.notebookId}`);
      },
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-1.5 min-w-0",
          children: [
            e.jsx(Xt, {
              sourceType: a.sourceType
            }),
            e.jsx("span", {
              className: "text-xs font-medium text-neutral-900 dark:text-slate-100 truncate flex-1 min-w-0",
              children: it(a.title || "Untitled source", s)
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-2 ml-6 min-w-0",
          children: [
            e.jsxs("a", {
              href: `#/notebook/${a.notebookId}`,
              className: "text-[10px] text-neutral-500 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-200 truncate max-w-[180px]",
              children: [
                a.notebookEmoji || "\u{1F4D3}",
                " ",
                a.notebookTitle || "Untitled notebook"
              ]
            }),
            e.jsxs("a", {
              href: ee(a.notebookId, i),
              target: "_blank",
              rel: "noopener noreferrer",
              title: "Open in NotebookLM",
              className: "flex-shrink-0 flex items-center gap-0.5 text-[10px] text-neutral-400 dark:text-slate-500 hover:text-neutral-700 dark:hover:text-slate-300",
              children: [
                e.jsx(de, {
                  className: "h-2.5 w-2.5"
                }),
                e.jsx("span", {
                  children: "NotebookLM"
                }),
                e.jsx(J, {
                  className: "h-2 w-2"
                })
              ]
            }),
            h && e.jsxs("span", {
              className: "text-[10px] text-neutral-400 dark:text-slate-500 truncate max-w-[120px]",
              children: [
                "\u2192 ",
                h
              ]
            }),
            e.jsx("span", {
              className: "text-[10px] text-neutral-400 dark:text-slate-500 tabular-nums ml-auto flex-shrink-0",
              children: nt(a.createdAt)
            }),
            e.jsx(dt, {
              onDelete: o,
              canDelete: d,
              disabledReason: n,
              item: a,
              label: "Delete source"
            })
          ]
        })
      ]
    });
  }
  function fs({ typeCounts: a, typeFilter: s, setTypeFilter: i }) {
    const o = Object.keys(a).sort();
    if (o.length <= 1)
      return null;
    const d = Object.values(a).reduce((n, h) => n + h, 0);
    return e.jsxs("div", {
      className: "flex items-center gap-1.5 flex-wrap",
      children: [
        e.jsxs("button", {
          onClick: () => i(null),
          className: `px-2 py-1 rounded-full text-xs font-medium ${s === null ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : "bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-300 hover:bg-gray-200 dark:hover:bg-slate-600"}`,
          children: [
            "All (",
            d,
            ")"
          ]
        }),
        o.map((n) => {
          const h = s === n, x = Jt[n], g = es[n] || "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300";
          return e.jsxs("button", {
            onClick: () => i(h ? null : n),
            className: `inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${h ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : g}`,
            children: [
              x && e.jsx(x, {
                className: "w-3 h-3",
                "aria-hidden": "true"
              }),
              qt[n] || "Unknown",
              " (",
              a[n],
              ")"
            ]
          }, n);
        })
      ]
    });
  }
  const G = 24;
  function Xe({ pageIndex: a, pageCount: s, setPageIndex: i, total: o, visible: d }) {
    if (s <= 1)
      return null;
    const n = ({ onClick: h, disabled: x, icon: g }) => e.jsx("button", {
      className: "inline-flex items-center justify-center w-6 h-6 text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed",
      onClick: h,
      disabled: x,
      children: e.jsx(g, {
        className: "w-3.5 h-3.5"
      })
    });
    return e.jsxs("div", {
      className: "flex items-center justify-between px-1 pt-2",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-1",
          children: [
            e.jsx(n, {
              icon: st,
              onClick: () => i(0),
              disabled: a === 0
            }),
            e.jsx(n, {
              icon: at,
              onClick: () => i(a - 1),
              disabled: a === 0
            }),
            e.jsxs("span", {
              className: "mx-2 text-xs text-neutral-600 dark:text-slate-400 font-medium",
              children: [
                "Page ",
                e.jsx("span", {
                  className: "text-neutral-900 dark:text-slate-100",
                  children: a + 1
                }),
                " of",
                " ",
                e.jsx("span", {
                  className: "text-neutral-900 dark:text-slate-100",
                  children: s
                })
              ]
            }),
            e.jsx(n, {
              icon: rt,
              onClick: () => i(a + 1),
              disabled: a >= s - 1
            }),
            e.jsx(n, {
              icon: lt,
              onClick: () => i(s - 1),
              disabled: a >= s - 1
            })
          ]
        }),
        e.jsxs("span", {
          className: "text-xs text-neutral-500 dark:text-slate-400 font-medium",
          children: [
            e.jsx("span", {
              className: "text-neutral-900 dark:text-slate-100",
              children: d
            }),
            " of",
            " ",
            e.jsx("span", {
              className: "text-neutral-900 dark:text-slate-100",
              children: o
            })
          ]
        })
      ]
    });
  }
  function js({ activeTab: a, notebookResults: s, sourceResults: i, query: o, sourceTypeFilter: d, setSourceTypeFilter: n, sourceTypeCounts: h, onTabChange: x, authuser: g, onDeleteSource: b, onDeleteNotebook: f, canDeleteSource: p, canDeleteNotebook: C, sourceDisabledReason: S, notebookDisabledReason: w }) {
    const [u, y] = r.useState(0), [T, D] = r.useState(0);
    r.useEffect(() => {
      y(0);
    }, [
      s
    ]), r.useEffect(() => {
      D(0);
    }, [
      i
    ]);
    const L = Math.ceil(s.length / G), c = Math.ceil(i.length / G);
    r.useEffect(() => {
      T > 0 && T >= c && D(Math.max(0, c - 1));
    }, [
      T,
      c
    ]), r.useEffect(() => {
      u > 0 && u >= L && y(Math.max(0, L - 1));
    }, [
      u,
      L
    ]);
    const I = r.useMemo(() => s.slice(u * G, (u + 1) * G), [
      s,
      u
    ]), R = r.useMemo(() => i.slice(T * G, (T + 1) * G), [
      i,
      T
    ]), N = r.useMemo(() => new Set(i.map((j) => j.notebookId)).size, [
      i
    ]);
    if (s.length === 0 && i.length === 0)
      return e.jsxs("div", {
        role: "tabpanel",
        id: `tabpanel-${a}`,
        className: "flex flex-col items-center justify-center py-12 bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 border-dashed",
        children: [
          e.jsx("div", {
            className: "p-3 bg-neutral-50 dark:bg-slate-900 rounded-full mb-3",
            children: e.jsx(Se, {
              className: "h-5 w-5 text-neutral-400 dark:text-slate-500"
            })
          }),
          e.jsxs("h3", {
            className: "text-xs font-medium text-neutral-900 dark:text-slate-100",
            children: [
              "No matches for \u201C",
              o,
              "\u201D"
            ]
          }),
          e.jsx("p", {
            className: "mt-1 text-xs text-neutral-500 dark:text-slate-400 text-center max-w-[250px]",
            children: "Try a different search term or check your spelling"
          })
        ]
      });
    if (a === "all") {
      const j = s.slice(0, 2), P = i.slice(0, 5);
      return e.jsxs("div", {
        role: "tabpanel",
        id: "tabpanel-all",
        className: "space-y-4",
        children: [
          j.length > 0 && e.jsxs("div", {
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between mb-1 px-1",
                children: [
                  e.jsx("h3", {
                    className: "text-[10px] font-semibold text-neutral-500 dark:text-slate-400 uppercase tracking-wider",
                    children: "Notebooks"
                  }),
                  s.length > 2 && e.jsxs("button", {
                    onClick: () => x("notebooks"),
                    className: "text-[10px] text-neutral-500 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-200 underline",
                    children: [
                      "See all ",
                      s.length
                    ]
                  })
                ]
              }),
              e.jsx("div", {
                className: "bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 divide-y divide-neutral-100 dark:divide-slate-700",
                children: j.map((O) => e.jsx(Ke, {
                  notebook: O,
                  query: o,
                  authuser: g,
                  onDelete: f,
                  canDelete: C ? C(O) : true,
                  disabledReason: w
                }, O.id))
              })
            ]
          }),
          P.length > 0 && e.jsxs("div", {
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between mb-1 px-1",
                children: [
                  e.jsxs("h3", {
                    className: "text-[10px] font-semibold text-neutral-500 dark:text-slate-400 uppercase tracking-wider",
                    children: [
                      "Sources",
                      e.jsxs("span", {
                        className: "ml-1 font-normal normal-case",
                        children: [
                          "(",
                          i.length,
                          " across ",
                          N,
                          " notebook",
                          N !== 1 ? "s" : "",
                          ")"
                        ]
                      })
                    ]
                  }),
                  i.length > 5 && e.jsxs("button", {
                    onClick: () => x("sources"),
                    className: "text-[10px] text-neutral-500 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-200 underline",
                    children: [
                      "See all ",
                      i.length
                    ]
                  })
                ]
              }),
              e.jsx("div", {
                className: "bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 divide-y divide-neutral-100 dark:divide-slate-700",
                children: P.map((O, m) => e.jsx(We, {
                  source: O,
                  query: o,
                  authuser: g,
                  onDelete: b,
                  canDelete: p ? p(O) : true,
                  disabledReason: S
                }, `${O.notebookId}-${O.id}-${m}`))
              })
            ]
          })
        ]
      });
    }
    return a === "notebooks" ? e.jsxs("div", {
      role: "tabpanel",
      id: "tabpanel-notebooks",
      className: "space-y-2",
      children: [
        e.jsxs("p", {
          className: "text-xs text-neutral-500 dark:text-slate-400 px-1",
          children: [
            s.length,
            " notebook",
            s.length !== 1 ? "s" : "",
            " matching \u201C",
            o,
            "\u201D"
          ]
        }),
        e.jsx("div", {
          className: "bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 divide-y divide-neutral-100 dark:divide-slate-700",
          children: I.map((j) => e.jsx(Ke, {
            notebook: j,
            query: o,
            authuser: g,
            onDelete: f,
            canDelete: C ? C(j) : true,
            disabledReason: w
          }, j.id))
        }),
        e.jsx(Xe, {
          pageIndex: u,
          pageCount: L,
          setPageIndex: y,
          total: s.length,
          visible: I.length
        })
      ]
    }) : e.jsxs("div", {
      role: "tabpanel",
      id: "tabpanel-sources",
      className: "space-y-2",
      children: [
        e.jsx(fs, {
          typeCounts: h,
          typeFilter: d,
          setTypeFilter: n
        }),
        e.jsxs("p", {
          className: "text-xs text-neutral-500 dark:text-slate-400 px-1",
          children: [
            i.length,
            " source",
            i.length !== 1 ? "s" : "",
            " across",
            " ",
            N,
            " notebook",
            N !== 1 ? "s" : ""
          ]
        }),
        e.jsx("div", {
          className: "bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 divide-y divide-neutral-100 dark:divide-slate-700",
          children: R.map((j, P) => e.jsx(We, {
            source: j,
            query: o,
            authuser: g,
            onDelete: b,
            canDelete: p ? p(j) : true,
            disabledReason: S
          }, `${j.notebookId}-${j.id}-${P}`))
        }),
        e.jsx(Xe, {
          pageIndex: T,
          pageCount: c,
          setPageIndex: D,
          total: i.length,
          visible: R.length
        })
      ]
    });
  }
  function Ns({ isOpen: a, onClose: s, onConfirm: i, notebook: o }) {
    var _a;
    const [d, n] = r.useState(false);
    if (r.useEffect(() => {
      a && n(false);
    }, [
      a
    ]), !o)
      return null;
    const h = ((_a = o.sources) == null ? void 0 : _a.length) ?? 0, x = `Delete "${o.title || "Untitled notebook"}"?`, g = `This will permanently delete the notebook, all ${h} source${h === 1 ? "" : "s"}, chats, and artifacts. This cannot be undone.`, b = async () => {
      n(true);
      try {
        await i(o), s();
      } catch {
        n(false);
      }
    };
    return e.jsxs(Ut, {
      open: a,
      onClose: d ? () => {
      } : s,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(zt, {
            className: "w-full max-w-sm space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsx(Vt, {
                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                children: x
              }),
              e.jsx("p", {
                className: "text-xs text-gray-500 dark:text-slate-400",
                children: g
              }),
              e.jsxs("div", {
                className: "flex justify-end gap-2 pt-2",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: s,
                    disabled: d,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  e.jsx("button", {
                    type: "button",
                    onClick: b,
                    disabled: d,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50",
                    children: d ? "Deleting..." : "Delete"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  const vs = {
    [je.OWNER]: "Owner",
    [je.EDITOR]: "Editor",
    [je.VIEWER]: "Viewer"
  }, qe = "YT_NOTEBOOKLM_TOOLS_ROLE_TAB", ws = K.lazy(() => U(() => import("./chunk-fafac451.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-fafac451.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css"])), ys = K.lazy(() => U(() => import("./chunk-cbf1930e.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-cbf1930e.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css"])), Cs = K.lazy(() => U(() => import("./chunk-7b729e74.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-7b729e74.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-95b0b380.js","assets/chunk-b5767d08.js"])), Ss = K.lazy(() => U(() => import("./chunk-f5c7cdb5.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-f5c7cdb5.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-b81ff817.js","assets/chunk-57988b21.js"])), Ts = K.lazy(() => U(() => import("./chunk-c7467381.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-c7467381.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-b81ff817.js","assets/chunk-e153acea.js","assets/chunk-234b1720.js"])), Is = K.lazy(() => U(() => import("./chunk-d3f2238e.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-d3f2238e.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css"])), Ls = async (a) => {
    const { default: s } = await U(() => import("./chunk-20599fbc.js"), []);
    s(a);
  }, Ms = (a) => a >= 16 ? "bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300" : a >= 6 ? "bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300" : "bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300";
  Ys = function() {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i;
    const [a, s] = ne(), { authNotebookLM: i, notebooklm: o, notebookTags: d, sourceFolders: n } = a, h = (_a = Je(a)) == null ? void 0 : _a.authuser, x = Qt(), g = Ht(), [b, f] = r.useState(false), [p, C] = r.useState(false), [S, w] = r.useState(false), [u, y] = r.useState(false), [T, D] = r.useState("export"), [L, c] = r.useState(false), [I, R] = r.useState(false), [N, j] = r.useState({}), [P, O] = r.useState(false), [m, W] = r.useState(() => localStorage.getItem("YT_NOTEBOOKLM_TOOLS_VIEW_MODE") || "grid"), [_, ct] = r.useState(() => localStorage.getItem(qe) || "mine"), [Q, te] = r.useState(""), [M, Ie] = r.useState(() => sessionStorage.getItem("crossSearchQuery") || ""), [se, ie] = r.useState(() => sessionStorage.getItem("crossSearchTab") || "all"), [z, Le] = r.useState(() => sessionStorage.getItem("crossSourceTypeFilter") || null), { artifactStats: $ } = a, { pendingRenameItems: ce, handleRename: xe, handleBulkRename: xt, confirmRename: ut, closeRenameDialog: gt } = ts({
      renameAction: (t, l) => s.renameNotebookLM(t, l),
      refreshAction: () => s.fetchNotebookLMProjects(),
      setIsLoading: f,
      setSelectedRows: j,
      itemLabel: "notebook"
    });
    r.useEffect(() => {
      d.isLoaded || s.loadTags();
    }, [
      d.isLoaded,
      s
    ]), r.useEffect(() => {
      Object.keys($.statsMap).length === 0 && s.loadStatsFromCache();
    }, []);
    const ue = r.useRef(false);
    r.useEffect(() => {
      !(n == null ? void 0 : n.isLoaded) && !ue.current && (ue.current = true, s.loadSourceFolders().finally(() => {
        ue.current = false;
      }));
    }, [
      n == null ? void 0 : n.isLoaded,
      s
    ]), r.useEffect(() => {
      const t = new URLSearchParams(g.search), l = t.get("tags"), k = t.get("tag");
      t.get("untagged") === "true" && d.isLoaded ? (s.setShowUntagged(true), x("/notebooklm", {
        replace: true
      })) : (l || k) && d.isLoaded && (l ? s.setTagFilter(l.split(",").filter(Boolean)) : k && s.setTagFilter([
        k
      ]), x("/notebooklm", {
        replace: true
      }));
    }, [
      g.search,
      d.isLoaded,
      s,
      x
    ]), r.useEffect(() => {
      !P && s.isNotebookLMAuthenticated() && (ht(), O(true));
    }, [
      P,
      s
    ]);
    const ht = async () => {
      f(true);
      try {
        await s.fetchNotebookLMProjects();
      } catch {
        v.error("Failed to load projects");
      } finally {
        f(false);
      }
    }, ge = async (t) => {
      if (window.confirm("Delete this project?")) {
        f(true);
        try {
          await s.deleteNotebookLMProject(t.id), await s.fetchNotebookLMProjects(), v.success("Project deleted"), Z(() => s.isLicensed());
        } catch {
          v.error("Failed to delete project");
        } finally {
          f(false);
        }
      }
    }, mt = r.useMemo(() => [
      {
        id: "select",
        header: ({ table: t }) => e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 focus:ring-1 transition-colors cursor-pointer",
          checked: t.getIsAllPageRowsSelected(),
          onClick: (l) => l.stopPropagation(),
          onChange: t.getToggleAllPageRowsSelectedHandler()
        }),
        cell: ({ row: t }) => e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 focus:ring-1 transition-colors cursor-pointer",
          checked: t.getIsSelected(),
          disabled: !t.getCanSelect(),
          onClick: (l) => l.stopPropagation(),
          onChange: t.getToggleSelectedHandler()
        }),
        enableSorting: false,
        enableColumnFilter: false
      },
      {
        id: "title",
        accessorKey: "title",
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
          children: "Title"
        }),
        cell: (t) => e.jsxs("div", {
          className: "flex flex-col gap-1",
          children: [
            e.jsxs("div", {
              className: "flex items-start gap-2",
              children: [
                e.jsxs("span", {
                  className: "line-clamp-2 font-medium text-xs text-neutral-900 dark:text-slate-100 hover:underline cursor-pointer",
                  onClick: (l) => {
                    l.stopPropagation(), Object.values(N).some(Boolean) ? t.row.toggleSelected() : x(`/notebook/${t.row.original.id}`);
                  },
                  children: [
                    t.row.original.emoji,
                    " ",
                    t.getValue()
                  ]
                }),
                e.jsx("button", {
                  onClick: (l) => {
                    l.stopPropagation(), navigator.clipboard.writeText(t.getValue()), Ls({
                      particleCount: 50,
                      spread: 50,
                      origin: {
                        y: 0.6
                      }
                    }), v.success("Title copied");
                  },
                  className: "p-1 rounded-full bg-neutral-100 dark:bg-slate-700 hover:bg-neutral-200 dark:hover:bg-slate-600 flex-shrink-0",
                  title: "Copy title",
                  children: e.jsx("svg", {
                    className: "w-2.5 h-2.5 text-neutral-600 dark:text-slate-400",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                    })
                  })
                }),
                e.jsx("a", {
                  href: ee(t.row.original.id, h),
                  target: "_blank",
                  rel: "noopener noreferrer",
                  onClick: (l) => l.stopPropagation(),
                  className: "p-1 rounded-full bg-neutral-100 dark:bg-slate-700 hover:bg-neutral-200 dark:hover:bg-slate-600 flex-shrink-0",
                  title: "Open in NotebookLM",
                  children: e.jsx(J, {
                    className: "w-2.5 h-2.5 text-neutral-600 dark:text-slate-400"
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("span", {
                  className: "text-xs text-neutral-500 dark:text-slate-400",
                  children: new Date(t.row.original.createdAt).toLocaleString(void 0, {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                  })
                }),
                e.jsx(Te, {
                  notebookId: t.row.original.id
                })
              ]
            })
          ]
        }),
        footer: (t) => t.column.id
      },
      {
        id: "tags",
        accessorFn: (t) => s.getNotebookTags(t.id).map((k) => k.name).join(" "),
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
          children: "Tags"
        }),
        cell: (t) => e.jsx("div", {
          onClick: (l) => l.stopPropagation(),
          children: e.jsx(et, {
            notebookId: t.row.original.id,
            compact: true
          })
        }),
        footer: (t) => t.column.id,
        enableColumnFilter: true,
        size: 150
      },
      {
        id: "sources",
        accessorFn: (t) => t == null ? void 0 : t.sources,
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
          children: "Sources"
        }),
        cell: (t) => {
          var _a2, _b2;
          const l = ((_a2 = t == null ? void 0 : t.getValue()) == null ? void 0 : _a2.length) || 0, k = Object.keys(((_b2 = n == null ? void 0 : n.folders) == null ? void 0 : _b2[t.row.original.id]) || {}).length;
          return e.jsxs("div", {
            className: "flex items-center gap-1",
            children: [
              e.jsxs("span", {
                className: "relative group/src",
                children: [
                  e.jsxs("span", {
                    className: `inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-xs ${Ms(l)}`,
                    children: [
                      e.jsx(Ce, {
                        className: "w-3 h-3"
                      }),
                      l
                    ]
                  }),
                  e.jsxs("span", {
                    className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-1.5 py-0.5 text-[10px] text-white bg-neutral-800 rounded whitespace-nowrap opacity-0 group-hover/src:opacity-100 pointer-events-none z-10",
                    children: [
                      l,
                      " source",
                      l !== 1 ? "s" : ""
                    ]
                  })
                ]
              }),
              k > 0 && e.jsxs("span", {
                className: "relative group/fld",
                children: [
                  e.jsxs("span", {
                    className: "inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-xs bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300",
                    children: [
                      e.jsx(tt, {
                        className: "w-3 h-3"
                      }),
                      k
                    ]
                  }),
                  e.jsxs("span", {
                    className: "absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-1.5 py-0.5 text-[10px] text-white bg-neutral-800 rounded whitespace-nowrap opacity-0 group-hover/fld:opacity-100 pointer-events-none z-10",
                    children: [
                      k,
                      " folder",
                      k !== 1 ? "s" : ""
                    ]
                  })
                ]
              })
            ]
          });
        },
        footer: (t) => t.column.id,
        enableColumnFilter: false
      },
      {
        id: "role",
        accessorFn: (t) => t == null ? void 0 : t.permissionCode,
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
          children: "Role"
        }),
        cell: (t) => e.jsx(ot, {
          code: t.getValue()
        }),
        footer: (t) => t.column.id,
        enableColumnFilter: false,
        size: 70
      },
      {
        id: "updatedAt",
        accessorFn: (t) => t == null ? void 0 : t.updatedAt,
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
          children: "Updated"
        }),
        cell: (t) => e.jsx("span", {
          className: "text-xs text-neutral-500 dark:text-slate-400 whitespace-nowrap",
          children: new Date(t.getValue()).toLocaleString(void 0, {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          })
        }),
        footer: (t) => t.column.id,
        enableColumnFilter: false,
        size: 120
      },
      {
        id: "actions",
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-neutral-700 dark:text-slate-300"
        }),
        cell: (t) => e.jsxs("div", {
          className: "flex items-center justify-end gap-1",
          children: [
            e.jsxs("a", {
              href: ee(t.row.original.id, h),
              target: "_blank",
              rel: "noopener noreferrer",
              className: "flex items-center gap-1.5 p-1.5 px-2 rounded-md hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 transition-colors",
              onClick: (l) => l.stopPropagation(),
              title: "Open in NotebookLM",
              children: [
                e.jsx(de, {
                  className: "h-3.5 w-3.5"
                }),
                e.jsx("span", {
                  className: "text-xs font-medium",
                  children: "NotebookLM"
                }),
                e.jsx(J, {
                  className: "h-3 w-3"
                })
              ]
            }),
            e.jsxs("a", {
              href: `#/notebook/${t.row.original.id}`,
              className: "flex items-center gap-1.5 p-1.5 px-2 rounded-md hover:bg-neutral-100 dark:hover:bg-slate-700 text-neutral-500 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 transition-colors",
              onClick: (l) => l.stopPropagation(),
              title: "Manage sources",
              children: [
                e.jsx(ye, {
                  className: "h-3.5 w-3.5"
                }),
                e.jsx("span", {
                  className: "text-xs font-medium",
                  children: "Sources"
                })
              ]
            }),
            e.jsx("button", {
              className: "p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 text-neutral-400 dark:text-slate-500 hover:text-neutral-700 dark:hover:text-slate-300",
              onClick: (l) => {
                l.stopPropagation(), xe(t.row.original);
              },
              disabled: b,
              title: "Rename notebook",
              children: e.jsx(we, {
                className: "h-3.5 w-3.5"
              })
            }),
            e.jsx("button", {
              className: "p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-950 text-neutral-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition-colors",
              onClick: (l) => {
                l.stopPropagation(), ge(t.row.original);
              },
              title: "Delete notebook",
              children: e.jsx(oe, {
                className: "h-3.5 w-3.5"
              })
            })
          ]
        }),
        footer: (t) => t.column.id,
        enableColumnFilter: false,
        enableSorting: false
      }
    ], [
      N,
      s,
      d,
      n,
      xe,
      ge,
      h
    ]), V = r.useMemo(() => {
      const t = (o == null ? void 0 : o.projects) || [], l = t.filter(re), k = t.filter(Ft);
      return {
        mine: l,
        shared: k
      };
    }, [
      o == null ? void 0 : o.projects
    ]), Me = r.useMemo(() => (V[_] || []).filter((l) => !$.statsMap[l.id]).length, [
      V,
      _,
      $.statsMap
    ]), B = r.useMemo(() => {
      const t = _ === "shared" ? V.shared : V.mine, l = d.selectedTagFilter || [];
      return d.showUntagged ? t.filter((k) => (d.notebookTags[k.id] || []).length === 0) : l.length === 0 ? t : t.filter((k) => {
        const E = d.notebookTags[k.id] || [];
        return l.some((me) => E.includes(me));
      });
    }, [
      V,
      _,
      d.selectedTagFilter,
      d.notebookTags,
      d.showUntagged
    ]), he = r.useMemo(() => {
      if (m !== "grid" || !Q.trim())
        return B;
      const t = Q.toLowerCase().trim();
      return B.filter((l) => {
        var _a2;
        return !!(((_a2 = l.title) == null ? void 0 : _a2.toLowerCase().includes(t)) || s.getNotebookTags(l.id).some((E) => E.name.toLowerCase().includes(t)));
      });
    }, [
      B,
      Q,
      m,
      s
    ]), Oe = r.useMemo(() => ((o == null ? void 0 : o.projects) || []).flatMap((t) => (t.sources || []).map((l) => ({
      ...l,
      notebookId: t.id,
      notebookTitle: t.title,
      notebookEmoji: t.emoji
    }))), [
      o == null ? void 0 : o.projects
    ]), Pe = r.useMemo(() => {
      if (!M.trim())
        return [];
      const t = M.toLowerCase().trim();
      return ((o == null ? void 0 : o.projects) || []).filter((l) => {
        var _a2;
        return ((_a2 = l.title) == null ? void 0 : _a2.toLowerCase().includes(t)) ? true : s.getNotebookTags(l.id).some((E) => E.name.toLowerCase().includes(t));
      });
    }, [
      M,
      o == null ? void 0 : o.projects,
      d.notebookTags,
      d.tags,
      s
    ]), H = r.useMemo(() => {
      if (!M.trim())
        return [];
      const t = M.toLowerCase().trim();
      return Oe.filter((l) => {
        var _a2, _b2, _c2;
        return ((_a2 = l.title) == null ? void 0 : _a2.toLowerCase().includes(t)) || ((_b2 = l.url) == null ? void 0 : _b2.toLowerCase().includes(t)) || ((_c2 = l.authorName) == null ? void 0 : _c2.toLowerCase().includes(t));
      });
    }, [
      M,
      Oe
    ]), bt = r.useMemo(() => z === null ? H : H.filter((t) => t.sourceType === z), [
      H,
      z
    ]), pt = r.useMemo(() => {
      const t = {};
      for (const l of H)
        t[l.sourceType] = (t[l.sourceType] || 0) + 1;
      return t;
    }, [
      H
    ]), [X, Ee] = r.useState(null), [ae, De] = r.useState(null), Re = r.useMemo(() => new Map(((o == null ? void 0 : o.projects) || []).map((t) => [
      t.id,
      t
    ])), [
      o == null ? void 0 : o.projects
    ]), kt = r.useCallback((t) => re(Re.get(t.notebookId)), [
      Re
    ]), ft = r.useCallback((t) => {
      Ee(t);
    }, []), jt = r.useCallback((t) => {
      De(t);
    }, []), Nt = r.useCallback(async () => {
      const t = X;
      if (t)
        try {
          await s.deleteSourceNotebookLM(t.id, t.notebookId), await Promise.all([
            s.fetchNotebookLMProjects(),
            s.bulkRemoveFromFolder(t.notebookId, [
              t.id
            ])
          ]), v.success("Source removed"), Z(() => s.isLicensed());
        } catch (l) {
          throw v.error("Failed to remove source"), l;
        }
    }, [
      X,
      s
    ]), vt = r.useCallback(async () => {
      const t = ae;
      if (t)
        try {
          await s.deleteNotebookLMProject(t.id), await s.fetchNotebookLMProjects(), v.success("Notebook deleted"), Z(() => s.isLicensed());
        } catch (l) {
          throw v.error("Failed to delete notebook"), l;
        }
    }, [
      ae,
      s
    ]);
    r.useEffect(() => {
      M ? (sessionStorage.setItem("crossSearchQuery", M), sessionStorage.setItem("crossSearchTab", se), z ? sessionStorage.setItem("crossSourceTypeFilter", z) : sessionStorage.removeItem("crossSourceTypeFilter")) : (sessionStorage.removeItem("crossSearchQuery"), sessionStorage.removeItem("crossSearchTab"), sessionStorage.removeItem("crossSourceTypeFilter"));
    }, [
      M,
      se,
      z
    ]);
    const wt = () => {
      Ie(""), ie("all"), Le(null), sessionStorage.removeItem("crossSearchQuery"), sessionStorage.removeItem("crossSearchTab"), sessionStorage.removeItem("crossSourceTypeFilter");
    }, yt = async (t) => {
      R(true);
      try {
        const l = await s.createNotebookLMProject(t || "");
        await s.fetchNotebookLMProjects(), v.success("Project created"), Z(() => s.isLicensed()), l && x(`/notebook/${l}`);
      } catch {
        v.error("Failed to create project");
      } finally {
        R(false);
      }
    }, Ct = async () => {
      const t = Object.keys(N).filter((k) => N[k]).map((k) => {
        var _a2;
        return (_a2 = o == null ? void 0 : o.projects) == null ? void 0 : _a2.find((E) => E.id === k);
      }).filter(Boolean);
      if (t.length === 0) {
        v.error("No notebooks selected");
        return;
      }
      if (window.confirm(`Delete ${t.length} notebook${t.length > 1 ? "s" : ""}?`)) {
        f(true);
        try {
          await Promise.all(t.map((k) => s.deleteNotebookLMProject(k.id))), await s.fetchNotebookLMProjects(), j({}), v.success(`${t.length} notebook${t.length > 1 ? "s" : ""} deleted`), Z(() => s.isLicensed());
        } catch {
          v.error("Failed to delete notebooks");
        } finally {
          f(false);
        }
      }
    }, _e = Object.values(N).filter(Boolean).length, q = r.useMemo(() => Object.keys(N).filter((t) => N[t]).map((t) => {
      var _a2;
      return (_a2 = o == null ? void 0 : o.projects) == null ? void 0 : _a2.find((l) => l.id === t);
    }).filter(Boolean), [
      N,
      o == null ? void 0 : o.projects
    ]), Ae = q.some((t) => !ve(t)), Fe = q.some((t) => !re(t)), St = Ae ? "Selection includes notebooks you cannot delete (only owner can delete)" : void 0, Tt = Fe ? "Selection includes viewer notebooks (read-only)" : void 0, $e = r.useMemo(() => !rs(q), [
      q
    ]), It = $e ? "Selection has no Google Drive sources to sync" : void 0, Lt = () => {
      const t = B;
      if (!(t == null ? void 0 : t.length))
        return;
      const l = (A) => `"${String(A ?? "").replace(/"/g, '""')}"`, k = [
        "Title",
        "Role",
        "Tags",
        "Sources",
        "Updated",
        "Created",
        "Total Outputs",
        "Audio",
        "Reports",
        "Videos",
        "Quizzes",
        "Flashcards",
        "Mind Maps",
        "Slide Decks",
        "Notes"
      ], E = t.map((A) => {
        var _a2, _b2;
        const Et = s.getNotebookTags(A.id).map((Dt) => Dt.name).join(", "), F = (_a2 = $.statsMap) == null ? void 0 : _a2[A.id];
        return [
          l(A.title),
          l(vs[A.permissionCode] || "Unknown"),
          l(Et),
          ((_b2 = A.sources) == null ? void 0 : _b2.length) ?? 0,
          l(A.updatedAt),
          l(A.createdAt),
          (F == null ? void 0 : F.total) ?? "",
          (F == null ? void 0 : F[1]) ?? "",
          (F == null ? void 0 : F[2]) ?? "",
          (F == null ? void 0 : F[3]) ?? "",
          (F == null ? void 0 : F[10]) ?? "",
          (F == null ? void 0 : F[11]) ?? "",
          (F == null ? void 0 : F[5]) ?? "",
          (F == null ? void 0 : F[8]) ?? "",
          (F == null ? void 0 : F[12]) ?? ""
        ].join(",");
      }), me = [
        k.join(","),
        ...E
      ].join(`
`), Pt = new Blob([
        me
      ], {
        type: "text/csv"
      }), ze = URL.createObjectURL(Pt), be = document.createElement("a");
      be.href = ze, be.download = `notebook-overview-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`, be.click(), URL.revokeObjectURL(ze), v.success(`Exported ${t.length} notebooks to CSV`), Z(() => s.isLicensed());
    }, Be = (t) => {
      W(t), localStorage.setItem("YT_NOTEBOOKLM_TOOLS_VIEW_MODE", t), j({}), te("");
    }, Ue = (t) => {
      ct(t), localStorage.setItem(qe, t), j({}), te("");
    }, Mt = async () => {
      f(true);
      try {
        await s.fetchNotebookLMProjects(), v.success("Projects refreshed");
      } catch {
        v.error("Failed to refresh projects");
      } finally {
        f(false);
      }
    }, Ot = async () => {
      try {
        await s.scanAllStats({
          role: _
        }), v.success(_ === "shared" ? "Shared outputs scanned" : "My outputs scanned");
      } catch {
        v.error("Failed to scan outputs");
      }
    };
    return e.jsxs(Zt, {
      children: [
        e.jsx(Gt, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "NotebookLM"
          })
        }),
        e.jsxs("div", {
          className: "flex flex-col gap-4",
          children: [
            e.jsx(Yt, {}),
            s.isNotebookLMAuthenticated() && e.jsx(ks, {
              query: M,
              setQuery: Ie,
              activeTab: se,
              setActiveTab: ie,
              notebookCount: Pe.length,
              sourceCount: H.length,
              totalNotebooks: ((_b = o == null ? void 0 : o.projects) == null ? void 0 : _b.length) || 0,
              onClose: wt
            }),
            !M.trim() && e.jsxs("div", {
              className: "flex items-center gap-1 border-b border-neutral-200 dark:border-slate-700",
              children: [
                e.jsxs("button", {
                  onClick: () => Ue("mine"),
                  className: Y("px-3 py-1.5 text-xs font-medium border-b-2 -mb-px", _ === "mine" ? "border-neutral-900 dark:border-slate-200 text-neutral-900 dark:text-slate-100" : "border-transparent text-neutral-500 dark:text-slate-400 hover:text-neutral-700 dark:hover:text-slate-200"),
                  children: [
                    "My Notebooks",
                    e.jsxs("span", {
                      className: "ml-1 text-neutral-400 dark:text-slate-500",
                      children: [
                        "(",
                        V.mine.length,
                        ")"
                      ]
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: () => Ue("shared"),
                  className: Y("px-3 py-1.5 text-xs font-medium border-b-2 -mb-px", _ === "shared" ? "border-neutral-900 dark:border-slate-200 text-neutral-900 dark:text-slate-100" : "border-transparent text-neutral-500 dark:text-slate-400 hover:text-neutral-700 dark:hover:text-slate-200"),
                  children: [
                    "Shared with me",
                    e.jsxs("span", {
                      className: "ml-1 text-neutral-400 dark:text-slate-500",
                      children: [
                        "(",
                        V.shared.length,
                        ")"
                      ]
                    })
                  ]
                })
              ]
            }),
            !M.trim() && e.jsxs("div", {
              className: "flex items-start justify-between gap-4",
              children: [
                e.jsxs("div", {
                  className: "flex-1 min-w-0",
                  children: [
                    e.jsx("h1", {
                      className: "text-sm font-medium text-neutral-900 dark:text-slate-100",
                      children: "Manage Notebooks"
                    }),
                    e.jsx("p", {
                      className: "text-xs text-neutral-500 dark:text-slate-400 mt-1",
                      children: d.showUntagged ? `${B.length} untagged of ${((_c = o == null ? void 0 : o.projects) == null ? void 0 : _c.length) || 0} notebooks` : ((_d = d.selectedTagFilter) == null ? void 0 : _d.length) > 0 ? `${B.length} of ${((_e2 = o == null ? void 0 : o.projects) == null ? void 0 : _e2.length) || 0} notebooks` : `${((_f = o == null ? void 0 : o.projects) == null ? void 0 : _f.length) || 0} notebook${((_g = o == null ? void 0 : o.projects) == null ? void 0 : _g.length) !== 1 ? "s" : ""}`
                    }),
                    d.showUntagged && e.jsx("button", {
                      onClick: () => s.setShowUntagged(false),
                      className: "text-xs text-neutral-600 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-200 underline mt-1",
                      children: "Clear untagged filter"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2 flex-shrink-0",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center border border-neutral-300 dark:border-slate-600 rounded-md overflow-hidden",
                      children: [
                        e.jsx("button", {
                          onClick: () => Be("table"),
                          className: `p-1.5 transition-colors ${m === "table" ? "bg-neutral-900 dark:bg-gray-100 text-white dark:text-gray-900" : "bg-white dark:bg-slate-800 text-neutral-500 dark:text-slate-400 hover:text-neutral-700 dark:hover:text-slate-300"}`,
                          title: "Table view",
                          children: e.jsx($t, {
                            className: "w-3.5 h-3.5"
                          })
                        }),
                        e.jsx("button", {
                          onClick: () => Be("grid"),
                          className: `p-1.5 transition-colors ${m === "grid" ? "bg-neutral-900 dark:bg-gray-100 text-white dark:text-gray-900" : "bg-white dark:bg-slate-800 text-neutral-500 dark:text-slate-400 hover:text-neutral-700 dark:hover:text-slate-300"}`,
                          title: "Grid view",
                          children: e.jsx(Kt, {
                            className: "w-3.5 h-3.5"
                          })
                        })
                      ]
                    }),
                    e.jsx(gs, {}),
                    e.jsxs("div", {
                      className: "flex items-center border border-neutral-300 dark:border-slate-600 rounded-md overflow-hidden shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx("a", {
                          href: "#/tags",
                          className: "px-2 py-1.5 flex items-center gap-1 text-xs font-medium bg-white dark:bg-slate-800 text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-700",
                          title: "Manage tags",
                          children: e.jsx(Ne, {
                            className: "w-3.5 h-3.5"
                          })
                        }),
                        e.jsxs("button", {
                          onClick: Ot,
                          disabled: $.isScanning,
                          className: "px-2 py-1.5 flex items-center gap-1 text-xs font-medium bg-white dark:bg-slate-800 text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-50 border-l border-neutral-300 dark:border-slate-600",
                          title: `Scan ${_ === "shared" ? "shared" : "my"} notebooks to count generated outputs`,
                          children: [
                            e.jsx(is, {
                              className: "w-3.5 h-3.5"
                            }),
                            $.isScanning ? e.jsxs("span", {
                              className: "text-[10px]",
                              children: [
                                $.scanProgress.current,
                                "/",
                                $.scanProgress.total
                              ]
                            }) : Me > 0 && e.jsx("span", {
                              className: "px-1 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300 text-[10px] font-medium leading-none",
                              children: Me
                            })
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex items-center border border-neutral-300 dark:border-slate-600 rounded-md overflow-hidden shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsxs("button", {
                          onClick: Lt,
                          className: "px-2 py-1.5 flex items-center gap-1 text-xs font-medium bg-white dark:bg-slate-800 text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-700",
                          title: "Export notebook overview as spreadsheet",
                          children: [
                            e.jsx(Ye, {
                              className: "w-3.5 h-3.5"
                            }),
                            e.jsx("span", {
                              children: "Export"
                            })
                          ]
                        }),
                        e.jsx("button", {
                          onClick: () => {
                            D("import"), y(true);
                          },
                          className: "px-2 py-1.5 flex items-center gap-1 text-xs font-medium bg-white dark:bg-slate-800 text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 hover:bg-neutral-50 dark:hover:bg-slate-700 border-l border-neutral-300 dark:border-slate-600",
                          title: "Import notebooks",
                          children: e.jsx(os, {
                            className: "w-3.5 h-3.5"
                          })
                        })
                      ]
                    }),
                    e.jsx("button", {
                      onClick: Mt,
                      disabled: b,
                      className: "p-1.5 text-neutral-600 dark:text-slate-400 bg-white dark:bg-slate-800 border border-neutral-300 dark:border-slate-600 rounded-md hover:bg-neutral-50 dark:hover:bg-slate-700 hover:text-neutral-900 dark:hover:text-slate-100 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                      title: "Refresh notebooks",
                      children: e.jsx(Qe, {
                        className: "w-3.5 h-3.5"
                      })
                    }),
                    e.jsxs("button", {
                      onClick: () => C(true),
                      disabled: b,
                      className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-white dark:text-gray-900 bg-neutral-900 dark:bg-gray-100 rounded-md hover:bg-neutral-800 dark:hover:bg-gray-200 disabled:opacity-50 transition-colors shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(He, {
                          className: "w-3.5 h-3.5"
                        }),
                        e.jsx("span", {
                          className: "hidden sm:inline",
                          children: "New"
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            !M.trim() && _e > 0 && e.jsxs("div", {
              className: "flex items-center justify-between bg-neutral-50 dark:bg-slate-900 border border-neutral-200 dark:border-slate-700 rounded-lg p-2 px-3 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("div", {
                      className: "flex items-center justify-center w-5 h-5 rounded-full bg-neutral-200 dark:bg-slate-700",
                      children: e.jsx("span", {
                        className: "text-xs font-medium text-neutral-700 dark:text-slate-300",
                        children: _e
                      })
                    }),
                    e.jsx("span", {
                      className: "text-xs text-neutral-600 dark:text-slate-400",
                      children: "selected"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("button", {
                      onClick: () => j({}),
                      className: "px-2.5 py-1 text-xs font-medium text-neutral-600 dark:text-slate-400 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 transition-colors shadow-sm dark:shadow-slate-900/30",
                      children: "Clear"
                    }),
                    e.jsxs("button", {
                      onClick: () => xt(q),
                      disabled: b || Fe,
                      title: Tt,
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(we, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Rename"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => w(true),
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 transition-colors shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(Ne, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Assign Tag"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => {
                        D("export"), y(true);
                      },
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 transition-colors shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(Ye, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Export"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: () => c(true),
                      disabled: $e,
                      title: It,
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-neutral-300 dark:border-slate-600 hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(Qe, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Sync sources"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: Ct,
                      disabled: b || Ae,
                      title: St,
                      className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 transition-colors shadow-sm dark:shadow-slate-900/30",
                      children: [
                        e.jsx(oe, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Delete"
                      ]
                    })
                  ]
                })
              ]
            }),
            M.trim() && s.isNotebookLMAuthenticated() && e.jsx(js, {
              activeTab: se,
              notebookResults: Pe,
              sourceResults: bt,
              query: M,
              sourceTypeFilter: z,
              setSourceTypeFilter: Le,
              sourceTypeCounts: pt,
              onTabChange: ie,
              authuser: h,
              onDeleteSource: ft,
              onDeleteNotebook: jt,
              canDeleteSource: kt,
              canDeleteNotebook: ve,
              sourceDisabledReason: "You don't have edit access to this notebook",
              notebookDisabledReason: "Only the owner can delete this notebook"
            }),
            !M.trim() && s.isNotebookLMAuthenticated() ? e.jsx(e.Fragment, {
              children: b ? e.jsx("div", {
                className: "flex flex-col items-center justify-center w-full py-12 bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 border-dashed",
                children: e.jsx(as, {
                  text: "Loading notebooks..."
                })
              }) : B.length > 0 ? m === "table" ? e.jsx(us, {
                columns: mt,
                data: B,
                enableRowSelection: true,
                onRowSelectionChange: j,
                rowSelection: N
              }) : e.jsxs(e.Fragment, {
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsxs("div", {
                        className: "relative flex-1 max-w-xs",
                        children: [
                          e.jsx(Se, {
                            className: "absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400 dark:text-slate-500"
                          }),
                          e.jsx("input", {
                            type: "text",
                            value: Q,
                            onChange: (t) => te(t.target.value),
                            placeholder: "Search notebooks...",
                            className: "w-full pl-8 pr-8 py-1.5 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100"
                          }),
                          Q && e.jsx("button", {
                            onClick: () => te(""),
                            className: "absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-slate-500 hover:text-neutral-600 dark:hover:text-slate-300",
                            children: e.jsx(le, {
                              className: "h-3.5 w-3.5"
                            })
                          })
                        ]
                      }),
                      Q && e.jsxs("span", {
                        className: "text-xs text-neutral-500 dark:text-slate-400",
                        children: [
                          he.length,
                          " result",
                          he.length !== 1 ? "s" : ""
                        ]
                      })
                    ]
                  }),
                  e.jsx(bs, {
                    data: he,
                    selectedRows: N,
                    onRowSelectionChange: j,
                    onDelete: ge,
                    onRename: xe
                  })
                ]
              }) : ((_h = o == null ? void 0 : o.projects) == null ? void 0 : _h.length) > 0 ? e.jsxs("div", {
                className: "flex flex-col items-center justify-center py-12 bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 border-dashed",
                children: [
                  e.jsx("div", {
                    className: "p-3 bg-neutral-50 dark:bg-slate-900 rounded-full mb-3",
                    children: e.jsx(Ne, {
                      className: "h-5 w-5 text-neutral-400 dark:text-slate-500"
                    })
                  }),
                  e.jsx("h3", {
                    className: "text-xs font-medium text-neutral-900 dark:text-slate-100",
                    children: d.showUntagged ? "All notebooks are tagged" : `No notebooks match ${((_i = d.selectedTagFilter) == null ? void 0 : _i.length) > 1 ? "these tags" : "this tag"}`
                  }),
                  e.jsx("p", {
                    className: "mt-1 text-xs text-neutral-500 dark:text-slate-400 mb-3",
                    children: d.showUntagged ? "Great job organizing your notebooks!" : "Clear the filter to see all notebooks"
                  }),
                  e.jsx("button", {
                    onClick: () => {
                      s.clearAllFilters();
                    },
                    className: "text-xs font-medium text-neutral-600 dark:text-slate-400 hover:text-neutral-800 dark:hover:text-slate-200 underline",
                    children: "Clear filter"
                  })
                ]
              }) : e.jsxs("div", {
                className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-neutral-200 dark:border-slate-700 border-dashed",
                children: [
                  e.jsx("div", {
                    className: "p-3 bg-neutral-50 dark:bg-slate-900 rounded-full mb-3",
                    children: e.jsx(ye, {
                      className: "h-6 w-6 text-neutral-400 dark:text-slate-500"
                    })
                  }),
                  e.jsx("h3", {
                    className: "text-xs font-medium text-neutral-900 dark:text-slate-100",
                    children: "No notebooks yet"
                  }),
                  e.jsx("p", {
                    className: "mt-1 text-xs text-neutral-500 dark:text-slate-400 max-w-[250px] text-center mb-4",
                    children: "Create your first notebook to start organizing your knowledge."
                  }),
                  e.jsxs("button", {
                    onClick: () => C(true),
                    className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white dark:text-gray-900 bg-neutral-900 dark:bg-gray-100 rounded-md hover:bg-neutral-800 dark:hover:bg-gray-200 transition-colors shadow-sm dark:shadow-slate-900/30",
                    children: [
                      e.jsx(He, {
                        className: "w-3.5 h-3.5"
                      }),
                      "Create Notebook"
                    ]
                  })
                ]
              })
            }) : null
          ]
        }),
        e.jsxs(r.Suspense, {
          fallback: null,
          children: [
            ce && e.jsx(ys, {
              isOpen: !!ce,
              onClose: gt,
              onConfirm: ut,
              items: ce,
              itemLabel: "notebook"
            }),
            p && e.jsx(ws, {
              isOpen: p,
              onClose: () => C(false),
              onSubmit: yt,
              isLoading: I
            }),
            S && e.jsx(Cs, {
              isOpen: S,
              onClose: () => w(false),
              selectedNotebookIds: Object.keys(N).filter((t) => N[t]),
              onSuccess: (t, l, k) => {
                v.success(k === "add" ? `Added ${l} tag${l > 1 ? "s" : ""} to ${t} notebook${t > 1 ? "s" : ""}` : `Set ${l} tag${l > 1 ? "s" : ""} on ${t} notebook${t > 1 ? "s" : ""}`), j({});
              }
            }),
            u && T === "export" && e.jsx(Ss, {
              isOpen: u,
              onClose: () => y(false),
              selectedNotebookIds: Object.keys(N).filter((t) => N[t]),
              notebooks: (o == null ? void 0 : o.projects) || [],
              onExportSuccess: (t) => {
                v.success(`Exported ${t} notebook${t !== 1 ? "s" : ""}`);
              }
            }),
            u && T === "import" && e.jsx(Ts, {
              isOpen: u,
              onClose: () => y(false),
              onImportSuccess: async (t) => {
                v.success(`Imported ${t} notebook${t !== 1 ? "s" : ""}`), await s.fetchNotebookLMProjects(), y(false);
              }
            }),
            L && e.jsx(Is, {
              isOpen: L,
              onClose: () => c(false),
              selectedNotebookIds: Object.keys(N).filter((t) => N[t]),
              notebooks: (o == null ? void 0 : o.projects) || []
            })
          ]
        }),
        e.jsx(ss, {
          isOpen: !!X,
          onClose: () => Ee(null),
          onConfirm: Nt,
          sources: X ? [
            X
          ] : []
        }),
        e.jsx(Ns, {
          isOpen: !!ae,
          onClose: () => De(null),
          onConfirm: vt,
          notebook: ae
        })
      ]
    });
  };
});
export {
  __tla,
  Ys as default
};
