import { r as n, j as e, u as H, d as V, c as O, O as B, L as _, A as J, H as Z, G as ee, S as te, l as se, aj as ae, ak as G, p as re, U as le, al as ne, am as oe, X as ce, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { aN as de, x as F, aO as Y, ac as U, a5 as ie, aP as M, aQ as xe, aR as D } from "./chunk-68adfa56.js";
import { f as Q, ak as ue, al as be, a6 as ge, i as me, z as he, Q as pe, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { S as fe, __tla as __tla_2 } from "./chunk-4c77bdf2.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
import { __tla as __tla_3 } from "./chunk-95b0b380.js";
let Ge;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  function ke(l) {
    const [t, r] = n.useState(null), s = n.useMemo(() => (l == null ? void 0 : l.map((c) => c.id)) || [], [
      l
    ]), g = t || s, a = s.length === 0, o = n.useMemo(() => new Set(s), [
      s
    ]), u = n.useCallback((c) => {
      r((d) => {
        const x = d || s, i = new Set(x);
        return i.has(c) ? i.delete(c) : i.add(c), i.size === o.size ? null : [
          ...i
        ];
      });
    }, [
      s,
      o
    ]), b = n.useCallback((c) => {
      r(c ? null : []);
    }, []), h = n.useCallback((c) => {
      c && r(c);
    }, []);
    return {
      sourceIds: s,
      activeSourceIds: g,
      hasNoSources: a,
      handleSourceToggle: u,
      handleSelectAll: b,
      syncFromGlobal: h
    };
  }
  function ye({ label: l, value: t, options: r, onChange: s, disabled: g }) {
    return e.jsxs("div", {
      className: "flex items-center gap-2",
      children: [
        l && e.jsx("span", {
          className: "text-xs text-gray-500 dark:text-slate-400 shrink-0 min-w-[3rem]",
          children: l
        }),
        e.jsx("div", {
          className: "flex gap-1 flex-wrap",
          children: (r || []).map((a) => {
            const o = a.value === t;
            return e.jsx("button", {
              type: "button",
              onClick: () => s(a.value),
              disabled: g,
              className: `px-2.5 py-1 text-xs rounded border focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed ${o ? "bg-blue-600 border-blue-600 text-white font-medium" : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-blue-500"}`,
              children: a.label
            }, a.value);
          })
        })
      ]
    });
  }
  function je({ label: l, value: t, options: r, onChange: s, disabled: g }) {
    const a = n.useId();
    return e.jsxs("div", {
      children: [
        l && e.jsx("label", {
          htmlFor: a,
          className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
          children: l
        }),
        e.jsx("select", {
          id: a,
          value: t ?? "",
          onChange: (o) => s(o.target.value),
          disabled: g,
          className: "w-full rounded-md border border-gray-300 dark:border-gray-600 dark:bg-slate-700 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs px-2.5 py-1.5 disabled:opacity-50",
          children: (r || []).map((o) => e.jsx("option", {
            value: o.value,
            children: o.label
          }, o.value))
        })
      ]
    });
  }
  function X({ opt: l, value: t, onChange: r, disabled: s }) {
    return l.options.length < de ? e.jsx(ye, {
      label: l.label,
      value: t,
      options: l.options,
      onChange: r,
      disabled: s
    }) : e.jsx(je, {
      label: l.label,
      value: t,
      options: l.options,
      onChange: r,
      disabled: s
    });
  }
  function Ne({ notebookId: l, sourceIds: t, onPick: r, disabled: s }) {
    const [, g] = H(), [a, o] = n.useState([]), [u, b] = n.useState(false), [h, c] = n.useState(false), d = !t || t.length === 0, x = async () => {
      if (u || s)
        return;
      b(true);
      const i = await g.suggestShortVideoIdeas(l, t);
      o(i || []), c(true), b(false);
    };
    return e.jsxs("div", {
      children: [
        e.jsxs("div", {
          className: "flex items-center justify-between mb-1",
          children: [
            e.jsx("p", {
              className: "text-xs font-medium text-gray-700 dark:text-slate-300",
              children: "Ideas"
            }),
            e.jsxs("button", {
              type: "button",
              onClick: x,
              disabled: s || u || d,
              className: "flex items-center gap-1 px-2 py-0.5 text-xs rounded border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 hover:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed",
              children: [
                e.jsx(V, {
                  className: "w-3 h-3"
                }),
                u ? "Loading..." : h ? "Refresh" : "Suggest ideas"
              ]
            })
          ]
        }),
        d && e.jsx("p", {
          className: "text-xs text-gray-400 dark:text-slate-500",
          children: "Select a source to get ideas"
        }),
        !d && h && !u && a.length === 0 && e.jsx("p", {
          className: "text-xs text-gray-400 dark:text-slate-500",
          children: "No ideas found \u2014 try again"
        }),
        a.length > 0 && e.jsx("div", {
          className: "flex flex-col gap-1",
          children: a.map((i, y) => e.jsxs("button", {
            type: "button",
            onClick: () => r(i.prompt || i.title),
            disabled: s,
            title: i.prompt,
            className: "text-left px-2.5 py-1.5 text-xs rounded border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 hover:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
            children: [
              e.jsx("span", {
                className: "font-medium block truncate",
                children: i.title || i.prompt
              }),
              i.prompt && i.title && e.jsx("span", {
                className: "text-gray-400 dark:text-slate-500 block truncate",
                children: i.prompt
              })
            ]
          }, y))
        })
      ]
    });
  }
  const R = 50, ve = n.memo(function({ sources: t, activeSourceIds: r, onSourceToggle: s, onSelectAll: g, disabled: a = false }) {
    const [o, u] = n.useState(false), b = () => u((k) => !k), h = (t == null ? void 0 : t.length) || 0, c = r.length, d = c === h, [x, i] = n.useState(R), y = n.useMemo(() => new Set(r), [
      r
    ]), f = n.useRef(null), p = n.useRef(t);
    p.current !== t && (f.current = null, p.current = t), !f.current && (r == null ? void 0 : r.length) && (f.current = new Set(r)), n.useEffect(() => {
      i(R);
    }, [
      t
    ]);
    const v = f.current, j = n.useMemo(() => t ? !v || v.size === 0 ? t : [
      ...t
    ].sort((k, T) => {
      const N = v.has(k.id), w = v.has(T.id);
      return N !== w ? N ? -1 : 1 : 0;
    }) : [], [
      t,
      v
    ]);
    return e.jsxs("div", {
      className: "mb-2",
      children: [
        e.jsxs("button", {
          onClick: b,
          className: O("flex items-center justify-between w-full px-2.5 py-1.5 text-xs rounded-md", c === 0 ? "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" : "text-gray-700 dark:text-slate-300 bg-gray-50 dark:bg-slate-900"),
          "aria-expanded": o,
          children: [
            e.jsxs("span", {
              className: "flex items-center gap-1.5",
              children: [
                e.jsx("span", {
                  children: "Sources:"
                }),
                e.jsxs("span", {
                  className: "font-medium",
                  children: [
                    d ? "All" : c,
                    "/",
                    h
                  ]
                })
              ]
            }),
            e.jsx(Q, {
              className: O("w-3 h-3", o && "rotate-180")
            })
          ]
        }),
        o && e.jsxs("div", {
          className: "mt-1 border border-gray-200 dark:border-slate-700 rounded-md overflow-hidden",
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between px-2.5 py-1.5 bg-gray-50 dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700",
              children: [
                e.jsx("button", {
                  onClick: () => g(!d),
                  disabled: a,
                  className: "text-xs text-blue-600 dark:text-blue-400 hover:underline disabled:opacity-50 disabled:cursor-not-allowed",
                  children: d ? "Deselect all" : "Select all"
                }),
                e.jsxs("span", {
                  className: "text-xs text-gray-400 dark:text-slate-400",
                  children: [
                    c,
                    " selected"
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "max-h-48 overflow-y-auto",
              children: [
                j.slice(0, x).map((k) => {
                  const T = y.has(k.id);
                  return e.jsxs("label", {
                    className: O("flex items-center gap-2 px-2.5 py-1.5 cursor-pointer", T ? "bg-blue-50/50 dark:bg-blue-950/30 hover:bg-blue-50 dark:hover:bg-blue-950/50" : "hover:bg-gray-50 dark:hover:bg-slate-700/50 text-gray-400 dark:text-slate-500"),
                    children: [
                      e.jsx("input", {
                        type: "checkbox",
                        checked: T,
                        onChange: () => s(k.id),
                        disabled: a,
                        className: "rounded border-gray-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5 flex-shrink-0 disabled:opacity-50"
                      }),
                      e.jsx(fe, {
                        sourceType: k.sourceType
                      }),
                      e.jsx("span", {
                        className: "text-xs text-gray-700 dark:text-slate-300 truncate min-w-0",
                        children: k.title || k.id
                      })
                    ]
                  }, k.id);
                }),
                j.length > x && e.jsxs("button", {
                  onClick: () => i((k) => k + R),
                  className: "w-full px-2.5 py-1.5 text-xs text-blue-600 dark:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-700/50 text-center",
                  children: [
                    "Show more (",
                    j.length - x,
                    " remaining)"
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  });
  function Se(l, t) {
    return !l.length || !t ? null : l.map((r) => {
      var _a;
      const s = t[r.key];
      return (_a = r.options.find((a) => a.value === s)) == null ? void 0 : _a.label;
    }).filter(Boolean).join(" \xB7 ");
  }
  function we({ selectedTypes: l, optionsMap: t, onOptionChange: r, isGenerating: s }) {
    const [g, a] = n.useState(/* @__PURE__ */ new Set()), o = n.useCallback((b) => {
      a((h) => B(h, b));
    }, []), u = [
      ...l
    ];
    return e.jsx("div", {
      className: "space-y-1.5",
      children: u.map((b) => {
        const h = J[b], c = Y[b] || [], d = c.length > 0, x = g.has(b), i = x ? null : Se(c, t[b]);
        return d ? e.jsxs("div", {
          children: [
            e.jsxs("button", {
              type: "button",
              onClick: () => o(b),
              disabled: s,
              className: "flex items-center justify-between w-full px-2.5 py-1.5 text-xs rounded-md text-gray-700 dark:text-slate-300 bg-gray-50 dark:bg-slate-900 disabled:opacity-50",
              children: [
                e.jsxs("span", {
                  className: "flex items-center gap-1.5 min-w-0",
                  children: [
                    h && e.jsx(h, {
                      className: O("w-3 h-3 shrink-0", _[b])
                    }),
                    e.jsx("span", {
                      className: "font-medium",
                      children: F[b]
                    }),
                    i && e.jsx("span", {
                      className: "text-gray-400 dark:text-slate-500 truncate",
                      children: i
                    })
                  ]
                }),
                e.jsx(Q, {
                  className: O("w-3 h-3 shrink-0", x && "rotate-180")
                })
              ]
            }),
            x && e.jsx("div", {
              className: "mt-1 border border-gray-200 dark:border-slate-700 rounded-md overflow-hidden",
              children: e.jsx("div", {
                className: "px-2.5 py-2 space-y-2",
                children: c.map((y) => {
                  var _a;
                  return e.jsx(X, {
                    opt: y,
                    value: (_a = t[b]) == null ? void 0 : _a[y.key],
                    onChange: (f) => r(b, y.key, f),
                    disabled: s
                  }, y.key);
                })
              })
            })
          ]
        }, b) : e.jsxs("div", {
          className: "flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-md bg-gray-50 dark:bg-slate-900 text-gray-700 dark:text-slate-300",
          children: [
            h && e.jsx(h, {
              className: O("w-3 h-3", _[b])
            }),
            e.jsx("span", {
              children: F[b]
            })
          ]
        }, b);
      })
    });
  }
  const Te = se.outputLanguages;
  function Ce({ instructions: l, onInstructionsChange: t, isGenerating: r }) {
    return e.jsxs("div", {
      children: [
        e.jsxs("p", {
          className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
          children: [
            "Instructions",
            " ",
            e.jsx("span", {
              className: "font-normal text-gray-400 dark:text-slate-500",
              children: "(optional)"
            })
          ]
        }),
        e.jsx("textarea", {
          value: l,
          onChange: (s) => t(s.target.value),
          maxLength: M,
          rows: 2,
          placeholder: "Optional focus or instructions...",
          "aria-label": "Optional focus or instructions",
          disabled: r,
          className: "w-full border rounded-md border-gray-300 dark:border-gray-600 dark:bg-slate-700 dark:text-slate-100 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-xs px-2.5 py-1.5 disabled:opacity-50 resize-none"
        }),
        e.jsxs("p", {
          className: O("text-xs mt-0.5", l.length >= xe ? "text-amber-600 dark:text-amber-400" : "text-gray-400 dark:text-slate-500"),
          children: [
            l.length,
            "/",
            M
          ]
        })
      ]
    });
  }
  function Ae({ outputLanguage: l, overrideLanguage: t, outputFavorites: r, onChange: s, disabled: g }) {
    var _a;
    const [a, o] = n.useState(false), u = t ?? l ?? "en", h = ((_a = Z(u, ae.OUTPUT)) == null ? void 0 : _a.name) ?? u, c = (r || []).slice(0, 3), d = u && !c.some((x) => x.code === u) && c.length > 0;
    return e.jsxs("div", {
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("span", {
              className: "text-xs text-gray-500 dark:text-slate-400 shrink-0",
              children: "Language"
            }),
            e.jsxs("div", {
              className: "flex items-center gap-1 flex-wrap",
              children: [
                d && e.jsx("button", {
                  type: "button",
                  onClick: () => s(null),
                  disabled: g,
                  className: "px-2.5 py-1 text-xs rounded border bg-blue-600 border-blue-600 text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed",
                  children: u.toUpperCase()
                }),
                c.map((x) => {
                  const i = x.code === u;
                  return e.jsx("button", {
                    type: "button",
                    onClick: () => s(i ? null : x.code),
                    disabled: g,
                    className: O("px-2.5 py-1 text-xs rounded border disabled:opacity-50 disabled:cursor-not-allowed", i ? "bg-blue-600 border-blue-600 text-white font-medium" : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-blue-500"),
                    children: (x.code || "DEFAULT").toUpperCase()
                  }, x.code || "default");
                }),
                c.length === 0 && !d && e.jsx("span", {
                  className: "text-xs text-gray-400 dark:text-slate-500",
                  children: h
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => o((x) => !x),
                  disabled: g,
                  className: "p-1 rounded text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                  title: "More languages",
                  children: e.jsx(ee, {
                    className: "w-3.5 h-3.5"
                  })
                })
              ]
            })
          ]
        }),
        a && e.jsx("div", {
          className: "mt-1.5",
          children: e.jsx(ge, {
            languages: Te,
            value: u,
            label: null,
            favoriteKey: te.OUTPUT_FAVORITES,
            onSelect: (x) => {
              s(x), o(false);
            }
          })
        }),
        t && e.jsxs("p", {
          className: "mt-1 text-xs text-gray-400 dark:text-slate-500",
          children: [
            "Using ",
            h,
            " for this generation",
            " ",
            e.jsx("button", {
              type: "button",
              onClick: () => s(null),
              className: "text-blue-600 dark:text-blue-400 hover:underline",
              children: "reset"
            })
          ]
        })
      ]
    });
  }
  function Oe({ notebookId: l, selectedTypes: t, onTypeToggle: r, optionsMap: s, onOptionChange: g, instructions: a, onInstructionsChange: o, overrideLanguage: u, onOverrideLanguageChange: b, outputLanguage: h, outputFavorites: c, sources: d, activeSourceIds: x, onSourceToggle: i, onSelectAll: y, isGenerating: f }) {
    var _a;
    const p = t.size === 1 ? t.values().next().value : null, v = p === U.MIND_MAP, j = p === U.VIDEO ? (_a = s[p]) == null ? void 0 : _a.format : null, k = j === D.SHORT, T = (p ? Y[p] || [] : []).filter((C) => C.key !== "style" || !k), N = p ? !ie.includes(p) : t.size > 1, w = j === D.CINEMATIC;
    return e.jsxs(e.Fragment, {
      children: [
        e.jsx("p", {
          className: "text-xs text-gray-400 dark:text-slate-400 mb-2",
          children: "Select one or more types to generate"
        }),
        e.jsx("div", {
          className: "mb-3",
          children: e.jsx(ue, {
            selectedTypes: t,
            onTypeToggle: r
          })
        }),
        t.size > 1 && e.jsx("div", {
          className: "mb-2 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded p-2 text-xs text-amber-700 dark:text-amber-200",
          children: "Batch \u2014 customize each type below"
        }),
        t.size > 0 && e.jsxs(e.Fragment, {
          children: [
            e.jsx(ve, {
              sources: d,
              activeSourceIds: x,
              onSourceToggle: i,
              onSelectAll: y,
              disabled: f
            }),
            e.jsxs("div", {
              className: "space-y-3",
              children: [
                p && !v && T.length > 0 && e.jsxs("div", {
                  children: [
                    e.jsx("p", {
                      className: "text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                      children: "Options"
                    }),
                    e.jsx("div", {
                      className: "space-y-2",
                      children: T.map((C) => {
                        var _a2;
                        return e.jsx(X, {
                          opt: C,
                          value: (_a2 = s[p]) == null ? void 0 : _a2[C.key],
                          onChange: (I) => g(p, C.key, I),
                          disabled: f
                        }, C.key);
                      })
                    })
                  ]
                }),
                w && e.jsx("div", {
                  className: "bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded p-2 text-xs text-amber-700 dark:text-amber-200",
                  children: "Cinematic requires AI Ultra subscription"
                }),
                k && e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("p", {
                      className: "text-xs text-gray-400 dark:text-slate-400",
                      children: "60-second vertical video \xB7 one concept per short"
                    }),
                    e.jsx(Ne, {
                      notebookId: l,
                      sourceIds: x,
                      onPick: o,
                      disabled: f
                    })
                  ]
                }),
                t.size > 1 && e.jsx(we, {
                  selectedTypes: t,
                  optionsMap: s,
                  onOptionChange: g,
                  isGenerating: f
                }),
                N && e.jsx(Ae, {
                  outputLanguage: h,
                  overrideLanguage: u,
                  outputFavorites: c,
                  onChange: b,
                  disabled: f
                }),
                e.jsx(Ce, {
                  instructions: a,
                  onInstructionsChange: o,
                  isGenerating: f
                }),
                v && e.jsx("p", {
                  className: "text-xs text-gray-400 dark:text-slate-400",
                  children: "Mind Maps save as Notes, not Studio items"
                }),
                t.size > 1 && e.jsx(be, {
                  steps: [
                    ...t
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  }
  Ge = function({ isOpen: l, onClose: t, notebookId: r, sources: s }) {
    const [g, a] = H(), { studioGeneration: o } = g, { isGenerating: u } = o, { outputLanguage: b, outputFavorites: h } = g.languageSettings;
    n.useEffect(() => {
      a.loadOutputLanguage(), a.loadOutputFavorites();
    }, []);
    const c = a.isLicensed(), [d, x] = n.useState(/* @__PURE__ */ new Set()), i = n.useRef(d);
    i.current = d;
    const [y, f] = n.useState({}), [p, v] = n.useState(""), [j, k] = n.useState(null), { sourceIds: T, activeSourceIds: N, hasNoSources: w, handleSourceToggle: C, handleSelectAll: I, syncFromGlobal: z } = ke(s);
    n.useEffect(() => {
      o.selectedSourceIds && (z(o.selectedSourceIds), a.setSelectedSourceIds(null));
    }, [
      o.selectedSourceIds,
      z,
      a
    ]), n.useEffect(() => {
      const m = o.selectedType;
      m && (x(/* @__PURE__ */ new Set([
        m
      ])), f({
        [m]: G(m)
      }), a.setSelectedType(null));
    }, [
      o.selectedType,
      a
    ]);
    const $ = n.useCallback((m) => {
      const S = i.current;
      if (!c && !S.has(m) && S.size >= 1) {
        re();
        return;
      }
      x((A) => {
        const L = B(A, m);
        return L.has(m) && !A.has(m) && f((E) => ({
          ...E,
          [m]: G(m)
        })), !L.has(m) && A.has(m) && f((E) => {
          const P = {
            ...E
          };
          return delete P[m], P;
        }), L;
      });
    }, [
      c
    ]), K = n.useCallback(() => {
      if (d.size === 0 || w || u)
        return;
      const m = [
        ...d
      ];
      if (t(), m.length === 1) {
        const S = {
          ...y[m[0]] || {}
        };
        p && (S.instructions = p), j !== null && (S.overrideLanguage = j), a.generateArtifact(r, m[0], N, S), le(() => a.isLicensed());
      } else {
        const S = m.map((A) => ({
          type: A,
          options: {
            ...y[A] || {},
            ...p ? {
              instructions: p
            } : {},
            ...j !== null ? {
              overrideLanguage: j
            } : {}
          }
        }));
        a.generatePack(r, ne(S), N);
      }
    }, [
      d,
      w,
      u,
      t,
      y,
      p,
      j,
      r,
      N,
      a
    ]), W = n.useCallback((m, S, A) => {
      f((L) => ({
        ...L,
        [m]: {
          ...L[m],
          [S]: oe(A)
        }
      }));
    }, []), q = d.size === 0 ? "Select types" : d.size === 1 ? `Generate ${F[d.values().next().value] || ""}` : `Generate ${d.size} types`;
    return e.jsxs(me, {
      open: l,
      onClose: t,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(he, {
            className: "w-full max-w-sm max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(pe, {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100 flex items-center gap-1.5",
                    children: [
                      e.jsx(V, {
                        className: "w-3.5 h-3.5"
                      }),
                      "Generate"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: t,
                    "aria-label": "Close generate panel",
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-400 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                    children: e.jsx(ce, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-3",
                children: w ? e.jsxs("div", {
                  className: "text-center py-8",
                  children: [
                    e.jsx("p", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: "Add sources to your notebook before generating."
                    }),
                    e.jsx("p", {
                      className: "text-xs text-gray-400 dark:text-slate-500 mt-1",
                      children: "Use the Sources tab to add web pages, text, or files."
                    })
                  ]
                }) : e.jsx(Oe, {
                  notebookId: r,
                  selectedTypes: d,
                  onTypeToggle: $,
                  optionsMap: y,
                  onOptionChange: W,
                  instructions: p,
                  onInstructionsChange: v,
                  overrideLanguage: j,
                  onOverrideLanguageChange: k,
                  outputLanguage: b,
                  outputFavorites: h,
                  sources: s,
                  activeSourceIds: N,
                  onSourceToggle: C,
                  onSelectAll: I,
                  isGenerating: u
                })
              }),
              !w && e.jsxs(e.Fragment, {
                children: [
                  d.size > 0 && N.length === 0 && !u && e.jsx("p", {
                    "aria-live": "polite",
                    role: "status",
                    className: "text-xs text-amber-600 dark:text-amber-400 text-center px-3 pb-1",
                    children: "Select at least one source to generate"
                  }),
                  e.jsxs("div", {
                    className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                    children: [
                      e.jsx("button", {
                        onClick: t,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                        children: "Cancel"
                      }),
                      e.jsx("button", {
                        onClick: K,
                        disabled: w || u || d.size === 0 || N.length === 0,
                        title: d.size === 0 ? "Select at least one type" : void 0,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500",
                        children: u ? "Generating..." : q
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  Ge as default
};
