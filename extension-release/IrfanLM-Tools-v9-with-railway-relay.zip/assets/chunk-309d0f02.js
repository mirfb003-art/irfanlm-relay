import { r as s, j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { u as g, __tla as __tla_1 } from "./chunk-93ad41a0.js";
import { P as w, am as k, __tla as __tla_2 } from "./chunk-2a4ab792.js";
import { P as C, __tla as __tla_3 } from "./chunk-cfcef7af.js";
import { A as R, __tla as __tla_4 } from "./chunk-57988b21.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let D;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  function T({ isPlaying: r, progress: a, formattedTime: i, formattedDuration: t, playbackRate: x, toggle: c, seek: o, cycleSpeed: f, downloadUrl: u, containerRef: d, visible: p }) {
    const l = (m) => {
      const n = m.currentTarget.getBoundingClientRect(), b = m.clientX - n.left;
      o(b / n.width);
    }, h = () => {
      document.fullscreenElement ? document.exitFullscreen() : d.current && d.current.requestFullscreen();
    };
    return e.jsxs("div", {
      className: `absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2 ${p ? "opacity-100" : "opacity-0"}`,
      children: [
        e.jsx("div", {
          className: "w-full bg-white/30 h-1 rounded-full cursor-pointer mb-2",
          onClick: l,
          children: e.jsx("div", {
            className: "bg-white h-full rounded-full",
            style: {
              width: `${a}%`
            }
          })
        }),
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("button", {
              type: "button",
              onClick: c,
              className: "text-white",
              children: r ? e.jsx(C, {
                className: "w-4 h-4"
              }) : e.jsx(w, {
                className: "w-4 h-4"
              })
            }),
            e.jsxs("span", {
              className: "text-xs text-white",
              children: [
                i,
                " / ",
                t
              ]
            }),
            e.jsx("div", {
              className: "flex-1"
            }),
            e.jsxs("button", {
              type: "button",
              onClick: f,
              className: "text-xs text-white bg-white/20 px-1.5 py-0.5 rounded",
              children: [
                x,
                "x"
              ]
            }),
            u && e.jsx("a", {
              href: u,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-white",
              children: e.jsx(R, {
                className: "w-4 h-4"
              })
            }),
            e.jsx("button", {
              type: "button",
              onClick: h,
              className: "text-white",
              children: e.jsx(k, {
                className: "w-4 h-4"
              })
            })
          ]
        })
      ]
    });
  }
  D = function({ content: r }) {
    var _a;
    const a = s.useRef(null), i = s.useRef(null), t = s.useRef(null), [x, c] = s.useState(true), { isPlaying: o, playbackRate: f, progress: u, formattedTime: d, formattedDuration: p, toggle: l, seek: h, cycleSpeed: m } = g(a), n = r == null ? void 0 : r.videoUrl, b = r == null ? void 0 : r.downloadUrl, N = s.useCallback(() => {
      c(true), t.current && clearTimeout(t.current), t.current = setTimeout(() => {
        c(false);
      }, 3e3);
    }, []);
    if (s.useEffect(() => () => {
      t.current && clearTimeout(t.current);
    }, []), !n)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "No video URL available."
      });
    const v = x || !o;
    return e.jsxs("div", {
      ref: i,
      className: "relative aspect-video bg-black rounded overflow-hidden",
      onMouseMove: N,
      children: [
        e.jsxs("video", {
          ref: a,
          className: "w-full h-full object-contain",
          preload: "metadata",
          onClick: l,
          children: [
            e.jsx("source", {
              src: n,
              type: "video/mp4"
            }),
            (_a = r == null ? void 0 : r.formats) == null ? void 0 : _a.map((j, y) => e.jsx("source", {
              src: j.url,
              type: j.mimeType
            }, y)),
            "Your browser does not support video playback."
          ]
        }),
        !o && e.jsx("div", {
          className: "absolute inset-0 flex items-center justify-center",
          onClick: l,
          children: e.jsx("button", {
            type: "button",
            className: "bg-black/50 rounded-full p-4 text-white",
            children: e.jsx(w, {
              className: "w-12 h-12"
            })
          })
        }),
        e.jsx(T, {
          isPlaying: o,
          progress: u,
          formattedTime: d,
          formattedDuration: p,
          playbackRate: f,
          toggle: l,
          seek: h,
          cycleSpeed: m,
          downloadUrl: b,
          containerRef: i,
          visible: v
        })
      ]
    });
  };
});
export {
  __tla,
  D as default
};
