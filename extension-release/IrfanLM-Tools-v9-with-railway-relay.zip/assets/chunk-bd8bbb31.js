import { r as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
let d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function o({ title: t, titleId: r, ...a }, l) {
    return e.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: l,
      "aria-labelledby": r
    }, a), t ? e.createElement("title", {
      id: r
    }, t) : null, e.createElement("path", {
      fillRule: "evenodd",
      d: "M3.43 2.524A41.29 41.29 0 0 1 10 2c2.236 0 4.43.18 6.57.524 1.437.231 2.43 1.49 2.43 2.902v5.148c0 1.413-.993 2.67-2.43 2.902a41.202 41.202 0 0 1-5.183.501.78.78 0 0 0-.528.224l-3.579 3.58A.75.75 0 0 1 6 17.25v-3.443a41.033 41.033 0 0 1-2.57-.33C1.993 13.244 1 11.986 1 10.573V5.426c0-1.413.993-2.67 2.43-2.902Z",
      clipRule: "evenodd"
    }));
  }
  let n;
  n = e.forwardRef(o);
  d = n;
});
export {
  d as C,
  __tla
};
