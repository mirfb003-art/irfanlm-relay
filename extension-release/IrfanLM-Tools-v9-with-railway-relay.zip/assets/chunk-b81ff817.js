import { r as e, J as i, __tla as __tla_0 } from "./chunk-b41980cc.js";
let E, A;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  A = function({ isOpen: o }) {
    const [d, u] = e.useState(false), [S, c] = e.useState({
      current: 0,
      total: 0,
      currentNotebook: "",
      phase: "",
      sourceProgress: ""
    }), [g, r] = e.useState(null), [F, n] = e.useState(null), [k, a] = e.useState("json"), [b, p] = e.useState("json"), l = e.useRef(null);
    return e.useEffect(() => {
      o && (u(false), r(null), n(null), a("json"), c({
        current: 0,
        total: 0,
        currentNotebook: "",
        phase: "",
        sourceProgress: ""
      }));
    }, [
      o
    ]), {
      isProcessing: d,
      setIsProcessing: u,
      progress: S,
      setProgress: c,
      importFile: g,
      importData: F,
      importFormat: k,
      exportFormat: b,
      setExportFormat: p,
      fileInputRef: l,
      handleFileSelect: (I) => {
        var _a;
        const s = (_a = I.target.files) == null ? void 0 : _a[0];
        if (!s)
          return;
        const f = s.name.endsWith(".zip"), h = s.name.endsWith(".json");
        if (!f && !h) {
          i.error("Please select a JSON or ZIP file");
          return;
        }
        if (f) {
          a("zip"), r(s), n(null);
          return;
        }
        a("json"), r(s);
        const m = new FileReader();
        m.onload = (j) => {
          try {
            const t = JSON.parse(j.target.result);
            t.type === "bulk" && Array.isArray(t.notebooks) ? n(t) : t.version && t.notebook && Array.isArray(t.sources) ? n({
              type: "single",
              notebooks: [
                t
              ]
            }) : (i.error("Invalid backup file format"), r(null));
          } catch {
            i.error("Failed to parse backup file"), r(null);
          }
        }, m.readAsText(s);
      },
      resetState: () => {
        n(null), r(null), a("json"), p("json"), l.current && (l.current.value = "");
      }
    };
  };
  E = function(o) {
    return o && o.replace(/[<>:"/\\|?*]/g, "-").replace(/\s+/g, " ").trim().slice(0, 100) || "Untitled";
  };
});
export {
  __tla,
  E as s,
  A as u
};
