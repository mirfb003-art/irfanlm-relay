import { r as n, j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { A as k, __tla as __tla_1 } from "./chunk-4115c378.js";
import { am as j, __tla as __tla_2 } from "./chunk-2a4ab792.js";
import { A as b, __tla as __tla_3 } from "./chunk-57988b21.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let R;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  R = function({ content: g }) {
    const [a, o] = n.useState(0), [c, h] = n.useState(false), i = n.useRef(null), d = n.useRef(null);
    if (!g)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "No slide deck content available."
      });
    const { slides: x = [], pdfUrl: u, pptxUrl: m } = g, l = x.length, s = x[a];
    return n.useEffect(() => {
      if (!i.current)
        return;
      const t = i.current.querySelector(`[data-slide-index="${a}"]`);
      t && t.scrollIntoView({
        behavior: "instant",
        block: "nearest",
        inline: "center"
      });
    }, [
      a
    ]), n.useEffect(() => {
      const t = (r) => {
        const p = r.target.tagName.toLowerCase();
        p === "input" || p === "textarea" || (r.key === "ArrowLeft" ? (r.preventDefault(), o((f) => Math.max(0, f - 1))) : r.key === "ArrowRight" && (r.preventDefault(), o((f) => Math.min(l - 1, f + 1))));
      };
      return window.addEventListener("keydown", t), () => window.removeEventListener("keydown", t);
    }, [
      l
    ]), n.useEffect(() => {
      const t = d.current;
      if (!t)
        return;
      const r = () => h(document.fullscreenElement === t);
      return t.addEventListener("fullscreenchange", r), () => t.removeEventListener("fullscreenchange", r);
    }, []), e.jsxs("div", {
      className: "space-y-3",
      children: [
        l > 0 && s && e.jsxs(e.Fragment, {
          children: [
            e.jsxs("div", {
              ref: d,
              className: `relative bg-gray-100 dark:bg-gray-900 rounded overflow-hidden aspect-video flex items-center justify-center ${c ? "bg-black" : ""}`,
              children: [
                s.imageUrl ? e.jsx("img", {
                  src: s.imageUrl,
                  alt: `Slide ${a + 1}`,
                  className: "max-h-full max-w-full object-contain"
                }) : e.jsx("span", {
                  className: "text-xs text-gray-500 dark:text-gray-400",
                  children: "No image"
                }),
                e.jsxs("span", {
                  className: "absolute top-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-full",
                  children: [
                    a + 1,
                    "/",
                    l
                  ]
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => {
                    var _a;
                    try {
                      document.fullscreenElement ? document.exitFullscreen() : (_a = d.current) == null ? void 0 : _a.requestFullscreen();
                    } catch {
                    }
                  },
                  className: "absolute top-2 left-2 bg-black/60 text-white p-1 rounded hover:bg-black/80",
                  title: c ? "Exit fullscreen" : "Fullscreen",
                  children: c ? e.jsx(k, {
                    className: "w-4 h-4"
                  }) : e.jsx(j, {
                    className: "w-4 h-4"
                  })
                })
              ]
            }),
            l > 1 && e.jsx("div", {
              ref: i,
              className: "flex gap-1.5 overflow-x-auto py-2 px-1",
              children: x.map((t, r) => e.jsx("button", {
                "data-slide-index": r,
                onClick: () => o(r),
                className: `w-16 h-10 rounded cursor-pointer border-2 overflow-hidden flex-shrink-0 ${r === a ? "border-blue-500" : "border-transparent hover:border-gray-300 dark:hover:border-slate-500"}`,
                children: t.imageUrl ? e.jsx("img", {
                  src: t.imageUrl,
                  alt: `Thumbnail ${r + 1}`,
                  className: "w-full h-full object-cover"
                }) : e.jsx("div", {
                  className: "w-full h-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center",
                  children: e.jsx("span", {
                    className: "text-[8px] text-gray-500 dark:text-gray-400",
                    children: r + 1
                  })
                })
              }, r))
            }),
            (s.description || s.text) && e.jsxs("div", {
              className: "p-3 space-y-1",
              children: [
                s.description && e.jsx("p", {
                  className: "text-xs text-gray-700 dark:text-slate-300",
                  children: s.description
                }),
                s.text && e.jsx("p", {
                  className: "text-xs text-gray-600 dark:text-slate-400 whitespace-pre-line break-words",
                  children: s.text
                })
              ]
            })
          ]
        }),
        (u || m) && e.jsxs("div", {
          className: "flex items-center justify-center gap-2",
          children: [
            u && e.jsxs("a", {
              href: u,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950 rounded border border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900",
              children: [
                e.jsx(b, {
                  className: "w-3.5 h-3.5"
                }),
                "PDF"
              ]
            }),
            m && e.jsxs("a", {
              href: m,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950 rounded border border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900",
              children: [
                e.jsx(b, {
                  className: "w-3.5 h-3.5"
                }),
                "PPTX"
              ]
            })
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  R as default
};
