import { j as e, c as C, T as E, r as g, X as G, u as re, M as le, ae as de, P as oe, J as p, U as w, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { h as R, i as I, z as _, Q as A, b as ne, d as ie, l as ce, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { L as K, __tla as __tla_2 } from "./chunk-de7ca15a.js";
import { P as Y, __tla as __tla_3 } from "./chunk-3daa5dc5.js";
import { T as z, __tla as __tla_4 } from "./chunk-b5767d08.js";
import { C as xe, __tla as __tla_5 } from "./chunk-7d0f6285.js";
import { A as ge, __tla as __tla_6 } from "./chunk-234b1720.js";
import { A as me, __tla as __tla_7 } from "./chunk-57988b21.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let $e;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })()
]).then(async () => {
  const ue = {
    gray: "bg-gray-400",
    red: "bg-red-400",
    orange: "bg-orange-400",
    yellow: "bg-yellow-400",
    green: "bg-green-400",
    teal: "bg-teal-400",
    blue: "bg-blue-400",
    indigo: "bg-indigo-400",
    purple: "bg-purple-400",
    pink: "bg-pink-400"
  }, be = (t) => t ? new Date(t).toLocaleDateString(void 0, {
    month: "short",
    day: "numeric"
  }) : "";
  function he({ tag: t, usageCount: s = 0, isSelected: d, isSelecting: n, onSelect: i, onEdit: o, onDelete: r }) {
    return e.jsxs("div", {
      className: C("bg-white dark:bg-slate-800 border rounded-lg p-2 group relative", d ? "border-blue-500 ring-1 ring-blue-500" : "border-gray-200 dark:border-slate-700 hover:border-gray-300 dark:hover:border-slate-600"),
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-1.5",
          children: [
            e.jsx("span", {
              className: C("w-2 h-2 rounded-full flex-shrink-0", ue[t.color])
            }),
            e.jsx("input", {
              type: "checkbox",
              checked: d,
              onChange: () => i(t.id),
              className: "h-3 w-3 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-1 cursor-pointer flex-shrink-0"
            }),
            e.jsx("span", {
              onClick: (m) => {
                m.stopPropagation(), n ? i(t.id) : window.location.hash = `/notebooklm?tag=${t.id}`;
              },
              className: "text-xs font-medium text-gray-900 dark:text-slate-100 truncate cursor-pointer hover:text-blue-600",
              children: t.name
            })
          ]
        }),
        e.jsxs("div", {
          className: "mt-1 text-xs text-gray-500 dark:text-slate-400",
          children: [
            s,
            " ",
            s === 1 ? "notebook" : "notebooks"
          ]
        }),
        e.jsx("div", {
          className: "mt-0.5 text-xs text-gray-400 dark:text-slate-500",
          children: be(t.createdAt)
        }),
        e.jsxs("div", {
          className: "absolute top-1 right-1 flex items-center gap-0.5 opacity-0 group-hover:opacity-100 bg-white dark:bg-slate-800 rounded",
          children: [
            e.jsx("button", {
              onClick: () => o(t),
              className: "p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded",
              title: "Edit",
              children: e.jsx(Y, {
                className: "w-3 h-3"
              })
            }),
            e.jsx("button", {
              onClick: () => r(t.id),
              className: "p-1 text-gray-400 dark:text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950 rounded",
              title: "Delete",
              children: e.jsx(R, {
                className: "w-3 h-3"
              })
            })
          ]
        })
      ]
    });
  }
  function pe({ tags: t, selectedIds: s, onSelect: d, onEdit: n, onDelete: i, usageCounts: o = {}, emptyMessage: r = "No tags yet", emptyDescription: m = "Create your first tag to organize notebooks" }) {
    if (t.length === 0)
      return e.jsxs("div", {
        className: "flex flex-col items-center justify-center py-10 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
        children: [
          e.jsx("div", {
            className: "w-10 h-10 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center mb-3",
            children: e.jsx(z, {
              className: "w-5 h-5 text-gray-400 dark:text-slate-500"
            })
          }),
          e.jsx("p", {
            className: "text-xs font-medium text-gray-600 dark:text-slate-400",
            children: r
          }),
          e.jsx("p", {
            className: "text-xs text-gray-400 dark:text-slate-500 mt-1",
            children: m
          })
        ]
      });
    const u = s.size > 0;
    return e.jsx("div", {
      className: "grid grid-cols-3 gap-1.5",
      children: t.map((c) => e.jsx(he, {
        tag: c,
        usageCount: o[c.id] || 0,
        isSelected: s.has(c.id),
        isSelecting: u,
        onSelect: d,
        onEdit: n,
        onDelete: i
      }, c.id))
    });
  }
  const ke = {
    gray: "bg-gray-400",
    red: "bg-red-400",
    orange: "bg-orange-400",
    yellow: "bg-yellow-400",
    green: "bg-green-400",
    teal: "bg-teal-400",
    blue: "bg-blue-400",
    indigo: "bg-indigo-400",
    purple: "bg-purple-400",
    pink: "bg-pink-400"
  }, fe = (t) => t ? new Date(t).toLocaleDateString(void 0, {
    month: "short",
    day: "numeric"
  }) : "";
  function ye({ tag: t, usageCount: s = 0, isSelected: d, isSelecting: n, onSelect: i, onEdit: o, onDelete: r }) {
    return e.jsxs("div", {
      className: "flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-slate-700 rounded-md group",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2 min-w-0",
          children: [
            e.jsx("span", {
              className: C("w-2 h-2 rounded-full flex-shrink-0", ke[t.color])
            }),
            e.jsx("input", {
              type: "checkbox",
              checked: d,
              onChange: () => i(t.id),
              className: "h-3 w-3 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-1 cursor-pointer flex-shrink-0"
            }),
            e.jsx("span", {
              onClick: (m) => {
                m.stopPropagation(), n ? i(t.id) : window.location.hash = `/notebooklm?tag=${t.id}`;
              },
              className: "text-xs font-medium text-gray-900 dark:text-slate-100 truncate cursor-pointer hover:text-blue-600",
              children: t.name
            }),
            e.jsxs("span", {
              className: "text-xs text-gray-500 dark:text-slate-400 flex-shrink-0",
              children: [
                s,
                " ",
                s === 1 ? "notebook" : "notebooks"
              ]
            }),
            e.jsx("span", {
              className: "text-xs text-gray-400 dark:text-slate-500 flex-shrink-0",
              children: fe(t.createdAt)
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-0.5 opacity-0 group-hover:opacity-100 flex-shrink-0",
          children: [
            e.jsx("button", {
              onClick: () => o(t),
              className: "p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded",
              title: "Edit",
              children: e.jsx(Y, {
                className: "w-3 h-3"
              })
            }),
            e.jsx("button", {
              onClick: () => r(t.id),
              className: "p-1 text-gray-400 dark:text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950 rounded",
              title: "Delete",
              children: e.jsx(R, {
                className: "w-3 h-3"
              })
            })
          ]
        })
      ]
    });
  }
  function je({ tags: t, selectedIds: s, onSelect: d, onEdit: n, onDelete: i, usageCounts: o = {}, emptyMessage: r = "No tags yet", emptyDescription: m = "Create your first tag to organize notebooks" }) {
    if (t.length === 0)
      return e.jsxs("div", {
        className: "flex flex-col items-center justify-center py-10 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
        children: [
          e.jsx("div", {
            className: "w-10 h-10 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center mb-3",
            children: e.jsx(z, {
              className: "w-5 h-5 text-gray-400 dark:text-slate-500"
            })
          }),
          e.jsx("p", {
            className: "text-xs font-medium text-gray-600 dark:text-slate-400",
            children: r
          }),
          e.jsx("p", {
            className: "text-xs text-gray-400 dark:text-slate-500 mt-1",
            children: m
          })
        ]
      });
    const u = s.size > 0;
    return e.jsx("div", {
      className: "bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg divide-y divide-gray-100 dark:divide-slate-700",
      children: t.map((c) => e.jsx(ye, {
        tag: c,
        usageCount: o[c.id] || 0,
        isSelected: s.has(c.id),
        isSelecting: u,
        onSelect: d,
        onEdit: n,
        onDelete: i
      }, c.id))
    });
  }
  const ve = {
    gray: "bg-gray-400",
    red: "bg-red-400",
    orange: "bg-orange-400",
    yellow: "bg-yellow-400",
    green: "bg-green-400",
    teal: "bg-teal-400",
    blue: "bg-blue-400",
    indigo: "bg-indigo-400",
    purple: "bg-purple-400",
    pink: "bg-pink-400"
  };
  function Ne({ value: t, onChange: s, size: d = "normal" }) {
    const n = d === "compact" ? "w-4 h-4" : "w-5 h-5", i = d === "compact" ? "gap-1" : "gap-1.5";
    return e.jsx("div", {
      className: C("flex flex-wrap", i),
      children: E.map((o) => e.jsx("button", {
        type: "button",
        onClick: () => s(o),
        "aria-label": `Select ${o}`,
        "aria-pressed": t === o,
        className: C("rounded-full", n, ve[o], t === o && "ring-2 ring-offset-2 ring-gray-400"),
        title: o
      }, o))
    });
  }
  function we({ isOpen: t, onClose: s, onSubmit: d, editingTag: n = null, isLoading: i = false }) {
    const [o, r] = g.useState(""), [m, u] = g.useState("blue"), c = g.useRef(null), y = !!n;
    g.useEffect(() => {
      t && (n ? (r(n.name), u(n.color)) : (r(""), u("blue")), setTimeout(() => {
        var _a;
        return (_a = c.current) == null ? void 0 : _a.focus();
      }, 100));
    }, [
      t,
      n
    ]);
    const h = () => {
      r(""), u("blue"), s();
    }, b = async (k) => {
      k.preventDefault(), o.trim() && (await d({
        name: o.trim(),
        color: m
      }, n == null ? void 0 : n.id), h());
    }, j = (k) => {
      k.key === "Escape" && h();
    };
    return e.jsxs(I, {
      open: t,
      onClose: h,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(_, {
            className: "w-full max-w-sm space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between",
                children: [
                  e.jsx(A, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                    children: y ? "Edit Tag" : "Create Tag"
                  }),
                  e.jsx("button", {
                    onClick: h,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                    children: e.jsx(G, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsxs("form", {
                onSubmit: b,
                className: "space-y-4",
                onKeyDown: j,
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "tagName",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: "Name"
                      }),
                      e.jsx("input", {
                        ref: c,
                        type: "text",
                        id: "tagName",
                        value: o,
                        onChange: (k) => r(k.target.value),
                        placeholder: "Enter tag name...",
                        className: "block w-full rounded-md border-gray-300 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs px-3 py-2 dark:bg-slate-900 dark:text-slate-100"
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-2",
                        children: "Color"
                      }),
                      e.jsx(Ne, {
                        value: m,
                        onChange: u
                      })
                    ]
                  }),
                  !y && e.jsx(K, {
                    compact: true
                  }),
                  e.jsxs("div", {
                    className: "flex justify-end gap-2 pt-2",
                    children: [
                      e.jsx("button", {
                        type: "button",
                        onClick: h,
                        disabled: i,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
                        children: "Cancel"
                      }),
                      e.jsx("button", {
                        type: "submit",
                        disabled: i || !o.trim(),
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
                        children: i ? y ? "Saving..." : "Creating..." : y ? "Save" : "Create"
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  const Ce = [
    {
      value: "name",
      label: "Name"
    },
    {
      value: "usage",
      label: "Most Used"
    },
    {
      value: "color",
      label: "Color"
    },
    {
      value: "createdAt",
      label: "Newest"
    }
  ], P = "YT_NOTEBOOKLM_TOOLS_TAGS_VIEW_MODE", U = "YT_NOTEBOOKLM_TOOLS_TAGS_SORT_BY";
  $e = function() {
    const [t, s] = re(), [d, n] = g.useState(""), [i, o] = g.useState(() => localStorage.getItem(U) || "most-used"), [r, m] = g.useState(/* @__PURE__ */ new Set()), [u, c] = g.useState(false), [y, h] = g.useState(null), [b, j] = g.useState(null), [k, M] = g.useState(false), [V, S] = g.useState(false), [D, F] = g.useState(() => localStorage.getItem(P) || "grid"), T = g.useRef(null);
    g.useEffect(() => {
      t.notebookTags.isLoaded || s.loadTags();
    }, []);
    const v = s.getAllTags(), N = s.getTagUsageCounts(), J = g.useMemo(() => {
      let a = d.trim() ? v.filter((l) => l.name.toLowerCase().includes(d.toLowerCase())) : v;
      switch (i) {
        case "name":
          a = [
            ...a
          ].sort((l, x) => l.name.localeCompare(x.name));
          break;
        case "usage":
          a = [
            ...a
          ].sort((l, x) => (N[x.id] || 0) - (N[l.id] || 0));
          break;
        case "color":
          a = [
            ...a
          ].sort((l, x) => E.indexOf(l.color) - E.indexOf(x.color));
          break;
        case "createdAt":
          a = [
            ...a
          ].sort((l, x) => x.createdAt - l.createdAt);
          break;
      }
      return a;
    }, [
      v,
      d,
      i,
      N
    ]), $ = (a) => {
      F(a), localStorage.setItem(P, a);
    }, Q = async ({ name: a, color: l }, x) => {
      M(true);
      try {
        x ? (await s.updateTag(x, {
          name: a,
          color: l
        }), p.success("Tag updated")) : (await s.createTag(a, l), p.success("Tag created"), w(() => s.isLicensed()));
      } finally {
        M(false);
      }
    }, W = (a) => {
      const l = new Set(r);
      l.has(a) ? l.delete(a) : l.add(a), m(l);
    }, X = (a) => {
      j(a);
    }, q = async () => {
      b && (await s.deleteTag(b), r.delete(b), m(new Set(r)), j(null), p.success("Tag deleted"), w(() => s.isLicensed()));
    }, H = async () => {
      if (r.size !== 0) {
        for (const a of r)
          await s.deleteTag(a);
        p.success(`Deleted ${r.size} tag${r.size !== 1 ? "s" : ""}`), w(() => s.isLicensed()), m(/* @__PURE__ */ new Set()), S(false);
      }
    }, Z = () => {
      const a = s.exportTags(), l = new Blob([
        JSON.stringify(a, null, 2)
      ], {
        type: "application/json"
      }), x = URL.createObjectURL(l), f = document.createElement("a");
      f.href = x, f.download = `tags-backup-${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`, document.body.appendChild(f), f.click(), document.body.removeChild(f), URL.revokeObjectURL(x), p.success("Tags exported"), w(() => s.isLicensed());
    }, ee = () => {
      var _a;
      (_a = T.current) == null ? void 0 : _a.click();
    }, te = async (a) => {
      var _a;
      const l = (_a = a.target.files) == null ? void 0 : _a[0];
      if (!l)
        return;
      if (!l.name.endsWith(".json")) {
        p.error("Please select a JSON file");
        return;
      }
      const x = new FileReader();
      x.onload = async (f) => {
        try {
          const L = JSON.parse(f.target.result), B = await s.importTags(L);
          p.success(`Imported ${B} new tag${B !== 1 ? "s" : ""}`), w(() => s.isLicensed());
        } catch (L) {
          p.error(L.message || "Failed to import tags");
        }
      }, x.readAsText(l), T.current && (T.current.value = "");
    }, ae = b ? t.notebookTags.tags[b] : null, O = b && N[b] || 0, se = D === "grid" ? pe : je;
    return e.jsxs(ne, {
      children: [
        e.jsx(ie, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "Manage Tags"
          })
        }),
        e.jsxs("div", {
          className: "flex flex-col gap-3",
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("a", {
                      href: "#/notebooklm",
                      className: "p-1 rounded-md text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                      title: "Back to Notebooks",
                      children: e.jsx(xe, {
                        className: "w-4 h-4"
                      })
                    }),
                    e.jsx(z, {
                      className: "w-4 h-4 text-gray-500 dark:text-slate-400"
                    }),
                    e.jsx("h1", {
                      className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                      children: "Manage Tags"
                    }),
                    e.jsx("span", {
                      className: "px-1.5 py-0.5 text-xs font-medium text-gray-500 dark:text-slate-400 bg-gray-100 dark:bg-slate-700 rounded",
                      children: v.length
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex gap-1.5",
                  children: [
                    e.jsx("input", {
                      ref: T,
                      type: "file",
                      accept: ".json",
                      onChange: te,
                      className: "hidden"
                    }),
                    e.jsxs("button", {
                      onClick: ee,
                      className: "px-2 py-1.5 flex items-center gap-1 text-xs font-medium text-gray-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                      children: [
                        e.jsx(ge, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Import"
                      ]
                    }),
                    e.jsxs("button", {
                      onClick: Z,
                      disabled: v.length === 0,
                      className: "px-2 py-1.5 flex items-center gap-1 text-xs font-medium text-gray-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
                      children: [
                        e.jsx(me, {
                          className: "w-3.5 h-3.5"
                        }),
                        "Export"
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsx(K, {}),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs("div", {
                  className: "relative flex-1",
                  children: [
                    e.jsx(le, {
                      className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                    }),
                    e.jsx("input", {
                      type: "text",
                      value: d,
                      onChange: (a) => n(a.target.value),
                      placeholder: "Search...",
                      className: "w-full pl-8 pr-7 py-1.5 rounded-md border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-800 dark:text-slate-100"
                    }),
                    d && e.jsx("button", {
                      onClick: () => n(""),
                      className: "absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300",
                      children: e.jsx(G, {
                        className: "w-3.5 h-3.5"
                      })
                    })
                  ]
                }),
                e.jsx("select", {
                  value: i,
                  onChange: (a) => {
                    o(a.target.value), localStorage.setItem(U, a.target.value);
                  },
                  className: "py-1.5 pl-2 pr-7 rounded-md border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-800 dark:text-slate-100",
                  children: Ce.map((a) => e.jsx("option", {
                    value: a.value,
                    children: a.label
                  }, a.value))
                }),
                e.jsxs("div", {
                  className: "flex items-center border border-gray-300 dark:border-gray-600 rounded-md overflow-hidden",
                  children: [
                    e.jsx("button", {
                      onClick: () => $("list"),
                      className: `p-1.5 ${D === "list" ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : "bg-white dark:bg-slate-800 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"}`,
                      title: "List view",
                      children: e.jsx(de, {
                        className: "w-3.5 h-3.5"
                      })
                    }),
                    e.jsx("button", {
                      onClick: () => $("grid"),
                      className: `p-1.5 ${D === "grid" ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : "bg-white dark:bg-slate-800 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"}`,
                      title: "Grid view",
                      children: e.jsx(ce, {
                        className: "w-3.5 h-3.5"
                      })
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: () => c(true),
                  className: "flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700",
                  children: [
                    e.jsx(oe, {
                      className: "w-3.5 h-3.5"
                    }),
                    "Create"
                  ]
                })
              ]
            }),
            r.size > 0 && e.jsxs("div", {
              className: "flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-md",
              children: [
                e.jsxs("span", {
                  className: "text-xs text-blue-700 dark:text-blue-300",
                  children: [
                    r.size,
                    " selected"
                  ]
                }),
                e.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    e.jsx("button", {
                      onClick: () => m(/* @__PURE__ */ new Set()),
                      className: "px-2 py-1 text-xs font-medium text-gray-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-50 dark:hover:bg-slate-700",
                      children: "Cancel"
                    }),
                    e.jsxs("button", {
                      onClick: () => S(true),
                      className: "px-2 py-1 text-xs font-medium text-red-600 dark:text-red-400 bg-white dark:bg-slate-800 border border-red-300 dark:border-red-700 rounded hover:bg-red-50 dark:hover:bg-red-950 flex items-center gap-1",
                      children: [
                        e.jsx(R, {
                          className: "w-3 h-3"
                        }),
                        "Delete"
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsx(se, {
              tags: J,
              selectedIds: r,
              onSelect: W,
              onEdit: (a) => {
                h(a), c(true);
              },
              onDelete: X,
              usageCounts: N,
              emptyMessage: d ? `No tags match "${d}"` : "No tags yet",
              emptyDescription: d ? "Try a different search term" : "Create your first tag to organize notebooks"
            })
          ]
        }),
        e.jsxs(I, {
          open: !!b,
          onClose: () => j(null),
          className: "relative z-50",
          children: [
            e.jsx("div", {
              className: "fixed inset-0 bg-black/25",
              "aria-hidden": "true"
            }),
            e.jsx("div", {
              className: "fixed inset-0 flex w-screen items-center justify-center p-4",
              children: e.jsxs(_, {
                className: "w-full max-w-sm bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
                children: [
                  e.jsx(A, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                    children: "Delete Tag"
                  }),
                  e.jsxs("div", {
                    className: "mt-3",
                    children: [
                      e.jsxs("p", {
                        className: "text-xs text-gray-700 dark:text-slate-300",
                        children: [
                          'Delete "',
                          ae == null ? void 0 : ae.name,
                          '"?'
                        ]
                      }),
                      O > 0 && e.jsxs("p", {
                        className: "text-xs text-red-600 dark:text-red-400 mt-1",
                        children: [
                          "This tag will be removed from ",
                          O,
                          " notebook",
                          O !== 1 ? "s" : "",
                          "."
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "mt-4 flex justify-end gap-2",
                    children: [
                      e.jsx("button", {
                        onClick: () => j(null),
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                        children: "Cancel"
                      }),
                      e.jsx("button", {
                        onClick: q,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700",
                        children: "Delete"
                      })
                    ]
                  })
                ]
              })
            })
          ]
        }),
        e.jsxs(I, {
          open: V,
          onClose: () => S(false),
          className: "relative z-50",
          children: [
            e.jsx("div", {
              className: "fixed inset-0 bg-black/25",
              "aria-hidden": "true"
            }),
            e.jsx("div", {
              className: "fixed inset-0 flex w-screen items-center justify-center p-4",
              children: e.jsxs(_, {
                className: "w-full max-w-sm bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
                children: [
                  e.jsx(A, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                    children: "Delete Tags"
                  }),
                  e.jsxs("div", {
                    className: "mt-3",
                    children: [
                      e.jsxs("p", {
                        className: "text-xs text-gray-700 dark:text-slate-300",
                        children: [
                          "Delete ",
                          r.size,
                          " tag",
                          r.size !== 1 ? "s" : "",
                          "?"
                        ]
                      }),
                      e.jsx("p", {
                        className: "text-xs text-red-600 dark:text-red-400 mt-1",
                        children: "This action cannot be undone."
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "mt-4 flex justify-end gap-2",
                    children: [
                      e.jsx("button", {
                        onClick: () => S(false),
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                        children: "Cancel"
                      }),
                      e.jsx("button", {
                        onClick: H,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700",
                        children: "Delete"
                      })
                    ]
                  })
                ]
              })
            })
          ]
        }),
        e.jsx(we, {
          isOpen: u,
          onClose: () => {
            c(false), h(null);
          },
          onSubmit: Q,
          editingTag: y,
          isLoading: k
        })
      ]
    });
  };
});
export {
  __tla,
  $e as default
};
