import { j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { i as o, z as c, Q as x, __tla as __tla_1 } from "./chunk-2a4ab792.js";
let g;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  g = function({ open: r, onClose: s, onConfirm: t, title: a, message: i, confirmLabel: d = "Confirm", variant: l = "danger", disabled: n = false }) {
    return e.jsxs(o, {
      open: r,
      onClose: s,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(c, {
            className: "w-full max-w-xs bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-4",
            children: [
              e.jsx(x, {
                className: "text-xs font-medium text-gray-900 dark:text-slate-100 mb-2",
                children: a
              }),
              e.jsx("p", {
                className: "text-xs text-gray-500 dark:text-slate-400 mb-4 whitespace-pre-line",
                children: i
              }),
              e.jsxs("div", {
                className: "flex justify-end gap-2",
                children: [
                  e.jsx("button", {
                    autoFocus: true,
                    onClick: s,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500",
                    children: "Cancel"
                  }),
                  e.jsx("button", {
                    onClick: t,
                    disabled: n,
                    className: `px-3 py-1.5 text-xs font-medium text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 ${l === "primary" ? "bg-blue-600 hover:bg-blue-700 focus:ring-blue-500" : "bg-red-600 hover:bg-red-700 focus:ring-red-500"}`,
                    children: d
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  g as C,
  __tla
};
