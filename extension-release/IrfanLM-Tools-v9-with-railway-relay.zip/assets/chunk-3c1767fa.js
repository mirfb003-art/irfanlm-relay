import { r, j as e, X as Z, J as c, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as F, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { A as z, __tla as __tla_2 } from "./chunk-57988b21.js";
import { A as I, __tla as __tla_3 } from "./chunk-234b1720.js";
import { i as D, z as E, Q as L, __tla as __tla_4 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_5 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let K;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  K = function({ isOpen: C, onClose: A, notebook: k, sources: y, onExport: B, onImport: N, isExporting: t = false, isImporting: a = false, exportProgress: l = {
    current: 0,
    total: 0
  } }) {
    const [x, v] = r.useState("export"), [s, b] = r.useState(null), [d, p] = r.useState("json"), [m, h] = r.useState("json"), [i, g] = r.useState(null), f = r.useRef(null), J = (o) => {
      var _a;
      const n = (_a = o.target.files) == null ? void 0 : _a[0];
      if (!n)
        return;
      const w = n.name.endsWith(".zip"), T = n.name.endsWith(".json");
      if (!w && !T) {
        c.error("Please select a JSON or ZIP file");
        return;
      }
      if (w) {
        h("zip"), g(n), b(null);
        return;
      }
      h("json"), g(null);
      const S = new FileReader();
      S.onload = (O) => {
        try {
          const u = JSON.parse(O.target.result);
          if (!u.version || !u.notebook || !Array.isArray(u.sources)) {
            c.error("Invalid backup file format");
            return;
          }
          b(u);
        } catch {
          c.error("Failed to parse backup file");
        }
      }, S.readAsText(n);
    }, R = () => {
      if (m === "zip") {
        if (!i) {
          c.error("Please select a ZIP file first");
          return;
        }
        N({
          type: "zip",
          file: i
        });
      } else {
        if (!s) {
          c.error("Please select a backup file first");
          return;
        }
        N({
          type: "json",
          data: s
        });
      }
    }, j = () => {
      b(null), g(null), h("json"), p("json"), f.current && (f.current.value = ""), A();
    };
    return e.jsxs(D, {
      open: C,
      onClose: j,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(E, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsx(L, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: "Backup & Restore"
                  }),
                  e.jsx("button", {
                    onClick: j,
                    disabled: t || a,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(Z, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs("button", {
                    onClick: () => v("export"),
                    disabled: t || a,
                    className: `flex-1 py-2 px-4 text-xs font-medium ${x === "export" ? "text-gray-900 dark:text-slate-100 border-b-2 border-gray-900 dark:border-slate-100" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"} disabled:opacity-50`,
                    children: [
                      e.jsx(z, {
                        className: "w-3.5 h-3.5 inline mr-1.5"
                      }),
                      "Export Backup"
                    ]
                  }),
                  e.jsxs("button", {
                    onClick: () => v("import"),
                    disabled: t || a,
                    className: `flex-1 py-2 px-4 text-xs font-medium ${x === "import" ? "text-gray-900 dark:text-slate-100 border-b-2 border-gray-900 dark:border-slate-100" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"} disabled:opacity-50`,
                    children: [
                      e.jsx(I, {
                        className: "w-3.5 h-3.5 inline mr-1.5"
                      }),
                      "Import Backup"
                    ]
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: x === "export" ? e.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    e.jsxs("div", {
                      className: "bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border border-gray-200 dark:border-slate-700",
                      children: [
                        e.jsx("h4", {
                          className: "text-xs font-medium text-gray-900 dark:text-slate-100 mb-2",
                          children: "Notebook Info"
                        }),
                        e.jsxs("div", {
                          className: "space-y-1 text-xs text-gray-600 dark:text-slate-400",
                          children: [
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Title:"
                                }),
                                " ",
                                k == null ? void 0 : k.emoji,
                                " ",
                                k == null ? void 0 : k.title
                              ]
                            }),
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Sources:"
                                }),
                                " ",
                                (y == null ? void 0 : y.length) || 0
                              ]
                            })
                          ]
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx("label", {
                          className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                          children: "Export Format"
                        }),
                        e.jsxs("div", {
                          className: "flex gap-3",
                          children: [
                            e.jsxs("label", {
                              className: "flex items-center gap-2 cursor-pointer",
                              children: [
                                e.jsx("input", {
                                  type: "radio",
                                  name: "exportFormat",
                                  value: "json",
                                  checked: d === "json",
                                  onChange: (o) => p(o.target.value),
                                  className: "h-3.5 w-3.5 text-gray-900 focus:ring-gray-900",
                                  disabled: t
                                }),
                                e.jsx("span", {
                                  className: "text-xs text-gray-700 dark:text-slate-300",
                                  children: "JSON (full metadata)"
                                })
                              ]
                            }),
                            e.jsxs("label", {
                              className: "flex items-center gap-2 cursor-pointer",
                              children: [
                                e.jsx("input", {
                                  type: "radio",
                                  name: "exportFormat",
                                  value: "zip",
                                  checked: d === "zip",
                                  onChange: (o) => p(o.target.value),
                                  className: "h-3.5 w-3.5 text-gray-900 focus:ring-gray-900",
                                  disabled: t
                                }),
                                e.jsx("span", {
                                  className: "text-xs text-gray-700 dark:text-slate-300",
                                  children: "ZIP (Markdown files)"
                                })
                              ]
                            })
                          ]
                        })
                      ]
                    }),
                    d === "json" && e.jsxs("div", {
                      className: "text-xs text-gray-500 dark:text-slate-400 space-y-1",
                      children: [
                        e.jsx("p", {
                          children: "Export will download a JSON file containing:"
                        }),
                        e.jsxs("ul", {
                          className: "list-disc list-inside ml-2 space-y-0.5",
                          children: [
                            e.jsx("li", {
                              children: "Notebook metadata (title, emoji)"
                            }),
                            e.jsx("li", {
                              children: "All source titles and URLs"
                            }),
                            e.jsx("li", {
                              children: "Full content of each source"
                            }),
                            e.jsx("li", {
                              children: "Source folder organization"
                            })
                          ]
                        })
                      ]
                    }),
                    d === "zip" && e.jsxs("div", {
                      className: "text-xs text-gray-500 dark:text-slate-400 space-y-1",
                      children: [
                        e.jsx("p", {
                          children: "Export will download a ZIP file containing:"
                        }),
                        e.jsxs("ul", {
                          className: "list-disc list-inside ml-2 space-y-0.5",
                          children: [
                            e.jsx("li", {
                              children: "Each source as a separate .md file"
                            }),
                            e.jsx("li", {
                              children: "Source URL included as blockquote"
                            }),
                            e.jsx("li", {
                              children: "Filename format: index-title.md"
                            }),
                            e.jsx("li", {
                              children: "Folder organization not included (JSON only)"
                            })
                          ]
                        })
                      ]
                    }),
                    t && e.jsxs("div", {
                      className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-2 mb-2",
                          children: [
                            e.jsx(F, {
                              size: "sm"
                            }),
                            e.jsx("span", {
                              className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                              children: "Exporting..."
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "w-full bg-blue-200 rounded-full h-1.5",
                          children: e.jsx("div", {
                            className: "bg-blue-600 h-1.5 rounded-full",
                            style: {
                              width: `${l.total > 0 ? l.current / l.total * 100 : 0}%`
                            }
                          })
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-blue-600 dark:text-blue-400 mt-1",
                          children: [
                            l.current,
                            " / ",
                            l.total,
                            " sources"
                          ]
                        })
                      ]
                    })
                  ]
                }) : e.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    e.jsxs("div", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: [
                        e.jsx("p", {
                          children: "Import sources from a previously exported backup file."
                        }),
                        e.jsx("p", {
                          className: "mt-1 text-amber-600 dark:text-amber-400",
                          children: "Note: This will add new sources to the current notebook."
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx("label", {
                          className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                          children: "Select Backup File"
                        }),
                        e.jsx("input", {
                          ref: f,
                          type: "file",
                          accept: ".json,.zip",
                          onChange: J,
                          disabled: a,
                          className: "block w-full text-xs text-gray-500 dark:text-slate-400 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-medium file:bg-gray-100 dark:file:bg-slate-700 file:text-gray-700 dark:file:text-slate-300 hover:file:bg-gray-200 dark:hover:file:bg-slate-600 disabled:opacity-50"
                        })
                      ]
                    }),
                    m === "json" && s && e.jsxs("div", {
                      className: "bg-green-50 dark:bg-green-950 p-3 rounded-lg border border-green-200 dark:border-green-800",
                      children: [
                        e.jsx("h4", {
                          className: "text-xs font-medium text-green-800 dark:text-green-300 mb-2",
                          children: "Backup Preview"
                        }),
                        e.jsxs("div", {
                          className: "space-y-1 text-xs text-green-700 dark:text-green-300",
                          children: [
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Original Notebook:"
                                }),
                                " ",
                                s.notebook.emoji,
                                " ",
                                s.notebook.title
                              ]
                            }),
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Sources to import:"
                                }),
                                " ",
                                s.sources.length
                              ]
                            }),
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "Exported on:"
                                }),
                                " ",
                                new Date(s.exportedAt).toLocaleString()
                              ]
                            })
                          ]
                        })
                      ]
                    }),
                    m === "zip" && i && e.jsxs("div", {
                      className: "bg-green-50 dark:bg-green-950 p-3 rounded-lg border border-green-200 dark:border-green-800",
                      children: [
                        e.jsx("h4", {
                          className: "text-xs font-medium text-green-800 dark:text-green-300 mb-2",
                          children: "ZIP File Selected"
                        }),
                        e.jsxs("div", {
                          className: "space-y-1 text-xs text-green-700 dark:text-green-300",
                          children: [
                            e.jsxs("p", {
                              children: [
                                e.jsx("span", {
                                  className: "font-medium",
                                  children: "File:"
                                }),
                                " ",
                                i.name
                              ]
                            }),
                            e.jsx("p", {
                              className: "text-amber-600 dark:text-amber-400",
                              children: "Note: .md files will be imported as text sources"
                            })
                          ]
                        })
                      ]
                    }),
                    a && e.jsx("div", {
                      className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                      children: e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(F, {
                            size: "sm"
                          }),
                          e.jsx("span", {
                            className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                            children: "Importing sources..."
                          })
                        ]
                      })
                    })
                  ]
                })
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                children: [
                  e.jsx("button", {
                    onClick: j,
                    disabled: t || a,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  x === "export" ? e.jsxs("button", {
                    onClick: () => B(d),
                    disabled: t || !(y == null ? void 0 : y.length),
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                    children: [
                      e.jsx(z, {
                        className: "w-3.5 h-3.5"
                      }),
                      t ? "Exporting..." : "Export Backup"
                    ]
                  }) : e.jsxs("button", {
                    onClick: R,
                    disabled: a || (m === "json" ? !s : !i),
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                    children: [
                      e.jsx(I, {
                        className: "w-3.5 h-3.5"
                      }),
                      a ? "Importing..." : "Import Backup"
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  K as default
};
