var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { r as u, n as xe, t as Rn, u as ee, j as l, m as j, o as Di, p as zn, X as sn, q as xo, v as _i, w as Bi, $ as Hi, x as Fr, y as Ui, z as Vi, B as Wi, D as zi, E as Gi, F as Zi, H as qi, I as Mt, h as rt, P as an, J as ge, K as br, c as $e, A as bo, L as vo, N as Ki, O as Yi, Q as Xi, d as yo, k as Qi, U as on, V as Ji, W as Cn, Y as wo, Z as Js, _ as ea, M as ko, a0 as Eo, a1 as ec, a2 as tc, S as Ut, a3 as jo, a4 as nc, G as rc, C as No, l as wn, a5 as sc, a6 as ac, a7 as oc, e as lc, a8 as Ae, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { q as ic, r as cc, s as uc, t as ta, u as na, v as ra, w as sa, F as aa, C as dc, E as Co, G as An, x as Pn, y as fc, I as hc, O as pc } from "./chunk-68adfa56.js";
import { g as cs } from "./chunk-725317a4.js";
import { c as mc } from "./chunk-38df7042.js";
import { c as gc, a as xc } from "./chunk-9bfc7485.js";
let zs, nv, is, Ic, ki, On, Qc, tb, Yb, su, eb, Kt, Ei, rb, wd, ab, Ln, fm, Ks, de, rv, lb, sb, ub, cb, Hx, _x, Ws, Ox, Ci, Gs, it, To, In, Eb, kb, Si, Wg, Ig, Rb, $b, Sb, Tb, $o, Hg, pu, fb, mb, pb, zx, Vx, Ec, lx, ia, Mx, Gn, So, Ti, oa, hm, qe, Ux, Yt, Kc, qs, du, Dt, Kb, Xb, yu, vn, ms, Im, xt, yn, pe, bi;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  var _a2, _b2;
  function bc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M17 4.25A2.25 2.25 0 0 0 14.75 2h-5.5A2.25 2.25 0 0 0 7 4.25v2a.75.75 0 0 0 1.5 0v-2a.75.75 0 0 1 .75-.75h5.5a.75.75 0 0 1 .75.75v11.5a.75.75 0 0 1-.75.75h-5.5a.75.75 0 0 1-.75-.75v-2a.75.75 0 0 0-1.5 0v2A2.25 2.25 0 0 0 9.25 18h5.5A2.25 2.25 0 0 0 17 15.75V4.25Z",
      clipRule: "evenodd"
    }), u.createElement("path", {
      fillRule: "evenodd",
      d: "M14 10a.75.75 0 0 0-.75-.75H3.704l1.048-.943a.75.75 0 1 0-1.004-1.114l-2.5 2.25a.75.75 0 0 0 0 1.114l2.5 2.25a.75.75 0 1 0 1.004-1.114l-1.048-.943h9.546A.75.75 0 0 0 14 10Z",
      clipRule: "evenodd"
    }));
  }
  const vc = u.forwardRef(bc), yc = vc;
  function wc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      d: "m13.28 7.78 3.22-3.22v2.69a.75.75 0 0 0 1.5 0v-4.5a.75.75 0 0 0-.75-.75h-4.5a.75.75 0 0 0 0 1.5h2.69l-3.22 3.22a.75.75 0 0 0 1.06 1.06ZM2 17.25v-4.5a.75.75 0 0 1 1.5 0v2.69l3.22-3.22a.75.75 0 0 1 1.06 1.06L4.56 16.5h2.69a.75.75 0 0 1 0 1.5h-4.5a.747.747 0 0 1-.75-.75ZM12.22 13.28l3.22 3.22h-2.69a.75.75 0 0 0 0 1.5h4.5a.747.747 0 0 0 .75-.75v-4.5a.75.75 0 0 0-1.5 0v2.69l-3.22-3.22a.75.75 0 1 0-1.06 1.06ZM3.5 4.56l3.22 3.22a.75.75 0 0 0 1.06-1.06L4.56 3.5h2.69a.75.75 0 0 0 0-1.5h-4.5a.75.75 0 0 0-.75.75v4.5a.75.75 0 0 0 1.5 0V4.56Z"
    }));
  }
  let kc;
  kc = u.forwardRef(wc);
  Ec = kc;
  function jc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M13.2 2.24a.75.75 0 0 0 .04 1.06l2.1 1.95H6.75a.75.75 0 0 0 0 1.5h8.59l-2.1 1.95a.75.75 0 1 0 1.02 1.1l3.5-3.25a.75.75 0 0 0 0-1.1l-3.5-3.25a.75.75 0 0 0-1.06.04Zm-6.4 8a.75.75 0 0 0-1.06-.04l-3.5 3.25a.75.75 0 0 0 0 1.1l3.5 3.25a.75.75 0 1 0 1.02-1.1l-2.1-1.95h8.59a.75.75 0 0 0 0-1.5H4.66l2.1-1.95a.75.75 0 0 0 .04-1.06Z",
      clipRule: "evenodd"
    }));
  }
  const Nc = u.forwardRef(jc), Cc = Nc;
  function Sc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M2 4.75A.75.75 0 0 1 2.75 4h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 4.75Zm0 10.5a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5a.75.75 0 0 1-.75-.75ZM2 10a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 10Z",
      clipRule: "evenodd"
    }));
  }
  const Tc = u.forwardRef(Sc), $c = Tc;
  function Rc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      d: "M11.983 1.907a.75.75 0 0 0-1.292-.657l-8.5 9.5A.75.75 0 0 0 2.75 12h6.572l-1.305 6.093a.75.75 0 0 0 1.292.657l8.5-9.5A.75.75 0 0 0 17.25 8h-6.572l1.305-6.093Z"
    }));
  }
  const Ac = u.forwardRef(Rc), Pc = Ac;
  function Oc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M16.403 12.652a3 3 0 0 0 0-5.304 3 3 0 0 0-3.75-3.751 3 3 0 0 0-5.305 0 3 3 0 0 0-3.751 3.75 3 3 0 0 0 0 5.305 3 3 0 0 0 3.75 3.751 3 3 0 0 0 5.305 0 3 3 0 0 0 3.751-3.75Zm-2.546-4.46a.75.75 0 0 0-1.214-.883l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z",
      clipRule: "evenodd"
    }));
  }
  let Lc;
  Lc = u.forwardRef(Oc);
  Ic = Lc;
  function Fc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z",
      clipRule: "evenodd"
    }));
  }
  let Mc;
  Mc = u.forwardRef(Fc);
  Gn = Mc;
  function Dc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",
      clipRule: "evenodd"
    }));
  }
  let _c;
  _c = u.forwardRef(Dc);
  xt = _c;
  function Bc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z",
      clipRule: "evenodd"
    }));
  }
  let Hc;
  Hc = u.forwardRef(Bc);
  So = Hc;
  function Uc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M10.53 3.47a.75.75 0 0 0-1.06 0L6.22 6.72a.75.75 0 0 0 1.06 1.06L10 5.06l2.72 2.72a.75.75 0 1 0 1.06-1.06l-3.25-3.25Zm-4.31 9.81 3.25 3.25a.75.75 0 0 0 1.06 0l3.25-3.25a.75.75 0 1 0-1.06-1.06L10 14.94l-2.72-2.72a.75.75 0 0 0-1.06 1.06Z",
      clipRule: "evenodd"
    }));
  }
  const Vc = u.forwardRef(Uc), Wc = Vc;
  function zc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495ZM10 5a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 10 5Zm0 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z",
      clipRule: "evenodd"
    }));
  }
  let Gc;
  Gc = u.forwardRef(zc);
  On = Gc;
  function Zc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      d: "M10 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"
    }), u.createElement("path", {
      fillRule: "evenodd",
      d: "M.664 10.59a1.651 1.651 0 0 1 0-1.186A10.004 10.004 0 0 1 10 3c4.257 0 7.893 2.66 9.336 6.41.147.381.146.804 0 1.186A10.004 10.004 0 0 1 10 17c-4.257 0-7.893-2.66-9.336-6.41ZM14 10a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
      clipRule: "evenodd"
    }));
  }
  let qc;
  qc = u.forwardRef(Zc);
  Kc = qc;
  function Yc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M2.628 1.601C5.028 1.206 7.49 1 10 1s4.973.206 7.372.601a.75.75 0 0 1 .628.74v2.288a2.25 2.25 0 0 1-.659 1.59l-4.682 4.683a2.25 2.25 0 0 0-.659 1.59v3.037c0 .684-.31 1.33-.844 1.757l-1.937 1.55A.75.75 0 0 1 8 18.25v-5.757a2.25 2.25 0 0 0-.659-1.591L2.659 6.22A2.25 2.25 0 0 1 2 4.629V2.34a.75.75 0 0 1 .628-.74Z",
      clipRule: "evenodd"
    }));
  }
  let Xc;
  Xc = u.forwardRef(Yc);
  Qc = Xc;
  function Jc({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M9.293 2.293a1 1 0 0 1 1.414 0l7 7A1 1 0 0 1 17 11h-1v6a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6H3a1 1 0 0 1-.707-1.707l7-7Z",
      clipRule: "evenodd"
    }));
  }
  const eu = u.forwardRef(Jc), tu = eu;
  function nu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-7-4a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM9 9a.75.75 0 0 0 0 1.5h.253a.25.25 0 0 1 .244.304l-.459 2.066A1.75 1.75 0 0 0 10.747 15H11a.75.75 0 0 0 0-1.5h-.253a.25.25 0 0 1-.244-.304l.459-2.066A1.75 1.75 0 0 0 9.253 9H9Z",
      clipRule: "evenodd"
    }));
  }
  let ru;
  ru = u.forwardRef(nu);
  su = ru;
  function au({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M8 7a5 5 0 1 1 3.61 4.804l-1.903 1.903A1 1 0 0 1 9 14H8v1a1 1 0 0 1-1 1H6v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-2a1 1 0 0 1 .293-.707L8.196 8.39A5.002 5.002 0 0 1 8 7Zm5-3a.75.75 0 0 0 0 1.5A1.5 1.5 0 0 1 14.5 7 .75.75 0 0 0 16 7a3 3 0 0 0-3-3Z",
      clipRule: "evenodd"
    }));
  }
  let ou;
  ou = u.forwardRef(au);
  Kt = ou;
  function lu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      d: "M12.232 4.232a2.5 2.5 0 0 1 3.536 3.536l-1.225 1.224a.75.75 0 0 0 1.061 1.06l1.224-1.224a4 4 0 0 0-5.656-5.656l-3 3a4 4 0 0 0 .225 5.865.75.75 0 0 0 .977-1.138 2.5 2.5 0 0 1-.142-3.667l3-3Z"
    }), u.createElement("path", {
      d: "M11.603 7.963a.75.75 0 0 0-.977 1.138 2.5 2.5 0 0 1 .142 3.667l-3 3a2.5 2.5 0 0 1-3.536-3.536l1.225-1.224a.75.75 0 0 0-1.061-1.06l-1.224 1.224a4 4 0 1 0 5.656 5.656l3-3a4 4 0 0 0-.225-5.865Z"
    }));
  }
  let iu;
  iu = u.forwardRef(lu);
  To = iu;
  function cu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M10 1a4.5 4.5 0 0 0-4.5 4.5V9H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-.5V5.5A4.5 4.5 0 0 0 10 1Zm3 8V5.5a3 3 0 1 0-6 0V9h6Z",
      clipRule: "evenodd"
    }));
  }
  let uu;
  uu = u.forwardRef(cu);
  du = uu;
  function fu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M8.157 2.176a1.5 1.5 0 0 0-1.147 0l-4.084 1.69A1.5 1.5 0 0 0 2 5.25v10.877a1.5 1.5 0 0 0 2.074 1.386l3.51-1.452 4.26 1.762a1.5 1.5 0 0 0 1.146 0l4.083-1.69A1.5 1.5 0 0 0 18 14.75V3.872a1.5 1.5 0 0 0-2.073-1.386l-3.51 1.452-4.26-1.762ZM7.58 5a.75.75 0 0 1 .75.75v6.5a.75.75 0 0 1-1.5 0v-6.5A.75.75 0 0 1 7.58 5Zm5.59 2.75a.75.75 0 0 0-1.5 0v6.5a.75.75 0 0 0 1.5 0v-6.5Z",
      clipRule: "evenodd"
    }));
  }
  let hu;
  hu = u.forwardRef(fu);
  pu = hu;
  function mu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM6.75 9.25a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Z",
      clipRule: "evenodd"
    }));
  }
  const gu = u.forwardRef(mu), xu = gu;
  function bu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M1 5.25A2.25 2.25 0 0 1 3.25 3h13.5A2.25 2.25 0 0 1 19 5.25v9.5A2.25 2.25 0 0 1 16.75 17H3.25A2.25 2.25 0 0 1 1 14.75v-9.5Zm1.5 5.81v3.69c0 .414.336.75.75.75h13.5a.75.75 0 0 0 .75-.75v-2.69l-2.22-2.219a.75.75 0 0 0-1.06 0l-1.91 1.909.47.47a.75.75 0 1 1-1.06 1.06L6.53 8.091a.75.75 0 0 0-1.06 0l-2.97 2.97ZM12 7a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z",
      clipRule: "evenodd"
    }));
  }
  let vu;
  vu = u.forwardRef(bu);
  yu = vu;
  function wu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      d: "M6.3 2.84A1.5 1.5 0 0 0 4 4.11v11.78a1.5 1.5 0 0 0 2.3 1.27l9.344-5.891a1.5 1.5 0 0 0 0-2.538L6.3 2.841Z"
    }));
  }
  let ku;
  ku = u.forwardRef(wu);
  Ln = ku;
  function Eu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      d: "M3.75 3a.75.75 0 0 0-.75.75v.5c0 .414.336.75.75.75H4c6.075 0 11 4.925 11 11v.25c0 .414.336.75.75.75h.5a.75.75 0 0 0 .75-.75V16C17 8.82 11.18 3 4 3h-.25Z"
    }), u.createElement("path", {
      d: "M3 8.75A.75.75 0 0 1 3.75 8H4a8 8 0 0 1 8 8v.25a.75.75 0 0 1-.75.75h-.5a.75.75 0 0 1-.75-.75V16a6 6 0 0 0-6-6h-.25A.75.75 0 0 1 3 9.25v-.5ZM7 15a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z"
    }));
  }
  let ju;
  ju = u.forwardRef(Eu);
  In = ju;
  function Nu({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M4.25 2A2.25 2.25 0 0 0 2 4.25v2.5A2.25 2.25 0 0 0 4.25 9h2.5A2.25 2.25 0 0 0 9 6.75v-2.5A2.25 2.25 0 0 0 6.75 2h-2.5Zm0 9A2.25 2.25 0 0 0 2 13.25v2.5A2.25 2.25 0 0 0 4.25 18h2.5A2.25 2.25 0 0 0 9 15.75v-2.5A2.25 2.25 0 0 0 6.75 11h-2.5Zm9-9A2.25 2.25 0 0 0 11 4.25v2.5A2.25 2.25 0 0 0 13.25 9h2.5A2.25 2.25 0 0 0 18 6.75v-2.5A2.25 2.25 0 0 0 15.75 2h-2.5Zm0 9A2.25 2.25 0 0 0 11 13.25v2.5A2.25 2.25 0 0 0 13.25 18h2.5A2.25 2.25 0 0 0 18 15.75v-2.5A2.25 2.25 0 0 0 15.75 11h-2.5Z",
      clipRule: "evenodd"
    }));
  }
  let Cu;
  Cu = u.forwardRef(Nu);
  Yt = Cu;
  function Su({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401Z",
      clipRule: "evenodd"
    }));
  }
  let Tu;
  Tu = u.forwardRef(Su);
  $o = Tu;
  function $u({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M8.75 1A2.75 2.75 0 0 0 6 3.75v.443c-.795.077-1.584.176-2.365.298a.75.75 0 1 0 .23 1.482l.149-.022.841 10.518A2.75 2.75 0 0 0 7.596 19h4.807a2.75 2.75 0 0 0 2.742-2.53l.841-10.52.149.023a.75.75 0 0 0 .23-1.482A41.03 41.03 0 0 0 14 4.193V3.75A2.75 2.75 0 0 0 11.25 1h-2.5ZM10 4c.84 0 1.673.025 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325C8.327 4.025 9.16 4 10 4ZM8.58 7.72a.75.75 0 0 0-1.5.06l.3 7.5a.75.75 0 1 0 1.5-.06l-.3-7.5Zm4.34.06a.75.75 0 1 0-1.5-.06l-.3 7.5a.75.75 0 1 0 1.5.06l.3-7.5Z",
      clipRule: "evenodd"
    }));
  }
  let Ru;
  Ru = u.forwardRef($u);
  oa = Ru;
  function Au({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      fillRule: "evenodd",
      d: "M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-5.5-2.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0ZM10 12a5.99 5.99 0 0 0-4.793 2.39A6.483 6.483 0 0 0 10 16.5a6.483 6.483 0 0 0 4.793-2.11A5.99 5.99 0 0 0 10 12Z",
      clipRule: "evenodd"
    }));
  }
  const Pu = u.forwardRef(Au), la = Pu;
  (function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload"))
      return;
    for (const s of document.querySelectorAll('link[rel="modulepreload"]'))
      r(s);
    new MutationObserver((s) => {
      for (const a of s)
        if (a.type === "childList")
          for (const o of a.addedNodes)
            o.tagName === "LINK" && o.rel === "modulepreload" && r(o);
    }).observe(document, {
      childList: true,
      subtree: true
    });
    function n(s) {
      const a = {};
      return s.integrity && (a.integrity = s.integrity), s.referrerPolicy && (a.referrerPolicy = s.referrerPolicy), s.crossOrigin === "use-credentials" ? a.credentials = "include" : s.crossOrigin === "anonymous" ? a.credentials = "omit" : a.credentials = "same-origin", a;
    }
    function r(s) {
      if (s.ep)
        return;
      s.ep = true;
      const a = n(s);
      fetch(s.href, a);
    }
  })();
  let ca;
  ia = {};
  ca = xe;
  ia.createRoot = ca.createRoot, ia.hydrateRoot = ca.hydrateRoot;
  function Xt() {
    return Xt = Object.assign ? Object.assign.bind() : function(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n)
          Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
      }
      return e;
    }, Xt.apply(this, arguments);
  }
  var Xe;
  (function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE";
  })(Xe || (Xe = {}));
  const ua = "popstate";
  function Ou(e) {
    e === void 0 && (e = {});
    function t(s, a) {
      let { pathname: o = "/", search: i = "", hash: c = "" } = bt(s.location.hash.substr(1));
      return !o.startsWith("/") && !o.startsWith(".") && (o = "/" + o), Mr("", {
        pathname: o,
        search: i,
        hash: c
      }, a.state && a.state.usr || null, a.state && a.state.key || "default");
    }
    function n(s, a) {
      let o = s.document.querySelector("base"), i = "";
      if (o && o.getAttribute("href")) {
        let c = s.location.href, d = c.indexOf("#");
        i = d === -1 ? c : c.slice(0, d);
      }
      return i + "#" + (typeof a == "string" ? a : Fn(a));
    }
    function r(s, a) {
      us(s.pathname.charAt(0) === "/", "relative pathnames are not supported in hash history.push(" + JSON.stringify(a) + ")");
    }
    return Iu(t, n, r, e);
  }
  function ce(e, t) {
    if (e === false || e === null || typeof e > "u")
      throw new Error(t);
  }
  function us(e, t) {
    if (!e) {
      typeof console < "u" && console.warn(t);
      try {
        throw new Error(t);
      } catch {
      }
    }
  }
  function Lu() {
    return Math.random().toString(36).substr(2, 8);
  }
  function da(e, t) {
    return {
      usr: e.state,
      key: e.key,
      idx: t
    };
  }
  function Mr(e, t, n, r) {
    return n === void 0 && (n = null), Xt({
      pathname: typeof e == "string" ? e : e.pathname,
      search: "",
      hash: ""
    }, typeof t == "string" ? bt(t) : t, {
      state: n,
      key: t && t.key || r || Lu()
    });
  }
  function Fn(e) {
    let { pathname: t = "/", search: n = "", hash: r = "" } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t;
  }
  function bt(e) {
    let t = {};
    if (e) {
      let n = e.indexOf("#");
      n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
      let r = e.indexOf("?");
      r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e);
    }
    return t;
  }
  function Iu(e, t, n, r) {
    r === void 0 && (r = {});
    let { window: s = document.defaultView, v5Compat: a = false } = r, o = s.history, i = Xe.Pop, c = null, d = f();
    d == null && (d = 0, o.replaceState(Xt({}, o.state, {
      idx: d
    }), ""));
    function f() {
      return (o.state || {
        idx: null
      }).idx;
    }
    function h() {
      i = Xe.Pop;
      let b = f(), y = b == null ? null : b - d;
      d = b, c && c({
        action: i,
        location: x.location,
        delta: y
      });
    }
    function g(b, y) {
      i = Xe.Push;
      let v = Mr(x.location, b, y);
      n && n(v, b), d = f() + 1;
      let w = da(v, d), k = x.createHref(v);
      try {
        o.pushState(w, "", k);
      } catch (E) {
        if (E instanceof DOMException && E.name === "DataCloneError")
          throw E;
        s.location.assign(k);
      }
      a && c && c({
        action: i,
        location: x.location,
        delta: 1
      });
    }
    function m(b, y) {
      i = Xe.Replace;
      let v = Mr(x.location, b, y);
      n && n(v, b), d = f();
      let w = da(v, d), k = x.createHref(v);
      o.replaceState(w, "", k), a && c && c({
        action: i,
        location: x.location,
        delta: 0
      });
    }
    function p(b) {
      let y = s.location.origin !== "null" ? s.location.origin : s.location.href, v = typeof b == "string" ? b : Fn(b);
      return v = v.replace(/ $/, "%20"), ce(y, "No window.location.(origin|href) available to create URL for href: " + v), new URL(v, y);
    }
    let x = {
      get action() {
        return i;
      },
      get location() {
        return e(s, o);
      },
      listen(b) {
        if (c)
          throw new Error("A history only accepts one active listener");
        return s.addEventListener(ua, h), c = b, () => {
          s.removeEventListener(ua, h), c = null;
        };
      },
      createHref(b) {
        return t(s, b);
      },
      createURL: p,
      encodeLocation(b) {
        let y = p(b);
        return {
          pathname: y.pathname,
          search: y.search,
          hash: y.hash
        };
      },
      push: g,
      replace: m,
      go(b) {
        return o.go(b);
      }
    };
    return x;
  }
  var fa;
  (function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error";
  })(fa || (fa = {}));
  function Fu(e, t, n) {
    return n === void 0 && (n = "/"), Mu(e, t, n, false);
  }
  function Mu(e, t, n, r) {
    let s = typeof t == "string" ? bt(t) : t, a = ds(s.pathname || "/", n);
    if (a == null)
      return null;
    let o = Ro(e);
    Du(o);
    let i = null;
    for (let c = 0; i == null && c < o.length; ++c) {
      let d = Ku(a);
      i = Zu(o[c], d, r);
    }
    return i;
  }
  function Ro(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let s = (a, o, i) => {
      let c = {
        relativePath: i === void 0 ? a.path || "" : i,
        caseSensitive: a.caseSensitive === true,
        childrenIndex: o,
        route: a
      };
      c.relativePath.startsWith("/") && (ce(c.relativePath.startsWith(r), 'Absolute route path "' + c.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), c.relativePath = c.relativePath.slice(r.length));
      let d = Je([
        r,
        c.relativePath
      ]), f = n.concat(c);
      a.children && a.children.length > 0 && (ce(a.index !== true, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + d + '".')), Ro(a.children, t, f, d)), !(a.path == null && !a.index) && t.push({
        path: d,
        score: zu(d, a.index),
        routesMeta: f
      });
    };
    return e.forEach((a, o) => {
      var i;
      if (a.path === "" || !((i = a.path) != null && i.includes("?")))
        s(a, o);
      else
        for (let c of Ao(a.path))
          s(a, o, c);
    }), t;
  }
  function Ao(e) {
    let t = e.split("/");
    if (t.length === 0)
      return [];
    let [n, ...r] = t, s = n.endsWith("?"), a = n.replace(/\?$/, "");
    if (r.length === 0)
      return s ? [
        a,
        ""
      ] : [
        a
      ];
    let o = Ao(r.join("/")), i = [];
    return i.push(...o.map((c) => c === "" ? a : [
      a,
      c
    ].join("/"))), s && i.push(...o), i.map((c) => e.startsWith("/") && c === "" ? "/" : c);
  }
  function Du(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : Gu(t.routesMeta.map((r) => r.childrenIndex), n.routesMeta.map((r) => r.childrenIndex)));
  }
  const _u = /^:[\w-]+$/, Bu = 3, Hu = 2, Uu = 1, Vu = 10, Wu = -2, ha = (e) => e === "*";
  function zu(e, t) {
    let n = e.split("/"), r = n.length;
    return n.some(ha) && (r += Wu), t && (r += Hu), n.filter((s) => !ha(s)).reduce((s, a) => s + (_u.test(a) ? Bu : a === "" ? Uu : Vu), r);
  }
  function Gu(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, s) => r === t[s]) ? e[e.length - 1] - t[t.length - 1] : 0;
  }
  function Zu(e, t, n) {
    n === void 0 && (n = false);
    let { routesMeta: r } = e, s = {}, a = "/", o = [];
    for (let i = 0; i < r.length; ++i) {
      let c = r[i], d = i === r.length - 1, f = a === "/" ? t : t.slice(a.length) || "/", h = pa({
        path: c.relativePath,
        caseSensitive: c.caseSensitive,
        end: d
      }, f), g = c.route;
      if (!h && d && n && !r[r.length - 1].route.index && (h = pa({
        path: c.relativePath,
        caseSensitive: c.caseSensitive,
        end: false
      }, f)), !h)
        return null;
      Object.assign(s, h.params), o.push({
        params: s,
        pathname: Je([
          a,
          h.pathname
        ]),
        pathnameBase: Ju(Je([
          a,
          h.pathnameBase
        ])),
        route: g
      }), h.pathnameBase !== "/" && (a = Je([
        a,
        h.pathnameBase
      ]));
    }
    return o;
  }
  function pa(e, t) {
    typeof e == "string" && (e = {
      path: e,
      caseSensitive: false,
      end: true
    });
    let [n, r] = qu(e.path, e.caseSensitive, e.end), s = t.match(n);
    if (!s)
      return null;
    let a = s[0], o = a.replace(/(.)\/+$/, "$1"), i = s.slice(1);
    return {
      params: r.reduce((d, f, h) => {
        let { paramName: g, isOptional: m } = f;
        if (g === "*") {
          let x = i[h] || "";
          o = a.slice(0, a.length - x.length).replace(/(.)\/+$/, "$1");
        }
        const p = i[h];
        return m && !p ? d[g] = void 0 : d[g] = (p || "").replace(/%2F/g, "/"), d;
      }, {}),
      pathname: a,
      pathnameBase: o,
      pattern: e
    };
  }
  function qu(e, t, n) {
    t === void 0 && (t = false), n === void 0 && (n = true), us(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [], s = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (o, i, c) => (r.push({
      paramName: i,
      isOptional: c != null
    }), c ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
      paramName: "*"
    }), s += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? s += "\\/*$" : e !== "" && e !== "/" && (s += "(?:(?=\\/|$))"), [
      new RegExp(s, t ? void 0 : "i"),
      r
    ];
  }
  function Ku(e) {
    try {
      return e.split("/").map((t) => decodeURIComponent(t).replace(/\//g, "%2F")).join("/");
    } catch (t) {
      return us(false, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e;
    }
  }
  function ds(e, t) {
    if (t === "/")
      return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase()))
      return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length, r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/";
  }
  function Yu(e, t) {
    t === void 0 && (t = "/");
    let { pathname: n, search: r = "", hash: s = "" } = typeof e == "string" ? bt(e) : e;
    return {
      pathname: n ? n.startsWith("/") ? n : Xu(n, t) : t,
      search: ed(r),
      hash: td(s)
    };
  }
  function Xu(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach((s) => {
      s === ".." ? n.length > 1 && n.pop() : s !== "." && n.push(s);
    }), n.length > 1 ? n.join("/") : "/";
  }
  function vr(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.';
  }
  function Qu(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0);
  }
  function fs(e, t) {
    let n = Qu(e);
    return t ? n.map((r, s) => s === n.length - 1 ? r.pathname : r.pathnameBase) : n.map((r) => r.pathnameBase);
  }
  function hs(e, t, n, r) {
    r === void 0 && (r = false);
    let s;
    typeof e == "string" ? s = bt(e) : (s = Xt({}, e), ce(!s.pathname || !s.pathname.includes("?"), vr("?", "pathname", "search", s)), ce(!s.pathname || !s.pathname.includes("#"), vr("#", "pathname", "hash", s)), ce(!s.search || !s.search.includes("#"), vr("#", "search", "hash", s)));
    let a = e === "" || s.pathname === "", o = a ? "/" : s.pathname, i;
    if (o == null)
      i = n;
    else {
      let h = t.length - 1;
      if (!r && o.startsWith("..")) {
        let g = o.split("/");
        for (; g[0] === ".."; )
          g.shift(), h -= 1;
        s.pathname = g.join("/");
      }
      i = h >= 0 ? t[h] : "/";
    }
    let c = Yu(s, i), d = o && o !== "/" && o.endsWith("/"), f = (a || o === ".") && n.endsWith("/");
    return !c.pathname.endsWith("/") && (d || f) && (c.pathname += "/"), c;
  }
  const Je = (e) => e.join("/").replace(/\/\/+/g, "/"), Ju = (e) => e.replace(/\/+$/, "").replace(/^\/*/, "/"), ed = (e) => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e, td = (e) => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;
  function nd(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e;
  }
  const Po = [
    "post",
    "put",
    "patch",
    "delete"
  ];
  new Set(Po);
  const rd = [
    "get",
    ...Po
  ];
  new Set(rd);
  function Qt() {
    return Qt = Object.assign ? Object.assign.bind() : function(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n)
          Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
      }
      return e;
    }, Qt.apply(this, arguments);
  }
  const ps = u.createContext(null), sd = u.createContext(null), st = u.createContext(null), Zn = u.createContext(null), Ze = u.createContext({
    outlet: null,
    matches: [],
    isDataRoute: false
  }), Oo = u.createContext(null);
  function ad(e, t) {
    let { relative: n } = t === void 0 ? {} : t;
    Pt() || ce(false);
    let { basename: r, navigator: s } = u.useContext(st), { hash: a, pathname: o, search: i } = Io(e, {
      relative: n
    }), c = o;
    return r !== "/" && (c = o === "/" ? r : Je([
      r,
      o
    ])), s.createHref({
      pathname: c,
      search: i,
      hash: a
    });
  }
  function Pt() {
    return u.useContext(Zn) != null;
  }
  qe = function() {
    return Pt() || ce(false), u.useContext(Zn).location;
  };
  function Lo(e) {
    u.useContext(st).static || u.useLayoutEffect(e);
  }
  ms = function() {
    let { isDataRoute: e } = u.useContext(Ze);
    return e ? bd() : od();
  };
  function od() {
    Pt() || ce(false);
    let e = u.useContext(ps), { basename: t, future: n, navigator: r } = u.useContext(st), { matches: s } = u.useContext(Ze), { pathname: a } = qe(), o = JSON.stringify(fs(s, n.v7_relativeSplatPath)), i = u.useRef(false);
    return Lo(() => {
      i.current = true;
    }), u.useCallback(function(d, f) {
      if (f === void 0 && (f = {}), !i.current)
        return;
      if (typeof d == "number") {
        r.go(d);
        return;
      }
      let h = hs(d, JSON.parse(o), a, f.relative === "path");
      e == null && t !== "/" && (h.pathname = h.pathname === "/" ? t : Je([
        t,
        h.pathname
      ])), (f.replace ? r.replace : r.push)(h, f.state, f);
    }, [
      t,
      r,
      o,
      a,
      e
    ]);
  }
  Kb = function() {
    let { matches: e } = u.useContext(Ze), t = e[e.length - 1];
    return t ? t.params : {};
  };
  function Io(e, t) {
    let { relative: n } = t === void 0 ? {} : t, { future: r } = u.useContext(st), { matches: s } = u.useContext(Ze), { pathname: a } = qe(), o = JSON.stringify(fs(s, r.v7_relativeSplatPath));
    return u.useMemo(() => hs(e, JSON.parse(o), a, n === "path"), [
      e,
      o,
      a,
      n
    ]);
  }
  function ld(e, t) {
    return id(e, t);
  }
  function id(e, t, n, r) {
    Pt() || ce(false);
    let { navigator: s } = u.useContext(st), { matches: a } = u.useContext(Ze), o = a[a.length - 1], i = o ? o.params : {};
    o && o.pathname;
    let c = o ? o.pathnameBase : "/";
    o && o.route;
    let d = qe(), f;
    if (t) {
      var h;
      let b = typeof t == "string" ? bt(t) : t;
      c === "/" || (h = b.pathname) != null && h.startsWith(c) || ce(false), f = b;
    } else
      f = d;
    let g = f.pathname || "/", m = g;
    if (c !== "/") {
      let b = c.replace(/^\//, "").split("/");
      m = "/" + g.replace(/^\//, "").split("/").slice(b.length).join("/");
    }
    let p = Fu(e, {
      pathname: m
    }), x = hd(p && p.map((b) => Object.assign({}, b, {
      params: Object.assign({}, i, b.params),
      pathname: Je([
        c,
        s.encodeLocation ? s.encodeLocation(b.pathname).pathname : b.pathname
      ]),
      pathnameBase: b.pathnameBase === "/" ? c : Je([
        c,
        s.encodeLocation ? s.encodeLocation(b.pathnameBase).pathname : b.pathnameBase
      ])
    })), a, n, r);
    return t && x ? u.createElement(Zn.Provider, {
      value: {
        location: Qt({
          pathname: "/",
          search: "",
          hash: "",
          state: null,
          key: "default"
        }, f),
        navigationType: Xe.Pop
      }
    }, x) : x;
  }
  function cd() {
    let e = xd(), t = nd(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e), n = e instanceof Error ? e.stack : null, s = {
      padding: "0.5rem",
      backgroundColor: "rgba(200,200,200, 0.5)"
    }, a = null;
    return u.createElement(u.Fragment, null, u.createElement("h2", null, "Unexpected Application Error!"), u.createElement("h3", {
      style: {
        fontStyle: "italic"
      }
    }, t), n ? u.createElement("pre", {
      style: s
    }, n) : null, a);
  }
  const ud = u.createElement(cd, null);
  class dd extends u.Component {
    constructor(t) {
      super(t), this.state = {
        location: t.location,
        revalidation: t.revalidation,
        error: t.error
      };
    }
    static getDerivedStateFromError(t) {
      return {
        error: t
      };
    }
    static getDerivedStateFromProps(t, n) {
      return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
        error: t.error,
        location: t.location,
        revalidation: t.revalidation
      } : {
        error: t.error !== void 0 ? t.error : n.error,
        location: n.location,
        revalidation: t.revalidation || n.revalidation
      };
    }
    componentDidCatch(t, n) {
      console.error("React Router caught the following error during render", t, n);
    }
    render() {
      return this.state.error !== void 0 ? u.createElement(Ze.Provider, {
        value: this.props.routeContext
      }, u.createElement(Oo.Provider, {
        value: this.state.error,
        children: this.props.component
      })) : this.props.children;
    }
  }
  function fd(e) {
    let { routeContext: t, match: n, children: r } = e, s = u.useContext(ps);
    return s && s.static && s.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (s.staticContext._deepestRenderedBoundaryId = n.route.id), u.createElement(Ze.Provider, {
      value: t
    }, r);
  }
  function hd(e, t, n, r) {
    var s;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
      var a;
      if (!n)
        return null;
      if (n.errors)
        e = n.matches;
      else if ((a = r) != null && a.v7_partialHydration && t.length === 0 && !n.initialized && n.matches.length > 0)
        e = n.matches;
      else
        return null;
    }
    let o = e, i = (s = n) == null ? void 0 : s.errors;
    if (i != null) {
      let f = o.findIndex((h) => h.route.id && (i == null ? void 0 : i[h.route.id]) !== void 0);
      f >= 0 || ce(false), o = o.slice(0, Math.min(o.length, f + 1));
    }
    let c = false, d = -1;
    if (n && r && r.v7_partialHydration)
      for (let f = 0; f < o.length; f++) {
        let h = o[f];
        if ((h.route.HydrateFallback || h.route.hydrateFallbackElement) && (d = f), h.route.id) {
          let { loaderData: g, errors: m } = n, p = h.route.loader && g[h.route.id] === void 0 && (!m || m[h.route.id] === void 0);
          if (h.route.lazy || p) {
            c = true, d >= 0 ? o = o.slice(0, d + 1) : o = [
              o[0]
            ];
            break;
          }
        }
      }
    return o.reduceRight((f, h, g) => {
      let m, p = false, x = null, b = null;
      n && (m = i && h.route.id ? i[h.route.id] : void 0, x = h.route.errorElement || ud, c && (d < 0 && g === 0 ? (vd("route-fallback", false), p = true, b = null) : d === g && (p = true, b = h.route.hydrateFallbackElement || null)));
      let y = t.concat(o.slice(0, g + 1)), v = () => {
        let w;
        return m ? w = x : p ? w = b : h.route.Component ? w = u.createElement(h.route.Component, null) : h.route.element ? w = h.route.element : w = f, u.createElement(fd, {
          match: h,
          routeContext: {
            outlet: f,
            matches: y,
            isDataRoute: n != null
          },
          children: w
        });
      };
      return n && (h.route.ErrorBoundary || h.route.errorElement || g === 0) ? u.createElement(dd, {
        location: n.location,
        revalidation: n.revalidation,
        component: x,
        error: m,
        children: v(),
        routeContext: {
          outlet: null,
          matches: y,
          isDataRoute: true
        }
      }) : v();
    }, null);
  }
  var Fo = function(e) {
    return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e;
  }(Fo || {}), Mn = function(e) {
    return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e;
  }(Mn || {});
  function pd(e) {
    let t = u.useContext(ps);
    return t || ce(false), t;
  }
  function md(e) {
    let t = u.useContext(sd);
    return t || ce(false), t;
  }
  function gd(e) {
    let t = u.useContext(Ze);
    return t || ce(false), t;
  }
  function Mo(e) {
    let t = gd(), n = t.matches[t.matches.length - 1];
    return n.route.id || ce(false), n.route.id;
  }
  function xd() {
    var e;
    let t = u.useContext(Oo), n = md(Mn.UseRouteError), r = Mo(Mn.UseRouteError);
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r];
  }
  function bd() {
    let { router: e } = pd(Fo.UseNavigateStable), t = Mo(Mn.UseNavigateStable), n = u.useRef(false);
    return Lo(() => {
      n.current = true;
    }), u.useCallback(function(s, a) {
      a === void 0 && (a = {}), n.current && (typeof s == "number" ? e.navigate(s) : e.navigate(s, Qt({
        fromRouteId: t
      }, a)));
    }, [
      e,
      t
    ]);
  }
  const ma = {};
  function vd(e, t, n) {
    !t && !ma[e] && (ma[e] = true);
  }
  function yd(e, t) {
    e == null ? void 0 : e.v7_startTransition, (e == null ? void 0 : e.v7_relativeSplatPath) === void 0 && (!t || t.v7_relativeSplatPath), t && (t.v7_fetcherPersist, t.v7_normalizeFormMethod, t.v7_partialHydration, t.v7_skipActionErrorRevalidation);
  }
  wd = function(e) {
    let { to: t, replace: n, state: r, relative: s } = e;
    Pt() || ce(false);
    let { future: a, static: o } = u.useContext(st), { matches: i } = u.useContext(Ze), { pathname: c } = qe(), d = ms(), f = hs(t, fs(i, a.v7_relativeSplatPath), c, s === "path"), h = JSON.stringify(f);
    return u.useEffect(() => d(JSON.parse(h), {
      replace: n,
      state: r,
      relative: s
    }), [
      d,
      h,
      s,
      n,
      r
    ]), null;
  };
  function Dr(e) {
    ce(false);
  }
  function kd(e) {
    let { basename: t = "/", children: n = null, location: r, navigationType: s = Xe.Pop, navigator: a, static: o = false, future: i } = e;
    Pt() && ce(false);
    let c = t.replace(/^\/*/, "/"), d = u.useMemo(() => ({
      basename: c,
      navigator: a,
      static: o,
      future: Qt({
        v7_relativeSplatPath: false
      }, i)
    }), [
      c,
      i,
      a,
      o
    ]);
    typeof r == "string" && (r = bt(r));
    let { pathname: f = "/", search: h = "", hash: g = "", state: m = null, key: p = "default" } = r, x = u.useMemo(() => {
      let b = ds(f, c);
      return b == null ? null : {
        location: {
          pathname: b,
          search: h,
          hash: g,
          state: m,
          key: p
        },
        navigationType: s
      };
    }, [
      c,
      f,
      h,
      g,
      m,
      p,
      s
    ]);
    return x == null ? null : u.createElement(st.Provider, {
      value: d
    }, u.createElement(Zn.Provider, {
      children: n,
      value: x
    }));
  }
  function Ed(e) {
    let { children: t, location: n } = e;
    return ld(_r(t), n);
  }
  new Promise(() => {
  });
  function _r(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return u.Children.forEach(e, (r, s) => {
      if (!u.isValidElement(r))
        return;
      let a = [
        ...t,
        s
      ];
      if (r.type === u.Fragment) {
        n.push.apply(n, _r(r.props.children, a));
        return;
      }
      r.type !== Dr && ce(false), !r.props.index || !r.props.children || ce(false);
      let o = {
        id: r.props.id || a.join("-"),
        caseSensitive: r.props.caseSensitive,
        element: r.props.element,
        Component: r.props.Component,
        index: r.props.index,
        path: r.props.path,
        loader: r.props.loader,
        action: r.props.action,
        errorElement: r.props.errorElement,
        ErrorBoundary: r.props.ErrorBoundary,
        hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
        shouldRevalidate: r.props.shouldRevalidate,
        handle: r.props.handle,
        lazy: r.props.lazy
      };
      r.props.children && (o.children = _r(r.props.children, a)), n.push(o);
    }), n;
  }
  function Br() {
    return Br = Object.assign ? Object.assign.bind() : function(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n)
          Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
      }
      return e;
    }, Br.apply(this, arguments);
  }
  function jd(e, t) {
    if (e == null)
      return {};
    var n = {}, r = Object.keys(e), s, a;
    for (a = 0; a < r.length; a++)
      s = r[a], !(t.indexOf(s) >= 0) && (n[s] = e[s]);
    return n;
  }
  function Nd(e) {
    return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey);
  }
  function Cd(e, t) {
    return e.button === 0 && (!t || t === "_self") && !Nd(e);
  }
  function Hr(e) {
    return e === void 0 && (e = ""), new URLSearchParams(typeof e == "string" || Array.isArray(e) || e instanceof URLSearchParams ? e : Object.keys(e).reduce((t, n) => {
      let r = e[n];
      return t.concat(Array.isArray(r) ? r.map((s) => [
        n,
        s
      ]) : [
        [
          n,
          r
        ]
      ]);
    }, []));
  }
  function Sd(e, t) {
    let n = Hr(e);
    return t && t.forEach((r, s) => {
      n.has(s) || t.getAll(s).forEach((a) => {
        n.append(s, a);
      });
    }), n;
  }
  const Td = [
    "onClick",
    "relative",
    "reloadDocument",
    "replace",
    "state",
    "target",
    "to",
    "preventScrollReset",
    "viewTransition"
  ], $d = "6";
  try {
    window.__reactRouterVersion = $d;
  } catch {
  }
  const Rd = "startTransition", ga = Rn[Rd];
  Yb = function(e) {
    let { basename: t, children: n, future: r, window: s } = e, a = u.useRef();
    a.current == null && (a.current = Ou({
      window: s,
      v5Compat: true
    }));
    let o = a.current, [i, c] = u.useState({
      action: o.action,
      location: o.location
    }), { v7_startTransition: d } = r || {}, f = u.useCallback((h) => {
      d && ga ? ga(() => c(h)) : c(h);
    }, [
      c,
      d
    ]);
    return u.useLayoutEffect(() => o.listen(f), [
      o,
      f
    ]), u.useEffect(() => yd(r), [
      r
    ]), u.createElement(kd, {
      basename: t,
      children: n,
      location: i.location,
      navigationType: i.action,
      navigator: o,
      future: r
    });
  };
  let Ad, Pd;
  Ad = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u";
  Pd = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;
  Dt = u.forwardRef(function(t, n) {
    let { onClick: r, relative: s, reloadDocument: a, replace: o, state: i, target: c, to: d, preventScrollReset: f, viewTransition: h } = t, g = jd(t, Td), { basename: m } = u.useContext(st), p, x = false;
    if (typeof d == "string" && Pd.test(d) && (p = d, Ad))
      try {
        let w = new URL(window.location.href), k = d.startsWith("//") ? new URL(w.protocol + d) : new URL(d), E = ds(k.pathname, m);
        k.origin === w.origin && E != null ? d = E + k.search + k.hash : x = true;
      } catch {
      }
    let b = ad(d, {
      relative: s
    }), y = Od(d, {
      replace: o,
      state: i,
      target: c,
      preventScrollReset: f,
      relative: s,
      viewTransition: h
    });
    function v(w) {
      r && r(w), w.defaultPrevented || y(w);
    }
    return u.createElement("a", Br({}, g, {
      href: p || b,
      onClick: x || a ? r : v,
      ref: n,
      target: c
    }));
  });
  var xa;
  (function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState";
  })(xa || (xa = {}));
  var ba;
  (function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration";
  })(ba || (ba = {}));
  function Od(e, t) {
    let { target: n, replace: r, state: s, preventScrollReset: a, relative: o, viewTransition: i } = t === void 0 ? {} : t, c = ms(), d = qe(), f = Io(e, {
      relative: o
    });
    return u.useCallback((h) => {
      if (Cd(h, n)) {
        h.preventDefault();
        let g = r !== void 0 ? r : Fn(d) === Fn(f);
        c(e, {
          replace: g,
          state: s,
          preventScrollReset: a,
          relative: o,
          viewTransition: i
        });
      }
    }, [
      d,
      c,
      f,
      r,
      s,
      n,
      e,
      a,
      o,
      i
    ]);
  }
  Xb = function(e) {
    let t = u.useRef(Hr(e)), n = u.useRef(false), r = qe(), s = u.useMemo(() => Sd(r.search, n.current ? null : t.current), [
      r.search
    ]), a = ms(), o = u.useCallback((i, c) => {
      const d = Hr(typeof i == "function" ? i(s) : i);
      n.current = true, a("?" + d, c);
    }, [
      a,
      s
    ]);
    return [
      s,
      o
    ];
  };
  function Ld({ children: e }) {
    const [t, n] = ee(), r = qe();
    return n.isLicensed() ? e : l.jsx(wd, {
      to: "/login",
      state: {
        from: r
      },
      replace: true
    });
  }
  const Do = typeof document < "u" ? j.useLayoutEffect : () => {
  };
  var yr;
  const Id = (yr = j.useInsertionEffect) !== null && yr !== void 0 ? yr : Do;
  function Fd(e) {
    const t = u.useRef(null);
    return Id(() => {
      t.current = e;
    }, [
      e
    ]), u.useCallback((...n) => {
      const r = t.current;
      return r == null ? void 0 : r(...n);
    }, []);
  }
  const at = (e) => {
    var t;
    return (t = e == null ? void 0 : e.ownerDocument) !== null && t !== void 0 ? t : document;
  }, ct = (e) => e && "window" in e && e.window === e ? e : at(e).defaultView || window;
  function Md(e) {
    return e !== null && typeof e == "object" && "nodeType" in e && typeof e.nodeType == "number";
  }
  function Dd(e) {
    return Md(e) && e.nodeType === Node.DOCUMENT_FRAGMENT_NODE && "host" in e;
  }
  let _d = false;
  function gs() {
    return _d;
  }
  function _o(e, t) {
    if (!gs())
      return t && e ? e.contains(t) : false;
    if (!e || !t)
      return false;
    let n = t;
    for (; n !== null; ) {
      if (n === e)
        return true;
      n.tagName === "SLOT" && n.assignedSlot ? n = n.assignedSlot.parentNode : Dd(n) ? n = n.host : n = n.parentNode;
    }
    return false;
  }
  const Ur = (e = document) => {
    var t;
    if (!gs())
      return e.activeElement;
    let n = e.activeElement;
    for (; n && "shadowRoot" in n && (!((t = n.shadowRoot) === null || t === void 0) && t.activeElement); )
      n = n.shadowRoot.activeElement;
    return n;
  };
  function Bo(e) {
    return gs() && e.target.shadowRoot && e.composedPath ? e.composedPath()[0] : e.target;
  }
  function Bd(e) {
    var t;
    if (typeof window > "u" || window.navigator == null)
      return false;
    let n = (t = window.navigator.userAgentData) === null || t === void 0 ? void 0 : t.brands;
    return Array.isArray(n) && n.some((r) => e.test(r.brand)) || e.test(window.navigator.userAgent);
  }
  function Hd(e) {
    var t;
    return typeof window < "u" && window.navigator != null ? e.test(((t = window.navigator.userAgentData) === null || t === void 0 ? void 0 : t.platform) || window.navigator.platform) : false;
  }
  function Ho(e) {
    let t = null;
    return () => (t == null && (t = e()), t);
  }
  const Ud = Ho(function() {
    return Hd(/^Mac/i);
  }), Vd = Ho(function() {
    return Bd(/Android/i);
  });
  function Uo() {
    let e = u.useRef(/* @__PURE__ */ new Map()), t = u.useCallback((s, a, o, i) => {
      let c = (i == null ? void 0 : i.once) ? (...d) => {
        e.current.delete(o), o(...d);
      } : o;
      e.current.set(o, {
        type: a,
        eventTarget: s,
        fn: c,
        options: i
      }), s.addEventListener(a, c, i);
    }, []), n = u.useCallback((s, a, o, i) => {
      var c;
      let d = ((c = e.current.get(o)) === null || c === void 0 ? void 0 : c.fn) || o;
      s.removeEventListener(a, d, i), e.current.delete(o);
    }, []), r = u.useCallback(() => {
      e.current.forEach((s, a) => {
        n(s.eventTarget, s.type, a, s.options);
      });
    }, [
      n
    ]);
    return u.useEffect(() => r, [
      r
    ]), {
      addGlobalListener: t,
      removeGlobalListener: n,
      removeAllGlobalListeners: r
    };
  }
  function Wd(e) {
    return e.pointerType === "" && e.isTrusted ? true : Vd() && e.pointerType ? e.type === "click" && e.buttons === 1 : e.detail === 0 && !e.pointerType;
  }
  function Vo(e) {
    let t = e;
    return t.nativeEvent = e, t.isDefaultPrevented = () => t.defaultPrevented, t.isPropagationStopped = () => t.cancelBubble, t.persist = () => {
    }, t;
  }
  function zd(e, t) {
    Object.defineProperty(e, "target", {
      value: t
    }), Object.defineProperty(e, "currentTarget", {
      value: t
    });
  }
  function Wo(e) {
    let t = u.useRef({
      isFocused: false,
      observer: null
    });
    Do(() => {
      const r = t.current;
      return () => {
        r.observer && (r.observer.disconnect(), r.observer = null);
      };
    }, []);
    let n = Fd((r) => {
      e == null ? void 0 : e(r);
    });
    return u.useCallback((r) => {
      if (r.target instanceof HTMLButtonElement || r.target instanceof HTMLInputElement || r.target instanceof HTMLTextAreaElement || r.target instanceof HTMLSelectElement) {
        t.current.isFocused = true;
        let s = r.target, a = (o) => {
          if (t.current.isFocused = false, s.disabled) {
            let i = Vo(o);
            n(i);
          }
          t.current.observer && (t.current.observer.disconnect(), t.current.observer = null);
        };
        s.addEventListener("focusout", a, {
          once: true
        }), t.current.observer = new MutationObserver(() => {
          if (t.current.isFocused && s.disabled) {
            var o;
            (o = t.current.observer) === null || o === void 0 || o.disconnect();
            let i = s === document.activeElement ? null : document.activeElement;
            s.dispatchEvent(new FocusEvent("blur", {
              relatedTarget: i
            })), s.dispatchEvent(new FocusEvent("focusout", {
              bubbles: true,
              relatedTarget: i
            }));
          }
        }), t.current.observer.observe(s, {
          attributes: true,
          attributeFilter: [
            "disabled"
          ]
        });
      }
    }, [
      n
    ]);
  }
  let Gd = false, ln = null, Vr = /* @__PURE__ */ new Set(), Gt = /* @__PURE__ */ new Map(), ft = false, Wr = false;
  const Zd = {
    Tab: true,
    Escape: true
  };
  function xs(e, t) {
    for (let n of Vr)
      n(e, t);
  }
  function qd(e) {
    return !(e.metaKey || !Ud() && e.altKey || e.ctrlKey || e.key === "Control" || e.key === "Shift" || e.key === "Meta");
  }
  function Dn(e) {
    ft = true, qd(e) && (ln = "keyboard", xs("keyboard", e));
  }
  function Ct(e) {
    ln = "pointer", (e.type === "mousedown" || e.type === "pointerdown") && (ft = true, xs("pointer", e));
  }
  function zo(e) {
    Wd(e) && (ft = true, ln = "virtual");
  }
  function Go(e) {
    e.target === window || e.target === document || Gd || !e.isTrusted || (!ft && !Wr && (ln = "virtual", xs("virtual", e)), ft = false, Wr = false);
  }
  function Zo() {
    ft = false, Wr = true;
  }
  function zr(e) {
    if (typeof window > "u" || typeof document > "u" || Gt.get(ct(e)))
      return;
    const t = ct(e), n = at(e);
    let r = t.HTMLElement.prototype.focus;
    t.HTMLElement.prototype.focus = function() {
      ft = true, r.apply(this, arguments);
    }, n.addEventListener("keydown", Dn, true), n.addEventListener("keyup", Dn, true), n.addEventListener("click", zo, true), t.addEventListener("focus", Go, true), t.addEventListener("blur", Zo, false), typeof PointerEvent < "u" && (n.addEventListener("pointerdown", Ct, true), n.addEventListener("pointermove", Ct, true), n.addEventListener("pointerup", Ct, true)), t.addEventListener("beforeunload", () => {
      qo(e);
    }, {
      once: true
    }), Gt.set(t, {
      focus: r
    });
  }
  const qo = (e, t) => {
    const n = ct(e), r = at(e);
    t && r.removeEventListener("DOMContentLoaded", t), Gt.has(n) && (n.HTMLElement.prototype.focus = Gt.get(n).focus, r.removeEventListener("keydown", Dn, true), r.removeEventListener("keyup", Dn, true), r.removeEventListener("click", zo, true), n.removeEventListener("focus", Go, true), n.removeEventListener("blur", Zo, false), typeof PointerEvent < "u" && (r.removeEventListener("pointerdown", Ct, true), r.removeEventListener("pointermove", Ct, true), r.removeEventListener("pointerup", Ct, true)), Gt.delete(n));
  };
  function Kd(e) {
    const t = at(e);
    let n;
    return t.readyState !== "loading" ? zr(e) : (n = () => {
      zr(e);
    }, t.addEventListener("DOMContentLoaded", n)), () => qo(e, n);
  }
  typeof document < "u" && Kd();
  function Ko() {
    return ln !== "pointer";
  }
  const Yd = /* @__PURE__ */ new Set([
    "checkbox",
    "radio",
    "range",
    "color",
    "file",
    "image",
    "button",
    "submit",
    "reset"
  ]);
  function Xd(e, t, n) {
    let r = at(n == null ? void 0 : n.target);
    const s = typeof window < "u" ? ct(n == null ? void 0 : n.target).HTMLInputElement : HTMLInputElement, a = typeof window < "u" ? ct(n == null ? void 0 : n.target).HTMLTextAreaElement : HTMLTextAreaElement, o = typeof window < "u" ? ct(n == null ? void 0 : n.target).HTMLElement : HTMLElement, i = typeof window < "u" ? ct(n == null ? void 0 : n.target).KeyboardEvent : KeyboardEvent;
    return e = e || r.activeElement instanceof s && !Yd.has(r.activeElement.type) || r.activeElement instanceof a || r.activeElement instanceof o && r.activeElement.isContentEditable, !(e && t === "keyboard" && n instanceof i && !Zd[n.key]);
  }
  function Qd(e, t, n) {
    zr(), u.useEffect(() => {
      let r = (s, a) => {
        Xd(!!(n == null ? void 0 : n.isTextInput), s, a) && e(Ko());
      };
      return Vr.add(r), () => {
        Vr.delete(r);
      };
    }, t);
  }
  function Jd(e) {
    let { isDisabled: t, onFocus: n, onBlur: r, onFocusChange: s } = e;
    const a = u.useCallback((c) => {
      if (c.target === c.currentTarget)
        return r && r(c), s && s(false), true;
    }, [
      r,
      s
    ]), o = Wo(a), i = u.useCallback((c) => {
      const d = at(c.target), f = d ? Ur(d) : Ur();
      c.target === c.currentTarget && f === Bo(c.nativeEvent) && (n && n(c), s && s(true), o(c));
    }, [
      s,
      n,
      o
    ]);
    return {
      focusProps: {
        onFocus: !t && (n || s || r) ? i : void 0,
        onBlur: !t && (r || s) ? a : void 0
      }
    };
  }
  function e0(e) {
    let { isDisabled: t, onBlurWithin: n, onFocusWithin: r, onFocusWithinChange: s } = e, a = u.useRef({
      isFocusWithin: false
    }), { addGlobalListener: o, removeAllGlobalListeners: i } = Uo(), c = u.useCallback((h) => {
      h.currentTarget.contains(h.target) && a.current.isFocusWithin && !h.currentTarget.contains(h.relatedTarget) && (a.current.isFocusWithin = false, i(), n && n(h), s && s(false));
    }, [
      n,
      s,
      a,
      i
    ]), d = Wo(c), f = u.useCallback((h) => {
      if (!h.currentTarget.contains(h.target))
        return;
      const g = at(h.target), m = Ur(g);
      if (!a.current.isFocusWithin && m === Bo(h.nativeEvent)) {
        r && r(h), s && s(true), a.current.isFocusWithin = true, d(h);
        let p = h.currentTarget;
        o(g, "focus", (x) => {
          if (a.current.isFocusWithin && !_o(p, x.target)) {
            let b = new g.defaultView.FocusEvent("blur", {
              relatedTarget: x.target
            });
            zd(b, p);
            let y = Vo(b);
            c(y);
          }
        }, {
          capture: true
        });
      }
    }, [
      r,
      s,
      d,
      o,
      c
    ]);
    return t ? {
      focusWithinProps: {
        onFocus: void 0,
        onBlur: void 0
      }
    } : {
      focusWithinProps: {
        onFocus: f,
        onBlur: c
      }
    };
  }
  let Gr = false, kn = 0;
  function t0() {
    Gr = true, setTimeout(() => {
      Gr = false;
    }, 50);
  }
  function va(e) {
    e.pointerType === "touch" && t0();
  }
  function n0() {
    if (!(typeof document > "u"))
      return kn === 0 && typeof PointerEvent < "u" && document.addEventListener("pointerup", va), kn++, () => {
        kn--, !(kn > 0) && typeof PointerEvent < "u" && document.removeEventListener("pointerup", va);
      };
  }
  function cn(e) {
    let { onHoverStart: t, onHoverChange: n, onHoverEnd: r, isDisabled: s } = e, [a, o] = u.useState(false), i = u.useRef({
      isHovered: false,
      ignoreEmulatedMouseEvents: false,
      pointerType: "",
      target: null
    }).current;
    u.useEffect(n0, []);
    let { addGlobalListener: c, removeAllGlobalListeners: d } = Uo(), { hoverProps: f, triggerHoverEnd: h } = u.useMemo(() => {
      let g = (x, b) => {
        if (i.pointerType = b, s || b === "touch" || i.isHovered || !x.currentTarget.contains(x.target))
          return;
        i.isHovered = true;
        let y = x.currentTarget;
        i.target = y, c(at(x.target), "pointerover", (v) => {
          i.isHovered && i.target && !_o(i.target, v.target) && m(v, v.pointerType);
        }, {
          capture: true
        }), t && t({
          type: "hoverstart",
          target: y,
          pointerType: b
        }), n && n(true), o(true);
      }, m = (x, b) => {
        let y = i.target;
        i.pointerType = "", i.target = null, !(b === "touch" || !i.isHovered || !y) && (i.isHovered = false, d(), r && r({
          type: "hoverend",
          target: y,
          pointerType: b
        }), n && n(false), o(false));
      }, p = {};
      return typeof PointerEvent < "u" && (p.onPointerEnter = (x) => {
        Gr && x.pointerType === "mouse" || g(x, x.pointerType);
      }, p.onPointerLeave = (x) => {
        !s && x.currentTarget.contains(x.target) && m(x, x.pointerType);
      }), {
        hoverProps: p,
        triggerHoverEnd: m
      };
    }, [
      t,
      n,
      r,
      s,
      i,
      c,
      d
    ]);
    return u.useEffect(() => {
      s && h({
        currentTarget: i.target
      }, i.pointerType);
    }, [
      s
    ]), {
      hoverProps: f,
      isHovered: a
    };
  }
  function Ot(e = {}) {
    let { autoFocus: t = false, isTextInput: n, within: r } = e, s = u.useRef({
      isFocused: false,
      isFocusVisible: t || Ko()
    }), [a, o] = u.useState(false), [i, c] = u.useState(() => s.current.isFocused && s.current.isFocusVisible), d = u.useCallback(() => c(s.current.isFocused && s.current.isFocusVisible), []), f = u.useCallback((m) => {
      s.current.isFocused = m, o(m), d();
    }, [
      d
    ]);
    Qd((m) => {
      s.current.isFocusVisible = m, d();
    }, [], {
      isTextInput: n
    });
    let { focusProps: h } = Jd({
      isDisabled: r,
      onFocusChange: f
    }), { focusWithinProps: g } = e0({
      isDisabled: !r,
      onFocusWithinChange: f
    });
    return {
      isFocused: a,
      isFocusVisible: i,
      focusProps: r ? g : h
    };
  }
  var r0 = Object.defineProperty, s0 = (e, t, n) => t in e ? r0(e, t, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: n
  }) : e[t] = n, wr = (e, t, n) => (s0(e, typeof t != "symbol" ? t + "" : t, n), n);
  let a0 = class {
    constructor() {
      wr(this, "current", this.detect()), wr(this, "handoffState", "pending"), wr(this, "currentId", 0);
    }
    set(t) {
      this.current !== t && (this.handoffState = "pending", this.currentId = 0, this.current = t);
    }
    reset() {
      this.set(this.detect());
    }
    nextId() {
      return ++this.currentId;
    }
    get isServer() {
      return this.current === "server";
    }
    get isClient() {
      return this.current === "client";
    }
    detect() {
      return typeof window > "u" || typeof document > "u" ? "server" : "client";
    }
    handoff() {
      this.handoffState === "pending" && (this.handoffState = "complete");
    }
    get isHandoffComplete() {
      return this.handoffState === "complete";
    }
  }, Fe = new a0();
  function ot(e) {
    var t;
    return Fe.isServer ? null : e == null ? document : (t = e == null ? void 0 : e.ownerDocument) != null ? t : document;
  }
  function ht(e) {
    var t, n;
    return Fe.isServer ? null : e == null ? document : (n = (t = e == null ? void 0 : e.getRootNode) == null ? void 0 : t.call(e)) != null ? n : document;
  }
  function et(e) {
    var t, n;
    return (n = (t = ht(e)) == null ? void 0 : t.activeElement) != null ? n : null;
  }
  function bs(e) {
    return et(e) === e;
  }
  function un(e) {
    typeof queueMicrotask == "function" ? queueMicrotask(e) : Promise.resolve().then(e).catch((t) => setTimeout(() => {
      throw t;
    }));
  }
  function Se() {
    let e = [], t = {
      addEventListener(n, r, s, a) {
        return n.addEventListener(r, s, a), t.add(() => n.removeEventListener(r, s, a));
      },
      requestAnimationFrame(...n) {
        let r = requestAnimationFrame(...n);
        return t.add(() => cancelAnimationFrame(r));
      },
      nextFrame(...n) {
        return t.requestAnimationFrame(() => t.requestAnimationFrame(...n));
      },
      setTimeout(...n) {
        let r = setTimeout(...n);
        return t.add(() => clearTimeout(r));
      },
      microTask(...n) {
        let r = {
          current: true
        };
        return un(() => {
          r.current && n[0]();
        }), t.add(() => {
          r.current = false;
        });
      },
      style(n, r, s) {
        let a = n.style.getPropertyValue(r);
        return Object.assign(n.style, {
          [r]: s
        }), this.add(() => {
          Object.assign(n.style, {
            [r]: a
          });
        });
      },
      group(n) {
        let r = Se();
        return n(r), this.add(() => r.dispose());
      },
      add(n) {
        return e.includes(n) || e.push(n), () => {
          let r = e.indexOf(n);
          if (r >= 0)
            for (let s of e.splice(r, 1))
              s();
        };
      },
      dispose() {
        for (let n of e.splice(0))
          n();
      }
    };
    return t;
  }
  function Ke() {
    let [e] = u.useState(Se);
    return u.useEffect(() => () => e.dispose(), [
      e
    ]), e;
  }
  let X = (e, t) => {
    Fe.isServer ? u.useEffect(e, t) : u.useLayoutEffect(e, t);
  };
  function ye(e) {
    let t = u.useRef(e);
    return X(() => {
      t.current = e;
    }, [
      e
    ]), t;
  }
  let R = function(e) {
    let t = ye(e);
    return j.useCallback((...n) => t.current(...n), [
      t
    ]);
  };
  function o0(e) {
    let t = e.width / 2, n = e.height / 2;
    return {
      top: e.clientY - n,
      right: e.clientX + t,
      bottom: e.clientY + n,
      left: e.clientX - t
    };
  }
  function l0(e, t) {
    return !(!e || !t || e.right < t.left || e.left > t.right || e.bottom < t.top || e.top > t.bottom);
  }
  function qn({ disabled: e = false } = {}) {
    let t = u.useRef(null), [n, r] = u.useState(false), s = Ke(), a = R(() => {
      t.current = null, r(false), s.dispose();
    }), o = R((i) => {
      if (s.dispose(), t.current === null) {
        t.current = i.currentTarget, r(true);
        {
          let c = ot(i.currentTarget);
          s.addEventListener(c, "pointerup", a, false), s.addEventListener(c, "pointermove", (d) => {
            if (t.current) {
              let f = o0(d);
              r(l0(f, t.current.getBoundingClientRect()));
            }
          }, false), s.addEventListener(c, "pointercancel", a, false);
        }
      }
    });
    return {
      pressed: n,
      pressProps: e ? {} : {
        onPointerDown: o,
        onPointerUp: a,
        onClick: a
      }
    };
  }
  function ae(e) {
    return u.useMemo(() => e, Object.values(e));
  }
  let i0 = u.createContext(void 0);
  function Kn() {
    return u.useContext(i0);
  }
  function Zr(...e) {
    return Array.from(new Set(e.flatMap((t) => typeof t == "string" ? t.split(" ") : []))).filter(Boolean).join(" ");
  }
  function re(e, t, ...n) {
    if (e in t) {
      let s = t[e];
      return typeof s == "function" ? s(...n) : s;
    }
    let r = new Error(`Tried to handle "${e}" but there is no handler defined. Only defined handlers are: ${Object.keys(t).map((s) => `"${s}"`).join(", ")}.`);
    throw Error.captureStackTrace && Error.captureStackTrace(r, re), r;
  }
  var Ce = ((e) => (e[e.None = 0] = "None", e[e.RenderStrategy = 1] = "RenderStrategy", e[e.Static = 2] = "Static", e))(Ce || {}), Qe = ((e) => (e[e.Unmount = 0] = "Unmount", e[e.Hidden = 1] = "Hidden", e))(Qe || {});
  function J() {
    let e = u0();
    return u.useCallback((t) => c0({
      mergeRefs: e,
      ...t
    }), [
      e
    ]);
  }
  function c0({ ourProps: e, theirProps: t, slot: n, defaultTag: r, features: s, visible: a = true, name: o, mergeRefs: i }) {
    i = i ?? d0;
    let c = Yo(t, e);
    if (a)
      return En(c, n, r, o, i);
    let d = s ?? 0;
    if (d & 2) {
      let { static: f = false, ...h } = c;
      if (f)
        return En(h, n, r, o, i);
    }
    if (d & 1) {
      let { unmount: f = true, ...h } = c;
      return re(f ? 0 : 1, {
        0() {
          return null;
        },
        1() {
          return En({
            ...h,
            hidden: true,
            style: {
              display: "none"
            }
          }, n, r, o, i);
        }
      });
    }
    return En(c, n, r, o, i);
  }
  function En(e, t = {}, n, r, s) {
    let { as: a = n, children: o, refName: i = "ref", ...c } = kr(e, [
      "unmount",
      "static"
    ]), d = e.ref !== void 0 ? {
      [i]: e.ref
    } : {}, f = typeof o == "function" ? o(t) : o;
    "className" in c && c.className && typeof c.className == "function" && (c.className = c.className(t)), c["aria-labelledby"] && c["aria-labelledby"] === c.id && (c["aria-labelledby"] = void 0);
    let h = {};
    if (t) {
      let g = false, m = [];
      for (let [p, x] of Object.entries(t))
        typeof x == "boolean" && (g = true), x === true && m.push(p.replace(/([A-Z])/g, (b) => `-${b.toLowerCase()}`));
      if (g) {
        h["data-headlessui-state"] = m.join(" ");
        for (let p of m)
          h[`data-${p}`] = "";
      }
    }
    if (Zt(a) && (Object.keys(Ye(c)).length > 0 || Object.keys(Ye(h)).length > 0))
      if (!u.isValidElement(f) || Array.isArray(f) && f.length > 1 || h0(f)) {
        if (Object.keys(Ye(c)).length > 0)
          throw new Error([
            'Passing props on "Fragment"!',
            "",
            `The current component <${r} /> is rendering a "Fragment".`,
            "However we need to passthrough the following props:",
            Object.keys(Ye(c)).concat(Object.keys(Ye(h))).map((g) => `  - ${g}`).join(`
`),
            "",
            "You can apply a few solutions:",
            [
              'Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".',
              "Render a single element as the child so that we can forward the props onto that element."
            ].map((g) => `  - ${g}`).join(`
`)
          ].join(`
`));
      } else {
        let g = f.props, m = g == null ? void 0 : g.className, p = typeof m == "function" ? (...y) => Zr(m(...y), c.className) : Zr(m, c.className), x = p ? {
          className: p
        } : {}, b = Yo(f.props, Ye(kr(c, [
          "ref"
        ])));
        for (let y in h)
          y in b && delete h[y];
        return u.cloneElement(f, Object.assign({}, b, h, d, {
          ref: s(f0(f), d.ref)
        }, x));
      }
    return u.createElement(a, Object.assign({}, kr(c, [
      "ref"
    ]), !Zt(a) && d, !Zt(a) && h), f);
  }
  function u0() {
    let e = u.useRef([]), t = u.useCallback((n) => {
      for (let r of e.current)
        r != null && (typeof r == "function" ? r(n) : r.current = n);
    }, []);
    return (...n) => {
      if (!n.every((r) => r == null))
        return e.current = n, t;
    };
  }
  function d0(...e) {
    return e.every((t) => t == null) ? void 0 : (t) => {
      for (let n of e)
        n != null && (typeof n == "function" ? n(t) : n.current = t);
    };
  }
  function Yo(...e) {
    if (e.length === 0)
      return {};
    if (e.length === 1)
      return e[0];
    let t = {}, n = {};
    for (let r of e)
      for (let s in r)
        s.startsWith("on") && typeof r[s] == "function" ? (n[s] != null || (n[s] = []), n[s].push(r[s])) : t[s] = r[s];
    if (t.disabled || t["aria-disabled"])
      for (let r in n)
        /^(on(?:Click|Pointer|Mouse|Key)(?:Down|Up|Press)?)$/.test(r) && (n[r] = [
          (s) => {
            var a;
            return (a = s == null ? void 0 : s.preventDefault) == null ? void 0 : a.call(s);
          }
        ]);
    for (let r in n)
      Object.assign(t, {
        [r](s, ...a) {
          let o = n[r];
          for (let i of o) {
            if ((s instanceof Event || (s == null ? void 0 : s.nativeEvent) instanceof Event) && s.defaultPrevented)
              return;
            i(s, ...a);
          }
        }
      });
    return t;
  }
  function Ge(...e) {
    if (e.length === 0)
      return {};
    if (e.length === 1)
      return e[0];
    let t = {}, n = {};
    for (let r of e)
      for (let s in r)
        s.startsWith("on") && typeof r[s] == "function" ? (n[s] != null || (n[s] = []), n[s].push(r[s])) : t[s] = r[s];
    for (let r in n)
      Object.assign(t, {
        [r](...s) {
          let a = n[r];
          for (let o of a)
            o == null ? void 0 : o(...s);
        }
      });
    return t;
  }
  function Q(e) {
    var t;
    return Object.assign(u.forwardRef(e), {
      displayName: (t = e.displayName) != null ? t : e.name
    });
  }
  function Ye(e) {
    let t = Object.assign({}, e);
    for (let n in t)
      t[n] === void 0 && delete t[n];
    return t;
  }
  function kr(e, t = []) {
    let n = Object.assign({}, e);
    for (let r of t)
      r in n && delete n[r];
    return n;
  }
  function f0(e) {
    return j.version.split(".")[0] >= "19" ? e.props.ref : e.ref;
  }
  function Zt(e) {
    return e === u.Fragment || e === Symbol.for("react.fragment");
  }
  function h0(e) {
    return Zt(e.type);
  }
  function Xo(e, t, n) {
    let [r, s] = u.useState(n), a = e !== void 0, o = u.useRef(a), i = u.useRef(false), c = u.useRef(false);
    return a && !o.current && !i.current ? (i.current = true, o.current = a, console.error("A component is changing from uncontrolled to controlled. This may be caused by the value changing from undefined to a defined value, which should not happen.")) : !a && o.current && !c.current && (c.current = true, o.current = a, console.error("A component is changing from controlled to uncontrolled. This may be caused by the value changing from a defined value to undefined, which should not happen.")), [
      a ? e : r,
      R((d) => (a || xe.flushSync(() => s(d)), t == null ? void 0 : t(d)))
    ];
  }
  function Qo(e) {
    let [t] = u.useState(e);
    return t;
  }
  function Jo(e = {}, t = null, n = []) {
    for (let [r, s] of Object.entries(e))
      tl(n, el(t, r), s);
    return n;
  }
  function el(e, t) {
    return e ? e + "[" + t + "]" : t;
  }
  function tl(e, t, n) {
    if (Array.isArray(n))
      for (let [r, s] of n.entries())
        tl(e, el(t, r.toString()), s);
    else
      n instanceof Date ? e.push([
        t,
        n.toISOString()
      ]) : typeof n == "boolean" ? e.push([
        t,
        n ? "1" : "0"
      ]) : typeof n == "string" ? e.push([
        t,
        n
      ]) : typeof n == "number" ? e.push([
        t,
        `${n}`
      ]) : n == null ? e.push([
        t,
        ""
      ]) : m0(n) && !u.isValidElement(n) && Jo(n, t, e);
  }
  function p0(e) {
    var t, n;
    let r = (t = e == null ? void 0 : e.form) != null ? t : e.closest("form");
    if (r) {
      for (let s of r.elements)
        if (s !== e && (s.tagName === "INPUT" && s.type === "submit" || s.tagName === "BUTTON" && s.type === "submit" || s.nodeName === "INPUT" && s.type === "image")) {
          s.click();
          return;
        }
      (n = r.requestSubmit) == null || n.call(r);
    }
  }
  function m0(e) {
    if (Object.prototype.toString.call(e) !== "[object Object]")
      return false;
    let t = Object.getPrototypeOf(e);
    return t === null || Object.getPrototypeOf(t) === null;
  }
  let g0 = "span";
  var _e = ((e) => (e[e.None = 1] = "None", e[e.Focusable = 2] = "Focusable", e[e.Hidden = 4] = "Hidden", e))(_e || {});
  function x0(e, t) {
    var n;
    let { features: r = 1, ...s } = e, a = {
      ref: t,
      "aria-hidden": (r & 2) === 2 ? true : (n = s["aria-hidden"]) != null ? n : void 0,
      hidden: (r & 4) === 4 ? true : void 0,
      style: {
        position: "fixed",
        top: 1,
        left: 1,
        width: 1,
        height: 0,
        padding: 0,
        margin: -1,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        borderWidth: "0",
        ...(r & 4) === 4 && (r & 2) !== 2 && {
          display: "none"
        }
      }
    };
    return J()({
      ourProps: a,
      theirProps: s,
      slot: {},
      defaultTag: g0,
      name: "Hidden"
    });
  }
  let Be = Q(x0), b0 = u.createContext(null);
  function v0({ children: e }) {
    let t = u.useContext(b0);
    if (!t)
      return j.createElement(j.Fragment, null, e);
    let { target: n } = t;
    return n ? xe.createPortal(j.createElement(j.Fragment, null, e), n) : null;
  }
  function nl({ data: e, form: t, disabled: n, onReset: r, overrides: s }) {
    let [a, o] = u.useState(null), i = Ke();
    return u.useEffect(() => {
      if (r && a)
        return i.addEventListener(a, "reset", r);
    }, [
      a,
      t,
      r
    ]), j.createElement(v0, null, j.createElement(y0, {
      setForm: o,
      formId: t
    }), Jo(e).map(([c, d]) => j.createElement(Be, {
      features: _e.Hidden,
      ...Ye({
        key: c,
        as: "input",
        type: "hidden",
        hidden: true,
        readOnly: true,
        form: t,
        disabled: n,
        name: c,
        value: d,
        ...s
      })
    })));
  }
  function y0({ setForm: e, formId: t }) {
    return u.useEffect(() => {
      if (t) {
        let n = document.getElementById(t);
        n && e(n);
      }
    }, [
      e,
      t
    ]), t ? null : j.createElement(Be, {
      features: _e.Hidden,
      as: "input",
      type: "hidden",
      hidden: true,
      readOnly: true,
      ref: (n) => {
        if (!n)
          return;
        let r = n.closest("form");
        r && e(r);
      }
    });
  }
  let w0 = u.createContext(void 0);
  function vs() {
    return u.useContext(w0);
  }
  function rl(e) {
    return typeof e != "object" || e === null ? false : "nodeType" in e;
  }
  function We(e) {
    return rl(e) && "tagName" in e;
  }
  function ve(e) {
    return We(e) && "accessKey" in e;
  }
  function Le(e) {
    return We(e) && "tabIndex" in e;
  }
  function k0(e) {
    return We(e) && "style" in e;
  }
  function E0(e) {
    return ve(e) && e.nodeName === "IFRAME";
  }
  function _n(e) {
    return ve(e) && e.nodeName === "INPUT";
  }
  function qr(e) {
    return ve(e) && e.nodeName === "LABEL";
  }
  function j0(e) {
    return ve(e) && e.nodeName === "FIELDSET";
  }
  function sl(e) {
    return ve(e) && e.nodeName === "LEGEND";
  }
  function N0(e) {
    return We(e) ? e.matches('a[href],audio[controls],button,details,embed,iframe,img[usemap],input:not([type="hidden"]),label,select,textarea,video[controls]') : false;
  }
  function Jt(e) {
    let t = e.parentElement, n = null;
    for (; t && !j0(t); )
      sl(t) && (n = t), t = t.parentElement;
    let r = (t == null ? void 0 : t.getAttribute("disabled")) === "";
    return r && C0(n) ? false : r;
  }
  function C0(e) {
    if (!e)
      return false;
    let t = e.previousElementSibling;
    for (; t !== null; ) {
      if (sl(t))
        return false;
      t = t.previousElementSibling;
    }
    return true;
  }
  let al = Symbol();
  function ol(e, t = true) {
    return Object.assign(e, {
      [al]: t
    });
  }
  function ne(...e) {
    let t = u.useRef(e);
    u.useEffect(() => {
      t.current = e;
    }, [
      e
    ]);
    let n = R((r) => {
      for (let s of t.current)
        s != null && (typeof s == "function" ? s(r) : s.current = r);
    });
    return e.every((r) => r == null || (r == null ? void 0 : r[al])) ? void 0 : n;
  }
  let Yn = u.createContext(null);
  Yn.displayName = "DescriptionContext";
  function ll() {
    let e = u.useContext(Yn);
    if (e === null) {
      let t = new Error("You used a <Description /> component, but it is not inside a relevant parent.");
      throw Error.captureStackTrace && Error.captureStackTrace(t, ll), t;
    }
    return e;
  }
  function il() {
    var e, t;
    return (t = (e = u.useContext(Yn)) == null ? void 0 : e.value) != null ? t : void 0;
  }
  function cl() {
    let [e, t] = u.useState([]);
    return [
      e.length > 0 ? e.join(" ") : void 0,
      u.useMemo(() => function(n) {
        let r = R((a) => (t((o) => [
          ...o,
          a
        ]), () => t((o) => {
          let i = o.slice(), c = i.indexOf(a);
          return c !== -1 && i.splice(c, 1), i;
        }))), s = u.useMemo(() => ({
          register: r,
          slot: n.slot,
          name: n.name,
          props: n.props,
          value: n.value
        }), [
          r,
          n.slot,
          n.name,
          n.props,
          n.value
        ]);
        return j.createElement(Yn.Provider, {
          value: s
        }, n.children);
      }, [
        t
      ])
    ];
  }
  let S0 = "p";
  function T0(e, t) {
    let n = u.useId(), r = Kn(), { id: s = `headlessui-description-${n}`, ...a } = e, o = ll(), i = ne(t);
    X(() => o.register(s), [
      s,
      o.register
    ]);
    let c = ae({
      ...o.slot,
      disabled: r || false
    }), d = {
      ref: i,
      ...o.props,
      id: s
    };
    return J()({
      ourProps: d,
      theirProps: a,
      slot: c,
      defaultTag: S0,
      name: o.name || "Description"
    });
  }
  let $0 = Q(T0), ul = Object.assign($0, {});
  var Y = ((e) => (e.Space = " ", e.Enter = "Enter", e.Escape = "Escape", e.Backspace = "Backspace", e.Delete = "Delete", e.ArrowLeft = "ArrowLeft", e.ArrowUp = "ArrowUp", e.ArrowRight = "ArrowRight", e.ArrowDown = "ArrowDown", e.Home = "Home", e.End = "End", e.PageUp = "PageUp", e.PageDown = "PageDown", e.Tab = "Tab", e))(Y || {});
  let Xn = u.createContext(null);
  Xn.displayName = "LabelContext";
  function dl() {
    let e = u.useContext(Xn);
    if (e === null) {
      let t = new Error("You used a <Label /> component, but it is not inside a relevant parent.");
      throw Error.captureStackTrace && Error.captureStackTrace(t, dl), t;
    }
    return e;
  }
  function dn(e) {
    var t, n, r;
    let s = (n = (t = u.useContext(Xn)) == null ? void 0 : t.value) != null ? n : void 0;
    return ((r = e == null ? void 0 : e.length) != null ? r : 0) > 0 ? [
      s,
      ...e
    ].filter(Boolean).join(" ") : s;
  }
  function fl({ inherit: e = false } = {}) {
    let t = dn(), [n, r] = u.useState([]), s = e ? [
      t,
      ...n
    ].filter(Boolean) : n;
    return [
      s.length > 0 ? s.join(" ") : void 0,
      u.useMemo(() => function(a) {
        let o = R((c) => (r((d) => [
          ...d,
          c
        ]), () => r((d) => {
          let f = d.slice(), h = f.indexOf(c);
          return h !== -1 && f.splice(h, 1), f;
        }))), i = u.useMemo(() => ({
          register: o,
          slot: a.slot,
          name: a.name,
          props: a.props,
          value: a.value
        }), [
          o,
          a.slot,
          a.name,
          a.props,
          a.value
        ]);
        return j.createElement(Xn.Provider, {
          value: i
        }, a.children);
      }, [
        r
      ])
    ];
  }
  let R0 = "label";
  function A0(e, t) {
    var n;
    let r = u.useId(), s = dl(), a = vs(), o = Kn(), { id: i = `headlessui-label-${r}`, htmlFor: c = a ?? ((n = s.props) == null ? void 0 : n.htmlFor), passive: d = false, ...f } = e, h = ne(t);
    X(() => s.register(i), [
      i,
      s.register
    ]);
    let g = R((x) => {
      let b = x.currentTarget;
      if (!(x.target !== x.currentTarget && N0(x.target)) && (qr(b) && x.preventDefault(), s.props && "onClick" in s.props && typeof s.props.onClick == "function" && s.props.onClick(x), qr(b))) {
        let y = document.getElementById(b.htmlFor);
        if (y) {
          let v = y.getAttribute("disabled");
          if (v === "true" || v === "")
            return;
          let w = y.getAttribute("aria-disabled");
          if (w === "true" || w === "")
            return;
          (_n(y) && (y.type === "file" || y.type === "radio" || y.type === "checkbox") || y.role === "radio" || y.role === "checkbox" || y.role === "switch") && y.click(), y.focus({
            preventScroll: true
          });
        }
      }
    }), m = ae({
      ...s.slot,
      disabled: o || false
    }), p = {
      ref: h,
      ...s.props,
      id: i,
      htmlFor: c,
      onClick: g
    };
    return d && ("onClick" in p && (delete p.htmlFor, delete p.onClick), "onClick" in f && delete f.onClick), J()({
      ourProps: p,
      theirProps: f,
      slot: m,
      defaultTag: c ? R0 : "div",
      name: s.name || "Label"
    });
  }
  let P0 = Q(A0), hl = Object.assign(P0, {}), O0 = u.createContext(() => {
  });
  function ys({ value: e, children: t }) {
    return j.createElement(O0.Provider, {
      value: e
    }, t);
  }
  function wt(e, t, n) {
    let r = n.initialDeps ?? [], s;
    function a() {
      var o, i, c, d;
      let f;
      n.key && ((o = n.debug) != null && o.call(n)) && (f = Date.now());
      const h = e();
      if (!(h.length !== r.length || h.some((p, x) => r[x] !== p)))
        return s;
      r = h;
      let m;
      if (n.key && ((i = n.debug) != null && i.call(n)) && (m = Date.now()), s = t(...h), n.key && ((c = n.debug) != null && c.call(n))) {
        const p = Math.round((Date.now() - f) * 100) / 100, x = Math.round((Date.now() - m) * 100) / 100, b = x / 16, y = (v, w) => {
          for (v = String(v); v.length < w; )
            v = " " + v;
          return v;
        };
        console.info(`%c\u23F1 ${y(x, 5)} /${y(p, 5)} ms`, `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * b, 120))}deg 100% 31%);`, n == null ? void 0 : n.key);
      }
      return (d = n == null ? void 0 : n.onChange) == null || d.call(n, s), s;
    }
    return a.updateDeps = (o) => {
      r = o;
    }, a;
  }
  function ya(e, t) {
    if (e === void 0)
      throw new Error(`Unexpected undefined${t ? `: ${t}` : ""}`);
    return e;
  }
  const L0 = (e, t) => Math.abs(e - t) < 1.01, I0 = (e, t, n) => {
    let r;
    return function(...s) {
      e.clearTimeout(r), r = e.setTimeout(() => t.apply(this, s), n);
    };
  }, wa = (e) => {
    const { offsetWidth: t, offsetHeight: n } = e;
    return {
      width: t,
      height: n
    };
  }, F0 = (e) => e, M0 = (e) => {
    const t = Math.max(e.startIndex - e.overscan, 0), n = Math.min(e.endIndex + e.overscan, e.count - 1), r = [];
    for (let s = t; s <= n; s++)
      r.push(s);
    return r;
  }, D0 = (e, t) => {
    const n = e.scrollElement;
    if (!n)
      return;
    const r = e.targetWindow;
    if (!r)
      return;
    const s = (o) => {
      const { width: i, height: c } = o;
      t({
        width: Math.round(i),
        height: Math.round(c)
      });
    };
    if (s(wa(n)), !r.ResizeObserver)
      return () => {
      };
    const a = new r.ResizeObserver((o) => {
      const i = () => {
        const c = o[0];
        if (c == null ? void 0 : c.borderBoxSize) {
          const d = c.borderBoxSize[0];
          if (d) {
            s({
              width: d.inlineSize,
              height: d.blockSize
            });
            return;
          }
        }
        s(wa(n));
      };
      e.options.useAnimationFrameWithResizeObserver ? requestAnimationFrame(i) : i();
    });
    return a.observe(n, {
      box: "border-box"
    }), () => {
      a.unobserve(n);
    };
  }, ka = {
    passive: true
  }, Ea = typeof window > "u" ? true : "onscrollend" in window, _0 = (e, t) => {
    const n = e.scrollElement;
    if (!n)
      return;
    const r = e.targetWindow;
    if (!r)
      return;
    let s = 0;
    const a = e.options.useScrollendEvent && Ea ? () => {
    } : I0(r, () => {
      t(s, false);
    }, e.options.isScrollingResetDelay), o = (f) => () => {
      const { horizontal: h, isRtl: g } = e.options;
      s = h ? n.scrollLeft * (g && -1 || 1) : n.scrollTop, a(), t(s, f);
    }, i = o(true), c = o(false);
    c(), n.addEventListener("scroll", i, ka);
    const d = e.options.useScrollendEvent && Ea;
    return d && n.addEventListener("scrollend", c, ka), () => {
      n.removeEventListener("scroll", i), d && n.removeEventListener("scrollend", c);
    };
  }, B0 = (e, t, n) => {
    if (t == null ? void 0 : t.borderBoxSize) {
      const r = t.borderBoxSize[0];
      if (r)
        return Math.round(r[n.options.horizontal ? "inlineSize" : "blockSize"]);
    }
    return e[n.options.horizontal ? "offsetWidth" : "offsetHeight"];
  }, H0 = (e, { adjustments: t = 0, behavior: n }, r) => {
    var s, a;
    const o = e + t;
    (a = (s = r.scrollElement) == null ? void 0 : s.scrollTo) == null || a.call(s, {
      [r.options.horizontal ? "left" : "top"]: o,
      behavior: n
    });
  };
  class U0 {
    constructor(t) {
      this.unsubs = [], this.scrollElement = null, this.targetWindow = null, this.isScrolling = false, this.measurementsCache = [], this.itemSizeCache = /* @__PURE__ */ new Map(), this.pendingMeasuredCacheIndexes = [], this.scrollRect = null, this.scrollOffset = null, this.scrollDirection = null, this.scrollAdjustments = 0, this.elementsCache = /* @__PURE__ */ new Map(), this.observer = (() => {
        let n = null;
        const r = () => n || (!this.targetWindow || !this.targetWindow.ResizeObserver ? null : n = new this.targetWindow.ResizeObserver((s) => {
          s.forEach((a) => {
            const o = () => {
              this._measureElement(a.target, a);
            };
            this.options.useAnimationFrameWithResizeObserver ? requestAnimationFrame(o) : o();
          });
        }));
        return {
          disconnect: () => {
            var s;
            (s = r()) == null || s.disconnect(), n = null;
          },
          observe: (s) => {
            var a;
            return (a = r()) == null ? void 0 : a.observe(s, {
              box: "border-box"
            });
          },
          unobserve: (s) => {
            var a;
            return (a = r()) == null ? void 0 : a.unobserve(s);
          }
        };
      })(), this.range = null, this.setOptions = (n) => {
        Object.entries(n).forEach(([r, s]) => {
          typeof s > "u" && delete n[r];
        }), this.options = {
          debug: false,
          initialOffset: 0,
          overscan: 1,
          paddingStart: 0,
          paddingEnd: 0,
          scrollPaddingStart: 0,
          scrollPaddingEnd: 0,
          horizontal: false,
          getItemKey: F0,
          rangeExtractor: M0,
          onChange: () => {
          },
          measureElement: B0,
          initialRect: {
            width: 0,
            height: 0
          },
          scrollMargin: 0,
          gap: 0,
          indexAttribute: "data-index",
          initialMeasurementsCache: [],
          lanes: 1,
          isScrollingResetDelay: 150,
          enabled: true,
          isRtl: false,
          useScrollendEvent: false,
          useAnimationFrameWithResizeObserver: false,
          ...n
        };
      }, this.notify = (n) => {
        var r, s;
        (s = (r = this.options).onChange) == null || s.call(r, this, n);
      }, this.maybeNotify = wt(() => (this.calculateRange(), [
        this.isScrolling,
        this.range ? this.range.startIndex : null,
        this.range ? this.range.endIndex : null
      ]), (n) => {
        this.notify(n);
      }, {
        key: false,
        debug: () => this.options.debug,
        initialDeps: [
          this.isScrolling,
          this.range ? this.range.startIndex : null,
          this.range ? this.range.endIndex : null
        ]
      }), this.cleanup = () => {
        this.unsubs.filter(Boolean).forEach((n) => n()), this.unsubs = [], this.observer.disconnect(), this.scrollElement = null, this.targetWindow = null;
      }, this._didMount = () => () => {
        this.cleanup();
      }, this._willUpdate = () => {
        var n;
        const r = this.options.enabled ? this.options.getScrollElement() : null;
        if (this.scrollElement !== r) {
          if (this.cleanup(), !r) {
            this.maybeNotify();
            return;
          }
          this.scrollElement = r, this.scrollElement && "ownerDocument" in this.scrollElement ? this.targetWindow = this.scrollElement.ownerDocument.defaultView : this.targetWindow = ((n = this.scrollElement) == null ? void 0 : n.window) ?? null, this.elementsCache.forEach((s) => {
            this.observer.observe(s);
          }), this._scrollToOffset(this.getScrollOffset(), {
            adjustments: void 0,
            behavior: void 0
          }), this.unsubs.push(this.options.observeElementRect(this, (s) => {
            this.scrollRect = s, this.maybeNotify();
          })), this.unsubs.push(this.options.observeElementOffset(this, (s, a) => {
            this.scrollAdjustments = 0, this.scrollDirection = a ? this.getScrollOffset() < s ? "forward" : "backward" : null, this.scrollOffset = s, this.isScrolling = a, this.maybeNotify();
          }));
        }
      }, this.getSize = () => this.options.enabled ? (this.scrollRect = this.scrollRect ?? this.options.initialRect, this.scrollRect[this.options.horizontal ? "width" : "height"]) : (this.scrollRect = null, 0), this.getScrollOffset = () => this.options.enabled ? (this.scrollOffset = this.scrollOffset ?? (typeof this.options.initialOffset == "function" ? this.options.initialOffset() : this.options.initialOffset), this.scrollOffset) : (this.scrollOffset = null, 0), this.getFurthestMeasurement = (n, r) => {
        const s = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
        for (let o = r - 1; o >= 0; o--) {
          const i = n[o];
          if (s.has(i.lane))
            continue;
          const c = a.get(i.lane);
          if (c == null || i.end > c.end ? a.set(i.lane, i) : i.end < c.end && s.set(i.lane, true), s.size === this.options.lanes)
            break;
        }
        return a.size === this.options.lanes ? Array.from(a.values()).sort((o, i) => o.end === i.end ? o.index - i.index : o.end - i.end)[0] : void 0;
      }, this.getMeasurementOptions = wt(() => [
        this.options.count,
        this.options.paddingStart,
        this.options.scrollMargin,
        this.options.getItemKey,
        this.options.enabled
      ], (n, r, s, a, o) => (this.pendingMeasuredCacheIndexes = [], {
        count: n,
        paddingStart: r,
        scrollMargin: s,
        getItemKey: a,
        enabled: o
      }), {
        key: false
      }), this.getMeasurements = wt(() => [
        this.getMeasurementOptions(),
        this.itemSizeCache
      ], ({ count: n, paddingStart: r, scrollMargin: s, getItemKey: a, enabled: o }, i) => {
        if (!o)
          return this.measurementsCache = [], this.itemSizeCache.clear(), [];
        this.measurementsCache.length === 0 && (this.measurementsCache = this.options.initialMeasurementsCache, this.measurementsCache.forEach((f) => {
          this.itemSizeCache.set(f.key, f.size);
        }));
        const c = this.pendingMeasuredCacheIndexes.length > 0 ? Math.min(...this.pendingMeasuredCacheIndexes) : 0;
        this.pendingMeasuredCacheIndexes = [];
        const d = this.measurementsCache.slice(0, c);
        for (let f = c; f < n; f++) {
          const h = a(f), g = this.options.lanes === 1 ? d[f - 1] : this.getFurthestMeasurement(d, f), m = g ? g.end + this.options.gap : r + s, p = i.get(h), x = typeof p == "number" ? p : this.options.estimateSize(f), b = m + x, y = g ? g.lane : f % this.options.lanes;
          d[f] = {
            index: f,
            start: m,
            size: x,
            end: b,
            key: h,
            lane: y
          };
        }
        return this.measurementsCache = d, d;
      }, {
        key: false,
        debug: () => this.options.debug
      }), this.calculateRange = wt(() => [
        this.getMeasurements(),
        this.getSize(),
        this.getScrollOffset(),
        this.options.lanes
      ], (n, r, s, a) => this.range = n.length > 0 && r > 0 ? V0({
        measurements: n,
        outerSize: r,
        scrollOffset: s,
        lanes: a
      }) : null, {
        key: false,
        debug: () => this.options.debug
      }), this.getVirtualIndexes = wt(() => {
        let n = null, r = null;
        const s = this.calculateRange();
        return s && (n = s.startIndex, r = s.endIndex), this.maybeNotify.updateDeps([
          this.isScrolling,
          n,
          r
        ]), [
          this.options.rangeExtractor,
          this.options.overscan,
          this.options.count,
          n,
          r
        ];
      }, (n, r, s, a, o) => a === null || o === null ? [] : n({
        startIndex: a,
        endIndex: o,
        overscan: r,
        count: s
      }), {
        key: false,
        debug: () => this.options.debug
      }), this.indexFromElement = (n) => {
        const r = this.options.indexAttribute, s = n.getAttribute(r);
        return s ? parseInt(s, 10) : (console.warn(`Missing attribute name '${r}={index}' on measured element.`), -1);
      }, this._measureElement = (n, r) => {
        const s = this.indexFromElement(n), a = this.measurementsCache[s];
        if (!a)
          return;
        const o = a.key, i = this.elementsCache.get(o);
        i !== n && (i && this.observer.unobserve(i), this.observer.observe(n), this.elementsCache.set(o, n)), n.isConnected && this.resizeItem(s, this.options.measureElement(n, r, this));
      }, this.resizeItem = (n, r) => {
        const s = this.measurementsCache[n];
        if (!s)
          return;
        const a = this.itemSizeCache.get(s.key) ?? s.size, o = r - a;
        o !== 0 && ((this.shouldAdjustScrollPositionOnItemSizeChange !== void 0 ? this.shouldAdjustScrollPositionOnItemSizeChange(s, o, this) : s.start < this.getScrollOffset() + this.scrollAdjustments) && this._scrollToOffset(this.getScrollOffset(), {
          adjustments: this.scrollAdjustments += o,
          behavior: void 0
        }), this.pendingMeasuredCacheIndexes.push(s.index), this.itemSizeCache = new Map(this.itemSizeCache.set(s.key, r)), this.notify(false));
      }, this.measureElement = (n) => {
        if (!n) {
          this.elementsCache.forEach((r, s) => {
            r.isConnected || (this.observer.unobserve(r), this.elementsCache.delete(s));
          });
          return;
        }
        this._measureElement(n, void 0);
      }, this.getVirtualItems = wt(() => [
        this.getVirtualIndexes(),
        this.getMeasurements()
      ], (n, r) => {
        const s = [];
        for (let a = 0, o = n.length; a < o; a++) {
          const i = n[a], c = r[i];
          s.push(c);
        }
        return s;
      }, {
        key: false,
        debug: () => this.options.debug
      }), this.getVirtualItemForOffset = (n) => {
        const r = this.getMeasurements();
        if (r.length !== 0)
          return ya(r[pl(0, r.length - 1, (s) => ya(r[s]).start, n)]);
      }, this.getOffsetForAlignment = (n, r, s = 0) => {
        const a = this.getSize(), o = this.getScrollOffset();
        r === "auto" && (r = n >= o + a ? "end" : "start"), r === "center" ? n += (s - a) / 2 : r === "end" && (n -= a);
        const i = this.getTotalSize() + this.options.scrollMargin - a;
        return Math.max(Math.min(i, n), 0);
      }, this.getOffsetForIndex = (n, r = "auto") => {
        n = Math.max(0, Math.min(n, this.options.count - 1));
        const s = this.measurementsCache[n];
        if (!s)
          return;
        const a = this.getSize(), o = this.getScrollOffset();
        if (r === "auto")
          if (s.end >= o + a - this.options.scrollPaddingEnd)
            r = "end";
          else if (s.start <= o + this.options.scrollPaddingStart)
            r = "start";
          else
            return [
              o,
              r
            ];
        const i = r === "end" ? s.end + this.options.scrollPaddingEnd : s.start - this.options.scrollPaddingStart;
        return [
          this.getOffsetForAlignment(i, r, s.size),
          r
        ];
      }, this.isDynamicMode = () => this.elementsCache.size > 0, this.scrollToOffset = (n, { align: r = "start", behavior: s } = {}) => {
        s === "smooth" && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), this._scrollToOffset(this.getOffsetForAlignment(n, r), {
          adjustments: void 0,
          behavior: s
        });
      }, this.scrollToIndex = (n, { align: r = "auto", behavior: s } = {}) => {
        s === "smooth" && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), n = Math.max(0, Math.min(n, this.options.count - 1));
        let a = 0;
        const o = 10, i = (d) => {
          if (!this.targetWindow)
            return;
          const f = this.getOffsetForIndex(n, d);
          if (!f) {
            console.warn("Failed to get offset for index:", n);
            return;
          }
          const [h, g] = f;
          this._scrollToOffset(h, {
            adjustments: void 0,
            behavior: s
          }), this.targetWindow.requestAnimationFrame(() => {
            const m = this.getScrollOffset(), p = this.getOffsetForIndex(n, g);
            if (!p) {
              console.warn("Failed to get offset for index:", n);
              return;
            }
            L0(p[0], m) || c(g);
          });
        }, c = (d) => {
          this.targetWindow && (a++, a < o ? this.targetWindow.requestAnimationFrame(() => i(d)) : console.warn(`Failed to scroll to index ${n} after ${o} attempts.`));
        };
        i(r);
      }, this.scrollBy = (n, { behavior: r } = {}) => {
        r === "smooth" && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), this._scrollToOffset(this.getScrollOffset() + n, {
          adjustments: void 0,
          behavior: r
        });
      }, this.getTotalSize = () => {
        var n;
        const r = this.getMeasurements();
        let s;
        if (r.length === 0)
          s = this.options.paddingStart;
        else if (this.options.lanes === 1)
          s = ((n = r[r.length - 1]) == null ? void 0 : n.end) ?? 0;
        else {
          const a = Array(this.options.lanes).fill(null);
          let o = r.length - 1;
          for (; o >= 0 && a.some((i) => i === null); ) {
            const i = r[o];
            a[i.lane] === null && (a[i.lane] = i.end), o--;
          }
          s = Math.max(...a.filter((i) => i !== null));
        }
        return Math.max(s - this.options.scrollMargin + this.options.paddingEnd, 0);
      }, this._scrollToOffset = (n, { adjustments: r, behavior: s }) => {
        this.options.scrollToFn(n, {
          behavior: s,
          adjustments: r
        }, this);
      }, this.measure = () => {
        this.itemSizeCache = /* @__PURE__ */ new Map(), this.notify(false);
      }, this.setOptions(t);
    }
  }
  const pl = (e, t, n, r) => {
    for (; e <= t; ) {
      const s = (e + t) / 2 | 0, a = n(s);
      if (a < r)
        e = s + 1;
      else if (a > r)
        t = s - 1;
      else
        return s;
    }
    return e > 0 ? e - 1 : 0;
  };
  function V0({ measurements: e, outerSize: t, scrollOffset: n, lanes: r }) {
    const s = e.length - 1, a = (c) => e[c].start;
    if (e.length <= r)
      return {
        startIndex: 0,
        endIndex: s
      };
    let o = pl(0, s, a, n), i = o;
    if (r === 1)
      for (; i < s && e[i].end < n + t; )
        i++;
    else if (r > 1) {
      const c = Array(r).fill(0);
      for (; i < s && c.some((f) => f < n + t); ) {
        const f = e[i];
        c[f.lane] = f.end, i++;
      }
      const d = Array(r).fill(n + t);
      for (; o >= 0 && d.some((f) => f >= n); ) {
        const f = e[o];
        d[f.lane] = f.start, o--;
      }
      o = Math.max(0, o - o % r), i = Math.min(s, i + (r - 1 - i % r));
    }
    return {
      startIndex: o,
      endIndex: i
    };
  }
  const ja = typeof document < "u" ? u.useLayoutEffect : u.useEffect;
  function W0(e) {
    const t = u.useReducer(() => ({}), {})[1], n = {
      ...e,
      onChange: (s, a) => {
        var o;
        a ? xe.flushSync(t) : t(), (o = e.onChange) == null || o.call(e, s, a);
      }
    }, [r] = u.useState(() => new U0(n));
    return r.setOptions(n), ja(() => r._didMount(), []), ja(() => r._willUpdate()), r;
  }
  function z0(e) {
    return W0({
      observeElementRect: D0,
      observeElementOffset: _0,
      scrollToFn: H0,
      ...e
    });
  }
  function G0(e, t) {
    return e !== null && t !== null && typeof e == "object" && typeof t == "object" && "id" in e && "id" in t ? e.id === t.id : e === t;
  }
  function Z0(e = G0) {
    return u.useCallback((t, n) => {
      if (typeof e == "string") {
        let r = e;
        return (t == null ? void 0 : t[r]) === (n == null ? void 0 : n[r]);
      }
      return e(t, n);
    }, [
      e
    ]);
  }
  function Na(e) {
    if (e === null)
      return {
        width: 0,
        height: 0
      };
    let { width: t, height: n } = e.getBoundingClientRect();
    return {
      width: t,
      height: n
    };
  }
  function Kr(e, t, n = false) {
    let [r, s] = u.useState(() => Na(t));
    return X(() => {
      if (!t || !e)
        return;
      let a = Se();
      return a.requestAnimationFrame(function o() {
        a.requestAnimationFrame(o), s((i) => {
          let c = Na(t);
          return c.width === i.width && c.height === i.height ? i : c;
        });
      }), () => {
        a.dispose();
      };
    }, [
      t,
      e
    ]), n ? {
      width: `${r.width}px`,
      height: `${r.height}px`
    } : r;
  }
  var ws = ((e) => (e[e.Left = 0] = "Left", e[e.Right = 2] = "Right", e))(ws || {});
  function q0(e) {
    let t = u.useRef(null), n = R((s) => {
      t.current = s.pointerType, !Jt(s.currentTarget) && s.pointerType === "mouse" && s.button === ws.Left && (s.preventDefault(), e(s));
    }), r = R((s) => {
      t.current !== "mouse" && (Jt(s.currentTarget) || e(s));
    });
    return {
      onPointerDown: n,
      onClick: r
    };
  }
  let ml = class extends Map {
    constructor(t) {
      super(), this.factory = t;
    }
    get(t) {
      let n = super.get(t);
      return n === void 0 && (n = this.factory(t), this.set(t, n)), n;
    }
  };
  var K0 = Object.defineProperty, Y0 = (e, t, n) => t in e ? K0(e, t, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: n
  }) : e[t] = n, X0 = (e, t, n) => (Y0(e, typeof t != "symbol" ? t + "" : t, n), n), gl = (e, t, n) => {
    if (!t.has(e))
      throw TypeError("Cannot " + n);
  }, je = (e, t, n) => (gl(e, t, "read from private field"), n ? n.call(e) : t.get(e)), Er = (e, t, n) => {
    if (t.has(e))
      throw TypeError("Cannot add the same private member more than once");
    t instanceof WeakSet ? t.add(e) : t.set(e, n);
  }, Ca = (e, t, n, r) => (gl(e, t, "write to private field"), r ? r.call(e, n) : t.set(e, n), n), Pe, Vt, Wt;
  let ks = class {
    constructor(t) {
      Er(this, Pe, {}), Er(this, Vt, new ml(() => /* @__PURE__ */ new Set())), Er(this, Wt, /* @__PURE__ */ new Set()), X0(this, "disposables", Se()), Ca(this, Pe, t), Fe.isServer && this.disposables.microTask(() => {
        this.dispose();
      });
    }
    dispose() {
      this.disposables.dispose();
    }
    get state() {
      return je(this, Pe);
    }
    subscribe(t, n) {
      if (Fe.isServer)
        return () => {
        };
      let r = {
        selector: t,
        callback: n,
        current: t(je(this, Pe))
      };
      return je(this, Wt).add(r), this.disposables.add(() => {
        je(this, Wt).delete(r);
      });
    }
    on(t, n) {
      return Fe.isServer ? () => {
      } : (je(this, Vt).get(t).add(n), this.disposables.add(() => {
        je(this, Vt).get(t).delete(n);
      }));
    }
    send(t) {
      let n = this.reduce(je(this, Pe), t);
      if (n !== je(this, Pe)) {
        Ca(this, Pe, n);
        for (let r of je(this, Wt)) {
          let s = r.selector(je(this, Pe));
          xl(r.current, s) || (r.current = s, r.callback(s));
        }
        for (let r of je(this, Vt).get(t.type))
          r(je(this, Pe), t);
      }
    }
  };
  Pe = /* @__PURE__ */ new WeakMap(), Vt = /* @__PURE__ */ new WeakMap(), Wt = /* @__PURE__ */ new WeakMap();
  function xl(e, t) {
    return Object.is(e, t) ? true : typeof e != "object" || e === null || typeof t != "object" || t === null ? false : Array.isArray(e) && Array.isArray(t) ? e.length !== t.length ? false : jr(e[Symbol.iterator](), t[Symbol.iterator]()) : e instanceof Map && t instanceof Map || e instanceof Set && t instanceof Set ? e.size !== t.size ? false : jr(e.entries(), t.entries()) : Sa(e) && Sa(t) ? jr(Object.entries(e)[Symbol.iterator](), Object.entries(t)[Symbol.iterator]()) : false;
  }
  function jr(e, t) {
    do {
      let n = e.next(), r = t.next();
      if (n.done && r.done)
        return true;
      if (n.done || r.done || !Object.is(n.value, r.value))
        return false;
    } while (true);
  }
  function Sa(e) {
    if (Object.prototype.toString.call(e) !== "[object Object]")
      return false;
    let t = Object.getPrototypeOf(e);
    return t === null || Object.getPrototypeOf(t) === null;
  }
  var Q0 = Object.defineProperty, J0 = (e, t, n) => t in e ? Q0(e, t, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: n
  }) : e[t] = n, Ta = (e, t, n) => (J0(e, typeof t != "symbol" ? t + "" : t, n), n), bl = ((e) => (e[e.Push = 0] = "Push", e[e.Pop = 1] = "Pop", e))(bl || {});
  let ef = {
    0(e, t) {
      let n = t.id, r = e.stack, s = e.stack.indexOf(n);
      if (s !== -1) {
        let a = e.stack.slice();
        return a.splice(s, 1), a.push(n), r = a, {
          ...e,
          stack: r
        };
      }
      return {
        ...e,
        stack: [
          ...e.stack,
          n
        ]
      };
    },
    1(e, t) {
      let n = t.id, r = e.stack.indexOf(n);
      if (r === -1)
        return e;
      let s = e.stack.slice();
      return s.splice(r, 1), {
        ...e,
        stack: s
      };
    }
  }, tf = class vl extends ks {
    constructor() {
      super(...arguments), Ta(this, "actions", {
        push: (t) => this.send({
          type: 0,
          id: t
        }),
        pop: (t) => this.send({
          type: 1,
          id: t
        })
      }), Ta(this, "selectors", {
        isTop: (t, n) => t.stack[t.stack.length - 1] === n,
        inStack: (t, n) => t.stack.includes(n)
      });
    }
    static new() {
      return new vl({
        stack: []
      });
    }
    reduce(t, n) {
      return re(n.type, ef, t, n);
    }
  };
  const fn = new ml(() => tf.new());
  var yl = {
    exports: {}
  }, wl = {};
  var hn = u;
  function nf(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
  }
  var rf = typeof Object.is == "function" ? Object.is : nf, sf = hn.useSyncExternalStore, af = hn.useRef, of = hn.useEffect, lf = hn.useMemo, cf = hn.useDebugValue;
  wl.useSyncExternalStoreWithSelector = function(e, t, n, r, s) {
    var a = af(null);
    if (a.current === null) {
      var o = {
        hasValue: false,
        value: null
      };
      a.current = o;
    } else
      o = a.current;
    a = lf(function() {
      function c(m) {
        if (!d) {
          if (d = true, f = m, m = r(m), s !== void 0 && o.hasValue) {
            var p = o.value;
            if (s(p, m))
              return h = p;
          }
          return h = m;
        }
        if (p = h, rf(f, m))
          return p;
        var x = r(m);
        return s !== void 0 && s(p, x) ? (f = m, p) : (f = m, h = x);
      }
      var d = false, f, h, g = n === void 0 ? null : n;
      return [
        function() {
          return c(t());
        },
        g === null ? void 0 : function() {
          return c(g());
        }
      ];
    }, [
      t,
      n,
      r,
      s
    ]);
    var i = sf(e, a[0], a[1]);
    return of(function() {
      o.hasValue = true, o.value = i;
    }, [
      i
    ]), cf(i), i;
  };
  yl.exports = wl;
  var uf = yl.exports;
  function se(e, t, n = xl) {
    return uf.useSyncExternalStoreWithSelector(R((r) => e.subscribe(df, r)), R(() => e.state), R(() => e.state), R(t), n);
  }
  function df(e) {
    return e;
  }
  function pn(e, t) {
    let n = u.useId(), r = fn.get(t), [s, a] = se(r, u.useCallback((o) => [
      r.selectors.isTop(o, n),
      r.selectors.inStack(o, n)
    ], [
      r,
      n
    ]));
    return X(() => {
      if (e)
        return r.actions.push(n), () => r.actions.pop(n);
    }, [
      r,
      e,
      n
    ]), e ? a ? s : true : false;
  }
  let Yr = /* @__PURE__ */ new Map(), qt = /* @__PURE__ */ new Map();
  function $a(e) {
    var t;
    let n = (t = qt.get(e)) != null ? t : 0;
    return qt.set(e, n + 1), n !== 0 ? () => Ra(e) : (Yr.set(e, {
      "aria-hidden": e.getAttribute("aria-hidden"),
      inert: e.inert
    }), e.setAttribute("aria-hidden", "true"), e.inert = true, () => Ra(e));
  }
  function Ra(e) {
    var t;
    let n = (t = qt.get(e)) != null ? t : 1;
    if (n === 1 ? qt.delete(e) : qt.set(e, n - 1), n !== 1)
      return;
    let r = Yr.get(e);
    r && (r["aria-hidden"] === null ? e.removeAttribute("aria-hidden") : e.setAttribute("aria-hidden", r["aria-hidden"]), e.inert = r.inert, Yr.delete(e));
  }
  function kl(e, { allowed: t, disallowed: n } = {}) {
    let r = pn(e, "inert-others");
    X(() => {
      var s, a;
      if (!r)
        return;
      let o = Se();
      for (let c of (s = n == null ? void 0 : n()) != null ? s : [])
        c && o.add($a(c));
      let i = (a = t == null ? void 0 : t()) != null ? a : [];
      for (let c of i) {
        if (!c)
          continue;
        let d = ot(c);
        if (!d)
          continue;
        let f = c.parentElement;
        for (; f && f !== d.body; ) {
          for (let h of f.children)
            i.some((g) => h.contains(g)) || o.add($a(h));
          f = f.parentElement;
        }
      }
      return o.dispose;
    }, [
      r,
      t,
      n
    ]);
  }
  function Es(e, t, n) {
    let r = ye((s) => {
      let a = s.getBoundingClientRect();
      a.x === 0 && a.y === 0 && a.width === 0 && a.height === 0 && n();
    });
    u.useEffect(() => {
      if (!e)
        return;
      let s = t === null ? null : ve(t) ? t : t.current;
      if (!s)
        return;
      let a = Se();
      if (typeof ResizeObserver < "u") {
        let o = new ResizeObserver(() => r.current(s));
        o.observe(s), a.add(() => o.disconnect());
      }
      if (typeof IntersectionObserver < "u") {
        let o = new IntersectionObserver(() => r.current(s));
        o.observe(s), a.add(() => o.disconnect());
      }
      return () => a.dispose();
    }, [
      t,
      r,
      e
    ]);
  }
  let Bn = [
    "[contentEditable=true]",
    "[tabindex]",
    "a[href]",
    "area[href]",
    "button:not([disabled])",
    "iframe",
    "input:not([disabled])",
    "select:not([disabled])",
    "details>summary",
    "textarea:not([disabled])"
  ].map((e) => `${e}:not([tabindex='-1'])`).join(","), ff = [
    "[data-autofocus]"
  ].map((e) => `${e}:not([tabindex='-1'])`).join(",");
  var te = ((e) => (e[e.First = 1] = "First", e[e.Previous = 2] = "Previous", e[e.Next = 4] = "Next", e[e.Last = 8] = "Last", e[e.WrapAround = 16] = "WrapAround", e[e.NoScroll = 32] = "NoScroll", e[e.AutoFocus = 64] = "AutoFocus", e))(te || {}), Ie = ((e) => (e[e.Error = 0] = "Error", e[e.Overflow = 1] = "Overflow", e[e.Success = 2] = "Success", e[e.Underflow = 3] = "Underflow", e))(Ie || {}), hf = ((e) => (e[e.Previous = -1] = "Previous", e[e.Next = 1] = "Next", e))(hf || {});
  function Qn(e = document.body) {
    return e == null ? [] : Array.from(e.querySelectorAll(Bn)).sort((t, n) => Math.sign((t.tabIndex || Number.MAX_SAFE_INTEGER) - (n.tabIndex || Number.MAX_SAFE_INTEGER)));
  }
  function pf(e = document.body) {
    return e == null ? [] : Array.from(e.querySelectorAll(ff)).sort((t, n) => Math.sign((t.tabIndex || Number.MAX_SAFE_INTEGER) - (n.tabIndex || Number.MAX_SAFE_INTEGER)));
  }
  var js = ((e) => (e[e.Strict = 0] = "Strict", e[e.Loose = 1] = "Loose", e))(js || {});
  function El(e, t = 0) {
    var n;
    return e === ((n = ot(e)) == null ? void 0 : n.body) ? false : re(t, {
      0() {
        return e.matches(Bn);
      },
      1() {
        let r = e;
        for (; r !== null; ) {
          if (r.matches(Bn))
            return true;
          r = r.parentElement;
        }
        return false;
      }
    });
  }
  var mf = ((e) => (e[e.Keyboard = 0] = "Keyboard", e[e.Mouse = 1] = "Mouse", e))(mf || {});
  typeof window < "u" && typeof document < "u" && (document.addEventListener("keydown", (e) => {
    e.metaKey || e.altKey || e.ctrlKey || (document.documentElement.dataset.headlessuiFocusVisible = "");
  }, true), document.addEventListener("click", (e) => {
    e.detail === 1 ? delete document.documentElement.dataset.headlessuiFocusVisible : e.detail === 0 && (document.documentElement.dataset.headlessuiFocusVisible = "");
  }, true));
  function ze(e) {
    e == null ? void 0 : e.focus({
      preventScroll: true
    });
  }
  let gf = [
    "textarea",
    "input"
  ].join(",");
  function xf(e) {
    var t, n;
    return (n = (t = e == null ? void 0 : e.matches) == null ? void 0 : t.call(e, gf)) != null ? n : false;
  }
  function ut(e, t = (n) => n) {
    return e.slice().sort((n, r) => {
      let s = t(n), a = t(r);
      if (s === null || a === null)
        return 0;
      let o = s.compareDocumentPosition(a);
      return o & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : o & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
    });
  }
  function he(e, t, { sorted: n = true, relativeTo: r = null, skipElements: s = [] } = {}) {
    let a = Array.isArray(e) ? e.length > 0 ? ht(e[0]) : document : ht(e), o = Array.isArray(e) ? n ? ut(e) : e : t & 64 ? pf(e) : Qn(e);
    s.length > 0 && o.length > 1 && (o = o.filter((m) => !s.some((p) => p != null && "current" in p ? (p == null ? void 0 : p.current) === m : p === m))), r = r ?? (a == null ? void 0 : a.activeElement);
    let i = (() => {
      if (t & 5)
        return 1;
      if (t & 10)
        return -1;
      throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
    })(), c = (() => {
      if (t & 1)
        return 0;
      if (t & 2)
        return Math.max(0, o.indexOf(r)) - 1;
      if (t & 4)
        return Math.max(0, o.indexOf(r)) + 1;
      if (t & 8)
        return o.length - 1;
      throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
    })(), d = t & 32 ? {
      preventScroll: true
    } : {}, f = 0, h = o.length, g;
    do {
      if (f >= h || f + h <= 0)
        return 0;
      let m = c + f;
      if (t & 16)
        m = (m + h) % h;
      else {
        if (m < 0)
          return 3;
        if (m >= h)
          return 1;
      }
      g = o[m], g == null ? void 0 : g.focus(d), f += i;
    } while (g !== et(g));
    return t & 6 && xf(g) && g.select(), 2;
  }
  function jl() {
    return /iPhone/gi.test(window.navigator.platform) || /Mac/gi.test(window.navigator.platform) && window.navigator.maxTouchPoints > 0;
  }
  function bf() {
    return /Android/gi.test(window.navigator.userAgent);
  }
  function Xr() {
    return jl() || bf();
  }
  function Nt(e, t, n, r) {
    let s = ye(n);
    u.useEffect(() => {
      if (!e)
        return;
      function a(o) {
        s.current(o);
      }
      return document.addEventListener(t, a, r), () => document.removeEventListener(t, a, r);
    }, [
      e,
      t,
      r
    ]);
  }
  function Nl(e, t, n, r) {
    let s = ye(n);
    u.useEffect(() => {
      if (!e)
        return;
      function a(o) {
        s.current(o);
      }
      return window.addEventListener(t, a, r), () => window.removeEventListener(t, a, r);
    }, [
      e,
      t,
      r
    ]);
  }
  const Aa = 30;
  function Ns(e, t, n) {
    let r = ye(n), s = u.useCallback(function(i, c) {
      if (i.defaultPrevented)
        return;
      let d = c(i);
      if (d === null || !d.getRootNode().contains(d) || !d.isConnected)
        return;
      let f = function h(g) {
        return typeof g == "function" ? h(g()) : Array.isArray(g) || g instanceof Set ? g : [
          g
        ];
      }(t);
      for (let h of f)
        if (h !== null && (h.contains(d) || i.composed && i.composedPath().includes(h)))
          return;
      return !El(d, js.Loose) && d.tabIndex !== -1 && i.preventDefault(), r.current(i, d);
    }, [
      r,
      t
    ]), a = u.useRef(null);
    Nt(e, "pointerdown", (i) => {
      var c, d;
      Xr() || (a.current = ((d = (c = i.composedPath) == null ? void 0 : c.call(i)) == null ? void 0 : d[0]) || i.target);
    }, true), Nt(e, "pointerup", (i) => {
      if (Xr() || !a.current)
        return;
      let c = a.current;
      return a.current = null, s(i, () => c);
    }, true);
    let o = u.useRef({
      x: 0,
      y: 0
    });
    Nt(e, "touchstart", (i) => {
      o.current.x = i.touches[0].clientX, o.current.y = i.touches[0].clientY;
    }, true), Nt(e, "touchend", (i) => {
      let c = {
        x: i.changedTouches[0].clientX,
        y: i.changedTouches[0].clientY
      };
      if (!(Math.abs(c.x - o.current.x) >= Aa || Math.abs(c.y - o.current.y) >= Aa))
        return s(i, () => Le(i.target) ? i.target : null);
    }, true), Nl(e, "blur", (i) => s(i, () => E0(window.document.activeElement) ? window.document.activeElement : null), true);
  }
  function pt(...e) {
    return u.useMemo(() => ot(...e), [
      ...e
    ]);
  }
  function vf(...e) {
    return u.useMemo(() => ht(...e), [
      ...e
    ]);
  }
  var yf = ((e) => (e[e.Ignore = 0] = "Ignore", e[e.Select = 1] = "Select", e[e.Close = 2] = "Close", e))(yf || {});
  const _t = {
    Ignore: {
      kind: 0
    },
    Select: (e) => ({
      kind: 1,
      target: e
    }),
    Close: {
      kind: 2
    }
  }, wf = 200, Pa = 5;
  function kf(e, { trigger: t, action: n, close: r, select: s }) {
    let a = u.useRef(null), o = u.useRef(null), i = u.useRef(null);
    Nt(e && t !== null, "pointerdown", (c) => {
      rl(c == null ? void 0 : c.target) && t != null && t.contains(c.target) && (o.current = c.x, i.current = c.y, a.current = c.timeStamp);
    }), Nt(e && t !== null, "pointerup", (c) => {
      var d, f;
      let h = a.current;
      if (h === null || (a.current = null, !Le(c.target)) || Math.abs(c.x - ((d = o.current) != null ? d : c.x)) < Pa && Math.abs(c.y - ((f = i.current) != null ? f : c.y)) < Pa)
        return;
      let g = n(c);
      switch (g.kind) {
        case 0:
          return;
        case 1: {
          c.timeStamp - h > wf && (s(g.target), r());
          break;
        }
        case 2: {
          r();
          break;
        }
      }
    }, {
      capture: true
    });
  }
  function Jn(e, t, n, r) {
    let s = ye(n);
    u.useEffect(() => {
      e = e ?? window;
      function a(o) {
        s.current(o);
      }
      return e.addEventListener(t, a, r), () => e.removeEventListener(t, a, r);
    }, [
      e,
      t,
      r
    ]);
  }
  function Cl(e) {
    let t = u.useRef({
      value: "",
      selectionStart: null,
      selectionEnd: null
    });
    return Jn(e, "blur", (n) => {
      let r = n.target;
      _n(r) && (t.current = {
        value: r.value,
        selectionStart: r.selectionStart,
        selectionEnd: r.selectionEnd
      });
    }), R(() => {
      if (!bs(e) && _n(e) && e.isConnected) {
        if (e.focus({
          preventScroll: true
        }), e.value !== t.current.value)
          e.setSelectionRange(e.value.length, e.value.length);
        else {
          let { selectionStart: n, selectionEnd: r } = t.current;
          n !== null && r !== null && e.setSelectionRange(n, r);
        }
        t.current = {
          value: "",
          selectionStart: null,
          selectionEnd: null
        };
      }
    });
  }
  function er(e, t) {
    return u.useMemo(() => {
      var n;
      if (e.type)
        return e.type;
      let r = (n = e.as) != null ? n : "button";
      if (typeof r == "string" && r.toLowerCase() === "button" || (t == null ? void 0 : t.tagName) === "BUTTON" && !t.hasAttribute("type"))
        return "button";
    }, [
      e.type,
      e.as,
      t
    ]);
  }
  function Ef(e) {
    return u.useSyncExternalStore(e.subscribe, e.getSnapshot, e.getSnapshot);
  }
  function jf(e, t) {
    let n = e(), r = /* @__PURE__ */ new Set();
    return {
      getSnapshot() {
        return n;
      },
      subscribe(s) {
        return r.add(s), () => r.delete(s);
      },
      dispatch(s, ...a) {
        let o = t[s].call(n, ...a);
        o && (n = o, r.forEach((i) => i()));
      }
    };
  }
  function Nf() {
    let e;
    return {
      before({ doc: t }) {
        var n;
        let r = t.documentElement, s = (n = t.defaultView) != null ? n : window;
        e = Math.max(0, s.innerWidth - r.clientWidth);
      },
      after({ doc: t, d: n }) {
        let r = t.documentElement, s = Math.max(0, r.clientWidth - r.offsetWidth), a = Math.max(0, e - s);
        n.style(r, "paddingRight", `${a}px`);
      }
    };
  }
  function Cf() {
    return jl() ? {
      before({ doc: e, d: t, meta: n }) {
        function r(s) {
          for (let a of n().containers)
            for (let o of a())
              if (o.contains(s))
                return true;
          return false;
        }
        t.microTask(() => {
          var s;
          if (window.getComputedStyle(e.documentElement).scrollBehavior !== "auto") {
            let i = Se();
            i.style(e.documentElement, "scrollBehavior", "auto"), t.add(() => t.microTask(() => i.dispose()));
          }
          let a = (s = window.scrollY) != null ? s : window.pageYOffset, o = null;
          t.addEventListener(e, "click", (i) => {
            if (Le(i.target))
              try {
                let c = i.target.closest("a");
                if (!c)
                  return;
                let { hash: d } = new URL(c.href), f = e.querySelector(d);
                Le(f) && !r(f) && (o = f);
              } catch {
              }
          }, true), t.group((i) => {
            t.addEventListener(e, "touchstart", (c) => {
              if (i.dispose(), Le(c.target) && k0(c.target))
                if (r(c.target)) {
                  let d = c.target;
                  for (; d.parentElement && r(d.parentElement); )
                    d = d.parentElement;
                  i.style(d, "overscrollBehavior", "contain");
                } else
                  i.style(c.target, "touchAction", "none");
            });
          }), t.addEventListener(e, "touchmove", (i) => {
            if (Le(i.target)) {
              if (_n(i.target))
                return;
              if (r(i.target)) {
                let c = i.target;
                for (; c.parentElement && c.dataset.headlessuiPortal !== "" && !(c.scrollHeight > c.clientHeight || c.scrollWidth > c.clientWidth); )
                  c = c.parentElement;
                c.dataset.headlessuiPortal === "" && i.preventDefault();
              } else
                i.preventDefault();
            }
          }, {
            passive: false
          }), t.add(() => {
            var i;
            let c = (i = window.scrollY) != null ? i : window.pageYOffset;
            a !== c && window.scrollTo(0, a), o && o.isConnected && (o.scrollIntoView({
              block: "nearest"
            }), o = null);
          });
        });
      }
    } : {};
  }
  function Sf() {
    return {
      before({ doc: e, d: t }) {
        t.style(e.documentElement, "overflow", "hidden");
      }
    };
  }
  function Oa(e) {
    let t = {};
    for (let n of e)
      Object.assign(t, n(t));
    return t;
  }
  let dt = jf(() => /* @__PURE__ */ new Map(), {
    PUSH(e, t) {
      var n;
      let r = (n = this.get(e)) != null ? n : {
        doc: e,
        count: 0,
        d: Se(),
        meta: /* @__PURE__ */ new Set(),
        computedMeta: {}
      };
      return r.count++, r.meta.add(t), r.computedMeta = Oa(r.meta), this.set(e, r), this;
    },
    POP(e, t) {
      let n = this.get(e);
      return n && (n.count--, n.meta.delete(t), n.computedMeta = Oa(n.meta)), this;
    },
    SCROLL_PREVENT(e) {
      let t = {
        doc: e.doc,
        d: e.d,
        meta() {
          return e.computedMeta;
        }
      }, n = [
        Cf(),
        Nf(),
        Sf()
      ];
      n.forEach(({ before: r }) => r == null ? void 0 : r(t)), n.forEach(({ after: r }) => r == null ? void 0 : r(t));
    },
    SCROLL_ALLOW({ d: e }) {
      e.dispose();
    },
    TEARDOWN({ doc: e }) {
      this.delete(e);
    }
  });
  dt.subscribe(() => {
    let e = dt.getSnapshot(), t = /* @__PURE__ */ new Map();
    for (let [n] of e)
      t.set(n, n.documentElement.style.overflow);
    for (let n of e.values()) {
      let r = t.get(n.doc) === "hidden", s = n.count !== 0;
      (s && !r || !s && r) && dt.dispatch(n.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", n), n.count === 0 && dt.dispatch("TEARDOWN", n);
    }
  });
  function Tf(e, t, n = () => ({
    containers: []
  })) {
    let r = Ef(dt), s = t ? r.get(t) : void 0, a = s ? s.count > 0 : false;
    return X(() => {
      if (!(!t || !e))
        return dt.dispatch("PUSH", t, n), () => dt.dispatch("POP", t, n);
    }, [
      e,
      t
    ]), a;
  }
  function Cs(e, t, n = () => [
    document.body
  ]) {
    let r = pn(e, "scroll-lock");
    Tf(r, t, (s) => {
      var a;
      return {
        containers: [
          ...(a = s.containers) != null ? a : [],
          n
        ]
      };
    });
  }
  function La(e) {
    return [
      e.screenX,
      e.screenY
    ];
  }
  function $f() {
    let e = u.useRef([
      -1,
      -1
    ]);
    return {
      wasMoved(t) {
        let n = La(t);
        return e.current[0] === n[0] && e.current[1] === n[1] ? false : (e.current = n, true);
      },
      update(t) {
        e.current = La(t);
      }
    };
  }
  function Rf(e = 0) {
    let [t, n] = u.useState(e), r = u.useCallback((c) => n(c), []), s = u.useCallback((c) => n((d) => d | c), []), a = u.useCallback((c) => (t & c) === c, [
      t
    ]), o = u.useCallback((c) => n((d) => d & ~c), []), i = u.useCallback((c) => n((d) => d ^ c), []);
    return {
      flags: t,
      setFlag: r,
      addFlag: s,
      hasFlag: a,
      removeFlag: o,
      toggleFlag: i
    };
  }
  var Ia, Fa;
  typeof process < "u" && typeof globalThis < "u" && typeof Element < "u" && ((Ia = process == null ? void 0 : process.env) == null ? void 0 : Ia.NODE_ENV) === "test" && typeof ((Fa = Element == null ? void 0 : Element.prototype) == null ? void 0 : Fa.getAnimations) > "u" && (Element.prototype.getAnimations = function() {
    return console.warn([
      "Headless UI has polyfilled `Element.prototype.getAnimations` for your tests.",
      "Please install a proper polyfill e.g. `jsdom-testing-mocks`, to silence these warnings.",
      "",
      "Example usage:",
      "```js",
      "import { mockAnimationsApi } from 'jsdom-testing-mocks'",
      "mockAnimationsApi()",
      "```"
    ].join(`
`)), [];
  });
  var Af = ((e) => (e[e.None = 0] = "None", e[e.Closed = 1] = "Closed", e[e.Enter = 2] = "Enter", e[e.Leave = 4] = "Leave", e))(Af || {});
  function tr(e) {
    let t = {};
    for (let n in e)
      e[n] === true && (t[`data-${n}`] = "");
    return t;
  }
  function nr(e, t, n, r) {
    let [s, a] = u.useState(n), { hasFlag: o, addFlag: i, removeFlag: c } = Rf(e && s ? 3 : 0), d = u.useRef(false), f = u.useRef(false), h = Ke();
    return X(() => {
      var g;
      if (e) {
        if (n && a(true), !t) {
          n && i(3);
          return;
        }
        return (g = r == null ? void 0 : r.start) == null || g.call(r, n), Pf(t, {
          inFlight: d,
          prepare() {
            f.current ? f.current = false : f.current = d.current, d.current = true, !f.current && (n ? (i(3), c(4)) : (i(4), c(2)));
          },
          run() {
            f.current ? n ? (c(3), i(4)) : (c(4), i(3)) : n ? c(1) : i(1);
          },
          done() {
            var m;
            f.current && If(t) || (d.current = false, c(7), n || a(false), (m = r == null ? void 0 : r.end) == null || m.call(r, n));
          }
        });
      }
    }, [
      e,
      n,
      t,
      h
    ]), e ? [
      s,
      {
        closed: o(1),
        enter: o(2),
        leave: o(4),
        transition: o(2) || o(4)
      }
    ] : [
      n,
      {
        closed: void 0,
        enter: void 0,
        leave: void 0,
        transition: void 0
      }
    ];
  }
  function Pf(e, { prepare: t, run: n, done: r, inFlight: s }) {
    let a = Se();
    return Lf(e, {
      prepare: t,
      inFlight: s
    }), a.nextFrame(() => {
      n(), a.requestAnimationFrame(() => {
        a.add(Of(e, r));
      });
    }), a.dispose;
  }
  function Of(e, t) {
    var n, r;
    let s = Se();
    if (!e)
      return s.dispose;
    let a = false;
    s.add(() => {
      a = true;
    });
    let o = (r = (n = e.getAnimations) == null ? void 0 : n.call(e).filter((i) => i instanceof CSSTransition)) != null ? r : [];
    return o.length === 0 ? (t(), s.dispose) : (Promise.allSettled(o.map((i) => i.finished)).then(() => {
      a || t();
    }), s.dispose);
  }
  function Lf(e, { inFlight: t, prepare: n }) {
    if (t != null && t.current) {
      n();
      return;
    }
    let r = e.style.transition;
    e.style.transition = "none", n(), e.offsetHeight, e.style.transition = r;
  }
  function If(e) {
    var t, n;
    return ((n = (t = e.getAnimations) == null ? void 0 : t.call(e)) != null ? n : []).some((r) => r instanceof CSSTransition && r.playState !== "finished");
  }
  function Ff(e, { container: t, accept: n, walk: r }) {
    let s = u.useRef(n), a = u.useRef(r);
    u.useEffect(() => {
      s.current = n, a.current = r;
    }, [
      n,
      r
    ]), X(() => {
      if (!t || !e)
        return;
      let o = ot(t);
      if (!o)
        return;
      let i = s.current, c = a.current, d = Object.assign((h) => i(h), {
        acceptNode: i
      }), f = o.createTreeWalker(t, NodeFilter.SHOW_ELEMENT, d, false);
      for (; f.nextNode(); )
        c(f.currentNode);
    }, [
      t,
      e,
      s,
      a
    ]);
  }
  function en(e, t) {
    let n = u.useRef([]), r = R(e);
    u.useEffect(() => {
      let s = [
        ...n.current
      ];
      for (let [a, o] of t.entries())
        if (n.current[a] !== o) {
          let i = r(t, s);
          return n.current = t, i;
        }
    }, [
      r,
      ...t
    ]);
  }
  function rr() {
    return typeof window < "u";
  }
  function Lt(e) {
    return Sl(e) ? (e.nodeName || "").toLowerCase() : "#document";
  }
  function Ee(e) {
    var t;
    return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
  }
  function Ue(e) {
    var t;
    return (t = (Sl(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
  }
  function Sl(e) {
    return rr() ? e instanceof Node || e instanceof Ee(e).Node : false;
  }
  function be(e) {
    return rr() ? e instanceof Element || e instanceof Ee(e).Element : false;
  }
  function He(e) {
    return rr() ? e instanceof HTMLElement || e instanceof Ee(e).HTMLElement : false;
  }
  function Ma(e) {
    return !rr() || typeof ShadowRoot > "u" ? false : e instanceof ShadowRoot || e instanceof Ee(e).ShadowRoot;
  }
  const Mf = /* @__PURE__ */ new Set([
    "inline",
    "contents"
  ]);
  function mn(e) {
    const { overflow: t, overflowX: n, overflowY: r, display: s } = Re(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !Mf.has(s);
  }
  const Df = /* @__PURE__ */ new Set([
    "table",
    "td",
    "th"
  ]);
  function _f(e) {
    return Df.has(Lt(e));
  }
  const Bf = [
    ":popover-open",
    ":modal"
  ];
  function sr(e) {
    return Bf.some((t) => {
      try {
        return e.matches(t);
      } catch {
        return false;
      }
    });
  }
  const Hf = [
    "transform",
    "translate",
    "scale",
    "rotate",
    "perspective"
  ], Uf = [
    "transform",
    "translate",
    "scale",
    "rotate",
    "perspective",
    "filter"
  ], Vf = [
    "paint",
    "layout",
    "strict",
    "content"
  ];
  function Ss(e) {
    const t = Ts(), n = be(e) ? Re(e) : e;
    return Hf.some((r) => n[r] ? n[r] !== "none" : false) || (n.containerType ? n.containerType !== "normal" : false) || !t && (n.backdropFilter ? n.backdropFilter !== "none" : false) || !t && (n.filter ? n.filter !== "none" : false) || Uf.some((r) => (n.willChange || "").includes(r)) || Vf.some((r) => (n.contain || "").includes(r));
  }
  function Wf(e) {
    let t = tt(e);
    for (; He(t) && !Rt(t); ) {
      if (Ss(t))
        return t;
      if (sr(t))
        return null;
      t = tt(t);
    }
    return null;
  }
  function Ts() {
    return typeof CSS > "u" || !CSS.supports ? false : CSS.supports("-webkit-backdrop-filter", "none");
  }
  const zf = /* @__PURE__ */ new Set([
    "html",
    "body",
    "#document"
  ]);
  function Rt(e) {
    return zf.has(Lt(e));
  }
  function Re(e) {
    return Ee(e).getComputedStyle(e);
  }
  function ar(e) {
    return be(e) ? {
      scrollLeft: e.scrollLeft,
      scrollTop: e.scrollTop
    } : {
      scrollLeft: e.scrollX,
      scrollTop: e.scrollY
    };
  }
  function tt(e) {
    if (Lt(e) === "html")
      return e;
    const t = e.assignedSlot || e.parentNode || Ma(e) && e.host || Ue(e);
    return Ma(t) ? t.host : t;
  }
  function Tl(e) {
    const t = tt(e);
    return Rt(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : He(t) && mn(t) ? t : Tl(t);
  }
  function tn(e, t, n) {
    var r;
    t === void 0 && (t = []), n === void 0 && (n = true);
    const s = Tl(e), a = s === ((r = e.ownerDocument) == null ? void 0 : r.body), o = Ee(s);
    if (a) {
      const i = Qr(o);
      return t.concat(o, o.visualViewport || [], mn(s) ? s : [], i && n ? tn(i) : []);
    }
    return t.concat(s, tn(s, [], n));
  }
  function Qr(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
  }
  function Gf() {
    const e = navigator.userAgentData;
    return e && Array.isArray(e.brands) ? e.brands.map((t) => {
      let { brand: n, version: r } = t;
      return n + "/" + r;
    }).join(" ") : navigator.userAgent;
  }
  const mt = Math.min, me = Math.max, nn = Math.round, jn = Math.floor, Me = (e) => ({
    x: e,
    y: e
  }), Zf = {
    left: "right",
    right: "left",
    bottom: "top",
    top: "bottom"
  }, qf = {
    start: "end",
    end: "start"
  };
  function Da(e, t, n) {
    return me(e, mt(t, n));
  }
  function It(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  function nt(e) {
    return e.split("-")[0];
  }
  function gn(e) {
    return e.split("-")[1];
  }
  function $l(e) {
    return e === "x" ? "y" : "x";
  }
  function Rl(e) {
    return e === "y" ? "height" : "width";
  }
  const Kf = /* @__PURE__ */ new Set([
    "top",
    "bottom"
  ]);
  function Ve(e) {
    return Kf.has(nt(e)) ? "y" : "x";
  }
  function Al(e) {
    return $l(Ve(e));
  }
  function Yf(e, t, n) {
    n === void 0 && (n = false);
    const r = gn(e), s = Al(e), a = Rl(s);
    let o = s === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
    return t.reference[a] > t.floating[a] && (o = Hn(o)), [
      o,
      Hn(o)
    ];
  }
  function Xf(e) {
    const t = Hn(e);
    return [
      Jr(e),
      t,
      Jr(t)
    ];
  }
  function Jr(e) {
    return e.replace(/start|end/g, (t) => qf[t]);
  }
  const _a = [
    "left",
    "right"
  ], Ba = [
    "right",
    "left"
  ], Qf = [
    "top",
    "bottom"
  ], Jf = [
    "bottom",
    "top"
  ];
  function eh(e, t, n) {
    switch (e) {
      case "top":
      case "bottom":
        return n ? t ? Ba : _a : t ? _a : Ba;
      case "left":
      case "right":
        return t ? Qf : Jf;
      default:
        return [];
    }
  }
  function th(e, t, n, r) {
    const s = gn(e);
    let a = eh(nt(e), n === "start", r);
    return s && (a = a.map((o) => o + "-" + s), t && (a = a.concat(a.map(Jr)))), a;
  }
  function Hn(e) {
    return e.replace(/left|right|bottom|top/g, (t) => Zf[t]);
  }
  function nh(e) {
    return {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0,
      ...e
    };
  }
  function rh(e) {
    return typeof e != "number" ? nh(e) : {
      top: e,
      right: e,
      bottom: e,
      left: e
    };
  }
  function Un(e) {
    const { x: t, y: n, width: r, height: s } = e;
    return {
      width: r,
      height: s,
      top: n,
      left: t,
      right: t + r,
      bottom: n + s,
      x: t,
      y: n
    };
  }
  function Ha(e, t, n) {
    let { reference: r, floating: s } = e;
    const a = Ve(t), o = Al(t), i = Rl(o), c = nt(t), d = a === "y", f = r.x + r.width / 2 - s.width / 2, h = r.y + r.height / 2 - s.height / 2, g = r[i] / 2 - s[i] / 2;
    let m;
    switch (c) {
      case "top":
        m = {
          x: f,
          y: r.y - s.height
        };
        break;
      case "bottom":
        m = {
          x: f,
          y: r.y + r.height
        };
        break;
      case "right":
        m = {
          x: r.x + r.width,
          y: h
        };
        break;
      case "left":
        m = {
          x: r.x - s.width,
          y: h
        };
        break;
      default:
        m = {
          x: r.x,
          y: r.y
        };
    }
    switch (gn(t)) {
      case "start":
        m[o] -= g * (n && d ? -1 : 1);
        break;
      case "end":
        m[o] += g * (n && d ? -1 : 1);
        break;
    }
    return m;
  }
  const sh = async (e, t, n) => {
    const { placement: r = "bottom", strategy: s = "absolute", middleware: a = [], platform: o } = n, i = a.filter(Boolean), c = await (o.isRTL == null ? void 0 : o.isRTL(t));
    let d = await o.getElementRects({
      reference: e,
      floating: t,
      strategy: s
    }), { x: f, y: h } = Ha(d, r, c), g = r, m = {}, p = 0;
    for (let x = 0; x < i.length; x++) {
      const { name: b, fn: y } = i[x], { x: v, y: w, data: k, reset: E } = await y({
        x: f,
        y: h,
        initialPlacement: r,
        placement: g,
        strategy: s,
        middlewareData: m,
        rects: d,
        platform: o,
        elements: {
          reference: e,
          floating: t
        }
      });
      f = v ?? f, h = w ?? h, m = {
        ...m,
        [b]: {
          ...m[b],
          ...k
        }
      }, E && p <= 50 && (p++, typeof E == "object" && (E.placement && (g = E.placement), E.rects && (d = E.rects === true ? await o.getElementRects({
        reference: e,
        floating: t,
        strategy: s
      }) : E.rects), { x: f, y: h } = Ha(d, g, c)), x = -1);
    }
    return {
      x: f,
      y: h,
      placement: g,
      strategy: s,
      middlewareData: m
    };
  };
  async function or(e, t) {
    var n;
    t === void 0 && (t = {});
    const { x: r, y: s, platform: a, rects: o, elements: i, strategy: c } = e, { boundary: d = "clippingAncestors", rootBoundary: f = "viewport", elementContext: h = "floating", altBoundary: g = false, padding: m = 0 } = It(t, e), p = rh(m), b = i[g ? h === "floating" ? "reference" : "floating" : h], y = Un(await a.getClippingRect({
      element: (n = await (a.isElement == null ? void 0 : a.isElement(b))) == null || n ? b : b.contextElement || await (a.getDocumentElement == null ? void 0 : a.getDocumentElement(i.floating)),
      boundary: d,
      rootBoundary: f,
      strategy: c
    })), v = h === "floating" ? {
      x: r,
      y: s,
      width: o.floating.width,
      height: o.floating.height
    } : o.reference, w = await (a.getOffsetParent == null ? void 0 : a.getOffsetParent(i.floating)), k = await (a.isElement == null ? void 0 : a.isElement(w)) ? await (a.getScale == null ? void 0 : a.getScale(w)) || {
      x: 1,
      y: 1
    } : {
      x: 1,
      y: 1
    }, E = Un(a.convertOffsetParentRelativeRectToViewportRelativeRect ? await a.convertOffsetParentRelativeRectToViewportRelativeRect({
      elements: i,
      rect: v,
      offsetParent: w,
      strategy: c
    }) : v);
    return {
      top: (y.top - E.top + p.top) / k.y,
      bottom: (E.bottom - y.bottom + p.bottom) / k.y,
      left: (y.left - E.left + p.left) / k.x,
      right: (E.right - y.right + p.right) / k.x
    };
  }
  const ah = function(e) {
    return e === void 0 && (e = {}), {
      name: "flip",
      options: e,
      async fn(t) {
        var n, r;
        const { placement: s, middlewareData: a, rects: o, initialPlacement: i, platform: c, elements: d } = t, { mainAxis: f = true, crossAxis: h = true, fallbackPlacements: g, fallbackStrategy: m = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: x = true, ...b } = It(e, t);
        if ((n = a.arrow) != null && n.alignmentOffset)
          return {};
        const y = nt(s), v = Ve(i), w = nt(i) === i, k = await (c.isRTL == null ? void 0 : c.isRTL(d.floating)), E = g || (w || !x ? [
          Hn(i)
        ] : Xf(i)), N = p !== "none";
        !g && N && E.push(...th(i, x, p, k));
        const C = [
          i,
          ...E
        ], I = await or(t, b), H = [];
        let A = ((r = a.flip) == null ? void 0 : r.overflows) || [];
        if (f && H.push(I[y]), h) {
          const T = Yf(s, o, k);
          H.push(I[T[0]], I[T[1]]);
        }
        if (A = [
          ...A,
          {
            placement: s,
            overflows: H
          }
        ], !H.every((T) => T <= 0)) {
          var F, O;
          const T = (((F = a.flip) == null ? void 0 : F.index) || 0) + 1, L = C[T];
          if (L && (!(h === "alignment" ? v !== Ve(L) : false) || A.every((_) => Ve(_.placement) === v ? _.overflows[0] > 0 : true)))
            return {
              data: {
                index: T,
                overflows: A
              },
              reset: {
                placement: L
              }
            };
          let U = (O = A.filter((W) => W.overflows[0] <= 0).sort((W, _) => W.overflows[1] - _.overflows[1])[0]) == null ? void 0 : O.placement;
          if (!U)
            switch (m) {
              case "bestFit": {
                var M;
                const W = (M = A.filter((_) => {
                  if (N) {
                    const B = Ve(_.placement);
                    return B === v || B === "y";
                  }
                  return true;
                }).map((_) => [
                  _.placement,
                  _.overflows.filter((B) => B > 0).reduce((B, D) => B + D, 0)
                ]).sort((_, B) => _[1] - B[1])[0]) == null ? void 0 : M[0];
                W && (U = W);
                break;
              }
              case "initialPlacement":
                U = i;
                break;
            }
          if (s !== U)
            return {
              reset: {
                placement: U
              }
            };
        }
        return {};
      }
    };
  }, oh = /* @__PURE__ */ new Set([
    "left",
    "top"
  ]);
  async function lh(e, t) {
    const { placement: n, platform: r, elements: s } = e, a = await (r.isRTL == null ? void 0 : r.isRTL(s.floating)), o = nt(n), i = gn(n), c = Ve(n) === "y", d = oh.has(o) ? -1 : 1, f = a && c ? -1 : 1, h = It(t, e);
    let { mainAxis: g, crossAxis: m, alignmentAxis: p } = typeof h == "number" ? {
      mainAxis: h,
      crossAxis: 0,
      alignmentAxis: null
    } : {
      mainAxis: h.mainAxis || 0,
      crossAxis: h.crossAxis || 0,
      alignmentAxis: h.alignmentAxis
    };
    return i && typeof p == "number" && (m = i === "end" ? p * -1 : p), c ? {
      x: m * f,
      y: g * d
    } : {
      x: g * d,
      y: m * f
    };
  }
  const ih = function(e) {
    return e === void 0 && (e = 0), {
      name: "offset",
      options: e,
      async fn(t) {
        var n, r;
        const { x: s, y: a, placement: o, middlewareData: i } = t, c = await lh(t, e);
        return o === ((n = i.offset) == null ? void 0 : n.placement) && (r = i.arrow) != null && r.alignmentOffset ? {} : {
          x: s + c.x,
          y: a + c.y,
          data: {
            ...c,
            placement: o
          }
        };
      }
    };
  }, ch = function(e) {
    return e === void 0 && (e = {}), {
      name: "shift",
      options: e,
      async fn(t) {
        const { x: n, y: r, placement: s } = t, { mainAxis: a = true, crossAxis: o = false, limiter: i = {
          fn: (b) => {
            let { x: y, y: v } = b;
            return {
              x: y,
              y: v
            };
          }
        }, ...c } = It(e, t), d = {
          x: n,
          y: r
        }, f = await or(t, c), h = Ve(nt(s)), g = $l(h);
        let m = d[g], p = d[h];
        if (a) {
          const b = g === "y" ? "top" : "left", y = g === "y" ? "bottom" : "right", v = m + f[b], w = m - f[y];
          m = Da(v, m, w);
        }
        if (o) {
          const b = h === "y" ? "top" : "left", y = h === "y" ? "bottom" : "right", v = p + f[b], w = p - f[y];
          p = Da(v, p, w);
        }
        const x = i.fn({
          ...t,
          [g]: m,
          [h]: p
        });
        return {
          ...x,
          data: {
            x: x.x - n,
            y: x.y - r,
            enabled: {
              [g]: a,
              [h]: o
            }
          }
        };
      }
    };
  }, uh = function(e) {
    return e === void 0 && (e = {}), {
      name: "size",
      options: e,
      async fn(t) {
        var n, r;
        const { placement: s, rects: a, platform: o, elements: i } = t, { apply: c = () => {
        }, ...d } = It(e, t), f = await or(t, d), h = nt(s), g = gn(s), m = Ve(s) === "y", { width: p, height: x } = a.floating;
        let b, y;
        h === "top" || h === "bottom" ? (b = h, y = g === (await (o.isRTL == null ? void 0 : o.isRTL(i.floating)) ? "start" : "end") ? "left" : "right") : (y = h, b = g === "end" ? "top" : "bottom");
        const v = x - f.top - f.bottom, w = p - f.left - f.right, k = mt(x - f[b], v), E = mt(p - f[y], w), N = !t.middlewareData.shift;
        let C = k, I = E;
        if ((n = t.middlewareData.shift) != null && n.enabled.x && (I = w), (r = t.middlewareData.shift) != null && r.enabled.y && (C = v), N && !g) {
          const A = me(f.left, 0), F = me(f.right, 0), O = me(f.top, 0), M = me(f.bottom, 0);
          m ? I = p - 2 * (A !== 0 || F !== 0 ? A + F : me(f.left, f.right)) : C = x - 2 * (O !== 0 || M !== 0 ? O + M : me(f.top, f.bottom));
        }
        await c({
          ...t,
          availableWidth: I,
          availableHeight: C
        });
        const H = await o.getDimensions(i.floating);
        return p !== H.width || x !== H.height ? {
          reset: {
            rects: true
          }
        } : {};
      }
    };
  };
  function Pl(e) {
    const t = Re(e);
    let n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0;
    const s = He(e), a = s ? e.offsetWidth : n, o = s ? e.offsetHeight : r, i = nn(n) !== a || nn(r) !== o;
    return i && (n = a, r = o), {
      width: n,
      height: r,
      $: i
    };
  }
  function $s(e) {
    return be(e) ? e : e.contextElement;
  }
  function St(e) {
    const t = $s(e);
    if (!He(t))
      return Me(1);
    const n = t.getBoundingClientRect(), { width: r, height: s, $: a } = Pl(t);
    let o = (a ? nn(n.width) : n.width) / r, i = (a ? nn(n.height) : n.height) / s;
    return (!o || !Number.isFinite(o)) && (o = 1), (!i || !Number.isFinite(i)) && (i = 1), {
      x: o,
      y: i
    };
  }
  const dh = Me(0);
  function Ol(e) {
    const t = Ee(e);
    return !Ts() || !t.visualViewport ? dh : {
      x: t.visualViewport.offsetLeft,
      y: t.visualViewport.offsetTop
    };
  }
  function fh(e, t, n) {
    return t === void 0 && (t = false), !n || t && n !== Ee(e) ? false : t;
  }
  function gt(e, t, n, r) {
    t === void 0 && (t = false), n === void 0 && (n = false);
    const s = e.getBoundingClientRect(), a = $s(e);
    let o = Me(1);
    t && (r ? be(r) && (o = St(r)) : o = St(e));
    const i = fh(a, n, r) ? Ol(a) : Me(0);
    let c = (s.left + i.x) / o.x, d = (s.top + i.y) / o.y, f = s.width / o.x, h = s.height / o.y;
    if (a) {
      const g = Ee(a), m = r && be(r) ? Ee(r) : r;
      let p = g, x = Qr(p);
      for (; x && r && m !== p; ) {
        const b = St(x), y = x.getBoundingClientRect(), v = Re(x), w = y.left + (x.clientLeft + parseFloat(v.paddingLeft)) * b.x, k = y.top + (x.clientTop + parseFloat(v.paddingTop)) * b.y;
        c *= b.x, d *= b.y, f *= b.x, h *= b.y, c += w, d += k, p = Ee(x), x = Qr(p);
      }
    }
    return Un({
      width: f,
      height: h,
      x: c,
      y: d
    });
  }
  function lr(e, t) {
    const n = ar(e).scrollLeft;
    return t ? t.left + n : gt(Ue(e)).left + n;
  }
  function Ll(e, t) {
    const n = e.getBoundingClientRect(), r = n.left + t.scrollLeft - lr(e, n), s = n.top + t.scrollTop;
    return {
      x: r,
      y: s
    };
  }
  function hh(e) {
    let { elements: t, rect: n, offsetParent: r, strategy: s } = e;
    const a = s === "fixed", o = Ue(r), i = t ? sr(t.floating) : false;
    if (r === o || i && a)
      return n;
    let c = {
      scrollLeft: 0,
      scrollTop: 0
    }, d = Me(1);
    const f = Me(0), h = He(r);
    if ((h || !h && !a) && ((Lt(r) !== "body" || mn(o)) && (c = ar(r)), He(r))) {
      const m = gt(r);
      d = St(r), f.x = m.x + r.clientLeft, f.y = m.y + r.clientTop;
    }
    const g = o && !h && !a ? Ll(o, c) : Me(0);
    return {
      width: n.width * d.x,
      height: n.height * d.y,
      x: n.x * d.x - c.scrollLeft * d.x + f.x + g.x,
      y: n.y * d.y - c.scrollTop * d.y + f.y + g.y
    };
  }
  function ph(e) {
    return Array.from(e.getClientRects());
  }
  function mh(e) {
    const t = Ue(e), n = ar(e), r = e.ownerDocument.body, s = me(t.scrollWidth, t.clientWidth, r.scrollWidth, r.clientWidth), a = me(t.scrollHeight, t.clientHeight, r.scrollHeight, r.clientHeight);
    let o = -n.scrollLeft + lr(e);
    const i = -n.scrollTop;
    return Re(r).direction === "rtl" && (o += me(t.clientWidth, r.clientWidth) - s), {
      width: s,
      height: a,
      x: o,
      y: i
    };
  }
  const Ua = 25;
  function gh(e, t) {
    const n = Ee(e), r = Ue(e), s = n.visualViewport;
    let a = r.clientWidth, o = r.clientHeight, i = 0, c = 0;
    if (s) {
      a = s.width, o = s.height;
      const f = Ts();
      (!f || f && t === "fixed") && (i = s.offsetLeft, c = s.offsetTop);
    }
    const d = lr(r);
    if (d <= 0) {
      const f = r.ownerDocument, h = f.body, g = getComputedStyle(h), m = f.compatMode === "CSS1Compat" && parseFloat(g.marginLeft) + parseFloat(g.marginRight) || 0, p = Math.abs(r.clientWidth - h.clientWidth - m);
      p <= Ua && (a -= p);
    } else
      d <= Ua && (a += d);
    return {
      width: a,
      height: o,
      x: i,
      y: c
    };
  }
  const xh = /* @__PURE__ */ new Set([
    "absolute",
    "fixed"
  ]);
  function bh(e, t) {
    const n = gt(e, true, t === "fixed"), r = n.top + e.clientTop, s = n.left + e.clientLeft, a = He(e) ? St(e) : Me(1), o = e.clientWidth * a.x, i = e.clientHeight * a.y, c = s * a.x, d = r * a.y;
    return {
      width: o,
      height: i,
      x: c,
      y: d
    };
  }
  function Va(e, t, n) {
    let r;
    if (t === "viewport")
      r = gh(e, n);
    else if (t === "document")
      r = mh(Ue(e));
    else if (be(t))
      r = bh(t, n);
    else {
      const s = Ol(e);
      r = {
        x: t.x - s.x,
        y: t.y - s.y,
        width: t.width,
        height: t.height
      };
    }
    return Un(r);
  }
  function Il(e, t) {
    const n = tt(e);
    return n === t || !be(n) || Rt(n) ? false : Re(n).position === "fixed" || Il(n, t);
  }
  function vh(e, t) {
    const n = t.get(e);
    if (n)
      return n;
    let r = tn(e, [], false).filter((i) => be(i) && Lt(i) !== "body"), s = null;
    const a = Re(e).position === "fixed";
    let o = a ? tt(e) : e;
    for (; be(o) && !Rt(o); ) {
      const i = Re(o), c = Ss(o);
      !c && i.position === "fixed" && (s = null), (a ? !c && !s : !c && i.position === "static" && !!s && xh.has(s.position) || mn(o) && !c && Il(e, o)) ? r = r.filter((f) => f !== o) : s = i, o = tt(o);
    }
    return t.set(e, r), r;
  }
  function yh(e) {
    let { element: t, boundary: n, rootBoundary: r, strategy: s } = e;
    const o = [
      ...n === "clippingAncestors" ? sr(t) ? [] : vh(t, this._c) : [].concat(n),
      r
    ], i = o[0], c = o.reduce((d, f) => {
      const h = Va(t, f, s);
      return d.top = me(h.top, d.top), d.right = mt(h.right, d.right), d.bottom = mt(h.bottom, d.bottom), d.left = me(h.left, d.left), d;
    }, Va(t, i, s));
    return {
      width: c.right - c.left,
      height: c.bottom - c.top,
      x: c.left,
      y: c.top
    };
  }
  function wh(e) {
    const { width: t, height: n } = Pl(e);
    return {
      width: t,
      height: n
    };
  }
  function kh(e, t, n) {
    const r = He(t), s = Ue(t), a = n === "fixed", o = gt(e, true, a, t);
    let i = {
      scrollLeft: 0,
      scrollTop: 0
    };
    const c = Me(0);
    function d() {
      c.x = lr(s);
    }
    if (r || !r && !a)
      if ((Lt(t) !== "body" || mn(s)) && (i = ar(t)), r) {
        const m = gt(t, true, a, t);
        c.x = m.x + t.clientLeft, c.y = m.y + t.clientTop;
      } else
        s && d();
    a && !r && s && d();
    const f = s && !r && !a ? Ll(s, i) : Me(0), h = o.left + i.scrollLeft - c.x - f.x, g = o.top + i.scrollTop - c.y - f.y;
    return {
      x: h,
      y: g,
      width: o.width,
      height: o.height
    };
  }
  function Nr(e) {
    return Re(e).position === "static";
  }
  function Wa(e, t) {
    if (!He(e) || Re(e).position === "fixed")
      return null;
    if (t)
      return t(e);
    let n = e.offsetParent;
    return Ue(e) === n && (n = n.ownerDocument.body), n;
  }
  function Fl(e, t) {
    const n = Ee(e);
    if (sr(e))
      return n;
    if (!He(e)) {
      let s = tt(e);
      for (; s && !Rt(s); ) {
        if (be(s) && !Nr(s))
          return s;
        s = tt(s);
      }
      return n;
    }
    let r = Wa(e, t);
    for (; r && _f(r) && Nr(r); )
      r = Wa(r, t);
    return r && Rt(r) && Nr(r) && !Ss(r) ? n : r || Wf(e) || n;
  }
  const Eh = async function(e) {
    const t = this.getOffsetParent || Fl, n = this.getDimensions, r = await n(e.floating);
    return {
      reference: kh(e.reference, await t(e.floating), e.strategy),
      floating: {
        x: 0,
        y: 0,
        width: r.width,
        height: r.height
      }
    };
  };
  function jh(e) {
    return Re(e).direction === "rtl";
  }
  const Nh = {
    convertOffsetParentRelativeRectToViewportRelativeRect: hh,
    getDocumentElement: Ue,
    getClippingRect: yh,
    getOffsetParent: Fl,
    getElementRects: Eh,
    getClientRects: ph,
    getDimensions: wh,
    getScale: St,
    isElement: be,
    isRTL: jh
  };
  function Ml(e, t) {
    return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
  }
  function Ch(e, t) {
    let n = null, r;
    const s = Ue(e);
    function a() {
      var i;
      clearTimeout(r), (i = n) == null || i.disconnect(), n = null;
    }
    function o(i, c) {
      i === void 0 && (i = false), c === void 0 && (c = 1), a();
      const d = e.getBoundingClientRect(), { left: f, top: h, width: g, height: m } = d;
      if (i || t(), !g || !m)
        return;
      const p = jn(h), x = jn(s.clientWidth - (f + g)), b = jn(s.clientHeight - (h + m)), y = jn(f), w = {
        rootMargin: -p + "px " + -x + "px " + -b + "px " + -y + "px",
        threshold: me(0, mt(1, c)) || 1
      };
      let k = true;
      function E(N) {
        const C = N[0].intersectionRatio;
        if (C !== c) {
          if (!k)
            return o();
          C ? o(false, C) : r = setTimeout(() => {
            o(false, 1e-7);
          }, 1e3);
        }
        C === 1 && !Ml(d, e.getBoundingClientRect()) && o(), k = false;
      }
      try {
        n = new IntersectionObserver(E, {
          ...w,
          root: s.ownerDocument
        });
      } catch {
        n = new IntersectionObserver(E, w);
      }
      n.observe(e);
    }
    return o(true), a;
  }
  function Sh(e, t, n, r) {
    r === void 0 && (r = {});
    const { ancestorScroll: s = true, ancestorResize: a = true, elementResize: o = typeof ResizeObserver == "function", layoutShift: i = typeof IntersectionObserver == "function", animationFrame: c = false } = r, d = $s(e), f = s || a ? [
      ...d ? tn(d) : [],
      ...tn(t)
    ] : [];
    f.forEach((y) => {
      s && y.addEventListener("scroll", n, {
        passive: true
      }), a && y.addEventListener("resize", n);
    });
    const h = d && i ? Ch(d, n) : null;
    let g = -1, m = null;
    o && (m = new ResizeObserver((y) => {
      let [v] = y;
      v && v.target === d && m && (m.unobserve(t), cancelAnimationFrame(g), g = requestAnimationFrame(() => {
        var w;
        (w = m) == null || w.observe(t);
      })), n();
    }), d && !c && m.observe(d), m.observe(t));
    let p, x = c ? gt(e) : null;
    c && b();
    function b() {
      const y = gt(e);
      x && !Ml(x, y) && n(), x = y, p = requestAnimationFrame(b);
    }
    return n(), () => {
      var y;
      f.forEach((v) => {
        s && v.removeEventListener("scroll", n), a && v.removeEventListener("resize", n);
      }), h == null ? void 0 : h(), (y = m) == null || y.disconnect(), m = null, c && cancelAnimationFrame(p);
    };
  }
  const Cr = or, Th = ih, $h = ch, Rh = ah, Ah = uh, Ph = (e, t, n) => {
    const r = /* @__PURE__ */ new Map(), s = {
      platform: Nh,
      ...n
    }, a = {
      ...s.platform,
      _c: r
    };
    return sh(e, t, {
      ...s,
      platform: a
    });
  };
  var Oh = typeof document < "u", Lh = function() {
  }, Sn = Oh ? u.useLayoutEffect : Lh;
  function Vn(e, t) {
    if (e === t)
      return true;
    if (typeof e != typeof t)
      return false;
    if (typeof e == "function" && e.toString() === t.toString())
      return true;
    let n, r, s;
    if (e && t && typeof e == "object") {
      if (Array.isArray(e)) {
        if (n = e.length, n !== t.length)
          return false;
        for (r = n; r-- !== 0; )
          if (!Vn(e[r], t[r]))
            return false;
        return true;
      }
      if (s = Object.keys(e), n = s.length, n !== Object.keys(t).length)
        return false;
      for (r = n; r-- !== 0; )
        if (!{}.hasOwnProperty.call(t, s[r]))
          return false;
      for (r = n; r-- !== 0; ) {
        const a = s[r];
        if (!(a === "_owner" && e.$$typeof) && !Vn(e[a], t[a]))
          return false;
      }
      return true;
    }
    return e !== e && t !== t;
  }
  function Dl(e) {
    return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
  }
  function za(e, t) {
    const n = Dl(e);
    return Math.round(t * n) / n;
  }
  function Sr(e) {
    const t = u.useRef(e);
    return Sn(() => {
      t.current = e;
    }), t;
  }
  function Ih(e) {
    e === void 0 && (e = {});
    const { placement: t = "bottom", strategy: n = "absolute", middleware: r = [], platform: s, elements: { reference: a, floating: o } = {}, transform: i = true, whileElementsMounted: c, open: d } = e, [f, h] = u.useState({
      x: 0,
      y: 0,
      strategy: n,
      placement: t,
      middlewareData: {},
      isPositioned: false
    }), [g, m] = u.useState(r);
    Vn(g, r) || m(r);
    const [p, x] = u.useState(null), [b, y] = u.useState(null), v = u.useCallback((_) => {
      _ !== N.current && (N.current = _, x(_));
    }, []), w = u.useCallback((_) => {
      _ !== C.current && (C.current = _, y(_));
    }, []), k = a || p, E = o || b, N = u.useRef(null), C = u.useRef(null), I = u.useRef(f), H = c != null, A = Sr(c), F = Sr(s), O = Sr(d), M = u.useCallback(() => {
      if (!N.current || !C.current)
        return;
      const _ = {
        placement: t,
        strategy: n,
        middleware: g
      };
      F.current && (_.platform = F.current), Ph(N.current, C.current, _).then((B) => {
        const D = {
          ...B,
          isPositioned: O.current !== false
        };
        T.current && !Vn(I.current, D) && (I.current = D, xe.flushSync(() => {
          h(D);
        }));
      });
    }, [
      g,
      t,
      n,
      F,
      O
    ]);
    Sn(() => {
      d === false && I.current.isPositioned && (I.current.isPositioned = false, h((_) => ({
        ..._,
        isPositioned: false
      })));
    }, [
      d
    ]);
    const T = u.useRef(false);
    Sn(() => (T.current = true, () => {
      T.current = false;
    }), []), Sn(() => {
      if (k && (N.current = k), E && (C.current = E), k && E) {
        if (A.current)
          return A.current(k, E, M);
        M();
      }
    }, [
      k,
      E,
      M,
      A,
      H
    ]);
    const L = u.useMemo(() => ({
      reference: N,
      floating: C,
      setReference: v,
      setFloating: w
    }), [
      v,
      w
    ]), U = u.useMemo(() => ({
      reference: k,
      floating: E
    }), [
      k,
      E
    ]), W = u.useMemo(() => {
      const _ = {
        position: n,
        left: 0,
        top: 0
      };
      if (!U.floating)
        return _;
      const B = za(U.floating, f.x), D = za(U.floating, f.y);
      return i ? {
        ..._,
        transform: "translate(" + B + "px, " + D + "px)",
        ...Dl(U.floating) >= 1.5 && {
          willChange: "transform"
        }
      } : {
        position: n,
        left: B,
        top: D
      };
    }, [
      n,
      i,
      U.floating,
      f.x,
      f.y
    ]);
    return u.useMemo(() => ({
      ...f,
      update: M,
      refs: L,
      elements: U,
      floatingStyles: W
    }), [
      f,
      M,
      L,
      U,
      W
    ]);
  }
  const _l = (e, t) => ({
    ...Th(e),
    options: [
      e,
      t
    ]
  }), Fh = (e, t) => ({
    ...$h(e),
    options: [
      e,
      t
    ]
  }), Mh = (e, t) => ({
    ...Rh(e),
    options: [
      e,
      t
    ]
  }), Dh = (e, t) => ({
    ...Ah(e),
    options: [
      e,
      t
    ]
  }), Bl = {
    ...Rn
  }, _h = Bl.useInsertionEffect, Bh = _h || ((e) => e());
  function Hl(e) {
    const t = u.useRef(() => {
    });
    return Bh(() => {
      t.current = e;
    }), u.useCallback(function() {
      for (var n = arguments.length, r = new Array(n), s = 0; s < n; s++)
        r[s] = arguments[s];
      return t.current == null ? void 0 : t.current(...r);
    }, []);
  }
  var es = typeof document < "u" ? u.useLayoutEffect : u.useEffect;
  let Ga = false, Hh = 0;
  const Za = () => "floating-ui-" + Math.random().toString(36).slice(2, 6) + Hh++;
  function Uh() {
    const [e, t] = u.useState(() => Ga ? Za() : void 0);
    return es(() => {
      e == null && t(Za());
    }, []), u.useEffect(() => {
      Ga = true;
    }, []), e;
  }
  const Vh = Bl.useId, Wh = Vh || Uh;
  function zh() {
    const e = /* @__PURE__ */ new Map();
    return {
      emit(t, n) {
        var r;
        (r = e.get(t)) == null || r.forEach((s) => s(n));
      },
      on(t, n) {
        e.set(t, [
          ...e.get(t) || [],
          n
        ]);
      },
      off(t, n) {
        var r;
        e.set(t, ((r = e.get(t)) == null ? void 0 : r.filter((s) => s !== n)) || []);
      }
    };
  }
  const Gh = u.createContext(null), Zh = u.createContext(null), qh = () => {
    var e;
    return ((e = u.useContext(Gh)) == null ? void 0 : e.id) || null;
  }, Kh = () => u.useContext(Zh), Yh = "data-floating-ui-focusable";
  function Xh(e) {
    const { open: t = false, onOpenChange: n, elements: r } = e, s = Wh(), a = u.useRef({}), [o] = u.useState(() => zh()), i = qh() != null, [c, d] = u.useState(r.reference), f = Hl((m, p, x) => {
      a.current.openEvent = m ? p : void 0, o.emit("openchange", {
        open: m,
        event: p,
        reason: x,
        nested: i
      }), n == null ? void 0 : n(m, p, x);
    }), h = u.useMemo(() => ({
      setPositionReference: d
    }), []), g = u.useMemo(() => ({
      reference: c || r.reference || null,
      floating: r.floating || null,
      domReference: r.reference
    }), [
      c,
      r.reference,
      r.floating
    ]);
    return u.useMemo(() => ({
      dataRef: a,
      open: t,
      onOpenChange: f,
      elements: g,
      events: o,
      floatingId: s,
      refs: h
    }), [
      t,
      f,
      g,
      o,
      s,
      h
    ]);
  }
  function Qh(e) {
    e === void 0 && (e = {});
    const { nodeId: t } = e, n = Xh({
      ...e,
      elements: {
        reference: null,
        floating: null,
        ...e.elements
      }
    }), r = e.rootContext || n, s = r.elements, [a, o] = u.useState(null), [i, c] = u.useState(null), f = (s == null ? void 0 : s.domReference) || a, h = u.useRef(null), g = Kh();
    es(() => {
      f && (h.current = f);
    }, [
      f
    ]);
    const m = Ih({
      ...e,
      elements: {
        ...s,
        ...i && {
          reference: i
        }
      }
    }), p = u.useCallback((w) => {
      const k = be(w) ? {
        getBoundingClientRect: () => w.getBoundingClientRect(),
        contextElement: w
      } : w;
      c(k), m.refs.setReference(k);
    }, [
      m.refs
    ]), x = u.useCallback((w) => {
      (be(w) || w === null) && (h.current = w, o(w)), (be(m.refs.reference.current) || m.refs.reference.current === null || w !== null && !be(w)) && m.refs.setReference(w);
    }, [
      m.refs
    ]), b = u.useMemo(() => ({
      ...m.refs,
      setReference: x,
      setPositionReference: p,
      domReference: h
    }), [
      m.refs,
      x,
      p
    ]), y = u.useMemo(() => ({
      ...m.elements,
      domReference: f
    }), [
      m.elements,
      f
    ]), v = u.useMemo(() => ({
      ...m,
      ...r,
      refs: b,
      elements: y,
      nodeId: t
    }), [
      m,
      b,
      y,
      t,
      r
    ]);
    return es(() => {
      r.dataRef.current.floatingContext = v;
      const w = g == null ? void 0 : g.nodesRef.current.find((k) => k.id === t);
      w && (w.context = v);
    }), u.useMemo(() => ({
      ...m,
      context: v,
      refs: b,
      elements: y
    }), [
      m,
      b,
      y,
      v
    ]);
  }
  const qa = "active", Ka = "selected";
  function Tr(e, t, n) {
    const r = /* @__PURE__ */ new Map(), s = n === "item";
    let a = e;
    if (s && e) {
      const { [qa]: o, [Ka]: i, ...c } = e;
      a = c;
    }
    return {
      ...n === "floating" && {
        tabIndex: -1,
        [Yh]: ""
      },
      ...a,
      ...t.map((o) => {
        const i = o ? o[n] : null;
        return typeof i == "function" ? e ? i(e) : null : i;
      }).concat(e).reduce((o, i) => (i && Object.entries(i).forEach((c) => {
        let [d, f] = c;
        if (!(s && [
          qa,
          Ka
        ].includes(d)))
          if (d.indexOf("on") === 0) {
            if (r.has(d) || r.set(d, []), typeof f == "function") {
              var h;
              (h = r.get(d)) == null || h.push(f), o[d] = function() {
                for (var g, m = arguments.length, p = new Array(m), x = 0; x < m; x++)
                  p[x] = arguments[x];
                return (g = r.get(d)) == null ? void 0 : g.map((b) => b(...p)).find((b) => b !== void 0);
              };
            }
          } else
            o[d] = f;
      }), o), {})
    };
  }
  function Jh(e) {
    e === void 0 && (e = []);
    const t = e.map((i) => i == null ? void 0 : i.reference), n = e.map((i) => i == null ? void 0 : i.floating), r = e.map((i) => i == null ? void 0 : i.item), s = u.useCallback((i) => Tr(i, e, "reference"), t), a = u.useCallback((i) => Tr(i, e, "floating"), n), o = u.useCallback((i) => Tr(i, e, "item"), r);
    return u.useMemo(() => ({
      getReferenceProps: s,
      getFloatingProps: a,
      getItemProps: o
    }), [
      s,
      a,
      o
    ]);
  }
  function Ya(e, t) {
    return {
      ...e,
      rects: {
        ...e.rects,
        floating: {
          ...e.rects.floating,
          height: t
        }
      }
    };
  }
  const ep = (e) => ({
    name: "inner",
    options: e,
    async fn(t) {
      const { listRef: n, overflowRef: r, onFallbackChange: s, offset: a = 0, index: o = 0, minItemsVisible: i = 4, referenceOverflowThreshold: c = 0, scrollRef: d, ...f } = It(e, t), { rects: h, elements: { floating: g } } = t, m = n.current[o], p = (d == null ? void 0 : d.current) || g, x = g.clientTop || p.clientTop, b = g.clientTop !== 0, y = p.clientTop !== 0, v = g === p;
      if (!m)
        return {};
      const w = {
        ...t,
        ...await _l(-m.offsetTop - g.clientTop - h.reference.height / 2 - m.offsetHeight / 2 - a).fn(t)
      }, k = await Cr(Ya(w, p.scrollHeight + x + g.clientTop), f), E = await Cr(w, {
        ...f,
        elementContext: "reference"
      }), N = me(0, k.top), C = w.y + N, A = (p.scrollHeight > p.clientHeight ? (F) => F : nn)(me(0, p.scrollHeight + (b && v || y ? x * 2 : 0) - N - me(0, k.bottom)));
      if (p.style.maxHeight = A + "px", p.scrollTop = N, s) {
        const F = p.offsetHeight < m.offsetHeight * mt(i, n.current.length) - 1 || E.top >= -c || E.bottom >= -c;
        xe.flushSync(() => s(F));
      }
      return r && (r.current = await Cr(Ya({
        ...w,
        y: C
      }, p.offsetHeight + x + g.clientTop), f)), {
        y: C
      };
    }
  });
  function tp(e, t) {
    const { open: n, elements: r } = e, { enabled: s = true, overflowRef: a, scrollRef: o, onChange: i } = t, c = Hl(i), d = u.useRef(false), f = u.useRef(null), h = u.useRef(null);
    u.useEffect(() => {
      if (!s)
        return;
      function m(x) {
        if (x.ctrlKey || !p || a.current == null)
          return;
        const b = x.deltaY, y = a.current.top >= -0.5, v = a.current.bottom >= -0.5, w = p.scrollHeight - p.clientHeight, k = b < 0 ? -1 : 1, E = b < 0 ? "max" : "min";
        p.scrollHeight <= p.clientHeight || (!y && b > 0 || !v && b < 0 ? (x.preventDefault(), xe.flushSync(() => {
          c((N) => N + Math[E](b, w * k));
        })) : /firefox/i.test(Gf()) && (p.scrollTop += b));
      }
      const p = (o == null ? void 0 : o.current) || r.floating;
      if (n && p)
        return p.addEventListener("wheel", m), requestAnimationFrame(() => {
          f.current = p.scrollTop, a.current != null && (h.current = {
            ...a.current
          });
        }), () => {
          f.current = null, h.current = null, p.removeEventListener("wheel", m);
        };
    }, [
      s,
      n,
      r.floating,
      a,
      o,
      c
    ]);
    const g = u.useMemo(() => ({
      onKeyDown() {
        d.current = true;
      },
      onWheel() {
        d.current = false;
      },
      onPointerMove() {
        d.current = false;
      },
      onScroll() {
        const m = (o == null ? void 0 : o.current) || r.floating;
        if (!(!a.current || !m || !d.current)) {
          if (f.current !== null) {
            const p = m.scrollTop - f.current;
            (a.current.bottom < -0.5 && p < -1 || a.current.top < -0.5 && p > 1) && xe.flushSync(() => c((x) => x + p));
          }
          requestAnimationFrame(() => {
            f.current = m.scrollTop;
          });
        }
      }
    }), [
      r.floating,
      c,
      a,
      o
    ]);
    return u.useMemo(() => s ? {
      floating: g
    } : {}, [
      s,
      g
    ]);
  }
  let xn = u.createContext({
    styles: void 0,
    setReference: () => {
    },
    setFloating: () => {
    },
    getReferenceProps: () => ({}),
    getFloatingProps: () => ({}),
    slot: {}
  });
  xn.displayName = "FloatingContext";
  let Rs = u.createContext(null);
  Rs.displayName = "PlacementContext";
  function Ul(e) {
    return u.useMemo(() => e ? typeof e == "string" ? {
      to: e
    } : e : null, [
      e
    ]);
  }
  function Vl() {
    return u.useContext(xn).setReference;
  }
  function Wl() {
    let { getFloatingProps: e, slot: t } = u.useContext(xn);
    return u.useCallback((...n) => Object.assign({}, e(...n), {
      "data-anchor": t.anchor
    }), [
      e,
      t
    ]);
  }
  function zl(e = null) {
    e === false && (e = null), typeof e == "string" && (e = {
      to: e
    });
    let t = u.useContext(Rs), n = u.useMemo(() => e, [
      JSON.stringify(e, (s, a) => {
        var o;
        return (o = a == null ? void 0 : a.outerHTML) != null ? o : a;
      })
    ]);
    X(() => {
      t == null ? void 0 : t(n ?? null);
    }, [
      t,
      n
    ]);
    let r = u.useContext(xn);
    return u.useMemo(() => [
      r.setFloating,
      e ? r.styles : {}
    ], [
      r.setFloating,
      e,
      r.styles
    ]);
  }
  let Xa = 4;
  function Gl({ children: e, enabled: t = true }) {
    let [n, r] = u.useState(null), [s, a] = u.useState(0), o = u.useRef(null), [i, c] = u.useState(null);
    np(i);
    let d = t && n !== null && i !== null, { to: f = "bottom", gap: h = 0, offset: g = 0, padding: m = 0, inner: p } = rp(n, i), [x, b = "center"] = f.split(" ");
    X(() => {
      d && a(0);
    }, [
      d
    ]);
    let { refs: y, floatingStyles: v, context: w } = Qh({
      open: d,
      placement: x === "selection" ? b === "center" ? "bottom" : `bottom-${b}` : b === "center" ? `${x}` : `${x}-${b}`,
      strategy: "absolute",
      transform: false,
      middleware: [
        _l({
          mainAxis: x === "selection" ? 0 : h,
          crossAxis: g
        }),
        Fh({
          padding: m
        }),
        x !== "selection" && Mh({
          padding: m
        }),
        x === "selection" && p ? ep({
          ...p,
          padding: m,
          overflowRef: o,
          offset: s,
          minItemsVisible: Xa,
          referenceOverflowThreshold: m,
          onFallbackChange(F) {
            var O, M;
            if (!F)
              return;
            let T = w.elements.floating;
            if (!T)
              return;
            let L = parseFloat(getComputedStyle(T).scrollPaddingBottom) || 0, U = Math.min(Xa, T.childElementCount), W = 0, _ = 0;
            for (let B of (M = (O = w.elements.floating) == null ? void 0 : O.childNodes) != null ? M : [])
              if (ve(B)) {
                let D = B.offsetTop, K = D + B.clientHeight + L, $ = T.scrollTop, S = $ + T.clientHeight;
                if (D >= $ && K <= S)
                  U--;
                else {
                  _ = Math.max(0, Math.min(K, S) - Math.max(D, $)), W = B.clientHeight;
                  break;
                }
              }
            U >= 1 && a((B) => {
              let D = W * U - _ + L;
              return B >= D ? B : D;
            });
          }
        }) : null,
        Dh({
          padding: m,
          apply({ availableWidth: F, availableHeight: O, elements: M }) {
            Object.assign(M.floating.style, {
              overflow: "auto",
              maxWidth: `${F}px`,
              maxHeight: `min(var(--anchor-max-height, 100vh), ${O}px)`
            });
          }
        })
      ].filter(Boolean),
      whileElementsMounted: Sh
    }), [k = x, E = b] = w.placement.split("-");
    x === "selection" && (k = "selection");
    let N = u.useMemo(() => ({
      anchor: [
        k,
        E
      ].filter(Boolean).join(" ")
    }), [
      k,
      E
    ]), C = tp(w, {
      overflowRef: o,
      onChange: a
    }), { getReferenceProps: I, getFloatingProps: H } = Jh([
      C
    ]), A = R((F) => {
      c(F), y.setFloating(F);
    });
    return u.createElement(Rs.Provider, {
      value: r
    }, u.createElement(xn.Provider, {
      value: {
        setFloating: A,
        setReference: y.setReference,
        styles: v,
        getReferenceProps: I,
        getFloatingProps: H,
        slot: N
      }
    }, e));
  }
  function np(e) {
    X(() => {
      if (!e)
        return;
      let t = new MutationObserver(() => {
        let n = window.getComputedStyle(e).maxHeight, r = parseFloat(n);
        if (isNaN(r))
          return;
        let s = parseInt(n);
        isNaN(s) || r !== s && (e.style.maxHeight = `${Math.ceil(r)}px`);
      });
      return t.observe(e, {
        attributes: true,
        attributeFilter: [
          "style"
        ]
      }), () => {
        t.disconnect();
      };
    }, [
      e
    ]);
  }
  function rp(e, t) {
    var n, r, s;
    let a = $r((n = e == null ? void 0 : e.gap) != null ? n : "var(--anchor-gap, 0)", t), o = $r((r = e == null ? void 0 : e.offset) != null ? r : "var(--anchor-offset, 0)", t), i = $r((s = e == null ? void 0 : e.padding) != null ? s : "var(--anchor-padding, 0)", t);
    return {
      ...e,
      gap: a,
      offset: o,
      padding: i
    };
  }
  function $r(e, t, n = void 0) {
    let r = Ke(), s = R((c, d) => {
      if (c == null)
        return [
          n,
          null
        ];
      if (typeof c == "number")
        return [
          c,
          null
        ];
      if (typeof c == "string") {
        if (!d)
          return [
            n,
            null
          ];
        let f = Qa(c, d);
        return [
          f,
          (h) => {
            let g = Zl(c);
            {
              let m = g.map((p) => window.getComputedStyle(d).getPropertyValue(p));
              r.requestAnimationFrame(function p() {
                r.nextFrame(p);
                let x = false;
                for (let [y, v] of g.entries()) {
                  let w = window.getComputedStyle(d).getPropertyValue(v);
                  if (m[y] !== w) {
                    m[y] = w, x = true;
                    break;
                  }
                }
                if (!x)
                  return;
                let b = Qa(c, d);
                f !== b && (h(b), f = b);
              });
            }
            return r.dispose;
          }
        ];
      }
      return [
        n,
        null
      ];
    }), a = u.useMemo(() => s(e, t)[0], [
      e,
      t
    ]), [o = a, i] = u.useState();
    return X(() => {
      let [c, d] = s(e, t);
      if (i(c), !!d)
        return d(i);
    }, [
      e,
      t
    ]), o;
  }
  function Zl(e) {
    let t = /var\((.*)\)/.exec(e);
    if (t) {
      let n = t[1].indexOf(",");
      if (n === -1)
        return [
          t[1]
        ];
      let r = t[1].slice(0, n).trim(), s = t[1].slice(n + 1).trim();
      return s ? [
        r,
        ...Zl(s)
      ] : [
        r
      ];
    }
    return [];
  }
  function Qa(e, t) {
    let n = document.createElement("div");
    t.appendChild(n), n.style.setProperty("margin-top", "0px", "important"), n.style.setProperty("margin-top", e, "important");
    let r = parseFloat(window.getComputedStyle(n).marginTop) || 0;
    return t.removeChild(n), r;
  }
  function sp({ children: e, freeze: t }, n) {
    let r = ts(t, e);
    return u.isValidElement(r) ? u.cloneElement(r, {
      ref: n
    }) : j.createElement(j.Fragment, null, r);
  }
  const ap = j.forwardRef(sp);
  function ts(e, t) {
    let [n, r] = u.useState(t);
    return !e && n !== t && r(t), e ? n : t;
  }
  let ir = u.createContext(null);
  ir.displayName = "OpenClosedContext";
  var ie = ((e) => (e[e.Open = 1] = "Open", e[e.Closed = 2] = "Closed", e[e.Closing = 4] = "Closing", e[e.Opening = 8] = "Opening", e))(ie || {});
  function vt() {
    return u.useContext(ir);
  }
  function As({ value: e, children: t }) {
    return j.createElement(ir.Provider, {
      value: e
    }, t);
  }
  function ql({ children: e }) {
    return j.createElement(ir.Provider, {
      value: null
    }, e);
  }
  function op(e) {
    function t() {
      document.readyState !== "loading" && (e(), document.removeEventListener("DOMContentLoaded", t));
    }
    typeof window < "u" && typeof document < "u" && (document.addEventListener("DOMContentLoaded", t), t());
  }
  let Oe = [];
  op(() => {
    function e(t) {
      if (!Le(t.target) || t.target === document.body || Oe[0] === t.target)
        return;
      let n = t.target;
      n = n.closest(Bn), Oe.unshift(n ?? t.target), Oe = Oe.filter((r) => r != null && r.isConnected), Oe.splice(10);
    }
    window.addEventListener("click", e, {
      capture: true
    }), window.addEventListener("mousedown", e, {
      capture: true
    }), window.addEventListener("focus", e, {
      capture: true
    }), document.body.addEventListener("click", e, {
      capture: true
    }), document.body.addEventListener("mousedown", e, {
      capture: true
    }), document.body.addEventListener("focus", e, {
      capture: true
    });
  });
  function lp(e) {
    throw new Error("Unexpected object: " + e);
  }
  var fe = ((e) => (e[e.First = 0] = "First", e[e.Previous = 1] = "Previous", e[e.Next = 2] = "Next", e[e.Last = 3] = "Last", e[e.Specific = 4] = "Specific", e[e.Nothing = 5] = "Nothing", e))(fe || {});
  function Ja(e, t) {
    let n = t.resolveItems();
    if (n.length <= 0)
      return null;
    let r = t.resolveActiveIndex(), s = r ?? -1;
    switch (e.focus) {
      case 0: {
        for (let a = 0; a < n.length; ++a)
          if (!t.resolveDisabled(n[a], a, n))
            return a;
        return r;
      }
      case 1: {
        s === -1 && (s = n.length);
        for (let a = s - 1; a >= 0; --a)
          if (!t.resolveDisabled(n[a], a, n))
            return a;
        return r;
      }
      case 2: {
        for (let a = s + 1; a < n.length; ++a)
          if (!t.resolveDisabled(n[a], a, n))
            return a;
        return r;
      }
      case 3: {
        for (let a = n.length - 1; a >= 0; --a)
          if (!t.resolveDisabled(n[a], a, n))
            return a;
        return r;
      }
      case 4: {
        for (let a = 0; a < n.length; ++a)
          if (t.resolveId(n[a], a, n) === e.id)
            return a;
        return r;
      }
      case 5:
        return null;
      default:
        lp(e);
    }
  }
  function cr(e) {
    let t = R(e), n = u.useRef(false);
    u.useEffect(() => (n.current = false, () => {
      n.current = true, un(() => {
        n.current && t();
      });
    }), [
      t
    ]);
  }
  let Kl = u.createContext(false);
  function ip() {
    return u.useContext(Kl);
  }
  function eo(e) {
    return j.createElement(Kl.Provider, {
      value: e.force
    }, e.children);
  }
  function cp(e) {
    let t = ip(), n = u.useContext(Xl), [r, s] = u.useState(() => {
      var a;
      if (!t && n !== null)
        return (a = n.current) != null ? a : null;
      if (Fe.isServer)
        return null;
      let o = e == null ? void 0 : e.getElementById("headlessui-portal-root");
      if (o)
        return o;
      if (e === null)
        return null;
      let i = e.createElement("div");
      return i.setAttribute("id", "headlessui-portal-root"), e.body.appendChild(i);
    });
    return u.useEffect(() => {
      r !== null && (e != null && e.body.contains(r) || e == null || e.body.appendChild(r));
    }, [
      r,
      e
    ]), u.useEffect(() => {
      t || n !== null && s(n.current);
    }, [
      n,
      s,
      t
    ]), r;
  }
  let Yl = u.Fragment, up = Q(function(e, t) {
    let { ownerDocument: n = null, ...r } = e, s = u.useRef(null), a = ne(ol((g) => {
      s.current = g;
    }), t), o = pt(s.current), i = n ?? o, c = cp(i), d = u.useContext(ns), f = Ke(), h = J();
    return cr(() => {
      var g;
      c && c.childNodes.length <= 0 && ((g = c.parentElement) == null || g.removeChild(c));
    }), c ? xe.createPortal(j.createElement("div", {
      "data-headlessui-portal": "",
      ref: (g) => {
        f.dispose(), d && g && f.add(d.register(g));
      }
    }, h({
      ourProps: {
        ref: a
      },
      theirProps: r,
      slot: {},
      defaultTag: Yl,
      name: "Portal"
    })), c) : null;
  });
  function dp(e, t) {
    let n = ne(t), { enabled: r = true, ownerDocument: s, ...a } = e, o = J();
    return r ? j.createElement(up, {
      ...a,
      ownerDocument: s,
      ref: n
    }) : o({
      ourProps: {
        ref: n
      },
      theirProps: a,
      slot: {},
      defaultTag: Yl,
      name: "Portal"
    });
  }
  let fp = u.Fragment, Xl = u.createContext(null);
  function hp(e, t) {
    let { target: n, ...r } = e, s = {
      ref: ne(t)
    }, a = J();
    return j.createElement(Xl.Provider, {
      value: n
    }, a({
      ourProps: s,
      theirProps: r,
      defaultTag: fp,
      name: "Popover.Group"
    }));
  }
  let ns = u.createContext(null);
  function Ql() {
    let e = u.useContext(ns), t = u.useRef([]), n = R((a) => (t.current.push(a), e && e.register(a), () => r(a))), r = R((a) => {
      let o = t.current.indexOf(a);
      o !== -1 && t.current.splice(o, 1), e && e.unregister(a);
    }), s = u.useMemo(() => ({
      register: n,
      unregister: r,
      portals: t
    }), [
      n,
      r,
      t
    ]);
    return [
      t,
      u.useMemo(() => function({ children: a }) {
        return j.createElement(ns.Provider, {
          value: s
        }, a);
      }, [
        s
      ])
    ];
  }
  let pp = Q(dp), Jl = Q(hp), Ps = Object.assign(pp, {
    Group: Jl
  });
  const zt = {
    Idle: {
      kind: "Idle"
    },
    Tracked: (e) => ({
      kind: "Tracked",
      position: e
    }),
    Moved: {
      kind: "Moved"
    }
  };
  function ei(e) {
    let t = e.getBoundingClientRect();
    return `${t.x},${t.y}`;
  }
  function mp(e, t, n) {
    let r = Se();
    if (t.kind === "Tracked") {
      let s = function() {
        a !== ei(e) && (r.dispose(), n());
      }, { position: a } = t, o = new ResizeObserver(s);
      o.observe(e), r.add(() => o.disconnect()), r.addEventListener(window, "scroll", s, {
        passive: true
      }), r.addEventListener(window, "resize", s);
    }
    return () => r.dispose();
  }
  var gp = Object.defineProperty, xp = (e, t, n) => t in e ? gp(e, t, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: n
  }) : e[t] = n, to = (e, t, n) => (xp(e, typeof t != "symbol" ? t + "" : t, n), n), q = ((e) => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(q || {}), we = ((e) => (e[e.Single = 0] = "Single", e[e.Multi = 1] = "Multi", e))(we || {}), De = ((e) => (e[e.Pointer = 0] = "Pointer", e[e.Focus = 1] = "Focus", e[e.Other = 2] = "Other", e))(De || {}), ti = ((e) => (e[e.OpenCombobox = 0] = "OpenCombobox", e[e.CloseCombobox = 1] = "CloseCombobox", e[e.GoToOption = 2] = "GoToOption", e[e.SetTyping = 3] = "SetTyping", e[e.RegisterOption = 4] = "RegisterOption", e[e.UnregisterOption = 5] = "UnregisterOption", e[e.DefaultToFirstOption = 6] = "DefaultToFirstOption", e[e.SetActivationTrigger = 7] = "SetActivationTrigger", e[e.UpdateVirtualConfiguration = 8] = "UpdateVirtualConfiguration", e[e.SetInputElement = 9] = "SetInputElement", e[e.SetButtonElement = 10] = "SetButtonElement", e[e.SetOptionsElement = 11] = "SetOptionsElement", e[e.MarkInputAsMoved = 12] = "MarkInputAsMoved", e))(ti || {});
  function Rr(e, t = (n) => n) {
    let n = e.activeOptionIndex !== null ? e.options[e.activeOptionIndex] : null, r = t(e.options.slice()), s = r.length > 0 && r[0].dataRef.current.order !== null ? r.sort((o, i) => o.dataRef.current.order - i.dataRef.current.order) : ut(r, (o) => o.dataRef.current.domRef.current), a = n ? s.indexOf(n) : null;
    return a === -1 && (a = null), {
      options: s,
      activeOptionIndex: a
    };
  }
  let bp = {
    1(e) {
      var t;
      if ((t = e.dataRef.current) != null && t.disabled || e.comboboxState === 1)
        return e;
      let n = e.inputElement ? zt.Tracked(ei(e.inputElement)) : e.inputPositionState;
      return {
        ...e,
        activeOptionIndex: null,
        comboboxState: 1,
        isTyping: false,
        activationTrigger: 2,
        inputPositionState: n,
        __demoMode: false
      };
    },
    0(e) {
      var t, n;
      if ((t = e.dataRef.current) != null && t.disabled || e.comboboxState === 0)
        return e;
      if ((n = e.dataRef.current) != null && n.value) {
        let r = e.dataRef.current.calculateIndex(e.dataRef.current.value);
        if (r !== -1)
          return {
            ...e,
            activeOptionIndex: r,
            comboboxState: 0,
            __demoMode: false,
            inputPositionState: zt.Idle
          };
      }
      return {
        ...e,
        comboboxState: 0,
        inputPositionState: zt.Idle,
        __demoMode: false
      };
    },
    3(e, t) {
      return e.isTyping === t.isTyping ? e : {
        ...e,
        isTyping: t.isTyping
      };
    },
    2(e, t) {
      var n, r, s, a;
      if ((n = e.dataRef.current) != null && n.disabled || e.optionsElement && !((r = e.dataRef.current) != null && r.optionsPropsRef.current.static) && e.comboboxState === 1)
        return e;
      if (e.virtual) {
        let { options: d, disabled: f } = e.virtual, h = t.focus === fe.Specific ? t.idx : Ja(t, {
          resolveItems: () => d,
          resolveActiveIndex: () => {
            var m, p;
            return (p = (m = e.activeOptionIndex) != null ? m : d.findIndex((x) => !f(x))) != null ? p : null;
          },
          resolveDisabled: f,
          resolveId() {
            throw new Error("Function not implemented.");
          }
        }), g = (s = t.trigger) != null ? s : 2;
        return e.activeOptionIndex === h && e.activationTrigger === g ? e : {
          ...e,
          activeOptionIndex: h,
          activationTrigger: g,
          isTyping: false,
          __demoMode: false
        };
      }
      let o = Rr(e);
      if (o.activeOptionIndex === null) {
        let d = o.options.findIndex((f) => !f.dataRef.current.disabled);
        d !== -1 && (o.activeOptionIndex = d);
      }
      let i = t.focus === fe.Specific ? t.idx : Ja(t, {
        resolveItems: () => o.options,
        resolveActiveIndex: () => o.activeOptionIndex,
        resolveId: (d) => d.id,
        resolveDisabled: (d) => d.dataRef.current.disabled
      }), c = (a = t.trigger) != null ? a : 2;
      return e.activeOptionIndex === i && e.activationTrigger === c ? e : {
        ...e,
        ...o,
        isTyping: false,
        activeOptionIndex: i,
        activationTrigger: c,
        __demoMode: false
      };
    },
    4: (e, t) => {
      var n, r, s, a;
      if ((n = e.dataRef.current) != null && n.virtual)
        return {
          ...e,
          options: [
            ...e.options,
            t.payload
          ]
        };
      let o = t.payload, i = Rr(e, (d) => (d.push(o), d));
      e.activeOptionIndex === null && (s = (r = e.dataRef.current).isSelected) != null && s.call(r, t.payload.dataRef.current.value) && (i.activeOptionIndex = i.options.indexOf(o));
      let c = {
        ...e,
        ...i,
        activationTrigger: 2
      };
      return (a = e.dataRef.current) != null && a.__demoMode && e.dataRef.current.value === void 0 && (c.activeOptionIndex = 0), c;
    },
    5: (e, t) => {
      var n;
      if ((n = e.dataRef.current) != null && n.virtual)
        return {
          ...e,
          options: e.options.filter((s) => s.id !== t.id)
        };
      let r = Rr(e, (s) => {
        let a = s.findIndex((o) => o.id === t.id);
        return a !== -1 && s.splice(a, 1), s;
      });
      return {
        ...e,
        ...r,
        activationTrigger: 2
      };
    },
    6: (e, t) => e.defaultToFirstOption === t.value ? e : {
      ...e,
      defaultToFirstOption: t.value
    },
    7: (e, t) => e.activationTrigger === t.trigger ? e : {
      ...e,
      activationTrigger: t.trigger
    },
    8: (e, t) => {
      var n, r;
      if (e.virtual === null)
        return {
          ...e,
          virtual: {
            options: t.options,
            disabled: (n = t.disabled) != null ? n : () => false
          }
        };
      if (e.virtual.options === t.options && e.virtual.disabled === t.disabled)
        return e;
      let s = e.activeOptionIndex;
      if (e.activeOptionIndex !== null) {
        let a = t.options.indexOf(e.virtual.options[e.activeOptionIndex]);
        a !== -1 ? s = a : s = null;
      }
      return {
        ...e,
        activeOptionIndex: s,
        virtual: {
          options: t.options,
          disabled: (r = t.disabled) != null ? r : () => false
        }
      };
    },
    9: (e, t) => e.inputElement === t.element ? e : {
      ...e,
      inputElement: t.element
    },
    10: (e, t) => e.buttonElement === t.element ? e : {
      ...e,
      buttonElement: t.element
    },
    11: (e, t) => e.optionsElement === t.element ? e : {
      ...e,
      optionsElement: t.element
    },
    12(e) {
      return e.inputPositionState.kind !== "Tracked" ? e : {
        ...e,
        inputPositionState: zt.Moved
      };
    }
  };
  class Os extends ks {
    constructor(t) {
      super(t), to(this, "actions", {
        onChange: (n) => {
          let { onChange: r, compare: s, mode: a, value: o } = this.state.dataRef.current;
          return re(a, {
            0: () => r == null ? void 0 : r(n),
            1: () => {
              let i = o.slice(), c = i.findIndex((d) => s(d, n));
              return c === -1 ? i.push(n) : i.splice(c, 1), r == null ? void 0 : r(i);
            }
          });
        },
        registerOption: (n, r) => (this.send({
          type: 4,
          payload: {
            id: n,
            dataRef: r
          }
        }), () => {
          this.state.activeOptionIndex === this.state.dataRef.current.calculateIndex(r.current.value) && this.send({
            type: 6,
            value: true
          }), this.send({
            type: 5,
            id: n
          });
        }),
        goToOption: (n, r) => (this.send({
          type: 6,
          value: false
        }), this.send({
          type: 2,
          ...n,
          trigger: r
        })),
        setIsTyping: (n) => {
          this.send({
            type: 3,
            isTyping: n
          });
        },
        closeCombobox: () => {
          var n, r;
          this.send({
            type: 1
          }), this.send({
            type: 6,
            value: false
          }), (r = (n = this.state.dataRef.current).onClose) == null || r.call(n);
        },
        openCombobox: () => {
          this.send({
            type: 0
          }), this.send({
            type: 6,
            value: true
          });
        },
        setActivationTrigger: (n) => {
          this.send({
            type: 7,
            trigger: n
          });
        },
        selectActiveOption: () => {
          let n = this.selectors.activeOptionIndex(this.state);
          if (n !== null) {
            if (this.actions.setIsTyping(false), this.state.virtual)
              this.actions.onChange(this.state.virtual.options[n]);
            else {
              let { dataRef: r } = this.state.options[n];
              this.actions.onChange(r.current.value);
            }
            this.actions.goToOption({
              focus: fe.Specific,
              idx: n
            });
          }
        },
        setInputElement: (n) => {
          this.send({
            type: 9,
            element: n
          });
        },
        setButtonElement: (n) => {
          this.send({
            type: 10,
            element: n
          });
        },
        setOptionsElement: (n) => {
          this.send({
            type: 11,
            element: n
          });
        }
      }), to(this, "selectors", {
        activeDescendantId: (n) => {
          var r, s;
          let a = this.selectors.activeOptionIndex(n);
          if (a !== null)
            return n.virtual ? (s = n.options.find((o) => !o.dataRef.current.disabled && n.dataRef.current.compare(o.dataRef.current.value, n.virtual.options[a]))) == null ? void 0 : s.id : (r = n.options[a]) == null ? void 0 : r.id;
        },
        activeOptionIndex: (n) => {
          if (n.defaultToFirstOption && n.activeOptionIndex === null && (n.virtual ? n.virtual.options.length > 0 : n.options.length > 0)) {
            if (n.virtual) {
              let { options: s, disabled: a } = n.virtual, o = s.findIndex((i) => {
                var c;
                return !((c = a == null ? void 0 : a(i)) != null && c);
              });
              if (o !== -1)
                return o;
            }
            let r = n.options.findIndex((s) => !s.dataRef.current.disabled);
            if (r !== -1)
              return r;
          }
          return n.activeOptionIndex;
        },
        activeOption: (n) => {
          var r, s;
          let a = this.selectors.activeOptionIndex(n);
          return a === null ? null : n.virtual ? n.virtual.options[a ?? 0] : (s = (r = n.options[a]) == null ? void 0 : r.dataRef.current.value) != null ? s : null;
        },
        isActive: (n, r, s) => {
          var a;
          let o = this.selectors.activeOptionIndex(n);
          return o === null ? false : n.virtual ? o === n.dataRef.current.calculateIndex(r) : ((a = n.options[o]) == null ? void 0 : a.id) === s;
        },
        shouldScrollIntoView: (n, r, s) => !(n.virtual || n.__demoMode || n.comboboxState !== 0 || n.activationTrigger === 0 || !this.selectors.isActive(n, r, s)),
        didInputMove(n) {
          return n.inputPositionState.kind === "Moved";
        }
      });
      {
        let n = this.state.id, r = fn.get(null);
        this.disposables.add(r.on(bl.Push, (s) => {
          !r.selectors.isTop(s, n) && this.state.comboboxState === 0 && this.actions.closeCombobox();
        })), this.on(0, () => r.actions.push(n)), this.on(1, () => r.actions.pop(n));
      }
      this.disposables.group((n) => {
        this.on(1, (r) => {
          r.inputElement && (n.dispose(), n.add(mp(r.inputElement, r.inputPositionState, () => {
            this.send({
              type: 12
            });
          })));
        });
      });
    }
    static new({ id: t, virtual: n = null, __demoMode: r = false }) {
      var s;
      return new Os({
        id: t,
        dataRef: {
          current: {}
        },
        comboboxState: r ? 0 : 1,
        isTyping: false,
        options: [],
        virtual: n ? {
          options: n.options,
          disabled: (s = n.disabled) != null ? s : () => false
        } : null,
        activeOptionIndex: null,
        activationTrigger: 2,
        inputElement: null,
        buttonElement: null,
        optionsElement: null,
        __demoMode: r,
        inputPositionState: zt.Idle
      });
    }
    reduce(t, n) {
      return re(n.type, bp, t, n);
    }
  }
  const ni = u.createContext(null);
  function bn(e) {
    let t = u.useContext(ni);
    if (t === null) {
      let n = new Error(`<${e} /> is missing a parent <Combobox /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(n, ri), n;
    }
    return t;
  }
  function ri({ id: e, virtual: t = null, __demoMode: n = false }) {
    let r = u.useMemo(() => Os.new({
      id: e,
      virtual: t,
      __demoMode: n
    }), []);
    return cr(() => r.dispose()), r;
  }
  let rn = u.createContext(null);
  rn.displayName = "ComboboxDataContext";
  function Ft(e) {
    let t = u.useContext(rn);
    if (t === null) {
      let n = new Error(`<${e} /> is missing a parent <Combobox /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(n, Ft), n;
    }
    return t;
  }
  let si = u.createContext(null);
  function vp(e) {
    let t = bn("VirtualProvider"), n = Ft("VirtualProvider"), { options: r } = n.virtual, s = se(t, (m) => m.optionsElement), [a, o] = u.useMemo(() => {
      let m = s;
      if (!m)
        return [
          0,
          0
        ];
      let p = window.getComputedStyle(m);
      return [
        parseFloat(p.paddingBlockStart || p.paddingTop),
        parseFloat(p.paddingBlockEnd || p.paddingBottom)
      ];
    }, [
      s
    ]), i = z0({
      enabled: r.length !== 0,
      scrollPaddingStart: a,
      scrollPaddingEnd: o,
      count: r.length,
      estimateSize() {
        return 40;
      },
      getScrollElement() {
        return t.state.optionsElement;
      },
      overscan: 12
    }), [c, d] = u.useState(0);
    X(() => {
      d((m) => m + 1);
    }, [
      r
    ]);
    let f = i.getVirtualItems(), h = se(t, (m) => m.activationTrigger === De.Pointer), g = se(t, t.selectors.activeOptionIndex);
    return f.length === 0 ? null : j.createElement(si.Provider, {
      value: i
    }, j.createElement("div", {
      style: {
        position: "relative",
        width: "100%",
        height: `${i.getTotalSize()}px`
      },
      ref: (m) => {
        m && (h || g !== null && r.length > g && i.scrollToIndex(g));
      }
    }, f.map((m) => {
      var p;
      return j.createElement(u.Fragment, {
        key: m.key
      }, j.cloneElement((p = e.children) == null ? void 0 : p.call(e, {
        ...e.slot,
        option: r[m.index]
      }), {
        key: `${c}-${m.key}`,
        "data-index": m.index,
        "aria-setsize": r.length,
        "aria-posinset": m.index + 1,
        style: {
          position: "absolute",
          top: 0,
          left: 0,
          transform: `translateY(${m.start}px)`,
          overflowAnchor: "none"
        }
      }));
    })));
  }
  let yp = u.Fragment;
  function wp(e, t) {
    let n = u.useId(), r = Kn(), { value: s, defaultValue: a, onChange: o, form: i, name: c, by: d, invalid: f = false, disabled: h = r || false, onClose: g, __demoMode: m = false, multiple: p = false, immediate: x = false, virtual: b = null, nullable: y, ...v } = e, w = Qo(a), [k = p ? [] : void 0, E] = Xo(s, o, w), N = ri({
      id: n,
      virtual: b,
      __demoMode: m
    }), C = u.useRef({
      static: false,
      hold: false
    }), I = Z0(d), H = R((G) => b ? d === null ? b.options.indexOf(G) : b.options.findIndex((oe) => I(oe, G)) : N.state.options.findIndex((oe) => I(oe.dataRef.current.value, G))), A = u.useCallback((G) => re(M.mode, {
      [we.Multi]: () => k.some((oe) => I(oe, G)),
      [we.Single]: () => I(k, G)
    }), [
      k
    ]), F = se(N, (G) => G.virtual), O = R(() => g == null ? void 0 : g()), M = u.useMemo(() => ({
      __demoMode: m,
      immediate: x,
      optionsPropsRef: C,
      value: k,
      defaultValue: w,
      disabled: h,
      invalid: f,
      mode: p ? we.Multi : we.Single,
      virtual: b ? F : null,
      onChange: E,
      isSelected: A,
      calculateIndex: H,
      compare: I,
      onClose: O
    }), [
      m,
      x,
      C,
      k,
      w,
      h,
      f,
      p,
      b,
      F,
      E,
      A,
      H,
      I,
      O
    ]);
    X(() => {
      var G;
      b && N.send({
        type: ti.UpdateVirtualConfiguration,
        options: b.options,
        disabled: (G = b.disabled) != null ? G : null
      });
    }, [
      b,
      b == null ? void 0 : b.options,
      b == null ? void 0 : b.disabled
    ]), X(() => {
      N.state.dataRef.current = M;
    }, [
      M
    ]);
    let [T, L, U, W] = se(N, (G) => [
      G.comboboxState,
      G.buttonElement,
      G.inputElement,
      G.optionsElement
    ]), _ = fn.get(null), B = se(_, u.useCallback((G) => _.selectors.isTop(G, n), [
      _,
      n
    ]));
    Ns(B, [
      L,
      U,
      W
    ], () => N.actions.closeCombobox());
    let D = se(N, N.selectors.activeOptionIndex), K = se(N, N.selectors.activeOption), $ = ae({
      open: T === q.Open,
      disabled: h,
      invalid: f,
      activeIndex: D,
      activeOption: K,
      value: k
    }), [S, P] = fl(), V = t === null ? {} : {
      ref: t
    }, Z = u.useCallback(() => {
      if (w !== void 0)
        return E == null ? void 0 : E(w);
    }, [
      E,
      w
    ]), z = J();
    return j.createElement(P, {
      value: S,
      props: {
        htmlFor: U == null ? void 0 : U.id
      },
      slot: {
        open: T === q.Open,
        disabled: h
      }
    }, j.createElement(Gl, null, j.createElement(rn.Provider, {
      value: M
    }, j.createElement(ni.Provider, {
      value: N
    }, j.createElement(As, {
      value: re(T, {
        [q.Open]: ie.Open,
        [q.Closed]: ie.Closed
      })
    }, c != null && j.createElement(nl, {
      disabled: h,
      data: k != null ? {
        [c]: k
      } : {},
      form: i,
      onReset: Z
    }), z({
      ourProps: V,
      theirProps: v,
      slot: $,
      defaultTag: yp,
      name: "Combobox"
    }))))));
  }
  let kp = "input";
  function Ep(e, t) {
    var n, r;
    let s = bn("Combobox.Input"), a = Ft("Combobox.Input"), o = u.useId(), i = vs(), { id: c = i || `headlessui-combobox-input-${o}`, onChange: d, displayValue: f, disabled: h = a.disabled || false, autoFocus: g = false, type: m = "text", ...p } = e, x = u.useRef(null), b = ne(x, t, Vl(), s.actions.setInputElement), [y, v] = se(s, ($) => [
      $.comboboxState,
      $.isTyping
    ]), w = Ke(), k = R(() => {
      s.actions.onChange(null), s.state.optionsElement && (s.state.optionsElement.scrollTop = 0), s.actions.goToOption({
        focus: fe.Nothing
      });
    }), E = u.useMemo(() => {
      var $;
      return typeof f == "function" && a.value !== void 0 ? ($ = f(a.value)) != null ? $ : "" : typeof a.value == "string" ? a.value : "";
    }, [
      a.value,
      f
    ]);
    en(([$, S], [P, V]) => {
      if (s.state.isTyping)
        return;
      let Z = x.current;
      Z && ((V === q.Open && S === q.Closed || $ !== P) && (Z.value = $), requestAnimationFrame(() => {
        if (s.state.isTyping || !Z || bs(Z))
          return;
        let { selectionStart: z, selectionEnd: G } = Z;
        Math.abs((G ?? 0) - (z ?? 0)) === 0 && z === 0 && Z.setSelectionRange(Z.value.length, Z.value.length);
      }));
    }, [
      E,
      y,
      v
    ]), en(([$], [S]) => {
      if ($ === q.Open && S === q.Closed) {
        if (s.state.isTyping)
          return;
        let P = x.current;
        if (!P)
          return;
        let V = P.value, { selectionStart: Z, selectionEnd: z, selectionDirection: G } = P;
        P.value = "", P.value = V, G !== null ? P.setSelectionRange(Z, z, G) : P.setSelectionRange(Z, z);
      }
    }, [
      y
    ]);
    let N = u.useRef(false), C = R(() => {
      N.current = true;
    }), I = R(() => {
      w.nextFrame(() => {
        N.current = false;
      });
    }), H = R(($) => {
      switch (s.actions.setIsTyping(true), $.key) {
        case Y.Enter:
          if (s.state.comboboxState !== q.Open || N.current)
            return;
          if ($.preventDefault(), $.stopPropagation(), s.selectors.activeOptionIndex(s.state) === null) {
            s.actions.closeCombobox();
            return;
          }
          s.actions.selectActiveOption(), a.mode === we.Single && s.actions.closeCombobox();
          break;
        case Y.ArrowDown:
          return $.preventDefault(), $.stopPropagation(), re(s.state.comboboxState, {
            [q.Open]: () => s.actions.goToOption({
              focus: fe.Next
            }),
            [q.Closed]: () => s.actions.openCombobox()
          });
        case Y.ArrowUp:
          return $.preventDefault(), $.stopPropagation(), re(s.state.comboboxState, {
            [q.Open]: () => s.actions.goToOption({
              focus: fe.Previous
            }),
            [q.Closed]: () => {
              xe.flushSync(() => s.actions.openCombobox()), a.value || s.actions.goToOption({
                focus: fe.Last
              });
            }
          });
        case Y.Home:
          if (s.state.comboboxState === q.Closed || $.shiftKey)
            break;
          return $.preventDefault(), $.stopPropagation(), s.actions.goToOption({
            focus: fe.First
          });
        case Y.PageUp:
          return $.preventDefault(), $.stopPropagation(), s.actions.goToOption({
            focus: fe.First
          });
        case Y.End:
          if (s.state.comboboxState === q.Closed || $.shiftKey)
            break;
          return $.preventDefault(), $.stopPropagation(), s.actions.goToOption({
            focus: fe.Last
          });
        case Y.PageDown:
          return $.preventDefault(), $.stopPropagation(), s.actions.goToOption({
            focus: fe.Last
          });
        case Y.Escape:
          return s.state.comboboxState !== q.Open ? void 0 : ($.preventDefault(), s.state.optionsElement && !a.optionsPropsRef.current.static && $.stopPropagation(), a.mode === we.Single && a.value === null && k(), s.actions.closeCombobox());
        case Y.Tab:
          if (s.actions.setIsTyping(false), s.state.comboboxState !== q.Open)
            return;
          a.mode === we.Single && s.state.activationTrigger !== De.Focus && s.actions.selectActiveOption(), s.actions.closeCombobox();
          break;
      }
    }), A = R(($) => {
      d == null ? void 0 : d($), a.mode === we.Single && $.target.value === "" && k(), s.actions.openCombobox();
    }), F = R(($) => {
      var S, P, V;
      let Z = (S = $.relatedTarget) != null ? S : Oe.find((z) => z !== $.currentTarget);
      if (!((P = s.state.optionsElement) != null && P.contains(Z)) && !((V = s.state.buttonElement) != null && V.contains(Z)) && s.state.comboboxState === q.Open)
        return $.preventDefault(), a.mode === we.Single && a.value === null && k(), s.actions.closeCombobox();
    }), O = R(($) => {
      var S, P, V;
      let Z = (S = $.relatedTarget) != null ? S : Oe.find((z) => z !== $.currentTarget);
      (P = s.state.buttonElement) != null && P.contains(Z) || (V = s.state.optionsElement) != null && V.contains(Z) || a.disabled || a.immediate && s.state.comboboxState !== q.Open && w.microTask(() => {
        xe.flushSync(() => s.actions.openCombobox()), s.actions.setActivationTrigger(De.Focus);
      });
    }), M = dn(), T = il(), { isFocused: L, focusProps: U } = Ot({
      autoFocus: g
    }), { isHovered: W, hoverProps: _ } = cn({
      isDisabled: h
    }), B = se(s, ($) => $.optionsElement), D = ae({
      open: y === q.Open,
      disabled: h,
      invalid: a.invalid,
      hover: W,
      focus: L,
      autofocus: g
    }), K = Ge({
      ref: b,
      id: c,
      role: "combobox",
      type: m,
      "aria-controls": B == null ? void 0 : B.id,
      "aria-expanded": y === q.Open,
      "aria-activedescendant": se(s, s.selectors.activeDescendantId),
      "aria-labelledby": M,
      "aria-describedby": T,
      "aria-autocomplete": "list",
      defaultValue: (r = (n = e.defaultValue) != null ? n : a.defaultValue !== void 0 ? f == null ? void 0 : f(a.defaultValue) : null) != null ? r : a.defaultValue,
      disabled: h || void 0,
      autoFocus: g,
      onCompositionStart: C,
      onCompositionEnd: I,
      onKeyDown: H,
      onChange: A,
      onFocus: O,
      onBlur: F
    }, U, _);
    return J()({
      ourProps: K,
      theirProps: p,
      slot: D,
      defaultTag: kp,
      name: "Combobox.Input"
    });
  }
  let jp = "button";
  function Np(e, t) {
    let n = bn("Combobox.Button"), r = Ft("Combobox.Button"), [s, a] = u.useState(null), o = ne(t, a, n.actions.setButtonElement), i = u.useId(), { id: c = `headlessui-combobox-button-${i}`, disabled: d = r.disabled || false, autoFocus: f = false, ...h } = e, [g, m, p] = se(n, (O) => [
      O.comboboxState,
      O.inputElement,
      O.optionsElement
    ]), x = Cl(m), b = g === q.Open;
    kf(b, {
      trigger: s,
      action: u.useCallback((O) => {
        if (s != null && s.contains(O.target) || m != null && m.contains(O.target))
          return _t.Ignore;
        let M = O.target.closest('[role="option"]:not([data-disabled])');
        return ve(M) ? _t.Select(M) : p != null && p.contains(O.target) ? _t.Ignore : _t.Close;
      }, [
        s,
        m,
        p
      ]),
      close: n.actions.closeCombobox,
      select: n.actions.selectActiveOption
    });
    let y = R((O) => {
      switch (O.key) {
        case Y.Space:
        case Y.Enter:
          O.preventDefault(), O.stopPropagation(), n.state.comboboxState === q.Closed && xe.flushSync(() => n.actions.openCombobox()), x();
          return;
        case Y.ArrowDown:
          O.preventDefault(), O.stopPropagation(), n.state.comboboxState === q.Closed && (xe.flushSync(() => n.actions.openCombobox()), n.state.dataRef.current.value || n.actions.goToOption({
            focus: fe.First
          })), x();
          return;
        case Y.ArrowUp:
          O.preventDefault(), O.stopPropagation(), n.state.comboboxState === q.Closed && (xe.flushSync(() => n.actions.openCombobox()), n.state.dataRef.current.value || n.actions.goToOption({
            focus: fe.Last
          })), x();
          return;
        case Y.Escape:
          if (n.state.comboboxState !== q.Open)
            return;
          O.preventDefault(), n.state.optionsElement && !r.optionsPropsRef.current.static && O.stopPropagation(), xe.flushSync(() => n.actions.closeCombobox()), x();
          return;
        default:
          return;
      }
    }), v = q0(() => {
      n.state.comboboxState === q.Open ? n.actions.closeCombobox() : n.actions.openCombobox(), x();
    }), w = dn([
      c
    ]), { isFocusVisible: k, focusProps: E } = Ot({
      autoFocus: f
    }), { isHovered: N, hoverProps: C } = cn({
      isDisabled: d
    }), { pressed: I, pressProps: H } = qn({
      disabled: d
    }), A = ae({
      open: g === q.Open,
      active: I || g === q.Open,
      disabled: d,
      invalid: r.invalid,
      value: r.value,
      hover: N,
      focus: k
    }), F = Ge({
      ref: o,
      id: c,
      type: er(e, s),
      tabIndex: -1,
      "aria-haspopup": "listbox",
      "aria-controls": p == null ? void 0 : p.id,
      "aria-expanded": g === q.Open,
      "aria-labelledby": w,
      disabled: d || void 0,
      autoFocus: f,
      onKeyDown: y
    }, v, E, C, H);
    return J()({
      ourProps: F,
      theirProps: h,
      slot: A,
      defaultTag: jp,
      name: "Combobox.Button"
    });
  }
  let Cp = "div", Sp = Ce.RenderStrategy | Ce.Static;
  function Tp(e, t) {
    var n, r, s;
    let a = u.useId(), { id: o = `headlessui-combobox-options-${a}`, hold: i = false, anchor: c, portal: d = false, modal: f = true, transition: h = false, ...g } = e, m = bn("Combobox.Options"), p = Ft("Combobox.Options"), x = Ul(c);
    x && (d = true);
    let [b, y] = zl(x), [v, w] = u.useState(null), k = Wl(), E = ne(t, x ? b : null, m.actions.setOptionsElement, w), [N, C, I, H, A] = se(m, (le) => [
      le.comboboxState,
      le.inputElement,
      le.buttonElement,
      le.optionsElement,
      le.activationTrigger
    ]), F = pt(C || I), O = pt(H), M = vt(), [T, L] = nr(h, v, M !== null ? (M & ie.Open) === ie.Open : N === q.Open);
    Es(T, C, m.actions.closeCombobox);
    let U = p.__demoMode ? false : f && N === q.Open;
    Cs(U, O);
    let W = p.__demoMode ? false : f && N === q.Open;
    kl(W, {
      allowed: u.useCallback(() => [
        C,
        I,
        H
      ], [
        C,
        I,
        H
      ])
    });
    let _ = se(m, m.selectors.didInputMove) ? false : T;
    X(() => {
      var le;
      p.optionsPropsRef.current.static = (le = e.static) != null ? le : false;
    }, [
      p.optionsPropsRef,
      e.static
    ]), X(() => {
      p.optionsPropsRef.current.hold = i;
    }, [
      p.optionsPropsRef,
      i
    ]), Ff(N === q.Open, {
      container: H,
      accept(le) {
        return le.getAttribute("role") === "option" ? NodeFilter.FILTER_REJECT : le.hasAttribute("role") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT;
      },
      walk(le) {
        le.setAttribute("role", "none");
      }
    });
    let B = dn([
      I == null ? void 0 : I.id
    ]), D = ae({
      open: N === q.Open,
      option: void 0
    }), K = R(() => {
      m.actions.setActivationTrigger(De.Pointer);
    }), $ = R((le) => {
      le.preventDefault(), m.actions.setActivationTrigger(De.Pointer);
    }), S = Ge(x ? k() : {}, {
      "aria-labelledby": B,
      role: "listbox",
      "aria-multiselectable": p.mode === we.Multi ? true : void 0,
      id: o,
      ref: E,
      style: {
        ...g.style,
        ...y,
        "--input-width": Kr(T, C, true).width,
        "--button-width": Kr(T, I, true).width
      },
      onWheel: A === De.Pointer ? void 0 : K,
      onMouseDown: $,
      ...tr(L)
    }), P = T && N === q.Closed && !e.static, V = ts(P, (n = p.virtual) == null ? void 0 : n.options), Z = ts(P, p.value), z = u.useCallback((le) => p.compare(Z, le), [
      p.compare,
      Z
    ]), G = u.useMemo(() => {
      if (!p.virtual)
        return p;
      if (V === void 0)
        throw new Error("Missing `options` in virtual mode");
      return V !== p.virtual.options ? {
        ...p,
        virtual: {
          ...p.virtual,
          options: V
        }
      } : p;
    }, [
      p,
      V,
      (r = p.virtual) == null ? void 0 : r.options
    ]);
    p.virtual && Object.assign(g, {
      children: j.createElement(rn.Provider, {
        value: G
      }, j.createElement(vp, {
        slot: D
      }, g.children))
    });
    let oe = J(), yt = u.useMemo(() => p.mode === we.Multi ? p : {
      ...p,
      isSelected: z
    }, [
      p,
      z
    ]);
    return j.createElement(Ps, {
      enabled: d ? e.static || T : false,
      ownerDocument: F
    }, j.createElement(rn.Provider, {
      value: yt
    }, oe({
      ourProps: S,
      theirProps: {
        ...g,
        children: j.createElement(ap, {
          freeze: P
        }, typeof g.children == "function" ? (s = g.children) == null ? void 0 : s.call(g, D) : g.children)
      },
      slot: D,
      defaultTag: Cp,
      features: Sp,
      visible: _,
      name: "Combobox.Options"
    })));
  }
  let $p = "div";
  function Rp(e, t) {
    var n, r, s;
    let a = Ft("Combobox.Option"), o = bn("Combobox.Option"), i = u.useId(), { id: c = `headlessui-combobox-option-${i}`, value: d, disabled: f = (s = (r = (n = a.virtual) == null ? void 0 : n.disabled) == null ? void 0 : r.call(n, d)) != null ? s : false, order: h = null, ...g } = e, [m] = se(o, (L) => [
      L.inputElement
    ]), p = Cl(m), x = se(o, u.useCallback((L) => o.selectors.isActive(L, d, c), [
      d,
      c
    ])), b = a.isSelected(d), y = u.useRef(null), v = ye({
      disabled: f,
      value: d,
      domRef: y,
      order: h
    }), w = u.useContext(si), k = ne(t, y, w ? w.measureElement : null), E = R(() => {
      o.actions.setIsTyping(false), o.actions.onChange(d);
    });
    X(() => o.actions.registerOption(c, v), [
      v,
      c
    ]);
    let N = se(o, u.useCallback((L) => o.selectors.shouldScrollIntoView(L, d, c), [
      d,
      c
    ]));
    X(() => {
      if (N)
        return Se().requestAnimationFrame(() => {
          var L, U;
          (U = (L = y.current) == null ? void 0 : L.scrollIntoView) == null || U.call(L, {
            block: "nearest"
          });
        });
    }, [
      N,
      y
    ]);
    let C = R((L) => {
      L.preventDefault(), L.button === ws.Left && (f || (E(), Xr() || requestAnimationFrame(() => p()), a.mode === we.Single && o.actions.closeCombobox()));
    }), I = R(() => {
      if (f)
        return o.actions.goToOption({
          focus: fe.Nothing
        });
      let L = a.calculateIndex(d);
      o.actions.goToOption({
        focus: fe.Specific,
        idx: L
      });
    }), H = $f(), A = R((L) => H.update(L)), F = R((L) => {
      if (!H.wasMoved(L) || f || x && o.state.activationTrigger === De.Pointer)
        return;
      let U = a.calculateIndex(d);
      o.actions.goToOption({
        focus: fe.Specific,
        idx: U
      }, De.Pointer);
    }), O = R((L) => {
      H.wasMoved(L) && (f || x && (a.optionsPropsRef.current.hold || o.state.activationTrigger === De.Pointer && o.actions.goToOption({
        focus: fe.Nothing
      })));
    }), M = ae({
      active: x,
      focus: x,
      selected: b,
      disabled: f
    }), T = {
      id: c,
      ref: k,
      role: "option",
      tabIndex: f === true ? void 0 : -1,
      "aria-disabled": f === true ? true : void 0,
      "aria-selected": b,
      disabled: void 0,
      onMouseDown: C,
      onFocus: I,
      onPointerEnter: A,
      onMouseEnter: A,
      onPointerMove: F,
      onMouseMove: F,
      onPointerLeave: O,
      onMouseLeave: O
    };
    return J()({
      ourProps: T,
      theirProps: g,
      slot: M,
      defaultTag: $p,
      name: "Combobox.Option"
    });
  }
  let Ap = Q(wp), ai = Q(Np), oi = Q(Ep), Pp = hl, li = Q(Tp), ii = Q(Rp), Op = Object.assign(Ap, {
    Input: oi,
    Button: ai,
    Label: Pp,
    Options: li,
    Option: ii
  });
  function Lp(e, t = typeof document < "u" ? document.defaultView : null, n) {
    let r = pn(e, "escape");
    Jn(t, "keydown", (s) => {
      r && (s.defaultPrevented || s.key === Y.Escape && n(s));
    });
  }
  function Ip() {
    var e;
    let [t] = u.useState(() => typeof window < "u" && typeof window.matchMedia == "function" ? window.matchMedia("(pointer: coarse)") : null), [n, r] = u.useState((e = t == null ? void 0 : t.matches) != null ? e : false);
    return X(() => {
      if (!t)
        return;
      function s(a) {
        r(a.matches);
      }
      return t.addEventListener("change", s), () => t.removeEventListener("change", s);
    }, [
      t
    ]), n;
  }
  function ci({ defaultContainers: e = [], portals: t, mainTreeNode: n } = {}) {
    let r = R(() => {
      var s, a;
      let o = ot(n), i = [];
      for (let c of e)
        c !== null && (We(c) ? i.push(c) : "current" in c && We(c.current) && i.push(c.current));
      if (t != null && t.current)
        for (let c of t.current)
          i.push(c);
      for (let c of (s = o == null ? void 0 : o.querySelectorAll("html > *, body > *")) != null ? s : [])
        c !== document.body && c !== document.head && We(c) && c.id !== "headlessui-portal-root" && (n && (c.contains(n) || c.contains((a = n == null ? void 0 : n.getRootNode()) == null ? void 0 : a.host)) || i.some((d) => c.contains(d)) || i.push(c));
      return i;
    });
    return {
      resolveContainers: r,
      contains: R((s) => r().some((a) => a.contains(s)))
    };
  }
  let ui = u.createContext(null);
  function Wn({ children: e, node: t }) {
    let [n, r] = u.useState(null), s = Ls(t ?? n);
    return j.createElement(ui.Provider, {
      value: s
    }, e, s === null && j.createElement(Be, {
      features: _e.Hidden,
      ref: (a) => {
        var o, i;
        if (a) {
          for (let c of (i = (o = ot(a)) == null ? void 0 : o.querySelectorAll("html > *, body > *")) != null ? i : [])
            if (c !== document.body && c !== document.head && We(c) && c != null && c.contains(a)) {
              r(c);
              break;
            }
        }
      }
    }));
  }
  function Ls(e = null) {
    var t;
    return (t = u.useContext(ui)) != null ? t : e;
  }
  function Fp() {
    let e = typeof document > "u";
    return "useSyncExternalStore" in Rn ? ((t) => t.useSyncExternalStore)(Rn)(() => () => {
    }, () => false, () => !e) : false;
  }
  function ur() {
    let e = Fp(), [t, n] = u.useState(Fe.isHandoffComplete);
    return t && Fe.isHandoffComplete === false && n(false), u.useEffect(() => {
      t !== true && n(true);
    }, [
      t
    ]), u.useEffect(() => Fe.handoff(), []), e ? false : t;
  }
  function dr() {
    let e = u.useRef(false);
    return X(() => (e.current = true, () => {
      e.current = false;
    }), []), e;
  }
  var ke = ((e) => (e[e.Forwards = 0] = "Forwards", e[e.Backwards = 1] = "Backwards", e))(ke || {});
  function Is() {
    let e = u.useRef(0);
    return Nl(true, "keydown", (t) => {
      t.key === "Tab" && (e.current = t.shiftKey ? 1 : 0);
    }, true), e;
  }
  function di(e) {
    if (!e)
      return /* @__PURE__ */ new Set();
    if (typeof e == "function")
      return new Set(e());
    let t = /* @__PURE__ */ new Set();
    for (let n of e.current)
      We(n.current) && t.add(n.current);
    return t;
  }
  let Mp = "div";
  var lt = ((e) => (e[e.None = 0] = "None", e[e.InitialFocus = 1] = "InitialFocus", e[e.TabLock = 2] = "TabLock", e[e.FocusLock = 4] = "FocusLock", e[e.RestoreFocus = 8] = "RestoreFocus", e[e.AutoFocus = 16] = "AutoFocus", e))(lt || {});
  function Dp(e, t) {
    let n = u.useRef(null), r = ne(n, t), { initialFocus: s, initialFocusFallback: a, containers: o, features: i = 15, ...c } = e;
    ur() || (i = 0);
    let d = pt(n.current);
    Up(i, {
      ownerDocument: d
    });
    let f = Vp(i, {
      ownerDocument: d,
      container: n,
      initialFocus: s,
      initialFocusFallback: a
    });
    Wp(i, {
      ownerDocument: d,
      container: n,
      containers: o,
      previousActiveElement: f
    });
    let h = Is(), g = R((v) => {
      if (!ve(n.current))
        return;
      let w = n.current;
      ((k) => k())(() => {
        re(h.current, {
          [ke.Forwards]: () => {
            he(w, te.First, {
              skipElements: [
                v.relatedTarget,
                a
              ]
            });
          },
          [ke.Backwards]: () => {
            he(w, te.Last, {
              skipElements: [
                v.relatedTarget,
                a
              ]
            });
          }
        });
      });
    }), m = pn(!!(i & 2), "focus-trap#tab-lock"), p = Ke(), x = u.useRef(false), b = {
      ref: r,
      onKeyDown(v) {
        v.key == "Tab" && (x.current = true, p.requestAnimationFrame(() => {
          x.current = false;
        }));
      },
      onBlur(v) {
        if (!(i & 4))
          return;
        let w = di(o);
        ve(n.current) && w.add(n.current);
        let k = v.relatedTarget;
        Le(k) && k.dataset.headlessuiFocusGuard !== "true" && (fi(w, k) || (x.current ? he(n.current, re(h.current, {
          [ke.Forwards]: () => te.Next,
          [ke.Backwards]: () => te.Previous
        }) | te.WrapAround, {
          relativeTo: v.target
        }) : Le(v.target) && ze(v.target)));
      }
    }, y = J();
    return j.createElement(j.Fragment, null, m && j.createElement(Be, {
      as: "button",
      type: "button",
      "data-headlessui-focus-guard": true,
      onFocus: g,
      features: _e.Focusable
    }), y({
      ourProps: b,
      theirProps: c,
      defaultTag: Mp,
      name: "FocusTrap"
    }), m && j.createElement(Be, {
      as: "button",
      type: "button",
      "data-headlessui-focus-guard": true,
      onFocus: g,
      features: _e.Focusable
    }));
  }
  let _p = Q(Dp), Bp = Object.assign(_p, {
    features: lt
  });
  function Hp(e = true) {
    let t = u.useRef(Oe.slice());
    return en(([n], [r]) => {
      r === true && n === false && un(() => {
        t.current.splice(0);
      }), r === false && n === true && (t.current = Oe.slice());
    }, [
      e,
      Oe,
      t
    ]), R(() => {
      var n;
      return (n = t.current.find((r) => r != null && r.isConnected)) != null ? n : null;
    });
  }
  function Up(e, { ownerDocument: t }) {
    let n = !!(e & 8), r = Hp(n);
    en(() => {
      n || bs(t == null ? void 0 : t.body) && ze(r());
    }, [
      n
    ]), cr(() => {
      n && ze(r());
    });
  }
  function Vp(e, { ownerDocument: t, container: n, initialFocus: r, initialFocusFallback: s }) {
    let a = u.useRef(null), o = pn(!!(e & 1), "focus-trap#initial-focus"), i = dr();
    return en(() => {
      if (e === 0)
        return;
      if (!o) {
        s != null && s.current && ze(s.current);
        return;
      }
      let c = n.current;
      c && un(() => {
        if (!i.current)
          return;
        let d = t == null ? void 0 : t.activeElement;
        if (r != null && r.current) {
          if ((r == null ? void 0 : r.current) === d) {
            a.current = d;
            return;
          }
        } else if (c.contains(d)) {
          a.current = d;
          return;
        }
        if (r != null && r.current)
          ze(r.current);
        else {
          if (e & 16) {
            if (he(c, te.First | te.AutoFocus) !== Ie.Error)
              return;
          } else if (he(c, te.First) !== Ie.Error)
            return;
          if (s != null && s.current && (ze(s.current), (t == null ? void 0 : t.activeElement) === s.current))
            return;
          console.warn("There are no focusable elements inside the <FocusTrap />");
        }
        a.current = t == null ? void 0 : t.activeElement;
      });
    }, [
      s,
      o,
      e
    ]), a;
  }
  function Wp(e, { ownerDocument: t, container: n, containers: r, previousActiveElement: s }) {
    let a = dr(), o = !!(e & 4);
    Jn(t == null ? void 0 : t.defaultView, "focus", (i) => {
      if (!o || !a.current)
        return;
      let c = di(r);
      ve(n.current) && c.add(n.current);
      let d = s.current;
      if (!d)
        return;
      let f = i.target;
      ve(f) ? fi(c, f) ? (s.current = f, ze(f)) : (i.preventDefault(), i.stopPropagation(), ze(d)) : ze(s.current);
    }, true);
  }
  function fi(e, t) {
    for (let n of e)
      if (n.contains(t))
        return true;
    return false;
  }
  function hi(e) {
    var t;
    return !!(e.enter || e.enterFrom || e.enterTo || e.leave || e.leaveFrom || e.leaveTo) || !Zt((t = e.as) != null ? t : mi) || j.Children.count(e.children) === 1;
  }
  let fr = u.createContext(null);
  fr.displayName = "TransitionContext";
  var zp = ((e) => (e.Visible = "visible", e.Hidden = "hidden", e))(zp || {});
  function Gp() {
    let e = u.useContext(fr);
    if (e === null)
      throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");
    return e;
  }
  function Zp() {
    let e = u.useContext(hr);
    if (e === null)
      throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");
    return e;
  }
  let hr = u.createContext(null);
  hr.displayName = "NestingContext";
  function pr(e) {
    return "children" in e ? pr(e.children) : e.current.filter(({ el: t }) => t.current !== null).filter(({ state: t }) => t === "visible").length > 0;
  }
  function pi(e, t) {
    let n = ye(e), r = u.useRef([]), s = dr(), a = Ke(), o = R((m, p = Qe.Hidden) => {
      let x = r.current.findIndex(({ el: b }) => b === m);
      x !== -1 && (re(p, {
        [Qe.Unmount]() {
          r.current.splice(x, 1);
        },
        [Qe.Hidden]() {
          r.current[x].state = "hidden";
        }
      }), a.microTask(() => {
        var b;
        !pr(r) && s.current && ((b = n.current) == null || b.call(n));
      }));
    }), i = R((m) => {
      let p = r.current.find(({ el: x }) => x === m);
      return p ? p.state !== "visible" && (p.state = "visible") : r.current.push({
        el: m,
        state: "visible"
      }), () => o(m, Qe.Unmount);
    }), c = u.useRef([]), d = u.useRef(Promise.resolve()), f = u.useRef({
      enter: [],
      leave: []
    }), h = R((m, p, x) => {
      c.current.splice(0), t && (t.chains.current[p] = t.chains.current[p].filter(([b]) => b !== m)), t == null ? void 0 : t.chains.current[p].push([
        m,
        new Promise((b) => {
          c.current.push(b);
        })
      ]), t == null ? void 0 : t.chains.current[p].push([
        m,
        new Promise((b) => {
          Promise.all(f.current[p].map(([y, v]) => v)).then(() => b());
        })
      ]), p === "enter" ? d.current = d.current.then(() => t == null ? void 0 : t.wait.current).then(() => x(p)) : x(p);
    }), g = R((m, p, x) => {
      Promise.all(f.current[p].splice(0).map(([b, y]) => y)).then(() => {
        var b;
        (b = c.current.shift()) == null || b();
      }).then(() => x(p));
    });
    return u.useMemo(() => ({
      children: r,
      register: i,
      unregister: o,
      onStart: h,
      onStop: g,
      wait: d,
      chains: f
    }), [
      i,
      o,
      r,
      h,
      g,
      f,
      d
    ]);
  }
  let mi = u.Fragment, gi = Ce.RenderStrategy;
  function qp(e, t) {
    var n, r;
    let { transition: s = true, beforeEnter: a, afterEnter: o, beforeLeave: i, afterLeave: c, enter: d, enterFrom: f, enterTo: h, entered: g, leave: m, leaveFrom: p, leaveTo: x, ...b } = e, [y, v] = u.useState(null), w = u.useRef(null), k = hi(e), E = ne(...k ? [
      w,
      t,
      v
    ] : t === null ? [] : [
      t
    ]), N = (n = b.unmount) == null || n ? Qe.Unmount : Qe.Hidden, { show: C, appear: I, initial: H } = Gp(), [A, F] = u.useState(C ? "visible" : "hidden"), O = Zp(), { register: M, unregister: T } = O;
    X(() => M(w), [
      M,
      w
    ]), X(() => {
      if (N === Qe.Hidden && w.current) {
        if (C && A !== "visible") {
          F("visible");
          return;
        }
        return re(A, {
          hidden: () => T(w),
          visible: () => M(w)
        });
      }
    }, [
      A,
      w,
      M,
      T,
      C,
      N
    ]);
    let L = ur();
    X(() => {
      if (k && L && A === "visible" && w.current === null)
        throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?");
    }, [
      w,
      A,
      L,
      k
    ]);
    let U = H && !I, W = I && C && H, _ = u.useRef(false), B = pi(() => {
      _.current || (F("hidden"), T(w));
    }, O), D = R((z) => {
      _.current = true;
      let G = z ? "enter" : "leave";
      B.onStart(w, G, (oe) => {
        oe === "enter" ? a == null ? void 0 : a() : oe === "leave" && (i == null ? void 0 : i());
      });
    }), K = R((z) => {
      let G = z ? "enter" : "leave";
      _.current = false, B.onStop(w, G, (oe) => {
        oe === "enter" ? o == null ? void 0 : o() : oe === "leave" && (c == null ? void 0 : c());
      }), G === "leave" && !pr(B) && (F("hidden"), T(w));
    });
    u.useEffect(() => {
      k && s || (D(C), K(C));
    }, [
      C,
      k,
      s
    ]);
    let $ = (() => !(!s || !k || !L || U))(), [, S] = nr($, y, C, {
      start: D,
      end: K
    }), P = Ye({
      ref: E,
      className: ((r = Zr(b.className, W && d, W && f, S.enter && d, S.enter && S.closed && f, S.enter && !S.closed && h, S.leave && m, S.leave && !S.closed && p, S.leave && S.closed && x, !S.transition && C && g)) == null ? void 0 : r.trim()) || void 0,
      ...tr(S)
    }), V = 0;
    A === "visible" && (V |= ie.Open), A === "hidden" && (V |= ie.Closed), C && A === "hidden" && (V |= ie.Opening), !C && A === "visible" && (V |= ie.Closing);
    let Z = J();
    return j.createElement(hr.Provider, {
      value: B
    }, j.createElement(As, {
      value: V
    }, Z({
      ourProps: P,
      theirProps: b,
      defaultTag: mi,
      features: gi,
      visible: A === "visible",
      name: "Transition.Child"
    })));
  }
  function Kp(e, t) {
    let { show: n, appear: r = false, unmount: s = true, ...a } = e, o = u.useRef(null), i = hi(e), c = ne(...i ? [
      o,
      t
    ] : t === null ? [] : [
      t
    ]);
    ur();
    let d = vt();
    if (n === void 0 && d !== null && (n = (d & ie.Open) === ie.Open), n === void 0)
      throw new Error("A <Transition /> is used but it is missing a `show={true | false}` prop.");
    let [f, h] = u.useState(n ? "visible" : "hidden"), g = pi(() => {
      n || h("hidden");
    }), [m, p] = u.useState(true), x = u.useRef([
      n
    ]);
    X(() => {
      m !== false && x.current[x.current.length - 1] !== n && (x.current.push(n), p(false));
    }, [
      x,
      n
    ]);
    let b = u.useMemo(() => ({
      show: n,
      appear: r,
      initial: m
    }), [
      n,
      r,
      m
    ]);
    X(() => {
      n ? h("visible") : !pr(g) && o.current !== null && h("hidden");
    }, [
      n,
      g
    ]);
    let y = {
      unmount: s
    }, v = R(() => {
      var E;
      m && p(false), (E = e.beforeEnter) == null || E.call(e);
    }), w = R(() => {
      var E;
      m && p(false), (E = e.beforeLeave) == null || E.call(e);
    }), k = J();
    return j.createElement(hr.Provider, {
      value: g
    }, j.createElement(fr.Provider, {
      value: b
    }, k({
      ourProps: {
        ...y,
        as: u.Fragment,
        children: j.createElement(xi, {
          ref: c,
          ...y,
          ...a,
          beforeEnter: v,
          beforeLeave: w
        })
      },
      theirProps: {},
      defaultTag: u.Fragment,
      features: gi,
      visible: f === "visible",
      name: "Transition"
    })));
  }
  function Yp(e, t) {
    let n = u.useContext(fr) !== null, r = vt() !== null;
    return j.createElement(j.Fragment, null, !n && r ? j.createElement(rs, {
      ref: t,
      ...e
    }) : j.createElement(xi, {
      ref: t,
      ...e
    }));
  }
  let rs = Q(Kp), xi = Q(qp), Fs = Q(Yp), Xp = Object.assign(rs, {
    Child: Fs,
    Root: rs
  });
  var Qp = ((e) => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(Qp || {}), Jp = ((e) => (e[e.SetTitleId = 0] = "SetTitleId", e))(Jp || {});
  let em = {
    0(e, t) {
      return e.titleId === t.id ? e : {
        ...e,
        titleId: t.id
      };
    }
  }, Ms = u.createContext(null);
  Ms.displayName = "DialogContext";
  function mr(e) {
    let t = u.useContext(Ms);
    if (t === null) {
      let n = new Error(`<${e} /> is missing a parent <Dialog /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(n, mr), n;
    }
    return t;
  }
  function tm(e, t) {
    return re(t.type, em, e, t);
  }
  let no = Q(function(e, t) {
    let n = u.useId(), { id: r = `headlessui-dialog-${n}`, open: s, onClose: a, initialFocus: o, role: i = "dialog", autoFocus: c = true, __demoMode: d = false, unmount: f = false, ...h } = e, g = u.useRef(false);
    i = function() {
      return i === "dialog" || i === "alertdialog" ? i : (g.current || (g.current = true, console.warn(`Invalid role [${i}] passed to <Dialog />. Only \`dialog\` and and \`alertdialog\` are supported. Using \`dialog\` instead.`)), "dialog");
    }();
    let m = vt();
    s === void 0 && m !== null && (s = (m & ie.Open) === ie.Open);
    let p = u.useRef(null), x = ne(p, t), b = pt(p.current), y = s ? 0 : 1, [v, w] = u.useReducer(tm, {
      titleId: null,
      descriptionId: null,
      panelRef: u.createRef()
    }), k = R(() => a(false)), E = R((S) => w({
      type: 0,
      id: S
    })), N = ur() ? y === 0 : false, [C, I] = Ql(), H = {
      get current() {
        var S;
        return (S = v.panelRef.current) != null ? S : p.current;
      }
    }, A = Ls(), { resolveContainers: F } = ci({
      mainTreeNode: A,
      portals: C,
      defaultContainers: [
        H
      ]
    }), O = m !== null ? (m & ie.Closing) === ie.Closing : false;
    kl(d || O ? false : N, {
      allowed: R(() => {
        var S, P;
        return [
          (P = (S = p.current) == null ? void 0 : S.closest("[data-headlessui-portal]")) != null ? P : null
        ];
      }),
      disallowed: R(() => {
        var S;
        return [
          (S = A == null ? void 0 : A.closest("body > *:not(#headlessui-portal-root)")) != null ? S : null
        ];
      })
    });
    let M = fn.get(null);
    X(() => {
      if (N)
        return M.actions.push(r), () => M.actions.pop(r);
    }, [
      M,
      r,
      N
    ]);
    let T = se(M, u.useCallback((S) => M.selectors.isTop(S, r), [
      M,
      r
    ]));
    Ns(T, F, (S) => {
      S.preventDefault(), k();
    }), Lp(T, b == null ? void 0 : b.defaultView, (S) => {
      S.preventDefault(), S.stopPropagation(), document.activeElement && "blur" in document.activeElement && typeof document.activeElement.blur == "function" && document.activeElement.blur(), k();
    }), Cs(d || O ? false : N, b, F), Es(N, p, k);
    let [L, U] = cl(), W = u.useMemo(() => [
      {
        dialogState: y,
        close: k,
        setTitleId: E,
        unmount: f
      },
      v
    ], [
      y,
      k,
      E,
      f,
      v
    ]), _ = ae({
      open: y === 0
    }), B = {
      ref: x,
      id: r,
      role: i,
      tabIndex: -1,
      "aria-modal": d ? void 0 : y === 0 ? true : void 0,
      "aria-labelledby": v.titleId,
      "aria-describedby": L,
      unmount: f
    }, D = !Ip(), K = lt.None;
    N && !d && (K |= lt.RestoreFocus, K |= lt.TabLock, c && (K |= lt.AutoFocus), D && (K |= lt.InitialFocus));
    let $ = J();
    return j.createElement(ql, null, j.createElement(eo, {
      force: true
    }, j.createElement(Ps, null, j.createElement(Ms.Provider, {
      value: W
    }, j.createElement(Jl, {
      target: p
    }, j.createElement(eo, {
      force: false
    }, j.createElement(U, {
      slot: _
    }, j.createElement(I, null, j.createElement(Bp, {
      initialFocus: o,
      initialFocusFallback: p,
      containers: F,
      features: K
    }, j.createElement(ys, {
      value: k
    }, $({
      ourProps: B,
      theirProps: h,
      slot: _,
      defaultTag: nm,
      features: rm,
      visible: y === 0,
      name: "Dialog"
    })))))))))));
  }), nm = "div", rm = Ce.RenderStrategy | Ce.Static;
  function sm(e, t) {
    let { transition: n = false, open: r, ...s } = e, a = vt(), o = e.hasOwnProperty("open") || a !== null, i = e.hasOwnProperty("onClose");
    if (!o && !i)
      throw new Error("You have to provide an `open` and an `onClose` prop to the `Dialog` component.");
    if (!o)
      throw new Error("You provided an `onClose` prop to the `Dialog`, but forgot an `open` prop.");
    if (!i)
      throw new Error("You provided an `open` prop to the `Dialog`, but forgot an `onClose` prop.");
    if (!a && typeof e.open != "boolean")
      throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${e.open}`);
    if (typeof e.onClose != "function")
      throw new Error(`You provided an \`onClose\` prop to the \`Dialog\`, but the value is not a function. Received: ${e.onClose}`);
    return (r !== void 0 || n) && !s.static ? j.createElement(Wn, null, j.createElement(Xp, {
      show: r,
      transition: n,
      unmount: s.unmount
    }, j.createElement(no, {
      ref: t,
      ...s
    }))) : j.createElement(Wn, null, j.createElement(no, {
      ref: t,
      open: r,
      ...s
    }));
  }
  let am = "div";
  function om(e, t) {
    let n = u.useId(), { id: r = `headlessui-dialog-panel-${n}`, transition: s = false, ...a } = e, [{ dialogState: o, unmount: i }, c] = mr("Dialog.Panel"), d = ne(t, c.panelRef), f = ae({
      open: o === 0
    }), h = R((b) => {
      b.stopPropagation();
    }), g = {
      ref: d,
      id: r,
      onClick: h
    }, m = s ? Fs : u.Fragment, p = s ? {
      unmount: i
    } : {}, x = J();
    return j.createElement(m, {
      ...p
    }, x({
      ourProps: g,
      theirProps: a,
      slot: f,
      defaultTag: am,
      name: "Dialog.Panel"
    }));
  }
  let lm = "div";
  function im(e, t) {
    let { transition: n = false, ...r } = e, [{ dialogState: s, unmount: a }] = mr("Dialog.Backdrop"), o = ae({
      open: s === 0
    }), i = {
      ref: t,
      "aria-hidden": true
    }, c = n ? Fs : u.Fragment, d = n ? {
      unmount: a
    } : {}, f = J();
    return j.createElement(c, {
      ...d
    }, f({
      ourProps: i,
      theirProps: r,
      slot: o,
      defaultTag: lm,
      name: "Dialog.Backdrop"
    }));
  }
  let cm = "h2";
  function um(e, t) {
    let n = u.useId(), { id: r = `headlessui-dialog-title-${n}`, ...s } = e, [{ dialogState: a, setTitleId: o }] = mr("Dialog.Title"), i = ne(t);
    u.useEffect(() => (o(r), () => o(null)), [
      r,
      o
    ]);
    let c = ae({
      open: a === 0
    }), d = {
      ref: i,
      id: r
    };
    return J()({
      ourProps: d,
      theirProps: s,
      slot: c,
      defaultTag: cm,
      name: "Dialog.Title"
    });
  }
  let dm;
  dm = Q(sm);
  bi = Q(om);
  Q(im);
  fm = Q(um);
  hm = Object.assign(dm, {
    Panel: bi,
    Title: fm,
    Description: ul
  });
  var pm = Object.defineProperty, mm = (e, t, n) => t in e ? pm(e, t, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: n
  }) : e[t] = n, ro = (e, t, n) => (mm(e, typeof t != "symbol" ? t + "" : t, n), n), ue = ((e) => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(ue || {}), gm = ((e) => (e[e.OpenPopover = 0] = "OpenPopover", e[e.ClosePopover = 1] = "ClosePopover", e[e.SetButton = 2] = "SetButton", e[e.SetButtonId = 3] = "SetButtonId", e[e.SetPanel = 4] = "SetPanel", e[e.SetPanelId = 5] = "SetPanelId", e))(gm || {});
  let xm = {
    0: (e) => e.popoverState === 0 ? e : {
      ...e,
      popoverState: 0,
      __demoMode: false
    },
    1(e) {
      return e.popoverState === 1 ? e : {
        ...e,
        popoverState: 1,
        __demoMode: false
      };
    },
    2(e, t) {
      return e.button === t.button ? e : {
        ...e,
        button: t.button
      };
    },
    3(e, t) {
      return e.buttonId === t.buttonId ? e : {
        ...e,
        buttonId: t.buttonId
      };
    },
    4(e, t) {
      return e.panel === t.panel ? e : {
        ...e,
        panel: t.panel
      };
    },
    5(e, t) {
      return e.panelId === t.panelId ? e : {
        ...e,
        panelId: t.panelId
      };
    }
  };
  class Ds extends ks {
    constructor(t) {
      super(t), ro(this, "actions", {
        close: () => this.send({
          type: 1
        }),
        refocusableClose: (n) => {
          this.actions.close();
          let r = (() => n ? ve(n) ? n : "current" in n && ve(n.current) ? n.current : this.state.button : this.state.button)();
          r == null ? void 0 : r.focus();
        },
        open: () => this.send({
          type: 0
        }),
        setButtonId: (n) => this.send({
          type: 3,
          buttonId: n
        }),
        setButton: (n) => this.send({
          type: 2,
          button: n
        }),
        setPanelId: (n) => this.send({
          type: 5,
          panelId: n
        }),
        setPanel: (n) => this.send({
          type: 4,
          panel: n
        })
      }), ro(this, "selectors", {
        isPortalled: (n) => {
          var r;
          if (!n.button || !n.panel)
            return false;
          let s = (r = ot(n.button)) != null ? r : document;
          for (let h of s.querySelectorAll("body > *"))
            if (Number(h == null ? void 0 : h.contains(n.button)) ^ Number(h == null ? void 0 : h.contains(n.panel)))
              return true;
          let a = Qn(s), o = a.indexOf(n.button), i = (o + a.length - 1) % a.length, c = (o + 1) % a.length, d = a[i], f = a[c];
          return !n.panel.contains(d) && !n.panel.contains(f);
        }
      });
      {
        let n = this.state.id, r = fn.get(null);
        this.on(0, () => r.actions.push(n)), this.on(1, () => r.actions.pop(n));
      }
    }
    static new({ id: t, __demoMode: n = false }) {
      return new Ds({
        id: t,
        __demoMode: n,
        popoverState: n ? 0 : 1,
        buttons: {
          current: []
        },
        button: null,
        buttonId: null,
        panel: null,
        panelId: null,
        beforePanelSentinel: {
          current: null
        },
        afterPanelSentinel: {
          current: null
        },
        afterButtonSentinel: {
          current: null
        }
      });
    }
    reduce(t, n) {
      return re(n.type, xm, t, n);
    }
  }
  const vi = u.createContext(null);
  function gr(e) {
    let t = u.useContext(vi);
    if (t === null) {
      let n = new Error(`<${e} /> is missing a parent <Popover /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(n, gr), n;
    }
    return t;
  }
  function bm({ id: e, __demoMode: t = false }) {
    let n = u.useMemo(() => Ds.new({
      id: e,
      __demoMode: t
    }), []);
    return cr(() => n.dispose()), n;
  }
  let _s = u.createContext(null);
  _s.displayName = "PopoverGroupContext";
  function yi() {
    return u.useContext(_s);
  }
  let xr = u.createContext(null);
  xr.displayName = "PopoverPanelContext";
  function vm() {
    return u.useContext(xr);
  }
  let ym = "div";
  function wm(e, t) {
    var n;
    let r = u.useId(), { __demoMode: s = false, ...a } = e, o = bm({
      id: r,
      __demoMode: s
    }), i = u.useRef(null), c = ne(t, ol((T) => {
      i.current = T;
    })), [d, f, h, g, m] = se(o, u.useCallback((T) => [
      T.popoverState,
      T.button,
      T.panel,
      T.buttonId,
      T.panelId
    ], [])), p = vf((n = i.current) != null ? n : f), x = ye(g), b = ye(m), y = u.useMemo(() => ({
      buttonId: x,
      panelId: b,
      close: o.actions.close
    }), [
      x,
      b,
      o
    ]), v = yi(), w = v == null ? void 0 : v.registerPopover, k = R(() => {
      var T, L;
      let U = et((T = i.current) != null ? T : f);
      return (L = v == null ? void 0 : v.isFocusWithinPopoverGroup()) != null ? L : U && ((f == null ? void 0 : f.contains(U)) || (h == null ? void 0 : h.contains(U)));
    });
    u.useEffect(() => w == null ? void 0 : w(y), [
      w,
      y
    ]);
    let [E, N] = Ql(), C = Ls(f), I = ci({
      mainTreeNode: C,
      portals: E,
      defaultContainers: [
        {
          get current() {
            return o.state.button;
          }
        },
        {
          get current() {
            return o.state.panel;
          }
        }
      ]
    });
    Jn(p, "focus", (T) => {
      var L, U, W, _, B, D;
      T.target !== window && Le(T.target) && o.state.popoverState === ue.Open && (k() || o.state.button && o.state.panel && (I.contains(T.target) || (U = (L = o.state.beforePanelSentinel.current) == null ? void 0 : L.contains) != null && U.call(L, T.target) || (_ = (W = o.state.afterPanelSentinel.current) == null ? void 0 : W.contains) != null && _.call(W, T.target) || (D = (B = o.state.afterButtonSentinel.current) == null ? void 0 : B.contains) != null && D.call(B, T.target) || o.actions.close()));
    }, true);
    let H = d === ue.Open;
    Ns(H, I.resolveContainers, (T, L) => {
      o.actions.close(), El(L, js.Loose) || (T.preventDefault(), f == null ? void 0 : f.focus());
    });
    let A = ae({
      open: d === ue.Open,
      close: o.actions.refocusableClose
    }), F = se(o, u.useCallback((T) => re(T.popoverState, {
      [ue.Open]: ie.Open,
      [ue.Closed]: ie.Closed
    }), [])), O = {
      ref: c
    }, M = J();
    return j.createElement(Wn, {
      node: C
    }, j.createElement(Gl, null, j.createElement(xr.Provider, {
      value: null
    }, j.createElement(vi.Provider, {
      value: o
    }, j.createElement(ys, {
      value: o.actions.refocusableClose
    }, j.createElement(As, {
      value: F
    }, j.createElement(N, null, M({
      ourProps: O,
      theirProps: a,
      slot: A,
      defaultTag: ym,
      name: "Popover"
    }))))))));
  }
  let km = "button";
  function Em(e, t) {
    let n = u.useId(), { id: r = `headlessui-popover-button-${n}`, disabled: s = false, autoFocus: a = false, ...o } = e, i = gr("Popover.Button"), [c, d, f, h, g, m, p] = se(i, u.useCallback((P) => [
      P.popoverState,
      i.selectors.isPortalled(P),
      P.button,
      P.buttonId,
      P.panel,
      P.panelId,
      P.afterButtonSentinel
    ], [])), x = u.useRef(null), b = `headlessui-focus-sentinel-${u.useId()}`, y = yi(), v = y == null ? void 0 : y.closeOthers, w = vm() !== null;
    u.useEffect(() => {
      if (!w)
        return i.actions.setButtonId(r), () => i.actions.setButtonId(null);
    }, [
      w,
      r,
      i
    ]);
    let [k] = u.useState(() => Symbol()), E = ne(x, t, Vl(), R((P) => {
      if (!w) {
        if (P)
          i.state.buttons.current.push(k);
        else {
          let V = i.state.buttons.current.indexOf(k);
          V !== -1 && i.state.buttons.current.splice(V, 1);
        }
        i.state.buttons.current.length > 1 && console.warn("You are already using a <Popover.Button /> but only 1 <Popover.Button /> is supported."), P && i.actions.setButton(P);
      }
    })), N = ne(x, t), C = R((P) => {
      var V, Z, z;
      if (w) {
        if (i.state.popoverState === ue.Closed)
          return;
        switch (P.key) {
          case Y.Space:
          case Y.Enter:
            P.preventDefault(), (Z = (V = P.target).click) == null || Z.call(V), i.actions.close(), (z = i.state.button) == null || z.focus();
            break;
        }
      } else
        switch (P.key) {
          case Y.Space:
          case Y.Enter:
            P.preventDefault(), P.stopPropagation(), i.state.popoverState === ue.Closed ? (v == null ? void 0 : v(i.state.buttonId), i.actions.open()) : i.actions.close();
            break;
          case Y.Escape:
            if (i.state.popoverState !== ue.Open)
              return v == null ? void 0 : v(i.state.buttonId);
            if (!x.current)
              return;
            let G = et(x.current);
            if (G && !x.current.contains(G))
              return;
            P.preventDefault(), P.stopPropagation(), i.actions.close();
            break;
        }
    }), I = R((P) => {
      w || P.key === Y.Space && P.preventDefault();
    }), H = R((P) => {
      var V, Z;
      Jt(P.currentTarget) || s || (w ? (i.actions.close(), (V = i.state.button) == null || V.focus()) : (P.preventDefault(), P.stopPropagation(), i.state.popoverState === ue.Closed ? (v == null ? void 0 : v(i.state.buttonId), i.actions.open()) : i.actions.close(), (Z = i.state.button) == null || Z.focus()));
    }), A = R((P) => {
      P.preventDefault(), P.stopPropagation();
    }), { isFocusVisible: F, focusProps: O } = Ot({
      autoFocus: a
    }), { isHovered: M, hoverProps: T } = cn({
      isDisabled: s
    }), { pressed: L, pressProps: U } = qn({
      disabled: s
    }), W = c === ue.Open, _ = ae({
      open: W,
      active: L || W,
      disabled: s,
      hover: M,
      focus: F,
      autofocus: a
    }), B = er(e, f), D = Ge(w ? {
      ref: N,
      type: B,
      onKeyDown: C,
      onClick: H,
      disabled: s || void 0,
      autoFocus: a
    } : {
      ref: E,
      id: h,
      type: B,
      "aria-expanded": c === ue.Open,
      "aria-controls": g ? m : void 0,
      disabled: s || void 0,
      autoFocus: a,
      onKeyDown: C,
      onKeyUp: I,
      onClick: H,
      onMouseDown: A
    }, O, T, U), K = Is(), $ = R(() => {
      if (!ve(i.state.panel))
        return;
      let P = i.state.panel;
      function V() {
        re(K.current, {
          [ke.Forwards]: () => he(P, te.First),
          [ke.Backwards]: () => he(P, te.Last)
        }) === Ie.Error && he(Qn(ht(i.state.button)).filter((Z) => Z.dataset.headlessuiFocusGuard !== "true"), re(K.current, {
          [ke.Forwards]: te.Next,
          [ke.Backwards]: te.Previous
        }), {
          relativeTo: i.state.button
        });
      }
      V();
    }), S = J();
    return j.createElement(j.Fragment, null, S({
      ourProps: D,
      theirProps: o,
      slot: _,
      defaultTag: km,
      name: "Popover.Button"
    }), W && !w && d && j.createElement(Be, {
      id: b,
      ref: p,
      features: _e.Focusable,
      "data-headlessui-focus-guard": true,
      as: "button",
      type: "button",
      onFocus: $
    }));
  }
  let jm = "div", Nm = Ce.RenderStrategy | Ce.Static;
  function wi(e, t) {
    let n = u.useId(), { id: r = `headlessui-popover-backdrop-${n}`, transition: s = false, ...a } = e, o = gr("Popover.Backdrop"), i = se(o, u.useCallback((y) => y.popoverState, [])), [c, d] = u.useState(null), f = ne(t, d), h = vt(), [g, m] = nr(s, c, h !== null ? (h & ie.Open) === ie.Open : i === ue.Open), p = R((y) => {
      if (Jt(y.currentTarget))
        return y.preventDefault();
      o.actions.close();
    }), x = ae({
      open: i === ue.Open
    }), b = {
      ref: f,
      id: r,
      "aria-hidden": true,
      onClick: p,
      ...tr(m)
    };
    return J()({
      ourProps: b,
      theirProps: a,
      slot: x,
      defaultTag: jm,
      features: Nm,
      visible: g,
      name: "Popover.Backdrop"
    });
  }
  let Cm = "div", Sm = Ce.RenderStrategy | Ce.Static;
  function Tm(e, t) {
    let n = u.useId(), { id: r = `headlessui-popover-panel-${n}`, focus: s = false, anchor: a, portal: o = false, modal: i = false, transition: c = false, ...d } = e, f = gr("Popover.Panel"), h = se(f, f.selectors.isPortalled), [g, m, p, x, b] = se(f, u.useCallback((S) => [
      S.popoverState,
      S.button,
      S.__demoMode,
      S.beforePanelSentinel,
      S.afterPanelSentinel
    ], [])), y = `headlessui-focus-sentinel-before-${n}`, v = `headlessui-focus-sentinel-after-${n}`, w = u.useRef(null), k = Ul(a), [E, N] = zl(k), C = Wl();
    k && (o = true);
    let [I, H] = u.useState(null), A = ne(w, t, k ? E : null, f.actions.setPanel, H), F = pt(m), O = pt(w.current);
    X(() => (f.actions.setPanelId(r), () => f.actions.setPanelId(null)), [
      r,
      f
    ]);
    let M = vt(), [T, L] = nr(c, I, M !== null ? (M & ie.Open) === ie.Open : g === ue.Open);
    Es(T, m, f.actions.close), Cs(p ? false : i && T, O);
    let U = R((S) => {
      var P;
      switch (S.key) {
        case Y.Escape:
          if (f.state.popoverState !== ue.Open || !w.current)
            return;
          let V = et(w.current);
          if (V && !w.current.contains(V))
            return;
          S.preventDefault(), S.stopPropagation(), f.actions.close(), (P = f.state.button) == null || P.focus();
          break;
      }
    });
    u.useEffect(() => {
      var S;
      e.static || g === ue.Closed && ((S = e.unmount) == null || S) && f.actions.setPanel(null);
    }, [
      g,
      e.unmount,
      e.static,
      f
    ]), u.useEffect(() => {
      if (p || !s || g !== ue.Open || !w.current)
        return;
      let S = et(w.current);
      w.current.contains(S) || he(w.current, te.First);
    }, [
      p,
      s,
      w.current,
      g
    ]);
    let W = ae({
      open: g === ue.Open,
      close: f.actions.refocusableClose
    }), _ = Ge(k ? C() : {}, {
      ref: A,
      id: r,
      onKeyDown: U,
      onBlur: s && g === ue.Open ? (S) => {
        var P, V, Z, z, G;
        let oe = S.relatedTarget;
        oe && w.current && ((P = w.current) != null && P.contains(oe) || (f.actions.close(), ((Z = (V = x.current) == null ? void 0 : V.contains) != null && Z.call(V, oe) || (G = (z = b.current) == null ? void 0 : z.contains) != null && G.call(z, oe)) && oe.focus({
          preventScroll: true
        })));
      } : void 0,
      tabIndex: -1,
      style: {
        ...d.style,
        ...N,
        "--button-width": Kr(T, m, true).width
      },
      ...tr(L)
    }), B = Is(), D = R(() => {
      let S = w.current;
      if (!S)
        return;
      function P() {
        re(B.current, {
          [ke.Forwards]: () => {
            var V;
            he(S, te.First) === Ie.Error && ((V = f.state.afterPanelSentinel.current) == null || V.focus());
          },
          [ke.Backwards]: () => {
            var V;
            (V = f.state.button) == null || V.focus({
              preventScroll: true
            });
          }
        });
      }
      P();
    }), K = R(() => {
      let S = w.current;
      if (!S)
        return;
      function P() {
        re(B.current, {
          [ke.Forwards]: () => {
            var V;
            if (!f.state.button)
              return;
            let Z = (V = ht(f.state.button)) != null ? V : document.body, z = Qn(Z), G = z.indexOf(f.state.button), oe = z.slice(0, G + 1), yt = [
              ...z.slice(G + 1),
              ...oe
            ];
            for (let le of yt.slice())
              if (le.dataset.headlessuiFocusGuard === "true" || I != null && I.contains(le)) {
                let Qs = yt.indexOf(le);
                Qs !== -1 && yt.splice(Qs, 1);
              }
            he(yt, te.First, {
              sorted: false
            });
          },
          [ke.Backwards]: () => {
            var V;
            he(S, te.Previous) === Ie.Error && ((V = f.state.button) == null || V.focus());
          }
        });
      }
      P();
    }), $ = J();
    return j.createElement(ql, null, j.createElement(xr.Provider, {
      value: r
    }, j.createElement(ys, {
      value: f.actions.refocusableClose
    }, j.createElement(Ps, {
      enabled: o ? e.static || T : false,
      ownerDocument: F
    }, T && h && j.createElement(Be, {
      id: y,
      ref: x,
      features: _e.Focusable,
      "data-headlessui-focus-guard": true,
      as: "button",
      type: "button",
      onFocus: D
    }), $({
      ourProps: _,
      theirProps: d,
      slot: W,
      defaultTag: Cm,
      features: Sm,
      visible: T,
      name: "Popover.Panel"
    }), T && h && j.createElement(Be, {
      id: v,
      ref: b,
      features: _e.Focusable,
      "data-headlessui-focus-guard": true,
      as: "button",
      type: "button",
      onFocus: K
    })))));
  }
  let $m = "div";
  function Rm(e, t) {
    let n = u.useRef(null), r = ne(n, t), [s, a] = u.useState([]), o = R((x) => {
      a((b) => {
        let y = b.indexOf(x);
        if (y !== -1) {
          let v = b.slice();
          return v.splice(y, 1), v;
        }
        return b;
      });
    }), i = R((x) => (a((b) => [
      ...b,
      x
    ]), () => o(x))), c = R(() => {
      var x;
      let b = ht(n.current);
      if (!b)
        return false;
      let y = et(n.current);
      return (x = n.current) != null && x.contains(y) ? true : s.some((v) => {
        var w, k;
        return ((w = b.getElementById(v.buttonId.current)) == null ? void 0 : w.contains(y)) || ((k = b.getElementById(v.panelId.current)) == null ? void 0 : k.contains(y));
      });
    }), d = R((x) => {
      for (let b of s)
        b.buttonId.current !== x && b.close();
    }), f = u.useMemo(() => ({
      registerPopover: i,
      unregisterPopover: o,
      isFocusWithinPopoverGroup: c,
      closeOthers: d
    }), [
      i,
      o,
      c,
      d
    ]), h = ae({}), g = e, m = {
      ref: r
    }, p = J();
    return j.createElement(Wn, null, j.createElement(_s.Provider, {
      value: f
    }, p({
      ourProps: m,
      theirProps: g,
      slot: h,
      defaultTag: $m,
      name: "Popover.Group"
    })));
  }
  let Am, Pm, Om, Lm, Bs;
  Am = Q(wm);
  ki = Q(Em);
  Pm = Q(wi);
  Om = Q(wi);
  Ei = Q(Tm);
  Lm = Q(Rm);
  Im = Object.assign(Am, {
    Button: ki,
    Backdrop: Om,
    Overlay: Pm,
    Panel: Ei,
    Group: Lm
  });
  Bs = u.createContext(null);
  Bs.displayName = "GroupContext";
  let Fm = u.Fragment;
  function Mm(e) {
    var t;
    let [n, r] = u.useState(null), [s, a] = fl(), [o, i] = cl(), c = u.useMemo(() => ({
      switch: n,
      setSwitch: r
    }), [
      n,
      r
    ]), d = {}, f = e, h = J();
    return j.createElement(i, {
      name: "Switch.Description",
      value: o
    }, j.createElement(a, {
      name: "Switch.Label",
      value: s,
      props: {
        htmlFor: (t = c.switch) == null ? void 0 : t.id,
        onClick(g) {
          n && (qr(g.currentTarget) && g.preventDefault(), n.click(), n.focus({
            preventScroll: true
          }));
        }
      }
    }, j.createElement(Bs.Provider, {
      value: c
    }, h({
      ourProps: d,
      theirProps: f,
      slot: {},
      defaultTag: Fm,
      name: "Switch.Group"
    }))));
  }
  let Dm = "button";
  function _m(e, t) {
    var n;
    let r = u.useId(), s = vs(), a = Kn(), { id: o = s || `headlessui-switch-${r}`, disabled: i = a || false, checked: c, defaultChecked: d, onChange: f, name: h, value: g, form: m, autoFocus: p = false, ...x } = e, b = u.useContext(Bs), [y, v] = u.useState(null), w = u.useRef(null), k = ne(w, t, b === null ? null : b.setSwitch, v), E = Qo(d), [N, C] = Xo(c, f, E ?? false), I = Ke(), [H, A] = u.useState(false), F = R(() => {
      A(true), C == null ? void 0 : C(!N), I.nextFrame(() => {
        A(false);
      });
    }), O = R((z) => {
      if (Jt(z.currentTarget))
        return z.preventDefault();
      z.preventDefault(), F();
    }), M = R((z) => {
      z.key === Y.Space ? (z.preventDefault(), F()) : z.key === Y.Enter && p0(z.currentTarget);
    }), T = R((z) => z.preventDefault()), L = dn(), U = il(), { isFocusVisible: W, focusProps: _ } = Ot({
      autoFocus: p
    }), { isHovered: B, hoverProps: D } = cn({
      isDisabled: i
    }), { pressed: K, pressProps: $ } = qn({
      disabled: i
    }), S = ae({
      checked: N,
      disabled: i,
      hover: B,
      focus: W,
      active: K,
      autofocus: p,
      changing: H
    }), P = Ge({
      id: o,
      ref: k,
      role: "switch",
      type: er(e, y),
      tabIndex: e.tabIndex === -1 ? 0 : (n = e.tabIndex) != null ? n : 0,
      "aria-checked": N,
      "aria-labelledby": L,
      "aria-describedby": U,
      disabled: i || void 0,
      autoFocus: p,
      onClick: O,
      onKeyUp: M,
      onKeyPress: T
    }, _, D, $), V = u.useCallback(() => {
      if (E !== void 0)
        return C == null ? void 0 : C(E);
    }, [
      C,
      E
    ]), Z = J();
    return j.createElement(j.Fragment, null, h != null && j.createElement(nl, {
      disabled: i,
      data: {
        [h]: g || "on"
      },
      overrides: {
        type: "checkbox",
        checked: N
      },
      form: m,
      onReset: V
    }), Z({
      ourProps: P,
      theirProps: x,
      slot: S,
      defaultTag: Dm,
      name: "Switch"
    }));
  }
  let Bm = Q(_m), Hm = Mm, Um = hl, Vm = ul, Wm = Object.assign(Bm, {
    Group: Hm,
    Label: Um,
    Description: Vm
  });
  function zm({ onFocus: e }) {
    let [t, n] = u.useState(true), r = dr();
    return t ? j.createElement(Be, {
      as: "button",
      type: "button",
      features: _e.Focusable,
      onFocus: (s) => {
        s.preventDefault();
        let a, o = 50;
        function i() {
          if (o-- <= 0) {
            a && cancelAnimationFrame(a);
            return;
          }
          if (e()) {
            if (cancelAnimationFrame(a), !r.current)
              return;
            n(false);
            return;
          }
          a = requestAnimationFrame(i);
        }
        a = requestAnimationFrame(i);
      }
    }) : null;
  }
  const ji = u.createContext(null);
  function Gm() {
    return {
      groups: /* @__PURE__ */ new Map(),
      get(e, t) {
        var n;
        let r = this.groups.get(e);
        r || (r = /* @__PURE__ */ new Map(), this.groups.set(e, r));
        let s = (n = r.get(t)) != null ? n : 0;
        r.set(t, s + 1);
        let a = Array.from(r.keys()).indexOf(t);
        function o() {
          let i = r.get(t);
          i > 1 ? r.set(t, i - 1) : r.delete(t);
        }
        return [
          a,
          o
        ];
      }
    };
  }
  function Zm({ children: e }) {
    let t = u.useRef(Gm());
    return u.createElement(ji.Provider, {
      value: t
    }, e);
  }
  function Ni(e) {
    let t = u.useContext(ji);
    if (!t)
      throw new Error("You must wrap your component in a <StableCollection>");
    let n = u.useId(), [r, s] = t.current.get(e, n);
    return u.useEffect(() => s, []), r;
  }
  var qm = ((e) => (e[e.Forwards = 0] = "Forwards", e[e.Backwards = 1] = "Backwards", e))(qm || {}), Km = ((e) => (e[e.Less = -1] = "Less", e[e.Equal = 0] = "Equal", e[e.Greater = 1] = "Greater", e))(Km || {}), Ym = ((e) => (e[e.SetSelectedIndex = 0] = "SetSelectedIndex", e[e.RegisterTab = 1] = "RegisterTab", e[e.UnregisterTab = 2] = "UnregisterTab", e[e.RegisterPanel = 3] = "RegisterPanel", e[e.UnregisterPanel = 4] = "UnregisterPanel", e))(Ym || {});
  let Xm = {
    0(e, t) {
      var n;
      let r = ut(e.tabs, (f) => f.current), s = ut(e.panels, (f) => f.current), a = r.filter((f) => {
        var h;
        return !((h = f.current) != null && h.hasAttribute("disabled"));
      }), o = {
        ...e,
        tabs: r,
        panels: s
      };
      if (t.index < 0 || t.index > r.length - 1) {
        let f = re(Math.sign(t.index - e.selectedIndex), {
          [-1]: () => 1,
          0: () => re(Math.sign(t.index), {
            [-1]: () => 0,
            0: () => 0,
            1: () => 1
          }),
          1: () => 0
        });
        if (a.length === 0)
          return o;
        let h = re(f, {
          0: () => r.indexOf(a[0]),
          1: () => r.indexOf(a[a.length - 1])
        });
        return {
          ...o,
          selectedIndex: h === -1 ? e.selectedIndex : h
        };
      }
      let i = r.slice(0, t.index), c = [
        ...r.slice(t.index),
        ...i
      ].find((f) => a.includes(f));
      if (!c)
        return o;
      let d = (n = r.indexOf(c)) != null ? n : e.selectedIndex;
      return d === -1 && (d = e.selectedIndex), {
        ...o,
        selectedIndex: d
      };
    },
    1(e, t) {
      if (e.tabs.includes(t.tab))
        return e;
      let n = e.tabs[e.selectedIndex], r = ut([
        ...e.tabs,
        t.tab
      ], (a) => a.current), s = e.selectedIndex;
      return e.info.current.isControlled || (s = r.indexOf(n), s === -1 && (s = e.selectedIndex)), {
        ...e,
        tabs: r,
        selectedIndex: s
      };
    },
    2(e, t) {
      return {
        ...e,
        tabs: e.tabs.filter((n) => n !== t.tab)
      };
    },
    3(e, t) {
      return e.panels.includes(t.panel) ? e : {
        ...e,
        panels: ut([
          ...e.panels,
          t.panel
        ], (n) => n.current)
      };
    },
    4(e, t) {
      return {
        ...e,
        panels: e.panels.filter((n) => n !== t.panel)
      };
    }
  }, Hs = u.createContext(null);
  Hs.displayName = "TabsDataContext";
  function At(e) {
    let t = u.useContext(Hs);
    if (t === null) {
      let n = new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(n, At), n;
    }
    return t;
  }
  let Us = u.createContext(null);
  Us.displayName = "TabsActionsContext";
  function Vs(e) {
    let t = u.useContext(Us);
    if (t === null) {
      let n = new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(n, Vs), n;
    }
    return t;
  }
  function Qm(e, t) {
    return re(t.type, Xm, e, t);
  }
  let Jm = "div";
  function eg(e, t) {
    let { defaultIndex: n = 0, vertical: r = false, manual: s = false, onChange: a, selectedIndex: o = null, ...i } = e;
    const c = r ? "vertical" : "horizontal", d = s ? "manual" : "auto";
    let f = o !== null, h = ye({
      isControlled: f
    }), g = ne(t), [m, p] = u.useReducer(Qm, {
      info: h,
      selectedIndex: o ?? n,
      tabs: [],
      panels: []
    }), x = ae({
      selectedIndex: m.selectedIndex
    }), b = ye(a || (() => {
    })), y = ye(m.tabs), v = u.useMemo(() => ({
      orientation: c,
      activation: d,
      ...m
    }), [
      c,
      d,
      m
    ]), w = R((A) => (p({
      type: 1,
      tab: A
    }), () => p({
      type: 2,
      tab: A
    }))), k = R((A) => (p({
      type: 3,
      panel: A
    }), () => p({
      type: 4,
      panel: A
    }))), E = R((A) => {
      N.current !== A && b.current(A), f || p({
        type: 0,
        index: A
      });
    }), N = ye(f ? e.selectedIndex : m.selectedIndex), C = u.useMemo(() => ({
      registerTab: w,
      registerPanel: k,
      change: E
    }), []);
    X(() => {
      p({
        type: 0,
        index: o ?? n
      });
    }, [
      o
    ]), X(() => {
      if (N.current === void 0 || m.tabs.length <= 0)
        return;
      let A = ut(m.tabs, (F) => F.current);
      A.some((F, O) => m.tabs[O] !== F) && E(A.indexOf(m.tabs[N.current]));
    });
    let I = {
      ref: g
    }, H = J();
    return j.createElement(Zm, null, j.createElement(Us.Provider, {
      value: C
    }, j.createElement(Hs.Provider, {
      value: v
    }, v.tabs.length <= 0 && j.createElement(zm, {
      onFocus: () => {
        var A, F;
        for (let O of y.current)
          if (((A = O.current) == null ? void 0 : A.tabIndex) === 0)
            return (F = O.current) == null || F.focus(), true;
        return false;
      }
    }), H({
      ourProps: I,
      theirProps: i,
      slot: x,
      defaultTag: Jm,
      name: "Tabs"
    }))));
  }
  let tg = "div";
  function ng(e, t) {
    let { orientation: n, selectedIndex: r } = At("Tab.List"), s = ne(t), a = ae({
      selectedIndex: r
    }), o = e, i = {
      ref: s,
      role: "tablist",
      "aria-orientation": n
    };
    return J()({
      ourProps: i,
      theirProps: o,
      slot: a,
      defaultTag: tg,
      name: "Tabs.List"
    });
  }
  let rg = "button";
  function sg(e, t) {
    var n, r;
    let s = u.useId(), { id: a = `headlessui-tabs-tab-${s}`, disabled: o = false, autoFocus: i = false, ...c } = e, { orientation: d, activation: f, selectedIndex: h, tabs: g, panels: m } = At("Tab"), p = Vs("Tab"), x = At("Tab"), [b, y] = u.useState(null), v = u.useRef(null), w = ne(v, t, y);
    X(() => p.registerTab(v), [
      p,
      v
    ]);
    let k = Ni("tabs"), E = g.indexOf(v);
    E === -1 && (E = k);
    let N = E === h, C = R((D) => {
      let K = D();
      if (K === Ie.Success && f === "auto") {
        let $ = et(v.current), S = x.tabs.findIndex((P) => P.current === $);
        S !== -1 && p.change(S);
      }
      return K;
    }), I = R((D) => {
      let K = g.map(($) => $.current).filter(Boolean);
      if (D.key === Y.Space || D.key === Y.Enter) {
        D.preventDefault(), D.stopPropagation(), p.change(E);
        return;
      }
      switch (D.key) {
        case Y.Home:
        case Y.PageUp:
          return D.preventDefault(), D.stopPropagation(), C(() => he(K, te.First));
        case Y.End:
        case Y.PageDown:
          return D.preventDefault(), D.stopPropagation(), C(() => he(K, te.Last));
      }
      if (C(() => re(d, {
        vertical() {
          return D.key === Y.ArrowUp ? he(K, te.Previous | te.WrapAround) : D.key === Y.ArrowDown ? he(K, te.Next | te.WrapAround) : Ie.Error;
        },
        horizontal() {
          return D.key === Y.ArrowLeft ? he(K, te.Previous | te.WrapAround) : D.key === Y.ArrowRight ? he(K, te.Next | te.WrapAround) : Ie.Error;
        }
      })) === Ie.Success)
        return D.preventDefault();
    }), H = u.useRef(false), A = R(() => {
      var D;
      H.current || (H.current = true, (D = v.current) == null || D.focus({
        preventScroll: true
      }), p.change(E), un(() => {
        H.current = false;
      }));
    }), F = R((D) => {
      D.preventDefault();
    }), { isFocusVisible: O, focusProps: M } = Ot({
      autoFocus: i
    }), { isHovered: T, hoverProps: L } = cn({
      isDisabled: o
    }), { pressed: U, pressProps: W } = qn({
      disabled: o
    }), _ = ae({
      selected: N,
      hover: T,
      active: U,
      focus: O,
      autofocus: i,
      disabled: o
    }), B = Ge({
      ref: w,
      onKeyDown: I,
      onMouseDown: F,
      onClick: A,
      id: a,
      role: "tab",
      type: er(e, b),
      "aria-controls": (r = (n = m[E]) == null ? void 0 : n.current) == null ? void 0 : r.id,
      "aria-selected": N,
      tabIndex: N ? 0 : -1,
      disabled: o || void 0,
      autoFocus: i
    }, M, L, W);
    return J()({
      ourProps: B,
      theirProps: c,
      slot: _,
      defaultTag: rg,
      name: "Tabs.Tab"
    });
  }
  let ag = "div";
  function og(e, t) {
    let { selectedIndex: n } = At("Tab.Panels"), r = ne(t), s = ae({
      selectedIndex: n
    }), a = e, o = {
      ref: r
    };
    return J()({
      ourProps: o,
      theirProps: a,
      slot: s,
      defaultTag: ag,
      name: "Tabs.Panels"
    });
  }
  let lg = "div", ig = Ce.RenderStrategy | Ce.Static;
  function cg(e, t) {
    var n, r, s, a;
    let o = u.useId(), { id: i = `headlessui-tabs-panel-${o}`, tabIndex: c = 0, ...d } = e, { selectedIndex: f, tabs: h, panels: g } = At("Tab.Panel"), m = Vs("Tab.Panel"), p = u.useRef(null), x = ne(p, t);
    X(() => m.registerPanel(p), [
      m,
      p
    ]);
    let b = Ni("panels"), y = g.indexOf(p);
    y === -1 && (y = b);
    let v = y === f, { isFocusVisible: w, focusProps: k } = Ot(), E = ae({
      selected: v,
      focus: w
    }), N = Ge({
      ref: x,
      id: i,
      role: "tabpanel",
      "aria-labelledby": (r = (n = h[y]) == null ? void 0 : n.current) == null ? void 0 : r.id,
      tabIndex: v ? c : -1
    }, k), C = J();
    return !v && ((s = d.unmount) == null || s) && !((a = d.static) != null && a) ? j.createElement(Be, {
      "aria-hidden": "true",
      ...N
    }) : C({
      ourProps: N,
      theirProps: d,
      slot: E,
      defaultTag: lg,
      features: ig,
      visible: v,
      name: "Tabs.Panel"
    });
  }
  let ug;
  ug = Q(sg);
  Ws = Q(eg);
  zs = Q(ng);
  Gs = Q(og);
  it = Q(cg);
  Ci = Object.assign(ug, {
    Group: Ws,
    List: zs,
    Panels: Gs,
    Panel: it
  });
  function dg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z"
    }));
  }
  const fg = u.forwardRef(dg), hg = fg;
  function pg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25"
    }));
  }
  const mg = u.forwardRef(pg), so = mg;
  function gg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
    }));
  }
  const xg = u.forwardRef(gg), bg = xg;
  function vg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25"
    }));
  }
  const yg = u.forwardRef(vg), wg = yg;
  function kg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.076-4.076a1.526 1.526 0 0 1 1.037-.443 48.282 48.282 0 0 0 5.68-.494c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z"
    }));
  }
  const Eg = u.forwardRef(kg), jg = Eg;
  function Ng({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.325.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 0 1 1.37.49l1.296 2.247a1.125 1.125 0 0 1-.26 1.431l-1.003.827c-.293.241-.438.613-.43.992a7.723 7.723 0 0 1 0 .255c-.008.378.137.75.43.991l1.004.827c.424.35.534.955.26 1.43l-1.298 2.247a1.125 1.125 0 0 1-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.47 6.47 0 0 1-.22.128c-.331.183-.581.495-.644.869l-.213 1.281c-.09.543-.56.94-1.11.94h-2.594c-.55 0-1.019-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 0 1-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 0 1-1.369-.49l-1.297-2.247a1.125 1.125 0 0 1 .26-1.431l1.004-.827c.292-.24.437-.613.43-.991a6.932 6.932 0 0 1 0-.255c.007-.38-.138-.751-.43-.992l-1.004-.827a1.125 1.125 0 0 1-.26-1.43l1.297-2.247a1.125 1.125 0 0 1 1.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.086.22-.128.332-.183.582-.495.644-.869l.214-1.28Z"
    }), u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
    }));
  }
  const Cg = u.forwardRef(Ng), Sg = Cg;
  function Tg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25"
    }));
  }
  let $g;
  $g = u.forwardRef(Tg);
  Si = $g;
  function Rg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
    }));
  }
  const Ag = u.forwardRef(Rg), Pg = Ag;
  function Og({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z"
    }));
  }
  let Lg;
  Lg = u.forwardRef(Og);
  Ig = Lg;
  function Fg({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.009 9.009 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z"
    }));
  }
  const Mg = u.forwardRef(Fg), Dg = Mg;
  function _g({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z"
    }));
  }
  let Bg;
  Bg = u.forwardRef(_g);
  Hg = Bg;
  function Ug({ title: e, titleId: t, ...n }, r) {
    return u.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": t
    }, n), e ? u.createElement("title", {
      id: t
    }, e) : null, u.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z"
    }));
  }
  let Vg, zg;
  Vg = u.forwardRef(Ug);
  Wg = Vg;
  Ti = (e) => l.jsxs("svg", {
    style: {
      flex: "none",
      lineHeight: 1
    },
    ...e,
    fill: "currentColor",
    fillRule: "evenodd",
    height: "1em",
    viewBox: "0 0 24 24",
    width: "1em",
    xmlns: "http://www.w3.org/2000/svg",
    children: [
      l.jsx("title", {
        children: "NotebookLM"
      }),
      l.jsx("path", {
        d: "M11.999 3.14C5.372 3.14 0 8.588 0 15.312v5.828h2.212v-.58c0-2.728 2.178-4.938 4.866-4.938 2.688 0 4.866 2.21 4.866 4.937v.581h2.212v-.58c0-3.967-3.17-7.18-7.078-7.18a6.966 6.966 0 00-4.086 1.318C4.2 12.262 6.687 10.59 9.56 10.59c4.057 0 7.347 3.338 7.347 7.453v3.097h2.212v-3.097c0-5.355-4.28-9.698-9.56-9.698a9.438 9.438 0 00-6.217 2.332C4.984 7.528 8.244 5.383 12 5.383c5.406 0 9.788 4.446 9.788 9.93v5.827H24v-5.828C23.999 8.588 18.627 3.14 11.999 3.14z"
      })
    ]
  });
  zg = 10;
  function Gg() {
    const [, e] = ee();
    return e.isLicensed() ? l.jsxs("a", {
      href: "#/profile",
      className: "flex items-center justify-center gap-1 rounded-lg bg-emerald-50 dark:bg-emerald-900/30 px-2 py-1.5 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 hover:text-emerald-800 dark:hover:text-emerald-300 active:bg-emerald-200 dark:active:bg-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-200 dark:focus:ring-emerald-600 focus:ring-offset-1",
      title: "Licensed",
      children: [
        l.jsx(Ic, {
          className: "w-3.5 h-3.5",
          "aria-hidden": "true"
        }),
        l.jsx("span", {
          className: "text-xs",
          children: "Licensed"
        })
      ]
    }) : l.jsxs("a", {
      href: "#/login",
      className: "flex items-center justify-center gap-1 rounded-lg bg-slate-100 dark:bg-slate-700/50 px-2 py-1.5 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-slate-300 active:bg-slate-300 dark:active:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-200 dark:focus:ring-slate-600 focus:ring-offset-1",
      title: "Running unlicensed \u2014 click to activate",
      children: [
        l.jsx(Kt, {
          className: "w-3.5 h-3.5",
          "aria-hidden": "true"
        }),
        l.jsx("span", {
          className: "text-xs",
          children: "Unlicensed"
        })
      ]
    });
  }
  function Zg() {
    const [, e] = ee(), [t, n] = u.useState(0), [r, s] = u.useState(() => sessionStorage.getItem("nlm_banner_dismissed") === "true");
    if (u.useEffect(() => {
      Di().then(n);
    }, []), e.isLicensed() || r)
      return null;
    const a = () => {
      s(true), sessionStorage.setItem("nlm_banner_dismissed", "true");
    }, o = t >= zg ? `NotebookLM Tools is unlicensed. You've used it ${t} times \u2014 if it's useful, please consider buying a license.` : "NotebookLM Tools is unlicensed. If you find it useful, please consider buying a license.";
    return l.jsxs("div", {
      className: "flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-xs",
      children: [
        l.jsx(Kt, {
          className: "w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0",
          "aria-hidden": "true"
        }),
        l.jsx("span", {
          className: "flex-1 text-slate-600 dark:text-slate-300",
          children: o
        }),
        l.jsx("button", {
          onClick: () => zn("banner"),
          className: "shrink-0 inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-700 dark:bg-slate-600 text-white hover:bg-slate-800 dark:hover:bg-slate-500",
          children: "Buy a license"
        }),
        l.jsx("button", {
          onClick: a,
          "aria-label": "Dismiss",
          className: "shrink-0 p-0.5 rounded text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700",
          children: l.jsx(sn, {
            className: "w-3 h-3"
          })
        })
      ]
    });
  }
  const qg = [
    {
      path: "/",
      title: "Home",
      icon: Pg,
      iconOnly: true
    },
    {
      path: "/notebooklm",
      title: "Notebooks",
      icon: wg,
      target: "_blank"
    },
    {
      path: "/podcast",
      title: "Podcast",
      icon: Dg,
      target: "_blank"
    },
    {
      path: "/prompts",
      title: "Prompts",
      icon: jg
    }
  ], Kg = "flex items-center justify-center p-2 min-[480px]:justify-start min-[480px]:gap-1 min-[480px]:px-2 min-[480px]:py-1.5 rounded-md text-xs font-medium", Yg = "bg-slate-100 dark:bg-slate-700/50 text-slate-700 dark:text-slate-200", Xg = "text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-slate-200", kt = "w-full flex items-center gap-2 px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md", Ar = "px-3 pt-2 pb-1 text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500", Qg = "flex items-center justify-center rounded-lg bg-slate-50 dark:bg-slate-700 p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-600 hover:text-slate-700 dark:hover:text-slate-200 active:bg-slate-200 dark:active:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200 dark:focus:ring-slate-600 focus:ring-offset-1";
  function Jg() {
    var _a3;
    const [e, t] = ee(), n = (_a3 = xo(e)) == null ? void 0 : _a3.authuser, r = qe(), s = t.isLicensed(), a = (o) => o === "/" ? r.pathname === "/" : o === "/notebooklm" ? r.pathname.startsWith("/notebooklm") || r.pathname.startsWith("/notebook/") : r.pathname.startsWith(o);
    return l.jsxs("nav", {
      className: "flex items-center justify-between gap-2 px-2 py-2 border-b bg-white dark:bg-slate-800 border-slate-200/80 dark:border-slate-700",
      children: [
        l.jsx("div", {
          className: "flex items-center gap-1",
          children: qg.map(({ path: o, title: i, icon: c, target: d, iconOnly: f }) => l.jsxs(Dt, {
            to: o,
            target: d,
            rel: d ? "noopener noreferrer" : void 0,
            className: `${Kg} ${a(o) ? Yg : Xg}`,
            title: i,
            children: [
              l.jsx(c, {
                className: "w-4 h-4",
                "aria-hidden": "true"
              }),
              !f && l.jsx("span", {
                className: "hidden min-[480px]:inline",
                children: i
              })
            ]
          }, o))
        }),
        l.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            l.jsx(Gg, {}),
            l.jsxs(Im, {
              className: "relative",
              children: [
                l.jsx(ki, {
                  className: Qg,
                  children: l.jsx(bg, {
                    className: "w-3.5 h-3.5",
                    "aria-hidden": "true"
                  })
                }),
                l.jsx(Ei, {
                  anchor: "bottom end",
                  className: "z-20 w-52 rounded-lg bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 ring-1 ring-black/5 dark:ring-slate-700 focus:outline-none",
                  children: ({ close: o }) => l.jsxs("div", {
                    className: "p-1.5",
                    children: [
                      l.jsx("div", {
                        className: Ar,
                        children: "Open"
                      }),
                      l.jsxs("a", {
                        href: ic(n),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: kt,
                        onClick: () => o(),
                        children: [
                          l.jsx(Ti, {
                            className: "w-3.5 h-3.5",
                            "aria-hidden": "true"
                          }),
                          l.jsx("span", {
                            children: "NotebookLM"
                          }),
                          l.jsx(so, {
                            className: "w-3 h-3 ml-auto",
                            "aria-hidden": "true"
                          })
                        ]
                      }),
                      l.jsx("div", {
                        className: Ar,
                        children: "Account"
                      }),
                      s ? l.jsxs(Dt, {
                        to: "/profile",
                        className: kt,
                        onClick: () => o(),
                        children: [
                          l.jsx(la, {
                            className: "w-3.5 h-3.5",
                            "aria-hidden": "true"
                          }),
                          l.jsx("span", {
                            children: "Profile"
                          })
                        ]
                      }) : l.jsxs(Dt, {
                        to: "/login",
                        className: kt,
                        onClick: () => o(),
                        children: [
                          l.jsx(Kt, {
                            className: "w-3.5 h-3.5",
                            "aria-hidden": "true"
                          }),
                          l.jsx("span", {
                            children: "Activate License"
                          })
                        ]
                      }),
                      !s && l.jsxs("button", {
                        className: "w-full flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-600/40 rounded-md",
                        onClick: () => {
                          o(), zn("menu");
                        },
                        children: [
                          l.jsx(Kt, {
                            className: "w-3.5 h-3.5 text-slate-500"
                          }),
                          l.jsx("span", {
                            children: "Buy a license"
                          })
                        ]
                      }),
                      s && l.jsxs("a", {
                        href: cc,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: kt,
                        onClick: () => o(),
                        children: [
                          l.jsx(la, {
                            className: "w-3.5 h-3.5",
                            "aria-hidden": "true"
                          }),
                          l.jsx("span", {
                            children: "Customer Portal"
                          }),
                          l.jsx(so, {
                            className: "w-3 h-3 ml-auto",
                            "aria-hidden": "true"
                          })
                        ]
                      }),
                      l.jsx("div", {
                        className: Ar,
                        children: "Settings"
                      }),
                      l.jsxs(Dt, {
                        to: "/settings",
                        className: kt,
                        onClick: () => o(),
                        children: [
                          l.jsx(Sg, {
                            className: "w-3.5 h-3.5",
                            "aria-hidden": "true"
                          }),
                          l.jsx("span", {
                            children: "Settings"
                          })
                        ]
                      }),
                      l.jsxs(Dt, {
                        to: "/backup",
                        className: kt,
                        onClick: () => o(),
                        children: [
                          l.jsx(hg, {
                            className: "w-3.5 h-3.5",
                            "aria-hidden": "true"
                          }),
                          l.jsx("span", {
                            children: "Backup"
                          })
                        ]
                      })
                    ]
                  })
                })
              ]
            })
          ]
        })
      ]
    });
  }
  const Pr = [
    "system",
    "light",
    "dark"
  ], ex = {
    system: Si,
    light: Wg,
    dark: Ig
  }, tx = {
    system: "Theme: System",
    light: "Theme: Light",
    dark: "Theme: Dark"
  };
  function nx() {
    const [e, t] = ee(), { themeMode: n } = e.themeSettings, r = () => {
      const a = Pr.indexOf(n), o = Pr[(a + 1) % Pr.length];
      t.setThemeMode(o);
    }, s = ex[n] || Si;
    return l.jsx("button", {
      onClick: r,
      className: "flex items-center justify-center rounded-lg bg-slate-50 dark:bg-slate-700 p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-600 hover:text-slate-700 dark:hover:text-slate-200 active:bg-slate-200 dark:active:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-200 dark:focus:ring-slate-600 focus:ring-offset-1 transition-all duration-150",
      title: tx[n],
      children: l.jsx(s, {
        className: "w-3.5 h-3.5",
        "aria-hidden": "true"
      })
    });
  }
  function $i() {
    const [e, t] = ee(), { themeMode: n } = e.themeSettings, [r, s] = u.useState("light");
    return u.useEffect(() => {
      t.loadThemeMode();
    }, []), u.useEffect(() => {
      const a = (c) => {
        s(c ? "dark" : "light"), c ? document.documentElement.classList.add("dark") : document.documentElement.classList.remove("dark");
      };
      if (n === "dark") {
        a(true);
        return;
      }
      if (n === "light") {
        a(false);
        return;
      }
      const o = window.matchMedia("(prefers-color-scheme: dark)");
      a(o.matches);
      const i = (c) => a(c.matches);
      return o.addEventListener("change", i), () => o.removeEventListener("change", i);
    }, [
      n
    ]), {
      resolvedTheme: r,
      themeMode: n
    };
  }
  const rx = [
    {
      label: "Multi-type generation",
      unlicensed: "x",
      licensed: "check"
    },
    {
      label: "Banner & logo-free",
      unlicensed: "x",
      licensed: "check"
    },
    {
      label: "Early access",
      unlicensed: "dash",
      licensed: "check"
    },
    {
      label: "Priority requests",
      unlicensed: "dash",
      licensed: "check"
    },
    {
      label: "Supports development",
      unlicensed: "dash",
      licensed: "check"
    },
    {
      label: "Everything else",
      unlicensed: "check",
      licensed: "check"
    }
  ];
  function ao({ type: e }) {
    return e === "check" ? l.jsx(xt, {
      className: "w-3 h-3 text-emerald-500 shrink-0"
    }) : e === "x" ? l.jsx(sn, {
      className: "w-3 h-3 text-slate-300 dark:text-slate-600 shrink-0"
    }) : l.jsx("span", {
      className: "w-3 text-slate-300 dark:text-slate-600 text-center shrink-0",
      children: "\u2014"
    });
  }
  function sx({ isOpen: e, onClose: t, title: n = "You're using NotebookLM Tools unlicensed", source: r, note: s }) {
    return l.jsxs(hm, {
      open: e,
      onClose: () => {
      },
      className: "relative z-50",
      children: [
        l.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        l.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: l.jsxs(bi, {
            className: "w-full max-w-xs space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5 relative",
            children: [
              l.jsx("button", {
                onClick: t,
                "aria-label": "Close",
                className: "absolute top-3 right-3 rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                children: l.jsx(sn, {
                  className: "h-4 w-4"
                })
              }),
              l.jsxs("div", {
                className: "text-center",
                children: [
                  l.jsx("img", {
                    src: chrome.runtime.getURL("img/logo-96.png"),
                    className: "w-12 h-12 mx-auto",
                    alt: "IrfanLM Tools"
                  }),
                  l.jsx("p", {
                    className: "mt-2 text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: n
                  })
                ]
              }),
              s ? l.jsx("p", {
                className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line",
                children: s
              }) : l.jsxs("div", {
                className: "grid grid-cols-[1fr_auto_auto] items-center gap-x-3 gap-y-1.5",
                children: [
                  l.jsx("span", {}),
                  l.jsx("span", {
                    className: "text-xs font-semibold text-slate-400 dark:text-slate-500",
                    children: "Unlicensed"
                  }),
                  l.jsx("span", {
                    className: "text-xs font-semibold text-emerald-600 dark:text-emerald-400",
                    children: "Licensed"
                  }),
                  rx.map((a, o) => l.jsxs(u.Fragment, {
                    children: [
                      l.jsx("span", {
                        className: "text-xs text-slate-700 dark:text-slate-300",
                        children: a.label
                      }),
                      l.jsx("span", {
                        className: "justify-self-center",
                        children: l.jsx(ao, {
                          type: a.unlicensed
                        })
                      }),
                      l.jsx("span", {
                        className: "justify-self-center",
                        children: l.jsx(ao, {
                          type: a.licensed
                        })
                      })
                    ]
                  }, o))
                ]
              }),
              l.jsxs("a", {
                href: uc(r),
                target: "_blank",
                rel: "noopener noreferrer",
                onClick: t,
                className: "inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-700 dark:bg-slate-600 rounded-lg hover:bg-slate-800 dark:hover:bg-slate-500 w-full justify-center",
                children: [
                  l.jsx(Kt, {
                    className: "w-3.5 h-3.5"
                  }),
                  "Buy a license"
                ]
              }),
              !s && l.jsx("a", {
                href: "#/login",
                onClick: t,
                className: "block w-full text-center text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200",
                children: "I have a license"
              }),
              l.jsx("button", {
                onClick: t,
                className: "w-full text-xs text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300",
                children: "Continue unlicensed"
              })
            ]
          })
        })
      ]
    });
  }
  const ax = chrome.runtime ? chrome.runtime.getManifest() : {
    version: "N/A"
  }, ox = ax.version;
  lx = function({ children: e }) {
    const [t, n] = ee(), { resolvedTheme: r } = $i(), [s, a] = u.useState(false), [o, i] = u.useState(null), [c, d] = u.useState(null), f = qe();
    u.useEffect(() => {
      (async () => {
        var _a3;
        const { licenseKey: m, me: p } = t.auth;
        if (m) {
          const x = (_a3 = p == null ? void 0 : p.licenseKey) == null ? void 0 : _a3.lastValidatedAt, b = Date.now() - 60 * 60 * 1e3;
          if (!x || new Date(x).getTime() < b)
            try {
              await n.validateCurrentLicense();
            } catch {
            }
        }
      })();
    }, []), u.useEffect(() => {
      (async () => {
        if (await Fr("page_view"), n.isLicensed())
          return;
        const m = await Ui();
        if (m) {
          await Vi(m), d(m), i(`milestone-${m}`), a(true);
          return;
        }
        await Wi("community") && (i("auto"), a(true));
      })();
    }, [
      f.pathname
    ]), u.useEffect(() => {
      const g = (m) => {
        var _a3;
        i(((_a3 = m.detail) == null ? void 0 : _a3.source) || null), a(true);
      };
      return window.addEventListener(ta, g), () => window.removeEventListener(ta, g);
    }, []);
    const h = async () => {
      await zi(), a(false), d(null);
    };
    return l.jsxs("div", {
      className: "flex flex-col h-full bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200",
      children: [
        l.jsx("header", {
          className: "bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 overflow-hidden shadow-sm dark:shadow-slate-900/30",
          children: l.jsx("div", {
            className: "px-3 py-2",
            children: l.jsxs("div", {
              className: "flex items-center justify-between",
              children: [
                l.jsxs("div", {
                  className: "flex items-center space-x-2",
                  children: [
                    l.jsx("img", {
                      src: chrome.runtime.getURL("img/logo-196.png"),
                      className: "w-8 h-8",
                      alt: na
                    }),
                    l.jsxs("div", {
                      children: [
                        l.jsx("h1", {
                          className: "text-sm font-bold tracking-tight text-slate-900 dark:text-slate-100",
                          children: na
                        }),
                        l.jsxs("div", {
                          className: "flex items-center gap-1.5",
                          children: [
                            l.jsxs("p", {
                              className: "text-[10px] text-slate-600 dark:text-slate-400 font-light",
                              children: [
                                "v",
                                ox ?? "1.0.0"
                              ]
                            }),
                            l.jsx("span", {
                              className: "text-[10px] text-slate-400 dark:text-slate-500",
                              children: "\u2022"
                            }),
                            l.jsx("a", {
                              href: ra,
                              target: "_blank",
                              rel: "noopener noreferrer",
                              className: "text-[10px] text-slate-900 dark:text-slate-100 hover:text-slate-800 dark:hover:text-slate-200",
                              children: l.jsx("span", {
                                className: "font-semibold bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full",
                                children: sa
                              })
                            }),
                            l.jsx("span", {
                              className: "text-[10px] text-slate-400 dark:text-slate-500",
                              children: "\u2022"
                            }),
                            l.jsx("a", {
                              href: aa,
                              target: "_blank",
                              rel: "noopener noreferrer",
                              className: "text-[10px] text-slate-900 dark:text-slate-100 hover:text-slate-800 dark:hover:text-slate-200",
                              children: l.jsx("span", {
                                className: "font-semibold bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full",
                                children: "Feedback"
                              })
                            })
                          ]
                        })
                      ]
                    })
                  ]
                }),
                l.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    l.jsx(nx, {}),
                    l.jsxs("a", {
                      href: "https://x.com/_trungpv",
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className: "text-xs text-slate-900 dark:text-slate-100 hover:text-slate-800 dark:hover:text-slate-200 flex items-center space-x-1",
                      children: [
                        l.jsx("span", {
                          children: "By"
                        }),
                        l.jsx("span", {
                          className: "font-semibold bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full",
                          children: "_trungpv"
                        })
                      ]
                    })
                  ]
                })
              ]
            })
          })
        }),
        l.jsx(Jg, {}),
        l.jsx(Zg, {}),
        l.jsx("main", {
          className: "flex-grow px-3 py-3 overflow-y-auto",
          children: e
        }),
        l.jsxs("footer", {
          className: "px-3 py-2 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 flex items-center justify-center gap-2",
          children: [
            l.jsx("a", {
              href: ra,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-slate-500 dark:text-slate-400",
              children: l.jsx("span", {
                className: "font-semibold bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full",
                children: sa
              })
            }),
            l.jsx("span", {
              className: "text-slate-400 dark:text-slate-500",
              children: "\u2022"
            }),
            l.jsx("a", {
              href: aa,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-slate-500 dark:text-slate-400",
              children: l.jsx("span", {
                className: "font-semibold bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full",
                children: "Feedback"
              })
            }),
            l.jsx("span", {
              className: "text-slate-400 dark:text-slate-500",
              children: "\u2022"
            }),
            l.jsxs("p", {
              className: "text-slate-500 dark:text-slate-400",
              children: [
                "\xA9 ",
                (/* @__PURE__ */ new Date()).getFullYear(),
                " "
              ]
            }),
            l.jsxs("a", {
              href: "https://x.com/_trungpv",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-slate-500 dark:text-slate-400 flex items-center space-x-1",
              children: [
                l.jsx("span", {
                  children: "By"
                }),
                l.jsx("span", {
                  className: "font-semibold bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full",
                  children: "_trungpv"
                })
              ]
            })
          ]
        }),
        l.jsx(sx, {
          isOpen: s,
          onClose: () => h(),
          source: o,
          ...c ? {
            title: _i,
            note: Bi(c)
          } : {}
        }),
        l.jsx(Hi, {
          theme: r
        })
      ]
    });
  };
  var ix = typeof Element < "u", cx = typeof Map == "function", ux = typeof Set == "function", dx = typeof ArrayBuffer == "function" && !!ArrayBuffer.isView;
  function Tn(e, t) {
    if (e === t)
      return true;
    if (e && t && typeof e == "object" && typeof t == "object") {
      if (e.constructor !== t.constructor)
        return false;
      var n, r, s;
      if (Array.isArray(e)) {
        if (n = e.length, n != t.length)
          return false;
        for (r = n; r-- !== 0; )
          if (!Tn(e[r], t[r]))
            return false;
        return true;
      }
      var a;
      if (cx && e instanceof Map && t instanceof Map) {
        if (e.size !== t.size)
          return false;
        for (a = e.entries(); !(r = a.next()).done; )
          if (!t.has(r.value[0]))
            return false;
        for (a = e.entries(); !(r = a.next()).done; )
          if (!Tn(r.value[1], t.get(r.value[0])))
            return false;
        return true;
      }
      if (ux && e instanceof Set && t instanceof Set) {
        if (e.size !== t.size)
          return false;
        for (a = e.entries(); !(r = a.next()).done; )
          if (!t.has(r.value[0]))
            return false;
        return true;
      }
      if (dx && ArrayBuffer.isView(e) && ArrayBuffer.isView(t)) {
        if (n = e.length, n != t.length)
          return false;
        for (r = n; r-- !== 0; )
          if (e[r] !== t[r])
            return false;
        return true;
      }
      if (e.constructor === RegExp)
        return e.source === t.source && e.flags === t.flags;
      if (e.valueOf !== Object.prototype.valueOf && typeof e.valueOf == "function" && typeof t.valueOf == "function")
        return e.valueOf() === t.valueOf();
      if (e.toString !== Object.prototype.toString && typeof e.toString == "function" && typeof t.toString == "function")
        return e.toString() === t.toString();
      if (s = Object.keys(e), n = s.length, n !== Object.keys(t).length)
        return false;
      for (r = n; r-- !== 0; )
        if (!Object.prototype.hasOwnProperty.call(t, s[r]))
          return false;
      if (ix && e instanceof Element)
        return false;
      for (r = n; r-- !== 0; )
        if (!((s[r] === "_owner" || s[r] === "__v" || s[r] === "__o") && e.$$typeof) && !Tn(e[s[r]], t[s[r]]))
          return false;
      return true;
    }
    return e !== e && t !== t;
  }
  var fx = function(t, n) {
    try {
      return Tn(t, n);
    } catch (r) {
      if ((r.message || "").match(/stack|recursion/i))
        return console.warn("react-fast-compare cannot handle circular refs"), false;
      throw r;
    }
  };
  const hx = cs(fx);
  var px = function(e, t, n, r, s, a, o, i) {
    if (!e) {
      var c;
      if (t === void 0)
        c = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
      else {
        var d = [
          n,
          r,
          s,
          a,
          o,
          i
        ], f = 0;
        c = new Error(t.replace(/%s/g, function() {
          return d[f++];
        })), c.name = "Invariant Violation";
      }
      throw c.framesToPop = 1, c;
    }
  }, mx = px;
  const oo = cs(mx);
  var gx = function(t, n, r, s) {
    var a = r ? r.call(s, t, n) : void 0;
    if (a !== void 0)
      return !!a;
    if (t === n)
      return true;
    if (typeof t != "object" || !t || typeof n != "object" || !n)
      return false;
    var o = Object.keys(t), i = Object.keys(n);
    if (o.length !== i.length)
      return false;
    for (var c = Object.prototype.hasOwnProperty.bind(n), d = 0; d < o.length; d++) {
      var f = o[d];
      if (!c(f))
        return false;
      var h = t[f], g = n[f];
      if (a = r ? r.call(s, h, g, f) : void 0, a === false || a === void 0 && h !== g)
        return false;
    }
    return true;
  };
  const xx = cs(gx);
  let Ri, Or, lo, Zs, bx, Te, Tt, $t, vx, yx, Lr, wx, kx, Bt, Ex, jx, Ai, Nx, Ir, io, Cx, ss, Pi, Sx, Tx, Oi, $x, $n, Ne, Rx, Ax, as, Nn, Li, os, Px, Ii, Et, ls, Lx, co, Ht, Ix, Fx, uo;
  Ri = ((e) => (e.BASE = "base", e.BODY = "body", e.HEAD = "head", e.HTML = "html", e.LINK = "link", e.META = "meta", e.NOSCRIPT = "noscript", e.SCRIPT = "script", e.STYLE = "style", e.TITLE = "title", e.FRAGMENT = "Symbol(react.fragment)", e))(Ri || {});
  Or = {
    link: {
      rel: [
        "amphtml",
        "canonical",
        "alternate"
      ]
    },
    script: {
      type: [
        "application/ld+json"
      ]
    },
    meta: {
      charset: "",
      name: [
        "generator",
        "robots",
        "description"
      ],
      property: [
        "og:type",
        "og:title",
        "og:url",
        "og:image",
        "og:image:alt",
        "og:description",
        "twitter:url",
        "twitter:title",
        "twitter:description",
        "twitter:image",
        "twitter:image:alt",
        "twitter:card",
        "twitter:site"
      ]
    }
  };
  lo = Object.values(Ri);
  Zs = {
    accesskey: "accessKey",
    charset: "charSet",
    class: "className",
    contenteditable: "contentEditable",
    contextmenu: "contextMenu",
    "http-equiv": "httpEquiv",
    itemprop: "itemProp",
    tabindex: "tabIndex"
  };
  bx = Object.entries(Zs).reduce((e, [t, n]) => (e[n] = t, e), {});
  Te = "data-rh";
  Tt = {
    DEFAULT_TITLE: "defaultTitle",
    DEFER: "defer",
    ENCODE_SPECIAL_CHARACTERS: "encodeSpecialCharacters",
    ON_CHANGE_CLIENT_STATE: "onChangeClientState",
    TITLE_TEMPLATE: "titleTemplate",
    PRIORITIZE_SEO_TAGS: "prioritizeSeoTags"
  };
  $t = (e, t) => {
    for (let n = e.length - 1; n >= 0; n -= 1) {
      const r = e[n];
      if (Object.prototype.hasOwnProperty.call(r, t))
        return r[t];
    }
    return null;
  };
  vx = (e) => {
    let t = $t(e, "title");
    const n = $t(e, Tt.TITLE_TEMPLATE);
    if (Array.isArray(t) && (t = t.join("")), n && t)
      return n.replace(/%s/g, () => t);
    const r = $t(e, Tt.DEFAULT_TITLE);
    return t || r || void 0;
  };
  yx = (e) => $t(e, Tt.ON_CHANGE_CLIENT_STATE) || (() => {
  });
  Lr = (e, t) => t.filter((n) => typeof n[e] < "u").map((n) => n[e]).reduce((n, r) => ({
    ...n,
    ...r
  }), {});
  wx = (e, t) => t.filter((n) => typeof n.base < "u").map((n) => n.base).reverse().reduce((n, r) => {
    if (!n.length) {
      const s = Object.keys(r);
      for (let a = 0; a < s.length; a += 1) {
        const i = s[a].toLowerCase();
        if (e.indexOf(i) !== -1 && r[i])
          return n.concat(r);
      }
    }
    return n;
  }, []);
  kx = (e) => console && typeof console.warn == "function" && console.warn(e);
  Bt = (e, t, n) => {
    const r = {};
    return n.filter((s) => Array.isArray(s[e]) ? true : (typeof s[e] < "u" && kx(`Helmet: ${e} should be of type "Array". Instead found type "${typeof s[e]}"`), false)).map((s) => s[e]).reverse().reduce((s, a) => {
      const o = {};
      a.filter((c) => {
        let d;
        const f = Object.keys(c);
        for (let g = 0; g < f.length; g += 1) {
          const m = f[g], p = m.toLowerCase();
          t.indexOf(p) !== -1 && !(d === "rel" && c[d].toLowerCase() === "canonical") && !(p === "rel" && c[p].toLowerCase() === "stylesheet") && (d = p), t.indexOf(m) !== -1 && (m === "innerHTML" || m === "cssText" || m === "itemprop") && (d = m);
        }
        if (!d || !c[d])
          return false;
        const h = c[d].toLowerCase();
        return r[d] || (r[d] = {}), o[d] || (o[d] = {}), r[d][h] ? false : (o[d][h] = true, true);
      }).reverse().forEach((c) => s.push(c));
      const i = Object.keys(o);
      for (let c = 0; c < i.length; c += 1) {
        const d = i[c], f = {
          ...r[d],
          ...o[d]
        };
        r[d] = f;
      }
      return s;
    }, []).reverse();
  };
  Ex = (e, t) => {
    if (Array.isArray(e) && e.length) {
      for (let n = 0; n < e.length; n += 1)
        if (e[n][t])
          return true;
    }
    return false;
  };
  jx = (e) => ({
    baseTag: wx([
      "href"
    ], e),
    bodyAttributes: Lr("bodyAttributes", e),
    defer: $t(e, Tt.DEFER),
    encode: $t(e, Tt.ENCODE_SPECIAL_CHARACTERS),
    htmlAttributes: Lr("htmlAttributes", e),
    linkTags: Bt("link", [
      "rel",
      "href"
    ], e),
    metaTags: Bt("meta", [
      "name",
      "charset",
      "http-equiv",
      "property",
      "itemprop"
    ], e),
    noscriptTags: Bt("noscript", [
      "innerHTML"
    ], e),
    onChangeClientState: yx(e),
    scriptTags: Bt("script", [
      "src",
      "innerHTML"
    ], e),
    styleTags: Bt("style", [
      "cssText"
    ], e),
    title: vx(e),
    titleAttributes: Lr("titleAttributes", e),
    prioritizeSeoTags: Ex(e, Tt.PRIORITIZE_SEO_TAGS)
  });
  Ai = (e) => Array.isArray(e) ? e.join("") : e;
  Nx = (e, t) => {
    const n = Object.keys(e);
    for (let r = 0; r < n.length; r += 1)
      if (t[n[r]] && t[n[r]].includes(e[n[r]]))
        return true;
    return false;
  };
  Ir = (e, t) => Array.isArray(e) ? e.reduce((n, r) => (Nx(r, t) ? n.priority.push(r) : n.default.push(r), n), {
    priority: [],
    default: []
  }) : {
    default: e,
    priority: []
  };
  io = (e, t) => ({
    ...e,
    [t]: void 0
  });
  Cx = [
    "noscript",
    "script",
    "style"
  ];
  ss = (e, t = true) => t === false ? String(e) : String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
  Pi = (e) => Object.keys(e).reduce((t, n) => {
    const r = typeof e[n] < "u" ? `${n}="${e[n]}"` : `${n}`;
    return t ? `${t} ${r}` : r;
  }, "");
  Sx = (e, t, n, r) => {
    const s = Pi(n), a = Ai(t);
    return s ? `<${e} ${Te}="true" ${s}>${ss(a, r)}</${e}>` : `<${e} ${Te}="true">${ss(a, r)}</${e}>`;
  };
  Tx = (e, t, n = true) => t.reduce((r, s) => {
    const a = s, o = Object.keys(a).filter((d) => !(d === "innerHTML" || d === "cssText")).reduce((d, f) => {
      const h = typeof a[f] > "u" ? f : `${f}="${ss(a[f], n)}"`;
      return d ? `${d} ${h}` : h;
    }, ""), i = a.innerHTML || a.cssText || "", c = Cx.indexOf(e) === -1;
    return `${r}<${e} ${Te}="true" ${o}${c ? "/>" : `>${i}</${e}>`}`;
  }, "");
  Oi = (e, t = {}) => Object.keys(e).reduce((n, r) => {
    const s = Zs[r];
    return n[s || r] = e[r], n;
  }, t);
  $x = (e, t, n) => {
    const r = {
      key: t,
      [Te]: true
    }, s = Oi(n, r);
    return [
      j.createElement("title", s, t)
    ];
  };
  $n = (e, t) => t.map((n, r) => {
    const s = {
      key: r,
      [Te]: true
    };
    return Object.keys(n).forEach((a) => {
      const i = Zs[a] || a;
      if (i === "innerHTML" || i === "cssText") {
        const c = n.innerHTML || n.cssText;
        s.dangerouslySetInnerHTML = {
          __html: c
        };
      } else
        s[i] = n[a];
    }), j.createElement(e, s);
  });
  Ne = (e, t, n = true) => {
    switch (e) {
      case "title":
        return {
          toComponent: () => $x(e, t.title, t.titleAttributes),
          toString: () => Sx(e, t.title, t.titleAttributes, n)
        };
      case "bodyAttributes":
      case "htmlAttributes":
        return {
          toComponent: () => Oi(t),
          toString: () => Pi(t)
        };
      default:
        return {
          toComponent: () => $n(e, t),
          toString: () => Tx(e, t, n)
        };
    }
  };
  Rx = ({ metaTags: e, linkTags: t, scriptTags: n, encode: r }) => {
    const s = Ir(e, Or.meta), a = Ir(t, Or.link), o = Ir(n, Or.script);
    return {
      priorityMethods: {
        toComponent: () => [
          ...$n("meta", s.priority),
          ...$n("link", a.priority),
          ...$n("script", o.priority)
        ],
        toString: () => `${Ne("meta", s.priority, r)} ${Ne("link", a.priority, r)} ${Ne("script", o.priority, r)}`
      },
      metaTags: s.default,
      linkTags: a.default,
      scriptTags: o.default
    };
  };
  Ax = (e) => {
    const { baseTag: t, bodyAttributes: n, encode: r = true, htmlAttributes: s, noscriptTags: a, styleTags: o, title: i = "", titleAttributes: c, prioritizeSeoTags: d } = e;
    let { linkTags: f, metaTags: h, scriptTags: g } = e, m = {
      toComponent: () => {
      },
      toString: () => ""
    };
    return d && ({ priorityMethods: m, linkTags: f, metaTags: h, scriptTags: g } = Rx(e)), {
      priority: m,
      base: Ne("base", t, r),
      bodyAttributes: Ne("bodyAttributes", n, r),
      htmlAttributes: Ne("htmlAttributes", s, r),
      link: Ne("link", f, r),
      meta: Ne("meta", h, r),
      noscript: Ne("noscript", a, r),
      script: Ne("script", g, r),
      style: Ne("style", o, r),
      title: Ne("title", {
        title: i,
        titleAttributes: c
      }, r)
    };
  };
  as = Ax;
  Nn = [];
  Li = !!(typeof window < "u" && window.document && window.document.createElement);
  os = class {
    constructor(e, t) {
      __publicField(this, "instances", []);
      __publicField(this, "canUseDOM", Li);
      __publicField(this, "context");
      __publicField(this, "value", {
        setHelmet: (e) => {
          this.context.helmet = e;
        },
        helmetInstances: {
          get: () => this.canUseDOM ? Nn : this.instances,
          add: (e) => {
            (this.canUseDOM ? Nn : this.instances).push(e);
          },
          remove: (e) => {
            const t = (this.canUseDOM ? Nn : this.instances).indexOf(e);
            (this.canUseDOM ? Nn : this.instances).splice(t, 1);
          }
        }
      });
      this.context = e, this.canUseDOM = t || false, t || (e.helmet = as({
        baseTag: [],
        bodyAttributes: {},
        encodeSpecialCharacters: true,
        htmlAttributes: {},
        linkTags: [],
        metaTags: [],
        noscriptTags: [],
        scriptTags: [],
        styleTags: [],
        title: "",
        titleAttributes: {}
      }));
    }
  };
  Px = {};
  Ii = j.createContext(Px);
  Ox = (_a2 = class extends u.Component {
    constructor(t) {
      super(t);
      __publicField(this, "helmetData");
      this.helmetData = new os(this.props.context || {}, _a2.canUseDOM);
    }
    render() {
      return j.createElement(Ii.Provider, {
        value: this.helmetData.value
      }, this.props.children);
    }
  }, __publicField(_a2, "canUseDOM", Li), _a2);
  Et = (e, t) => {
    const n = document.head || document.querySelector("head"), r = n.querySelectorAll(`${e}[${Te}]`), s = [].slice.call(r), a = [];
    let o;
    return t && t.length && t.forEach((i) => {
      const c = document.createElement(e);
      for (const d in i)
        if (Object.prototype.hasOwnProperty.call(i, d))
          if (d === "innerHTML")
            c.innerHTML = i.innerHTML;
          else if (d === "cssText")
            c.styleSheet ? c.styleSheet.cssText = i.cssText : c.appendChild(document.createTextNode(i.cssText));
          else {
            const f = d, h = typeof i[f] > "u" ? "" : i[f];
            c.setAttribute(d, h);
          }
      c.setAttribute(Te, "true"), s.some((d, f) => (o = f, c.isEqualNode(d))) ? s.splice(o, 1) : a.push(c);
    }), s.forEach((i) => {
      var _a3;
      return (_a3 = i.parentNode) == null ? void 0 : _a3.removeChild(i);
    }), a.forEach((i) => n.appendChild(i)), {
      oldTags: s,
      newTags: a
    };
  };
  ls = (e, t) => {
    const n = document.getElementsByTagName(e)[0];
    if (!n)
      return;
    const r = n.getAttribute(Te), s = r ? r.split(",") : [], a = [
      ...s
    ], o = Object.keys(t);
    for (const i of o) {
      const c = t[i] || "";
      n.getAttribute(i) !== c && n.setAttribute(i, c), s.indexOf(i) === -1 && s.push(i);
      const d = a.indexOf(i);
      d !== -1 && a.splice(d, 1);
    }
    for (let i = a.length - 1; i >= 0; i -= 1)
      n.removeAttribute(a[i]);
    s.length === a.length ? n.removeAttribute(Te) : n.getAttribute(Te) !== o.join(",") && n.setAttribute(Te, o.join(","));
  };
  Lx = (e, t) => {
    typeof e < "u" && document.title !== e && (document.title = Ai(e)), ls("title", t);
  };
  co = (e, t) => {
    const { baseTag: n, bodyAttributes: r, htmlAttributes: s, linkTags: a, metaTags: o, noscriptTags: i, onChangeClientState: c, scriptTags: d, styleTags: f, title: h, titleAttributes: g } = e;
    ls("body", r), ls("html", s), Lx(h, g);
    const m = {
      baseTag: Et("base", n),
      linkTags: Et("link", a),
      metaTags: Et("meta", o),
      noscriptTags: Et("noscript", i),
      scriptTags: Et("script", d),
      styleTags: Et("style", f)
    }, p = {}, x = {};
    Object.keys(m).forEach((b) => {
      const { newTags: y, oldTags: v } = m[b];
      y.length && (p[b] = y), v.length && (x[b] = m[b].oldTags);
    }), t && t(), c(e, p, x);
  };
  Ht = null;
  Ix = (e) => {
    Ht && cancelAnimationFrame(Ht), e.defer ? Ht = requestAnimationFrame(() => {
      co(e, () => {
        Ht = null;
      });
    }) : (co(e), Ht = null);
  };
  Fx = Ix;
  uo = class extends u.Component {
    constructor() {
      super(...arguments);
      __publicField(this, "rendered", false);
    }
    shouldComponentUpdate(e) {
      return !xx(e, this.props);
    }
    componentDidUpdate() {
      this.emitChange();
    }
    componentWillUnmount() {
      const { helmetInstances: e } = this.props.context;
      e.remove(this), this.emitChange();
    }
    emitChange() {
      const { helmetInstances: e, setHelmet: t } = this.props.context;
      let n = null;
      const r = jx(e.get().map((s) => {
        const a = {
          ...s.props
        };
        return delete a.context, a;
      }));
      Ox.canUseDOM ? Fx(r) : as && (n = as(r)), t(n);
    }
    init() {
      if (this.rendered)
        return;
      this.rendered = true;
      const { helmetInstances: e } = this.props.context;
      e.add(this), this.emitChange();
    }
    render() {
      return this.init(), null;
    }
  };
  Mx = (_b2 = class extends u.Component {
    shouldComponentUpdate(e) {
      return !hx(io(this.props, "helmetData"), io(e, "helmetData"));
    }
    mapNestedChildrenToProps(e, t) {
      if (!t)
        return null;
      switch (e.type) {
        case "script":
        case "noscript":
          return {
            innerHTML: t
          };
        case "style":
          return {
            cssText: t
          };
        default:
          throw new Error(`<${e.type} /> elements are self-closing and can not contain children. Refer to our API for more information.`);
      }
    }
    flattenArrayTypeChildren(e, t, n, r) {
      return {
        ...t,
        [e.type]: [
          ...t[e.type] || [],
          {
            ...n,
            ...this.mapNestedChildrenToProps(e, r)
          }
        ]
      };
    }
    mapObjectTypeChildren(e, t, n, r) {
      switch (e.type) {
        case "title":
          return {
            ...t,
            [e.type]: r,
            titleAttributes: {
              ...n
            }
          };
        case "body":
          return {
            ...t,
            bodyAttributes: {
              ...n
            }
          };
        case "html":
          return {
            ...t,
            htmlAttributes: {
              ...n
            }
          };
        default:
          return {
            ...t,
            [e.type]: {
              ...n
            }
          };
      }
    }
    mapArrayTypeChildrenToProps(e, t) {
      let n = {
        ...t
      };
      return Object.keys(e).forEach((r) => {
        n = {
          ...n,
          [r]: e[r]
        };
      }), n;
    }
    warnOnInvalidChildren(e, t) {
      return oo(lo.some((n) => e.type === n), typeof e.type == "function" ? "You may be attempting to nest <Helmet> components within each other, which is not allowed. Refer to our API for more information." : `Only elements types ${lo.join(", ")} are allowed. Helmet does not support rendering <${e.type}> elements. Refer to our API for more information.`), oo(!t || typeof t == "string" || Array.isArray(t) && !t.some((n) => typeof n != "string"), `Helmet expects a string as a child of <${e.type}>. Did you forget to wrap your children in braces? ( <${e.type}>{\`\`}</${e.type}> ) Refer to our API for more information.`), true;
    }
    mapChildrenToProps(e, t) {
      let n = {};
      return j.Children.forEach(e, (r) => {
        if (!r || !r.props)
          return;
        const { children: s, ...a } = r.props, o = Object.keys(a).reduce((c, d) => (c[bx[d] || d] = a[d], c), {});
        let { type: i } = r;
        switch (typeof i == "symbol" ? i = i.toString() : this.warnOnInvalidChildren(r, s), i) {
          case "Symbol(react.fragment)":
            t = this.mapChildrenToProps(s, t);
            break;
          case "link":
          case "meta":
          case "noscript":
          case "script":
          case "style":
            n = this.flattenArrayTypeChildren(r, n, o, s);
            break;
          default:
            t = this.mapObjectTypeChildren(r, t, o, s);
            break;
        }
      }), this.mapArrayTypeChildrenToProps(n, t);
    }
    render() {
      const { children: e, ...t } = this.props;
      let n = {
        ...t
      }, { helmetData: r } = t;
      if (e && (n = this.mapChildrenToProps(e, n)), r && !(r instanceof os)) {
        const s = r;
        r = new os(s.context, true), delete n.helmetData;
      }
      return r ? j.createElement(uo, {
        ...n,
        context: r.value
      }) : j.createElement(Ii.Consumer, null, (s) => j.createElement(uo, {
        ...n,
        context: s
      }));
    }
  }, __publicField(_b2, "defaultProps", {
    defer: true,
    encodeSpecialCharacters: true,
    prioritizeSeoTags: false
  }), _b2);
  let fo, Dx, Bx;
  fo = {
    sm: "w-5 h-5 text-[10px]",
    md: "w-6 h-6 text-xs",
    lg: "w-8 h-8 text-sm"
  };
  Dx = ({ email: e, size: t = "md", isActive: n = false }) => {
    const r = Gi(e), s = Zi(e), a = fo[t] || fo.md;
    return l.jsx("div", {
      className: `${a} ${r} rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0 ${n ? "ring-2 ring-offset-1 ring-blue-400" : ""}`,
      title: e,
      children: s
    });
  };
  _x = () => {
    const [e, t] = ee(), { authNotebookLM: n, languageSettings: r } = e, [s, a] = u.useState(false), [o, i] = u.useState(false), [c, d] = u.useState(false), [f, h] = u.useState(false), g = qi((r == null ? void 0 : r.interfaceLanguage) || "en"), m = xo(e), p = t.getAccountList();
    u.useEffect(() => {
      !o && t.isNotebookLMAuthenticated() && (x(), i(true));
    }, [
      o,
      t
    ]), u.useEffect(() => {
      const E = (N, C) => {
        C === "local" && N[dc] && t.syncAuthFromStorage();
      };
      return chrome.storage.onChanged.addListener(E), () => chrome.storage.onChanged.removeListener(E);
    }, []);
    const x = async () => {
      try {
        await t.fetchNotebookLMProjects();
      } catch (E) {
        console.error("Failed to load projects:", E);
      }
    }, b = async () => {
      a(true);
      try {
        await t.syncAuthFromStorage(), await t.fetchNotebookLMProjects(), ge.success("Projects refreshed");
      } catch {
        ge.error("Failed to refresh projects");
      } finally {
        a(false);
      }
    }, y = async () => {
      window.confirm("Disconnect from NotebookLM? This will reset all app data.") && (await t.disconnectNotebookLM(), await br(t), ge.success("Disconnected from NotebookLM"));
    }, v = async (E) => {
      if (!f) {
        h(true);
        try {
          await t.switchActiveAccount(E), await br(t), i(false), d(false), ge.success(`Switched to ${Mt(E)}`);
        } catch {
          ge.error("Failed to switch account");
        } finally {
          h(false);
        }
      }
    }, w = async (E) => {
      var _a3;
      if (window.confirm(`Disconnect ${Mt(E)}?`))
        try {
          const N = (_a3 = p.find((C) => C.email === E)) == null ? void 0 : _a3.isActive;
          await t.disconnectAccount(E), N && (await br(t), i(false)), ge.success(`Disconnected ${Mt(E)}`);
        } catch {
          ge.error("Failed to disconnect account");
        }
    }, k = () => {
      chrome.tabs.create({
        url: "https://notebooklm.google.com/"
      }), ge.success("Sign in with another Google account on the opened tab");
    };
    return l.jsxs("div", {
      className: "bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg p-3",
      children: [
        l.jsxs("div", {
          className: "flex items-start gap-2.5",
          children: [
            l.jsx("div", {
              className: "flex-shrink-0 w-8 h-8 bg-black rounded-lg flex items-center justify-center shadow-sm dark:shadow-slate-900/30",
              children: l.jsx(Ti, {
                className: "w-5 h-5 text-white"
              })
            }),
            l.jsxs("div", {
              className: "min-w-0 flex-1",
              children: [
                l.jsxs("div", {
                  className: "flex items-center gap-1.5 mb-0.5",
                  children: [
                    l.jsx("span", {
                      className: "text-xs font-semibold text-gray-900 dark:text-slate-100",
                      children: "NotebookLM"
                    }),
                    l.jsxs("div", {
                      className: "flex items-center gap-1 px-1.5 py-0.5 bg-green-50 dark:bg-green-950 rounded",
                      children: [
                        l.jsx("div", {
                          className: "w-1 h-1 bg-green-500 rounded-full"
                        }),
                        l.jsx("span", {
                          className: "text-xs font-medium text-green-700 dark:text-green-300",
                          children: "Connected"
                        })
                      ]
                    })
                  ]
                }),
                l.jsxs("div", {
                  className: "flex items-center gap-1.5",
                  children: [
                    l.jsx("div", {
                      className: "text-xs text-gray-500 dark:text-slate-400 truncate",
                      children: Mt(m == null ? void 0 : m.email)
                    }),
                    g && g.code !== "en" && l.jsxs("span", {
                      className: "text-xs text-gray-400 dark:text-slate-500",
                      children: [
                        "\u2022 ",
                        g.code.toUpperCase()
                      ]
                    })
                  ]
                })
              ]
            }),
            l.jsxs("div", {
              className: "flex items-center gap-0.5 -mt-0.5",
              children: [
                l.jsx("button", {
                  onClick: b,
                  disabled: s,
                  className: "p-1.5 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 rounded disabled:opacity-40 disabled:cursor-not-allowed",
                  title: "Refresh projects",
                  children: l.jsx(rt, {
                    className: `w-3.5 h-3.5 ${s ? "animate-spin" : ""}`
                  })
                }),
                l.jsx("button", {
                  onClick: y,
                  className: "p-1.5 text-gray-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 rounded",
                  title: "Disconnect",
                  children: l.jsx(yc, {
                    className: "w-3.5 h-3.5"
                  })
                })
              ]
            })
          ]
        }),
        l.jsxs("div", {
          className: "flex items-center gap-1.5 justify-between mt-2",
          children: [
            l.jsxs("button", {
              onClick: k,
              title: "Open NotebookLM to sign in with another Google account",
              className: "flex items-center gap-1 px-1.5 py-0.5 text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-700 rounded",
              children: [
                l.jsx(an, {
                  className: "w-3 h-3"
                }),
                l.jsx("span", {
                  children: "Add account"
                })
              ]
            }),
            p.length > 0 && l.jsxs("button", {
              onClick: () => d(!c),
              className: `flex items-center gap-1 px-1.5 py-0.5 text-xs rounded ${c ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-700"}`,
              children: [
                l.jsx(Cc, {
                  className: "w-3 h-3"
                }),
                l.jsxs("span", {
                  children: [
                    "Accounts (",
                    p.length,
                    ")"
                  ]
                })
              ]
            })
          ]
        }),
        c && l.jsx("div", {
          className: "mt-2 pt-2 border-t border-gray-100 dark:border-slate-700",
          children: l.jsx("div", {
            className: "space-y-1",
            children: p.map((E) => l.jsxs("div", {
              className: `flex items-center justify-between px-2 py-1.5 rounded text-xs ${E.isActive ? "bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300" : "text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
              children: [
                l.jsxs("div", {
                  className: "flex items-center gap-1.5 min-w-0 flex-1",
                  children: [
                    l.jsx(Dx, {
                      email: E.email,
                      size: "sm",
                      isActive: E.isActive
                    }),
                    l.jsx("span", {
                      className: "truncate",
                      children: Mt(E.email)
                    }),
                    E.isActive && l.jsx("span", {
                      className: "text-xs font-medium text-blue-500 dark:text-blue-400 flex-shrink-0",
                      children: "Active"
                    })
                  ]
                }),
                l.jsxs("div", {
                  className: "flex items-center gap-0.5 flex-shrink-0",
                  children: [
                    !E.isActive && l.jsx("button", {
                      onClick: () => v(E.email),
                      disabled: f,
                      className: "px-1.5 py-0.5 text-xs text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950 rounded disabled:opacity-40",
                      children: "Switch"
                    }),
                    !E.isActive && l.jsx("button", {
                      onClick: () => w(E.email),
                      className: "p-0.5 text-gray-400 hover:text-red-500 rounded",
                      title: "Disconnect account",
                      children: l.jsx(sn, {
                        className: "w-3 h-3"
                      })
                    })
                  ]
                })
              ]
            }, E.email))
          })
        }),
        l.jsxs("div", {
          className: "flex gap-1.5 mt-2 p-2 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded text-xs text-blue-700 dark:text-blue-300",
          children: [
            l.jsx(su, {
              className: "w-3.5 h-3.5 flex-shrink-0 mt-0.5"
            }),
            l.jsx("span", {
              children: "To add an account, open NotebookLM while signed into another Google account. It will be detected automatically."
            })
          ]
        })
      ]
    });
  };
  Bx = () => l.jsxs("div", {
    className: "flex items-center gap-1",
    children: [
      l.jsx("svg", {
        fill: "currentColor",
        className: "w-3 h-3 flex-shrink-0",
        viewBox: "0 0 24 24",
        xmlns: "http://www.w3.org/2000/svg",
        children: l.jsx("path", {
          d: "M11.999 3.14C5.372 3.14 0 8.588 0 15.312v5.828h2.212v-.58c0-2.728 2.178-4.938 4.866-4.938 2.688 0 4.866 2.21 4.866 4.937v.581h2.212v-.58c0-3.967-3.17-7.18-7.078-7.18a6.966 6.966 0 00-4.086 1.318C4.2 12.262 6.687 10.59 9.56 10.59c4.057 0 7.347 3.338 7.347 7.453v3.097h2.212v-3.097c0-5.355-4.28-9.698-9.56-9.698a9.438 9.438 0 00-6.217 2.332C4.984 7.528 8.244 5.383 12 5.383c5.406 0 9.788 4.446 9.788 9.93v5.827H24v-5.828C23.999 8.588 18.627 3.14 11.999 3.14z"
        })
      }),
      l.jsx("span", {
        className: "text-xs font-medium text-gray-900",
        children: "NotebookLM"
      })
    ]
  });
  Hx = () => {
    const e = () => {
      window.location.reload();
    };
    return l.jsxs("div", {
      className: "space-y-3",
      children: [
        l.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            l.jsx(Bx, {}),
            l.jsxs("button", {
              onClick: e,
              className: "flex items-center gap-1 px-2 py-1 text-xs bg-gray-50 dark:bg-slate-900 text-gray-700 dark:text-slate-300 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-700",
              title: "Refresh page",
              children: [
                l.jsx(rt, {
                  className: "w-3 h-3"
                }),
                "Refresh"
              ]
            })
          ]
        }),
        l.jsxs("div", {
          className: "text-center py-2",
          children: [
            l.jsx("p", {
              className: "text-xs text-gray-600 dark:text-slate-400 mb-3",
              children: "Connect your NotebookLM account to get started"
            }),
            l.jsxs("a", {
              href: "https://notebooklm.google.com",
              target: "_blank",
              rel: "noopener noreferrer",
              className: "inline-flex items-center gap-1 px-3 py-2 text-xs bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
              children: [
                l.jsx("svg", {
                  className: "w-3 h-3",
                  fill: "currentColor",
                  viewBox: "0 0 24 24",
                  children: l.jsx("path", {
                    d: "M11.999 3.14C5.372 3.14 0 8.588 0 15.312v5.828h2.212v-.58c0-2.728 2.178-4.938 4.866-4.938 2.688 0 4.866 2.21 4.866 4.937v.581h2.212v-.58c0-3.967-3.17-7.18-7.078-7.18a6.966 6.966 0 00-4.086 1.318C4.2 12.262 6.687 10.59 9.56 10.59c4.057 0 7.347 3.338 7.347 7.453v3.097h2.212v-3.097c0-5.355-4.28-9.698-9.56-9.698a9.438 9.438 0 00-6.217 2.332C4.984 7.528 8.244 5.383 12 5.383c5.406 0 9.788 4.446 9.788 9.93v5.827H24v-5.828C23.999 8.588 18.627 3.14 11.999 3.14z"
                  })
                }),
                "Open NotebookLM"
              ]
            })
          ]
        })
      ]
    });
  };
  Ux = function() {
    const [e, t] = ee();
    return l.jsx(l.Fragment, {
      children: t.isNotebookLMAuthenticated() ? l.jsx(_x, {}) : l.jsx("div", {
        className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
        children: l.jsx("div", {
          className: "p-3 space-y-3",
          children: l.jsx(Hx, {})
        })
      })
    });
  };
  de = ({ type: e = "info", message: t, progress: n, className: r = "" }) => {
    if (!t && e !== "progress")
      return null;
    const s = {
      error: {
        container: "bg-red-50 border-red-100 dark:bg-red-950 dark:border-red-900",
        icon: l.jsx(On, {
          className: "w-3 h-3 text-red-500 flex-shrink-0 mt-0.5"
        }),
        text: "text-red-700 dark:text-red-300"
      },
      success: {
        container: "bg-green-50 border-green-100 dark:bg-green-950 dark:border-green-900",
        icon: l.jsx(xt, {
          className: "w-3 h-3 text-green-600 flex-shrink-0 mt-0.5"
        }),
        text: "text-green-700 dark:text-green-300"
      },
      progress: {
        container: "bg-blue-50 border-blue-100 dark:bg-blue-950 dark:border-blue-900",
        icon: l.jsx(rt, {
          className: "w-3 h-3 text-blue-600 animate-spin flex-shrink-0"
        }),
        text: "text-blue-900 dark:text-blue-300"
      },
      warning: {
        container: "bg-amber-50 border-amber-100 dark:bg-amber-950 dark:border-amber-900",
        icon: l.jsx(On, {
          className: "w-3 h-3 text-amber-600 flex-shrink-0 mt-0.5"
        }),
        text: "text-amber-800 dark:text-amber-200"
      }
    }, a = s[e] || s.info;
    return l.jsx("div", {
      className: `px-2.5 py-2 rounded-md border ${a.container} ${r}`,
      children: l.jsxs("div", {
        className: "flex items-start gap-2",
        children: [
          a.icon,
          l.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              l.jsx("p", {
                className: `text-xs ${a.text}`,
                children: t
              }),
              e === "progress" && typeof n == "number" && l.jsx("div", {
                className: "w-full bg-blue-100 dark:bg-blue-900 rounded-full h-1 mt-1.5",
                children: l.jsx("div", {
                  className: "bg-blue-600 h-1 rounded-full",
                  style: {
                    width: `${n}%`
                  }
                })
              })
            ]
          })
        ]
      })
    });
  };
  vn = function() {
    const [, e] = ee(), t = e.isLicensed(), [n, r] = u.useState(false), [s, a] = u.useState(Co), [o, i] = u.useState(An.NEW), c = u.useMemo(() => n && s ? {
      selection: s,
      scope: o
    } : null, [
      n,
      s,
      o
    ]);
    return {
      alsoGenerateProps: {
        enabled: n,
        selection: s,
        onEnabledChange: r,
        onSelectionChange: a,
        licensed: t,
        scope: o,
        onScopeChange: i
      },
      generateConfig: c
    };
  };
  let Wx, Gx;
  qs = ({ projects: e = [], selectedProject: t, onSelectProject: n, query: r = "", onQueryChange: s, onClose: a, placeholder: o = "Search notebooks...", disabled: i = false }) => {
    const c = r === "" ? e : e.filter((d) => d.title.toLowerCase().includes(r.toLowerCase()));
    return l.jsx(Op, {
      value: t,
      onChange: n,
      onClose: a,
      disabled: i,
      children: l.jsxs("div", {
        className: "relative",
        children: [
          l.jsx(oi, {
            className: "w-full rounded-md border border-gray-200 bg-white px-2.5 py-2 pr-7 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-gray-900 focus:border-gray-900 disabled:bg-gray-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-100 dark:placeholder-slate-500 dark:focus:ring-slate-400 dark:focus:border-slate-400 dark:disabled:bg-slate-900",
            displayValue: (d) => (d == null ? void 0 : d.title) || "",
            onChange: (d) => s(d.target.value),
            placeholder: o
          }),
          l.jsx(ai, {
            className: "absolute inset-y-0 right-0 px-2",
            children: l.jsx(So, {
              className: "w-3 h-3 text-gray-400 dark:text-slate-500"
            })
          }),
          l.jsx(li, {
            anchor: "bottom start",
            className: "z-50 w-[var(--input-width)] rounded-md bg-white py-1 text-xs shadow-lg ring-1 ring-black ring-opacity-5 max-h-40 overflow-auto dark:bg-slate-800 dark:ring-slate-700 dark:shadow-slate-900/30",
            children: c.length === 0 ? l.jsx("div", {
              className: "px-2.5 py-2 text-gray-500 dark:text-slate-400",
              children: r !== "" ? "No notebooks found" : "No notebooks available"
            }) : c.map((d) => l.jsx(ii, {
              value: d,
              className: "flex cursor-pointer items-center justify-between gap-2 px-2.5 py-1.5 select-none data-[focus]:bg-gray-900 data-[focus]:text-white text-gray-900 dark:text-slate-100 dark:data-[focus]:bg-slate-600",
              children: ({ selected: f }) => l.jsxs(l.Fragment, {
                children: [
                  l.jsx("span", {
                    className: $e("truncate", f ? "font-medium" : "font-normal"),
                    children: d.title || "Untitled"
                  }),
                  f && l.jsx(xt, {
                    className: "w-3 h-3 flex-shrink-0"
                  })
                ]
              })
            }, d.id))
          })
        ]
      })
    });
  };
  pe = ({ onClick: e, disabled: t = false, isLoading: n = false, isSuccess: r = false, variant: s = "primary", icon: a = an, loadingText: o = "Processing...", successText: i = "Success", children: c, className: d = "" }) => {
    const f = {
      primary: {
        base: "bg-gray-900 text-white hover:bg-gray-800 dark:bg-gray-100 dark:text-gray-900 dark:hover:bg-gray-200",
        disabled: "bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-slate-700 dark:text-slate-500",
        success: "bg-green-600 text-white"
      },
      secondary: {
        base: "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 dark:hover:bg-slate-800",
        disabled: "bg-gray-100 text-gray-400 cursor-not-allowed border-gray-200 dark:bg-slate-700 dark:text-slate-500 dark:border-slate-700",
        success: "bg-green-600 text-white border-green-600"
      }
    }, h = f[s] || f.primary, g = $e("w-full flex items-center justify-center gap-2 px-3 py-2 rounded-md text-xs font-medium", r ? h.success : t || n ? h.disabled : h.base, d);
    return l.jsx("button", {
      onClick: e,
      disabled: t || n || r,
      className: g,
      children: n ? l.jsxs(l.Fragment, {
        children: [
          l.jsx(rt, {
            className: "w-3 h-3 animate-spin"
          }),
          l.jsx("span", {
            children: o
          })
        ]
      }) : r ? l.jsxs(l.Fragment, {
        children: [
          l.jsx(xt, {
            className: "w-3 h-3"
          }),
          l.jsx("span", {
            children: i
          })
        ]
      }) : l.jsxs(l.Fragment, {
        children: [
          l.jsx(a, {
            className: "w-3 h-3"
          }),
          l.jsx("span", {
            children: c
          })
        ]
      })
    });
  };
  Vx = u.memo(function({ steps: t, size: n = "sm" }) {
    if (!t || t.length === 0)
      return null;
    const r = n === "sm" ? "w-2.5 h-2.5" : "w-3 h-3", s = n === "sm" ? "px-1 py-0.5" : "px-1.5 py-0.5";
    return l.jsx("div", {
      className: "flex items-center gap-1 flex-wrap",
      children: t.map((a, o) => {
        const i = a.type ?? a, c = bo[i], d = vo[i] || "";
        return l.jsxs(u.Fragment, {
          children: [
            o > 0 && l.jsx("span", {
              className: "text-xs text-gray-400 dark:text-slate-400",
              "aria-hidden": "true",
              children: "\u2192"
            }),
            l.jsxs("span", {
              className: `inline-flex items-center gap-0.5 ${s} text-xs rounded ${d}`,
              children: [
                c && l.jsx(c, {
                  className: r
                }),
                Pn[i] || "Unknown"
              ]
            })
          ]
        }, o);
      })
    });
  });
  Wx = (e, t) => e.size === t.size && [
    ...e
  ].every((n) => t.has(n));
  zx = u.memo(function({ selectedTypes: t, onTypeToggle: n, disabled: r = false, size: s = "md" }) {
    const a = s === "sm" ? "gap-1" : "gap-1.5", o = s === "sm" ? "p-1.5 rounded-md" : "p-2 rounded-lg", i = s === "sm" ? "w-3.5 h-3.5" : "w-4 h-4", c = s === "sm" ? "w-2.5 h-2.5" : "w-3 h-3", d = s === "sm" ? "gap-0.5" : "gap-1", f = s === "sm" ? "" : "font-medium";
    return l.jsx("div", {
      className: `grid grid-cols-3 ${a}`,
      children: fc.map((h) => {
        const g = bo[h], m = t.has(h);
        return l.jsxs("button", {
          onClick: () => n(h),
          disabled: r,
          "aria-label": Pn[h],
          className: $e(`relative flex flex-col items-center ${d} ${o} border text-xs cursor-pointer disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-blue-500 ${f}`, m ? `${vo[h]} border-current ring-1 ring-current` : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-gray-300 dark:hover:border-slate-600"),
          children: [
            m && l.jsx(Gn, {
              className: `absolute top-0.5 right-0.5 ${c}`
            }),
            l.jsx(g, {
              className: i
            }),
            l.jsx("span", {
              children: Pn[h]
            })
          ]
        }, h);
      })
    });
  }, (e, t) => Wx(e.selectedTypes, t.selectedTypes) && e.onTypeToggle === t.onTypeToggle && e.disabled === t.disabled && e.size === t.size);
  Gx = [
    {
      value: An.NEW,
      label: "This source"
    },
    {
      value: An.ALL,
      label: "All sources"
    }
  ];
  yn = function({ enabled: e, selection: t, onEnabledChange: n, onSelectionChange: r, disabled: s = false, licensed: a = false, isExistingNotebook: o = false, scope: i = An.NEW, onScopeChange: c }) {
    const d = u.useMemo(() => {
      const { types: p } = Ki(t);
      return new Set(p);
    }, [
      t
    ]), f = u.useRef(d);
    f.current = d;
    const h = u.useCallback((p) => {
      const x = f.current;
      if (!a && !x.has(p) && x.size >= 1) {
        zn("multi-type");
        return;
      }
      const b = Yi(x, p);
      r(b.size === 0 ? Co : Xi(b));
    }, [
      a,
      r
    ]), g = d.size === 0 ? null : d.size === 1 ? Pn[[
      ...d
    ][0]] : `${d.size} types`, m = e ? So : Qi;
    return l.jsxs("div", {
      className: `rounded-lg border ${e ? "bg-blue-50/50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800/50" : "bg-gray-50 dark:bg-slate-800/50 border-gray-200 dark:border-slate-700"}`,
      children: [
        l.jsxs("button", {
          type: "button",
          onClick: () => n(!e),
          disabled: s,
          className: "flex items-center gap-2 w-full px-2.5 py-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed",
          children: [
            l.jsx(yo, {
              className: `w-3.5 h-3.5 shrink-0 ${e ? "text-blue-500 dark:text-blue-400" : "text-gray-400 dark:text-slate-500"}`
            }),
            l.jsx("span", {
              className: `text-xs font-medium ${e ? "text-blue-700 dark:text-blue-300" : "text-gray-700 dark:text-slate-300"}`,
              children: "Also generate Studio"
            }),
            e && g && l.jsx("span", {
              className: "text-xs text-blue-400 dark:text-blue-400/70",
              children: g
            }),
            l.jsx(m, {
              className: "w-3.5 h-3.5 ml-auto shrink-0 text-gray-400 dark:text-slate-500"
            })
          ]
        }),
        e && l.jsxs("div", {
          className: "px-2.5 pb-2.5",
          children: [
            o && l.jsx("div", {
              className: "flex gap-1 mb-1.5",
              children: Gx.map(({ value: p, label: x }) => l.jsx("button", {
                type: "button",
                onClick: () => c == null ? void 0 : c(p),
                disabled: s,
                className: `px-2 py-0.5 text-xs rounded-full disabled:opacity-50 ${i === p ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300" : "bg-gray-100 text-gray-600 dark:bg-slate-700 dark:text-slate-400"}`,
                children: x
              }, p))
            }),
            l.jsx("p", {
              className: "text-xs text-gray-400 dark:text-slate-500 mb-1",
              children: a ? "Select one or more types" : "Select a type (multi-type requires a license)"
            }),
            l.jsx(zx, {
              selectedTypes: d,
              onTypeToggle: h,
              disabled: s,
              size: "sm"
            }),
            d.size > 1 && l.jsx("div", {
              className: "mt-1.5",
              children: l.jsx(Vx, {
                steps: [
                  ...d
                ],
                size: "sm"
              })
            })
          ]
        })
      ]
    });
  };
  let Zx, qx, Kx, Yx, Xx, Qx, Jx, nb, ob, ib, db, hb, gb, xb, bb, vb;
  Zx = ({ tabInfo: e }) => {
    const [t, n] = ee(), [r, s] = u.useState(false), { projects: a = [], selectedProject: o, query: i } = t.notebooklm || {}, { isAdding: c, addSuccess: d, actionType: f, error: h, progressMessage: g, progressPercent: m } = t.notebookActions, { alsoGenerateProps: p, generateConfig: x } = vn(), b = u.useRef(false);
    u.useEffect(() => {
      d && !b.current && (b.current = true, on(() => n.isLicensed())), d || (b.current = false);
    }, [
      d
    ]);
    const y = async () => {
      try {
        await n.addToNotebook(e, null, {
          generateConfig: x
        });
      } catch (w) {
        console.error("Failed to create notebook:", w);
      }
    }, v = async () => {
      try {
        await n.addToNotebook(e, o == null ? void 0 : o.id, {
          generateConfig: x
        });
      } catch (w) {
        console.error("Failed to add to notebook:", w);
      }
    };
    return l.jsxs("div", {
      className: "space-y-3",
      children: [
        c && g && l.jsx(de, {
          type: "progress",
          message: g,
          progress: m
        }),
        d && l.jsx(de, {
          type: "success",
          message: f === "new" ? "Notebook created" : "Added to notebook"
        }),
        h && l.jsx(de, {
          type: "error",
          message: h
        }),
        !d && l.jsx(yn, {
          ...p,
          disabled: c,
          isExistingNotebook: r && !!o
        }),
        l.jsx(pe, {
          onClick: y,
          disabled: c || d,
          isLoading: c && f === "new",
          isSuccess: d && f === "new",
          loadingText: "Creating...",
          successText: "Created",
          children: "Create new notebook"
        }),
        r ? l.jsxs("div", {
          className: "space-y-2 p-2.5 bg-gray-50 dark:bg-slate-900 rounded-lg border border-gray-200 dark:border-slate-700",
          children: [
            l.jsxs("div", {
              className: "flex items-center justify-between mb-1",
              children: [
                l.jsx("label", {
                  className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                  children: "Select notebook"
                }),
                l.jsx("button", {
                  onClick: () => s(false),
                  disabled: c,
                  className: "text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 disabled:opacity-50",
                  children: "Cancel"
                })
              ]
            }),
            l.jsx(qs, {
              projects: a,
              selectedProject: o,
              onSelectProject: n.setSelectedProject,
              query: i,
              onQueryChange: n.setQuery,
              onClose: () => n.setQuery("")
            }),
            o && l.jsx("div", {
              className: "px-2 py-1.5 bg-white dark:bg-slate-800 rounded border border-gray-200 dark:border-slate-700",
              children: l.jsx("p", {
                className: "text-xs text-gray-600 dark:text-slate-400 truncate",
                children: l.jsx("span", {
                  className: "font-medium text-gray-900 dark:text-slate-100",
                  children: o.title
                })
              })
            }),
            l.jsx(pe, {
              onClick: v,
              disabled: c || d || !o,
              isLoading: c && f === "existing",
              isSuccess: d && f === "existing",
              loadingText: "Adding...",
              successText: "Added",
              icon: an,
              children: "Add to notebook"
            })
          ]
        }) : l.jsx(pe, {
          onClick: () => s(true),
          disabled: c || d || a.length === 0,
          variant: "secondary",
          children: "Add to existing notebook"
        })
      ]
    });
  };
  qx = ({ onRemoveHash: e, onRemoveParams: t, onCleanAll: n, disabled: r = false }) => l.jsxs("div", {
    className: "flex flex-wrap gap-1",
    children: [
      l.jsxs("button", {
        onClick: e,
        disabled: r,
        className: "flex items-center px-1.5 py-0.5 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded text-xs disabled:opacity-50 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-300",
        children: [
          l.jsx(oa, {
            className: "w-2.5 h-2.5 mr-0.5"
          }),
          "Hash"
        ]
      }),
      l.jsxs("button", {
        onClick: t,
        disabled: r,
        className: "flex items-center px-1.5 py-0.5 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded text-xs disabled:opacity-50 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-300",
        children: [
          l.jsx(oa, {
            className: "w-2.5 h-2.5 mr-0.5"
          }),
          "Params"
        ]
      }),
      l.jsxs("button", {
        onClick: n,
        disabled: r,
        className: "flex items-center px-1.5 py-0.5 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded text-xs disabled:opacity-50 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-300",
        children: [
          l.jsx(yo, {
            className: "w-2.5 h-2.5 mr-0.5"
          }),
          "Clean"
        ]
      })
    ]
  });
  Kx = (e) => {
    try {
      const t = new URL(e.trim());
      return t.hash = "", t.href;
    } catch {
      return e.trim();
    }
  };
  Yx = (e) => {
    try {
      const t = new URL(e.trim());
      return t.hash = "", t.href;
    } catch {
      return e.trim();
    }
  };
  Xx = (e) => {
    try {
      const t = new URL(e.trim());
      return t.search = "", t.href;
    } catch {
      return e.trim();
    }
  };
  Qx = (e) => {
    try {
      const t = new URL(e.trim());
      return t.hash = "", t.search = "", t.href;
    } catch {
      return e.trim();
    }
  };
  Jx = (e, t = Kx) => {
    const n = e.split(`
`).filter((r) => r.trim()).map(t);
    return [
      ...new Set(n)
    ];
  };
  is = (e, t) => {
    if (!t)
      return e;
    try {
      const n = new RegExp(t, "i");
      return e.filter((r) => n.test(r));
    } catch {
      return e.filter((n) => n.toLowerCase().includes(t.toLowerCase()));
    }
  };
  eb = ({ links: e, linksText: t, setLinksText: n, onLinksChange: r, disabled: s = false, placeholder: a = "Links will appear here...", rows: o = 5, showTools: i = true }) => {
    const c = (g) => {
      const m = g.target.value, p = Jx(m);
      n(p.join(`
`)), r(p);
    }, d = () => {
      const m = t.split(`
`).filter((x) => x.trim()).map(Xx), p = [
        ...new Set(m)
      ];
      n(p.join(`
`)), r(p);
    }, f = () => {
      const m = t.split(`
`).filter((x) => x.trim()).map(Yx), p = [
        ...new Set(m)
      ];
      n(p.join(`
`)), r(p);
    }, h = () => {
      const m = t.split(`
`).filter((x) => x.trim()).map(Qx), p = [
        ...new Set(m)
      ];
      n(p.join(`
`)), r(p);
    };
    return l.jsxs("div", {
      className: "space-y-3",
      children: [
        l.jsxs("div", {
          className: "space-y-1.5",
          children: [
            l.jsxs("label", {
              className: "text-xs text-gray-600 dark:text-slate-400",
              children: [
                "Links (",
                e.length,
                ")"
              ]
            }),
            l.jsx("textarea", {
              value: t,
              onChange: c,
              placeholder: a,
              disabled: s,
              className: "w-full rounded-md border border-gray-200 bg-white px-2.5 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-gray-900 focus:border-gray-900 resize-none disabled:bg-gray-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-100 dark:placeholder-slate-500 dark:focus:ring-slate-400 dark:focus:border-slate-400 dark:disabled:bg-slate-900",
              rows: o
            })
          ]
        }),
        i && e.length > 0 && l.jsx(qx, {
          onRemoveHash: f,
          onRemoveParams: d,
          onCleanAll: h,
          disabled: s
        })
      ]
    });
  };
  tb = ({ links: e, linkFilter: t, setLinkFilter: n, onApplyFilter: r, disabled: s = false }) => {
    const [a, o] = u.useState(false), i = t === "" ? e : a ? e.filter((f) => !is(e, t).includes(f)) : is(e, t), c = () => {
      i.length > 0 && (r(i), n(""));
    }, d = () => {
      n("");
    };
    return l.jsxs("div", {
      className: "space-y-2",
      children: [
        l.jsxs("div", {
          className: "flex items-center justify-between gap-2",
          children: [
            l.jsx("label", {
              className: "text-xs font-medium text-gray-700 dark:text-slate-300",
              children: "Filter Links"
            }),
            l.jsxs("div", {
              className: "flex rounded-md border border-gray-200 bg-white overflow-hidden dark:border-slate-700 dark:bg-slate-800",
              children: [
                l.jsxs("button", {
                  onClick: () => o(false),
                  disabled: s,
                  className: `flex items-center gap-1 px-2 py-1 text-xs disabled:opacity-50 ${a ? "bg-white text-gray-600 hover:bg-gray-50 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700" : "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900"}`,
                  children: [
                    l.jsx(Qc, {
                      className: "w-3 h-3"
                    }),
                    "Include"
                  ]
                }),
                l.jsxs("button", {
                  onClick: () => o(true),
                  disabled: s,
                  className: `flex items-center gap-1 px-2 py-1 text-xs disabled:opacity-50 border-l border-gray-200 dark:border-slate-700 ${a ? "bg-red-600 text-white" : "bg-white text-gray-600 hover:bg-gray-50 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"}`,
                  children: [
                    l.jsx(xu, {
                      className: "w-3 h-3"
                    }),
                    "Exclude"
                  ]
                })
              ]
            })
          ]
        }),
        l.jsx("div", {
          className: "relative",
          children: l.jsx("input", {
            type: "text",
            value: t,
            onChange: (f) => n(f.target.value),
            placeholder: "Search or use regex pattern...",
            disabled: s,
            className: "w-full rounded-md border border-gray-200 bg-white px-2.5 py-2 text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent disabled:bg-gray-50 disabled:text-gray-500 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-100 dark:placeholder-slate-500 dark:focus:ring-slate-400 dark:disabled:bg-slate-900 dark:disabled:text-slate-500"
          })
        }),
        t && l.jsxs("div", {
          className: "rounded-md bg-gray-50 border border-gray-200 p-2 space-y-2 dark:bg-slate-900 dark:border-slate-700",
          children: [
            l.jsx("div", {
              className: "flex items-center justify-between",
              children: l.jsx("span", {
                className: "text-xs text-gray-600 dark:text-slate-400",
                children: a ? l.jsxs(l.Fragment, {
                  children: [
                    l.jsx("span", {
                      className: "text-red-600",
                      children: i.length
                    }),
                    " remaining",
                    l.jsx("span", {
                      className: "text-gray-400 dark:text-slate-500 mx-1",
                      children: "\xB7"
                    }),
                    l.jsx("span", {
                      children: e.length - i.length
                    }),
                    " excluded"
                  ]
                }) : l.jsxs(l.Fragment, {
                  children: [
                    l.jsx("span", {
                      className: "text-gray-900 dark:text-slate-100",
                      children: i.length
                    }),
                    " ",
                    "matched",
                    l.jsx("span", {
                      className: "text-gray-400 dark:text-slate-500 mx-1",
                      children: "\xB7"
                    }),
                    e.length,
                    " total"
                  ]
                })
              })
            }),
            l.jsxs("div", {
              className: "flex gap-1.5",
              children: [
                l.jsxs("button", {
                  onClick: c,
                  disabled: s || i.length === 0,
                  className: `flex-1 flex items-center justify-center gap-1 px-2.5 py-1.5 rounded text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed ${a ? "bg-red-600 hover:bg-red-700 text-white" : "bg-gray-900 hover:bg-gray-800 text-white dark:bg-gray-100 dark:text-gray-900 dark:hover:bg-gray-200"}`,
                  children: [
                    l.jsx(xt, {
                      className: "w-3 h-3"
                    }),
                    a ? "Apply Exclusion" : "Apply Filter"
                  ]
                }),
                l.jsxs("button", {
                  onClick: d,
                  disabled: s,
                  className: "flex items-center justify-center gap-1 px-2.5 py-1.5 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded text-xs disabled:opacity-50 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 dark:border-slate-700",
                  children: [
                    l.jsx(sn, {
                      className: "w-3 h-3"
                    }),
                    "Clear"
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  };
  nb = ({ tabInfo: e }) => {
    const [t, n] = ee(), { projects: r = [], selectedBatchProject: s, batchQuery: a } = t.notebooklm || {}, { isExtracting: o, links: i, error: c } = t.linksExtractor, { isAdding: d, addSuccess: f, actionType: h, error: g, progressMessage: m, progressPercent: p, failedLinks: x, totalLinks: b } = t.batchNotebookActions, [y, v] = u.useState(""), [w, k] = u.useState(""), [E, N] = u.useState(""), [C, I] = u.useState(false), [H, A] = u.useState(false), { alsoGenerateProps: F, generateConfig: O } = vn();
    u.useEffect(() => {
      i.length > 0 && v(i.join(`
`));
    }, [
      i
    ]), u.useEffect(() => {
      if (e == null ? void 0 : e.url) {
        const $ = e.url.toLowerCase();
        $.includes("sitemap") && $.endsWith(".xml") ? (N(e.url), I(true)) : I(false);
      }
    }, [
      e == null ? void 0 : e.url
    ]);
    const M = u.useRef(false);
    u.useEffect(() => {
      f && !M.current && (M.current = true, on(() => n.isLicensed())), f || (M.current = false);
    }, [
      f
    ]);
    const T = async () => {
      (e == null ? void 0 : e.id) && (await n.extractLinks(e.id)).length === 0 && v("");
    }, L = async () => {
      const $ = E.trim();
      if ($) {
        try {
          new URL($);
        } catch {
          n.setLinks([]), v("");
          return;
        }
        try {
          (await n.extractFromSitemap($)).length === 0 && v("");
        } catch (S) {
          console.error("Failed to extract sitemap:", S);
        }
      }
    }, U = ($) => {
      n.setLinks($);
    }, W = async () => {
      const $ = y.split(`
`).filter((S) => S.trim());
      $.length > 0 && (await n.addLinksToNotebook($, null, {
        generateConfig: O
      }), await Fr("feature_used"));
    }, _ = async () => {
      const $ = y.split(`
`).filter((S) => S.trim());
      $.length > 0 && s && (await n.addLinksToNotebook($, (s == null ? void 0 : s.id) || null, {
        generateConfig: O
      }), await Fr("feature_used"));
    }, B = ($) => {
      v($.join(`
`)), n.setLinks($);
    }, D = w === "" ? i : is(i, w), K = w === "" ? y : D.join(`
`);
    return l.jsxs("div", {
      className: "space-y-4",
      children: [
        l.jsxs("div", {
          className: "space-y-2",
          children: [
            C && l.jsxs("div", {
              className: "px-2.5 py-2 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800",
              children: [
                l.jsx("p", {
                  className: "text-xs text-blue-700 dark:text-blue-300 font-medium",
                  children: "Sitemap detected"
                }),
                l.jsx("p", {
                  className: "text-xs text-blue-600 dark:text-blue-400 mt-0.5",
                  children: "Ready to extract all URLs"
                })
              ]
            }),
            l.jsx(pe, {
              onClick: C ? L : T,
              disabled: o || d,
              isLoading: o,
              icon: C ? pu : To,
              loadingText: C ? "Extracting from sitemap..." : "Extracting...",
              variant: C ? "primary" : "secondary",
              children: C ? "Extract from sitemap" : "Extract links from page"
            })
          ]
        }),
        c && l.jsx(de, {
          type: "error",
          message: c
        }),
        i.length > 0 && l.jsxs("div", {
          className: "space-y-2",
          children: [
            l.jsx("div", {
              className: "flex items-center justify-between",
              children: l.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  l.jsx("label", {
                    className: "text-xs font-medium text-neutral-900 dark:text-slate-100",
                    children: "Extracted Links"
                  }),
                  l.jsx("span", {
                    className: "px-1.5 py-0.5 bg-neutral-100 dark:bg-slate-700 rounded text-xs font-medium text-neutral-700 dark:text-slate-300",
                    children: w === "" ? i.length : D.length
                  })
                ]
              })
            }),
            !o && l.jsx(tb, {
              links: i,
              linkFilter: w,
              setLinkFilter: k,
              onApplyFilter: B,
              disabled: d
            }),
            l.jsx(eb, {
              links: i,
              linksText: K,
              setLinksText: v,
              onLinksChange: U,
              disabled: d || w !== "" || o,
              placeholder: "Links will appear here...",
              rows: 5,
              showTools: i.length > 0
            })
          ]
        }),
        i.length > 0 && !o && l.jsxs("div", {
          className: "pt-2 border-t border-neutral-200 dark:border-slate-700 space-y-3",
          children: [
            d && m && l.jsx(de, {
              type: "progress",
              message: m,
              progress: p
            }),
            f && l.jsx("div", {
              className: "px-2.5 py-2 bg-green-50 dark:bg-green-950 rounded-md border border-green-200 dark:border-green-800",
              children: l.jsxs("div", {
                className: "flex items-start gap-2",
                children: [
                  l.jsx(xt, {
                    className: "w-4 h-4 text-green-600 dark:text-green-400 flex-shrink-0"
                  }),
                  l.jsxs("div", {
                    className: "flex-1 min-w-0",
                    children: [
                      l.jsx("p", {
                        className: "text-xs font-medium text-green-900 dark:text-green-300",
                        children: h === "new" ? "Notebook created" : "Links added"
                      }),
                      l.jsxs("p", {
                        className: "text-xs text-green-700 dark:text-green-300 mt-0.5",
                        children: [
                          b - ((x == null ? void 0 : x.length) || 0),
                          " of ",
                          b,
                          " links processed",
                          (x == null ? void 0 : x.length) > 0 && ` \xB7 ${x.length} failed`
                        ]
                      })
                    ]
                  })
                ]
              })
            }),
            g && l.jsx(de, {
              type: "error",
              message: g
            }),
            !f && l.jsx(yn, {
              ...F,
              disabled: d,
              isExistingNotebook: H && !!s
            }),
            !f && l.jsxs("div", {
              className: "space-y-2",
              children: [
                l.jsx(pe, {
                  onClick: W,
                  disabled: d,
                  isLoading: d && h === "new",
                  loadingText: "Creating notebook...",
                  children: "Create new notebook"
                }),
                H ? l.jsxs("div", {
                  className: "space-y-2 p-3 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-slate-700",
                  children: [
                    l.jsxs("div", {
                      className: "flex items-center justify-between",
                      children: [
                        l.jsx("label", {
                          className: "text-xs font-medium text-neutral-900 dark:text-slate-100",
                          children: "Select notebook"
                        }),
                        l.jsx("button", {
                          onClick: () => {
                            A(false), n.setSelectedBatchProject(null);
                          },
                          disabled: d,
                          className: "text-xs font-medium text-neutral-600 dark:text-slate-400 hover:text-neutral-900 dark:hover:text-slate-100 disabled:opacity-50",
                          children: "Cancel"
                        })
                      ]
                    }),
                    l.jsx(qs, {
                      projects: r,
                      selectedProject: s,
                      onSelectProject: n.setSelectedBatchProject,
                      query: a,
                      onQueryChange: n.setBatchQuery,
                      onClose: () => n.setBatchQuery("")
                    }),
                    s && l.jsxs("div", {
                      className: "px-2.5 py-2 bg-white dark:bg-slate-800 rounded-md border border-neutral-200 dark:border-slate-700",
                      children: [
                        l.jsx("p", {
                          className: "text-xs text-neutral-500 dark:text-slate-400",
                          children: "Selected"
                        }),
                        l.jsx("p", {
                          className: "text-xs font-medium text-neutral-900 dark:text-slate-100 truncate mt-0.5",
                          children: s.title
                        })
                      ]
                    }),
                    l.jsxs(pe, {
                      onClick: _,
                      disabled: d || !s,
                      isLoading: d && h === "existing",
                      loadingText: "Adding links...",
                      icon: an,
                      children: [
                        "Add ",
                        i.length,
                        " ",
                        i.length === 1 ? "link" : "links"
                      ]
                    })
                  ]
                }) : l.jsx("button", {
                  onClick: () => A(true),
                  disabled: d || r.length === 0,
                  className: "w-full px-3 py-2 text-xs font-medium text-neutral-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-neutral-300 dark:border-slate-600 rounded-md hover:bg-neutral-50 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed",
                  children: r.length === 0 ? "No notebooks available" : "Add to existing notebook"
                })
              ]
            })
          ]
        })
      ]
    });
  };
  Ks = ({ isOpen: e, onToggle: t, projects: n, selectedProject: r, onSelectProject: s, query: a, onQueryChange: o, isLoading: i, actionType: c, onConfirm: d, itemCount: f, itemLabel: h = "videos" }) => e ? l.jsxs("div", {
    className: "space-y-2 p-3 bg-neutral-50 rounded-lg border border-neutral-200 dark:bg-slate-900 dark:border-slate-700",
    children: [
      l.jsxs("div", {
        className: "flex items-center justify-between",
        children: [
          l.jsx("label", {
            className: "text-xs font-medium text-neutral-900 dark:text-slate-100",
            children: "Select notebook"
          }),
          l.jsx("button", {
            onClick: () => {
              t(), s(null);
            },
            disabled: i,
            className: "text-xs font-medium text-neutral-600 hover:text-neutral-900 disabled:opacity-50 dark:text-slate-400 dark:hover:text-slate-100",
            children: "Cancel"
          })
        ]
      }),
      l.jsx(qs, {
        projects: n,
        selectedProject: r,
        onSelectProject: s,
        query: a,
        onQueryChange: o,
        onClose: () => o("")
      }),
      r && l.jsxs("div", {
        className: "px-2.5 py-2 bg-white rounded-md border border-neutral-200 dark:bg-slate-800 dark:border-slate-700",
        children: [
          l.jsx("p", {
            className: "text-xs text-neutral-500 dark:text-slate-400",
            children: "Selected"
          }),
          l.jsx("p", {
            className: "text-xs font-medium text-neutral-900 dark:text-slate-100 truncate mt-0.5",
            children: r.title
          })
        ]
      }),
      l.jsxs(pe, {
        onClick: d,
        disabled: i || !r,
        isLoading: i && c === "existing",
        loadingText: "Adding...",
        icon: an,
        children: [
          "Add ",
          f,
          " ",
          f === 1 ? h.replace(/s$/, "") : h
        ]
      })
    ]
  }) : l.jsx("button", {
    onClick: t,
    disabled: i || n.length === 0,
    className: "w-full px-3 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-300 rounded-md hover:bg-neutral-50 disabled:opacity-50 disabled:cursor-not-allowed dark:bg-slate-800 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700",
    children: n.length === 0 ? "No notebooks available" : "Add to existing notebook"
  });
  rb = () => {
    const [e, t] = ee(), { selectedVideoIds: n } = e.playlistImport, r = () => n.map((o) => Ji(o));
    return {
      selectedVideoIds: n,
      getSelectedVideoUrls: r,
      addToNewNotebook: async (o = null) => {
        const i = r();
        return i.length > 0 ? await t.addLinksToNotebook(i, null, {
          generateConfig: o
        }) : false;
      },
      addToExistingNotebook: async (o, i = null) => {
        const c = r();
        return c.length > 0 && o ? await t.addLinksToNotebook(c, o, {
          generateConfig: i
        }) : false;
      }
    };
  };
  sb = () => {
    const [e, t] = ee(), { videos: n, selectedVideoIds: r } = e.playlistImport, s = n.filter((c) => c.isAvailable), a = s.length > 0 && s.every((c) => r.includes(c.id)), o = () => {
      a ? t.deselectAllVideos() : t.selectAllVideos();
    }, i = (c) => {
      t.toggleVideoSelection(c);
    };
    return l.jsx("div", {
      className: "border border-neutral-200 dark:border-neutral-700 rounded-lg overflow-hidden",
      children: l.jsx("div", {
        className: "max-h-80 overflow-y-auto",
        children: l.jsxs("table", {
          className: "min-w-full divide-y divide-neutral-200 dark:divide-neutral-700",
          children: [
            l.jsx("thead", {
              className: "bg-neutral-50 dark:bg-slate-900 sticky top-0",
              children: l.jsxs("tr", {
                children: [
                  l.jsx("th", {
                    className: "w-10 px-3 py-2",
                    children: l.jsx("input", {
                      type: "checkbox",
                      checked: a,
                      onChange: o,
                      className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900"
                    })
                  }),
                  l.jsx("th", {
                    className: "w-16 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400"
                  }),
                  l.jsx("th", {
                    className: "px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Title"
                  }),
                  l.jsx("th", {
                    className: "w-20 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Views"
                  }),
                  l.jsx("th", {
                    className: "w-24 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Date"
                  }),
                  l.jsx("th", {
                    className: "w-16 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Duration"
                  })
                ]
              })
            }),
            l.jsx("tbody", {
              className: "bg-white dark:bg-slate-800 divide-y divide-neutral-100 dark:divide-neutral-700",
              children: n.map((c) => l.jsxs("tr", {
                className: $e("group", c.isAvailable ? "cursor-pointer hover:bg-neutral-50 dark:hover:bg-slate-700" : "opacity-50", r.includes(c.id) && "bg-neutral-50 dark:bg-slate-700"),
                onClick: () => c.isAvailable && i(c.id),
                children: [
                  l.jsx("td", {
                    className: "px-3 py-2",
                    children: l.jsx("input", {
                      type: "checkbox",
                      checked: r.includes(c.id),
                      onChange: () => i(c.id),
                      disabled: !c.isAvailable,
                      onClick: (d) => d.stopPropagation(),
                      className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 disabled:opacity-50"
                    })
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2",
                    children: l.jsx("div", {
                      className: "w-12 h-8 bg-neutral-200 dark:bg-neutral-700 rounded overflow-hidden flex-shrink-0",
                      children: c.thumbnailUrl ? l.jsx("img", {
                        src: c.thumbnailUrl,
                        alt: "",
                        className: "w-full h-full object-cover"
                      }) : l.jsx("div", {
                        className: "w-full h-full bg-neutral-300 dark:bg-neutral-600"
                      })
                    })
                  }),
                  l.jsxs("td", {
                    className: "px-2 py-2",
                    children: [
                      l.jsxs("div", {
                        className: "flex items-start gap-1.5",
                        children: [
                          l.jsx("p", {
                            className: $e("text-xs line-clamp-2", c.isAvailable ? "text-neutral-800 dark:text-neutral-200" : "text-neutral-500 dark:text-neutral-400"),
                            children: c.title
                          }),
                          !c.isAvailable && l.jsxs("span", {
                            className: "flex-shrink-0 inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-200 text-xs rounded",
                            children: [
                              l.jsx(On, {
                                className: "w-3 h-3"
                              }),
                              c.unavailableReason || "Unavailable"
                            ]
                          })
                        ]
                      }),
                      l.jsx("p", {
                        className: "text-xs text-neutral-500 dark:text-neutral-400 mt-0.5",
                        children: c.channelName
                      })
                    ]
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2 text-xs text-neutral-600 dark:text-neutral-400 whitespace-nowrap",
                    children: c.viewCountText || "-"
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2 text-xs text-neutral-500 dark:text-neutral-400 whitespace-nowrap",
                    children: c.uploadDateText || "-"
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2 text-xs text-neutral-600 dark:text-neutral-400",
                    children: c.duration
                  })
                ]
              }, c.id))
            })
          ]
        })
      })
    });
  };
  ab = () => {
    const [e] = ee(), { playlistInfo: t, videos: n, selectedVideoIds: r } = e.playlistImport;
    if (!t)
      return null;
    const s = n.filter((o) => o.isAvailable).length, a = n.length - s;
    return l.jsx("div", {
      className: "p-3 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-neutral-700",
      children: l.jsxs("div", {
        className: "flex items-start gap-3",
        children: [
          l.jsx("div", {
            className: "flex-shrink-0 w-10 h-10 bg-red-100 dark:bg-red-950 rounded-lg flex items-center justify-center",
            children: l.jsx(Ln, {
              className: "w-5 h-5 text-red-600 dark:text-red-400"
            })
          }),
          l.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              l.jsx("h3", {
                className: "text-xs font-semibold text-neutral-900 dark:text-neutral-100 line-clamp-1",
                children: t.title
              }),
              l.jsx("p", {
                className: "text-xs text-neutral-600 dark:text-neutral-400 dark:text-neutral-400 mt-0.5",
                children: t.channelName
              }),
              l.jsxs("div", {
                className: "flex items-center gap-3 mt-2",
                children: [
                  l.jsxs("span", {
                    className: "inline-flex items-center gap-1 text-xs text-neutral-600 dark:text-neutral-400",
                    children: [
                      l.jsx("span", {
                        className: "font-medium",
                        children: n.length
                      }),
                      " videos"
                    ]
                  }),
                  a > 0 && l.jsxs("span", {
                    className: "text-xs text-amber-600 dark:text-amber-400",
                    children: [
                      a,
                      " unavailable"
                    ]
                  }),
                  l.jsxs("span", {
                    className: "inline-flex items-center gap-1 text-xs text-green-700 dark:text-green-400",
                    children: [
                      l.jsx(Gn, {
                        className: "w-3.5 h-3.5"
                      }),
                      l.jsx("span", {
                        className: "font-medium",
                        children: r.length
                      }),
                      " selected"
                    ]
                  })
                ]
              })
            ]
          })
        ]
      })
    });
  };
  ob = ({ tabInfo: e }) => {
    const [t, n] = ee(), [r, s] = u.useState(false), [a, o] = u.useState(""), { projects: i = [], selectedBatchProject: c, batchQuery: d } = t.notebooklm || {}, { isParsing: f, parseError: h, videos: g, playlistInfo: m } = t.playlistImport, { isAdding: p, addSuccess: x, actionType: b, error: y, progressMessage: v, progressPercent: w } = t.batchNotebookActions, { selectedVideoIds: k, addToNewNotebook: E, addToExistingNotebook: N } = rb(), { alsoGenerateProps: C, generateConfig: I } = vn();
    u.useEffect(() => {
      (e == null ? void 0 : e.url) && Cn(e.url) && o(e.url);
    }, [
      e == null ? void 0 : e.url
    ]), u.useEffect(() => () => {
      n.resetPlaylistImport();
    }, []);
    const H = u.useRef(false);
    u.useEffect(() => {
      x && !H.current && (H.current = true, on(() => n.isLicensed())), x || (H.current = false);
    }, [
      x
    ]);
    const A = async () => {
      const L = a.trim();
      !L || !Cn(L) || await n.parsePlaylist(L);
    }, F = async () => {
      c && await N(c.id, I);
    }, O = Cn(a), M = O && !f, T = k.length > 0;
    return l.jsxs("div", {
      className: "space-y-3",
      children: [
        l.jsxs("div", {
          className: "space-y-2",
          children: [
            l.jsxs("div", {
              className: "relative",
              children: [
                l.jsx("input", {
                  type: "url",
                  value: a,
                  onChange: (L) => o(L.target.value),
                  placeholder: "YouTube playlist URL...",
                  disabled: f || p,
                  className: "w-full pl-8 pr-3 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 disabled:opacity-50 disabled:bg-neutral-50 dark:disabled:bg-slate-800 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100"
                }),
                l.jsx(Ln, {
                  className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-red-500"
                })
              ]
            }),
            a && !O && l.jsx("p", {
              className: "text-xs text-amber-600 dark:text-amber-400",
              children: "Enter a valid YouTube playlist URL"
            }),
            !g.length && l.jsx(pe, {
              onClick: A,
              disabled: !M,
              isLoading: f,
              loadingText: "Parsing...",
              icon: Ln,
              children: "Parse Playlist"
            })
          ]
        }),
        h && l.jsx(de, {
          type: "error",
          message: h
        }),
        m && g.length > 0 && l.jsxs(l.Fragment, {
          children: [
            l.jsx(ab, {}),
            l.jsx(sb, {})
          ]
        }),
        p && v && l.jsx(de, {
          type: "progress",
          message: v,
          progress: w
        }),
        x && l.jsx(de, {
          type: "success",
          message: b === "new" ? "Notebook created" : "Videos added"
        }),
        y && l.jsx(de, {
          type: "error",
          message: y
        }),
        T && !x && l.jsx(yn, {
          ...C,
          disabled: p,
          isExistingNotebook: r && !!c
        }),
        T && !x && l.jsxs(l.Fragment, {
          children: [
            l.jsxs(pe, {
              onClick: () => E(I),
              disabled: p,
              isLoading: p && b === "new",
              loadingText: "Creating...",
              children: [
                "Create notebook with ",
                k.length,
                " videos"
              ]
            }),
            l.jsx(Ks, {
              isOpen: r,
              onToggle: () => s(!r),
              projects: i,
              selectedProject: c,
              onSelectProject: n.setSelectedBatchProject,
              query: d,
              onQueryChange: n.setBatchQuery,
              isLoading: p,
              actionType: b,
              onConfirm: F,
              itemCount: k.length
            })
          ]
        }),
        x && l.jsx(pe, {
          onClick: () => {
            n.resetPlaylistImport(), n.resetBatchState(), o(""), s(false);
          },
          variant: "secondary",
          icon: rt,
          children: "Import another playlist"
        })
      ]
    });
  };
  lb = () => {
    const [e, t] = ee(), { articles: n, selectedArticleIds: r } = e.rssImport, s = () => n.filter((i) => r.includes(i.id)).map((i) => i.url).filter((i) => i);
    return {
      selectedArticleIds: r,
      getSelectedArticleUrls: s,
      addToNewNotebook: async (i = null) => {
        const c = s();
        return c.length > 0 ? await t.addLinksToNotebook(c, null, {
          generateConfig: i
        }) : false;
      },
      addToExistingNotebook: async (i, c = null) => {
        const d = s();
        return d.length > 0 && i ? await t.addLinksToNotebook(d, i, {
          generateConfig: c
        }) : false;
      }
    };
  };
  ib = (e) => {
    if (!e)
      return "-";
    try {
      return new Date(e).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric"
      });
    } catch {
      return e;
    }
  };
  cb = () => {
    const [e, t] = ee(), { articles: n, selectedArticleIds: r } = e.rssImport, s = n.filter((c) => c.isAvailable), a = s.length > 0 && s.every((c) => r.includes(c.id)), o = () => {
      a ? t.deselectAllArticles() : t.selectAllArticles();
    }, i = (c) => {
      t.toggleArticleSelection(c);
    };
    return l.jsx("div", {
      className: "border border-neutral-200 dark:border-neutral-700 rounded-lg overflow-hidden",
      children: l.jsx("div", {
        className: "max-h-80 overflow-y-auto",
        children: l.jsxs("table", {
          className: "min-w-full divide-y divide-neutral-200 dark:divide-neutral-700",
          children: [
            l.jsx("thead", {
              className: "bg-neutral-50 dark:bg-slate-900 sticky top-0",
              children: l.jsxs("tr", {
                children: [
                  l.jsx("th", {
                    className: "w-10 px-3 py-2",
                    children: l.jsx("input", {
                      type: "checkbox",
                      checked: a,
                      onChange: o,
                      className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900"
                    })
                  }),
                  l.jsx("th", {
                    className: "px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Title"
                  }),
                  l.jsx("th", {
                    className: "w-28 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Author"
                  }),
                  l.jsx("th", {
                    className: "w-24 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Date"
                  })
                ]
              })
            }),
            l.jsx("tbody", {
              className: "bg-white dark:bg-slate-800 divide-y divide-neutral-100 dark:divide-neutral-700",
              children: n.map((c) => l.jsxs("tr", {
                className: $e("group", c.isAvailable ? "cursor-pointer hover:bg-neutral-50 dark:hover:bg-slate-700" : "opacity-50", r.includes(c.id) && "bg-neutral-50 dark:bg-slate-700"),
                onClick: () => c.isAvailable && i(c.id),
                children: [
                  l.jsx("td", {
                    className: "px-3 py-2",
                    children: l.jsx("input", {
                      type: "checkbox",
                      checked: r.includes(c.id),
                      onChange: () => i(c.id),
                      disabled: !c.isAvailable,
                      onClick: (d) => d.stopPropagation(),
                      className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 disabled:opacity-50"
                    })
                  }),
                  l.jsxs("td", {
                    className: "px-2 py-2",
                    children: [
                      l.jsx("p", {
                        className: $e("text-xs line-clamp-2", c.isAvailable ? "text-neutral-800 dark:text-neutral-200" : "text-neutral-500 dark:text-neutral-400"),
                        children: c.title
                      }),
                      c.description && l.jsx("p", {
                        className: "text-xs text-neutral-500 dark:text-neutral-400 mt-0.5 line-clamp-1",
                        children: c.description
                      })
                    ]
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2 text-xs text-neutral-600 dark:text-neutral-400 whitespace-nowrap",
                    children: c.author || "-"
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2 text-xs text-neutral-500 dark:text-neutral-400 whitespace-nowrap",
                    children: ib(c.publishDate)
                  })
                ]
              }, c.id))
            })
          ]
        })
      })
    });
  };
  ub = () => {
    const [e] = ee(), { feedInfo: t, articles: n, selectedArticleIds: r } = e.rssImport;
    if (!t)
      return null;
    const s = n.filter((o) => o.isAvailable).length, a = n.length - s;
    return l.jsx("div", {
      className: "p-3 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-neutral-700",
      children: l.jsxs("div", {
        className: "flex items-start gap-3",
        children: [
          l.jsxs("div", {
            className: "flex-shrink-0 w-10 h-10 bg-orange-100 dark:bg-orange-950 rounded-lg flex items-center justify-center",
            children: [
              t.imageUrl ? l.jsx("img", {
                src: t.imageUrl,
                alt: "",
                className: "w-8 h-8 rounded object-cover",
                onError: (o) => {
                  o.target.style.display = "none", o.target.nextSibling.style.display = "block";
                }
              }) : null,
              l.jsx(In, {
                className: "w-5 h-5 text-orange-600",
                style: {
                  display: t.imageUrl ? "none" : "block"
                }
              })
            ]
          }),
          l.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              l.jsx("h3", {
                className: "text-xs font-semibold text-neutral-900 dark:text-neutral-100 line-clamp-1",
                children: t.title
              }),
              t.description && l.jsx("p", {
                className: "text-xs text-neutral-600 dark:text-neutral-400 mt-0.5 line-clamp-1",
                children: t.description
              }),
              l.jsxs("div", {
                className: "flex items-center gap-3 mt-2",
                children: [
                  l.jsxs("span", {
                    className: "inline-flex items-center gap-1 text-xs text-neutral-600 dark:text-neutral-400",
                    children: [
                      l.jsx("span", {
                        className: "font-medium",
                        children: n.length
                      }),
                      " articles"
                    ]
                  }),
                  a > 0 && l.jsxs("span", {
                    className: "text-xs text-amber-600 dark:text-amber-400",
                    children: [
                      a,
                      " unavailable"
                    ]
                  }),
                  l.jsxs("span", {
                    className: "inline-flex items-center gap-1 text-xs text-green-700 dark:text-green-400",
                    children: [
                      l.jsx(Gn, {
                        className: "w-3.5 h-3.5"
                      }),
                      l.jsx("span", {
                        className: "font-medium",
                        children: r.length
                      }),
                      " selected"
                    ]
                  })
                ]
              })
            ]
          })
        ]
      })
    });
  };
  db = ({ tabInfo: e }) => {
    const [t, n] = ee(), [r, s] = u.useState(false), [a, o] = u.useState(""), { projects: i = [], selectedBatchProject: c, batchQuery: d } = t.notebooklm || {}, { isParsing: f, parseError: h, articles: g, feedInfo: m, isDetecting: p, detectionError: x } = t.rssImport, { isAdding: b, addSuccess: y, actionType: v, error: w, progressMessage: k, progressPercent: E } = t.batchNotebookActions, { selectedArticleIds: N, addToNewNotebook: C, addToExistingNotebook: I } = lb(), { alsoGenerateProps: H, generateConfig: A } = vn();
    u.useEffect(() => {
      (e == null ? void 0 : e.url) && wo(e.url) && o(e.url);
    }, [
      e == null ? void 0 : e.url
    ]), u.useEffect(() => () => {
      n.resetRSSImport();
    }, []);
    const F = u.useRef(false);
    u.useEffect(() => {
      y && !F.current && (F.current = true, on(() => n.isLicensed())), y || (F.current = false);
    }, [
      y
    ]);
    const O = async () => {
      const B = Js(a.trim());
      !B || !ea(B) || await n.parseFeed(B);
    }, M = async () => {
      if (!(e == null ? void 0 : e.id))
        return;
      const B = await n.detectFeedFromTab(e.id);
      B && o(B);
    }, T = async () => {
      c && await I(c.id, A);
    }, L = Js(a), U = ea(L), W = U && !f, _ = N.length > 0;
    return l.jsxs("div", {
      className: "space-y-3",
      children: [
        l.jsxs("div", {
          className: "space-y-2",
          children: [
            l.jsxs("div", {
              className: "relative",
              children: [
                l.jsx("input", {
                  type: "url",
                  value: a,
                  onChange: (B) => o(B.target.value),
                  placeholder: "RSS/Atom feed URL...",
                  disabled: f || b,
                  className: "w-full pl-8 pr-3 py-2 text-xs border border-neutral-300 dark:border-slate-600 rounded-md focus:ring-1 focus:ring-neutral-900 dark:focus:ring-slate-400 focus:border-neutral-900 dark:focus:border-slate-400 disabled:opacity-50 disabled:bg-neutral-50 dark:disabled:bg-slate-800 bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100"
                }),
                l.jsx(In, {
                  className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-500"
                })
              ]
            }),
            a && !U && l.jsx("p", {
              className: "text-xs text-amber-600 dark:text-amber-400",
              children: "Enter a valid feed URL"
            }),
            !g.length && l.jsxs("div", {
              className: "flex gap-2",
              children: [
                l.jsx(pe, {
                  onClick: M,
                  disabled: p || f || b || !(e == null ? void 0 : e.id),
                  isLoading: p,
                  loadingText: "Detecting...",
                  icon: ko,
                  variant: "secondary",
                  className: "flex-1",
                  children: "Detect RSS"
                }),
                l.jsx(pe, {
                  onClick: O,
                  disabled: !W,
                  isLoading: f,
                  loadingText: "Parsing...",
                  icon: In,
                  className: "flex-1",
                  children: "Parse Feed"
                })
              ]
            })
          ]
        }),
        x && l.jsx(de, {
          type: "error",
          message: x
        }),
        h && l.jsx(de, {
          type: "error",
          message: h
        }),
        m && g.length > 0 && l.jsxs(l.Fragment, {
          children: [
            l.jsx(ub, {}),
            l.jsx(cb, {})
          ]
        }),
        b && k && l.jsx(de, {
          type: "progress",
          message: k,
          progress: E
        }),
        y && l.jsx(de, {
          type: "success",
          message: v === "new" ? "Notebook created" : "Articles added"
        }),
        w && l.jsx(de, {
          type: "error",
          message: w
        }),
        _ && !y && l.jsx(yn, {
          ...H,
          disabled: b,
          isExistingNotebook: r && !!c
        }),
        _ && !y && l.jsxs(l.Fragment, {
          children: [
            l.jsxs(pe, {
              onClick: () => C(A),
              disabled: b,
              isLoading: b && v === "new",
              loadingText: "Creating...",
              children: [
                "Create notebook with ",
                N.length,
                " articles"
              ]
            }),
            l.jsx(Ks, {
              isOpen: r,
              onToggle: () => s(!r),
              projects: i,
              selectedProject: c,
              onSelectProject: n.setSelectedBatchProject,
              query: d,
              onQueryChange: n.setBatchQuery,
              isLoading: b,
              actionType: v,
              onConfirm: T,
              itemCount: N.length
            })
          ]
        }),
        y && l.jsx(pe, {
          onClick: () => {
            n.resetRSSImport(), n.resetBatchState(), o(""), s(false);
          },
          variant: "secondary",
          icon: rt,
          children: "Import another feed"
        })
      ]
    });
  };
  fb = () => {
    const [e, t] = ee(), { tabs: n, selectedTabIds: r } = e.openTabsImport, s = () => n.filter((i) => r.includes(i.id)).map((i) => i.url);
    return {
      selectedTabIds: r,
      getSelectedTabUrls: s,
      addToNewNotebook: async (i = null) => {
        const c = s();
        return c.length > 0 ? await t.addLinksToNotebook(c, null, {
          generateConfig: i
        }) : false;
      },
      addToExistingNotebook: async (i, c = null) => {
        const d = s();
        return d.length > 0 && i ? await t.addLinksToNotebook(d, i, {
          generateConfig: c
        }) : false;
      }
    };
  };
  hb = (e) => {
    try {
      return new URL(e).hostname;
    } catch {
      return e;
    }
  };
  pb = () => {
    const [e, t] = ee(), { tabs: n, selectedTabIds: r } = e.openTabsImport, s = n.filter((c) => c.isValid), a = s.length > 0 && s.every((c) => r.includes(c.id)), o = () => {
      a ? t.deselectAllTabs() : t.selectAllTabs();
    }, i = (c) => {
      t.toggleTabSelection(c);
    };
    return l.jsx("div", {
      className: "border border-neutral-200 dark:border-neutral-700 rounded-lg overflow-hidden",
      children: l.jsx("div", {
        className: "max-h-80 overflow-y-auto",
        children: l.jsxs("table", {
          className: "min-w-full divide-y divide-neutral-200 dark:divide-neutral-700",
          children: [
            l.jsx("thead", {
              className: "bg-neutral-50 dark:bg-slate-900 sticky top-0",
              children: l.jsxs("tr", {
                children: [
                  l.jsx("th", {
                    className: "w-10 px-3 py-2",
                    children: l.jsx("input", {
                      type: "checkbox",
                      checked: a,
                      onChange: o,
                      className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900"
                    })
                  }),
                  l.jsx("th", {
                    className: "w-8 px-2 py-2"
                  }),
                  l.jsx("th", {
                    className: "px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Title"
                  }),
                  l.jsx("th", {
                    className: "w-32 px-2 py-2 text-left text-xs font-medium text-neutral-600 dark:text-neutral-400",
                    children: "Domain"
                  })
                ]
              })
            }),
            l.jsx("tbody", {
              className: "bg-white dark:bg-slate-800 divide-y divide-neutral-100 dark:divide-neutral-700",
              children: n.map((c) => l.jsxs("tr", {
                className: $e("group", c.isValid ? "cursor-pointer hover:bg-neutral-50 dark:hover:bg-slate-700" : "opacity-50", r.includes(c.id) && "bg-neutral-50 dark:bg-slate-700"),
                onClick: () => c.isValid && i(c.id),
                children: [
                  l.jsx("td", {
                    className: "px-3 py-2",
                    children: l.jsx("input", {
                      type: "checkbox",
                      checked: r.includes(c.id),
                      onChange: () => i(c.id),
                      disabled: !c.isValid,
                      onClick: (d) => d.stopPropagation(),
                      className: "h-3.5 w-3.5 rounded border-neutral-300 dark:border-neutral-600 text-neutral-900 focus:ring-neutral-900 disabled:opacity-50"
                    })
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2",
                    children: l.jsx("div", {
                      className: "w-4 h-4 flex-shrink-0",
                      children: c.favIconUrl ? l.jsx("img", {
                        src: c.favIconUrl,
                        alt: "",
                        className: "w-4 h-4 object-contain",
                        onError: (d) => {
                          d.target.style.display = "none";
                        }
                      }) : l.jsx("div", {
                        className: "w-4 h-4 bg-neutral-200 dark:bg-neutral-700 rounded"
                      })
                    })
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2",
                    children: l.jsxs("div", {
                      className: "flex items-start gap-1.5",
                      children: [
                        l.jsx("p", {
                          className: $e("text-xs line-clamp-2", c.isValid ? "text-neutral-800 dark:text-neutral-200" : "text-neutral-500 dark:text-neutral-400"),
                          children: c.title
                        }),
                        !c.isValid && l.jsxs("span", {
                          className: "flex-shrink-0 inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-200 text-xs rounded",
                          children: [
                            l.jsx(On, {
                              className: "w-3 h-3"
                            }),
                            "Invalid"
                          ]
                        })
                      ]
                    })
                  }),
                  l.jsx("td", {
                    className: "px-2 py-2 text-xs text-neutral-500 dark:text-neutral-400 truncate max-w-[8rem]",
                    children: hb(c.url)
                  })
                ]
              }, c.id))
            })
          ]
        })
      })
    });
  };
  mb = () => {
    const [e] = ee(), { tabs: t, selectedTabIds: n } = e.openTabsImport;
    if (t.length === 0)
      return null;
    const r = t.filter((a) => a.isValid).length, s = t.length - r;
    return l.jsx("div", {
      className: "p-3 bg-neutral-50 dark:bg-slate-900 rounded-lg border border-neutral-200 dark:border-neutral-700",
      children: l.jsxs("div", {
        className: "flex items-start gap-3",
        children: [
          l.jsx("div", {
            className: "flex-shrink-0 w-10 h-10 bg-blue-100 dark:bg-blue-950 rounded-lg flex items-center justify-center",
            children: l.jsx(Yt, {
              className: "w-5 h-5 text-blue-600 dark:text-blue-400"
            })
          }),
          l.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              l.jsx("h3", {
                className: "text-xs font-semibold text-neutral-900 dark:text-neutral-100",
                children: "Current Window Tabs"
              }),
              l.jsx("p", {
                className: "text-xs text-neutral-600 dark:text-neutral-400 dark:text-neutral-400 mt-0.5",
                children: "Import pages from your open browser tabs"
              }),
              l.jsxs("div", {
                className: "flex items-center gap-3 mt-2",
                children: [
                  l.jsxs("span", {
                    className: "inline-flex items-center gap-1 text-xs text-neutral-600 dark:text-neutral-400",
                    children: [
                      l.jsx("span", {
                        className: "font-medium",
                        children: t.length
                      }),
                      " tabs"
                    ]
                  }),
                  s > 0 && l.jsxs("span", {
                    className: "text-xs text-amber-600 dark:text-amber-400",
                    children: [
                      s,
                      " invalid"
                    ]
                  }),
                  l.jsxs("span", {
                    className: "inline-flex items-center gap-1 text-xs text-green-700 dark:text-green-400",
                    children: [
                      l.jsx(Gn, {
                        className: "w-3.5 h-3.5"
                      }),
                      l.jsx("span", {
                        className: "font-medium",
                        children: n.length
                      }),
                      " selected"
                    ]
                  })
                ]
              })
            ]
          })
        ]
      })
    });
  };
  gb = () => {
    const [e, t] = ee(), [n, r] = u.useState(false), { projects: s = [], selectedBatchProject: a, batchQuery: o } = e.notebooklm || {}, { isFetching: i, fetchError: c, tabs: d } = e.openTabsImport, { isAdding: f, addSuccess: h, actionType: g, error: m, progressMessage: p, progressPercent: x } = e.batchNotebookActions, { selectedTabIds: b, addToNewNotebook: y, addToExistingNotebook: v } = fb(), { alsoGenerateProps: w, generateConfig: k } = vn();
    u.useEffect(() => (t.fetchOpenTabs(), () => {
      t.resetOpenTabsImport();
    }), []);
    const E = u.useRef(false);
    u.useEffect(() => {
      h && !E.current && (E.current = true, on(() => t.isLicensed())), h || (E.current = false);
    }, [
      h
    ]);
    const N = async () => {
      await t.fetchOpenTabs();
    }, C = async () => {
      a && await v(a.id, k);
    }, I = b.length > 0;
    return l.jsxs("div", {
      className: "space-y-3",
      children: [
        i && d.length === 0 && l.jsx("div", {
          className: "text-center py-4",
          children: l.jsx("p", {
            className: "text-xs text-neutral-600 dark:text-slate-400",
            children: "Fetching open tabs..."
          })
        }),
        c && l.jsx(de, {
          type: "error",
          message: c
        }),
        d.length > 0 && l.jsxs(l.Fragment, {
          children: [
            l.jsx(mb, {}),
            l.jsx(pb, {}),
            l.jsx("button", {
              onClick: N,
              disabled: i || f,
              className: "text-xs text-neutral-500 dark:text-slate-400 hover:text-neutral-700 dark:hover:text-slate-300 underline disabled:opacity-50",
              children: "Refresh tabs"
            })
          ]
        }),
        !i && d.length === 0 && !c && l.jsxs("div", {
          className: "text-center py-4",
          children: [
            l.jsx(Yt, {
              className: "w-8 h-8 text-neutral-400 dark:text-slate-500 mx-auto mb-2"
            }),
            l.jsx("p", {
              className: "text-xs text-neutral-600 dark:text-slate-400 mb-3",
              children: "No open tabs found"
            }),
            l.jsx(pe, {
              onClick: N,
              disabled: i,
              isLoading: i,
              loadingText: "Fetching...",
              icon: Yt,
              children: "Fetch Open Tabs"
            })
          ]
        }),
        f && p && l.jsx(de, {
          type: "progress",
          message: p,
          progress: x
        }),
        h && l.jsx(de, {
          type: "success",
          message: g === "new" ? "Notebook created" : "Tabs added"
        }),
        m && l.jsx(de, {
          type: "error",
          message: m
        }),
        I && !h && l.jsx(yn, {
          ...w,
          disabled: f,
          isExistingNotebook: n && !!a
        }),
        I && !h && l.jsxs(l.Fragment, {
          children: [
            l.jsxs(pe, {
              onClick: () => y(k),
              disabled: f,
              isLoading: f && g === "new",
              loadingText: "Creating...",
              children: [
                "Create notebook with ",
                b.length,
                " tabs"
              ]
            }),
            l.jsx(Ks, {
              isOpen: n,
              onToggle: () => r(!n),
              projects: s,
              selectedProject: a,
              onSelectProject: t.setSelectedBatchProject,
              query: o,
              onQueryChange: t.setBatchQuery,
              isLoading: f,
              actionType: g,
              onConfirm: C,
              itemCount: b.length
            })
          ]
        }),
        h && l.jsx(pe, {
          onClick: () => {
            t.resetOpenTabsImport(), t.resetBatchState(), r(false), t.fetchOpenTabs();
          },
          variant: "secondary",
          icon: rt,
          children: "Import more tabs"
        })
      ]
    });
  };
  xb = ({ tabInfo: e }) => e ? l.jsx("div", {
    className: "px-3 py-2.5 border-b border-gray-100 dark:border-slate-700",
    children: l.jsxs("div", {
      className: "flex items-start gap-2",
      children: [
        e.favIconUrl && l.jsx("img", {
          src: e.favIconUrl,
          alt: "",
          className: "w-3 h-3 flex-shrink-0 mt-0.5 rounded-sm",
          onError: (t) => {
            t.target.style.display = "none";
          }
        }),
        l.jsxs("div", {
          className: "flex-1 min-w-0",
          children: [
            l.jsxs("div", {
              className: "flex items-start justify-between gap-2",
              children: [
                l.jsx("h2", {
                  className: "text-xs font-medium text-gray-900 dark:text-slate-100 line-clamp-2 leading-snug",
                  children: e.title
                }),
                e.isNotebookLM && l.jsx("span", {
                  className: "px-1.5 py-0.5 rounded text-[10px] font-medium bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 whitespace-nowrap",
                  children: "NotebookLM"
                })
              ]
            }),
            l.jsx("p", {
              className: "text-xs text-gray-500 dark:text-slate-400 truncate mt-0.5",
              children: e.url
            })
          ]
        })
      ]
    })
  }) : null;
  bb = ({ tabInfo: e }) => e ? l.jsx("div", {
    className: "px-3 py-2 bg-amber-50 dark:bg-amber-950 border-b border-amber-200 dark:border-amber-800",
    children: l.jsxs("div", {
      className: "flex items-center gap-2",
      children: [
        l.jsx(rt, {
          className: "w-3 h-3 text-amber-600 dark:text-amber-400 animate-spin flex-shrink-0"
        }),
        l.jsx("div", {
          className: "min-w-0 flex-1",
          children: l.jsx("p", {
            className: "text-xs text-amber-800 dark:text-amber-200 truncate",
            children: e.title
          })
        })
      ]
    })
  }) : null;
  vb = () => {
    const [e, t] = ee(), { tabInfo: n, loading: r, error: s, isInNewTab: a } = e.tabInfo, { isAdding: o } = e.notebookActions, [i, c] = u.useState(null), [d, f] = u.useState(0);
    if (u.useEffect(() => {
      t.initializeNotebookProjects(), t.initializeTabInfo();
      const p = () => {
        t.initializeTabInfo();
      }, x = (b, y, v) => {
        y.status === "complete" && chrome.tabs.query({
          active: true,
          currentWindow: true
        }, (w) => {
          var _a3;
          ((_a3 = w[0]) == null ? void 0 : _a3.id) === b && t.initializeTabInfo();
        });
      };
      return chrome.tabs.onActivated.addListener(p), chrome.tabs.onUpdated.addListener(x), () => {
        chrome.tabs.onActivated.removeListener(p), chrome.tabs.onUpdated.removeListener(x);
      };
    }, []), u.useEffect(() => {
      if (!o && i) {
        const p = setTimeout(() => {
          c(null);
        }, 500);
        return () => clearTimeout(p);
      }
    }, [
      o,
      i
    ]), u.useEffect(() => {
      (n == null ? void 0 : n.url) && (Cn(n.url) ? f(2) : wo(n.url) && f(3));
    }, [
      n == null ? void 0 : n.url
    ]), a || !t.isNotebookLMAuthenticated())
      return null;
    if (r)
      return l.jsx("div", {
        className: "bg-white dark:bg-slate-800 border-b border-neutral-100 dark:border-slate-700",
        children: l.jsx("div", {
          className: "p-3",
          children: l.jsxs("div", {
            className: "flex items-start gap-2",
            children: [
              l.jsx("div", {
                className: "w-3 h-3 bg-neutral-200 dark:bg-slate-700 rounded animate-pulse flex-shrink-0 mt-0.5"
              }),
              l.jsxs("div", {
                className: "flex-1 space-y-1.5 min-w-0",
                children: [
                  l.jsx("div", {
                    className: "h-3 bg-neutral-200 dark:bg-slate-700 rounded animate-pulse w-4/5"
                  }),
                  l.jsx("div", {
                    className: "h-2 bg-neutral-100 dark:bg-slate-700 rounded animate-pulse w-3/5"
                  })
                ]
              })
            ]
          })
        })
      });
    if (s && !n)
      return l.jsx("div", {
        className: "bg-white dark:bg-slate-800 border-b border-neutral-100 dark:border-slate-700",
        children: l.jsx("div", {
          className: "p-3 bg-red-50 dark:bg-red-950",
          children: l.jsx(de, {
            type: "error",
            message: s
          })
        })
      });
    if (!n)
      return l.jsx("div", {
        className: "bg-white dark:bg-slate-800 border-b border-neutral-100 dark:border-slate-700",
        children: l.jsx("div", {
          className: "p-3 bg-neutral-50 dark:bg-slate-900",
          children: l.jsx("p", {
            className: "text-xs text-neutral-500 dark:text-slate-400 text-center",
            children: "No tab information available"
          })
        })
      });
    const h = i || n, g = i && i.id !== (n == null ? void 0 : n.id), m = [
      {
        name: "Page",
        icon: Eo,
        disabled: h.isNotebookLM
      },
      {
        name: "Links",
        icon: To,
        disabled: h.isNotebookLM
      },
      {
        name: "Playlist",
        icon: Ln,
        disabled: h.isNotebookLM
      },
      {
        name: "RSS",
        icon: In,
        disabled: h.isNotebookLM
      },
      {
        name: "Tabs",
        icon: Yt,
        disabled: h.isNotebookLM
      }
    ];
    return l.jsxs("div", {
      className: "bg-white dark:bg-slate-800",
      children: [
        g && l.jsx(bb, {
          tabInfo: i
        }),
        l.jsx(xb, {
          tabInfo: h
        }),
        !h.isNotebookLM && l.jsx("div", {
          className: "px-3 py-3",
          children: l.jsxs(Ws, {
            selectedIndex: d,
            onChange: f,
            children: [
              l.jsx(zs, {
                className: "flex p-0.5 bg-neutral-100 dark:bg-slate-700 rounded-md",
                children: m.map((p) => l.jsxs(Ci, {
                  disabled: p.disabled,
                  className: $e("flex items-center justify-center gap-1.5 px-2 py-1.5 rounded text-xs font-medium flex-1", "focus:outline-none", p.disabled ? "text-neutral-400 dark:text-slate-500 cursor-not-allowed" : "text-neutral-700 dark:text-slate-300 data-[selected]:bg-white dark:data-[selected]:bg-slate-800 data-[selected]:text-neutral-900 dark:data-[selected]:text-slate-100 data-[selected]:shadow-sm dark:data-[selected]:shadow-slate-900/30"),
                  children: [
                    l.jsx(p.icon, {
                      className: "w-3 h-3"
                    }),
                    p.name
                  ]
                }, p.name))
              }),
              l.jsxs(Gs, {
                className: "mt-3",
                children: [
                  l.jsx(it, {
                    className: "focus:outline-none",
                    children: l.jsx(Zx, {
                      tabInfo: h
                    })
                  }),
                  l.jsx(it, {
                    className: "focus:outline-none",
                    children: l.jsx(nb, {
                      tabInfo: h
                    })
                  }),
                  l.jsx(it, {
                    className: "focus:outline-none",
                    children: l.jsx(ob, {
                      tabInfo: h
                    })
                  }),
                  l.jsx(it, {
                    className: "focus:outline-none",
                    children: l.jsx(db, {
                      tabInfo: h
                    })
                  }),
                  l.jsx(it, {
                    className: "focus:outline-none",
                    children: l.jsx(gb, {})
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
  var Mi = mc("popup"), Ys = gc("popup", (e) => Mi.postMessage(e));
  Mi.onMessage(Ys.handleMessage);
  var { sendMessage: yb, onMessage: tv } = Ys;
  xc(Ys);
  const wb = () => {
    const [e, t] = u.useState(false), n = async () => {
      if (!e)
        try {
          t(true);
          let [r] = await chrome.tabs.query({
            active: true,
            currentWindow: true
          });
          await yb("openSidePanel", {
            windowId: r.windowId
          }, "background"), ge.success("Ready to assist you!", {
            duration: 2e3
          }), window.close();
        } catch {
          t(false), ge.error("Unable to start the app");
        }
    };
    return l.jsx("div", {
      className: "flex flex-row items-center gap-2 w-full",
      children: l.jsxs("button", {
        onClick: n,
        disabled: e,
        className: `group w-full flex items-center justify-between px-3 py-2.5
                   bg-neutral-500 hover:bg-neutral-600
                   text-white text-xs font-medium
                   rounded-lg
                   shadow-sm dark:shadow-slate-900/30
                   focus:outline-none focus:ring-2 focus:ring-neutral-500 focus:ring-offset-1
                   disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:bg-neutral-500`,
        "aria-label": "Open Sidebar",
        children: [
          l.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e ? l.jsxs("svg", {
                className: "h-3.5 w-3.5 animate-spin",
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                children: [
                  l.jsx("circle", {
                    className: "opacity-25",
                    cx: "12",
                    cy: "12",
                    r: "10",
                    stroke: "currentColor",
                    strokeWidth: "4"
                  }),
                  l.jsx("path", {
                    className: "opacity-75",
                    fill: "currentColor",
                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  })
                ]
              }) : l.jsx("svg", {
                className: "w-3.5 h-3.5",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: 2,
                stroke: "currentColor",
                children: l.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12"
                })
              }),
              l.jsx("span", {
                children: e ? "Opening..." : "Open Sidebar"
              })
            ]
          }),
          l.jsx("svg", {
            className: "w-3.5 h-3.5 opacity-70 group-hover:opacity-100",
            fill: "none",
            viewBox: "0 0 24 24",
            strokeWidth: 2,
            stroke: "currentColor",
            children: l.jsx("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              d: "M8.25 4.5l7.5 7.5-7.5 7.5"
            })
          })
        ]
      })
    });
  };
  kb = function({ languages: e, value: t, label: n = "Interface Language", favoriteKey: r = Ut.INTERFACE_FAVORITES, onSelect: s = null }) {
    const [a, o] = u.useState(false), [i, c] = u.useState(""), [d, f] = u.useState([]), h = u.useRef(null), g = u.useRef(null), m = u.useCallback(async () => {
      try {
        const v = await ec(r);
        f(v);
      } catch {
        f([]);
      }
    }, [
      r
    ]);
    u.useEffect(() => {
      m();
    }, [
      m
    ]), u.useEffect(() => {
      const v = (k) => {
        h.current && !h.current.contains(k.target) && (o(false), c(""));
      };
      let w;
      return a && (document.addEventListener("mousedown", v), w = setTimeout(() => {
        var _a3;
        return (_a3 = g.current) == null ? void 0 : _a3.focus();
      }, 50)), () => {
        clearTimeout(w), document.removeEventListener("mousedown", v);
      };
    }, [
      a
    ]);
    const p = u.useCallback(async (v) => {
      const w = d.includes(v) ? d.filter((k) => k !== v) : [
        ...d,
        v
      ];
      f(w), await tc(w, r);
    }, [
      d,
      r
    ]), x = u.useMemo(() => {
      if (!i.trim())
        return e;
      const v = i.toLowerCase();
      return e.filter((w) => w.name.toLowerCase().includes(v) || w.code && w.code.toLowerCase().includes(v));
    }, [
      e,
      i
    ]), b = u.useMemo(() => e.filter((v) => d.includes(v.code)), [
      e,
      d
    ]);
    u.useEffect(() => {
      const v = (w, k) => {
        k === "local" && w[r] && m();
      };
      return chrome.storage.onChanged.addListener(v), () => chrome.storage.onChanged.removeListener(v);
    }, [
      r,
      m
    ]);
    const y = u.useMemo(() => e.find((v) => v.code === t), [
      e,
      t
    ]);
    return l.jsxs("div", {
      className: "relative",
      ref: h,
      children: [
        n && l.jsx("label", {
          className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
          children: n
        }),
        l.jsxs("button", {
          type: "button",
          onClick: () => o(!a),
          className: "w-full flex items-center justify-between gap-2 px-2.5 py-2 text-xs bg-white border border-gray-300 rounded hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-slate-800 dark:border-gray-600 dark:hover:border-gray-500",
          children: [
            l.jsx("span", {
              className: "truncate text-gray-900 dark:text-slate-100",
              children: y ? y.name : "Select language"
            }),
            l.jsx(Wc, {
              className: "w-4 h-4 text-gray-400 dark:text-slate-500 flex-shrink-0"
            })
          ]
        }),
        a && l.jsxs("div", {
          className: "absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded shadow-lg max-h-80 flex flex-col dark:bg-slate-800 dark:border-gray-600 dark:shadow-slate-900/30",
          children: [
            l.jsx("div", {
              className: "p-2 border-b border-gray-200 dark:border-slate-700",
              children: l.jsxs("div", {
                className: "relative",
                children: [
                  l.jsx(ko, {
                    className: "absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                  }),
                  l.jsx("input", {
                    ref: g,
                    type: "text",
                    value: i,
                    onChange: (v) => c(v.target.value),
                    placeholder: "Search languages...",
                    className: "w-full pl-7 pr-2 py-1.5 text-xs border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-slate-900 dark:border-gray-600 dark:text-slate-100 dark:placeholder-slate-500"
                  })
                ]
              })
            }),
            l.jsx("div", {
              className: "px-2 py-1 border-b border-gray-200 dark:border-slate-700",
              children: l.jsx("span", {
                className: "text-xs text-gray-400 dark:text-slate-500",
                children: s ? "Click name to switch \xB7 \u2B50 to favorite" : "Click a language to add/remove from favorites"
              })
            }),
            l.jsxs("div", {
              className: "overflow-y-auto flex-1",
              children: [
                b.length > 0 && !i && l.jsxs(l.Fragment, {
                  children: [
                    l.jsx("div", {
                      className: "px-2 py-1.5 bg-gray-50 border-b border-gray-200 dark:bg-slate-900 dark:border-slate-700",
                      children: l.jsxs("div", {
                        className: "flex items-center gap-1",
                        children: [
                          l.jsx($o, {
                            className: "w-3 h-3 text-yellow-500"
                          }),
                          l.jsx("span", {
                            className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                            children: "Favorites"
                          })
                        ]
                      })
                    }),
                    b.map((v) => l.jsx(ho, {
                      language: v,
                      isSelected: t === v.code,
                      isFavorite: true,
                      onToggleFavorite: p,
                      onSelect: s
                    }, `fav-${v.code}`)),
                    l.jsx("div", {
                      className: "border-b border-gray-200 dark:border-slate-700"
                    })
                  ]
                }),
                x.length > 0 ? x.map((v) => l.jsx(ho, {
                  language: v,
                  isSelected: t === v.code,
                  isFavorite: d.includes(v.code),
                  onToggleFavorite: p,
                  onSelect: s
                }, v.code)) : l.jsx("div", {
                  className: "p-4 text-center text-xs text-gray-500 dark:text-slate-400",
                  children: "No languages found"
                })
              ]
            })
          ]
        })
      ]
    });
  };
  function ho({ language: e, isSelected: t, isFavorite: n, onToggleFavorite: r, onSelect: s }) {
    const a = n ? "Remove from favorites" : "Add to favorites";
    return l.jsxs("div", {
      className: "flex items-center px-1",
      children: [
        l.jsx("button", {
          type: "button",
          onClick: (o) => {
            o.stopPropagation(), r(e.code);
          },
          title: a,
          "aria-label": a,
          className: "flex-shrink-0 p-1.5 rounded hover:bg-yellow-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500",
          children: n ? l.jsx($o, {
            className: "w-4 h-4 text-yellow-500"
          }) : l.jsx(Hg, {
            className: "w-4 h-4 text-gray-400 dark:text-slate-500"
          })
        }),
        l.jsxs("div", {
          className: "flex-1 min-w-0 flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700",
          onClick: () => s ? s(e.code) : r(e.code),
          title: s ? `Switch to ${e.name}` : a,
          children: [
            l.jsxs("div", {
              className: "flex-1 min-w-0",
              children: [
                l.jsx("div", {
                  className: "text-xs text-gray-900 dark:text-slate-100 truncate",
                  children: e.name
                }),
                l.jsx("div", {
                  className: "text-xs text-gray-500 dark:text-slate-400",
                  children: e.code || "default"
                })
              ]
            }),
            t && l.jsx(xt, {
              className: "w-4 h-4 text-blue-600 flex-shrink-0"
            })
          ]
        })
      ]
    });
  }
  Eb = function({ suggestions: e, favoriteKey: t }) {
    if (!e.length)
      return null;
    const n = async (r) => {
      await nc(r, t) && ge.success("Added to favorites");
    };
    return l.jsxs("div", {
      className: "flex flex-wrap items-center gap-1.5 mt-2",
      children: [
        l.jsx("span", {
          className: "text-xs text-gray-400 dark:text-slate-500",
          children: "Quick add:"
        }),
        e.map((r) => l.jsxs("button", {
          type: "button",
          onClick: () => n(r.code),
          className: "px-2 py-1 text-xs rounded border border-dashed border-gray-300 dark:border-slate-600 text-gray-600 dark:text-slate-300 hover:border-blue-500 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-700",
          children: [
            "+ ",
            jo(r)
          ]
        }, r.code))
      ]
    });
  };
  function jb({ lang: e, isActive: t, isChanging: n = false, onClick: r }) {
    const s = e.code ? e.code.toUpperCase() : "DEFAULT";
    return l.jsx("button", {
      type: "button",
      onClick: r,
      disabled: t || n,
      className: `
        px-2.5 py-1.5 text-xs rounded border
        ${t ? "bg-blue-600 border-blue-600 text-white" : n ? "bg-gray-50 dark:bg-slate-900 border-gray-200 dark:border-slate-700 text-gray-400 dark:text-slate-500" : "bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-slate-700"}
      `,
      children: l.jsxs("div", {
        className: "flex items-center gap-1",
        children: [
          l.jsx("span", {
            children: "\u2B50"
          }),
          l.jsx("span", {
            children: s
          }),
          l.jsx("span", {
            className: "opacity-70 truncate max-w-[50px]",
            children: jo(e)
          })
        ]
      })
    });
  }
  function po({ favs: e, value: t, isChanging: n = false, onSwitch: r, languages: s, favoriteKey: a, suggestions: o }) {
    const i = e.length > 0;
    return l.jsxs(l.Fragment, {
      children: [
        i && l.jsx("div", {
          className: "flex flex-wrap gap-1.5 mb-2",
          children: e.map((c) => l.jsx(jb, {
            lang: c,
            isActive: t === c.code,
            isChanging: n,
            onClick: () => r(c.code)
          }, c.code || "default"))
        }),
        l.jsx(kb, {
          languages: s,
          value: t,
          label: null,
          favoriteKey: a
        }),
        !i && l.jsx(Eb, {
          suggestions: o,
          favoriteKey: a
        })
      ]
    });
  }
  function Nb() {
    const [e, t] = ee(), { interfaceLanguage: n, interfaceFavorites: r, outputFavorites: s, outputLanguage: a } = e.languageSettings, [o, i] = u.useState(false), c = t.isNotebookLMAuthenticated();
    u.useEffect(() => {
      t.loadLanguageSettings(), t.loadInterfaceFavorites(), t.loadOutputFavorites(), t.loadOutputLanguage();
      const b = (y, v) => {
        v === "local" && (y[Ut.INTERFACE_FAVORITES] && t.loadInterfaceFavorites(), y[Ut.OUTPUT_FAVORITES] && t.loadOutputFavorites(), y[hc] && t.loadLanguageSettings(), y[pc] && t.loadOutputLanguage());
      };
      return chrome.storage.onChanged.addListener(b), () => chrome.storage.onChanged.removeListener(b);
    }, []);
    const d = (b) => {
      t.setInterfaceLanguage(b);
      const y = wn.interfaceLanguages.find((v) => v.code === b);
      ge.success(`Interface: ${(y == null ? void 0 : y.name) || b}`);
    }, f = async (b) => {
      if (!c) {
        ge.error("Connect to NotebookLM first");
        return;
      }
      if (!o) {
        i(true);
        try {
          await t.changeOutputLanguage(b), await t.loadOutputLanguage();
          const y = wn.outputLanguages.find((v) => v.code === b);
          ge.success(`Output: ${(y == null ? void 0 : y.name) || b || "Default"}`), chrome.tabs.query({
            active: true,
            currentWindow: true
          }, (v) => {
            var _a3;
            ((_a3 = v[0]) == null ? void 0 : _a3.id) && chrome.tabs.reload(v[0].id);
          });
        } catch (y) {
          console.error("Failed to change output language:", y), ge.error("Failed to change output language");
        } finally {
          i(false);
        }
      }
    }, h = r.slice(0, 5), g = s.slice(0, 5), m = h.length > 0, p = g.length > 0, x = !m && !p;
    return l.jsxs("div", {
      className: "bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg",
      children: [
        l.jsxs("div", {
          className: "px-3 py-2.5 border-b border-gray-100 dark:border-slate-700 flex items-center justify-between",
          children: [
            l.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                l.jsx(rc, {
                  className: "w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                }),
                l.jsx("span", {
                  className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                  children: "Languages"
                })
              ]
            }),
            l.jsxs("a", {
              href: "#/settings?tab=language",
              className: "flex items-center gap-1 px-1.5 py-0.5 text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 rounded",
              children: [
                l.jsx(No, {
                  className: "w-3 h-3"
                }),
                l.jsx("span", {
                  children: "Settings"
                })
              ]
            })
          ]
        }),
        l.jsxs("div", {
          className: "p-3 space-y-3",
          children: [
            x && l.jsx("p", {
              className: "text-xs text-gray-500 dark:text-slate-400",
              children: "\u2B50 Star the languages you switch between \u2014 they appear here for one-click switching and in the floating widget on NotebookLM pages."
            }),
            l.jsxs("div", {
              children: [
                l.jsxs("div", {
                  className: "mb-2 flex items-center gap-1.5",
                  children: [
                    l.jsx("span", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: "Interface"
                    }),
                    m && l.jsx("span", {
                      className: "text-xs text-gray-400 dark:text-slate-500",
                      children: "\xB7 click to switch"
                    })
                  ]
                }),
                l.jsx(po, {
                  favs: h,
                  value: n,
                  onSwitch: d,
                  languages: wn.interfaceLanguages,
                  favoriteKey: Ut.INTERFACE_FAVORITES,
                  suggestions: sc
                })
              ]
            }),
            l.jsxs("div", {
              className: "pt-1",
              children: [
                l.jsxs("div", {
                  className: "mb-2 flex items-center gap-1.5",
                  children: [
                    l.jsx("span", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: "Output"
                    }),
                    p && c && l.jsx("span", {
                      className: "text-xs text-gray-400 dark:text-slate-500",
                      children: "\xB7 click to switch"
                    }),
                    o && l.jsx("span", {
                      className: "text-xs text-blue-600",
                      children: "\u25CF"
                    })
                  ]
                }),
                c ? l.jsx(po, {
                  favs: g,
                  value: a,
                  isChanging: o,
                  onSwitch: f,
                  languages: wn.outputLanguages,
                  favoriteKey: Ut.OUTPUT_FAVORITES,
                  suggestions: ac
                }) : l.jsx("div", {
                  className: "bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded px-2.5 py-2",
                  children: l.jsx("p", {
                    className: "text-xs text-amber-700 dark:text-amber-200",
                    children: "Connect NotebookLM first"
                  })
                })
              ]
            })
          ]
        })
      ]
    });
  }
  function Xs({ enabled: e, onChange: t, title: n, description: r }) {
    return l.jsxs("div", {
      className: "flex items-start justify-between gap-3",
      children: [
        l.jsxs("div", {
          className: "flex-1",
          children: [
            n && l.jsx("div", {
              className: "text-sm font-medium text-gray-900 dark:text-slate-100",
              children: n
            }),
            r && l.jsx("div", {
              className: "text-xs text-gray-500 dark:text-slate-400",
              children: r
            })
          ]
        }),
        l.jsx(Wm, {
          checked: e,
          onChange: t,
          className: `${e ? "bg-blue-600" : "bg-gray-200 dark:bg-slate-600"}
          relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors`,
          children: l.jsx("span", {
            className: `${e ? "translate-x-5" : "translate-x-1"}
            inline-block h-3 w-3 transform rounded-full bg-white transition-transform`
          })
        })
      ]
    });
  }
  const mo = [
    {
      value: "top-left",
      label: "Top Left",
      className: "top-2 left-3"
    },
    {
      value: "top-right",
      label: "Top Right",
      className: "top-2 right-3"
    },
    {
      value: "middle-left",
      label: "Middle Left",
      className: "top-1/2 -translate-y-1/2 left-3"
    },
    {
      value: "middle-right",
      label: "Middle Right",
      className: "top-1/2 -translate-y-1/2 right-3"
    },
    {
      value: "bottom-left",
      label: "Bottom Left",
      className: "bottom-2 left-3"
    },
    {
      value: "bottom-right",
      label: "Bottom Right",
      className: "bottom-2 right-3"
    }
  ], Cb = {
    "top-left": "top-1.5 left-1.5",
    "top-right": "top-1.5 right-1.5",
    "middle-left": "top-1/2 -translate-y-1/2 left-1.5",
    "middle-right": "top-1/2 -translate-y-1/2 right-1.5",
    "bottom-left": "bottom-1.5 left-1.5",
    "bottom-right": "bottom-1.5 right-1.5"
  };
  Sb = function() {
    var _a3;
    const [e, t] = ee(), { switcherPosition: n, switcherOrientation: r, switcherVisible: s } = e.languageSettings;
    return u.useEffect(() => {
      t.loadSwitcherPosition(), t.loadSwitcherOrientation(), t.loadSwitcherVisible();
    }, []), l.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: l.jsxs("div", {
        className: "p-3",
        children: [
          l.jsxs("div", {
            className: "flex items-center gap-1.5 mb-3",
            children: [
              l.jsx(Ec, {
                className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
              }),
              l.jsx("h2", {
                className: "font-medium text-gray-900 dark:text-slate-100",
                children: "Language Switcher Widget"
              })
            ]
          }),
          l.jsxs("div", {
            className: "space-y-3",
            children: [
              l.jsx(Xs, {
                enabled: s,
                onChange: (a) => t.setSwitcherVisible(a),
                title: "Show Switcher",
                description: "Display the floating language switcher widget"
              }),
              l.jsxs("div", {
                className: s ? "" : "opacity-50 pointer-events-none",
                children: [
                  l.jsx("div", {
                    className: "relative w-full h-24 rounded-lg border-2 border-gray-300 dark:border-slate-600 bg-gray-50 dark:bg-slate-900",
                    children: mo.map(({ value: a, label: o, className: i }) => n === a ? l.jsx("div", {
                      className: `absolute ${Cb[a]} rounded border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 p-1 shadow-sm`,
                      children: l.jsxs("div", {
                        className: `flex ${r === "vertical" ? "flex-col" : ""} gap-0.5`,
                        children: [
                          l.jsx("span", {
                            className: "text-[7px] leading-none px-1 py-0.5 rounded bg-blue-600 text-white",
                            children: "EN"
                          }),
                          l.jsx("span", {
                            className: "text-[7px] leading-none px-1 py-0.5 rounded bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-slate-300",
                            children: "ES"
                          }),
                          l.jsx("span", {
                            className: "text-[7px] leading-none px-1 py-0.5 rounded bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-slate-300",
                            children: "FR"
                          })
                        ]
                      })
                    }, a) : l.jsx("button", {
                      onClick: () => t.setSwitcherPosition(a),
                      disabled: !s,
                      title: o,
                      className: `absolute w-3 h-3 rounded-full cursor-pointer ${i} bg-gray-300 dark:bg-slate-500 hover:bg-blue-400 dark:hover:bg-blue-500`,
                      "aria-label": o
                    }, a))
                  }),
                  l.jsx("p", {
                    className: "text-xs text-gray-500 dark:text-slate-400 mt-1.5 text-center",
                    children: (_a3 = mo.find((a) => a.value === n)) == null ? void 0 : _a3.label
                  })
                ]
              }),
              l.jsxs("div", {
                className: s ? "" : "opacity-50 pointer-events-none",
                children: [
                  l.jsx("label", {
                    className: "text-xs text-gray-600 dark:text-slate-400 mb-2 block",
                    children: "Orientation"
                  }),
                  l.jsxs("div", {
                    className: "grid grid-cols-2 gap-2",
                    children: [
                      l.jsxs("button", {
                        onClick: () => t.setSwitcherOrientation("horizontal"),
                        disabled: !s,
                        className: `flex flex-col items-center gap-1.5 px-3 py-2 rounded border ${r === "horizontal" ? "bg-blue-600 text-white border-blue-600" : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-blue-500 hover:text-blue-600"}`,
                        children: [
                          l.jsx("div", {
                            className: "flex gap-1",
                            children: [
                              0,
                              1,
                              2
                            ].map((a) => l.jsx("div", {
                              className: `w-4 h-1.5 rounded-sm ${r === "horizontal" ? "bg-blue-300" : "bg-gray-300 dark:bg-slate-500"}`
                            }, a))
                          }),
                          l.jsx("span", {
                            className: "text-xs font-medium",
                            children: "Horizontal"
                          })
                        ]
                      }),
                      l.jsxs("button", {
                        onClick: () => t.setSwitcherOrientation("vertical"),
                        disabled: !s,
                        className: `flex flex-col items-center gap-1.5 px-3 py-2 rounded border ${r === "vertical" ? "bg-blue-600 text-white border-blue-600" : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-blue-500 hover:text-blue-600"}`,
                        children: [
                          l.jsx("div", {
                            className: "flex flex-col gap-0.5",
                            children: [
                              0,
                              1,
                              2
                            ].map((a) => l.jsx("div", {
                              className: `w-4 h-1.5 rounded-sm ${r === "vertical" ? "bg-blue-300" : "bg-gray-300 dark:bg-slate-500"}`
                            }, a))
                          }),
                          l.jsx("span", {
                            className: "text-xs font-medium",
                            children: "Vertical"
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            ]
          })
        ]
      })
    });
  };
  function jt({ icon: e, title: t, description: n, enabled: r, onChange: s, locked: a = false }) {
    return l.jsxs("div", {
      className: "flex items-center justify-between gap-3 -mx-1.5 px-1.5 py-1 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700/40",
      children: [
        l.jsxs("div", {
          className: "flex items-center gap-2.5 min-w-0",
          children: [
            l.jsx("span", {
              className: "flex items-center justify-center w-7 h-7 flex-shrink-0 rounded-md bg-gray-100 dark:bg-slate-700 text-gray-500 dark:text-slate-300",
              children: l.jsx(e, {
                className: "w-4 h-4"
              })
            }),
            l.jsxs("div", {
              className: "min-w-0",
              children: [
                l.jsxs("div", {
                  className: "flex items-center gap-1",
                  children: [
                    l.jsx("span", {
                      className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                      children: t
                    }),
                    a && l.jsxs("span", {
                      className: "inline-flex items-center gap-0.5 px-1 rounded text-[9px] font-semibold uppercase tracking-wide text-amber-700 bg-amber-100 dark:text-amber-300 dark:bg-amber-900/40",
                      children: [
                        l.jsx(du, {
                          className: "w-2.5 h-2.5"
                        }),
                        "Pro"
                      ]
                    })
                  ]
                }),
                l.jsx("div", {
                  className: "text-[10px] text-gray-400 dark:text-slate-500",
                  children: n
                })
              ]
            })
          ]
        }),
        l.jsx(Xs, {
          enabled: r,
          onChange: s
        })
      ]
    });
  }
  function go({ label: e }) {
    return l.jsxs("div", {
      className: "flex items-center gap-2 mt-3 mb-1.5 first:mt-0",
      children: [
        l.jsx("span", {
          className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-slate-500",
          children: e
        }),
        l.jsx("div", {
          className: "flex-1 h-px bg-gray-100 dark:bg-slate-700"
        })
      ]
    });
  }
  Tb = function() {
    const [e, t] = ee(), { tagsVisibleHome: n, tagsVisibleDetail: r, allTagsBarVisible: s, detailOutputsVisible: a, detailActionsVisible: o } = e.languageSettings, i = t.isLicensed();
    return u.useEffect(() => {
      t.loadTagsVisibleHome(), t.loadTagsVisibleDetail(), t.loadAllTagsBarVisible(), t.loadDetailOutputsVisible(), t.loadDetailActionsVisible(), t.loadDetailLogoVisible();
    }, []), l.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: l.jsxs("div", {
        className: "p-3",
        children: [
          l.jsxs("div", {
            className: "flex items-center justify-between mb-2",
            children: [
              l.jsxs("div", {
                className: "flex items-center gap-1.5",
                children: [
                  l.jsx(Kc, {
                    className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
                  }),
                  l.jsx("h2", {
                    className: "font-medium text-gray-900 dark:text-slate-100",
                    children: "Page Display"
                  })
                ]
              }),
              l.jsx("a", {
                href: "#/tags",
                target: "_blank",
                className: "text-xs text-blue-600 dark:text-blue-400 hover:underline",
                children: "Manage tags \u2192"
              })
            ]
          }),
          l.jsx(go, {
            label: "Home page"
          }),
          l.jsx(jt, {
            icon: $c,
            title: "Tags Bar",
            description: "Filter bar at top of home",
            enabled: s,
            onChange: (c) => t.setAllTagsBarVisible(c)
          }),
          l.jsx(jt, {
            icon: Yt,
            title: "Card Tags",
            description: "Tags on each notebook card",
            enabled: n,
            onChange: (c) => t.setTagsVisibleHome(c)
          }),
          l.jsx(go, {
            label: "Notebook page"
          }),
          l.jsx(jt, {
            icon: Eo,
            title: "Detail Tags",
            description: "Tags inside a notebook",
            enabled: r,
            onChange: (c) => t.setTagsVisibleDetail(c)
          }),
          l.jsx(jt, {
            icon: oc,
            title: "Outputs",
            description: "Artifact counts (quizzes, notes\u2026)",
            enabled: a,
            onChange: (c) => t.setDetailOutputsVisible(c)
          }),
          l.jsx(jt, {
            icon: Pc,
            title: "Quick actions",
            description: "Generate, find duplicates, open",
            enabled: o,
            onChange: (c) => t.setDetailActionsVisible(c)
          }),
          l.jsx(jt, {
            icon: yu,
            title: "Attribution logo",
            description: i ? "NLMTools.com badge on the panel" : "Upgrade to hide the badge",
            locked: !i,
            enabled: t.getEffectiveDetailLogoVisible(),
            onChange: (c) => {
              if (!i) {
                zn("hide_logo");
                return;
              }
              t.setDetailLogoVisible(c);
            }
          }),
          l.jsx("p", {
            className: "mt-3 text-[10px] text-gray-400 dark:text-slate-500",
            children: "Shown on notebooklm.google.com"
          })
        ]
      })
    });
  };
  $b = function() {
    const [e, t] = ee(), { tabBehaviorAfterImport: n, openTabsInBackground: r } = e.languageSettings;
    u.useEffect(() => {
      t.loadTabBehaviorAfterImport(), t.loadOpenTabsInBackground();
    }, []);
    const s = [
      {
        value: "both",
        label: "Both Tabs",
        description: "Open NotebookLM and extension page"
      },
      {
        value: "notebooklm",
        label: "NotebookLM Only",
        description: "Open only the NotebookLM website"
      },
      {
        value: "internal",
        label: "Extension Only",
        description: "Open only the extension page"
      },
      {
        value: "none",
        label: "None (Silent)",
        description: "Do not open any tabs"
      }
    ];
    return l.jsx("div", {
      className: "bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30",
      children: l.jsxs("div", {
        className: "p-3",
        children: [
          l.jsxs("div", {
            className: "flex items-center gap-1.5 mb-3",
            children: [
              l.jsx(lc, {
                className: "w-3.5 h-3.5 text-gray-500 dark:text-slate-400"
              }),
              l.jsx("h2", {
                className: "font-medium text-gray-900 dark:text-slate-100",
                children: "Tab Behavior After Import"
              })
            ]
          }),
          l.jsxs("div", {
            className: "space-y-3",
            children: [
              l.jsxs("div", {
                children: [
                  l.jsx("label", {
                    className: "text-xs text-gray-600 dark:text-slate-400 mb-2 block",
                    children: "Choose what tabs open after adding content to a notebook"
                  }),
                  l.jsx("div", {
                    className: "grid grid-cols-2 gap-2",
                    children: s.map(({ value: a, label: o, description: i }) => l.jsxs("button", {
                      onClick: () => t.setTabBehaviorAfterImport(a),
                      className: `px-3 py-2 text-left rounded border ${n === a ? "bg-blue-600 text-white border-blue-600" : "bg-white dark:bg-slate-800 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:border-blue-500"}`,
                      children: [
                        l.jsx("div", {
                          className: "text-xs font-medium",
                          children: o
                        }),
                        l.jsx("div", {
                          className: `text-xs ${n === a ? "text-blue-100" : "text-gray-500 dark:text-slate-400"}`,
                          children: i
                        })
                      ]
                    }, a))
                  })
                ]
              }),
              l.jsx(Xs, {
                enabled: r,
                onChange: (a) => t.setOpenTabsInBackground(a),
                title: "Open tabs in background",
                description: "Tabs open without switching focus"
              }),
              l.jsx("div", {
                className: "p-2 bg-gray-50 dark:bg-slate-900 rounded border border-gray-200 dark:border-slate-700",
                children: l.jsx("p", {
                  className: "text-xs text-gray-600 dark:text-slate-400",
                  children: "The extension page is always accessible via the sidepanel or popup"
                })
              })
            ]
          })
        ]
      })
    });
  };
  Rb = function({ tabs: e, defaultIndex: t = 0 }) {
    return l.jsxs(Ws, {
      defaultIndex: t,
      children: [
        l.jsx(zs, {
          className: "flex p-0.5 bg-neutral-100 dark:bg-slate-700 rounded-md",
          children: e.map((n) => l.jsxs(Ci, {
            className: $e("flex items-center justify-center gap-1.5 px-2 py-1.5 rounded text-xs font-medium flex-1", "focus:outline-none", "text-neutral-700 dark:text-slate-300", "data-[selected]:bg-white dark:data-[selected]:bg-slate-800", "data-[selected]:text-neutral-900 dark:data-[selected]:text-slate-100", "data-[selected]:shadow-sm dark:data-[selected]:shadow-slate-900/30"),
            children: [
              l.jsx(n.icon, {
                className: "w-3 h-3"
              }),
              n.name
            ]
          }, n.name))
        }),
        l.jsx(Gs, {
          className: "mt-3",
          children: e.map((n) => l.jsx(it, {
            className: "focus:outline-none",
            children: n.content
          }, n.name))
        })
      ]
    });
  };
  function Ab() {
    const e = window.location.pathname.includes("sidepanel.html"), n = window.location.href.includes("popup=true");
    return l.jsxs(lx, {
      children: [
        l.jsx(Mx, {
          titleTemplate: "%s",
          children: l.jsx("title", {
            children: "Home"
          })
        }),
        l.jsxs("div", {
          className: "flex flex-col space-y-3",
          children: [
            !e && n && l.jsx(wb, {}),
            l.jsx(Ux, {}),
            l.jsx(vb, {}),
            l.jsx(Rb, {
              tabs: [
                {
                  name: "Overview",
                  icon: tu,
                  content: l.jsxs("div", {
                    className: "space-y-3",
                    children: [
                      l.jsx(Nb, {}),
                      l.jsx(Sb, {})
                    ]
                  })
                },
                {
                  name: "Settings",
                  icon: No,
                  content: l.jsxs("div", {
                    className: "space-y-3",
                    children: [
                      l.jsx(Tb, {}),
                      l.jsx($b, {})
                    ]
                  })
                }
              ]
            })
          ]
        })
      ]
    });
  }
  const Pb = j.lazy(() => Ae(() => import("./chunk-71715948.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-71715948.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-10b7446f.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Ob = j.lazy(() => Ae(() => import("./chunk-edb45d65.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-edb45d65.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-10b7446f.js","assets/chunk-378f9272.js","assets/chunk-bd8bbb31.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Lb = j.lazy(() => Ae(() => import("./chunk-26a96105.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-26a96105.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-4c77bdf2.js","assets/chunk-95b0b380.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-d4733473.js","assets/chunk-3daa5dc5.js","assets/chunk-10b7446f.js","assets/chunk-378f9272.js","assets/chunk-b5767d08.js","assets/chunk-57988b21.js","assets/chunk-234b1720.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Ib = j.lazy(() => Ae(() => import("./chunk-fc2109f5.js").then(async (m) => {
    await m.__tla;
    return m;
  }).then((e) => e.N), ["assets/chunk-fc2109f5.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-4c77bdf2.js","assets/chunk-95b0b380.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-378f9272.js","assets/chunk-3daa5dc5.js","assets/chunk-b5767d08.js","assets/chunk-bd7b16ee.js","assets/chunk-57988b21.js","assets/chunk-de7ca15a.js","assets/chunk-b81ff817.js","assets/chunk-1302cd21.js","assets/chunk-e153acea.js"])), Fb = j.lazy(() => Ae(() => import("./chunk-265f4969.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-265f4969.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-de7ca15a.js","assets/chunk-3daa5dc5.js","assets/chunk-b5767d08.js","assets/chunk-7d0f6285.js","assets/chunk-234b1720.js","assets/chunk-57988b21.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Mb = j.lazy(() => Ae(() => import("./chunk-1c7a4b9f.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-1c7a4b9f.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Db = j.lazy(() => Ae(() => import("./chunk-35515f86.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-35515f86.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-9b02a51a.js","assets/chunk-602992a9.js","assets/chunk-e3c02cf0.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), _b = j.lazy(() => Ae(() => import("./chunk-cc3b3940.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-cc3b3940.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-5518d26c.js","assets/chunk-de7ca15a.js","assets/chunk-5a4465c9.js","assets/chunk-57988b21.js","assets/chunk-234b1720.js","assets/chunk-1784b260.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Bb = j.lazy(() => Ae(() => import("./chunk-97e434c9.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-97e434c9.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-cfcef7af.js","assets/chunk-57988b21.js","assets/chunk-1302cd21.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Hb = j.lazy(() => Ae(() => import("./chunk-e7ac136f.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-e7ac136f.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-3daa5dc5.js","assets/chunk-1302cd21.js","assets/chunk-bd8bbb31.js","assets/chunk-4ab815d8.js","assets/chunk-de7ca15a.js","assets/chunk-7d0f6285.js","assets/chunk-234b1720.js","assets/chunk-57988b21.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Ub = j.lazy(() => Ae(() => import("./chunk-41a67e6e.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-41a67e6e.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-5518d26c.js","assets/chunk-de7ca15a.js","assets/chunk-5a4465c9.js","assets/chunk-57988b21.js","assets/chunk-234b1720.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js"])), Vb = [
    {
      path: "/login",
      isPublicRoute: true,
      component: Pb
    },
    {
      path: "/profile",
      isPublicRoute: false,
      component: Ob
    },
    {
      path: "/context-menu-preview",
      isPublicRoute: true,
      component: Db
    },
    {
      path: "/notebooklm-config",
      isPublicRoute: true,
      component: Mb
    },
    {
      path: "/notebooklm",
      isPublicRoute: true,
      component: Lb
    },
    {
      path: "/notebook/:id",
      isPublicRoute: true,
      component: Ib
    },
    {
      path: "/tags",
      isPublicRoute: true,
      component: Fb
    },
    {
      path: "/podcast",
      isPublicRoute: true,
      component: Bb
    },
    {
      path: "/prompts",
      isPublicRoute: true,
      component: Hb
    },
    {
      path: "/backup",
      isPublicRoute: true,
      component: Ub
    },
    {
      path: "/settings",
      isPublicRoute: true,
      component: _b
    },
    {
      path: "/",
      isPublicRoute: true,
      component: Ab
    }
  ];
  nv = function() {
    return l.jsx(u.Suspense, {
      fallback: l.jsx("div", {
        className: "p-4 text-xs text-gray-500",
        children: "Loading..."
      }),
      children: l.jsx(Ed, {
        children: Vb.map((e) => {
          const t = e.component;
          return e.isPublicRoute ? l.jsx(Dr, {
            path: e.path,
            element: l.jsx(t, {})
          }, e.path) : l.jsx(Dr, {
            path: e.path,
            element: l.jsx(Ld, {
              children: l.jsx(t, {})
            })
          }, e.path);
        })
      })
    });
  };
  rv = function({ children: e }) {
    return $i(), e;
  };
});
export {
  zs as $,
  nv as A,
  is as B,
  Ic as C,
  ki as D,
  On as E,
  Qc as F,
  tb as G,
  Yb as H,
  su as I,
  eb as J,
  Kt as K,
  Ei as L,
  rb as M,
  wd as N,
  ab as O,
  Ln as P,
  fm as Q,
  Ks as R,
  de as S,
  rv as T,
  lb as U,
  sb as V,
  ub as W,
  cb as X,
  Hx as Y,
  _x as Z,
  Ws as _,
  __tla,
  Ox as a,
  Ci as a0,
  Gs as a1,
  it as a2,
  To as a3,
  In as a4,
  Eb as a5,
  kb as a6,
  Si as a7,
  Wg as a8,
  Ig as a9,
  Rb as aa,
  $b as ab,
  Sb as ac,
  Tb as ad,
  $o as ae,
  Hg as af,
  pu as ag,
  fb as ah,
  mb as ai,
  pb as aj,
  zx as ak,
  Vx as al,
  Ec as am,
  lx as b,
  ia as c,
  Mx as d,
  Gn as e,
  So as f,
  Ti as g,
  oa as h,
  hm as i,
  qe as j,
  Ux as k,
  Yt as l,
  Kc as m,
  qs as n,
  du as o,
  Dt as p,
  Kb as q,
  Xb as r,
  yu as s,
  vn as t,
  ms as u,
  Im as v,
  xt as w,
  yn as x,
  pe as y,
  bi as z
};
