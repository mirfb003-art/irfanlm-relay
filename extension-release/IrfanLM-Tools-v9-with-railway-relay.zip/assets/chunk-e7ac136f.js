import { r as a, j as e, u as re, M as se, J as c, U as G, P as xe, X as ue, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { ae as ge, af as pe, h as he, i as be, z as fe, Q as ye, b as ke, d as je, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { P as ve, __tla as __tla_2 } from "./chunk-3daa5dc5.js";
import { az as w } from "./chunk-68adfa56.js";
import { C as Ne, __tla as __tla_3 } from "./chunk-1302cd21.js";
import { C as ae, __tla as __tla_4 } from "./chunk-bd8bbb31.js";
import { s as we, E as Se, __tla as __tla_5 } from "./chunk-4ab815d8.js";
import { L as Ce, __tla as __tla_6 } from "./chunk-de7ca15a.js";
import { C as Pe, __tla as __tla_7 } from "./chunk-7d0f6285.js";
import { A as Ee, __tla as __tla_8 } from "./chunk-234b1720.js";
import { A as Le, __tla as __tla_9 } from "./chunk-57988b21.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let Ze;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })()
]).then(async () => {
  function Ie({ prompt: s, isPinned: r, onTogglePin: S, onEdit: n, onDelete: x, selectionMode: i, isSelected: u, onSelect: m, usageCount: f }) {
    const [g, y] = a.useState(false);
    return e.jsxs("div", {
      className: "flex items-start gap-2 p-2 rounded-lg border border-gray-200 dark:border-slate-700 hover:border-gray-300 dark:hover:border-slate-500 bg-white dark:bg-slate-800",
      children: [
        i && e.jsx("input", {
          type: "checkbox",
          checked: u,
          onChange: () => m(s.id),
          "aria-label": `Select prompt: ${s.title}`,
          className: "h-4 w-4 mt-0.5 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-1 cursor-pointer flex-shrink-0"
        }),
        e.jsxs("div", {
          className: "flex-1 min-w-0",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                s.shortcode && e.jsx("span", {
                  className: "shrink-0 px-1.5 py-0.5 text-xs font-mono rounded text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800",
                  children: s.shortcode
                }),
                e.jsx("span", {
                  className: "text-xs font-medium text-gray-900 dark:text-slate-100 truncate",
                  title: s.title,
                  children: s.title
                }),
                f > 0 && e.jsxs("span", {
                  className: "text-xs text-gray-400 dark:text-slate-500 ml-auto shrink-0",
                  title: "Times inserted via / shortcut",
                  children: [
                    f,
                    "x used"
                  ]
                })
              ]
            }),
            e.jsx("p", {
              onClick: () => y((o) => !o),
              role: "button",
              tabIndex: 0,
              onKeyDown: (o) => {
                (o.key === "Enter" || o.key === " ") && (o.preventDefault(), y((h) => !h));
              },
              "aria-expanded": g,
              "aria-label": "Toggle full prompt text",
              className: `text-xs text-gray-500 dark:text-slate-400 mt-0.5 cursor-pointer ${g ? "" : "line-clamp-2"}`,
              children: s.text
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-0.5 shrink-0",
          children: [
            e.jsx("button", {
              onClick: () => S(s.id),
              className: `p-1 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 ${r ? "text-amber-500 dark:text-amber-400" : "text-gray-400 dark:text-slate-500 hover:text-amber-500 dark:hover:text-amber-400 hover:bg-gray-100 dark:hover:bg-slate-700"}`,
              title: r ? "Unpin" : "Pin",
              "aria-label": r ? `Unpin prompt: ${s.title}` : `Pin prompt: ${s.title}`,
              children: r ? e.jsx(ge, {
                className: "w-3.5 h-3.5"
              }) : e.jsx(pe, {
                className: "w-3.5 h-3.5"
              })
            }),
            e.jsx("button", {
              onClick: () => n(s),
              className: "p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-blue-500",
              title: "Edit",
              "aria-label": `Edit prompt: ${s.title}`,
              children: e.jsx(ve, {
                className: "w-3.5 h-3.5"
              })
            }),
            e.jsx("button", {
              onClick: () => x(s.id),
              className: "p-1 text-gray-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 rounded focus:outline-none focus:ring-1 focus:ring-blue-500",
              title: "Delete",
              "aria-label": `Delete prompt: ${s.title}`,
              children: e.jsx(he, {
                className: "w-3.5 h-3.5"
              })
            })
          ]
        })
      ]
    });
  }
  const Te = a.memo(Ie);
  function _e({ isOpen: s, onClose: r, onSubmit: S, editingPrompt: n, isLoading: x }) {
    const [, i] = re(), u = a.useRef(null), [m, f] = a.useState(""), [g, y] = a.useState(""), [o, h] = a.useState(""), [p, L] = a.useState(""), [C, D] = a.useState(""), [N, j] = a.useState(""), O = a.useMemo(() => {
      const d = i.getAllPrompts(), v = new Set(d.map((A) => A.category).filter(Boolean));
      return v.size === 0 && v.add("Custom"), [
        ...v
      ];
    }, [
      s
    ]);
    a.useEffect(() => {
      var _a;
      s && (n ? (f(n.category || ""), y(""), h(((_a = n.shortcode) == null ? void 0 : _a.replace(/^\//, "")) || ""), L(n.title || ""), D(n.text || "")) : (f(O[0] || "Custom"), y(""), h(""), L(""), D("")), j(""));
    }, [
      s,
      n
    ]), a.useEffect(() => {
      var _a;
      m === "__custom__" && ((_a = u.current) == null ? void 0 : _a.focus());
    }, [
      m
    ]);
    const R = (d) => {
      const v = d.replace(/^\//, "").toLowerCase().replace(/[^a-z0-9-]/g, "");
      if (h(v), v) {
        const A = i.validateShortcode(`/${v}`, n == null ? void 0 : n.id);
        j(A || "");
      } else
        j("");
    }, I = m === "__custom__" ? g.trim() : m, $ = I && I.length <= w.CATEGORY_MAX_LENGTH && p.trim() && C.trim() && p.trim().length <= w.TITLE_MAX_LENGTH && C.trim().length <= w.TEXT_MAX_LENGTH && !N, M = (d) => {
      d.preventDefault(), !(!$ || x) && S({
        category: I,
        shortcode: o ? `/${o}` : "",
        title: p.trim(),
        text: C.trim()
      }, n == null ? void 0 : n.id);
    };
    return e.jsxs(be, {
      open: s,
      onClose: r,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(fe, {
            className: "w-full max-w-sm bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsx(ye, {
                className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                children: n ? "Edit Prompt" : "Add Prompt"
              }),
              e.jsxs("form", {
                onSubmit: M,
                className: "mt-3 flex flex-col gap-3",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "prompt-category",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: "Category"
                      }),
                      e.jsxs("select", {
                        id: "prompt-category",
                        value: m,
                        onChange: (d) => f(d.target.value),
                        className: "w-full py-1.5 pl-2 pr-7 rounded-md border border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-700 dark:text-slate-100",
                        children: [
                          O.map((d) => e.jsx("option", {
                            value: d,
                            children: d
                          }, d)),
                          e.jsx("option", {
                            value: "__custom__",
                            children: "+ New category"
                          })
                        ]
                      }),
                      m === "__custom__" && e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("input", {
                            id: "prompt-custom-category",
                            ref: u,
                            type: "text",
                            value: g,
                            onChange: (d) => y(d.target.value),
                            placeholder: "Category name",
                            maxLength: w.CATEGORY_MAX_LENGTH,
                            className: "mt-1.5 w-full py-1.5 px-2 rounded-md border border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-700 dark:text-slate-100"
                          }),
                          e.jsxs("p", {
                            className: "text-xs text-gray-400 dark:text-slate-400 mt-0.5 text-right",
                            "aria-live": "polite",
                            children: [
                              g.length,
                              "/",
                              w.CATEGORY_MAX_LENGTH
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsxs("label", {
                        htmlFor: "prompt-shortcode",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: [
                          "Shortcode ",
                          e.jsx("span", {
                            className: "text-gray-400 dark:text-slate-400",
                            children: "(optional)"
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-1",
                        children: [
                          e.jsx("span", {
                            className: "text-xs text-gray-400 dark:text-slate-400 font-mono",
                            children: "/"
                          }),
                          e.jsx("input", {
                            id: "prompt-shortcode",
                            type: "text",
                            value: o,
                            onChange: (d) => R(d.target.value),
                            placeholder: "e.g. myquery",
                            maxLength: 20,
                            "aria-describedby": N ? "shortcode-error" : void 0,
                            className: "flex-1 py-1.5 px-2 rounded-md border border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs font-mono bg-white dark:bg-slate-700 dark:text-slate-100"
                          })
                        ]
                      }),
                      N && e.jsx("p", {
                        id: "shortcode-error",
                        className: "text-xs text-red-500 dark:text-red-400 mt-0.5",
                        children: N
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "prompt-title",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: "Title"
                      }),
                      e.jsx("input", {
                        id: "prompt-title",
                        type: "text",
                        value: p,
                        onChange: (d) => L(d.target.value),
                        placeholder: "Prompt title",
                        maxLength: w.TITLE_MAX_LENGTH,
                        required: true,
                        autoFocus: true,
                        className: "w-full py-1.5 px-2 rounded-md border border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-700 dark:text-slate-100"
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-gray-400 dark:text-slate-400 mt-0.5 text-right",
                        "aria-live": "polite",
                        children: [
                          p.length,
                          "/",
                          w.TITLE_MAX_LENGTH
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "prompt-text",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: "Prompt text"
                      }),
                      e.jsx("textarea", {
                        id: "prompt-text",
                        value: C,
                        onChange: (d) => D(d.target.value),
                        placeholder: "Enter the prompt text...",
                        maxLength: w.TEXT_MAX_LENGTH,
                        required: true,
                        rows: 4,
                        className: "w-full py-1.5 px-2 rounded-md border border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs bg-white dark:bg-slate-700 dark:text-slate-100 resize-none"
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-gray-400 dark:text-slate-400 mt-0.5 text-right",
                        "aria-live": "polite",
                        children: [
                          C.length,
                          "/",
                          w.TEXT_MAX_LENGTH
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "flex justify-end gap-2 mt-1",
                    children: [
                      e.jsx("button", {
                        type: "button",
                        onClick: r,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500",
                        children: "Cancel"
                      }),
                      e.jsx("button", {
                        type: "submit",
                        disabled: !$ || x,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-1 focus:ring-blue-500",
                        children: x ? "Saving..." : "Save"
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  function ee({ isOpen: s, onClose: r, onConfirm: S, isDeleting: n, title: x, message: i, confirmLabel: u = "Delete", confirmVariant: m = "danger", hideWarning: f = false }) {
    const g = f ? i : `${i}
This action cannot be undone.`;
    return e.jsx(Ne, {
      open: s,
      onClose: r,
      onConfirm: S,
      title: x,
      message: g,
      confirmLabel: n ? `${u}...` : u,
      variant: m === "primary" ? "primary" : "danger",
      disabled: n
    });
  }
  function De() {
    return e.jsx("div", {
      className: "flex flex-col gap-1.5",
      children: [
        1,
        2,
        3
      ].map((s) => e.jsx("div", {
        className: "flex items-start gap-2 p-2 rounded-lg border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800",
        children: e.jsxs("div", {
          className: "flex-1 min-w-0",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                e.jsx("div", {
                  className: "w-12 h-5 rounded bg-gray-200 dark:bg-slate-600 shrink-0"
                }),
                e.jsx("div", {
                  className: "w-24 h-4 rounded bg-gray-100 dark:bg-slate-700"
                }),
                e.jsx("div", {
                  className: "w-3.5 h-3.5 rounded bg-gray-100 dark:bg-slate-700 ml-auto shrink-0"
                })
              ]
            }),
            e.jsxs("div", {
              className: "mt-1 space-y-1",
              children: [
                e.jsx("div", {
                  className: "w-full h-3 rounded bg-gray-100 dark:bg-slate-700"
                }),
                e.jsx("div", {
                  className: "w-2/3 h-3 rounded bg-gray-100 dark:bg-slate-700"
                })
              ]
            })
          ]
        })
      }, s))
    });
  }
  function Me({ onAdd: s, onSample: r }) {
    return e.jsxs("div", {
      className: "border-2 border-dashed border-gray-300 dark:border-slate-600 rounded-lg p-6 text-center",
      children: [
        e.jsx("div", {
          className: "mx-auto w-10 h-10 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center mb-3",
          "aria-hidden": "true",
          children: e.jsx(ae, {
            className: "w-5 h-5 text-gray-400 dark:text-slate-500"
          })
        }),
        e.jsx("h3", {
          className: "text-xs font-medium text-gray-900 dark:text-slate-100",
          children: "No prompts yet"
        }),
        e.jsx("p", {
          className: "text-xs text-gray-500 dark:text-slate-400 mt-1",
          children: "Create prompts with shortcodes for quick insertion via / in NotebookLM chat"
        }),
        e.jsx("button", {
          onClick: s,
          className: "mt-3 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700",
          children: "Add Prompt"
        }),
        r && e.jsx("button", {
          onClick: r,
          className: "block mx-auto mt-2 text-xs text-blue-600 dark:text-blue-400 hover:underline",
          children: "Try sample prompts"
        })
      ]
    });
  }
  function Ae() {
    return e.jsxs("div", {
      className: "border-2 border-dashed border-gray-300 dark:border-slate-600 rounded-lg p-6 text-center",
      children: [
        e.jsx("div", {
          className: "mx-auto w-10 h-10 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center mb-3",
          "aria-hidden": "true",
          children: e.jsx(se, {
            className: "w-5 h-5 text-gray-400 dark:text-slate-500"
          })
        }),
        e.jsx("h3", {
          className: "text-xs font-medium text-gray-900 dark:text-slate-100",
          children: "No matching prompts"
        }),
        e.jsx("p", {
          className: "text-xs text-gray-500 dark:text-slate-400 mt-1",
          children: "Try a different search term"
        })
      ]
    });
  }
  function Fe() {
    const [s, r] = re(), [S, n] = a.useState(false), [x, i] = a.useState(null), [u, m] = a.useState(null), [f, g] = a.useState(false), [y, o] = a.useState(false), [h, p] = a.useState([]), [L, C] = a.useState(false), [D, N] = a.useState(false), [j, O] = a.useState(""), [R, I] = a.useState(false), [$, M] = a.useState(false), [d, v] = a.useState(false), A = a.useRef(null);
    a.useEffect(() => {
      s.promptsManager.isLoaded || r.loadPrompts(), r.loadUsageData();
    }, []), a.useEffect(() => {
      if (!y)
        return;
      const t = (l) => {
        l.key === "Escape" && (p([]), o(false));
      };
      return document.addEventListener("keydown", t), () => document.removeEventListener("keydown", t);
    }, [
      y
    ]);
    const P = r.getAllPrompts(), J = P.length >= w.MAX_PROMPTS, F = a.useMemo(() => {
      if (!j.trim())
        return P;
      const t = j.toLowerCase();
      return P.filter((l) => l.title.toLowerCase().includes(t) || l.shortcode && l.shortcode.toLowerCase().includes(t) || l.text.toLowerCase().includes(t));
    }, [
      P,
      j
    ]), { pinned: z, grouped: q } = a.useMemo(() => we(F), [
      F
    ]), B = async (t, l) => {
      g(true);
      try {
        l ? (await r.updatePrompt(l, t), c.success("Prompt updated")) : (await r.savePrompt(t), c.success("Prompt created"), G(() => r.isLicensed())), n(false), i(null);
      } catch (E) {
        c.error(E.message || "Failed to save prompt");
      } finally {
        g(false);
      }
    }, Q = (t) => {
      i(t), n(true);
    }, H = async () => {
      if (u) {
        N(true);
        try {
          await r.deletePrompt(u), m(null), c.success("Prompt deleted"), G(() => r.isLicensed());
        } catch (t) {
          c.error(t.message || "Failed to delete prompt");
        } finally {
          N(false);
        }
      }
    }, Y = async () => {
      N(true);
      try {
        await r.bulkDeletePrompts(h);
        const t = h.length;
        p([]), o(false), C(false), c.success(`${t} prompt${t > 1 ? "s" : ""} deleted`), G(() => r.isLicensed());
      } catch (t) {
        c.error(t.message || "Failed to delete prompts");
      } finally {
        N(false);
      }
    }, K = () => {
      const l = (j.trim() ? F : P).map((T) => T.id), E = l.length > 0 && l.every((T) => h.includes(T));
      p(E ? [] : l);
    }, V = (t) => {
      r.togglePinPrompt(t).catch(() => c.error("Failed to update pin"));
    }, X = (t) => {
      p((l) => l.includes(t) ? l.filter((E) => E !== t) : [
        ...l,
        t
      ]);
    }, W = (t = null) => {
      i(t), n(true);
    }, U = () => {
      n(false), i(null);
    }, k = () => {
      o(true), p([]);
    }, Z = () => {
      o(false), p([]);
    }, le = () => {
      const t = r.exportPromptsJson(), l = JSON.stringify(t, null, 2), E = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), T = new Blob([
        l
      ], {
        type: "application/json;charset=utf-8;"
      }), b = URL.createObjectURL(T), _ = document.createElement("a");
      _.href = b, _.download = `prompts-backup-${E}.json`, _.click(), URL.revokeObjectURL(b), c.success(`Exported to prompts-backup-${E}.json`), G(() => r.isLicensed());
    }, oe = async (t) => {
      var _a;
      const l = (_a = t.target.files) == null ? void 0 : _a[0];
      if (l) {
        if (l.size > 1e6) {
          c.error("File too large (max 1MB)"), t.target.value = "";
          return;
        }
        I(true);
        try {
          const E = await l.text();
          let T;
          try {
            T = JSON.parse(E);
          } catch {
            c.error("Invalid JSON file");
            return;
          }
          const b = await r.importPromptsJson(T);
          if (b.error)
            c.error(b.error);
          else {
            const _ = [
              `${b.imported} imported`
            ];
            b.duplicated > 0 && _.push(`${b.duplicated} already existed`), b.skipped > 0 && _.push(`${b.skipped} invalid`), b.capped > 0 && _.push(`${b.capped} over limit`), (b.imported > 0 ? c.success : c.info)(_.join(", ")), b.imported > 0 && G(() => r.isLicensed());
          }
        } catch {
          c.error("Failed to import JSON file");
        } finally {
          t.target.value = "", I(false);
        }
      }
    }, de = async () => {
      v(true);
      try {
        const t = r.generateSampleJson(), l = await r.importPromptsJson(t);
        M(false), l.error ? c.error(l.error) : c.success(`${l.imported} sample prompts loaded`);
      } catch {
        c.error("Failed to load sample prompts");
      } finally {
        v(false);
      }
    }, ne = s.promptsManager.usageData || {}, ie = u ? P.find((t) => t.id === u) : null, te = j.trim() ? F : P, ce = te.length > 0 && te.every((t) => h.includes(t.id)), me = s.promptsManager.isLoaded;
    return {
      isFormOpen: S,
      editingPrompt: x,
      deleteConfirmId: u,
      setDeleteConfirmId: m,
      isSaving: f,
      isSelectMode: y,
      selectedIds: h,
      bulkDeleteConfirm: L,
      setBulkDeleteConfirm: C,
      isDeleting: D,
      searchQuery: j,
      setSearchQuery: O,
      allPrompts: P,
      isAtLimit: J,
      filteredPrompts: F,
      pinned: z,
      groupedPrompts: q,
      handleSubmit: B,
      handleEdit: Q,
      confirmDelete: H,
      confirmBulkDelete: Y,
      toggleSelectAll: K,
      handleTogglePin: V,
      handleSelect: X,
      openForm: W,
      closeForm: U,
      startSelectMode: k,
      cancelSelectMode: Z,
      handleExport: le,
      handleImportFile: oe,
      handleSampleImport: de,
      isImporting: R,
      sampleConfirmOpen: $,
      setSampleConfirmOpen: M,
      isSampleImporting: d,
      fileInputRef: A,
      usageData: ne,
      deletePromptObj: ie,
      allSelected: ce,
      isLoaded: me
    };
  }
  function Oe() {
    const { isFormOpen: s, deleteConfirmId: r, setDeleteConfirmId: S, isSaving: n, isSelectMode: x, selectedIds: i, bulkDeleteConfirm: u, setBulkDeleteConfirm: m, isDeleting: f, searchQuery: g, setSearchQuery: y, allPrompts: o, isAtLimit: h, filteredPrompts: p, pinned: L, groupedPrompts: C, handleSubmit: D, handleEdit: N, confirmDelete: j, confirmBulkDelete: O, toggleSelectAll: R, handleTogglePin: I, handleSelect: $, openForm: M, closeForm: d, startSelectMode: v, cancelSelectMode: A, handleExport: P, handleImportFile: J, handleSampleImport: F, isImporting: z, sampleConfirmOpen: q, setSampleConfirmOpen: B, isSampleImporting: Q, fileInputRef: H, usageData: Y, deletePromptObj: K, allSelected: V, isLoaded: X, editingPrompt: W } = Fe(), U = (k) => {
      var _a;
      return e.jsx(Te, {
        prompt: k,
        isPinned: !!k.pinned,
        onTogglePin: I,
        onEdit: N,
        onDelete: (Z) => S(Z),
        selectionMode: x,
        isSelected: i.includes(k.id),
        onSelect: $,
        usageCount: ((_a = Y[k.id]) == null ? void 0 : _a.count) || 0
      }, k.id);
    };
    return e.jsxs(ke, {
      children: [
        e.jsx(je, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "Prompts"
          })
        }),
        e.jsxs("div", {
          className: "flex flex-col gap-3",
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    !x && e.jsx("a", {
                      href: "#/notebooklm",
                      className: "p-1 rounded-md text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                      title: "Back to Notebooks",
                      children: e.jsx(Pe, {
                        className: "w-4 h-4"
                      })
                    }),
                    x ? e.jsxs("span", {
                      className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                      children: [
                        i.length,
                        " selected"
                      ]
                    }) : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(ae, {
                          className: "w-4 h-4 text-gray-500 dark:text-slate-400"
                        }),
                        e.jsx("h1", {
                          className: "text-sm font-medium text-gray-900 dark:text-slate-100",
                          children: "Prompts"
                        }),
                        e.jsxs("span", {
                          className: "px-1.5 py-0.5 text-xs font-medium text-gray-500 dark:text-slate-400 bg-gray-100 dark:bg-slate-700 rounded",
                          children: [
                            o.length,
                            "/",
                            w.MAX_PROMPTS
                          ]
                        })
                      ]
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "flex items-center gap-1.5",
                  children: x ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("button", {
                        onClick: R,
                        className: "px-2.5 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                        children: V ? "Deselect All" : "Select All"
                      }),
                      e.jsx("button", {
                        onClick: () => m(true),
                        disabled: i.length === 0,
                        className: "px-2.5 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed",
                        children: "Delete"
                      }),
                      e.jsx("button", {
                        onClick: A,
                        className: "px-2.5 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                        children: "Cancel"
                      })
                    ]
                  }) : e.jsxs(e.Fragment, {
                    children: [
                      o.length > 0 && e.jsx("button", {
                        onClick: v,
                        className: "px-2.5 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                        children: "Select"
                      }),
                      e.jsx("button", {
                        onClick: () => {
                          var _a;
                          return (_a = H.current) == null ? void 0 : _a.click();
                        },
                        disabled: z,
                        className: "p-1.5 rounded-md text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed",
                        title: "Import Prompts",
                        "aria-label": "Import Prompts",
                        children: e.jsx(Ee, {
                          className: "w-4 h-4"
                        })
                      }),
                      e.jsx("button", {
                        onClick: P,
                        disabled: o.length === 0,
                        className: "p-1.5 rounded-md text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed",
                        title: "Export Prompts",
                        "aria-label": "Export Prompts",
                        children: e.jsx(Le, {
                          className: "w-4 h-4"
                        })
                      }),
                      e.jsxs("button", {
                        onClick: () => M(),
                        disabled: h,
                        className: "flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed",
                        title: h ? "Maximum 100 prompts reached" : "Add new prompt",
                        children: [
                          e.jsx(xe, {
                            className: "w-3.5 h-3.5"
                          }),
                          "Add"
                        ]
                      }),
                      e.jsx("input", {
                        ref: H,
                        type: "file",
                        accept: ".json",
                        className: "hidden",
                        onChange: J
                      })
                    ]
                  })
                })
              ]
            }),
            e.jsx(Ce, {}),
            !x && e.jsx("div", {
              className: "bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-2",
              children: e.jsxs("p", {
                className: "text-xs text-blue-700 dark:text-blue-200",
                children: [
                  "Type ",
                  e.jsx("span", {
                    className: "font-mono font-medium",
                    children: "/"
                  }),
                  " in NotebookLM chat to quickly insert a prompt. Use shortcodes like",
                  " ",
                  e.jsx("span", {
                    className: "font-mono font-medium",
                    children: "/sum"
                  }),
                  " for instant access."
                ]
              })
            }),
            o.length > 0 && e.jsxs("div", {
              className: "relative",
              children: [
                e.jsx(se, {
                  className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                }),
                e.jsx("input", {
                  type: "text",
                  value: g,
                  onChange: (k) => y(k.target.value),
                  placeholder: "Search prompts...",
                  "aria-label": "Search prompts",
                  className: "w-full pl-8 pr-8 py-1.5 text-xs rounded-md border border-gray-300 dark:border-gray-600 shadow-sm dark:shadow-slate-900/30 bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                }),
                g && e.jsx("button", {
                  onClick: () => y(""),
                  "aria-label": "Clear search",
                  className: "absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300",
                  children: e.jsx(ue, {
                    className: "w-3.5 h-3.5"
                  })
                })
              ]
            }),
            g && e.jsxs("p", {
              className: "text-xs text-gray-500 dark:text-slate-400 -mt-1.5",
              children: [
                "Showing ",
                p.length,
                " of ",
                o.length
              ]
            }),
            L.length > 0 && e.jsxs("div", {
              children: [
                e.jsx("h2", {
                  className: "text-xs font-medium text-amber-600 dark:text-amber-400 mb-1.5 px-0.5",
                  children: "Pinned"
                }),
                e.jsx("div", {
                  className: "flex flex-col gap-1.5",
                  children: L.map(U)
                })
              ]
            }),
            C.map((k) => e.jsxs("div", {
              children: [
                e.jsx("h2", {
                  className: "text-xs font-medium text-gray-500 dark:text-slate-400 mb-1.5 px-0.5",
                  children: k.category
                }),
                e.jsx("div", {
                  className: "flex flex-col gap-1.5",
                  children: k.items.map(U)
                })
              ]
            }, k.category)),
            !X && o.length === 0 && e.jsx(De, {}),
            X && o.length === 0 && e.jsx(Me, {
              onAdd: () => M(),
              onSample: () => B(true)
            }),
            X && o.length > 0 && p.length === 0 && e.jsx(Ae, {})
          ]
        }),
        e.jsx(ee, {
          isOpen: !!r,
          onClose: () => S(null),
          onConfirm: j,
          isDeleting: f,
          title: "Delete Prompt",
          message: `Delete "${K == null ? void 0 : K.title}"?`
        }),
        e.jsx(ee, {
          isOpen: u,
          onClose: () => m(false),
          onConfirm: O,
          isDeleting: f,
          title: "Delete Prompts",
          message: `Delete ${i.length} prompt${i.length > 1 ? "s" : ""}?`
        }),
        e.jsx(ee, {
          isOpen: q,
          onClose: () => B(false),
          onConfirm: F,
          isDeleting: Q,
          title: "Load Sample Prompts",
          message: "Add 3 sample prompts to your collection?",
          confirmLabel: "Load",
          hideWarning: true,
          confirmVariant: "primary"
        }),
        e.jsx(_e, {
          isOpen: s,
          onClose: d,
          onSubmit: D,
          editingPrompt: W,
          isLoading: n
        })
      ]
    });
  }
  Ze = function() {
    return e.jsx(Se, {
      children: e.jsx(Oe, {})
    });
  };
});
export {
  __tla,
  Ze as default
};
