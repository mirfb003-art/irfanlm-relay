// ─────────────────────────────────────────────────────────────────────────
// Lovable Bridge (custom addon) — background communication proxy
//
// Lets an external web app (e.g. https://your-app.lovable.app, or a local
// dev build on http://localhost:<any-port>) talk to this extension so it
// can drive NotebookLM on the user's behalf:
//   - PING                 → extension version + auth status
//   - GET_AUTH_PAYLOAD     → saved YT_NLM session fields (at, bl, f.sid, ...)
//   - LIST_NOTEBOOKS       → notebooks the user has opened, from storage (no RPC exists for this)
//   - EXECUTE_RPC           → batchexecute() proxy, but ONLY for RPCs on ALLOWED_RPC_NAMES below
//   - FETCH_STUDIO_ARTIFACT → list Studio artifacts, or fetch/upload one
//
// SECURITY: EXECUTE_RPC is allow-listed on purpose — without it, any origin
// matched by externally_connectable could call arbitrary NotebookLM RPCs as
// the signed-in user. Cloudinary uploads require a pre-signed { timestamp,
// signature } from the caller's own server; the extension never sees or
// computes with a raw Cloudinary API secret.
//
// Reachable two ways (both funnel into the same dispatcher below):
//   1) Directly, via chrome.runtime.connect/sendMessage(EXTENSION_ID, ...)
//      from an allowed origin — gated by manifest "externally_connectable".
//   2) Indirectly, via window.postMessage on the page, relayed by
//      nlm-lovable-bridge.js (the content script) using regular
//      chrome.runtime.sendMessage (same-extension, internal messaging).
//
// Reads the SAME chrome.storage.local keys the main extension bundle
// already writes (see chunk-68adfa56.js / chunk-5e2e563c.js):
//   YT_NOTEBOOKLM_TOOLS_CONFIG_NLM          → single active-account object
//   YT_NOTEBOOKLM_TOOLS_CONFIG_NLM_ACCOUNTS → { accounts, activeAccount }
// so no duplicate auth flow is needed — whatever account is active inside
// NotebookLM Tools is what the web app will drive.
// ─────────────────────────────────────────────────────────────────────────

(() => {
  "use strict";

  // ── constants ────────────────────────────────────────────────────────

  const CONFIG_NLM_KEY = "YT_NOTEBOOKLM_TOOLS_CONFIG_NLM";
  const CONFIG_NLM_ACCOUNTS_KEY = "YT_NOTEBOOKLM_TOOLS_CONFIG_NLM_ACCOUNTS";

  // Bridge-owned registry of notebooks the user has actually opened, kept up
  // to date by nlm-notebook-tracker.js on notebooklm.google.com. Deliberately
  // a separate key from the vendor bundle's own project cache so this never
  // collides with (or depends on the undocumented shape of) their storage.
  const KNOWN_NOTEBOOKS_KEY = "__nlmBridge_knownNotebooks";

  const RPC_HOST = "notebooklm.google.com";
  const RPC_ENDPOINT = `https://${RPC_HOST}/_/LabsTailwindUi/data/batchexecute`;
  const LIST_ARTIFACTS_RPC = "gArtLc";
  const GET_PROJECT_RPC = "rLM1Ne";
  const DEFAULT_BL = "boq_labs-tailwind-frontend_20250902.08_p1";

  // Only these RPCs may be invoked through EXECUTE_RPC. A web app with the
  // extension ID could otherwise call ANY NotebookLM RPC as the signed-in
  // user (delete notebooks, share sources, etc). Extend deliberately.
  const ALLOWED_RPC_NAMES = new Set([
    LIST_ARTIFACTS_RPC, // gArtLc — list Studio artifacts
    GET_PROJECT_RPC,    // rLM1Ne — get one notebook's details/sources
  ]);
  const ARTIFACT_TYPE = { AUDIO: 1, VIDEO: 3 };
  const ARTIFACT_TYPE_LABEL = {
    1: "Audio", 2: "Report", 3: "Video", 4: "Quiz/Flashcards", 5: "Mind Map",
    7: "Infographic", 8: "Slide Deck", 9: "Data Table", 10: "Quiz", 11: "Flashcards", 12: "Note",
  };
  const STATUS_READY = 3;

  // Guard against blowing up the extension messaging channel with a huge
  // base64 payload. Above this, callers must pass Cloudinary credentials
  // and get a hosted URL back instead of an inline blob.
  const MAX_INLINE_MEDIA_BYTES = 15 * 1024 * 1024; // 15 MB

  // Origins allowed to talk to this bridge. Mirrors manifest.externally_connectable
  // and is re-checked here as defense-in-depth (also covers the postMessage relay
  // path, which manifest.externally_connectable does not gate on its own).
  const ALLOWED_ORIGIN_PATTERNS = [
    /^https:\/\/[a-zA-Z0-9-]+\.lovable\.app$/,
    /^http:\/\/localhost(:\d+)?$/,
  ];

  function isAllowedOrigin(origin) {
    if (!origin) return false;
    return ALLOWED_ORIGIN_PATTERNS.some((re) => re.test(origin));
  }

  // ── shared RPC payload validation ───────────────────────────────────
  //
  // Every path that ends up calling callBatchExecute() — EXECUTE_RPC from
  // the Lovable app, and the internal FETCH_STUDIO_ARTIFACT / sync helpers
  // below — must go through this first. A bare `!rpcName || !notebookId`
  // check let non-string/whitespace values slip through and produced a
  // confusing downstream 400 from NotebookLM's batchexecute endpoint
  // instead of a clear local error, so this validates type + non-empty +
  // allow-list membership up front and always throws a specific message.
  function validateRpcRequest(rpcName, notebookId, params) {
    if (typeof rpcName !== "string" || !rpcName.trim()) {
      throw new Error('Invalid RPC request: "rpcName" is required (expected a non-empty string, e.g. "rLM1Ne" for projects or "gArtLc" for studio items).');
    }
    if (!ALLOWED_RPC_NAMES.has(rpcName)) {
      throw new Error(`Invalid RPC request: "${rpcName}" is not on the allow-list (${[...ALLOWED_RPC_NAMES].join(", ")}).`);
    }
    if (typeof notebookId !== "string" || !notebookId.trim()) {
      throw new Error('Invalid RPC request: "notebookId" is required (expected a non-empty string). Open a notebook on notebooklm.google.com and pass its ID.');
    }
    if (params !== undefined && !Array.isArray(params)) {
      throw new Error('Invalid RPC request: "params" must be an array when provided.');
    }
    return { rpcName: rpcName.trim(), notebookId: notebookId.trim(), params: params || [] };
  }

  // ── storage helpers ─────────────────────────────────────────────────

  async function getActiveAccount() {
    const store = await chrome.storage.local.get([CONFIG_NLM_KEY, CONFIG_NLM_ACCOUNTS_KEY]);

    const multi = store[CONFIG_NLM_ACCOUNTS_KEY];
    if (multi && multi.accounts && multi.activeAccount) {
      const acc = multi.accounts[multi.activeAccount];
      if (acc && acc.token) return acc;
    }

    const single = store[CONFIG_NLM_KEY];
    if (single && single.token) return single;

    return null;
  }

  async function getKnownNotebooks() {
    const store = await chrome.storage.local.get(KNOWN_NOTEBOOKS_KEY);
    const map = store[KNOWN_NOTEBOOKS_KEY] || {};
    return Object.values(map).sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
  }

  // ── RPC client (mirrors bulk-tools-ui.js's own batchexecute client) ──

  async function callBatchExecute(account, notebookId, rpcId, args) {
    const urlParams = new URLSearchParams({
      bl: account.bl || DEFAULT_BL,
      hl: "en",
      "source-path": `/notebook/${encodeURIComponent(notebookId)}`,
      ...(account.fsid ? { "f.sid": account.fsid } : {}),
      ...(Number.isInteger(account.authuser) && account.authuser > 0
        ? { authuser: String(account.authuser) }
        : {}),
    });
    const body = new URLSearchParams({
      rpcids: rpcId,
      "f.req": JSON.stringify([[[rpcId, JSON.stringify(args), null, null]]]),
      at: account.token,
    });

    const res = await fetch(`${RPC_ENDPOINT}?${urlParams}`, {
      method: "POST",
      headers: {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "x-same-domain": "1",
      },
      body,
      credentials: "include",
    });

    const text = await res.text();
    const lines = text.split("\n").filter((l) => l.trim());
    let parsed = null;
    for (const line of lines) {
      try {
        const v = JSON.parse(line);
        if (Array.isArray(v) && v.length > 0) {
          parsed = v;
          break;
        }
      } catch {
        // NotebookLM prefixes each batchexecute response with an anti-XSSI
        // line and length-prefix lines that aren't valid JSON — skip those.
      }
    }
    if (!parsed) {
      throw new Error("Could not read NotebookLM response — is the user logged in on notebooklm.google.com?");
    }

    const d = parsed[0];
    const errCode = d && d[5] ? d[5][0] : null;
    if (errCode != null && errCode !== 0) {
      throw new Error(`NotebookLM RPC error ${errCode} — session may be stale, try reloading notebooklm.google.com`);
    }
    return d && d[2] ? JSON.parse(d[2]) : null;
  }

  // ── lightweight artifact parsing (trimmed mirror of bulk-tools-ui.js) ─

  function safeGet(arr, idx, fallback = null) {
    return Array.isArray(arr) && arr.length > idx ? arr[idx] : fallback;
  }

  function parseDuration(d) {
    return Array.isArray(d) && d.length > 0 ? (d[0] || 0) + (d[1] || 0) / 1e9 : null;
  }

  function parseArtifactRaw(raw) {
    const id = safeGet(raw, 0);
    const title = safeGet(raw, 1) || "Untitled";
    const type = safeGet(raw, 2);
    const status = safeGet(raw, 4);
    if (!id) return null;

    const base = {
      id,
      title,
      type,
      status,
      isReady: status === STATUS_READY,
      typeLabel: ARTIFACT_TYPE_LABEL[type] || "Unknown",
    };

    if (type === ARTIFACT_TYPE.AUDIO) {
      const e = safeGet(raw, 6);
      if (e) {
        base.mediaUrl = safeGet(e, 2);
        base.downloadUrl = safeGet(e, 3);
        base.duration = parseDuration(safeGet(e, 6));
        base.kind = "audio";
      }
    } else if (type === ARTIFACT_TYPE.VIDEO) {
      const t2 = safeGet(raw, 8);
      if (t2) {
        base.mediaUrl = safeGet(t2, 1);
        base.downloadUrl = safeGet(t2, 3);
        base.duration = parseDuration(safeGet(t2, 5));
        base.kind = "video";
      }
    }
    return base;
  }

  async function listStudioArtifacts(account, notebookId) {
    const validated = validateRpcRequest(LIST_ARTIFACTS_RPC, notebookId);
    const data = await callBatchExecute(account, validated.notebookId, LIST_ARTIFACTS_RPC, [
      [2],
      validated.notebookId,
      'NOT artifact.status = "ARTIFACT_STATUS_SUGGESTED"',
    ]);
    if (!Array.isArray(data)) return [];
    const list = Array.isArray(data[0]) ? data[0] : data;
    if (!Array.isArray(list)) return [];
    return list
      .map(parseArtifactRaw)
      .filter((a) => a && a.isReady && a.kind && (a.mediaUrl || a.downloadUrl));
  }

  // ── media fetch + optional Cloudinary upload ──────────────────────────

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result); // data: URL
      reader.onerror = () => reject(new Error("Failed to read media blob"));
      reader.readAsDataURL(blob);
    });
  }

  function sanitizeFilename(name) {
    return (name || "untitled").replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 120);
  }

  function guessExt(kind) {
    if (kind === "video") return ".mp4";
    if (kind === "audio") return ".m4a";
    return "";
  }

  // FIX (v8.0.0): NotebookLM's media CDN does not send CORS headers
  // permitting fetch() from this extension's origin to read response bytes
  // — only chrome.downloads.download() and <video>/<audio> playback are
  // exempt, because they never expose bytes to JS. fetch(mediaUrl).blob()
  // therefore never resolves with usable data here, which is why Cloudinary
  // exports silently failed even though Preview and manual Download worked.
  //
  // Fix: don't fetch the media at all. Cloudinary accepts a remote URL
  // directly in the "file" field and fetches it server-side — no CORS
  // involved, since the browser never touches the response bytes.
  //
  // SECURITY: the extension never sees a Cloudinary API secret and never
  // computes a signature itself. Callers must obtain { timestamp, signature }
  // from their OWN server (e.g. a Supabase Edge Function that holds the
  // secret) and pass those through, along with the matching public_id/folder
  // that were actually signed.
  async function uploadUrlToCloudinary(sourceUrl, upload) {
    const { cloudName, apiKey, timestamp, signature, publicId, folder } = upload;
    if (!cloudName || !apiKey || !timestamp || !signature || !publicId) {
      throw new Error(
        '"upload" must include { cloudName, apiKey, timestamp, signature, publicId } from your own signing endpoint — ' +
          "the extension does not accept or use a raw apiSecret."
      );
    }

    const form = new FormData();
    form.append("file", sourceUrl); // URL string, not a Blob — Cloudinary fetches it itself
    form.append("api_key", apiKey);
    form.append("timestamp", String(timestamp));
    form.append("public_id", publicId);
    if (folder) form.append("folder", folder);
    form.append("signature", signature);

    const uploadUrl = `https://api.cloudinary.com/v1_1/${cloudName}/video/upload`;
    const res = await fetch(uploadUrl, { method: "POST", body: form });
    const json = await res.json().catch(() => null);
    if (!res.ok) throw new Error(json?.error?.message || `Cloudinary upload failed (HTTP ${res.status})`);
    return json.secure_url;
  }

  // NEW (v8.0.0): same remote-URL principle for Telegram. The Bot API
  // accepts a URL directly in the video/audio field and fetches it
  // server-side, so this never needs to read media bytes in the extension
  // either. Pass { botToken, chatId } in payload.telegram to use it.
  async function sendUrlToTelegram(sourceUrl, kind, title, telegram) {
    const { botToken, chatId } = telegram;
    if (!botToken || !chatId) {
      throw new Error('"telegram" must include { botToken, chatId }.');
    }
    const method = kind === "audio" ? "sendAudio" : "sendVideo";
    const fileField = kind === "audio" ? "audio" : "video";
    const endpoint = `https://api.telegram.org/bot${botToken}/${method}`;

    const form = new FormData();
    form.append("chat_id", chatId);
    form.append(fileField, sourceUrl); // URL string — Telegram fetches it server-side
    form.append("caption", (title || "Untitled").slice(0, 1024));
    form.append("supports_streaming", "true");

    const res = await fetch(endpoint, { method: "POST", body: form });
    const json = await res.json().catch(() => null);
    if (!json || !json.ok) {
      throw new Error(json?.description || `Telegram API error (HTTP ${res.status})`);
    }
    return json.result?.message_id ?? null;
  }

  // notebookId/artifactId are now used for more than just the "no mediaUrl
  // supplied" fallback: whenever they're both present we ALWAYS re-resolve
  // a fresh mediaUrl before an upload/send, because these are short-lived
  // signed URLs and a mediaUrl the caller cached even a couple of minutes
  // earlier may already have expired — a likely cause of intermittent
  // export failures even before the CORS issue above.
  async function fetchStudioMedia({ mediaUrl, notebookId, artifactId, title, kind, upload, telegram }, account) {
    let resolvedUrl = mediaUrl;
    let resolvedTitle = title || "untitled";
    let resolvedKind = kind;
    let resolvedDuration = null;

    if (notebookId && artifactId) {
      const artifacts = await listStudioArtifacts(account, notebookId);
      const match = artifacts.find((a) => a.id === artifactId);
      if (!match && !resolvedUrl) throw new Error(`Artifact ${artifactId} not found or not ready`);
      if (match) {
        resolvedUrl = match.mediaUrl || match.downloadUrl || resolvedUrl;
        resolvedTitle = match.title || resolvedTitle;
        resolvedKind = match.kind || resolvedKind;
        resolvedDuration = match.duration ?? null;
      }
    }
    if (!resolvedUrl) throw new Error("No mediaUrl and no resolvable artifactId was provided");

    if (upload && upload.cloudName && upload.apiKey && upload.signature) {
      const secureUrl = await uploadUrlToCloudinary(resolvedUrl, {
        ...upload,
        publicId: upload.publicId || sanitizeFilename(resolvedTitle),
      });
      return { mode: "uploaded", cloudinaryUrl: secureUrl, title: resolvedTitle, kind: resolvedKind };
    }

    if (telegram && telegram.botToken && telegram.chatId) {
      const messageId = await sendUrlToTelegram(resolvedUrl, resolvedKind, resolvedTitle, telegram);
      return { mode: "sent", telegramMessageId: messageId, title: resolvedTitle, kind: resolvedKind };
    }

    // Inline/base64 fallback — kept for parity with earlier versions, but
    // note this path still does fetch(resolvedUrl).blob() under the hood
    // and is subject to the SAME CORS restriction described above. It only
    // has a chance of working if NotebookLM's CDN happens to allow this
    // origin (it generally doesn't). Prefer "upload" or "telegram" above.
    const fileResp = await fetch(resolvedUrl, { credentials: "include" });
    if (!fileResp.ok) throw new Error(`Failed to fetch media (${fileResp.status})`);
    const blob = await fileResp.blob();

    if (blob.size > MAX_INLINE_MEDIA_BYTES) {
      throw new Error(
        `Media is ${(blob.size / 1024 / 1024).toFixed(1)}MB, over the ${MAX_INLINE_MEDIA_BYTES / 1024 / 1024}MB inline limit. ` +
          `Pass "upload": { cloudName, apiKey, timestamp, signature, publicId } or "telegram": { botToken, chatId } to have ` +
          `Cloudinary/Telegram fetch the media directly from its URL instead.`
      );
    }

    const dataUrl = await blobToBase64(blob);
    return { mode: "inline", dataUrl, mimeType: blob.type, title: resolvedTitle, kind: resolvedKind, sizeBytes: blob.size, duration: resolvedDuration };
  }

  // ── dispatcher (shared by both transport paths) ───────────────────────

  async function handleBridgeMessage(msg) {
    const account = await getActiveAccount();

    switch (msg?.type) {
      case "PING": {
        return {
          ok: true,
          version: chrome.runtime.getManifest().version,
          extensionId: chrome.runtime.id,
          authenticated: !!account,
          email: account?.email || null,
        };
      }

      case "GET_AUTH_PAYLOAD": {
        if (!account) return { ok: false, authenticated: false, error: "No active NotebookLM account found. Open notebooklm.google.com and sign in first." };
        return {
          ok: true,
          authenticated: true,
          at: account.token,
          bl: account.bl || DEFAULT_BL,
          "f.sid": account.fsid,
          authuser: account.authuser ?? 0,
          email: account.email,
        };
      }

      case "DEBUG_STATUS": {
        // Same underlying data as GET_AUTH_PAYLOAD, but with the token masked
        // (not raw-secret) and broken out field-by-field, for troubleshooting
        // "why isn't this connecting" without leaking the session token into
        // a debug screen someone might screenshot.
        const notebooks = await getKnownNotebooks();
        if (!account) {
          return {
            ok: true,
            authenticated: false,
            fields: { token: false, bl: false, fsid: false, email: false, authuser: false },
            knownNotebookCount: notebooks.length,
            hint: "No account object in storage at all — open notebooklm.google.com, sign in, and reload that tab (content scripts on already-open tabs don't update until reloaded).",
          };
        }
        const fields = {
          token: !!account.token,
          bl: !!account.bl,
          fsid: !!account.fsid,
          email: !!account.email,
          authuser: account.authuser != null,
        };
        const missing = Object.entries(fields).filter(([, present]) => !present).map(([k]) => k);
        return {
          ok: true,
          authenticated: !!account.token,
          email: account.email || null,
          lastRefreshed: account.lastRefreshed || null,
          fields,
          knownNotebookCount: notebooks.length,
          hint: missing.length
            ? `Account found but missing: ${missing.join(", ")}. Reload notebooklm.google.com while signed in to re-capture these.`
            : "All expected fields present.",
        };
      }

      case "EXECUTE_RPC": {
        if (!account) throw new Error("No active NotebookLM account found");
        const { rpcName, params, notebookId } = validateRpcRequest(
          msg.payload?.rpcName,
          msg.payload?.notebookId,
          msg.payload?.params
        );
        const data = await callBatchExecute(account, notebookId, rpcName, params);
        return { ok: true, data };
      }

      case "LIST_NOTEBOOKS": {
        // Storage-based, NOT an RPC call — NotebookLM has no known "list all
        // notebooks" RPC. This returns notebooks the user has actually opened
        // on notebooklm.google.com, tracked by nlm-notebook-tracker.js.
        const notebooks = await getKnownNotebooks();
        return { ok: true, notebooks };
      }

      case "FETCH_STUDIO_ARTIFACT": {
        if (!account) throw new Error("No active NotebookLM account found");
        const payload = msg.payload || {};
        const mode = payload.mode || "list";

        if (mode === "list") {
          if (!payload.notebookId) throw new Error('"notebookId" is required for mode "list"');
          const artifacts = await listStudioArtifacts(account, payload.notebookId);
          return { ok: true, mode: "list", artifacts };
        }

        if (mode === "media") {
          const result = await fetchStudioMedia(payload, account);
          return { ok: true, ...result };
        }

        throw new Error(`Unknown mode "${mode}" — expected "list" or "media"`);
      }

      default:
        throw new Error(`Unknown bridge message type: ${msg?.type}`);
    }
  }

  // ── transport 1: direct external messaging (chrome.runtime.onMessageExternal) ─

  chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.__nlmBridge) return; // not one of ours — let other listeners handle it

    if (!isAllowedOrigin(sender.origin)) {
      sendResponse({ ok: false, error: `Origin not allowed: ${sender.origin || "unknown"}` });
      return false;
    }

    handleBridgeMessage(msg)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));

    return true; // keep the message channel open for the async response
  });

  // ── transport 2: relayed from nlm-lovable-bridge.js content script ────

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;

    // Transport 3: the extension's own Options page (bridge-status.html).
    // No origin check — this only ever arrives from our own extension pages,
    // never from a web page, so it's trusted by construction.
    if (msg.__nlmBridgeDebug) {
      handleBridgeMessage(msg)
        .then((result) => sendResponse(result))
        .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
      return true;
    }

    if (!msg.__nlmBridgeRelay) return;

    // Relayed messages originate from our own content script, but we still
    // validate the page origin it captured before acting on it.
    if (!isAllowedOrigin(msg.pageOrigin)) {
      sendResponse({ ok: false, error: `Origin not allowed: ${msg.pageOrigin || "unknown"}` });
      return false;
    }

    handleBridgeMessage(msg)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));

    return true;
  });
})();
