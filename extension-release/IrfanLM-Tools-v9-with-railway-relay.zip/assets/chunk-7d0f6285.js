import { r as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
let d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function l({ title: r, titleId: t, ...a }, o) {
    return e.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": t
    }, a), r ? e.createElement("title", {
      id: t
    }, r) : null, e.createElement("path", {
      fillRule: "evenodd",
      d: "M11.78 5.22a.75.75 0 0 1 0 1.06L8.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06l-4.25-4.25a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0Z",
      clipRule: "evenodd"
    }));
  }
  let n;
  n = e.forwardRef(l);
  d = n;
});
export {
  d as C,
  __tla
};
