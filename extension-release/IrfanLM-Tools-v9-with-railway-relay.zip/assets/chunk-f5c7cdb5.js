import { u as D, j as e, X as T, J as P, U as _, a8 as J, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as M, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { u as Z, s as B, __tla as __tla_2 } from "./chunk-b81ff817.js";
import { A as v, __tla as __tla_3 } from "./chunk-57988b21.js";
import { i as Q, z as X, Q as q, __tla as __tla_4 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_5 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let ae;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  ae = function({ isOpen: E, onClose: $, selectedNotebookIds: S = [], notebooks: A = [], onExportSuccess: O }) {
    const [R, h] = D(), { notebookTags: j } = R, { isProcessing: i, setIsProcessing: L, progress: n, setProgress: f, exportFormat: m, setExportFormat: F } = Z({
      isOpen: E
    }), s = A.filter((t) => S.includes(t.id)), z = s.reduce((t, x) => {
      var _a;
      return t + (((_a = x.sources) == null ? void 0 : _a.length) || 0);
    }, 0), C = async () => {
      if (s.length === 0) {
        P.error("No notebooks selected");
        return;
      }
      L(true);
      try {
        m === "json" ? await U() : await I(), O == null ? void 0 : O(s.length), _(() => h.isLicensed());
      } catch (t) {
        P.error(t.message || "Export failed");
      } finally {
        L(false);
      }
    }, U = async () => {
      var _a;
      const t = [], x = s.length, g = /* @__PURE__ */ new Set();
      for (let o = 0; o < s.length; o++) {
        const r = s[o];
        f({
          current: o + 1,
          total: x,
          currentNotebook: r.title,
          phase: "Exporting notebooks",
          sourceProgress: ""
        });
        const a = await h.exportNotebookSources(r.id, (u) => {
          f({
            current: o + 1,
            total: x,
            currentNotebook: r.title,
            phase: "Exporting notebooks",
            sourceProgress: `${u.current}/${u.total} sources`
          });
        }), k = (j.notebookTags[r.id] || []).map((u) => {
          var _a2;
          return (_a2 = j.tags[u]) == null ? void 0 : _a2.name;
        }).filter(Boolean);
        k.forEach((u) => g.add(u)), t.push({
          notebook: a.notebook,
          sources: a.sources,
          tags: k
        });
      }
      const N = Array.from(g).map((o) => Object.values(j.tags).find((r) => r.name === o)).filter(Boolean).map(({ name: o, color: r }) => ({
        name: o,
        color: r
      })), b = {
        version: "1.0",
        type: "bulk",
        exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
        tags: N,
        notebooks: t
      }, l = h.exportSourceFolders();
      if (l && l.folders) {
        const o = {}, r = {};
        for (const a of S)
          l.folders[a] && (o[a] = l.folders[a]), ((_a = l.sourceFolderMap) == null ? void 0 : _a[a]) && (r[a] = l.sourceFolderMap[a]);
        Object.keys(o).length > 0 && (b.sourceFolders = {
          ...l,
          folders: o,
          sourceFolderMap: r
        });
      }
      const c = new Blob([
        JSON.stringify(b, null, 2)
      ], {
        type: "application/json"
      }), d = URL.createObjectURL(c), p = document.createElement("a");
      p.href = d, p.download = `notebooklm-bulk-export-${Date.now()}.json`, p.click(), URL.revokeObjectURL(d);
    }, I = async () => {
      const { default: t } = await J(() => import("./chunk-d45ab30c.js").then((c) => c.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), x = new t(), g = s.length;
      for (let c = 0; c < s.length; c++) {
        const d = s[c];
        f({
          current: c + 1,
          total: g,
          currentNotebook: d.title,
          phase: "Exporting notebooks",
          sourceProgress: ""
        });
        const p = await h.exportNotebookSourcesAsZip(d.id, (a) => {
          f({
            current: c + 1,
            total: g,
            currentNotebook: d.title,
            phase: "Exporting notebooks",
            sourceProgress: `${a.current}/${a.total} sources`
          });
        }), o = B(`${d.emoji || ""} ${d.title}`.trim()), r = await t.loadAsync(p.blob);
        for (const [a, w] of Object.entries(r.files))
          if (!w.dir) {
            const k = await w.async("blob");
            x.file(`${o}/${a}`, k);
          }
      }
      const N = await x.generateAsync({
        type: "blob"
      }), b = URL.createObjectURL(N), l = document.createElement("a");
      l.href = b, l.download = `notebooklm-bulk-export-${Date.now()}.zip`, l.click(), URL.revokeObjectURL(b);
    }, y = () => {
      i || $();
    };
    return e.jsxs(Q, {
      open: E,
      onClose: y,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(X, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(q, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(v, {
                        className: "w-4 h-4"
                      }),
                      "Export Notebooks"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: y,
                    disabled: i,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(T, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: e.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    s.length === 0 ? e.jsxs("div", {
                      className: "text-center py-6",
                      children: [
                        e.jsx(v, {
                          className: "w-8 h-8 text-gray-300 dark:text-slate-600 mx-auto mb-2"
                        }),
                        e.jsx("p", {
                          className: "text-xs text-gray-500 dark:text-slate-400",
                          children: "No notebooks selected"
                        }),
                        e.jsx("p", {
                          className: "text-xs text-gray-400 dark:text-slate-500 mt-1",
                          children: "Select notebooks from the list to export them"
                        })
                      ]
                    }) : e.jsxs(e.Fragment, {
                      children: [
                        e.jsxs("div", {
                          className: "bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border border-gray-200 dark:border-slate-700",
                          children: [
                            e.jsxs("h4", {
                              className: "text-xs font-medium text-gray-900 dark:text-slate-100 mb-2",
                              children: [
                                "Selected Notebooks (",
                                s.length,
                                ")",
                                e.jsxs("span", {
                                  className: "text-gray-500 dark:text-slate-400 font-normal ml-2",
                                  children: [
                                    z,
                                    " total sources"
                                  ]
                                })
                              ]
                            }),
                            e.jsx("div", {
                              className: "max-h-32 overflow-y-auto space-y-1",
                              children: s.map((t) => {
                                var _a;
                                return e.jsxs("div", {
                                  className: "text-xs text-gray-600 dark:text-slate-400 flex items-center gap-2",
                                  children: [
                                    e.jsx("span", {
                                      children: t.emoji
                                    }),
                                    e.jsx("span", {
                                      className: "truncate",
                                      children: t.title
                                    }),
                                    e.jsxs("span", {
                                      className: "text-gray-400 dark:text-slate-500 ml-auto flex-shrink-0",
                                      children: [
                                        ((_a = t.sources) == null ? void 0 : _a.length) || 0,
                                        " sources"
                                      ]
                                    })
                                  ]
                                }, t.id);
                              })
                            })
                          ]
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsx("label", {
                              className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                              children: "Export Format"
                            }),
                            e.jsxs("div", {
                              className: "flex gap-3",
                              children: [
                                e.jsxs("label", {
                                  className: "flex items-center gap-2 cursor-pointer",
                                  children: [
                                    e.jsx("input", {
                                      type: "radio",
                                      name: "exportFormat",
                                      value: "json",
                                      checked: m === "json",
                                      onChange: (t) => F(t.target.value),
                                      className: "h-3.5 w-3.5 text-gray-900 focus:ring-gray-900",
                                      disabled: i
                                    }),
                                    e.jsx("span", {
                                      className: "text-xs text-gray-700 dark:text-slate-300",
                                      children: "JSON (full metadata)"
                                    })
                                  ]
                                }),
                                e.jsxs("label", {
                                  className: "flex items-center gap-2 cursor-pointer",
                                  children: [
                                    e.jsx("input", {
                                      type: "radio",
                                      name: "exportFormat",
                                      value: "zip",
                                      checked: m === "zip",
                                      onChange: (t) => F(t.target.value),
                                      className: "h-3.5 w-3.5 text-gray-900 focus:ring-gray-900",
                                      disabled: i
                                    }),
                                    e.jsx("span", {
                                      className: "text-xs text-gray-700 dark:text-slate-300",
                                      children: "ZIP (Markdown files)"
                                    })
                                  ]
                                })
                              ]
                            })
                          ]
                        }),
                        m === "json" && e.jsxs("div", {
                          className: "text-xs text-gray-500 dark:text-slate-400 space-y-1",
                          children: [
                            e.jsx("p", {
                              children: "Export will download a JSON file containing:"
                            }),
                            e.jsxs("ul", {
                              className: "list-disc list-inside ml-2 space-y-0.5",
                              children: [
                                e.jsx("li", {
                                  children: "All notebook metadata (titles, emojis)"
                                }),
                                e.jsx("li", {
                                  children: "All source titles, URLs, and content"
                                }),
                                e.jsx("li", {
                                  children: "All tags assigned to notebooks"
                                }),
                                e.jsx("li", {
                                  children: "Source folder organization"
                                }),
                                e.jsx("li", {
                                  children: "Can be imported to create new notebooks"
                                })
                              ]
                            })
                          ]
                        }),
                        m === "zip" && e.jsxs("div", {
                          className: "text-xs text-gray-500 dark:text-slate-400 space-y-1",
                          children: [
                            e.jsx("p", {
                              children: "Export will download a ZIP file containing:"
                            }),
                            e.jsxs("ul", {
                              className: "list-disc list-inside ml-2 space-y-0.5",
                              children: [
                                e.jsx("li", {
                                  children: "One folder per notebook"
                                }),
                                e.jsx("li", {
                                  children: "Each source as a separate .md file"
                                }),
                                e.jsx("li", {
                                  children: "Source URL included as blockquote"
                                })
                              ]
                            })
                          ]
                        })
                      ]
                    }),
                    i && e.jsxs("div", {
                      className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-2 mb-2",
                          children: [
                            e.jsx(M, {
                              size: "sm"
                            }),
                            e.jsxs("span", {
                              className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                              children: [
                                n.phase,
                                "..."
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "w-full bg-blue-200 rounded-full h-1.5",
                          children: e.jsx("div", {
                            className: "bg-blue-600 h-1.5 rounded-full",
                            style: {
                              width: `${n.total > 0 ? n.current / n.total * 100 : 0}%`
                            }
                          })
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-blue-600 dark:text-blue-400 mt-1",
                          children: [
                            "Notebook ",
                            n.current,
                            "/",
                            n.total,
                            ": ",
                            n.currentNotebook,
                            n.sourceProgress && e.jsxs("span", {
                              className: "ml-2 text-blue-500",
                              children: [
                                "(",
                                n.sourceProgress,
                                ")"
                              ]
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                children: [
                  e.jsx("button", {
                    onClick: y,
                    disabled: i,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  e.jsxs("button", {
                    onClick: C,
                    disabled: i || s.length === 0,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                    children: [
                      e.jsx(v, {
                        className: "w-3.5 h-3.5"
                      }),
                      i ? "Exporting..." : `Export ${s.length} Notebook${s.length !== 1 ? "s" : ""}`
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  ae as default
};
