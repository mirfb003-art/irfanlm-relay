import { r as t, j as a, __tla as __tla_0 } from "./chunk-b41980cc.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
let c;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  c = function({ content: e }) {
    const [i, s] = t.useState(false), [r, l] = t.useState(true);
    return e ? a.jsxs("div", {
      className: "space-y-3",
      children: [
        e.title && a.jsx("h3", {
          className: "text-sm font-medium text-gray-900 dark:text-slate-100",
          children: e.title
        }),
        e.imageUrl && a.jsxs(a.Fragment, {
          children: [
            a.jsxs("div", {
              className: "bg-gray-100 dark:bg-gray-900 rounded-lg p-2 flex items-center justify-center",
              children: [
                r && a.jsx("div", {
                  className: "w-full h-48 bg-gray-200 dark:bg-gray-700 rounded"
                }),
                a.jsx("img", {
                  src: e.imageUrl,
                  alt: e.title || "Infographic",
                  className: `max-h-[60vh] object-contain cursor-zoom-in ${r ? "hidden" : ""}`,
                  onLoad: () => l(false),
                  onClick: () => s(true)
                })
              ]
            }),
            e.description && a.jsx("p", {
              className: "text-xs italic text-gray-500 dark:text-slate-400 mt-2",
              children: e.description
            })
          ]
        }),
        e.text && a.jsx("div", {
          className: "max-h-32 overflow-y-auto text-xs text-gray-700 dark:text-slate-300 bg-gray-50 dark:bg-slate-900 p-3 rounded border border-gray-100 dark:border-slate-700 whitespace-pre-line break-words",
          children: e.text
        }),
        i && a.jsx("div", {
          className: "fixed inset-0 z-50 bg-black/80 flex items-center justify-center cursor-zoom-out",
          onClick: () => s(false),
          children: a.jsx("img", {
            src: e.imageUrl,
            alt: e.title || "Infographic",
            className: "max-h-[95vh] max-w-[95vw] object-contain"
          })
        })
      ]
    }) : a.jsx("p", {
      className: "text-xs text-gray-500 dark:text-slate-400",
      children: "No infographic content available."
    });
  };
});
export {
  __tla,
  c as default
};
