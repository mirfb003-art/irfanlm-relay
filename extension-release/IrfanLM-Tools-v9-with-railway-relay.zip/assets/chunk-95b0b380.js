import { j as d, c as o, X as i, __tla as __tla_0 } from "./chunk-b41980cc.js";
let u, g, x;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  g = {
    gray: {
      light: "bg-gray-100 text-gray-700 border-gray-200",
      dark: "bg-gray-700 text-gray-200 border-gray-600",
      auto: "bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600",
      autoSelected: "bg-gray-200 text-gray-800 border-gray-300 dark:bg-gray-600 dark:text-gray-100 dark:border-gray-500"
    },
    red: {
      light: "bg-red-50 text-red-700 border-red-200",
      dark: "bg-red-900/40 text-red-300 border-red-700",
      auto: "bg-red-50 text-red-700 border-red-200 dark:bg-red-900/40 dark:text-red-300 dark:border-red-700",
      autoSelected: "bg-red-100 text-red-800 border-red-300 dark:bg-red-900/60 dark:text-red-200 dark:border-red-600"
    },
    orange: {
      light: "bg-orange-50 text-orange-700 border-orange-200",
      dark: "bg-orange-900/40 text-orange-300 border-orange-700",
      auto: "bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/40 dark:text-orange-300 dark:border-orange-700",
      autoSelected: "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/60 dark:text-orange-200 dark:border-orange-600"
    },
    yellow: {
      light: "bg-yellow-50 text-yellow-700 border-yellow-200",
      dark: "bg-yellow-900/40 text-yellow-300 border-yellow-700",
      auto: "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/40 dark:text-yellow-300 dark:border-yellow-700",
      autoSelected: "bg-yellow-100 text-yellow-800 border-yellow-300 dark:bg-yellow-900/60 dark:text-yellow-200 dark:border-yellow-600"
    },
    green: {
      light: "bg-green-50 text-green-700 border-green-200",
      dark: "bg-green-900/40 text-green-300 border-green-700",
      auto: "bg-green-50 text-green-700 border-green-200 dark:bg-green-900/40 dark:text-green-300 dark:border-green-700",
      autoSelected: "bg-green-100 text-green-800 border-green-300 dark:bg-green-900/60 dark:text-green-200 dark:border-green-600"
    },
    teal: {
      light: "bg-teal-50 text-teal-700 border-teal-200",
      dark: "bg-teal-900/40 text-teal-300 border-teal-700",
      auto: "bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-900/40 dark:text-teal-300 dark:border-teal-700",
      autoSelected: "bg-teal-100 text-teal-800 border-teal-300 dark:bg-teal-900/60 dark:text-teal-200 dark:border-teal-600"
    },
    blue: {
      light: "bg-blue-50 text-blue-700 border-blue-200",
      dark: "bg-blue-900/40 text-blue-300 border-blue-700",
      auto: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700",
      autoSelected: "bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/60 dark:text-blue-200 dark:border-blue-600"
    },
    indigo: {
      light: "bg-indigo-50 text-indigo-700 border-indigo-200",
      dark: "bg-indigo-900/40 text-indigo-300 border-indigo-700",
      auto: "bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-900/40 dark:text-indigo-300 dark:border-indigo-700",
      autoSelected: "bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-900/60 dark:text-indigo-200 dark:border-indigo-600"
    },
    purple: {
      light: "bg-purple-50 text-purple-700 border-purple-200",
      dark: "bg-purple-900/40 text-purple-300 border-purple-700",
      auto: "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700",
      autoSelected: "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/60 dark:text-purple-200 dark:border-purple-600"
    },
    pink: {
      light: "bg-pink-50 text-pink-700 border-pink-200",
      dark: "bg-pink-900/40 text-pink-300 border-pink-700",
      auto: "bg-pink-50 text-pink-700 border-pink-200 dark:bg-pink-900/40 dark:text-pink-300 dark:border-pink-700",
      autoSelected: "bg-pink-100 text-pink-800 border-pink-300 dark:bg-pink-900/60 dark:text-pink-200 dark:border-pink-600"
    }
  };
  x = function(e, t) {
    const r = g[e] || g.gray;
    return t === true ? r.dark : t === false ? r.light : r.auto;
  };
  u = function({ tag: e, onRemove: t, onClick: r, size: a = "sm", showRemove: b = false, isDarkMode: l }) {
    const n = x(e.color, l);
    return d.jsxs("span", {
      onClick: r,
      title: e.name,
      className: o("inline-flex items-center gap-0.5 border rounded-full font-medium", n, a === "xs" && "px-1.5 py-0 text-[10px]", a === "sm" && "px-2 py-0.5 text-xs", r && "cursor-pointer hover:opacity-80"),
      children: [
        d.jsx("span", {
          className: "truncate max-w-[100px]",
          children: e.name
        }),
        b && t && d.jsx("button", {
          onClick: (k) => {
            k.stopPropagation(), t(e);
          },
          className: o("ml-0.5 p-0.5 rounded-full", "hover:bg-black/10 dark:hover:bg-white/10"),
          children: d.jsx(i, {
            className: "w-3 h-3"
          })
        })
      ]
    });
  };
});
export {
  u as T,
  __tla,
  g as a,
  x as t
};
