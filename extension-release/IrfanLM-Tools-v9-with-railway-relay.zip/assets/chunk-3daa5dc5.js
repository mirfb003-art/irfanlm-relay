import { r as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
let i;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function o({ title: r, titleId: a, ...t }, n) {
    return e.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: n,
      "aria-labelledby": a
    }, t), r ? e.createElement("title", {
      id: a
    }, r) : null, e.createElement("path", {
      d: "m2.695 14.762-1.262 3.155a.5.5 0 0 0 .65.65l3.155-1.262a4 4 0 0 0 1.343-.886L17.5 5.501a2.121 2.121 0 0 0-3-3L3.58 13.419a4 4 0 0 0-.885 1.343Z"
    }));
  }
  let l;
  l = e.forwardRef(o);
  i = l;
});
export {
  i as P,
  __tla
};
