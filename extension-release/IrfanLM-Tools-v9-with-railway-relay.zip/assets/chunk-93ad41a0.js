import { r as n, __tla as __tla_0 } from "./chunk-b41980cc.js";
let _;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  const d = [
    0.5,
    0.75,
    1,
    1.25,
    1.5,
    2
  ], v = "YT_NOTEBOOKLM_TOOLS_MEDIA_PLAYBACK_RATE";
  function E(t) {
    if (!t || isNaN(t))
      return "0:00";
    const c = Math.floor(t / 60), s = Math.floor(t % 60);
    return `${c}:${s.toString().padStart(2, "0")}`;
  }
  _ = function(t) {
    const [c, s] = n.useState(false), [u, L] = n.useState(0), [r, y] = n.useState(0), [l, S] = n.useState(() => {
      try {
        const e = localStorage.getItem(v);
        return e ? parseFloat(e) : 1;
      } catch {
        return 1;
      }
    }), i = n.useRef(false), T = r > 0 ? u / r * 100 : 0, g = E(u), P = E(r);
    n.useEffect(() => {
      const e = t.current;
      if (!e || i.current)
        return;
      const a = () => L(e.currentTime), o = () => y(e.duration), p = () => s(true), f = () => s(false), m = () => s(false);
      return e.addEventListener("timeupdate", a), e.addEventListener("loadedmetadata", o), e.addEventListener("play", p), e.addEventListener("pause", f), e.addEventListener("ended", m), i.current = true, () => {
        e.removeEventListener("timeupdate", a), e.removeEventListener("loadedmetadata", o), e.removeEventListener("play", p), e.removeEventListener("pause", f), e.removeEventListener("ended", m), i.current = false;
      };
    }, [
      t
    ]), n.useEffect(() => {
      const e = t.current;
      e && (e.playbackRate = l);
    }, [
      l,
      t
    ]);
    const A = n.useCallback(() => {
      const e = t.current;
      e && (e.paused ? e.play().catch(console.error) : e.pause());
    }, [
      t
    ]), h = n.useCallback((e) => {
      const a = t.current;
      !a || !r || (a.currentTime = e * r);
    }, [
      t,
      r
    ]), k = n.useCallback(() => {
      S((e) => {
        const a = d.indexOf(e), o = d[(a + 1) % d.length];
        try {
          localStorage.setItem(v, o);
        } catch {
        }
        return o;
      });
    }, []);
    return {
      isPlaying: c,
      currentTime: u,
      duration: r,
      playbackRate: l,
      progress: T,
      formattedTime: g,
      formattedDuration: P,
      toggle: A,
      seek: h,
      cycleSpeed: k,
      formatTime: E
    };
  };
});
export {
  __tla,
  _ as u
};
