import { m as j, j as E, X as mt, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { i as _t, z as Vt, Q as Ft, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let er;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  var ce = (e) => e.type === "checkbox", se = (e) => e instanceof Date, U = (e) => e == null;
  const rt = (e) => typeof e == "object";
  var C = (e) => !U(e) && !Array.isArray(e) && rt(e) && !se(e), wt = (e) => C(e) && e.target ? ce(e.target) ? e.target.checked : e.target.value : e, kt = (e) => e.substring(0, e.search(/\.\d+(\.|$)/)) || e, At = (e, s) => e.has(kt(s)), Dt = (e) => {
    const s = e.constructor && e.constructor.prototype;
    return C(s) && s.hasOwnProperty("isPrototypeOf");
  }, Ce = typeof window < "u" && typeof window.HTMLElement < "u" && typeof document < "u";
  function T(e) {
    let s;
    const r = Array.isArray(e), a = typeof FileList < "u" ? e instanceof FileList : false;
    if (e instanceof Date)
      s = new Date(e);
    else if (!(Ce && (e instanceof Blob || a)) && (r || C(e)))
      if (s = r ? [] : Object.create(Object.getPrototypeOf(e)), !r && !Dt(e))
        s = e;
      else
        for (const u in e)
          e.hasOwnProperty(u) && (s[u] = T(e[u]));
    else
      return e;
    return s;
  }
  var xe = (e) => /^\w*$/.test(e), D = (e) => e === void 0, Ne = (e) => Array.isArray(e) ? e.filter(Boolean) : [], pe = (e) => Ne(e.replace(/["|']|\]/g, "").split(/\.|\[/)), h = (e, s, r) => {
    if (!s || !C(e))
      return r;
    const a = (xe(s) ? [
      s
    ] : pe(s)).reduce((u, n) => U(u) ? u : u[n], e);
    return D(a) || a === e ? D(e[s]) ? r : e[s] : a;
  }, Q = (e) => typeof e == "boolean", w = (e, s, r) => {
    let a = -1;
    const u = xe(s) ? [
      s
    ] : pe(s), n = u.length, f = n - 1;
    for (; ++a < n; ) {
      const c = u[a];
      let O = r;
      if (a !== f) {
        const I = e[c];
        O = C(I) || Array.isArray(I) ? I : isNaN(+u[a + 1]) ? {} : [];
      }
      if (c === "__proto__" || c === "constructor" || c === "prototype")
        return;
      e[c] = O, e = e[c];
    }
  };
  const He = {
    BLUR: "blur",
    FOCUS_OUT: "focusout",
    CHANGE: "change"
  }, W = {
    onBlur: "onBlur",
    onChange: "onChange",
    onSubmit: "onSubmit",
    onTouched: "onTouched",
    all: "all"
  }, Y = {
    max: "max",
    min: "min",
    maxLength: "maxLength",
    minLength: "minLength",
    pattern: "pattern",
    required: "required",
    validate: "validate"
  }, Et = j.createContext(null);
  Et.displayName = "HookFormContext";
  var St = (e, s, r, a = true) => {
    const u = {
      defaultValues: s._defaultValues
    };
    for (const n in e)
      Object.defineProperty(u, n, {
        get: () => {
          const f = n;
          return s._proxyFormState[f] !== W.all && (s._proxyFormState[f] = !a || W.all), r && (r[f] = true), e[f];
        }
      });
    return u;
  };
  const Ct = typeof window < "u" ? j.useLayoutEffect : j.useEffect;
  var B = (e) => typeof e == "string", Nt = (e, s, r, a, u) => B(e) ? (a && s.watch.add(e), h(r, e, u)) : Array.isArray(e) ? e.map((n) => (a && s.watch.add(n), h(r, n))) : (a && (s.watchAll = true), r), Ee = (e) => U(e) || !rt(e);
  function te(e, s, r = /* @__PURE__ */ new WeakSet()) {
    if (Ee(e) || Ee(s))
      return e === s;
    if (se(e) && se(s))
      return e.getTime() === s.getTime();
    const a = Object.keys(e), u = Object.keys(s);
    if (a.length !== u.length)
      return false;
    if (r.has(e) || r.has(s))
      return true;
    r.add(e), r.add(s);
    for (const n of a) {
      const f = e[n];
      if (!u.includes(n))
        return false;
      if (n !== "ref") {
        const c = s[n];
        if (se(f) && se(c) || C(f) && C(c) || Array.isArray(f) && Array.isArray(c) ? !te(f, c, r) : f !== c)
          return false;
      }
    }
    return true;
  }
  var pt = (e, s, r, a, u) => s ? {
    ...r[e],
    types: {
      ...r[e] && r[e].types ? r[e].types : {},
      [a]: u || true
    }
  } : {}, de = (e) => Array.isArray(e) ? e : [
    e
  ], ze = () => {
    let e = [];
    return {
      get observers() {
        return e;
      },
      next: (u) => {
        for (const n of e)
          n.next && n.next(u);
      },
      subscribe: (u) => (e.push(u), {
        unsubscribe: () => {
          e = e.filter((n) => n !== u);
        }
      }),
      unsubscribe: () => {
        e = [];
      }
    };
  };
  function st(e, s) {
    const r = {};
    for (const a in e)
      if (e.hasOwnProperty(a)) {
        const u = e[a], n = s[a];
        if (u && C(u) && n) {
          const f = st(u, n);
          C(f) && (r[a] = f);
        } else
          e[a] && (r[a] = n);
      }
    return r;
  }
  var M = (e) => C(e) && !Object.keys(e).length, Oe = (e) => e.type === "file", H = (e) => typeof e == "function", be = (e) => {
    if (!Ce)
      return false;
    const s = e ? e.ownerDocument : 0;
    return e instanceof (s && s.defaultView ? s.defaultView.HTMLElement : HTMLElement);
  }, it = (e) => e.type === "select-multiple", Te = (e) => e.type === "radio", Ot = (e) => Te(e) || ce(e), De = (e) => be(e) && e.isConnected;
  function Tt(e, s) {
    const r = s.slice(0, -1).length;
    let a = 0;
    for (; a < r; )
      e = D(e) ? a++ : e[s[a++]];
    return e;
  }
  function Rt(e) {
    for (const s in e)
      if (e.hasOwnProperty(s) && !D(e[s]))
        return false;
    return true;
  }
  function S(e, s) {
    const r = Array.isArray(s) ? s : xe(s) ? [
      s
    ] : pe(s), a = r.length === 1 ? e : Tt(e, r), u = r.length - 1, n = r[u];
    return a && delete a[n], u !== 0 && (C(a) && M(a) || Array.isArray(a) && Rt(a)) && S(e, r.slice(0, -1)), e;
  }
  var Lt = (e) => {
    for (const s in e)
      if (H(e[s]))
        return true;
    return false;
  };
  function at(e) {
    return Array.isArray(e) || C(e) && !Lt(e);
  }
  function Se(e, s = {}) {
    for (const r in e)
      at(e[r]) ? (s[r] = Array.isArray(e[r]) ? [] : {}, Se(e[r], s[r])) : D(e[r]) || (s[r] = true);
    return s;
  }
  function le(e, s, r) {
    r || (r = Se(s));
    for (const a in e)
      at(e[a]) ? D(s) || Ee(r[a]) ? r[a] = Se(e[a], Array.isArray(e[a]) ? [] : {}) : le(e[a], U(s) ? {} : s[a], r[a]) : r[a] = !te(e[a], s[a]);
    return r;
  }
  const $e = {
    value: false,
    isValid: false
  }, Ke = {
    value: true,
    isValid: true
  };
  var lt = (e) => {
    if (Array.isArray(e)) {
      if (e.length > 1) {
        const s = e.filter((r) => r && r.checked && !r.disabled).map((r) => r.value);
        return {
          value: s,
          isValid: !!s.length
        };
      }
      return e[0].checked && !e[0].disabled ? e[0].attributes && !D(e[0].attributes.value) ? D(e[0].value) || e[0].value === "" ? Ke : {
        value: e[0].value,
        isValid: true
      } : Ke : $e;
    }
    return $e;
  }, nt = (e, { valueAsNumber: s, valueAsDate: r, setValueAs: a }) => D(e) ? e : s ? e === "" ? NaN : e && +e : r && B(e) ? new Date(e) : a ? a(e) : e;
  const Qe = {
    isValid: false,
    value: null
  };
  var ot = (e) => Array.isArray(e) ? e.reduce((s, r) => r && r.checked && !r.disabled ? {
    isValid: true,
    value: r.value
  } : s, Qe) : Qe;
  function Xe(e) {
    const s = e.ref;
    return Oe(s) ? s.files : Te(s) ? ot(e.refs).value : it(s) ? [
      ...s.selectedOptions
    ].map(({ value: r }) => r) : ce(s) ? lt(e.refs).value : nt(D(s.value) ? e.ref.value : s.value, e);
  }
  var Mt = (e, s, r, a) => {
    const u = {};
    for (const n of e) {
      const f = h(s, n);
      f && w(u, n, f._f);
    }
    return {
      criteriaMode: r,
      names: [
        ...e
      ],
      fields: u,
      shouldUseNativeValidation: a
    };
  }, ve = (e) => e instanceof RegExp, ue = (e) => D(e) ? e : ve(e) ? e.source : C(e) ? ve(e.value) ? e.value.source : e.value : e, Ye = (e) => ({
    isOnSubmit: !e || e === W.onSubmit,
    isOnBlur: e === W.onBlur,
    isOnChange: e === W.onChange,
    isOnAll: e === W.all,
    isOnTouch: e === W.onTouched
  });
  const Ge = "AsyncFunction";
  var Ut = (e) => !!e && !!e.validate && !!(H(e.validate) && e.validate.constructor.name === Ge || C(e.validate) && Object.values(e.validate).find((s) => s.constructor.name === Ge)), jt = (e) => e.mount && (e.required || e.min || e.max || e.maxLength || e.minLength || e.pattern || e.validate), Je = (e, s, r) => !r && (s.watchAll || s.watch.has(e) || [
    ...s.watch
  ].some((a) => e.startsWith(a) && /^\.\w+/.test(e.slice(a.length))));
  const fe = (e, s, r, a) => {
    for (const u of r || Object.keys(e)) {
      const n = h(e, u);
      if (n) {
        const { _f: f, ...c } = n;
        if (f) {
          if (f.refs && f.refs[0] && s(f.refs[0], u) && !a)
            return true;
          if (f.ref && s(f.ref, f.name) && !a)
            return true;
          if (fe(c, s))
            break;
        } else if (C(c) && fe(c, s))
          break;
      }
    }
  };
  function Ze(e, s, r) {
    const a = h(e, r);
    if (a || xe(r))
      return {
        error: a,
        name: r
      };
    const u = r.split(".");
    for (; u.length; ) {
      const n = u.join("."), f = h(s, n), c = h(e, n);
      if (f && !Array.isArray(f) && r !== n)
        return {
          name: r
        };
      if (c && c.type)
        return {
          name: n,
          error: c
        };
      if (c && c.root && c.root.type)
        return {
          name: `${n}.root`,
          error: c.root
        };
      u.pop();
    }
    return {
      name: r
    };
  }
  var Bt = (e, s, r, a) => {
    r(e);
    const { name: u, ...n } = e;
    return M(n) || Object.keys(n).length >= Object.keys(s).length || Object.keys(n).find((f) => s[f] === (!a || W.all));
  }, It = (e, s, r) => !e || !s || e === s || de(e).some((a) => a && (r ? a === s : a.startsWith(s) || s.startsWith(a))), Pt = (e, s, r, a, u) => u.isOnAll ? false : !r && u.isOnTouch ? !(s || e) : (r ? a.isOnBlur : u.isOnBlur) ? !e : (r ? a.isOnChange : u.isOnChange) ? e : true, qt = (e, s) => !Ne(h(e, s)).length && S(e, s), Wt = (e, s, r) => {
    const a = de(h(e, r));
    return w(a, "root", s[r]), w(e, r, a), e;
  };
  function et(e, s, r = "validate") {
    if (B(e) || Array.isArray(e) && e.every(B) || Q(e) && !e)
      return {
        type: r,
        message: B(e) ? e : "",
        ref: s
      };
  }
  var ae = (e) => C(e) && !ve(e) ? e : {
    value: e,
    message: ""
  }, tt = async (e, s, r, a, u, n) => {
    const { ref: f, refs: c, required: O, maxLength: I, minLength: V, min: k, max: b, pattern: ne, validate: G, name: N, valueAsNumber: J, mount: me } = e._f, x = h(r, N);
    if (!me || s.has(N))
      return {};
    const X = c ? c[0] : f, z = (v) => {
      u && X.reportValidity && (X.setCustomValidity(Q(v) ? "" : v || ""), X.reportValidity());
    }, p = {}, ye = Te(f), Z = ce(f), _e = ye || Z, q = (J || Oe(f)) && D(f.value) && D(x) || be(f) && f.value === "" || x === "" || Array.isArray(x) && !x.length, re = pt.bind(null, N, a, p), $ = (v, _, A, R = Y.maxLength, L = Y.minLength) => {
      const K = v ? _ : A;
      p[N] = {
        type: v ? R : L,
        message: K,
        ref: f,
        ...re(v ? R : L, K)
      };
    };
    if (n ? !Array.isArray(x) || !x.length : O && (!_e && (q || U(x)) || Q(x) && !x || Z && !lt(c).isValid || ye && !ot(c).isValid)) {
      const { value: v, message: _ } = B(O) ? {
        value: !!O,
        message: O
      } : ae(O);
      if (v && (p[N] = {
        type: Y.required,
        message: _,
        ref: X,
        ...re(Y.required, _)
      }, !a))
        return z(_), p;
    }
    if (!q && (!U(k) || !U(b))) {
      let v, _;
      const A = ae(b), R = ae(k);
      if (!U(x) && !isNaN(x)) {
        const L = f.valueAsNumber || x && +x;
        U(A.value) || (v = L > A.value), U(R.value) || (_ = L < R.value);
      } else {
        const L = f.valueAsDate || new Date(x), K = (he) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + he), oe = f.type == "time", ie = f.type == "week";
        B(A.value) && x && (v = oe ? K(x) > K(A.value) : ie ? x > A.value : L > new Date(A.value)), B(R.value) && x && (_ = oe ? K(x) < K(R.value) : ie ? x < R.value : L < new Date(R.value));
      }
      if ((v || _) && ($(!!v, A.message, R.message, Y.max, Y.min), !a))
        return z(p[N].message), p;
    }
    if ((I || V) && !q && (B(x) || n && Array.isArray(x))) {
      const v = ae(I), _ = ae(V), A = !U(v.value) && x.length > +v.value, R = !U(_.value) && x.length < +_.value;
      if ((A || R) && ($(A, v.message, _.message), !a))
        return z(p[N].message), p;
    }
    if (ne && !q && B(x)) {
      const { value: v, message: _ } = ae(ne);
      if (ve(v) && !x.match(v) && (p[N] = {
        type: Y.pattern,
        message: _,
        ref: f,
        ...re(Y.pattern, _)
      }, !a))
        return z(_), p;
    }
    if (G) {
      if (H(G)) {
        const v = await G(x, r), _ = et(v, X);
        if (_ && (p[N] = {
          ..._,
          ...re(Y.validate, _.message)
        }, !a))
          return z(_.message), p;
      } else if (C(G)) {
        let v = {};
        for (const _ in G) {
          if (!M(v) && !a)
            break;
          const A = et(await G[_](x, r), X, _);
          A && (v = {
            ...A,
            ...re(_, A.message)
          }, z(A.message), a && (p[N] = v));
        }
        if (!M(v) && (p[N] = {
          ref: X,
          ...v
        }, !a))
          return p;
      }
    }
    return z(true), p;
  };
  const Ht = {
    mode: W.onSubmit,
    reValidateMode: W.onChange,
    shouldFocusError: true
  };
  function zt(e = {}) {
    let s = {
      ...Ht,
      ...e
    }, r = {
      submitCount: 0,
      isDirty: false,
      isReady: false,
      isLoading: H(s.defaultValues),
      isValidating: false,
      isSubmitted: false,
      isSubmitting: false,
      isSubmitSuccessful: false,
      isValid: false,
      touchedFields: {},
      dirtyFields: {},
      validatingFields: {},
      errors: s.errors || {},
      disabled: s.disabled || false
    }, a = {}, u = C(s.defaultValues) || C(s.values) ? T(s.defaultValues || s.values) || {} : {}, n = s.shouldUnregister ? {} : T(u), f = {
      action: false,
      mount: false,
      watch: false
    }, c = {
      mount: /* @__PURE__ */ new Set(),
      disabled: /* @__PURE__ */ new Set(),
      unMount: /* @__PURE__ */ new Set(),
      array: /* @__PURE__ */ new Set(),
      watch: /* @__PURE__ */ new Set()
    }, O, I = 0;
    const V = {
      isDirty: false,
      dirtyFields: false,
      validatingFields: false,
      touchedFields: false,
      isValidating: false,
      isValid: false,
      errors: false
    };
    let k = {
      ...V
    };
    const b = {
      array: ze(),
      state: ze()
    }, ne = s.criteriaMode === W.all, G = (t) => (i) => {
      clearTimeout(I), I = setTimeout(t, i);
    }, N = async (t) => {
      if (!s.disabled && (V.isValid || k.isValid || t)) {
        const i = s.resolver ? M((await Z()).errors) : await q(a, true);
        i !== r.isValid && b.state.next({
          isValid: i
        });
      }
    }, J = (t, i) => {
      !s.disabled && (V.isValidating || V.validatingFields || k.isValidating || k.validatingFields) && ((t || Array.from(c.mount)).forEach((l) => {
        l && (i ? w(r.validatingFields, l, i) : S(r.validatingFields, l));
      }), b.state.next({
        validatingFields: r.validatingFields,
        isValidating: !M(r.validatingFields)
      }));
    }, me = (t, i = [], l, y, d = true, o = true) => {
      if (y && l && !s.disabled) {
        if (f.action = true, o && Array.isArray(h(a, t))) {
          const g = l(h(a, t), y.argA, y.argB);
          d && w(a, t, g);
        }
        if (o && Array.isArray(h(r.errors, t))) {
          const g = l(h(r.errors, t), y.argA, y.argB);
          d && w(r.errors, t, g), qt(r.errors, t);
        }
        if ((V.touchedFields || k.touchedFields) && o && Array.isArray(h(r.touchedFields, t))) {
          const g = l(h(r.touchedFields, t), y.argA, y.argB);
          d && w(r.touchedFields, t, g);
        }
        (V.dirtyFields || k.dirtyFields) && (r.dirtyFields = le(u, n)), b.state.next({
          name: t,
          isDirty: $(t, i),
          dirtyFields: r.dirtyFields,
          errors: r.errors,
          isValid: r.isValid
        });
      } else
        w(n, t, i);
    }, x = (t, i) => {
      w(r.errors, t, i), b.state.next({
        errors: r.errors
      });
    }, X = (t) => {
      r.errors = t, b.state.next({
        errors: r.errors,
        isValid: false
      });
    }, z = (t, i, l, y) => {
      const d = h(a, t);
      if (d) {
        const o = h(n, t, D(l) ? h(u, t) : l);
        D(o) || y && y.defaultChecked || i ? w(n, t, i ? o : Xe(d._f)) : A(t, o), f.mount && N();
      }
    }, p = (t, i, l, y, d) => {
      let o = false, g = false;
      const m = {
        name: t
      };
      if (!s.disabled) {
        if (!l || y) {
          (V.isDirty || k.isDirty) && (g = r.isDirty, r.isDirty = m.isDirty = $(), o = g !== m.isDirty);
          const F = te(h(u, t), i);
          g = !!h(r.dirtyFields, t), F ? S(r.dirtyFields, t) : w(r.dirtyFields, t, true), m.dirtyFields = r.dirtyFields, o = o || (V.dirtyFields || k.dirtyFields) && g !== !F;
        }
        if (l) {
          const F = h(r.touchedFields, t);
          F || (w(r.touchedFields, t, l), m.touchedFields = r.touchedFields, o = o || (V.touchedFields || k.touchedFields) && F !== l);
        }
        o && d && b.state.next(m);
      }
      return o ? m : {};
    }, ye = (t, i, l, y) => {
      const d = h(r.errors, t), o = (V.isValid || k.isValid) && Q(i) && r.isValid !== i;
      if (s.delayError && l ? (O = G(() => x(t, l)), O(s.delayError)) : (clearTimeout(I), O = null, l ? w(r.errors, t, l) : S(r.errors, t)), (l ? !te(d, l) : d) || !M(y) || o) {
        const g = {
          ...y,
          ...o && Q(i) ? {
            isValid: i
          } : {},
          errors: r.errors,
          name: t
        };
        r = {
          ...r,
          ...g
        }, b.state.next(g);
      }
    }, Z = async (t) => {
      J(t, true);
      const i = await s.resolver(n, s.context, Mt(t || c.mount, a, s.criteriaMode, s.shouldUseNativeValidation));
      return J(t), i;
    }, _e = async (t) => {
      const { errors: i } = await Z(t);
      if (t)
        for (const l of t) {
          const y = h(i, l);
          y ? w(r.errors, l, y) : S(r.errors, l);
        }
      else
        r.errors = i;
      return i;
    }, q = async (t, i, l = {
      valid: true
    }) => {
      for (const y in t) {
        const d = t[y];
        if (d) {
          const { _f: o, ...g } = d;
          if (o) {
            const m = c.array.has(o.name), F = d._f && Ut(d._f);
            F && V.validatingFields && J([
              o.name
            ], true);
            const P = await tt(d, c.disabled, n, ne, s.shouldUseNativeValidation && !i, m);
            if (F && V.validatingFields && J([
              o.name
            ]), P[o.name] && (l.valid = false, i))
              break;
            !i && (h(P, o.name) ? m ? Wt(r.errors, P, o.name) : w(r.errors, o.name, P[o.name]) : S(r.errors, o.name));
          }
          !M(g) && await q(g, i, l);
        }
      }
      return l.valid;
    }, re = () => {
      for (const t of c.unMount) {
        const i = h(a, t);
        i && (i._f.refs ? i._f.refs.every((l) => !De(l)) : !De(i._f.ref)) && Ve(t);
      }
      c.unMount = /* @__PURE__ */ new Set();
    }, $ = (t, i) => !s.disabled && (t && i && w(n, t, i), !te(he(), u)), v = (t, i, l) => Nt(t, c, {
      ...f.mount ? n : D(i) ? u : B(t) ? {
        [t]: i
      } : i
    }, l, i), _ = (t) => Ne(h(f.mount ? n : u, t, s.shouldUnregister ? h(u, t, []) : [])), A = (t, i, l = {}) => {
      const y = h(a, t);
      let d = i;
      if (y) {
        const o = y._f;
        o && (!o.disabled && w(n, t, nt(i, o)), d = be(o.ref) && U(i) ? "" : i, it(o.ref) ? [
          ...o.ref.options
        ].forEach((g) => g.selected = d.includes(g.value)) : o.refs ? ce(o.ref) ? o.refs.forEach((g) => {
          (!g.defaultChecked || !g.disabled) && (Array.isArray(d) ? g.checked = !!d.find((m) => m === g.value) : g.checked = d === g.value || !!d);
        }) : o.refs.forEach((g) => g.checked = g.value === d) : Oe(o.ref) ? o.ref.value = "" : (o.ref.value = d, o.ref.type || b.state.next({
          name: t,
          values: T(n)
        })));
      }
      (l.shouldDirty || l.shouldTouch) && p(t, d, l.shouldTouch, l.shouldDirty, true), l.shouldValidate && ie(t);
    }, R = (t, i, l) => {
      for (const y in i) {
        if (!i.hasOwnProperty(y))
          return;
        const d = i[y], o = t + "." + y, g = h(a, o);
        (c.array.has(t) || C(d) || g && !g._f) && !se(d) ? R(o, d, l) : A(o, d, l);
      }
    }, L = (t, i, l = {}) => {
      const y = h(a, t), d = c.array.has(t), o = T(i);
      w(n, t, o), d ? (b.array.next({
        name: t,
        values: T(n)
      }), (V.isDirty || V.dirtyFields || k.isDirty || k.dirtyFields) && l.shouldDirty && b.state.next({
        name: t,
        dirtyFields: le(u, n),
        isDirty: $(t, o)
      })) : y && !y._f && !U(o) ? R(t, o, l) : A(t, o, l), Je(t, c) && b.state.next({
        ...r,
        name: t
      }), b.state.next({
        name: f.mount ? t : void 0,
        values: T(n)
      });
    }, K = async (t) => {
      f.mount = true;
      const i = t.target;
      let l = i.name, y = true;
      const d = h(a, l), o = (F) => {
        y = Number.isNaN(F) || se(F) && isNaN(F.getTime()) || te(F, h(n, l, F));
      }, g = Ye(s.mode), m = Ye(s.reValidateMode);
      if (d) {
        let F, P;
        const ge = i.type ? Xe(d._f) : wt(t), ee = t.type === He.BLUR || t.type === He.FOCUS_OUT, bt = !jt(d._f) && !s.resolver && !h(r.errors, l) && !d._f.deps || Pt(ee, h(r.touchedFields, l), r.isSubmitted, m, g), ke = Je(l, c, ee);
        w(n, l, ge), ee ? (!i || !i.readOnly) && (d._f.onBlur && d._f.onBlur(t), O && O(0)) : d._f.onChange && d._f.onChange(t);
        const Ae = p(l, ge, ee), vt = !M(Ae) || ke;
        if (!ee && b.state.next({
          name: l,
          type: t.type,
          values: T(n)
        }), bt)
          return (V.isValid || k.isValid) && (s.mode === "onBlur" ? ee && N() : ee || N()), vt && b.state.next({
            name: l,
            ...ke ? {} : Ae
          });
        if (!ee && ke && b.state.next({
          ...r
        }), s.resolver) {
          const { errors: qe } = await Z([
            l
          ]);
          if (o(ge), y) {
            const xt = Ze(r.errors, a, l), We = Ze(qe, a, xt.name || l);
            F = We.error, l = We.name, P = M(qe);
          }
        } else
          J([
            l
          ], true), F = (await tt(d, c.disabled, n, ne, s.shouldUseNativeValidation))[l], J([
            l
          ]), o(ge), y && (F ? P = false : (V.isValid || k.isValid) && (P = await q(a, true)));
        y && (d._f.deps && (!Array.isArray(d._f.deps) || d._f.deps.length > 0) && ie(d._f.deps), ye(l, P, F, Ae));
      }
    }, oe = (t, i) => {
      if (h(r.errors, i) && t.focus)
        return t.focus(), 1;
    }, ie = async (t, i = {}) => {
      let l, y;
      const d = de(t);
      if (s.resolver) {
        const o = await _e(D(t) ? t : d);
        l = M(o), y = t ? !d.some((g) => h(o, g)) : l;
      } else
        t ? (y = (await Promise.all(d.map(async (o) => {
          const g = h(a, o);
          return await q(g && g._f ? {
            [o]: g
          } : g);
        }))).every(Boolean), !(!y && !r.isValid) && N()) : y = l = await q(a);
      return b.state.next({
        ...!B(t) || (V.isValid || k.isValid) && l !== r.isValid ? {} : {
          name: t
        },
        ...s.resolver || !t ? {
          isValid: l
        } : {},
        errors: r.errors
      }), i.shouldFocus && !y && fe(a, oe, t ? d : c.mount), y;
    }, he = (t, i) => {
      let l = {
        ...f.mount ? n : u
      };
      return i && (l = st(i.dirtyFields ? r.dirtyFields : r.touchedFields, l)), D(t) ? l : B(t) ? h(l, t) : t.map((y) => h(l, y));
    }, Re = (t, i) => ({
      invalid: !!h((i || r).errors, t),
      isDirty: !!h((i || r).dirtyFields, t),
      error: h((i || r).errors, t),
      isValidating: !!h(r.validatingFields, t),
      isTouched: !!h((i || r).touchedFields, t)
    }), ut = (t) => {
      t && de(t).forEach((i) => S(r.errors, i)), b.state.next({
        errors: t ? r.errors : {}
      });
    }, Le = (t, i, l) => {
      const y = (h(a, t, {
        _f: {}
      })._f || {}).ref, d = h(r.errors, t) || {}, { ref: o, message: g, type: m, ...F } = d;
      w(r.errors, t, {
        ...F,
        ...i,
        ref: y
      }), b.state.next({
        name: t,
        errors: r.errors,
        isValid: false
      }), l && l.shouldFocus && y && y.focus && y.focus();
    }, dt = (t, i) => H(t) ? b.state.subscribe({
      next: (l) => "values" in l && t(v(void 0, i), l)
    }) : v(t, i, true), Me = (t) => b.state.subscribe({
      next: (i) => {
        It(t.name, i.name, t.exact) && Bt(i, t.formState || V, gt, t.reRenderRoot) && t.callback({
          values: {
            ...n
          },
          ...r,
          ...i,
          defaultValues: u
        });
      }
    }).unsubscribe, ft = (t) => (f.mount = true, k = {
      ...k,
      ...t.formState
    }, Me({
      ...t,
      formState: k
    })), Ve = (t, i = {}) => {
      for (const l of t ? de(t) : c.mount)
        c.mount.delete(l), c.array.delete(l), i.keepValue || (S(a, l), S(n, l)), !i.keepError && S(r.errors, l), !i.keepDirty && S(r.dirtyFields, l), !i.keepTouched && S(r.touchedFields, l), !i.keepIsValidating && S(r.validatingFields, l), !s.shouldUnregister && !i.keepDefaultValue && S(u, l);
      b.state.next({
        values: T(n)
      }), b.state.next({
        ...r,
        ...i.keepDirty ? {
          isDirty: $()
        } : {}
      }), !i.keepIsValid && N();
    }, Ue = ({ disabled: t, name: i }) => {
      (Q(t) && f.mount || t || c.disabled.has(i)) && (t ? c.disabled.add(i) : c.disabled.delete(i));
    }, Fe = (t, i = {}) => {
      let l = h(a, t);
      const y = Q(i.disabled) || Q(s.disabled);
      return w(a, t, {
        ...l || {},
        _f: {
          ...l && l._f ? l._f : {
            ref: {
              name: t
            }
          },
          name: t,
          mount: true,
          ...i
        }
      }), c.mount.add(t), l ? Ue({
        disabled: Q(i.disabled) ? i.disabled : s.disabled,
        name: t
      }) : z(t, true, i.value), {
        ...y ? {
          disabled: i.disabled || s.disabled
        } : {},
        ...s.progressive ? {
          required: !!i.required,
          min: ue(i.min),
          max: ue(i.max),
          minLength: ue(i.minLength),
          maxLength: ue(i.maxLength),
          pattern: ue(i.pattern)
        } : {},
        name: t,
        onChange: K,
        onBlur: K,
        ref: (d) => {
          if (d) {
            Fe(t, i), l = h(a, t);
            const o = D(d.value) && d.querySelectorAll && d.querySelectorAll("input,select,textarea")[0] || d, g = Ot(o), m = l._f.refs || [];
            if (g ? m.find((F) => F === o) : o === l._f.ref)
              return;
            w(a, t, {
              _f: {
                ...l._f,
                ...g ? {
                  refs: [
                    ...m.filter(De),
                    o,
                    ...Array.isArray(h(u, t)) ? [
                      {}
                    ] : []
                  ],
                  ref: {
                    type: o.type,
                    name: t
                  }
                } : {
                  ref: o
                }
              }
            }), z(t, false, void 0, o);
          } else
            l = h(a, t, {}), l._f && (l._f.mount = false), (s.shouldUnregister || i.shouldUnregister) && !(At(c.array, t) && f.action) && c.unMount.add(t);
        }
      };
    }, we = () => s.shouldFocusError && fe(a, oe, c.mount), ct = (t) => {
      Q(t) && (b.state.next({
        disabled: t
      }), fe(a, (i, l) => {
        const y = h(a, l);
        y && (i.disabled = y._f.disabled || t, Array.isArray(y._f.refs) && y._f.refs.forEach((d) => {
          d.disabled = y._f.disabled || t;
        }));
      }, 0, false));
    }, je = (t, i) => async (l) => {
      let y;
      l && (l.preventDefault && l.preventDefault(), l.persist && l.persist());
      let d = T(n);
      if (b.state.next({
        isSubmitting: true
      }), s.resolver) {
        const { errors: o, values: g } = await Z();
        r.errors = o, d = T(g);
      } else
        await q(a);
      if (c.disabled.size)
        for (const o of c.disabled)
          S(d, o);
      if (S(r.errors, "root"), M(r.errors)) {
        b.state.next({
          errors: {}
        });
        try {
          await t(d, l);
        } catch (o) {
          y = o;
        }
      } else
        i && await i({
          ...r.errors
        }, l), we(), setTimeout(we);
      if (b.state.next({
        isSubmitted: true,
        isSubmitting: false,
        isSubmitSuccessful: M(r.errors) && !y,
        submitCount: r.submitCount + 1,
        errors: r.errors
      }), y)
        throw y;
    }, yt = (t, i = {}) => {
      h(a, t) && (D(i.defaultValue) ? L(t, T(h(u, t))) : (L(t, i.defaultValue), w(u, t, T(i.defaultValue))), i.keepTouched || S(r.touchedFields, t), i.keepDirty || (S(r.dirtyFields, t), r.isDirty = i.defaultValue ? $(t, T(h(u, t))) : $()), i.keepError || (S(r.errors, t), V.isValid && N()), b.state.next({
        ...r
      }));
    }, Be = (t, i = {}) => {
      const l = t ? T(t) : u, y = T(l), d = M(t), o = d ? u : y;
      if (i.keepDefaultValues || (u = l), !i.keepValues) {
        if (i.keepDirtyValues) {
          const g = /* @__PURE__ */ new Set([
            ...c.mount,
            ...Object.keys(le(u, n))
          ]);
          for (const m of Array.from(g))
            h(r.dirtyFields, m) ? w(o, m, h(n, m)) : L(m, h(o, m));
        } else {
          if (Ce && D(t))
            for (const g of c.mount) {
              const m = h(a, g);
              if (m && m._f) {
                const F = Array.isArray(m._f.refs) ? m._f.refs[0] : m._f.ref;
                if (be(F)) {
                  const P = F.closest("form");
                  if (P) {
                    P.reset();
                    break;
                  }
                }
              }
            }
          if (i.keepFieldsRef)
            for (const g of c.mount)
              L(g, h(o, g));
          else
            a = {};
        }
        n = s.shouldUnregister ? i.keepDefaultValues ? T(u) : {} : T(o), b.array.next({
          values: {
            ...o
          }
        }), b.state.next({
          values: {
            ...o
          }
        });
      }
      c = {
        mount: i.keepDirtyValues ? c.mount : /* @__PURE__ */ new Set(),
        unMount: /* @__PURE__ */ new Set(),
        array: /* @__PURE__ */ new Set(),
        disabled: /* @__PURE__ */ new Set(),
        watch: /* @__PURE__ */ new Set(),
        watchAll: false,
        focus: ""
      }, f.mount = !V.isValid || !!i.keepIsValid || !!i.keepDirtyValues, f.watch = !!s.shouldUnregister, b.state.next({
        submitCount: i.keepSubmitCount ? r.submitCount : 0,
        isDirty: d ? false : i.keepDirty ? r.isDirty : !!(i.keepDefaultValues && !te(t, u)),
        isSubmitted: i.keepIsSubmitted ? r.isSubmitted : false,
        dirtyFields: d ? {} : i.keepDirtyValues ? i.keepDefaultValues && n ? le(u, n) : r.dirtyFields : i.keepDefaultValues && t ? le(u, t) : i.keepDirty ? r.dirtyFields : {},
        touchedFields: i.keepTouched ? r.touchedFields : {},
        errors: i.keepErrors ? r.errors : {},
        isSubmitSuccessful: i.keepIsSubmitSuccessful ? r.isSubmitSuccessful : false,
        isSubmitting: false,
        defaultValues: u
      });
    }, Ie = (t, i) => Be(H(t) ? t(n) : t, i), ht = (t, i = {}) => {
      const l = h(a, t), y = l && l._f;
      if (y) {
        const d = y.refs ? y.refs[0] : y.ref;
        d.focus && (d.focus(), i.shouldSelect && H(d.select) && d.select());
      }
    }, gt = (t) => {
      r = {
        ...r,
        ...t
      };
    }, Pe = {
      control: {
        register: Fe,
        unregister: Ve,
        getFieldState: Re,
        handleSubmit: je,
        setError: Le,
        _subscribe: Me,
        _runSchema: Z,
        _focusError: we,
        _getWatch: v,
        _getDirty: $,
        _setValid: N,
        _setFieldArray: me,
        _setDisabledField: Ue,
        _setErrors: X,
        _getFieldArray: _,
        _reset: Be,
        _resetDefaultValues: () => H(s.defaultValues) && s.defaultValues().then((t) => {
          Ie(t, s.resetOptions), b.state.next({
            isLoading: false
          });
        }),
        _removeUnmounted: re,
        _disableForm: ct,
        _subjects: b,
        _proxyFormState: V,
        get _fields() {
          return a;
        },
        get _formValues() {
          return n;
        },
        get _state() {
          return f;
        },
        set _state(t) {
          f = t;
        },
        get _defaultValues() {
          return u;
        },
        get _names() {
          return c;
        },
        set _names(t) {
          c = t;
        },
        get _formState() {
          return r;
        },
        get _options() {
          return s;
        },
        set _options(t) {
          s = {
            ...s,
            ...t
          };
        }
      },
      subscribe: ft,
      trigger: ie,
      register: Fe,
      handleSubmit: je,
      watch: dt,
      setValue: L,
      getValues: he,
      reset: Ie,
      resetField: yt,
      clearErrors: ut,
      unregister: Ve,
      setError: Le,
      setFocus: ht,
      getFieldState: Re
    };
    return {
      ...Pe,
      formControl: Pe
    };
  }
  function $t(e = {}) {
    const s = j.useRef(void 0), r = j.useRef(void 0), [a, u] = j.useState({
      isDirty: false,
      isValidating: false,
      isLoading: H(e.defaultValues),
      isSubmitted: false,
      isSubmitting: false,
      isSubmitSuccessful: false,
      isValid: false,
      submitCount: 0,
      dirtyFields: {},
      touchedFields: {},
      validatingFields: {},
      errors: e.errors || {},
      disabled: e.disabled || false,
      isReady: false,
      defaultValues: H(e.defaultValues) ? void 0 : e.defaultValues
    });
    if (!s.current)
      if (e.formControl)
        s.current = {
          ...e.formControl,
          formState: a
        }, e.defaultValues && !H(e.defaultValues) && e.formControl.reset(e.defaultValues, e.resetOptions);
      else {
        const { formControl: f, ...c } = zt(e);
        s.current = {
          ...c,
          formState: a
        };
      }
    const n = s.current.control;
    return n._options = e, Ct(() => {
      const f = n._subscribe({
        formState: n._proxyFormState,
        callback: () => u({
          ...n._formState
        }),
        reRenderRoot: true
      });
      return u((c) => ({
        ...c,
        isReady: true
      })), n._formState.isReady = true, f;
    }, [
      n
    ]), j.useEffect(() => n._disableForm(e.disabled), [
      n,
      e.disabled
    ]), j.useEffect(() => {
      e.mode && (n._options.mode = e.mode), e.reValidateMode && (n._options.reValidateMode = e.reValidateMode);
    }, [
      n,
      e.mode,
      e.reValidateMode
    ]), j.useEffect(() => {
      e.errors && (n._setErrors(e.errors), n._focusError());
    }, [
      n,
      e.errors
    ]), j.useEffect(() => {
      e.shouldUnregister && n._subjects.state.next({
        values: n._getWatch()
      });
    }, [
      n,
      e.shouldUnregister
    ]), j.useEffect(() => {
      if (n._proxyFormState.isDirty) {
        const f = n._getDirty();
        f !== a.isDirty && n._subjects.state.next({
          isDirty: f
        });
      }
    }, [
      n,
      a.isDirty
    ]), j.useEffect(() => {
      e.values && !te(e.values, r.current) ? (n._reset(e.values, {
        keepFieldsRef: true,
        ...n._options.resetOptions
      }), r.current = e.values, u((f) => ({
        ...f
      }))) : n._resetDefaultValues();
    }, [
      n,
      e.values
    ]), j.useEffect(() => {
      n._state.mount || (n._setValid(), n._state.mount = true), n._state.watch && (n._state.watch = false, n._subjects.state.next({
        ...n._formState
      })), n._removeUnmounted();
    }), s.current.formState = St(a, n), s.current;
  }
  er = function({ isOpen: e, onClose: s, onSubmit: r, isLoading: a = false }) {
    const { register: u, handleSubmit: n, reset: f, formState: { errors: c } } = $t({
      defaultValues: {
        title: ""
      }
    }), O = () => {
      f(), s();
    }, I = async (V) => {
      try {
        await r(V.title || null), f(), s();
      } catch {
      }
    };
    return E.jsxs(_t, {
      open: e,
      onClose: O,
      className: "relative z-50",
      children: [
        E.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        E.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: E.jsxs(Vt, {
            className: "w-full max-w-md space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-6",
            children: [
              E.jsxs("div", {
                className: "flex items-center justify-between",
                children: [
                  E.jsx(Ft, {
                    className: "text-lg font-medium text-gray-900 dark:text-slate-100",
                    children: "Create New Notebook"
                  }),
                  E.jsx("button", {
                    onClick: O,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                    children: E.jsx(mt, {
                      className: "h-5 w-5"
                    })
                  })
                ]
              }),
              E.jsxs("form", {
                onSubmit: n(I),
                className: "space-y-4",
                children: [
                  E.jsxs("div", {
                    children: [
                      E.jsx("label", {
                        htmlFor: "title",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: "Title (optional)"
                      }),
                      E.jsx("input", {
                        ...u("title"),
                        type: "text",
                        id: "title",
                        placeholder: "Enter notebook title...",
                        className: "block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-slate-700 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs px-3 py-2"
                      }),
                      c.title && E.jsx("p", {
                        className: "mt-1 text-xs text-red-600",
                        children: c.title.message
                      })
                    ]
                  }),
                  E.jsxs("div", {
                    className: "flex justify-end space-x-2 pt-2",
                    children: [
                      E.jsx("button", {
                        type: "button",
                        onClick: O,
                        disabled: a,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed",
                        children: "Cancel"
                      }),
                      E.jsxs("button", {
                        type: "submit",
                        disabled: a,
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-1",
                        children: [
                          a && E.jsxs("svg", {
                            className: "w-3 h-3 animate-spin",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                              E.jsx("circle", {
                                className: "opacity-25",
                                cx: "12",
                                cy: "12",
                                r: "10",
                                stroke: "currentColor",
                                strokeWidth: "4"
                              }),
                              E.jsx("path", {
                                className: "opacity-75",
                                fill: "currentColor",
                                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              })
                            ]
                          }),
                          E.jsx("span", {
                            children: a ? "Creating..." : "Create"
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  er as default
};
