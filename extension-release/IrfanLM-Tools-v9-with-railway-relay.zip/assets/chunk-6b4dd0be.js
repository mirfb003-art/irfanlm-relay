import { c as m } from "./chunk-38df7042.js";
import { c as f, a as h } from "./chunk-9bfc7485.js";
import "./chunk-725317a4.js";
var d, M = (e, i, a) => d ?? (d = new Promise((s) => {
  const o = (t) => {
    const { data: { cmd: r, scope: p, context: u }, ports: l } = t;
    if (r === "webext-port-offer" && p === i && u !== e)
      return window.removeEventListener("message", o), l[0].onmessage = a, l[0].postMessage("port-accepted"), s(l[0]);
  }, n = () => {
    const t = new MessageChannel();
    t.port1.onmessage = (r) => {
      if (r.data === "port-accepted")
        return window.removeEventListener("message", o), s(t.port1);
      a == null ? void 0 : a(r);
    }, window.postMessage({ cmd: "webext-port-offer", scope: i, context: e }, "*", [t.port2]);
  };
  window.addEventListener("message", o), e === "window" ? setTimeout(n, 0) : n();
})), L = (e) => {
  let i, a = false, s, o;
  return { enable: () => a = true, onMessage: (n) => s = n, postMessage: async (n) => {
    if (e !== "content-script" && e !== "window")
      throw new Error("Endpoint does not use postMessage");
    if (!a)
      throw new Error("Communication with window has not been allowed");
    return E(i), (await o).postMessage(n);
  }, setNamespace: (n) => {
    if (i)
      throw new Error("Namespace once set cannot be changed");
    i = n, o = M(e, n, ({ data: t }) => s == null ? void 0 : s(t));
  } };
};
function E(e) {
  if (typeof e != "string" || e.trim().length === 0)
    throw new Error(`webext-bridge uses window.postMessage to talk with other "window"(s) for message routingwhich is global/conflicting operation in case there are other scripts using webext-bridge. Call Bridge#setNamespace(nsps) to isolate your app. Example: setNamespace('com.facebook.react-devtools'). Make sure to use same namespace across all your scripts whereever window.postMessage is likely to be used\``);
}
var g = L("content-script"), w = m(), c = f("content-script", (e) => {
  e.destination.context === "window" ? g.postMessage(e) : w.postMessage(e);
});
g.onMessage((e) => {
  e.origin = { context: "window", tabId: null }, c.handleMessage(e);
});
w.onMessage(c.handleMessage);
w.onFailure((e) => {
  if (e.origin.context === "window") {
    g.postMessage({ type: "error", transactionID: e.transactionId });
    return;
  }
  c.endTransaction(e.transactionId);
});
var { sendMessage: N, onMessage: T } = c;
h(c);
(function(e, i) {
  console.log("NotebookLM inject"), s().then(async () => {
    let o = {};
    try {
      const r = window.localStorage.getItem("YT_NLM");
      r && (o = JSON.parse(r));
    } catch (r) {
      console.error("[NLM Tools] Corrupted auth storage:", r), window.localStorage.removeItem("YT_NLM");
    }
    try {
      const r = await N("YTUONG_NLM_PAYLOAD", o, "background");
      console.log("Response from background script:", r);
    } catch (r) {
      console.error("[NLM Tools] Failed to send auth payload:", r);
    }
    const t = (await chrome.storage.local.get("YT_NOTEBOOKLM_TOOLS_INTERFACE_LANGUAGE")).YT_NOTEBOOKLM_TOOLS_INTERFACE_LANGUAGE;
    if (t && new URL(window.location.href).searchParams.get("hl") !== t) {
      console.log("Auto-applying interface language:", t), a(t);
      return;
    }
  }).catch((o) => {
    console.error("Script injection failed:", o);
  }), e.runtime.onMessage.addListener((o, n, t) => {
    switch (o.type) {
      case "RELOAD_PAGE":
        window.location.reload();
        break;
      case "UPDATE_INTERFACE_LANGUAGE":
        a(o.languageCode);
        break;
    }
  });
  function a(o) {
    const n = new URL(window.location.href);
    n.searchParams.set("hl", o), n.toString() !== window.location.href && (window.location.href = n.toString());
  }
  function s() {
    return new Promise((o, n) => {
      var t = document.createElement("script");
      t.src = e.runtime.getURL("inject.js"), t.onload = function() {
        console.log("Inject script loaded successfully"), this.remove(), o();
      }, t.onerror = function() {
        console.error("Failed to load inject script"), this.remove(), n(new Error("Script loading failed"));
      }, (document.head || document.documentElement).appendChild(t);
    });
  }
})(chrome);
