import { l as s, aL as o } from "./chunk-68adfa56.js";
const c = 5, g = () => `action_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, d = (t) => {
  const e = Object.keys(t);
  if (e.length < c)
    return t;
  const i = e.sort((a, l) => t[a].timestamp - t[l].timestamp).slice(0, e.length - c + 1), r = { ...t };
  return i.forEach((a) => delete r[a]), r;
}, u = async (t) => {
  const e = g();
  let n = await s.get(o) || {};
  return n = d(n), n[e] = t, await s.set(o, n), e;
}, P = async (t) => t && (await s.get(o) || {})[t] || null, w = async (t) => {
  if (!t)
    return;
  const e = await s.get(o) || {};
  e[t] && (delete e[t], await s.set(o, e));
}, A = () => new URLSearchParams(window.location.hash.split("?")[1]).get("actionId");
export {
  P as a,
  A as g,
  w as r,
  u as s
};
