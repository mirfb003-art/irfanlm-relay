import { r as n, u as _, j as e, h as v, X as G, J as T, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as U, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { aB as z } from "./chunk-68adfa56.js";
import { i as X, z as Y, Q as H, E as K, e as O, __tla as __tla_2 } from "./chunk-2a4ab792.js";
import "./chunk-725317a4.js";
import { __tla as __tla_3 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let ie;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  function Q({ title: r, titleId: b, ...g }, k) {
    return n.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: k,
      "aria-labelledby": b
    }, g), r ? n.createElement("title", {
      id: b
    }, r) : null, n.createElement("path", {
      fillRule: "evenodd",
      d: "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-13a.75.75 0 0 0-1.5 0v5c0 .414.336.75.75.75h4a.75.75 0 0 0 0-1.5h-3.25V5Z",
      clipRule: "evenodd"
    }));
  }
  const W = n.forwardRef(Q), Z = W, J = 50, D = {
    synced: 0,
    processing: 0,
    failed: 0,
    failures: []
  }, y = "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700", w = "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200", V = {
    idle: 0,
    checking: 0,
    confirm: 1,
    syncing: 2,
    results: 3
  }, q = [
    {
      key: "synced",
      label: "updated",
      box: "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800",
      num: "text-green-700 dark:text-green-300",
      text: "text-green-600 dark:text-green-400"
    },
    {
      key: "processing",
      label: "processing",
      box: "bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800",
      num: "text-amber-700 dark:text-amber-300",
      text: "text-amber-600 dark:text-amber-400"
    },
    {
      key: "failed",
      label: "failed",
      box: "bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800",
      num: "text-red-700 dark:text-red-300",
      text: "text-red-600 dark:text-red-400"
    }
  ], ee = (r) => r ? r.phase === "checking" ? `Checking freshness\u2026 ${r.done}/${r.total}` : r.phase === "syncing" ? `Refreshing sources\u2026 ${r.done}/${r.total}` : r.phase === "verifying" ? `Confirming updates\u2026 ${r.done}/${r.total} done${r.remaining ? `, ${r.remaining} pending` : ""}` : "" : "";
  ie = function({ isOpen: r, onClose: b, selectedNotebookIds: g = [], notebooks: k = [] }) {
    var _a, _b;
    const [, C] = _(), [l, i] = n.useState("idle"), [d, h] = n.useState(null), [o, S] = n.useState(null), [a, f] = n.useState(null), m = n.useRef(null), c = n.useMemo(() => k.filter((t) => g.includes(t.id)), [
      k,
      g
    ]), x = n.useMemo(() => z(c), [
      c
    ]), p = l === "checking" || l === "syncing", R = n.useMemo(() => {
      const t = {};
      for (const s of x)
        t[s.notebookId] = (t[s.notebookId] || 0) + 1;
      return c.filter((s) => t[s.id]).map((s) => ({
        id: s.id,
        emoji: s.emoji,
        title: s.title,
        count: t[s.id]
      }));
    }, [
      x,
      c
    ]), j = c.length - R.length, E = n.useMemo(() => {
      if (!(o == null ? void 0 : o.stale))
        return [];
      const t = {};
      for (const s of o.stale)
        t[s.notebookId] || (t[s.notebookId] = {
          id: s.notebookId,
          title: s.notebookTitle,
          count: 0
        }), t[s.notebookId].count++;
      return Object.values(t);
    }, [
      o
    ]);
    n.useEffect(() => {
      r && (i("idle"), h(null), S(null), f(null), m.current = null);
    }, [
      r
    ]), n.useEffect(() => () => {
      var _a2;
      return (_a2 = m.current) == null ? void 0 : _a2.abort();
    }, []);
    const L = async () => {
      const t = new AbortController();
      m.current = t, h({
        phase: "checking",
        done: 0,
        total: x.length
      }), i("checking");
      try {
        const s = await C.checkSourcesFreshness({
          notebookIds: g,
          signal: t.signal,
          onProgress: h
        });
        if (s.cancelled) {
          i("idle");
          return;
        }
        if (s.authError) {
          f({
            ...D,
            authError: true
          }), i("results");
          return;
        }
        if (S(s), !s.stale.length) {
          f({
            ...D,
            alreadyFresh: s.total
          }), i("results");
          return;
        }
        i("confirm");
      } catch (s) {
        T.error((s == null ? void 0 : s.message) || "Freshness check failed"), i("idle");
      }
    }, $ = async (t) => {
      const s = new AbortController();
      m.current = s, h({
        phase: "syncing",
        done: 0,
        total: t.length
      }), i("syncing");
      try {
        const N = await C.refreshSourcesBulk(t, {
          signal: s.signal,
          onProgress: h
        });
        f(N), i("results");
      } catch (N) {
        T.error((N == null ? void 0 : N.message) || "Sync failed"), i("confirm");
      }
    }, B = () => {
      var _a2;
      return (_a2 = m.current) == null ? void 0 : _a2.abort();
    }, u = () => {
      p || b();
    }, F = (() => {
      if (!(d == null ? void 0 : d.total))
        return 0;
      if (d.phase === "syncing")
        return Math.round(Math.min(1, d.done / d.total) * 50);
      if (d.phase === "verifying") {
        const t = d.total - (d.remaining ?? 0);
        return Math.round(50 + Math.min(1, t / d.total) * 50);
      }
      return Math.round(Math.min(1, d.done / d.total) * 100);
    })(), M = [
      "Check",
      "Review",
      "Sync"
    ], I = V[l] ?? 0, P = l !== "results" || a && !a.authError && !a.alreadyFresh, A = {
      idle: "Sync Drive Sources",
      checking: "Checking sources",
      confirm: "Review changes",
      syncing: "Syncing sources",
      results: "Sync results"
    };
    return e.jsxs(X, {
      open: r,
      onClose: u,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Y, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(H, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(v, {
                        className: "w-4 h-4"
                      }),
                      A[l] || "Sync Drive Sources"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: u,
                    disabled: p,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(G, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex-1 overflow-y-auto p-4 space-y-4",
                children: [
                  P && e.jsx("div", {
                    className: "flex items-center gap-1.5",
                    children: M.map((t, s) => e.jsxs("div", {
                      className: "flex items-center gap-1.5",
                      children: [
                        e.jsxs("span", {
                          className: `px-2 py-0.5 rounded-full text-xs font-medium ${s === I ? "bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900" : s < I ? "bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-slate-300" : "bg-gray-100 dark:bg-slate-800 text-gray-400 dark:text-slate-500"}`,
                          children: [
                            s + 1,
                            ". ",
                            t
                          ]
                        }),
                        s < M.length - 1 && e.jsx("span", {
                          className: "text-gray-300 dark:text-slate-600",
                          children: "\u2192"
                        })
                      ]
                    }, t))
                  }),
                  l === "idle" && e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("div", {
                        className: "bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border border-gray-200 dark:border-slate-700",
                        children: e.jsxs("p", {
                          className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                          children: [
                            c.length,
                            " notebook",
                            c.length !== 1 ? "s" : "",
                            " ",
                            "selected",
                            e.jsxs("span", {
                              className: "text-gray-500 dark:text-slate-400 font-normal ml-2",
                              children: [
                                x.length,
                                " Google Drive source",
                                x.length !== 1 ? "s" : ""
                              ]
                            })
                          ]
                        })
                      }),
                      x.length === 0 ? e.jsx("p", {
                        className: "text-xs text-gray-500 dark:text-slate-400",
                        children: "None of the selected notebooks have Google Drive sources to sync."
                      }) : e.jsxs(e.Fragment, {
                        children: [
                          e.jsxs("div", {
                            className: "bg-gray-50 dark:bg-slate-900 p-3 rounded-lg border border-gray-200 dark:border-slate-700",
                            children: [
                              e.jsx("div", {
                                className: "max-h-32 overflow-y-auto space-y-1",
                                children: R.map((t) => e.jsxs("div", {
                                  className: "flex items-center justify-between gap-2 text-xs",
                                  children: [
                                    e.jsxs("span", {
                                      className: "text-gray-700 dark:text-slate-300 truncate",
                                      children: [
                                        t.emoji ? `${t.emoji} ` : "",
                                        t.title
                                      ]
                                    }),
                                    e.jsxs("span", {
                                      className: "text-gray-400 dark:text-slate-500 flex-shrink-0",
                                      children: [
                                        t.count,
                                        " source",
                                        t.count !== 1 ? "s" : ""
                                      ]
                                    })
                                  ]
                                }, t.id))
                              }),
                              j > 0 && e.jsxs("p", {
                                className: "text-xs text-gray-400 dark:text-slate-500 mt-1.5",
                                children: [
                                  j,
                                  " notebook",
                                  j !== 1 ? "s" : "",
                                  " have no Drive sources \u2014 skipped."
                                ]
                              })
                            ]
                          }),
                          e.jsx("p", {
                            className: "text-xs text-gray-500 dark:text-slate-400",
                            children: "We'll check which Drive sources changed, then refresh only those and confirm they're updated. Keep this side panel open until it finishes."
                          })
                        ]
                      })
                    ]
                  }),
                  (l === "checking" || l === "syncing") && e.jsxs("div", {
                    className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center justify-between gap-2 mb-2",
                        children: [
                          e.jsxs("div", {
                            className: "flex items-center gap-2 min-w-0",
                            children: [
                              e.jsx(U, {
                                className: "w-3.5 h-3.5"
                              }),
                              e.jsx("span", {
                                className: "text-xs font-medium text-blue-700 dark:text-blue-300 truncate",
                                children: ee(d)
                              })
                            ]
                          }),
                          e.jsxs("span", {
                            className: "text-xs font-medium text-blue-700 dark:text-blue-300 flex-shrink-0",
                            children: [
                              F,
                              "%"
                            ]
                          })
                        ]
                      }),
                      e.jsx("div", {
                        className: "w-full bg-blue-200 dark:bg-blue-900 rounded-full h-1.5",
                        children: e.jsx("div", {
                          className: "bg-blue-600 h-1.5 rounded-full",
                          style: {
                            width: `${F}%`
                          }
                        })
                      }),
                      (d == null ? void 0 : d.notebookTitle) && e.jsx("p", {
                        className: "text-xs text-blue-600 dark:text-blue-400 mt-1 truncate",
                        children: d.notebookTitle
                      })
                    ]
                  }),
                  l === "confirm" && o && e.jsxs(e.Fragment, {
                    children: [
                      e.jsxs("div", {
                        className: "bg-amber-50 dark:bg-amber-950 p-3 rounded-lg border border-amber-200 dark:border-amber-800 space-y-1",
                        children: [
                          e.jsxs("p", {
                            className: "text-xs font-medium text-amber-800 dark:text-amber-200",
                            children: [
                              o.stale.length,
                              " of ",
                              o.total,
                              " source",
                              o.total !== 1 ? "s" : "",
                              " need updating across ",
                              o.staleNotebookCount,
                              " notebook",
                              o.staleNotebookCount !== 1 ? "s" : "",
                              "."
                            ]
                          }),
                          e.jsx("p", {
                            className: "text-xs text-amber-700 dark:text-amber-300",
                            children: o.stale.length >= J ? "This can take several minutes \u2014 keep the side panel open until it finishes." : "Keep the side panel open until it finishes."
                          })
                        ]
                      }),
                      E.length > 0 && e.jsxs("div", {
                        className: "border border-gray-200 dark:border-slate-700 rounded-lg",
                        children: [
                          e.jsx("div", {
                            className: "px-2.5 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 border-b border-gray-200 dark:border-slate-700",
                            children: "Sources to update"
                          }),
                          e.jsx("div", {
                            className: "max-h-32 overflow-y-auto divide-y divide-gray-100 dark:divide-slate-700",
                            children: E.map((t) => e.jsxs("div", {
                              className: "px-2.5 py-1.5 flex items-center justify-between gap-2",
                              children: [
                                e.jsx("span", {
                                  className: "text-xs text-gray-700 dark:text-slate-300 truncate",
                                  children: t.title
                                }),
                                e.jsxs("span", {
                                  className: "text-xs text-gray-400 dark:text-slate-500 flex-shrink-0",
                                  children: [
                                    t.count,
                                    " source",
                                    t.count !== 1 ? "s" : ""
                                  ]
                                })
                              ]
                            }, t.id))
                          })
                        ]
                      })
                    ]
                  }),
                  l === "results" && a && e.jsx("div", {
                    className: "space-y-3",
                    children: a.authError ? e.jsxs("div", {
                      className: "bg-red-50 dark:bg-red-950 p-3 rounded-lg border border-red-200 dark:border-red-800 flex items-start gap-2",
                      children: [
                        e.jsx(K, {
                          className: "w-4 h-4 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5"
                        }),
                        e.jsx("p", {
                          className: "text-xs text-red-700 dark:text-red-300",
                          children: "Your NotebookLM session expired. Please reconnect and try again."
                        })
                      ]
                    }) : a.alreadyFresh ? e.jsxs("div", {
                      className: "bg-green-50 dark:bg-green-950 p-3 rounded-lg border border-green-200 dark:border-green-800 flex items-center gap-2",
                      children: [
                        e.jsx(O, {
                          className: "w-4 h-4 text-green-600 dark:text-green-400"
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-green-700 dark:text-green-300",
                          children: [
                            "All ",
                            a.alreadyFresh,
                            " source",
                            a.alreadyFresh !== 1 ? "s are" : " is",
                            " ",
                            "already up to date."
                          ]
                        })
                      ]
                    }) : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx("div", {
                          className: "grid grid-cols-3 gap-2",
                          children: q.map((t) => e.jsxs("div", {
                            className: `p-2 rounded-lg border text-center ${t.box}`,
                            children: [
                              e.jsx("div", {
                                className: `text-sm font-semibold ${t.num}`,
                                children: a[t.key]
                              }),
                              e.jsx("div", {
                                className: `text-xs ${t.text}`,
                                children: t.label
                              })
                            ]
                          }, t.key))
                        }),
                        a.processing > 0 && e.jsxs("p", {
                          className: "text-xs text-gray-500 dark:text-slate-400 flex items-start gap-1.5",
                          children: [
                            e.jsx(Z, {
                              className: "w-3.5 h-3.5 flex-shrink-0 mt-0.5"
                            }),
                            "Refresh was sent for the processing sources \u2014 NotebookLM is finishing them in the background."
                          ]
                        }),
                        a.cancelled && e.jsx("p", {
                          className: "text-xs text-gray-500 dark:text-slate-400",
                          children: "Sync was cancelled \u2014 partial results shown."
                        }),
                        ((_a = a.failures) == null ? void 0 : _a.length) > 0 && e.jsxs("div", {
                          className: "border border-gray-200 dark:border-slate-700 rounded-lg",
                          children: [
                            e.jsx("div", {
                              className: "px-2.5 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 border-b border-gray-200 dark:border-slate-700",
                              children: "Failed sources"
                            }),
                            e.jsx("div", {
                              className: "max-h-32 overflow-y-auto divide-y divide-gray-100 dark:divide-slate-700",
                              children: a.failures.map((t) => e.jsxs("div", {
                                className: "px-2.5 py-1.5",
                                children: [
                                  e.jsx("div", {
                                    className: "text-xs text-gray-700 dark:text-slate-300 truncate",
                                    children: t.title
                                  }),
                                  e.jsxs("div", {
                                    className: "text-xs text-gray-400 dark:text-slate-500 truncate",
                                    children: [
                                      t.notebookTitle,
                                      " \xB7 ",
                                      t.error
                                    ]
                                  })
                                ]
                              }, `${t.notebookId}-${t.sourceId}`))
                            })
                          ]
                        })
                      ]
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                children: [
                  l === "idle" && e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("button", {
                        onClick: u,
                        className: y,
                        children: "Cancel"
                      }),
                      e.jsxs("button", {
                        onClick: L,
                        disabled: x.length === 0,
                        className: `${w} disabled:opacity-50 flex items-center gap-1.5`,
                        children: [
                          e.jsx(v, {
                            className: "w-3.5 h-3.5"
                          }),
                          "Check sources"
                        ]
                      })
                    ]
                  }),
                  p && e.jsx("button", {
                    onClick: B,
                    className: y,
                    children: "Cancel"
                  }),
                  l === "confirm" && o && e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("button", {
                        onClick: u,
                        className: y,
                        children: "Cancel"
                      }),
                      e.jsxs("button", {
                        onClick: () => $(o.stale),
                        className: `${w} flex items-center gap-1.5`,
                        children: [
                          e.jsx(v, {
                            className: "w-3.5 h-3.5"
                          }),
                          "Sync ",
                          o.stale.length,
                          " now"
                        ]
                      })
                    ]
                  }),
                  l === "results" && a && e.jsxs(e.Fragment, {
                    children: [
                      ((_b = a.failures) == null ? void 0 : _b.length) > 0 && e.jsx("button", {
                        onClick: () => $(a.failures),
                        className: y,
                        children: "Retry failed"
                      }),
                      e.jsx("button", {
                        onClick: u,
                        className: w,
                        children: "Done"
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  ie as default
};
