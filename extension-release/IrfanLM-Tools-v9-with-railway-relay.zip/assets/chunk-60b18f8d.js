import { j as e, r as n, k as z, u as P, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { L as B, __tla as __tla_1 } from "./chunk-cbc671dd.js";
import { P as U, L as M, __tla as __tla_2 } from "./chunk-abc94b21.js";
import { C as J, __tla as __tla_3 } from "./chunk-7d0f6285.js";
import { A as T, __tla as __tla_4 } from "./chunk-57988b21.js";
import { A as G, __tla as __tla_5 } from "./chunk-4115c378.js";
import { am as Q, __tla as __tla_6 } from "./chunk-2a4ab792.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import { __tla as __tla_7 } from "./chunk-1784b260.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let de;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })()
]).then(async () => {
  function Y({ ratings: a, total: l, sessionStart: p, onReviewMissed: x, onStartOver: k }) {
    const c = Object.values(a).filter((d) => d === "correct").length, o = l - c, g = l > 0 ? Math.round(c / l * 100) : 0, u = g > 70 ? "text-green-600 dark:text-green-400" : g > 40 ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400", m = Math.round((Date.now() - p) / 1e3), y = Math.floor(m / 60), h = m % 60, v = y > 0 ? `${y}m ${h}s` : `${h}s`;
    return e.jsxs("div", {
      className: "space-y-4 text-center py-6",
      children: [
        e.jsxs("p", {
          className: `text-sm font-semibold ${u}`,
          children: [
            c,
            " / ",
            l,
            " correct (",
            g,
            "%)"
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center justify-center gap-3 text-[11px] text-gray-500 dark:text-slate-400",
          children: [
            e.jsx("span", {
              children: v
            }),
            e.jsx("span", {
              children: "\xB7"
            }),
            e.jsxs("span", {
              children: [
                l > 0 ? Math.round(m / l) : 0,
                "s/card"
              ]
            })
          ]
        }),
        e.jsx(U, {
          value: c,
          max: l,
          color: "bg-purple-500"
        }),
        e.jsxs("div", {
          className: "flex items-center justify-center gap-2",
          children: [
            o > 0 && e.jsxs("button", {
              onClick: x,
              className: "px-3 py-1.5 text-xs font-medium bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 rounded-md",
              children: [
                "Review ",
                o,
                " missed"
              ]
            }),
            e.jsx("button", {
              onClick: k,
              className: "px-3 py-1.5 text-xs font-medium bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300 rounded-md",
              children: "Start over"
            })
          ]
        })
      ]
    });
  }
  const q = (a) => {
    const l = [
      ...a
    ];
    for (let p = l.length - 1; p > 0; p--) {
      const x = Math.floor(Math.random() * (p + 1));
      [l[p], l[x]] = [
        l[x],
        l[p]
      ];
    }
    return l;
  };
  function K({ cards: a, isFullscreen: l = false, artifactId: p }) {
    var _a, _b;
    if (!a || a.length === 0)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400 py-4 text-center",
        children: "No flashcards available."
      });
    const x = p ? `fc_study_${p}` : null, k = n.useMemo(() => {
      var _a2;
      if (!x)
        return null;
      try {
        const s = sessionStorage.getItem(x), r = s ? JSON.parse(s) : null;
        return ((_a2 = r == null ? void 0 : r.indexOrder) == null ? void 0 : _a2.every((w) => w >= 0 && w < a.length)) ? r : null;
      } catch {
        return null;
      }
    }, [
      x,
      a.length
    ]), [c, o] = n.useState(() => (k == null ? void 0 : k.currentIndex) ?? 0), [g, u] = n.useState(false), [m, y] = n.useState(() => (k == null ? void 0 : k.ratings) ?? {}), [h, v] = n.useState(() => (k == null ? void 0 : k.shuffled) ?? false), [d, N] = n.useState(() => (k == null ? void 0 : k.indexOrder) ?? a.map((s, r) => r)), [t, i] = n.useState(null), f = n.useRef(Date.now()), C = n.useRef(null);
    n.useEffect(() => {
      if (x)
        try {
          sessionStorage.setItem(x, JSON.stringify({
            currentIndex: c,
            ratings: m,
            indexOrder: d,
            shuffled: h
          }));
        } catch {
        }
    }, [
      c,
      m,
      d,
      h,
      x
    ]);
    const S = d[c], j = a[S] || a[0], E = Object.keys(m).length, I = E === d.length, b = n.useCallback((s) => {
      s >= 0 && s < d.length && (o(s), u(false));
    }, [
      d.length
    ]), R = n.useCallback((s) => {
      if (d.length === 0)
        return null;
      for (let r = 1; r <= d.length; r++) {
        const w = (s + r) % d.length;
        if (!m[d[w]])
          return w;
      }
      return null;
    }, [
      d,
      m
    ]), F = (s) => {
      i({
        index: c,
        prevRatings: m
      });
      const r = {
        ...m,
        [S]: s
      };
      if (y(r), Object.keys(r).length < d.length) {
        const O = R(c);
        O !== null && b(O), setTimeout(() => {
          var _a2;
          return (_a2 = C.current) == null ? void 0 : _a2.focus();
        }, 50);
      } else
        u(false);
    }, A = () => {
      t && (y(t.prevRatings), o(t.index), u(true), i(null));
    }, $ = () => {
      N(h ? a.map((s, r) => r) : q(a.map((s, r) => r))), v(!h), o(0), u(false);
    }, L = () => {
      N(a.map((s, r) => r)), y({}), o(0), u(false), v(false), i(null), f.current = Date.now(), x && sessionStorage.removeItem(x);
    }, V = () => {
      const s = Object.entries(m).filter(([, r]) => r === "missed").map(([r]) => Number(r));
      s.length !== 0 && (N(s), y({}), o(0), u(false), v(false), i(null), f.current = Date.now());
    }, _ = n.useRef(), D = n.useRef();
    return _.current = F, D.current = A, n.useEffect(() => {
      const s = (r) => {
        const w = r.target.tagName.toLowerCase();
        w === "input" || w === "textarea" || (r.key === "ArrowLeft" ? b(c - 1) : r.key === "ArrowRight" ? b(c + 1) : r.key === " " ? (r.preventDefault(), u((O) => !O)) : g && r.key === "1" ? _.current("correct") : g && r.key === "2" ? _.current("missed") : r.key === "z" && D.current());
      };
      return window.addEventListener("keydown", s), () => window.removeEventListener("keydown", s);
    }, [
      c,
      b,
      g
    ]), I ? e.jsx(Y, {
      ratings: m,
      total: d.length,
      sessionStart: f.current,
      onReviewMissed: V,
      onStartOver: L
    }) : e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsx("button", {
          onClick: $,
          className: `px-2 py-1 text-xs font-medium rounded-md ${h ? "bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300" : "text-gray-600 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200"}`,
          children: "Shuffle"
        }),
        e.jsx(U, {
          value: E,
          max: d.length,
          color: "bg-purple-500"
        }),
        e.jsx("div", {
          ref: C,
          role: "button",
          tabIndex: 0,
          "aria-label": g ? "Answer card, click to flip back" : "Question card, click to reveal answer",
          style: {
            perspective: "1000px"
          },
          className: `${l ? "min-h-[60vh]" : "min-h-[200px]"} cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-purple-500 rounded-lg`,
          onClick: () => u((s) => !s),
          onKeyDown: (s) => {
            s.key === "Enter" && u((r) => !r);
          },
          children: e.jsxs("div", {
            className: `relative w-full h-full ${l ? "min-h-[60vh]" : "min-h-[200px]"}`,
            style: {
              transformStyle: "preserve-3d",
              willChange: "transform",
              transform: g ? "rotateY(180deg)" : "rotateY(0deg)",
              transition: ((_b = (_a = window.matchMedia) == null ? void 0 : _a.call(window, "(prefers-reduced-motion: reduce)")) == null ? void 0 : _b.matches) ? "none" : "transform 0.4s"
            },
            children: [
              e.jsx("div", {
                className: "absolute inset-0 flex items-center justify-center p-6 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg",
                style: {
                  backfaceVisibility: "hidden"
                },
                children: e.jsx("p", {
                  className: "text-sm font-medium text-gray-900 dark:text-slate-100 text-center",
                  children: e.jsx(M, {
                    children: j.f
                  })
                })
              }),
              e.jsx("div", {
                className: "absolute inset-0 flex items-center justify-center p-6 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg",
                style: {
                  backfaceVisibility: "hidden",
                  transform: "rotateY(180deg)"
                },
                children: e.jsx("p", {
                  className: "text-sm font-medium text-blue-900 dark:text-blue-100 text-center",
                  children: e.jsx(M, {
                    children: j.b
                  })
                })
              })
            ]
          })
        }),
        g && e.jsxs("div", {
          className: "flex flex-col items-center gap-1.5",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs("button", {
                  onClick: (s) => {
                    s.stopPropagation(), F("correct");
                  },
                  className: "bg-green-100 dark:bg-green-950 text-green-700 dark:text-green-300 px-3 py-1.5 text-xs font-medium rounded-md",
                  children: [
                    "Got it ",
                    e.jsx("kbd", {
                      className: "ml-1 opacity-60",
                      children: "1"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: (s) => {
                    s.stopPropagation(), F("missed");
                  },
                  className: "bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 px-3 py-1.5 text-xs font-medium rounded-md",
                  children: [
                    "Missed it ",
                    e.jsx("kbd", {
                      className: "ml-1 opacity-60",
                      children: "2"
                    })
                  ]
                })
              ]
            }),
            t && e.jsxs("button", {
              onClick: A,
              className: "text-[11px] text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300",
              children: [
                "Undo ",
                e.jsx("kbd", {
                  className: "opacity-60",
                  children: "z"
                })
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center justify-center gap-3",
          children: [
            e.jsx("button", {
              onClick: () => b(c - 1),
              disabled: c === 0,
              className: "p-1 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200 disabled:opacity-30",
              children: e.jsx(J, {
                className: "w-5 h-5"
              })
            }),
            e.jsxs("span", {
              className: "text-xs text-gray-600 dark:text-slate-400",
              children: [
                c + 1,
                " / ",
                d.length
              ]
            }),
            e.jsx("button", {
              onClick: () => b(c + 1),
              disabled: c === d.length - 1,
              className: "p-1 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200 disabled:opacity-30",
              children: e.jsx(z, {
                className: "w-5 h-5"
              })
            })
          ]
        }),
        e.jsxs("p", {
          className: "text-center text-[10px] text-gray-400 dark:text-slate-500",
          children: [
            "Space flip \xB7 Arrows navigate",
            g ? " \xB7 1 got it \xB7 2 missed" : "",
            t ? " \xB7 z undo" : ""
          ]
        })
      ]
    });
  }
  function H({ cards: a, artifactId: l }) {
    const [p, x] = n.useState({}), [k, c] = n.useState(false), [o, g] = n.useState("all"), u = n.useMemo(() => {
      var _a;
      if (!l)
        return {};
      try {
        const t = sessionStorage.getItem(`fc_study_${l}`);
        return t ? ((_a = JSON.parse(t)) == null ? void 0 : _a.ratings) || {} : {};
      } catch {
        return {};
      }
    }, [
      l
    ]), m = Object.keys(u).length > 0, y = n.useMemo(() => {
      const t = a.map((i, f) => f);
      return o === "all" || !m ? t : t.filter((i) => {
        const f = u[i];
        return o === "correct" ? f === "correct" : o === "missed" ? f === "missed" : !f;
      });
    }, [
      a,
      o,
      u,
      m
    ]), h = () => {
      if (k)
        x({}), c(false);
      else {
        const t = {};
        a.forEach((i, f) => {
          t[f] = true;
        }), x(t), c(true);
      }
    }, v = (t) => {
      x((i) => {
        const f = {
          ...i,
          [t]: !i[t]
        }, C = Object.values(f).filter(Boolean).length;
        return c(C === a.length), f;
      });
    }, d = (t) => {
      const i = u[t];
      return i === "correct" ? "border-l-4 border-l-green-400 dark:border-l-green-600" : i === "missed" ? "border-l-4 border-l-red-400 dark:border-l-red-600" : "";
    }, N = [
      [
        "all",
        "All",
        null
      ],
      [
        "correct",
        "Got it",
        "text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-950"
      ],
      [
        "missed",
        "Missed",
        "text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-950"
      ],
      [
        "unrated",
        "Unrated",
        null
      ]
    ];
    return e.jsxs("div", {
      className: "space-y-2",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-1.5 flex-wrap",
          children: [
            e.jsx("button", {
              onClick: h,
              className: "px-2 py-0.5 text-[11px] font-medium text-gray-600 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200",
              children: k ? "Hide all" : "Reveal all"
            }),
            m && N.map(([t, i, f]) => e.jsx("button", {
              onClick: () => g(t),
              className: `px-2 py-0.5 text-[11px] font-medium rounded-full ${o === t ? f || "bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-slate-100" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200"}`,
              children: i
            }, t))
          ]
        }),
        y.map((t) => {
          const i = a[t];
          return e.jsxs("button", {
            onClick: () => v(t),
            className: `w-full text-left border border-gray-200 dark:border-slate-700 rounded-lg p-3 hover:bg-gray-50 dark:hover:bg-slate-700 cursor-pointer ${d(t)}`,
            children: [
              e.jsxs("div", {
                className: "flex items-start justify-between gap-2",
                children: [
                  e.jsx("p", {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: e.jsx(M, {
                      children: i.f
                    })
                  }),
                  e.jsxs("span", {
                    className: "text-[11px] text-gray-400 dark:text-slate-500 flex-shrink-0",
                    children: [
                      t + 1,
                      " / ",
                      a.length
                    ]
                  })
                ]
              }),
              p[t] ? e.jsxs("div", {
                className: "mt-2 border-t border-gray-100 dark:border-slate-700 pt-2",
                children: [
                  e.jsx("p", {
                    className: "text-[11px] font-medium text-gray-400 dark:text-slate-500 mb-1",
                    children: "Answer"
                  }),
                  e.jsx("p", {
                    className: "text-xs text-gray-700 dark:text-slate-300",
                    children: e.jsx(M, {
                      children: i.b
                    })
                  })
                ]
              }) : e.jsx("p", {
                className: "mt-1 text-[11px] text-gray-400 dark:text-slate-500",
                children: "Click to reveal answer"
              })
            ]
          }, t);
        }),
        y.length === 0 && e.jsx("p", {
          className: "text-center py-4 text-xs text-gray-400 dark:text-slate-500",
          children: "No cards match this filter"
        })
      ]
    });
  }
  de = function({ content: a, artifact: l, notebookId: p }) {
    const [x, k] = P(), { quizContentMap: c } = x.artifacts, o = l == null ? void 0 : l.id, g = o ? c[o] : null, u = g == null ? void 0 : g.data, m = g == null ? void 0 : g.loading, y = g == null ? void 0 : g.error, h = !!(a == null ? void 0 : a.content), [v, d] = n.useState("study"), N = n.useRef(null), [t, i] = n.useState(false), f = n.useCallback(() => {
      var _a;
      document.fullscreenElement ? document.exitFullscreen() : (_a = N.current) == null ? void 0 : _a.requestFullscreen();
    }, []);
    n.useEffect(() => {
      const b = N.current;
      if (!b)
        return;
      const R = () => i(document.fullscreenElement === b);
      return b.addEventListener("fullscreenchange", R), () => b.removeEventListener("fullscreenchange", R);
    }, []), n.useEffect(() => {
      !h && o && p && !g && k.fetchQuizContent(o, p);
    }, [
      o,
      p,
      h
    ]);
    const C = u == null ? void 0 : u.flashcards;
    let S = null;
    if (h)
      try {
        const b = typeof a.content == "string" ? JSON.parse(a.content) : a.content;
        (b == null ? void 0 : b.flashcards) && (S = b.flashcards);
      } catch {
      }
    const j = C || S, E = (j == null ? void 0 : j.length) ? `${j.length} Flashcards` : "Flashcards", I = () => {
      if (!(j == null ? void 0 : j.length))
        return;
      const b = (L) => `"${String(L || "").replace(/"/g, '""')}"`, R = [
        '"Front","Back"',
        ...j.map((L) => `${b(L.f)},${b(L.b)}`)
      ], F = new Blob([
        R.join(`
`)
      ], {
        type: "text/csv"
      }), A = URL.createObjectURL(F), $ = document.createElement("a");
      $.href = A, $.download = `${(l == null ? void 0 : l.title) || "flashcards"}.csv`, $.click(), URL.revokeObjectURL(A);
    };
    return e.jsxs("div", {
      ref: N,
      className: `space-y-3 ${t ? "bg-white dark:bg-slate-900 p-4 overflow-y-auto h-screen" : ""}`,
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("div", {
              className: "inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200",
              children: E
            }),
            (j == null ? void 0 : j.length) > 0 && e.jsxs(e.Fragment, {
              children: [
                e.jsx("button", {
                  onClick: () => d("study"),
                  className: `px-2 py-1 text-xs font-medium rounded-md ${v === "study" ? "bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-slate-100" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200"}`,
                  children: "Study"
                }),
                e.jsx("button", {
                  onClick: () => d("list"),
                  className: `px-2 py-1 text-xs font-medium rounded-md ${v === "list" ? "bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-slate-100" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200"}`,
                  children: "List"
                }),
                e.jsxs("button", {
                  onClick: I,
                  className: "inline-flex items-center gap-1 px-1.5 py-0.5 text-[11px] text-gray-600 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200 rounded hover:bg-gray-100 dark:hover:bg-slate-800 ml-auto",
                  title: "Export as CSV (Anki-compatible)",
                  children: [
                    e.jsx(T, {
                      className: "w-3 h-3"
                    }),
                    "CSV"
                  ]
                }),
                e.jsx("button", {
                  onClick: f,
                  className: "p-1 text-gray-600 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200 rounded hover:bg-gray-100 dark:hover:bg-slate-800",
                  title: t ? "Exit fullscreen" : "Fullscreen",
                  children: t ? e.jsx(G, {
                    className: "w-3.5 h-3.5"
                  }) : e.jsx(Q, {
                    className: "w-3.5 h-3.5"
                  })
                })
              ]
            })
          ]
        }),
        h && !S && e.jsx("p", {
          className: "text-xs text-gray-500 dark:text-slate-400",
          children: "Could not parse flashcard content."
        }),
        !h && m && e.jsx("div", {
          className: "flex items-center justify-center py-8",
          children: e.jsx(B, {
            text: "Loading flashcards..."
          })
        }),
        !h && y && e.jsxs("div", {
          className: "text-center py-6 space-y-2",
          children: [
            e.jsxs("p", {
              className: "text-xs text-red-600 dark:text-red-400",
              children: [
                "Failed to load content: ",
                y
              ]
            }),
            e.jsx("button", {
              onClick: () => k.fetchQuizContent(o, p),
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
              children: "Retry"
            })
          ]
        }),
        !h && u && !C && e.jsx("p", {
          className: "text-xs text-gray-500 dark:text-slate-400",
          children: "Could not parse flashcard content from the response."
        }),
        j && v === "study" && e.jsx(K, {
          cards: j,
          isFullscreen: t,
          artifactId: o
        }),
        j && v === "list" && e.jsx(H, {
          cards: j,
          artifactId: o
        })
      ]
    });
  };
});
export {
  __tla,
  de as default
};
