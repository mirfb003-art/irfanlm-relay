// ─────────────────────────────────────────────────────────────────────────
// Lovable Bridge (custom addon) — notebook tracker
//
// NotebookLM has no known RPC that lists ALL of a user's notebooks — every
// RPC the bridge exposes (rLM1Ne, gArtLc) takes a specific notebookId. So
// instead of guessing at one, this script just records every notebook the
// user actually opens while browsing notebooklm.google.com, into a
// bridge-owned chrome.storage.local key. LIST_NOTEBOOKS (in
// nlm-lovable-bridge-bg.js) reads that registry back for the web app.
//
// Runs alongside the existing content_scripts entry on notebooklm.google.com.
// ─────────────────────────────────────────────────────────────────────────

(() => {
  "use strict";

  const KNOWN_NOTEBOOKS_KEY = "__nlmBridge_knownNotebooks";

  function detectNotebookId() {
    const m = location.hash.match(/\/notebook\/([a-zA-Z0-9_-]+)/);
    return m ? m[1] : null;
  }

  function detectTitle() {
    // NotebookLM sets document.title to "<notebook title> - NotebookLM" once
    // the page has loaded; fall back to a placeholder until it settles.
    const raw = document.title || "";
    const cleaned = raw.replace(/\s*-\s*NotebookLM\s*$/i, "").trim();
    return cleaned || null;
  }

  async function recordCurrentNotebook() {
    const id = detectNotebookId();
    if (!id) return;

    const title = detectTitle();
    const store = await chrome.storage.local.get(KNOWN_NOTEBOOKS_KEY);
    const map = store[KNOWN_NOTEBOOKS_KEY] || {};

    map[id] = {
      id,
      title: title || map[id]?.title || "Untitled notebook",
      lastSeen: Date.now(),
    };

    await chrome.storage.local.set({ [KNOWN_NOTEBOOKS_KEY]: map });
  }

  // Debounced: title/hash can each fire multiple times during SPA navigation.
  let pending = null;
  function scheduleRecord() {
    clearTimeout(pending);
    pending = setTimeout(recordCurrentNotebook, 800);
  }

  scheduleRecord();
  window.addEventListener("hashchange", scheduleRecord);

  // Catches the async title update after the notebook finishes loading,
  // without needing a broad, expensive DOM MutationObserver.
  const titleEl = document.querySelector("title");
  if (titleEl) {
    new MutationObserver(scheduleRecord).observe(titleEl, { childList: true });
  }
})();
