import { j as e, X as x, r as n, a8 as i, J as l, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { A as p, __tla as __tla_1 } from "./chunk-fc2109f5.js";
import { ac as o } from "./chunk-68adfa56.js";
import { C as m, __tla as __tla_2 } from "./chunk-9b02a51a.js";
import { i as u, z as g, Q as _, __tla as __tla_3 } from "./chunk-2a4ab792.js";
import "./chunk-725317a4.js";
import { __tla as __tla_4 } from "./chunk-4c77bdf2.js";
import { __tla as __tla_5 } from "./chunk-95b0b380.js";
import { __tla as __tla_6 } from "./chunk-cbc671dd.js";
import { __tla as __tla_7 } from "./chunk-1784b260.js";
import "./chunk-378f9272.js";
import { __tla as __tla_8 } from "./chunk-3daa5dc5.js";
import { __tla as __tla_9 } from "./chunk-b5767d08.js";
import { __tla as __tla_10 } from "./chunk-bd7b16ee.js";
import { __tla as __tla_11 } from "./chunk-57988b21.js";
import { __tla as __tla_12 } from "./chunk-de7ca15a.js";
import { __tla as __tla_13 } from "./chunk-b81ff817.js";
import { __tla as __tla_14 } from "./chunk-1302cd21.js";
import "./chunk-e153acea.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let Z;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_10;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_11;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_12;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_13;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_14;
    } catch {
    }
  })()
]).then(async () => {
  const f = n.lazy(() => i(() => import("./chunk-09dda41b.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-09dda41b.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-93ad41a0.js","assets/chunk-cfcef7af.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-57988b21.js"])), h = n.lazy(() => i(() => import("./chunk-c0faca66.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-c0faca66.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-e0aab7c8.js"])), y = n.lazy(() => i(() => import("./chunk-309d0f02.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-309d0f02.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-93ad41a0.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-cfcef7af.js","assets/chunk-57988b21.js"])), b = n.lazy(() => i(() => import("./chunk-60208c12.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-60208c12.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-abc94b21.js"])), j = n.lazy(() => i(() => import("./chunk-60b18f8d.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-60b18f8d.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-abc94b21.js","assets/chunk-7d0f6285.js","assets/chunk-57988b21.js","assets/chunk-4115c378.js"])), k = n.lazy(() => i(() => import("./chunk-93132de4.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-93132de4.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js"])), v = n.lazy(() => i(() => import("./chunk-860622dc.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-860622dc.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-4115c378.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-57988b21.js"])), E = n.lazy(() => i(() => import("./chunk-2aee98a6.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-2aee98a6.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css"])), R = n.lazy(() => i(() => import("./chunk-6578eedd.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-6578eedd.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-4115c378.js"])), A = n.lazy(() => i(() => import("./chunk-2e5e75b9.js").then(async (m2) => {
    await m2.__tla;
    return m2;
  }), ["assets/chunk-2e5e75b9.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-e0aab7c8.js"]));
  function N(s) {
    const r = s == null ? void 0 : s.parsedContent;
    if (!r)
      return null;
    if (r.slides && Array.isArray(r.slides))
      return r.slides.map((a) => {
        const d = [];
        return a.description && d.push(a.description), a.text && d.push(a.text), d.join(`
`);
      }).join(`

---

`);
    if (r.imageUrl) {
      const t = [];
      return r.description && t.push(r.description), r.text && t.push(r.text), t.length ? t.join(`

`) : null;
    }
    if (r.markdown)
      return r.markdown;
    if (r.text)
      return r.text;
    if (r.description)
      return r.description;
    if (r.headers && r.rows) {
      const t = [];
      r.headers.length && t.push(r.headers.join("	"));
      for (const a of r.rows)
        t.push(a.join("	"));
      return t.join(`
`);
    }
    return null;
  }
  function T({ artifact: s, notebookId: r }) {
    const t = s == null ? void 0 : s.parsedContent;
    if (!s.isReady)
      return e.jsxs("div", {
        className: "flex items-center gap-2 py-4",
        children: [
          e.jsx("span", {
            className: "inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200",
            children: "Processing"
          }),
          e.jsx("span", {
            className: "text-xs text-gray-500 dark:text-slate-400",
            children: "This item is still being generated."
          })
        ]
      });
    if (!t)
      return e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "No content available."
      });
    const a = {
      [o.AUDIO]: e.jsx(f, {
        content: t,
        artifact: s
      }),
      [o.REPORT]: e.jsx(h, {
        content: t
      }),
      [o.VIDEO]: e.jsx(y, {
        content: t
      }),
      [o.QUIZ]: e.jsx(b, {
        content: t,
        artifact: s,
        notebookId: r
      }),
      [o.FLASHCARDS]: e.jsx(j, {
        content: t,
        artifact: s,
        notebookId: r
      }),
      [o.MIND_MAP]: e.jsx(R, {
        content: t,
        artifact: s,
        notebookId: r
      }),
      [o.INFOGRAPHIC]: e.jsx(k, {
        content: t
      }),
      [o.SLIDE_DECK]: e.jsx(v, {
        content: t
      }),
      [o.DATA_TABLE]: e.jsx(E, {
        content: t
      }),
      [o.NOTE]: e.jsx(A, {
        content: t
      })
    };
    return e.jsx(n.Suspense, {
      fallback: e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "Loading content..."
      }),
      children: a[s.type] || e.jsx("p", {
        className: "text-xs text-gray-500 dark:text-slate-400",
        children: "Unsupported content type."
      })
    });
  }
  Z = function({ isOpen: s, onClose: r, artifact: t, notebookId: a }) {
    if (!t)
      return null;
    const d = N(t), c = async () => {
      if (d)
        try {
          await navigator.clipboard.writeText(d), l.success("Copied to clipboard");
        } catch {
          l.error("Failed to copy");
        }
    };
    return e.jsxs(u, {
      open: s,
      onClose: r,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(g, {
            className: "w-full max-w-4xl max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(_, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2 min-w-0",
                    children: [
                      e.jsx(p, {
                        artifactType: t.type
                      }),
                      e.jsx("span", {
                        className: "truncate",
                        children: t.title
                      })
                    ]
                  }),
                  e.jsx("button", {
                    onClick: r,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 flex-shrink-0",
                    children: e.jsx(x, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: e.jsx(T, {
                  artifact: t,
                  notebookId: a
                })
              }),
              e.jsxs("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                children: [
                  d && e.jsxs("button", {
                    onClick: c,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-1",
                    children: [
                      e.jsx(m, {
                        className: "w-3.5 h-3.5"
                      }),
                      "Copy"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: r,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                    children: "Close"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  Z as default
};
