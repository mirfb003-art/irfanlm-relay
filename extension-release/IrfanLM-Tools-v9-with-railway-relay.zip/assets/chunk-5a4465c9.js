import { r as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
let i;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function l({ title: a, titleId: r, ...t }, o) {
    return e.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": r
    }, t), a ? e.createElement("title", {
      id: r
    }, a) : null, e.createElement("path", {
      d: "M2 3a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H2Z"
    }), e.createElement("path", {
      fillRule: "evenodd",
      d: "M2 7.5h16l-.811 7.71a2 2 0 0 1-1.99 1.79H4.802a2 2 0 0 1-1.99-1.79L2 7.5ZM7 11a1 1 0 0 1 1-1h4a1 1 0 1 1 0 2H8a1 1 0 0 1-1-1Z",
      clipRule: "evenodd"
    }));
  }
  let n;
  n = e.forwardRef(l);
  i = n;
});
export {
  i as A,
  __tla
};
