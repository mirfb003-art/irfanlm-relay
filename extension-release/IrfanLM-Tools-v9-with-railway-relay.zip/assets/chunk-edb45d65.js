import { r as t, u as w, j as e, h as u, e as C, J as d, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { u as A, b as R, d as E, C as L, e as K, E as T, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { aD as D, r as I, F as P } from "./chunk-68adfa56.js";
import { f } from "./chunk-10b7446f.js";
import { r as F } from "./chunk-378f9272.js";
import { C as S, __tla as __tla_2 } from "./chunk-bd8bbb31.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let $;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  function B({ title: i, titleId: a, ...s }, r) {
    return t.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": a
    }, s), i ? t.createElement("title", {
      id: a
    }, i) : null, t.createElement("path", {
      fillRule: "evenodd",
      d: "M15.988 3.012A2.25 2.25 0 0 1 18 5.25v6.5A2.25 2.25 0 0 1 15.75 14H13.5v-3.379a3 3 0 0 0-.879-2.121l-3.12-3.121a3 3 0 0 0-1.402-.791 2.252 2.252 0 0 1 1.913-1.576A2.25 2.25 0 0 1 12.25 1h1.5a2.25 2.25 0 0 1 2.238 2.012ZM11.5 3.25a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 .75.75v.25h-3v-.25Z",
      clipRule: "evenodd"
    }), t.createElement("path", {
      d: "M3.5 6A1.5 1.5 0 0 0 2 7.5v9A1.5 1.5 0 0 0 3.5 18h7a1.5 1.5 0 0 0 1.5-1.5v-5.879a1.5 1.5 0 0 0-.44-1.06L8.44 6.439A1.5 1.5 0 0 0 7.378 6H3.5Z"
    }));
  }
  const M = t.forwardRef(B), _ = M;
  $ = function() {
    var _a, _b, _c, _d, _e;
    const [i, a] = w(), { me: s, isDeactivating: r } = i.auth, c = ((_a = s == null ? void 0 : s.licenseKey) == null ? void 0 : _a.customer) || {}, b = (_b = s == null ? void 0 : s.licenseKey) == null ? void 0 : _b.displayKey, x = (_c = s == null ? void 0 : s.licenseKey) == null ? void 0 : _c.expiresAt, m = (_d = s == null ? void 0 : s.licenseKey) == null ? void 0 : _d.lastValidatedAt, v = a.isLicensed() ? "Active" : (_e = s == null ? void 0 : s.licenseKey) == null ? void 0 : _e.status, j = A(), [k, n] = t.useState(false), [h, p] = t.useState(false), o = t.useRef(false), y = async () => {
      if (o.current)
        return;
      o.current = true, p(true), await a.validateCurrentLicense() ? d.success("License verified") : d.error("Failed to verify license"), o.current = false, p(false);
    }, N = async () => {
      const { licenseKey: l } = i.auth;
      if (l)
        try {
          await navigator.clipboard.writeText(l), d.success("License key copied");
        } catch {
          d.error("Failed to copy");
        }
    }, g = async () => {
      try {
        await a.deactivateLicenseKey(), j("/");
      } catch {
        d.error("Failed to deactivate on server. Please try again."), n(false);
      }
    };
    return e.jsxs(R, {
      children: [
        e.jsx(E, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: "Profile"
          })
        }),
        e.jsxs("div", {
          className: "max-w-sm mx-auto px-4 py-6 space-y-4",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                e.jsx(L, {
                  className: "w-5 h-5 text-emerald-600 dark:text-emerald-400"
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("h1", {
                      className: "text-sm font-bold text-slate-900 dark:text-slate-100",
                      children: "Licensed"
                    }),
                    e.jsx("p", {
                      className: "text-xs text-slate-500 dark:text-slate-400",
                      children: "Thank you for supporting NLMTools.com"
                    })
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 space-y-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2.5",
                  children: [
                    e.jsx("div", {
                      className: "w-8 h-8 rounded-full bg-emerald-200 dark:bg-emerald-800 flex items-center justify-center text-xs font-semibold text-emerald-700 dark:text-emerald-300",
                      children: c.email ? c.email[0].toUpperCase() : "?"
                    }),
                    e.jsx("span", {
                      className: "text-xs text-slate-700 dark:text-slate-300 truncate",
                      children: c.email || "No email"
                    }),
                    e.jsx("span", {
                      className: "ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400",
                      children: v || "Unknown"
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "space-y-1.5",
                  children: [
                    e.jsx("span", {
                      className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
                      children: "What you've unlocked"
                    }),
                    e.jsx("ul", {
                      className: "space-y-1",
                      children: D.map((l) => e.jsxs("li", {
                        className: "flex items-center gap-1.5",
                        children: [
                          e.jsx(K, {
                            className: "w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0"
                          }),
                          e.jsx("span", {
                            className: "text-xs text-slate-700 dark:text-slate-300",
                            children: l
                          })
                        ]
                      }, l))
                    })
                  ]
                }),
                e.jsxs("dl", {
                  className: "space-y-1.5 text-xs",
                  children: [
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("dt", {
                          className: "text-slate-500 dark:text-slate-400",
                          children: "Key"
                        }),
                        e.jsx("dd", {
                          children: e.jsxs("button", {
                            onClick: N,
                            "aria-label": "Copy license key",
                            title: "Copy license key",
                            className: "inline-flex items-center gap-1 font-mono text-slate-700 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-300",
                            children: [
                              b || "****",
                              e.jsx(_, {
                                className: "w-3 h-3 text-emerald-600 dark:text-emerald-400"
                              })
                            ]
                          })
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("dt", {
                          className: "text-slate-500 dark:text-slate-400",
                          children: "Expires"
                        }),
                        e.jsx("dd", {
                          className: "text-slate-700 dark:text-slate-300",
                          children: x ? f(x) : "Never"
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsx("dt", {
                          className: "text-slate-500 dark:text-slate-400",
                          children: "Verified"
                        }),
                        e.jsxs("dd", {
                          className: "flex items-center gap-1.5 text-slate-700 dark:text-slate-300",
                          children: [
                            e.jsx("span", {
                              title: f(m),
                              children: F(m)
                            }),
                            e.jsx("button", {
                              onClick: y,
                              disabled: h,
                              className: "p-0.5 rounded text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 disabled:opacity-50",
                              title: "Refresh license",
                              "aria-label": "Refresh license status",
                              children: e.jsx(u, {
                                className: h ? "w-3 h-3 animate-spin" : "w-3 h-3"
                              })
                            })
                          ]
                        })
                      ]
                    })
                  ]
                }),
                e.jsx("div", {
                  className: "border-t border-emerald-200 dark:border-emerald-800 pt-3",
                  children: k ? e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-start gap-1.5 text-xs text-red-600 dark:text-red-400",
                        children: [
                          e.jsx(T, {
                            className: "w-3.5 h-3.5 shrink-0 mt-0.5"
                          }),
                          e.jsx("span", {
                            children: "Are you sure? This will remove your license from this device."
                          })
                        ]
                      }),
                      e.jsxs("div", {
                        className: "flex gap-2",
                        children: [
                          e.jsxs("button", {
                            onClick: g,
                            disabled: r,
                            className: "flex items-center gap-1 px-3 py-1 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed",
                            children: [
                              r && e.jsx(u, {
                                className: "w-3 h-3 animate-spin"
                              }),
                              r ? "Deactivating..." : "Confirm"
                            ]
                          }),
                          e.jsx("button", {
                            onClick: () => n(false),
                            disabled: r,
                            className: "px-3 py-1 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 disabled:opacity-50",
                            children: "Cancel"
                          })
                        ]
                      })
                    ]
                  }) : e.jsx("button", {
                    onClick: () => n(true),
                    className: "text-xs text-red-400 dark:text-red-500 hover:text-red-600 dark:hover:text-red-300",
                    children: "Deactivate on this device"
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 space-y-3",
              children: [
                e.jsxs("a", {
                  href: I,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "flex items-center gap-2 text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300",
                  children: [
                    e.jsx(C, {
                      className: "w-3.5 h-3.5 shrink-0"
                    }),
                    e.jsx("span", {
                      children: "Customer Portal"
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "-mt-1.5 ml-[22px] text-xs text-slate-500 dark:text-slate-400",
                  children: "Billing, invoices, and license management"
                }),
                e.jsxs("a", {
                  href: P,
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "flex items-center gap-2 text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300",
                  children: [
                    e.jsx(S, {
                      className: "w-3.5 h-3.5 shrink-0"
                    }),
                    e.jsx("span", {
                      children: "Share feedback"
                    })
                  ]
                }),
                e.jsx("p", {
                  className: "-mt-1.5 ml-[22px] text-xs text-slate-500 dark:text-slate-400",
                  children: "Help us improve NLMTools.com"
                })
              ]
            })
          ]
        })
      ]
    });
  };
});
export {
  __tla,
  $ as default
};
