import { r as i, j as e, X as C, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { aG as R } from "./chunk-68adfa56.js";
import { i as T, z as $, Q as A, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let G;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  const E = [
    {
      id: "replace",
      label: "Replace Text"
    },
    {
      id: "add",
      label: "Add Text"
    },
    {
      id: "custom",
      label: "Custom"
    }
  ];
  function F({ item: l, isProcessing: a, onSave: g, onClose: n, maxTitleLength: s }) {
    const [o, r] = i.useState(l.title || ""), x = i.useRef(null);
    i.useEffect(() => {
      x.current && x.current.select();
    }, []);
    const c = s - o.length, m = o.trim() && o.trim() !== l.title, p = (u) => {
      u.preventDefault(), m && g([
        {
          id: l.id,
          newTitle: o.trim()
        }
      ]);
    };
    return e.jsxs("form", {
      onSubmit: p,
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx("input", {
              ref: x,
              autoFocus: true,
              type: "text",
              value: o,
              onChange: (u) => r(u.target.value),
              disabled: a,
              maxLength: s,
              "aria-label": "Title",
              className: "block w-full rounded-md border border-gray-300 dark:border-slate-700 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-xs px-3 py-2 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
            }),
            e.jsxs("p", {
              className: "text-[10px] text-gray-400 dark:text-slate-500 mt-1 text-right",
              children: [
                c,
                "/",
                s
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex justify-end gap-2 pt-2",
          children: [
            e.jsx("button", {
              type: "button",
              onClick: n,
              disabled: a,
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
              children: "Cancel"
            }),
            e.jsx("button", {
              type: "submit",
              disabled: !m || a,
              className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
              children: a ? "Saving..." : "Save"
            })
          ]
        })
      ]
    });
  }
  function M({ items: l, isProcessing: a, onSave: g, onClose: n, maxTitleLength: s, itemLabel: o }) {
    const [r, x] = i.useState("replace"), [c, m] = i.useState(""), [p, u] = i.useState(""), [h, N] = i.useState(""), [y, j] = i.useState("before"), [k, w] = i.useState(() => Object.fromEntries(l.map((t) => [
      t.id,
      t.title || ""
    ]))), v = i.useMemo(() => l.map((t) => {
      const d = t.title || "";
      let b = d;
      return r === "replace" && c ? b = d.replaceAll(c, p) : r === "add" && h ? b = y === "before" ? h + d : d + h : r === "custom" && (b = k[t.id] || ""), b = b.trim().slice(0, s), {
        id: t.id,
        original: d,
        newTitle: b,
        changed: b !== d
      };
    }), [
      l,
      r,
      c,
      p,
      h,
      y,
      k,
      s
    ]), f = v.filter((t) => t.changed && t.newTitle).length, S = () => {
      const t = v.filter((d) => d.changed && d.newTitle).map((d) => ({
        id: d.id,
        newTitle: d.newTitle
      }));
      t.length > 0 && g(t);
    };
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("label", {
              className: "text-xs font-medium text-gray-700 dark:text-slate-300 shrink-0",
              children: "Method:"
            }),
            e.jsx("select", {
              value: r,
              onChange: (t) => x(t.target.value),
              disabled: a,
              "aria-label": "Rename method",
              className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50",
              children: E.map((t) => e.jsx("option", {
                value: t.id,
                children: t.label
              }, t.id))
            })
          ]
        }),
        r === "replace" && e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("label", {
                  className: "text-xs text-gray-600 dark:text-slate-400 w-14 shrink-0",
                  children: "Find:"
                }),
                e.jsx("input", {
                  autoFocus: true,
                  type: "text",
                  value: c,
                  onChange: (t) => m(t.target.value),
                  disabled: a,
                  placeholder: "Text to find...",
                  maxLength: s,
                  "aria-label": "Find text",
                  className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("label", {
                  className: "text-xs text-gray-600 dark:text-slate-400 w-14 shrink-0",
                  children: "Replace:"
                }),
                e.jsx("input", {
                  type: "text",
                  value: p,
                  onChange: (t) => u(t.target.value),
                  disabled: a,
                  placeholder: "Replace with...",
                  maxLength: s,
                  "aria-label": "Replace text",
                  className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
                })
              ]
            })
          ]
        }),
        r === "add" && e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx("div", {
              className: "flex items-center gap-2",
              children: e.jsx("input", {
                autoFocus: true,
                type: "text",
                value: h,
                onChange: (t) => N(t.target.value),
                disabled: a,
                placeholder: "Text to add...",
                maxLength: s,
                "aria-label": "Text to add",
                className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
              })
            }),
            e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                e.jsx("button", {
                  type: "button",
                  onClick: () => j("before"),
                  className: `px-2 py-1 text-xs rounded-md border ${y === "before" ? "bg-blue-50 dark:bg-blue-950 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 font-medium" : "border-gray-300 dark:border-slate-600 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
                  children: "Before name"
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => j("after"),
                  className: `px-2 py-1 text-xs rounded-md border ${y === "after" ? "bg-blue-50 dark:bg-blue-950 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 font-medium" : "border-gray-300 dark:border-slate-600 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
                  children: "After name"
                })
              ]
            })
          ]
        }),
        r === "custom" && e.jsx("div", {
          className: "max-h-48 overflow-y-auto space-y-1.5 border border-gray-200 dark:border-slate-700 rounded-md p-2",
          children: l.map((t) => e.jsx("input", {
            type: "text",
            value: k[t.id] || "",
            onChange: (d) => w((b) => ({
              ...b,
              [t.id]: d.target.value
            })),
            disabled: a,
            maxLength: s,
            "aria-label": `Title for ${t.title}`,
            className: "block w-full rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
          }, t.id))
        }),
        r !== "custom" && e.jsxs("div", {
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between mb-1.5",
              children: [
                e.jsx("span", {
                  className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                  children: "Preview"
                }),
                e.jsxs("span", {
                  className: "text-xs text-gray-500 dark:text-slate-400",
                  children: [
                    f,
                    " changed"
                  ]
                })
              ]
            }),
            e.jsx("div", {
              className: "max-h-48 overflow-y-auto border border-gray-200 dark:border-slate-700 rounded-md divide-y divide-gray-100 dark:divide-slate-700",
              children: v.map((t) => e.jsxs("div", {
                className: `px-2 py-1.5 flex items-center gap-2 text-xs ${t.changed ? "text-gray-900 dark:text-slate-100" : "text-gray-400 dark:text-slate-500"}`,
                children: [
                  e.jsx("span", {
                    className: "truncate flex-1",
                    title: t.original,
                    children: t.original
                  }),
                  e.jsx("span", {
                    className: "text-gray-300 dark:text-slate-600 shrink-0",
                    children: "\u2192"
                  }),
                  e.jsx("span", {
                    className: "truncate flex-1",
                    title: t.newTitle,
                    children: t.newTitle
                  }),
                  t.changed && e.jsx("span", {
                    className: "text-blue-500 dark:text-blue-400 shrink-0",
                    children: "*"
                  })
                ]
              }, t.id))
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex justify-end gap-2 pt-2",
          children: [
            e.jsx("button", {
              type: "button",
              onClick: n,
              disabled: a,
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
              children: "Cancel"
            }),
            e.jsx("button", {
              type: "button",
              onClick: S,
              disabled: f === 0 || a,
              className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
              children: a ? `Renaming ${f} ${o}${f !== 1 ? "s" : ""}...` : "Apply All"
            })
          ]
        })
      ]
    });
  }
  G = function({ isOpen: l, onClose: a, onConfirm: g, items: n, itemLabel: s = "item", maxTitleLength: o = R }) {
    const [r, x] = i.useState(false);
    if (i.useEffect(() => {
      l && x(false);
    }, [
      l
    ]), !n || n.length === 0)
      return null;
    const c = n.length === 1, m = s.charAt(0).toUpperCase() + s.slice(1), p = c ? `Rename ${m}` : `Rename ${n.length} ${m}s`, u = async (h) => {
      x(true);
      try {
        await g(h), a();
      } catch {
        x(false);
      }
    };
    return e.jsxs(T, {
      open: l,
      onClose: r ? () => {
      } : a,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs($, {
            className: `w-full ${c ? "max-w-sm" : "max-w-md"} space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5`,
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between",
                children: [
                  e.jsx(A, {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: p
                  }),
                  e.jsx("button", {
                    onClick: a,
                    disabled: r,
                    "aria-label": "Close",
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: e.jsx(C, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              c ? e.jsx(F, {
                item: n[0],
                isProcessing: r,
                onSave: u,
                onClose: a,
                maxTitleLength: o
              }) : e.jsx(M, {
                items: n,
                isProcessing: r,
                onSave: u,
                onClose: a,
                maxTitleLength: o,
                itemLabel: s
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  G as default
};
