import { r as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
let d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function o({ title: a, titleId: r, ...l }, t) {
    return e.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: t,
      "aria-labelledby": r
    }, l), a ? e.createElement("title", {
      id: r
    }, a) : null, e.createElement("path", {
      fillRule: "evenodd",
      d: "M4.5 2A2.5 2.5 0 0 0 2 4.5v3.879a2.5 2.5 0 0 0 .732 1.767l7.5 7.5a2.5 2.5 0 0 0 3.536 0l3.878-3.878a2.5 2.5 0 0 0 0-3.536l-7.5-7.5A2.5 2.5 0 0 0 8.38 2H4.5ZM5 6a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z",
      clipRule: "evenodd"
    }));
  }
  let n;
  n = e.forwardRef(o);
  d = n;
});
export {
  d as T,
  __tla
};
