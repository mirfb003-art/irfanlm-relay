import { j as e, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { w as o, __tla as __tla_1 } from "./chunk-2a4ab792.js";
let l, i;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  i = ({ actionType: t, totalLinks: r, failedLinks: d }) => {
    const s = (d == null ? void 0 : d.length) || 0, n = r - s, a = t === "new" ? "Notebook created" : "Videos added";
    return e.jsx("div", {
      className: "px-2.5 py-2 bg-green-50 rounded-md border border-green-200 dark:bg-green-950 dark:border-green-800",
      children: e.jsxs("div", {
        className: "flex items-start gap-2",
        children: [
          e.jsx(o, {
            className: "w-4 h-4 text-green-600 flex-shrink-0"
          }),
          e.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              e.jsx("p", {
                className: "text-xs font-medium text-green-900 dark:text-green-300",
                children: a
              }),
              e.jsxs("p", {
                className: "text-xs text-green-700 dark:text-green-400 mt-0.5",
                children: [
                  n,
                  " of ",
                  r,
                  " videos imported",
                  s > 0 && ` \xB7 ${s} failed`
                ]
              })
            ]
          })
        ]
      })
    });
  };
  l = ({ actionType: t, totalLinks: r, failedLinks: d }) => {
    const s = (d == null ? void 0 : d.length) || 0, n = r - s, a = t === "new" ? "Notebook created" : "Articles added";
    return e.jsx("div", {
      className: "px-2.5 py-2 bg-green-50 rounded-md border border-green-200 dark:bg-green-950 dark:border-green-800",
      children: e.jsxs("div", {
        className: "flex items-start gap-2",
        children: [
          e.jsx(o, {
            className: "w-4 h-4 text-green-600 flex-shrink-0"
          }),
          e.jsxs("div", {
            className: "flex-1 min-w-0",
            children: [
              e.jsx("p", {
                className: "text-xs font-medium text-green-900 dark:text-green-300",
                children: a
              }),
              e.jsxs("p", {
                className: "text-xs text-green-700 dark:text-green-400 mt-0.5",
                children: [
                  n,
                  " of ",
                  r,
                  " articles imported",
                  s > 0 && ` \xB7 ${s} failed`
                ]
              })
            ]
          })
        ]
      })
    });
  };
});
export {
  l as F,
  i as P,
  __tla
};
