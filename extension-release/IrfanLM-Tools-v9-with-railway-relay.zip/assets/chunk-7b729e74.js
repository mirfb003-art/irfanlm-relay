import { r as a, u as Q, T as g, j as e, X as G, c as N, h as F, M as O, P as X, U as Z, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { i as _, z as $, Q as D, p as H, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { T as S, __tla as __tla_2 } from "./chunk-95b0b380.js";
import { T as A, __tla as __tla_3 } from "./chunk-b5767d08.js";
import "./chunk-68adfa56.js";
import "./chunk-725317a4.js";
import "./chunk-38df7042.js";
import "./chunk-9bfc7485.js";
let le;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  function U({ title: d, titleId: o, ...n }, b) {
    return a.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: b,
      "aria-labelledby": o
    }, n), d ? a.createElement("title", {
      id: o
    }, d) : null, a.createElement("path", {
      fillRule: "evenodd",
      d: "M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm.75-11.25a.75.75 0 0 0-1.5 0v2.5h-2.5a.75.75 0 0 0 0 1.5h2.5v2.5a.75.75 0 0 0 1.5 0v-2.5h2.5a.75.75 0 0 0 0-1.5h-2.5v-2.5Z",
      clipRule: "evenodd"
    }));
  }
  const V = a.forwardRef(U), W = V;
  le = function({ isOpen: d, onClose: o, selectedNotebookIds: n = [], onSuccess: b }) {
    const [q, i] = Q(), [r, x] = a.useState([]), [m, p] = a.useState("add"), [c, y] = a.useState(false), [l, f] = a.useState(""), [k, C] = a.useState(() => g[0]), [P, j] = a.useState(false), h = i.getAllTags(), u = h.filter((t) => t.name.toLowerCase().includes(l.toLowerCase())), T = l.trim() && !h.some((t) => t.name.toLowerCase() === l.trim().toLowerCase());
    a.useEffect(() => {
      d && (x([]), p("add"), f(""), C(g[0]), y(false), j(false));
    }, [
      d
    ]);
    const L = (t) => {
      x((s) => s.includes(t) ? s.filter((B) => B !== t) : [
        ...s,
        t
      ]);
    }, z = () => {
      x(u.map((t) => t.id));
    }, M = () => {
      x([]);
    }, R = (t) => {
      t.stopPropagation();
      const s = g.indexOf(k);
      C(g[(s + 1) % g.length]);
    }, E = async () => {
      j(true);
      const t = await i.createTag(l.trim(), k);
      t && (x((s) => [
        ...s,
        t.id
      ]), f("")), j(false);
    }, I = async () => {
      if (r.length !== 0) {
        y(true);
        try {
          m === "add" ? await i.bulkAddTagsToNotebooks(n, r) : await i.bulkSetTagsForNotebooks(n, r), b == null ? void 0 : b(n.length, r.length, m), Z(() => i.isLicensed()), o();
        } finally {
          y(false);
        }
      }
    }, w = () => {
      c || o();
    }, v = n.length;
    return e.jsxs(_, {
      open: d,
      onClose: w,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs($, {
            className: "w-full max-w-md bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                  e.jsxs(D, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(A, {
                        className: "w-4 h-4 text-gray-500 dark:text-slate-400"
                      }),
                      "Assign Tags to ",
                      v,
                      " notebook",
                      v !== 1 ? "s" : ""
                    ]
                  }),
                  e.jsx("button", {
                    onClick: w,
                    disabled: c,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: e.jsx(G, {
                      className: "h-5 w-5"
                    })
                  })
                ]
              }),
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsxs("div", {
                    className: "flex rounded-md border border-gray-200 dark:border-slate-700 p-0.5 bg-gray-50 dark:bg-slate-900",
                    children: [
                      e.jsxs("button", {
                        onClick: () => p("add"),
                        className: N("flex-1 px-3 py-1.5 text-xs font-medium rounded flex items-center justify-center gap-1.5", m === "add" ? "bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"),
                        children: [
                          e.jsx(W, {
                            className: "w-3.5 h-3.5"
                          }),
                          "Add to existing"
                        ]
                      }),
                      e.jsxs("button", {
                        onClick: () => p("replace"),
                        className: N("flex-1 px-3 py-1.5 text-xs font-medium rounded flex items-center justify-center gap-1.5", m === "replace" ? "bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30" : "text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300"),
                        children: [
                          e.jsx(F, {
                            className: "w-3.5 h-3.5"
                          }),
                          "Replace all"
                        ]
                      })
                    ]
                  }),
                  e.jsxs("div", {
                    className: "relative",
                    children: [
                      e.jsx(O, {
                        className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                      }),
                      e.jsx("input", {
                        type: "text",
                        value: l,
                        onChange: (t) => f(t.target.value),
                        placeholder: "Search or create tags...",
                        className: "w-full pl-8 pr-3 py-1.5 text-xs border border-gray-200 dark:border-slate-700 dark:bg-slate-700 dark:text-slate-100 rounded-md focus:ring-1 focus:ring-neutral-900 focus:border-neutral-900"
                      })
                    ]
                  }),
                  h.length > 0 && e.jsxs("div", {
                    className: "flex items-center justify-between",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx("button", {
                            onClick: z,
                            className: "text-xs text-blue-600 hover:text-blue-700",
                            children: "Select all"
                          }),
                          e.jsx("span", {
                            className: "text-gray-300 dark:text-slate-600",
                            children: "|"
                          }),
                          e.jsx("button", {
                            onClick: M,
                            className: "text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300",
                            children: "Clear"
                          })
                        ]
                      }),
                      e.jsxs("span", {
                        className: "text-xs text-gray-500 dark:text-slate-400",
                        children: [
                          r.length,
                          " selected"
                        ]
                      })
                    ]
                  }),
                  h.length === 0 ? e.jsxs("div", {
                    className: "border border-dashed border-gray-200 dark:border-slate-700 rounded-md p-6 text-center",
                    children: [
                      e.jsx(A, {
                        className: "w-8 h-8 text-gray-300 dark:text-slate-600 mx-auto mb-2"
                      }),
                      e.jsx("p", {
                        className: "text-xs text-gray-500 dark:text-slate-400 mb-2",
                        children: "No tags created yet"
                      }),
                      e.jsx(H, {
                        to: "/tags",
                        onClick: o,
                        className: "text-xs text-blue-600 hover:text-blue-700",
                        children: "Manage Tags \u2192"
                      })
                    ]
                  }) : u.length === 0 && !T ? e.jsx("div", {
                    className: "border border-gray-200 dark:border-slate-700 rounded-md p-4 text-center",
                    children: e.jsxs("p", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: [
                        'No tags match "',
                        l,
                        '"'
                      ]
                    })
                  }) : e.jsxs("div", {
                    className: "border border-gray-200 dark:border-slate-700 rounded-md",
                    children: [
                      u.length > 0 && e.jsx("div", {
                        className: "max-h-40 overflow-y-auto",
                        children: e.jsx("div", {
                          className: "grid grid-cols-2 gap-1 p-2",
                          children: u.map((t) => {
                            const s = r.includes(t.id);
                            return e.jsxs("label", {
                              className: N("flex items-center gap-2 cursor-pointer rounded-md p-1.5", s ? "bg-blue-50 dark:bg-blue-950" : "hover:bg-gray-50 dark:hover:bg-slate-700"),
                              children: [
                                e.jsx("input", {
                                  type: "checkbox",
                                  checked: s,
                                  onChange: () => L(t.id),
                                  className: "w-3.5 h-3.5 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500"
                                }),
                                e.jsx(S, {
                                  tag: t,
                                  size: "xs"
                                })
                              ]
                            }, t.id);
                          })
                        })
                      }),
                      T && e.jsxs("button", {
                        onClick: E,
                        disabled: P,
                        className: "w-full px-3 py-2 text-left flex items-center gap-2 text-xs border-t border-gray-100 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
                        children: [
                          e.jsx(X, {
                            className: "w-3.5 h-3.5 text-gray-400 dark:text-slate-500"
                          }),
                          e.jsx("span", {
                            className: "text-gray-600 dark:text-slate-400",
                            children: "Create"
                          }),
                          e.jsx("span", {
                            onClick: R,
                            className: "cursor-pointer",
                            children: e.jsx(S, {
                              tag: {
                                name: l.trim(),
                                color: k
                              },
                              size: "xs"
                            })
                          }),
                          e.jsx("span", {
                            className: "text-[10px] text-gray-400 dark:text-slate-500 ml-auto",
                            children: "click tag to change color"
                          })
                        ]
                      })
                    ]
                  })
                ]
              }),
              e.jsxs("div", {
                className: "flex justify-end gap-2 mt-5",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: w,
                    disabled: c,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  e.jsxs("button", {
                    type: "button",
                    onClick: I,
                    disabled: c || r.length === 0,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-neutral-800 dark:hover:bg-gray-200 disabled:opacity-50 flex items-center gap-1.5",
                    children: [
                      c && e.jsxs("svg", {
                        className: "w-3 h-3 animate-spin",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        children: [
                          e.jsx("circle", {
                            className: "opacity-25",
                            cx: "12",
                            cy: "12",
                            r: "10",
                            stroke: "currentColor",
                            strokeWidth: "4"
                          }),
                          e.jsx("path", {
                            className: "opacity-75",
                            fill: "currentColor",
                            d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          })
                        ]
                      }),
                      e.jsx("span", {
                        children: c ? "Applying..." : `Apply to ${v}`
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  };
});
export {
  __tla,
  le as default
};
