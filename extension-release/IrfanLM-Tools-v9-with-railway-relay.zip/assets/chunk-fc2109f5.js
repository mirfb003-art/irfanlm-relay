import { r as s, j as e, s as et, f as Na, i as Ca, J as k, e as Zt, a8 as he, ab as Ne, h as oe, X as ge, P as De, d as Se, M as Ue, a0 as ke, m as pe, u as Fe, a9 as qt, af as Sa, U as te, T as Et, c as Re, C as Fa, b as at, ae as Ra, L as bt, A as ft, k as La, q as Da, ad as Qt, __tla as __tla_0 } from "./chunk-b41980cc.js";
import { m as pt, h as Ee, i as Ve, z as Ge, Q as He, v as Me, D as Te, L as $e, n as Ea, f as Xe, e as Yt, o as xt, I as Ma, p as Ta, g as $a, q as Aa, r as _a, b as Oa, d as Pa, k as Ba, __tla as __tla_1 } from "./chunk-2a4ab792.js";
import { D as Kt, S as yt, F as Jt, d as Ia, f as za, e as Ua, g as Wt, u as Xt, T as Va, __tla as __tla_2 } from "./chunk-4c77bdf2.js";
import { L as Le, R as Ga, __tla as __tla_3 } from "./chunk-cbc671dd.js";
import { R as ea, aw as dt, aG as ze, av as Ha, aH as Ce, l as Mt, aI as Tt, x as st, ac as z, aJ as it, aE as Za, N as $t } from "./chunk-68adfa56.js";
import { g as qa, t as rt, r as Qa } from "./chunk-378f9272.js";
import { P as Ze, __tla as __tla_4 } from "./chunk-3daa5dc5.js";
import { T as Ya, __tla as __tla_5 } from "./chunk-b5767d08.js";
import { D as Ka, __tla as __tla_6 } from "./chunk-bd7b16ee.js";
import { A as mt, __tla as __tla_7 } from "./chunk-57988b21.js";
import { L as Ja, __tla as __tla_8 } from "./chunk-de7ca15a.js";
import { t as Wa, a as At, __tla as __tla_9 } from "./chunk-95b0b380.js";
import { s as Xa, __tla as __tla_10 } from "./chunk-b81ff817.js";
import { C as es, __tla as __tla_11 } from "./chunk-1302cd21.js";
import { i as ts } from "./chunk-e153acea.js";
let gr, Qr;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_10;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_11;
    } catch {
    }
  })()
]).then(async () => {
  function as({ title: t, titleId: a, ...n }, r) {
    return s.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": a
    }, n), t ? s.createElement("title", {
      id: a
    }, t) : null, s.createElement("path", {
      fillRule: "evenodd",
      d: "M2.24 6.8a.75.75 0 0 0 1.06-.04l1.95-2.1v8.59a.75.75 0 0 0 1.5 0V4.66l1.95 2.1a.75.75 0 1 0 1.1-1.02l-3.25-3.5a.75.75 0 0 0-1.1 0L2.2 5.74a.75.75 0 0 0 .04 1.06Zm8 6.4a.75.75 0 0 0-.04 1.06l3.25 3.5a.75.75 0 0 0 1.1 0l3.25-3.5a.75.75 0 1 0-1.1-1.02l-1.95 2.1V6.75a.75.75 0 0 0-1.5 0v8.59l-1.95-2.1a.75.75 0 0 0-1.06-.04Z",
      clipRule: "evenodd"
    }));
  }
  const ss = s.forwardRef(as), rs = ss;
  function ls({ title: t, titleId: a, ...n }, r) {
    return s.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": a
    }, n), t ? s.createElement("title", {
      id: a
    }, t) : null, s.createElement("path", {
      fillRule: "evenodd",
      d: "M15.988 3.012A2.25 2.25 0 0 1 18 5.25v6.5A2.25 2.25 0 0 1 15.75 14H13.5V7A2.5 2.5 0 0 0 11 4.5H8.128a2.252 2.252 0 0 1 1.884-1.488A2.25 2.25 0 0 1 12.25 1h1.5a2.25 2.25 0 0 1 2.238 2.012ZM11.5 3.25a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 .75.75v.25h-3v-.25Z",
      clipRule: "evenodd"
    }), s.createElement("path", {
      fillRule: "evenodd",
      d: "M2 7a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V7Zm2 3.25a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm0 3.5a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Z",
      clipRule: "evenodd"
    }));
  }
  const ns = s.forwardRef(ls), ht = ns;
  function os({ title: t, titleId: a, ...n }, r) {
    return s.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": a
    }, n), t ? s.createElement("title", {
      id: a
    }, t) : null, s.createElement("path", {
      d: "M1 12.5A4.5 4.5 0 0 0 5.5 17H15a4 4 0 0 0 1.866-7.539 3.504 3.504 0 0 0-4.504-4.272A4.5 4.5 0 0 0 4.06 8.235 4.502 4.502 0 0 0 1 12.5Z"
    }));
  }
  const ds = s.forwardRef(os), je = ds;
  function is({ title: t, titleId: a, ...n }, r) {
    return s.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": a
    }, n), t ? s.createElement("title", {
      id: a
    }, t) : null, s.createElement("path", {
      d: "M3 10a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0ZM8.5 10a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0ZM15.5 8.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"
    }));
  }
  const cs = s.forwardRef(is), us = cs;
  function xs({ title: t, titleId: a, ...n }, r) {
    return s.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: r,
      "aria-labelledby": a
    }, n), t ? s.createElement("title", {
      id: a
    }, t) : null, s.createElement("path", {
      fillRule: "evenodd",
      d: "M3.75 3A1.75 1.75 0 0 0 2 4.75v10.5c0 .966.784 1.75 1.75 1.75h12.5A1.75 1.75 0 0 0 18 15.25v-8.5A1.75 1.75 0 0 0 16.25 5h-4.836a.25.25 0 0 1-.177-.073L9.823 3.513A1.75 1.75 0 0 0 8.586 3H3.75ZM10 8a.75.75 0 0 1 .75.75v1.5h1.5a.75.75 0 0 1 0 1.5h-1.5v1.5a.75.75 0 0 1-1.5 0v-1.5h-1.5a.75.75 0 0 1 0-1.5h1.5v-1.5A.75.75 0 0 1 10 8Z",
      clipRule: "evenodd"
    }));
  }
  const ms = s.forwardRef(xs), hs = ms;
  function ta({ data: t, columns: a, enableRowSelection: n = false, onRowSelectionChange: r, rowSelection: l = {}, enableGrouping: i = false, expanded: d, onExpandedChange: o, onEditFolder: c, onDeleteFolder: u, onDragEnd: h }) {
    return e.jsx(Kt, {
      data: t,
      columns: a,
      enableRowSelection: n,
      onRowSelectionChange: r,
      rowSelection: l,
      initialSorting: [
        {
          id: "createdAt",
          desc: true
        }
      ],
      enableGrouping: i,
      expanded: d,
      onExpandedChange: o,
      getSubRows: (x) => x.subRows,
      onDragEnd: h,
      onEditFolder: c,
      onDeleteFolder: u
    });
  }
  function gs({ sources: t, folders: a, notebookSourceMap: n }) {
    return s.useMemo(() => {
      if (!(t == null ? void 0 : t.length))
        return [];
      const r = {}, l = [];
      for (const o of t) {
        const c = n[o.id];
        c && a[c] ? (r[c] || (r[c] = []), r[c].push(o)) : l.push(o);
      }
      const i = Object.keys(a).sort((o, c) => {
        var _a2, _b;
        return (((_a2 = a[o]) == null ? void 0 : _a2.name) || "").localeCompare(((_b = a[c]) == null ? void 0 : _b.name) || "");
      }), d = [];
      for (const o of i)
        d.push({
          id: `folder_group_${o}`,
          _isGroupRow: true,
          _folder: a[o],
          _sourceCount: (r[o] || []).length,
          subRows: r[o] || []
        });
      return l.length > 0 && d.push({
        id: "folder_group_ungrouped",
        _isGroupRow: true,
        _folder: null,
        _sourceCount: l.length,
        subRows: l
      }), d;
    }, [
      t,
      a,
      n
    ]);
  }
  function aa({ notebook: t, sources: a, globalActions: n }) {
    const [r, l] = s.useState({}), [i, d] = s.useState(false), [o, c] = s.useState(false), [u, h] = s.useState(false), [x, m] = s.useState(null), y = s.useRef(false), b = s.useRef(t == null ? void 0 : t.id), p = s.useRef(false), w = s.useRef(false), C = s.useMemo(() => a.filter((j) => ea.includes(j.sourceType)), [
      a
    ]), S = s.useMemo(() => Object.values(r).filter((j) => j === "stale").length, [
      r
    ]);
    s.useEffect(() => (y.current = false, b.current = t == null ? void 0 : t.id, l({}), d(false), c(false), h(false), m(null), () => {
      y.current = true;
    }), [
      t == null ? void 0 : t.id
    ]);
    const g = s.useCallback(async () => {
      if (C.length === 0 || !(t == null ? void 0 : t.id) || p.current)
        return;
      p.current = true;
      const j = t.id;
      d(true), h(false);
      const N = {}, E = 5;
      try {
        for (let T = 0; T < C.length; T += E) {
          if (y.current || b.current !== j)
            return;
          const M = C.slice(T, T + E);
          if (await Promise.all(M.map(async (F) => {
            var _a2, _b;
            try {
              const $ = ((_b = (_a2 = await n.checkSourceFreshnessNotebookLM(F.id, j)) == null ? void 0 : _a2[0]) == null ? void 0 : _b[1]) === false;
              N[F.id] = $ ? "stale" : "fresh";
            } catch (H) {
              console.warn("Failed to check freshness for source:", F.id, H), N[F.id] = null;
            }
          })), y.current || b.current !== j)
            return;
          l((F) => ({
            ...F,
            ...N
          }));
        }
        if (y.current || b.current !== j)
          return;
        await et(j, N), m((/* @__PURE__ */ new Date()).toISOString());
      } finally {
        p.current = false, !y.current && b.current === j && d(false);
      }
    }, [
      C,
      t == null ? void 0 : t.id,
      n
    ]), f = s.useCallback(async () => {
      if (!(t == null ? void 0 : t.id))
        return;
      const j = t.id, N = await Na(j);
      y.current || b.current !== j || (N && !Ca(N) ? (l(N.results), h(true), m(N.lastCheckTime)) : await g());
    }, [
      t == null ? void 0 : t.id,
      g
    ]);
    s.useEffect(() => {
      (t == null ? void 0 : t.id) && C.length > 0 && !i && Object.keys(r).length === 0 && f();
    }, [
      t == null ? void 0 : t.id,
      C.length,
      f
    ]);
    const v = async (j) => {
      var _a2, _b;
      if (w.current)
        return;
      const N = k.loading(`Checking "${j.title}" for updates...`);
      l((E) => ({
        ...E,
        [j.id]: "checking"
      }));
      try {
        if (!(((_b = (_a2 = await n.checkSourceFreshnessNotebookLM(j.id, t.id)) == null ? void 0 : _a2[0]) == null ? void 0 : _b[1]) === false)) {
          l((M) => {
            const F = {
              ...M,
              [j.id]: "fresh"
            };
            return (t == null ? void 0 : t.id) && et(t.id, F), F;
          }), k.success(`"${j.title}" is already up to date`, {
            id: N
          });
          return;
        }
        k.loading(`Refreshing "${j.title}"...`, {
          id: N
        }), await n.refreshSourceNotebookLM(j.id, t.id), l((M) => {
          const F = {
            ...M,
            [j.id]: "fresh"
          };
          return (t == null ? void 0 : t.id) && et(t.id, F), F;
        }), k.success(`"${j.title}" refreshed`, {
          id: N
        });
      } catch (E) {
        l((T) => ({
          ...T,
          [j.id]: null
        })), console.error("Failed to refresh source:", E), k.error(`Failed: ${E.message}`, {
          id: N
        });
      }
    }, D = async () => {
      const j = C.filter((M) => r[M.id] === "stale");
      if (j.length === 0 || w.current)
        return;
      w.current = true, c(true);
      const N = k.loading(`Refreshing ${j.length} sources...`);
      let E = 0, T = {
        ...r
      };
      try {
        for (const M of j)
          try {
            await n.refreshSourceNotebookLM(M.id, t.id), T[M.id] = "fresh", l((F) => ({
              ...F,
              [M.id]: "fresh"
            })), E++;
          } catch (F) {
            console.error(`Failed to refresh ${M.title}:`, F);
          }
        k.success(`${E} source${E > 1 ? "s" : ""} refreshed`, {
          id: N
        }), (t == null ? void 0 : t.id) && await et(t.id, T);
      } catch {
        k.error("Failed to refresh sources", {
          id: N
        });
      } finally {
        w.current = false, c(false);
      }
    }, O = s.useCallback(() => {
      l({}), h(false), m(null), p.current = false, g();
    }, [
      g
    ]);
    return {
      sourceFreshness: r,
      isCheckingFreshness: i,
      isRefreshingAll: o,
      staleCount: S,
      isCachedResult: u,
      lastCheckTime: x,
      handleRefreshSource: v,
      handleRefreshAllStale: D,
      forceCheck: O
    };
  }
  function sa({ sourceFreshness: t, handleRefreshSource: a, handleViewContent: n, handleRename: r, handleDelete: l, readOnly: i = false, renderSourceLabels: d }) {
    return [
      {
        id: "select",
        header: ({ table: o }) => e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-gray-900 focus:ring-1 cursor-pointer",
          checked: o.getIsAllPageRowsSelected(),
          onChange: o.getToggleAllPageRowsSelectedHandler(),
          "aria-label": "Select all rows"
        }),
        cell: ({ row: o }) => e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-gray-900 focus:ring-1 cursor-pointer",
          checked: o.getIsSelected(),
          disabled: !o.getCanSelect(),
          onChange: o.getToggleSelectedHandler(),
          "aria-label": `Select ${o.original.title || "source"}`
        }),
        enableSorting: false,
        enableColumnFilter: false
      },
      {
        id: "source",
        accessorKey: "title",
        filterFn: (o, c, u) => {
          var _a2;
          if (!u || ((_a2 = o.original) == null ? void 0 : _a2._isGroupRow))
            return true;
          const h = o.getValue(c);
          return h != null && String(h).toLowerCase().includes(String(u).toLowerCase());
        },
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-gray-700 dark:text-slate-300",
          children: "Source"
        }),
        cell: (o) => {
          const c = o.row.original.sourceType, u = o.row.original.url, h = qa(u);
          return e.jsx("div", {
            className: "flex items-start gap-2 group/row",
            children: e.jsxs("div", {
              className: "flex-1 min-w-0",
              children: [
                e.jsxs("div", {
                  className: "flex items-center gap-2 mb-1",
                  children: [
                    u ? e.jsxs("a", {
                      href: u,
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className: "group/link inline-flex items-start gap-1.5 text-xs font-medium text-gray-900 dark:text-slate-100 hover:text-gray-700 dark:hover:text-slate-300 leading-tight",
                      onClick: (x) => x.stopPropagation(),
                      children: [
                        e.jsx("span", {
                          className: "line-clamp-2",
                          title: o.getValue(),
                          children: o.getValue()
                        }),
                        e.jsx(Zt, {
                          className: "w-3 h-3 text-gray-400 dark:text-slate-500 opacity-0 group-hover/link:opacity-100 flex-shrink-0 mt-0.5"
                        })
                      ]
                    }) : e.jsx("p", {
                      className: "text-xs font-medium text-gray-900 dark:text-slate-100 line-clamp-2 leading-tight",
                      title: o.getValue(),
                      children: o.getValue()
                    }),
                    e.jsx("span", {
                      className: "inline-flex items-center opacity-0 group-hover/row:opacity-100",
                      children: e.jsx("button", {
                        onClick: async (x) => {
                          x.stopPropagation(), navigator.clipboard.writeText(o.getValue());
                          const { default: m } = await he(() => import("./chunk-20599fbc.js"), []);
                          m({
                            particleCount: 30,
                            spread: 45,
                            origin: {
                              y: 0.6
                            }
                          }), k.success("Title copied");
                        },
                        className: "p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300",
                        title: "Copy title",
                        "aria-label": "Copy title",
                        children: e.jsx("svg", {
                          className: "w-3.5 h-3.5",
                          fill: "none",
                          stroke: "currentColor",
                          viewBox: "0 0 24 24",
                          children: e.jsx("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: "2",
                            d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                          })
                        })
                      })
                    })
                  ]
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2 flex-wrap",
                  children: [
                    e.jsx(yt, {
                      sourceType: c
                    }),
                    t[o.row.original.id] === "stale" && e.jsx("span", {
                      className: "inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200",
                      children: "Updates available"
                    }),
                    u && e.jsx("span", {
                      className: "text-xs text-gray-500 dark:text-slate-400 truncate",
                      children: h
                    })
                  ]
                }),
                d == null ? void 0 : d(o.row.original.id)
              ]
            })
          });
        },
        footer: (o) => o.column.id
      },
      {
        id: "createdAt",
        accessorFn: (o) => o == null ? void 0 : o.createdAt,
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-gray-700 dark:text-slate-300",
          children: "Created At"
        }),
        cell: (o) => e.jsx("span", {
          className: "text-xs text-gray-500 dark:text-slate-400 whitespace-nowrap",
          children: new Date(o.getValue()).toLocaleString(void 0, {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          })
        }),
        footer: (o) => o.column.id,
        enableColumnFilter: false,
        size: 120
      },
      {
        id: "actions",
        header: () => null,
        cell: (o) => {
          const c = o.row.original, u = ea.includes(c.sourceType);
          return e.jsxs("div", {
            className: "flex items-center justify-end gap-1",
            children: [
              u && e.jsx("button", {
                disabled: i,
                className: `p-1.5 rounded-md disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent ${t[c.id] === "stale" ? "text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950 hover:text-amber-700 dark:hover:text-amber-300" : "text-gray-400 dark:text-slate-500 hover:bg-green-50 dark:hover:bg-green-950 hover:text-green-600 dark:hover:text-green-400"}`,
                onClick: (h) => {
                  h.stopPropagation(), a(c);
                },
                title: i ? Ne : t[c.id] === "stale" ? "Refresh source (updates available)" : "Refresh source",
                "aria-label": t[c.id] === "stale" ? "Refresh source (updates available)" : "Refresh source",
                children: e.jsx(oe, {
                  className: "h-3.5 w-3.5",
                  "aria-hidden": "true"
                })
              }),
              e.jsx("button", {
                disabled: i,
                className: "p-1.5 rounded-md hover:bg-blue-50 dark:hover:bg-blue-950 text-gray-400 dark:text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-gray-400",
                onClick: (h) => {
                  h.stopPropagation(), r(o.row.original);
                },
                title: i ? Ne : "Rename source",
                "aria-label": "Rename source",
                children: e.jsx(Ze, {
                  className: "h-3.5 w-3.5",
                  "aria-hidden": "true"
                })
              }),
              e.jsx("button", {
                className: "p-1.5 rounded-md hover:bg-blue-50 dark:hover:bg-blue-950 text-gray-400 dark:text-slate-500 hover:text-blue-600 dark:hover:text-blue-400",
                onClick: (h) => {
                  h.stopPropagation(), n(o.row.original);
                },
                title: "View source content",
                "aria-label": "View source content",
                children: e.jsx(pt, {
                  className: "h-3.5 w-3.5",
                  "aria-hidden": "true"
                })
              }),
              e.jsx("button", {
                disabled: i,
                className: "p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-950 text-gray-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-gray-400",
                onClick: (h) => {
                  h.stopPropagation(), l(o.row.original);
                },
                title: i ? Ne : "Remove source",
                "aria-label": "Remove source",
                children: e.jsx(Ee, {
                  className: "h-3.5 w-3.5",
                  "aria-hidden": "true"
                })
              })
            ]
          });
        },
        footer: (o) => o.column.id,
        enableColumnFilter: false,
        enableSorting: false,
        size: 80
      }
    ];
  }
  function ra({ isOpen: t, onClose: a, onSubmit: n, editingFolder: r = null, noun: l = "Folder", showLocalNotice: i = true }) {
    const [d, o] = s.useState(""), [c, u] = s.useState(false), h = !!r;
    s.useEffect(() => {
      t && (u(false), o(r ? r.name : ""));
    }, [
      t,
      r
    ]);
    const x = () => {
      o(""), a();
    }, m = async (b) => {
      if (b.preventDefault(), !d.trim()) {
        k.error(`${l} name is required`);
        return;
      }
      u(true);
      try {
        if (await n({
          name: d.trim()
        }, r == null ? void 0 : r.id) === false)
          return;
        x();
      } catch (p) {
        console.error("Failed to save folder:", p), k.error("Failed to save folder");
      } finally {
        u(false);
      }
    }, y = (b) => {
      b.key === "Escape" && x();
    };
    return e.jsxs(Ve, {
      open: t,
      onClose: x,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Ge, {
            className: "w-full max-w-sm space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between",
                children: [
                  e.jsx(He, {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: h ? `Edit ${l}` : `Create ${l}`
                  }),
                  e.jsx("button", {
                    onClick: x,
                    "aria-label": "Close",
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
                    children: e.jsx(ge, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsxs("form", {
                onSubmit: m,
                className: "space-y-4",
                onKeyDown: y,
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "folderName",
                        className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1",
                        children: "Name"
                      }),
                      e.jsx("input", {
                        autoFocus: true,
                        type: "text",
                        id: "folderName",
                        value: d,
                        onChange: (b) => o(b.target.value),
                        maxLength: dt,
                        placeholder: `Enter ${l.toLowerCase()} name...`,
                        className: "block w-full rounded-md border border-gray-300 dark:border-slate-700 shadow-sm dark:shadow-slate-900/30 focus:border-blue-500 focus:ring-blue-500 text-xs px-3 py-2 dark:bg-slate-900 dark:text-slate-100"
                      }),
                      e.jsxs("span", {
                        "aria-live": "polite",
                        "aria-atomic": "true",
                        className: `block text-right mt-1 text-xs ${d.length >= dt ? "text-red-500 dark:text-red-400" : "text-gray-400 dark:text-slate-500"}`,
                        children: [
                          d.length,
                          "/",
                          dt
                        ]
                      })
                    ]
                  }),
                  !h && i && e.jsx(Ja, {
                    compact: true
                  }),
                  e.jsxs("div", {
                    className: "flex justify-end gap-2 pt-2",
                    children: [
                      e.jsx("button", {
                        type: "button",
                        onClick: x,
                        disabled: c,
                        className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
                        children: "Cancel"
                      }),
                      e.jsx("button", {
                        type: "submit",
                        disabled: c || !d.trim(),
                        className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
                        children: c ? h ? "Saving..." : "Creating..." : h ? "Save" : "Create"
                      })
                    ]
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  function la({ isOpen: t, onClose: a, onConfirm: n, folder: r, sourceCount: l, noun: i = "folder", removalNote: d = "will become ungrouped" }) {
    const [o, c] = s.useState(false);
    if (s.useEffect(() => {
      t && c(false);
    }, [
      t
    ]), !r)
      return null;
    const u = l > 0 ? `${l} source${l !== 1 ? "s" : ""} ${d}.` : `This ${i} is empty.`, h = async () => {
      c(true);
      try {
        await n(r), a();
      } catch {
        c(false);
      }
    };
    return e.jsxs(Ve, {
      open: t,
      onClose: o ? () => {
      } : a,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Ge, {
            className: "w-full max-w-sm space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsxs(He, {
                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                children: [
                  "Delete ",
                  i,
                  " \u201C",
                  r.name,
                  "\u201D?"
                ]
              }),
              e.jsx("p", {
                className: "text-xs text-gray-500 dark:text-slate-400",
                children: u
              }),
              e.jsxs("div", {
                className: "flex justify-end gap-2 pt-2",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: a,
                    disabled: o,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  e.jsx("button", {
                    type: "button",
                    onClick: h,
                    disabled: o,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50",
                    children: o ? "Deleting..." : "Delete"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  function bs({ folders: t, sourceCounts: a, onMoveToFolder: n, onRemoveFromFolder: r, onCreateNew: l, disabled: i, noun: d = "folder", showRemoveFromFolder: o = true, addMode: c = false }) {
    const u = d.charAt(0).toUpperCase() + d.slice(1), h = c ? Ya : Jt;
    return e.jsxs(Me, {
      className: "relative",
      children: [
        e.jsxs(Te, {
          disabled: i,
          className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
          children: [
            e.jsx(h, {
              className: "w-3.5 h-3.5",
              "aria-hidden": "true"
            }),
            c ? `Add to ${u}` : `Move to ${u}`
          ]
        }),
        e.jsx($e, {
          anchor: "bottom end",
          className: "z-20 w-56 rounded-lg bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 ring-1 ring-black/5 dark:ring-slate-700 focus:outline-none",
          children: ({ close: x }) => e.jsx(fs, {
            folders: t,
            sourceCounts: a,
            close: x,
            onMoveToFolder: n,
            onRemoveFromFolder: r,
            onCreateNew: l,
            noun: d,
            showRemoveFromFolder: o,
            addMode: c
          })
        })
      ]
    });
  }
  function fs({ folders: t, sourceCounts: a, close: n, onMoveToFolder: r, onRemoveFromFolder: l, onCreateNew: i, noun: d = "folder", showRemoveFromFolder: o = true, addMode: c = false }) {
    const [u, h] = s.useState(""), x = t.filter((m) => !u.trim() || m.name.toLowerCase().includes(u.toLowerCase()));
    return e.jsxs("div", {
      className: "p-2",
      children: [
        e.jsx("input", {
          autoFocus: true,
          type: "text",
          value: u,
          onChange: (m) => h(m.target.value),
          placeholder: `Search ${d}s...`,
          "aria-label": `Search ${d}s`,
          className: "w-full rounded-md border border-gray-300 dark:border-slate-700 text-xs px-2.5 py-1.5 mb-1.5 dark:bg-slate-900 dark:text-slate-100 focus:border-blue-500 focus:ring-blue-500"
        }),
        e.jsxs("div", {
          className: "max-h-48 overflow-y-auto",
          children: [
            x.map((m) => e.jsxs("button", {
              onClick: () => {
                n(), r(m.id);
              },
              className: "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
              children: [
                e.jsx("span", {
                  className: "truncate",
                  title: m.name,
                  children: m.name
                }),
                (a == null ? void 0 : a[m.id]) > 0 && e.jsxs("span", {
                  className: "text-gray-400 dark:text-slate-500 flex-shrink-0",
                  children: [
                    "(",
                    a[m.id],
                    ")"
                  ]
                })
              ]
            }, m.id)),
            x.length === 0 && e.jsx("p", {
              className: "text-xs text-gray-500 dark:text-slate-400 px-2 py-1.5",
              children: t.length === 0 ? `No ${d}s yet` : `No matching ${d}s`
            }),
            e.jsxs("div", {
              className: "border-t border-gray-200 dark:border-slate-700 mt-1.5 pt-1.5 space-y-0.5",
              children: [
                e.jsxs("button", {
                  onClick: () => {
                    n(), i();
                  },
                  className: "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs font-medium text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950",
                  children: [
                    e.jsx(De, {
                      className: "w-3.5 h-3.5",
                      "aria-hidden": "true"
                    }),
                    c ? `Create & add to new ${d}` : `Create & move to new ${d}`
                  ]
                }),
                o && e.jsxs("button", {
                  onClick: () => {
                    n(), l();
                  },
                  className: "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-700",
                  children: [
                    e.jsx(ge, {
                      className: "w-3.5 h-3.5",
                      "aria-hidden": "true"
                    }),
                    "Remove from ",
                    d
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  }
  const ps = s.memo(bs);
  function ys({ selectedCount: t, folders: a, sourceCounts: n, isLoading: r, onMoveToFolder: l, onRemoveFromFolder: i, onCreateNewFolder: d, onBulkRename: o, onMerge: c, onDownload: u, isDownloading: h, downloadProgress: x, onCopyToNotebook: m, onGenerate: y, onCancel: b, onBulkDelete: p, readOnly: w = false, moveMenuNoun: C = "folder", showRemoveFromFolder: S = true, moveMenuAddMode: g = false }) {
    const f = w ? Ne : void 0;
    return t === 0 ? null : e.jsxs("div", {
      role: "toolbar",
      "aria-label": "Source actions",
      className: "flex flex-wrap items-center justify-between gap-2 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg p-2 px-3 shadow-sm dark:shadow-slate-900/30",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("div", {
              className: "flex items-center justify-center w-5 h-5 rounded-full bg-gray-200 dark:bg-slate-700",
              "aria-label": `${t} sources selected`,
              children: e.jsx("span", {
                className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                children: t
              })
            }),
            e.jsx("span", {
              className: "text-xs text-gray-600 dark:text-slate-400",
              children: "selected"
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex flex-wrap items-center gap-2",
          children: [
            e.jsx(ps, {
              folders: a,
              sourceCounts: n,
              disabled: r || w,
              onMoveToFolder: l,
              onRemoveFromFolder: i,
              onCreateNew: d,
              noun: C,
              showRemoveFromFolder: S,
              addMode: g
            }),
            e.jsxs("button", {
              onClick: o,
              disabled: r || w,
              "aria-label": `Rename ${t} sources`,
              title: f,
              className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(Ze, {
                  className: "w-3.5 h-3.5",
                  "aria-hidden": "true"
                }),
                "Rename"
              ]
            }),
            t >= 2 && e.jsxs("button", {
              onClick: c,
              disabled: r || w,
              "aria-label": `Merge ${t} sources`,
              title: f,
              className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(Ka, {
                  className: "w-3.5 h-3.5",
                  "aria-hidden": "true"
                }),
                "Merge"
              ]
            }),
            e.jsxs(Me, {
              className: "relative",
              children: [
                e.jsx(Te, {
                  disabled: r,
                  "aria-label": "More actions",
                  className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30 focus:outline-none",
                  children: h ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(oe, {
                        className: "w-3.5 h-3.5 animate-spin",
                        "aria-hidden": "true"
                      }),
                      x ? `${x.current}/${x.total}` : "Downloading"
                    ]
                  }) : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(us, {
                        className: "w-3.5 h-3.5",
                        "aria-hidden": "true"
                      }),
                      "More"
                    ]
                  })
                }),
                e.jsx($e, {
                  anchor: "bottom end",
                  className: "z-20 w-44 rounded-lg bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 ring-1 ring-black/5 dark:ring-slate-700 focus:outline-none py-1",
                  children: ({ close: v }) => e.jsxs(e.Fragment, {
                    children: [
                      e.jsxs("button", {
                        onClick: () => {
                          v(), u();
                        },
                        disabled: r || h,
                        className: "w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                        children: [
                          e.jsx(mt, {
                            className: "w-3.5 h-3.5 shrink-0",
                            "aria-hidden": "true"
                          }),
                          "Download"
                        ]
                      }),
                      e.jsxs("button", {
                        onClick: () => {
                          v(), m();
                        },
                        disabled: r,
                        className: "w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                        children: [
                          e.jsx(ht, {
                            className: "w-3.5 h-3.5 shrink-0",
                            "aria-hidden": "true"
                          }),
                          "Copy to notebook"
                        ]
                      }),
                      y && e.jsxs("button", {
                        onClick: () => {
                          v(), y();
                        },
                        disabled: r || w,
                        title: f,
                        className: "w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                        children: [
                          e.jsx(Se, {
                            className: "w-3.5 h-3.5 shrink-0",
                            "aria-hidden": "true"
                          }),
                          "Generate"
                        ]
                      })
                    ]
                  })
                })
              ]
            }),
            e.jsx("button", {
              onClick: b,
              "aria-label": "Clear selection",
              className: "px-2.5 py-1 text-xs font-medium text-gray-600 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 shadow-sm dark:shadow-slate-900/30",
              children: "Cancel"
            }),
            e.jsxs("button", {
              onClick: p,
              disabled: r || w,
              "aria-label": `Delete ${t} sources`,
              title: f,
              className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(Ee, {
                  className: "w-3.5 h-3.5",
                  "aria-hidden": "true"
                }),
                "Delete"
              ]
            })
          ]
        })
      ]
    });
  }
  const na = s.memo(ys);
  function oa({ uniqueTypes: t, typeCounts: a, typeFilter: n, setTypeFilter: r, searchQuery: l, setSearchQuery: i, hideSearch: d = false }) {
    const o = t.length > 1 ? e.jsxs(e.Fragment, {
      children: [
        e.jsxs("button", {
          onClick: () => r(null),
          className: `px-2 py-1 rounded-full text-xs font-medium ${n === null ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : "bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-300 hover:bg-gray-200 dark:hover:bg-slate-600"}`,
          children: [
            "All (",
            Object.values(a).reduce((c, u) => c + u, 0),
            ")"
          ]
        }),
        t.map((c) => {
          const u = za[c] || "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300", h = n === c, x = Ua[c];
          return e.jsxs("button", {
            onClick: () => r(h ? null : c),
            className: `inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${h ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : u}`,
            children: [
              x && e.jsx(x, {
                className: "w-3 h-3"
              }),
              Ia[c] || "Unknown",
              (a == null ? void 0 : a[c]) != null ? ` (${a[c]})` : ""
            ]
          }, c);
        })
      ]
    }) : null;
    return d ? o ? e.jsx("div", {
      className: "flex items-center gap-1.5 flex-wrap",
      children: o
    }) : null : e.jsxs("div", {
      className: "flex items-center gap-2",
      children: [
        e.jsx("div", {
          className: "flex items-center gap-1.5 flex-wrap flex-1 min-w-0",
          children: o
        }),
        e.jsxs("div", {
          className: "relative flex-shrink-0 w-36",
          children: [
            e.jsx(Ue, {
              className: "absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400 dark:text-slate-500 pointer-events-none"
            }),
            e.jsx("input", {
              type: "text",
              placeholder: "Search...",
              value: l,
              onChange: (c) => i(c.target.value),
              className: "w-full pl-7 pr-2 py-1.5 text-xs border border-gray-300 dark:border-gray-600 rounded-md focus:ring-1 focus:ring-gray-900 dark:focus:ring-gray-100 focus:border-gray-900 dark:focus:border-gray-100 bg-white dark:bg-slate-800 dark:text-slate-100"
            })
          ]
        })
      ]
    });
  }
  function da({ isOpen: t, onClose: a, sourceContent: n, isLoading: r = false }) {
    var _a2;
    return e.jsxs(Ve, {
      open: t,
      onClose: a,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Ge, {
            className: "w-full max-w-4xl max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(He, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(ke, {
                        className: "w-4 h-4 text-gray-500 dark:text-slate-400"
                      }),
                      "Source Content"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: a,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                    children: e.jsx(ge, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: r ? e.jsxs("div", {
                  className: "flex flex-col items-center justify-center h-64 space-y-2",
                  children: [
                    e.jsxs("svg", {
                      className: "w-6 h-6 text-blue-600 animate-spin",
                      xmlns: "http://www.w3.org/2000/svg",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      children: [
                        e.jsx("circle", {
                          className: "opacity-25",
                          cx: "12",
                          cy: "12",
                          r: "10",
                          stroke: "currentColor",
                          strokeWidth: "4"
                        }),
                        e.jsx("path", {
                          className: "opacity-75",
                          fill: "currentColor",
                          d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        })
                      ]
                    }),
                    e.jsx("p", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: "Loading..."
                    })
                  ]
                }) : n ? e.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    e.jsx("h3", {
                      className: "text-sm font-semibold text-gray-900 dark:text-slate-100",
                      children: n.title
                    }),
                    n.content ? e.jsx("div", {
                      className: "bg-gray-50 dark:bg-slate-900 p-3 rounded border border-gray-100 dark:border-slate-700",
                      children: e.jsx("pre", {
                        className: "text-xs text-gray-700 dark:text-slate-300 whitespace-pre-wrap font-mono break-words",
                        children: n.content
                      })
                    }) : ((_a2 = n.images) == null ? void 0 : _a2.length) > 0 ? e.jsx("div", {
                      className: "space-y-4",
                      children: n.images.map((l, i) => e.jsxs("div", {
                        className: "bg-gray-50 dark:bg-slate-900 p-2 rounded border border-gray-100 dark:border-slate-700",
                        children: [
                          e.jsxs("p", {
                            className: "text-xs text-gray-500 dark:text-slate-400 mb-2",
                            children: [
                              "Slide ",
                              i + 1
                            ]
                          }),
                          e.jsx("img", {
                            src: l.url,
                            alt: `Slide ${i + 1}`,
                            className: "w-full rounded"
                          })
                        ]
                      }, l.id || i))
                    }) : e.jsx("p", {
                      className: "text-xs text-gray-500 dark:text-slate-400",
                      children: "No content available"
                    })
                  ]
                }) : e.jsx("div", {
                  className: "flex flex-col items-center justify-center h-64 text-gray-500 dark:text-slate-400 text-xs",
                  children: e.jsx("p", {
                    children: "No content available"
                  })
                })
              }),
              e.jsx("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end",
                children: e.jsx("button", {
                  onClick: a,
                  className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                  children: "Close"
                })
              })
            ]
          })
        })
      ]
    });
  }
  const ks = [
    {
      id: "replace",
      label: "Replace Text"
    },
    {
      id: "add",
      label: "Add Text"
    },
    {
      id: "custom",
      label: "Custom"
    }
  ];
  function js({ source: t, isProcessing: a, onSave: n, onClose: r }) {
    const [l, i] = s.useState(t.title || ""), d = s.useRef(null);
    s.useEffect(() => {
      d.current && d.current.select();
    }, []);
    const o = l.trim() && l.trim() !== t.title, c = (u) => {
      u.preventDefault(), o && n([
        {
          sourceId: t.id,
          newTitle: l.trim()
        }
      ]);
    };
    return e.jsxs("form", {
      onSubmit: c,
      className: "space-y-4",
      children: [
        e.jsx("input", {
          ref: d,
          autoFocus: true,
          type: "text",
          value: l,
          onChange: (u) => i(u.target.value),
          disabled: a,
          maxLength: ze,
          "aria-label": "Source title",
          className: "block w-full rounded-md border border-gray-300 dark:border-slate-700 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-xs px-3 py-2 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
        }),
        e.jsxs("div", {
          className: "flex justify-end gap-2 pt-2",
          children: [
            e.jsx("button", {
              type: "button",
              onClick: r,
              disabled: a,
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
              children: "Cancel"
            }),
            e.jsx("button", {
              type: "submit",
              disabled: !o || a,
              className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
              children: a ? "Saving..." : "Save"
            })
          ]
        })
      ]
    });
  }
  function ws({ sources: t, isProcessing: a, onSave: n, onClose: r }) {
    const [l, i] = s.useState("replace"), [d, o] = s.useState(""), [c, u] = s.useState(""), [h, x] = s.useState(""), [m, y] = s.useState("before"), [b, p] = s.useState(() => Object.fromEntries(t.map((g) => [
      g.id,
      g.title || ""
    ]))), w = s.useMemo(() => t.map((g) => {
      const f = g.title || "";
      let v = f;
      return l === "replace" && d ? v = f.replaceAll(d, c) : l === "add" && h ? v = m === "before" ? h + f : f + h : l === "custom" && (v = b[g.id] || ""), v = v.trim().slice(0, ze), {
        id: g.id,
        original: f,
        newTitle: v,
        changed: v !== f
      };
    }), [
      t,
      l,
      d,
      c,
      h,
      m,
      b
    ]), C = w.filter((g) => g.changed && g.newTitle).length, S = () => {
      const g = w.filter((f) => f.changed && f.newTitle).map((f) => ({
        sourceId: f.id,
        newTitle: f.newTitle
      }));
      g.length > 0 && n(g);
    };
    return e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("label", {
              className: "text-xs font-medium text-gray-700 dark:text-slate-300 shrink-0",
              children: "Method:"
            }),
            e.jsx("select", {
              value: l,
              onChange: (g) => i(g.target.value),
              disabled: a,
              "aria-label": "Rename method",
              className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50",
              children: ks.map((g) => e.jsx("option", {
                value: g.id,
                children: g.label
              }, g.id))
            })
          ]
        }),
        l === "replace" && e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("label", {
                  className: "text-xs text-gray-600 dark:text-slate-400 w-14 shrink-0",
                  children: "Find:"
                }),
                e.jsx("input", {
                  autoFocus: true,
                  type: "text",
                  value: d,
                  onChange: (g) => o(g.target.value),
                  disabled: a,
                  placeholder: "Text to find...",
                  maxLength: ze,
                  "aria-label": "Find text",
                  className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("label", {
                  className: "text-xs text-gray-600 dark:text-slate-400 w-14 shrink-0",
                  children: "Replace:"
                }),
                e.jsx("input", {
                  type: "text",
                  value: c,
                  onChange: (g) => u(g.target.value),
                  disabled: a,
                  placeholder: "Replace with...",
                  maxLength: ze,
                  "aria-label": "Replace text",
                  className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
                })
              ]
            })
          ]
        }),
        l === "add" && e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx("div", {
              className: "flex items-center gap-2",
              children: e.jsx("input", {
                autoFocus: true,
                type: "text",
                value: h,
                onChange: (g) => x(g.target.value),
                disabled: a,
                placeholder: "Text to add...",
                maxLength: ze,
                "aria-label": "Text to add",
                className: "flex-1 rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
              })
            }),
            e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                e.jsx("button", {
                  type: "button",
                  onClick: () => y("before"),
                  className: `px-2 py-1 text-xs rounded-md border ${m === "before" ? "bg-blue-50 dark:bg-blue-950 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 font-medium" : "border-gray-300 dark:border-slate-600 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
                  children: "Before name"
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => y("after"),
                  className: `px-2 py-1 text-xs rounded-md border ${m === "after" ? "bg-blue-50 dark:bg-blue-950 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 font-medium" : "border-gray-300 dark:border-slate-600 text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
                  children: "After name"
                })
              ]
            })
          ]
        }),
        l === "custom" && e.jsx("div", {
          className: "max-h-48 overflow-y-auto space-y-1.5 border border-gray-200 dark:border-slate-700 rounded-md p-2",
          children: t.map((g) => e.jsx("input", {
            type: "text",
            value: b[g.id] || "",
            onChange: (f) => p((v) => ({
              ...v,
              [g.id]: f.target.value
            })),
            disabled: a,
            maxLength: ze,
            "aria-label": `Title for ${g.title}`,
            className: "block w-full rounded-md border border-gray-300 dark:border-slate-700 shadow-sm text-xs px-2 py-1.5 dark:bg-slate-900 dark:text-slate-100 disabled:opacity-50"
          }, g.id))
        }),
        l !== "custom" && e.jsxs("div", {
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between mb-1.5",
              children: [
                e.jsx("span", {
                  className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                  children: "Preview"
                }),
                e.jsxs("span", {
                  className: "text-xs text-gray-500 dark:text-slate-400",
                  children: [
                    C,
                    " changed"
                  ]
                })
              ]
            }),
            e.jsx("div", {
              className: "max-h-48 overflow-y-auto border border-gray-200 dark:border-slate-700 rounded-md divide-y divide-gray-100 dark:divide-slate-700",
              children: w.map((g) => e.jsxs("div", {
                className: `px-2 py-1.5 flex items-center gap-2 text-xs ${g.changed ? "text-gray-900 dark:text-slate-100" : "text-gray-400 dark:text-slate-500"}`,
                children: [
                  e.jsx("span", {
                    className: "truncate flex-1",
                    title: g.original,
                    children: g.original
                  }),
                  e.jsx("span", {
                    className: "text-gray-300 dark:text-slate-600 shrink-0",
                    children: "\u2192"
                  }),
                  e.jsx("span", {
                    className: "truncate flex-1",
                    title: g.newTitle,
                    children: g.newTitle
                  }),
                  g.changed && e.jsx("span", {
                    className: "text-blue-500 dark:text-blue-400 shrink-0",
                    children: "*"
                  })
                ]
              }, g.id))
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex justify-end gap-2 pt-2",
          children: [
            e.jsx("button", {
              type: "button",
              onClick: r,
              disabled: a,
              className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
              children: "Cancel"
            }),
            e.jsx("button", {
              type: "button",
              onClick: S,
              disabled: C === 0 || a,
              className: "px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50",
              children: a ? `Renaming ${C} source${C !== 1 ? "s" : ""}...` : "Apply All"
            })
          ]
        })
      ]
    });
  }
  function ia({ isOpen: t, onClose: a, onConfirm: n, sources: r }) {
    const [l, i] = s.useState(false);
    if (s.useEffect(() => {
      t && i(false);
    }, [
      t
    ]), !r || r.length === 0)
      return null;
    const d = r.length === 1, o = d ? "Rename Source" : `Rename ${r.length} Sources`, c = async (u) => {
      i(true);
      try {
        await n(u), a();
      } catch {
        i(false);
      }
    };
    return e.jsxs(Ve, {
      open: t,
      onClose: l ? () => {
      } : a,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Ge, {
            className: `w-full ${d ? "max-w-sm" : "max-w-md"} space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5`,
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between",
                children: [
                  e.jsx(He, {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                    children: o
                  }),
                  e.jsx("button", {
                    onClick: a,
                    disabled: l,
                    "aria-label": "Close",
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-50",
                    children: e.jsx(ge, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              d ? e.jsx(js, {
                source: r[0],
                isProcessing: l,
                onSave: c,
                onClose: a
              }) : e.jsx(ws, {
                sources: r,
                isProcessing: l,
                onSave: c,
                onClose: a
              })
            ]
          })
        })
      ]
    });
  }
  const vs = pe.lazy(() => he(() => import("./chunk-02fbf508.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-02fbf508.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-bd7b16ee.js"]));
  function Ns({ dialogs: t, notebook: a, sources: n, selectedRows: r, setSelectedRows: l, setIsLoading: i, globalActions: d, notebookId: o, selectedSourceIds: c, handleFolderSubmit: u, confirmDeleteFolder: h, folderSourceCounts: x }) {
    const { viewContentDialogOpen: m, viewingSourceContent: y, isLoadingContent: b, closeViewContentDialog: p, isMergeDialogOpen: w, closeMergeDialog: C, isCreateDialogOpen: S, isCreateFolderFromMenu: g, closeCreateDialog: f, editingFolder: v, pendingDeleteFolder: D, closeDeleteFolderDialog: O, pendingDeleteSources: j, closeDeleteSourceDialog: N, confirmDeleteSources: E, pendingRenameSources: T, closeRenameDialog: M, confirmRenameSources: F } = t, H = s.useCallback(async ({ name: $ }) => {
      const A = await d.createFolder(o, $);
      if (!A || A.error)
        return false;
      if (A.folder)
        try {
          await d.bulkMoveToFolder(o, c, A.folder.id), l({}), k.success(`Created folder and moved ${c.length} source${c.length > 1 ? "s" : ""}`);
        } catch {
          k.warning("Folder created but failed to move sources");
        }
    }, [
      d,
      o,
      c,
      l
    ]);
    return e.jsxs(e.Fragment, {
      children: [
        e.jsx(da, {
          isOpen: m,
          onClose: p,
          sourceContent: y,
          isLoading: b
        }),
        e.jsx(s.Suspense, {
          fallback: null,
          children: w && e.jsx(vs, {
            isOpen: w,
            onClose: C,
            notebook: a,
            selectedSources: Object.keys(r).filter(($) => r[$]).map(($) => n == null ? void 0 : n.find((A) => A.id === $)).filter(Boolean),
            onSuccess: async () => {
              l({}), i(true);
              try {
                await d.fetchNotebookLMProjects(), k.success("Sources refreshed");
              } catch {
                k.error("Failed to refresh");
              } finally {
                i(false);
              }
            }
          })
        }),
        e.jsx(ra, {
          isOpen: S || g,
          onClose: f,
          onSubmit: g ? H : u,
          editingFolder: v
        }),
        e.jsx(la, {
          isOpen: !!D,
          onClose: O,
          onConfirm: h,
          folder: D,
          sourceCount: D && x[D.id] || 0
        }),
        e.jsx(Wt, {
          isOpen: !!j,
          onClose: N,
          onConfirm: E,
          sources: j
        }),
        e.jsx(ia, {
          isOpen: !!T,
          onClose: M,
          onConfirm: F,
          sources: T
        })
      ]
    });
  }
  const Cs = s.memo(Ns), Ss = [
    {
      key: "fullCopy",
      title: "Re-added as original link",
      desc: "These keep their original source type in the target notebook.",
      borderClass: "border-green-200 dark:border-green-800",
      bgClass: "bg-green-50 dark:bg-green-950",
      titleClass: "text-green-800 dark:text-green-300"
    },
    {
      key: "textOnly",
      title: "Copied as text",
      desc: "Content extracted as text. Formatting, Drive links and structure will be lost.",
      borderClass: "border-amber-200 dark:border-amber-800",
      bgClass: "bg-amber-50 dark:bg-amber-950",
      titleClass: "text-amber-800 dark:text-amber-300"
    },
    {
      key: "nonCopyable",
      title: "Cannot be copied",
      desc: "These source types have no extractable content and will be skipped.",
      borderClass: "border-red-200 dark:border-red-800",
      bgClass: "bg-red-50 dark:bg-red-950",
      titleClass: "text-red-800 dark:text-red-300"
    }
  ], Fs = [
    {
      key: "success",
      cls: "text-green-700 dark:text-green-300",
      getLabel: (t) => t ? "moved" : "copied",
      suffix: "successfully"
    },
    {
      key: "failed",
      cls: "text-red-600 dark:text-red-400",
      getLabel: () => "failed",
      suffix: ""
    },
    {
      key: "skipped",
      cls: "text-amber-600 dark:text-amber-400",
      getLabel: () => "skipped",
      suffix: ""
    }
  ], Rs = {
    fullCopy: [],
    textOnly: [],
    nonCopyable: []
  };
  function ca({ isOpen: t, onClose: a, sourceNotebookId: n, selectedSources: r, onSuccess: l }) {
    const [i, d] = Fe(), [o, c] = s.useState(null), [u, h] = s.useState(""), [x, m] = s.useState(false), [y, b] = s.useState({
      current: 0,
      total: 0
    }), [p, w] = s.useState(null), [C, S] = s.useState(false), g = s.useMemo(() => (i.notebooklm.projects || []).filter((N) => N.id !== n && qt(N)), [
      i.notebooklm.projects,
      n
    ]), f = s.useMemo(() => t ? Sa(r || []) : Rs, [
      r,
      t
    ]), v = f.fullCopy.length + f.textOnly.length, D = s.useCallback(async () => {
      if (!(!o || v === 0)) {
        m(true), w(null), b({
          current: 0,
          total: v
        });
        try {
          const N = await d.copySelectedSourcesToNotebook(n, o.id, r, (E) => b(E));
          if (w(N), N.success > 0 && te(() => d.isLicensed()), C && N.success > 0) {
            const E = new Set(N.errors.map((F) => F.id)), T = new Set(f.nonCopyable.map((F) => F.id)), M = r.filter((F) => !E.has(F.id) && !T.has(F.id));
            for (let F = 0; F < M.length; F += 3)
              await Promise.allSettled(M.slice(F, F + 3).map((H) => d.deleteSourceNotebookLM(H.id, n)));
          }
        } catch (N) {
          k.error("Copy failed: " + N.message), w({
            success: 0,
            failed: v,
            skipped: 0,
            errors: []
          });
        } finally {
          m(false);
        }
      }
    }, [
      o,
      v,
      n,
      r,
      C,
      f,
      d
    ]), O = s.useCallback(() => {
      x || (a(), c(null), h(""), S(false), b({
        current: 0,
        total: 0
      }), w(null));
    }, [
      x,
      a
    ]), j = C ? "Move" : "Copy";
    return e.jsxs(Ve, {
      open: t,
      onClose: O,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Ge, {
            className: "w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30",
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between p-3 border-b border-gray-200 dark:border-slate-700",
                children: [
                  e.jsxs(He, {
                    className: "text-sm font-medium text-gray-900 dark:text-slate-100 flex items-center gap-2",
                    children: [
                      e.jsx(ht, {
                        className: "w-4 h-4"
                      }),
                      j,
                      " Sources to Notebook"
                    ]
                  }),
                  e.jsx("button", {
                    onClick: O,
                    disabled: x,
                    className: "rounded-md p-1 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                    children: e.jsx(ge, {
                      className: "h-4 w-4"
                    })
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-4",
                children: e.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx("label", {
                          className: "block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1.5",
                          children: "Target Notebook"
                        }),
                        e.jsx(Ea, {
                          projects: g,
                          selectedProject: o,
                          onSelectProject: c,
                          query: u,
                          onQueryChange: h,
                          onClose: () => h(""),
                          placeholder: "Search notebooks...",
                          disabled: x
                        })
                      ]
                    }),
                    Ss.map(({ key: N, title: E, desc: T, borderClass: M, bgClass: F, titleClass: H }) => {
                      const $ = f[N];
                      return $.length === 0 ? null : e.jsxs("div", {
                        className: `${F} p-2.5 rounded-lg border ${M}`,
                        children: [
                          e.jsxs("p", {
                            className: `text-xs font-medium ${H} mb-0.5`,
                            children: [
                              $.length,
                              " ",
                              E
                            ]
                          }),
                          e.jsx("p", {
                            className: "text-xs text-gray-500 dark:text-slate-400 mb-2",
                            children: T
                          }),
                          e.jsx("div", {
                            className: "flex flex-wrap gap-1",
                            children: $.map((A) => e.jsxs("span", {
                              className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/60 dark:bg-slate-800/60 text-xs text-gray-700 dark:text-slate-300 max-w-[200px]",
                              children: [
                                e.jsx(yt, {
                                  sourceType: A.sourceType
                                }),
                                e.jsx("span", {
                                  className: "truncate",
                                  children: A.title
                                })
                              ]
                            }, A.id))
                          })
                        ]
                      }, N);
                    }),
                    e.jsxs("label", {
                      className: "flex items-center gap-2 cursor-pointer",
                      children: [
                        e.jsx("input", {
                          type: "checkbox",
                          checked: C,
                          onChange: (N) => S(N.target.checked),
                          disabled: x,
                          className: "rounded border-gray-300 dark:border-slate-600 text-blue-600 focus:ring-blue-500 h-3.5 w-3.5"
                        }),
                        e.jsx("span", {
                          className: "text-xs text-gray-700 dark:text-slate-300",
                          children: "Delete originals after copying (move)"
                        })
                      ]
                    }),
                    C && e.jsx("p", {
                      className: "text-xs text-amber-600 dark:text-amber-400 ml-6",
                      children: "Original sources will be permanently deleted after successful copy."
                    }),
                    x && e.jsxs("div", {
                      className: "bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-2 mb-2",
                          children: [
                            e.jsx(Le, {
                              size: "sm"
                            }),
                            e.jsxs("span", {
                              className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                              children: [
                                C ? "Moving" : "Copying",
                                " sources..."
                              ]
                            })
                          ]
                        }),
                        e.jsx("div", {
                          className: "w-full bg-blue-200 rounded-full h-1.5",
                          children: e.jsx("div", {
                            className: "bg-blue-600 h-1.5 rounded-full",
                            style: {
                              width: `${y.total > 0 ? y.current / y.total * 100 : 0}%`
                            }
                          })
                        }),
                        e.jsxs("p", {
                          className: "text-xs text-blue-600 dark:text-blue-400 mt-1",
                          children: [
                            y.current,
                            "/",
                            y.total,
                            " sources"
                          ]
                        })
                      ]
                    }),
                    !x && p && e.jsx("div", {
                      className: "bg-green-50 dark:bg-green-950 p-3 rounded-lg border border-green-200 dark:border-green-800",
                      children: e.jsx("div", {
                        className: "space-y-1 text-xs",
                        children: Fs.map(({ key: N, cls: E, getLabel: T, suffix: M }) => {
                          const F = p[N];
                          return F ? e.jsxs("p", {
                            className: E,
                            children: [
                              e.jsx("span", {
                                className: "font-medium",
                                children: F
                              }),
                              " source",
                              F > 1 ? "s" : "",
                              " ",
                              T(C),
                              " ",
                              M
                            ]
                          }, N) : null;
                        })
                      })
                    })
                  ]
                })
              }),
              e.jsx("div", {
                className: "p-3 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-2",
                children: p ? e.jsx("button", {
                  onClick: () => {
                    l == null ? void 0 : l(), O();
                  },
                  className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500",
                  children: "Done"
                }) : e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("button", {
                      onClick: O,
                      disabled: x,
                      className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50",
                      children: "Cancel"
                    }),
                    e.jsxs("button", {
                      onClick: D,
                      disabled: x || !o || v === 0,
                      className: "px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center gap-1.5",
                      children: [
                        e.jsx(ht, {
                          className: "w-3.5 h-3.5"
                        }),
                        x ? `${C ? "Moving" : "Copying"}...` : `${j} ${v} Source${v > 1 ? "s" : ""}`
                      ]
                    })
                  ]
                })
              })
            ]
          })
        })
      ]
    });
  }
  const Ls = (t) => t && t.replace(/[<>:"/\\|?*]/g, "-").replace(/\s+/g, " ").trim().slice(0, 100) || "Untitled";
  function Ds({ globalActions: t, notebookId: a, selectedSourceIds: n, setSelectedRows: r, sources: l, notebookTitle: i }) {
    const [d, o] = s.useState(false), [c, u] = s.useState(false), [h, x] = s.useState(null), m = s.useCallback(async (S) => {
      if (!d) {
        o(true);
        try {
          await t.bulkMoveToFolder(a, n, S), r({}), k.success(`Moved ${n.length} source${n.length > 1 ? "s" : ""} to folder`), te(() => t.isLicensed());
        } catch (g) {
          console.error("Failed to move sources to folder:", g), k.error("Failed to move sources to folder");
        } finally {
          o(false);
        }
      }
    }, [
      d,
      t,
      a,
      n,
      r
    ]), y = s.useCallback(async () => {
      if (!d) {
        o(true);
        try {
          await t.bulkRemoveFromFolder(a, n), r({}), k.success("Removed from folder");
        } catch (S) {
          console.error("Failed to remove from folder:", S), k.error("Failed to remove from folder");
        } finally {
          o(false);
        }
      }
    }, [
      d,
      t,
      a,
      n,
      r
    ]), b = s.useCallback(async ({ sourceId: S, folderId: g }) => {
      if (!d && g) {
        o(true);
        try {
          g === "ungrouped" ? (await t.removeSourceFromFolder(a, S), k.success("Removed from folder")) : (await t.moveSourceToFolder(a, S, g), k.success("Moved to folder"));
        } catch {
          k.error("Failed to move source");
        } finally {
          o(false);
        }
      }
    }, [
      d,
      t,
      a
    ]), p = s.useCallback(async (S) => {
      try {
        await t.deleteFolder(a, S.id) !== false && (k.success("Folder deleted"), te(() => t.isLicensed()));
      } catch (g) {
        throw console.error("Failed to delete folder:", g), k.error("Failed to delete folder"), g;
      }
    }, [
      t,
      a
    ]), w = s.useCallback(async ({ name: S }, g) => {
      try {
        if (g) {
          if (await t.updateFolder(a, g, {
            name: S
          }) === null)
            return k.warning("A folder with that name already exists"), false;
        } else {
          const f = await t.createFolder(a, S);
          if (!f || f.error)
            return false;
          if (f.isNew)
            k.success("Folder created"), te(() => t.isLicensed());
          else
            return k.warning("Folder already exists"), false;
        }
      } catch (f) {
        return console.error("Failed to save folder:", f), k.error("Failed to save folder"), false;
      }
    }, [
      t,
      a
    ]), C = s.useCallback(async () => {
      const S = n.map((g) => l == null ? void 0 : l.find((f) => f.id === g)).filter(Boolean);
      if (S.length === 0) {
        k.error("No sources selected");
        return;
      }
      u(true), x(null);
      try {
        const { blob: g, sourceCount: f } = await t.downloadSelectedSourcesAsZip(a, S, (E) => x(E)), v = Ls(i || "notebook"), D = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), O = `${v}-${f}-sources-${D}.zip`, j = URL.createObjectURL(g), N = document.createElement("a");
        N.href = j, N.download = O, N.click(), URL.revokeObjectURL(j), k.success(`Downloaded ${f} source${f > 1 ? "s" : ""} as ZIP`), te(() => t.isLicensed());
      } catch (g) {
        console.error("Failed to download sources:", g), k.error("Failed to download sources");
      } finally {
        u(false), x(null);
      }
    }, [
      n,
      l,
      t,
      a,
      i
    ]);
    return {
      isMoving: d,
      isDownloading: c,
      downloadProgress: h,
      handleMoveToFolder: m,
      handleRemoveFromFolder: y,
      handleDragToFolder: b,
      confirmDeleteFolder: p,
      handleFolderSubmit: w,
      handleBulkDownload: C
    };
  }
  function ua({ globalActions: t, notebookId: a, notebook: n, sources: r, selectedRows: l, selectedSourceIds: i, setSelectedRows: d, setIsLoading: o }) {
    const [c, u] = s.useState(false), [h, x] = s.useState(null), [m, y] = s.useState(false), [b, p] = s.useState(false), [w, C] = s.useState(false), [S, g] = s.useState(false), [f, v] = s.useState(null), [D, O] = s.useState(null), [j, N] = s.useState(null), [E, T] = s.useState(null), M = s.useCallback(async (P) => {
      try {
        y(true), x(null), u(true);
        const U = await t.getNotebookSourceContent(P.id, a);
        x(U);
      } catch (U) {
        console.error("Failed to load source content:", U), k.error("Failed to load source content"), u(false);
      } finally {
        y(false);
      }
    }, [
      t,
      a
    ]), F = s.useCallback(() => {
      const P = Object.keys(l).filter((U) => l[U]).map((U) => r == null ? void 0 : r.find((V) => V.id === U)).filter(Boolean);
      if (P.length === 0) {
        k.error("No sources selected");
        return;
      }
      N(P);
    }, [
      l,
      r
    ]), H = s.useCallback((P) => {
      N([
        P
      ]);
    }, []), $ = s.useCallback(async (P) => {
      o(true);
      try {
        const U = await Promise.allSettled(P.map((Z) => t.deleteSourceNotebookLM(Z.id, n.id)));
        await t.fetchNotebookLMProjects();
        const V = P.filter((Z, G) => U[G].status === "fulfilled").map((Z) => Z.id);
        V.length > 0 && await t.bulkRemoveFromFolder(a, V), d({});
        const re = U.filter((Z) => Z.status === "rejected").length;
        re > 0 ? k.warning(`${V.length} source${V.length !== 1 ? "s" : ""} removed, ${re} failed`) : (k.success(`${P.length} source${P.length > 1 ? "s" : ""} removed`), te(() => t.isLicensed()));
      } catch (U) {
        throw console.error("Failed to remove sources:", U), k.error("Failed to remove sources"), U;
      } finally {
        o(false);
      }
    }, [
      t,
      n == null ? void 0 : n.id,
      a,
      o
    ]), A = s.useCallback((P) => {
      T([
        P
      ]);
    }, []), J = s.useCallback(() => {
      const P = Object.keys(l).filter((U) => l[U]).map((U) => r == null ? void 0 : r.find((V) => V.id === U)).filter(Boolean);
      if (P.length === 0) {
        k.error("No sources selected");
        return;
      }
      T(P);
    }, [
      l,
      r
    ]), de = s.useCallback(async (P) => {
      o(true);
      try {
        const V = [];
        for (let G = 0; G < P.length; G += 3) {
          const ne = P.slice(G, G + 3), ue = await Promise.allSettled(ne.map(({ sourceId: xe, newTitle: we }) => t.renameSourceNotebookLM(xe, we, a)));
          V.push(...ue);
        }
        await t.fetchNotebookLMProjects();
        const re = new Set(P.filter((G, ne) => V[ne].status === "rejected").map((G) => G.sourceId));
        re.size > 0 ? d((G) => {
          const ne = {};
          for (const ue of Object.keys(G))
            re.has(ue) && (ne[ue] = true);
          return ne;
        }) : d({});
        const Z = V.filter((G) => G.status === "rejected").length;
        Z > 0 ? k.warning(`${P.length - Z} renamed, ${Z} failed`) : (k.success(`${P.length} source${P.length > 1 ? "s" : ""} renamed`), te(() => t.isLicensed()));
      } catch (U) {
        throw console.error("Failed to rename sources:", U), k.error("Failed to rename sources"), U;
      } finally {
        o(false);
      }
    }, [
      t,
      a,
      o,
      d
    ]), X = s.useCallback(() => T(null), []), ie = s.useCallback((P) => {
      v(P), g(true);
    }, []), Y = s.useCallback((P) => {
      O(P);
    }, []), ee = s.useCallback(() => {
      v(null), g(true);
    }, []), Q = s.useCallback(() => {
      C(true);
    }, []), le = s.useCallback(() => {
      p(true);
    }, []), W = s.useCallback(() => {
      u(false);
    }, []), fe = s.useCallback(() => {
      p(false);
    }, []), ae = s.useCallback(() => {
      g(false), C(false), v(null);
    }, []), se = s.useCallback(() => {
      O(null);
    }, []), ce = s.useCallback(() => {
      N(null);
    }, []);
    return {
      viewContentDialogOpen: c,
      viewingSourceContent: h,
      isLoadingContent: m,
      isMergeDialogOpen: b,
      isCreateDialogOpen: S,
      isCreateFolderFromMenu: w,
      editingFolder: f,
      pendingDeleteFolder: D,
      pendingDeleteSources: j,
      pendingRenameSources: E,
      handleViewContent: M,
      handleBulkDelete: F,
      handleDelete: H,
      handleRename: A,
      handleBulkRename: J,
      confirmDeleteSources: $,
      confirmRenameSources: de,
      closeRenameDialog: X,
      handleEditFolder: ie,
      handleDeleteFolder: Y,
      openCreateFolder: ee,
      openCreateFolderFromMenu: Q,
      openMergeDialog: le,
      closeViewContentDialog: W,
      closeMergeDialog: fe,
      closeCreateDialog: ae,
      closeDeleteFolderDialog: se,
      closeDeleteSourceDialog: ce
    };
  }
  function Es({ notebook: t, sources: a, isLoading: n, setIsLoading: r, globalActions: l, notebookId: i, onAddSource: d, onTabChange: o, readOnly: c = false }) {
    const [u] = Fe(), [h, x] = s.useState({}), [m, y] = s.useState(null), [b, p] = s.useState("");
    s.useEffect(() => {
      x({}), y(null), p("");
    }, [
      i
    ]), s.useEffect(() => {
      x({});
    }, [
      m,
      b
    ]);
    const w = `${Ha}_EXPANDED_${i}`, [C, S] = s.useState(() => {
      try {
        const I = window.localStorage.getItem(w);
        return I !== null ? JSON.parse(I) : true;
      } catch {
        return true;
      }
    });
    s.useEffect(() => {
      try {
        window.localStorage.setItem(w, JSON.stringify(C));
      } catch {
      }
    }, [
      C,
      w
    ]);
    const { sourceFreshness: g, isCheckingFreshness: f, isRefreshingAll: v, staleCount: D, isCachedResult: O, lastCheckTime: j, handleRefreshSource: N, handleRefreshAllStale: E, forceCheck: T } = aa({
      notebook: t,
      sources: a,
      globalActions: l
    }), M = s.useRef(g);
    s.useEffect(() => {
      M.current = g;
    }, [
      g
    ]);
    const { folders: F, sourceFolderMap: H } = u.sourceFolders, [$, A] = s.useMemo(() => [
      F[i] || {},
      H[i] || {}
    ], [
      F,
      H,
      i
    ]), J = s.useMemo(() => Object.values($).sort((I, K) => I.name.localeCompare(K.name)), [
      $
    ]), de = s.useMemo(() => {
      const I = {};
      for (const K of Object.values(A))
        I[K] = (I[K] || 0) + 1;
      return I;
    }, [
      A
    ]), X = s.useMemo(() => [
      ...new Set(a.map((K) => K.sourceType))
    ].sort(), [
      a
    ]), ie = s.useMemo(() => {
      const I = {};
      for (const K of a)
        I[K.sourceType] = (I[K.sourceType] || 0) + 1;
      return I;
    }, [
      a
    ]), Y = s.useMemo(() => {
      let I = a;
      if (m !== null && (I = I.filter((K) => K.sourceType === m)), b.trim()) {
        const K = b.toLowerCase();
        I = I.filter((ot) => {
          var _a2;
          return (_a2 = ot.title) == null ? void 0 : _a2.toLowerCase().includes(K);
        });
      }
      return I;
    }, [
      a,
      m,
      b
    ]), ee = gs({
      sources: Y,
      folders: $,
      notebookSourceMap: A
    }), Q = m !== null || b.trim(), le = s.useMemo(() => Q ? ee.filter((I) => !I._isGroupRow || I.subRows.length > 0) : ee, [
      ee,
      Q
    ]), W = s.useMemo(() => Object.keys(h).filter((I) => h[I]), [
      h
    ]), { isMoving: fe, handleMoveToFolder: ae, handleRemoveFromFolder: se, handleDragToFolder: ce, confirmDeleteFolder: P, handleFolderSubmit: U, handleBulkDownload: V, isDownloading: re, downloadProgress: Z } = Ds({
      globalActions: l,
      notebookId: i,
      selectedSourceIds: W,
      setSelectedRows: x,
      sources: a,
      notebookTitle: t == null ? void 0 : t.title
    }), G = ua({
      globalActions: l,
      notebookId: i,
      notebook: t,
      sources: a,
      selectedRows: h,
      selectedSourceIds: W,
      setSelectedRows: x,
      setIsLoading: r
    }), { handleViewContent: ne, handleBulkDelete: ue, handleDelete: xe, handleRename: we, handleBulkRename: me, handleEditFolder: Ae, handleDeleteFolder: _e, openCreateFolder: be, openCreateFolderFromMenu: qe, openMergeDialog: Oe } = G, Pe = s.useCallback(() => x({}), []), [Qe, ve] = s.useState(false), R = s.useCallback(() => ve(true), []), _ = s.useCallback(() => ve(false), []), ye = s.useCallback(() => {
      ve(false), x({});
    }, []), Ye = s.useMemo(() => W.map((I) => a == null ? void 0 : a.find((K) => K.id === I)).filter(Boolean), [
      W,
      a
    ]), lt = s.useMemo(() => sa({
      sourceFreshness: M.current,
      handleRefreshSource: N,
      handleViewContent: ne,
      handleRename: we,
      handleDelete: xe,
      readOnly: c
    }), [
      N,
      ne,
      we,
      xe,
      c
    ]), nt = J.length > 0 ? le : Y;
    return e.jsxs(e.Fragment, {
      children: [
        (f || D > 0 || O) && e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            f && e.jsxs("span", {
              className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400",
              children: [
                e.jsx(oe, {
                  className: "w-3 h-3 animate-spin"
                }),
                "Checking updates..."
              ]
            }),
            D > 0 && e.jsxs("button", {
              onClick: E,
              disabled: v,
              className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-white bg-amber-600 rounded-md hover:bg-amber-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(oe, {
                  className: `w-3.5 h-3.5 ${v ? "animate-spin" : ""}`
                }),
                "Refresh ",
                D,
                " Source",
                D > 1 ? "s" : ""
              ]
            }),
            O && !f && e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                j && e.jsxs("span", {
                  className: "text-xs text-gray-500 dark:text-slate-400",
                  children: [
                    "Checked",
                    " ",
                    new Date(j).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: T,
                  className: "flex items-center gap-1 text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200",
                  children: [
                    e.jsx(oe, {
                      className: "w-3 h-3"
                    }),
                    "Re-check"
                  ]
                })
              ]
            })
          ]
        }),
        (a == null ? void 0 : a.length) > 0 && e.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400",
              "aria-live": "polite",
              children: [
                e.jsx(ke, {
                  className: "w-3 h-3"
                }),
                Y.length < a.length ? `${Y.length} of ${a.length} source${a.length !== 1 ? "s" : ""}` : `${a.length} source${a.length !== 1 ? "s" : ""}`,
                J.length > 0 && e.jsxs(e.Fragment, {
                  children: [
                    e.jsx(Jt, {
                      className: "w-3 h-3"
                    }),
                    "in ",
                    J.length,
                    " folder",
                    J.length !== 1 ? "s" : ""
                  ]
                })
              ]
            }),
            e.jsxs("button", {
              onClick: be,
              className: "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium text-blue-600 dark:text-blue-400 border border-dashed border-blue-300 dark:border-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950",
              children: [
                e.jsx(hs, {
                  className: "w-3.5 h-3.5",
                  "aria-hidden": "true"
                }),
                "New Folder"
              ]
            })
          ]
        }),
        (a == null ? void 0 : a.length) > 0 && e.jsx(oa, {
          uniqueTypes: X,
          typeCounts: ie,
          typeFilter: m,
          setTypeFilter: y,
          searchQuery: b,
          setSearchQuery: p
        }),
        e.jsx(na, {
          selectedCount: W.length,
          folders: J,
          sourceCounts: de,
          isLoading: n || fe,
          onMoveToFolder: ae,
          onRemoveFromFolder: se,
          onCreateNewFolder: qe,
          onBulkRename: me,
          onMerge: Oe,
          onDownload: V,
          isDownloading: re,
          downloadProgress: Z,
          onCopyToNotebook: R,
          onGenerate: () => {
            l.setSelectedSourceIds(W), o == null ? void 0 : o("artifacts");
          },
          onCancel: Pe,
          onBulkDelete: ue,
          readOnly: c
        }),
        n ? e.jsx("div", {
          className: "flex flex-col items-center justify-center w-full py-12 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
          children: e.jsx(Le, {
            text: "Loading sources..."
          })
        }) : (Y == null ? void 0 : Y.length) > 0 ? e.jsx(ta, {
          columns: lt,
          data: nt,
          enableRowSelection: true,
          onRowSelectionChange: x,
          rowSelection: h,
          enableGrouping: J.length > 0,
          expanded: C,
          onExpandedChange: S,
          onEditFolder: Ae,
          onDeleteFolder: _e,
          onDragEnd: ce
        }) : (a == null ? void 0 : a.length) > 0 ? e.jsxs("div", {
          className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
          children: [
            e.jsx("div", {
              className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
              children: e.jsx(ke, {
                className: "h-6 w-6 text-gray-400 dark:text-slate-500"
              })
            }),
            e.jsx("h3", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100",
              children: "No matching sources"
            }),
            e.jsx("p", {
              className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center",
              children: "Try adjusting your filters or search query."
            })
          ]
        }) : e.jsxs("div", {
          className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
          children: [
            e.jsx("div", {
              className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
              children: e.jsx(ke, {
                className: "h-6 w-6 text-gray-400 dark:text-slate-500"
              })
            }),
            e.jsx("h3", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100",
              children: "No sources yet"
            }),
            e.jsx("p", {
              className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center mb-4",
              children: "Add content to your notebook to start organizing your knowledge."
            }),
            e.jsxs("button", {
              onClick: d,
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(De, {
                  className: "w-3.5 h-3.5"
                }),
                "Add Source"
              ]
            })
          ]
        }),
        e.jsx(Cs, {
          dialogs: G,
          notebook: t,
          sources: a,
          selectedRows: h,
          setSelectedRows: x,
          setIsLoading: r,
          globalActions: l,
          notebookId: i,
          selectedSourceIds: W,
          handleFolderSubmit: U,
          confirmDeleteFolder: P,
          folderSourceCounts: de
        }),
        e.jsx(ca, {
          isOpen: Qe,
          onClose: _,
          sourceNotebookId: i,
          selectedSources: Ye,
          onSuccess: ye
        })
      ]
    });
  }
  const Ms = pe.lazy(() => he(() => import("./chunk-02fbf508.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-02fbf508.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-bd7b16ee.js"]));
  function Ts({ dialogs: t, notebook: a, sources: n, selectedRows: r, setSelectedRows: l, setIsLoading: i, globalActions: d, notebookId: o, selectedSourceIds: c, handleFolderSubmit: u, confirmDeleteFolder: h, folderSourceCounts: x }) {
    const { viewContentDialogOpen: m, viewingSourceContent: y, isLoadingContent: b, closeViewContentDialog: p, isMergeDialogOpen: w, closeMergeDialog: C, isCreateDialogOpen: S, isCreateFolderFromMenu: g, closeCreateDialog: f, editingFolder: v, pendingDeleteFolder: D, closeDeleteFolderDialog: O, pendingDeleteSources: j, closeDeleteSourceDialog: N, confirmDeleteSources: E, pendingRenameSources: T, closeRenameDialog: M, confirmRenameSources: F } = t, H = s.useCallback(async ({ name: $ }) => {
      const A = await d.createNotebookLabel(o, $);
      if (!A || A.error)
        return false;
      if (A.folder)
        try {
          await d.bulkMoveSourcesToNotebookLabel(o, c, A.folder.id), l({}), k.success(`Created label and moved ${c.length} source${c.length > 1 ? "s" : ""}`);
        } catch {
          k.warning("Label created but some sources failed to move");
        }
    }, [
      d,
      o,
      c,
      l
    ]);
    return e.jsxs(e.Fragment, {
      children: [
        e.jsx(da, {
          isOpen: m,
          onClose: p,
          sourceContent: y,
          isLoading: b
        }),
        e.jsx(s.Suspense, {
          fallback: null,
          children: w && e.jsx(Ms, {
            isOpen: w,
            onClose: C,
            notebook: a,
            selectedSources: Object.keys(r).filter(($) => r[$]).map(($) => n == null ? void 0 : n.find((A) => A.id === $)).filter(Boolean),
            onSuccess: async () => {
              l({}), i(true);
              try {
                await d.fetchNotebookLMProjects(), k.success("Sources refreshed");
              } catch {
                k.error("Failed to refresh");
              } finally {
                i(false);
              }
            }
          })
        }),
        e.jsx(ra, {
          isOpen: S || g,
          onClose: f,
          onSubmit: g ? H : u,
          editingFolder: v,
          noun: "Label",
          showLocalNotice: false
        }),
        e.jsx(la, {
          isOpen: !!D,
          onClose: O,
          onConfirm: h,
          folder: D,
          sourceCount: D && x[D.id] || 0,
          noun: "label",
          removalNote: "will be removed from this label"
        }),
        e.jsx(Wt, {
          isOpen: !!j,
          onClose: N,
          onConfirm: E,
          sources: j
        }),
        e.jsx(ia, {
          isOpen: !!T,
          onClose: M,
          onConfirm: F,
          sources: T
        })
      ]
    });
  }
  const $s = s.memo(Ts);
  function As({ isOpen: t, onClose: a, onConfirm: n }) {
    const [r, l] = s.useState(false);
    s.useEffect(() => {
      t && l(false);
    }, [
      t
    ]);
    const i = async () => {
      l(true);
      try {
        await n(), a();
      } catch {
        l(false);
      }
    };
    return e.jsxs(Ve, {
      open: t,
      onClose: r ? () => {
      } : a,
      className: "relative z-50",
      children: [
        e.jsx("div", {
          className: "fixed inset-0 bg-black/25",
          "aria-hidden": "true"
        }),
        e.jsx("div", {
          className: "fixed inset-0 flex w-screen items-center justify-center p-4",
          children: e.jsxs(Ge, {
            className: "w-full max-w-sm space-y-4 bg-white dark:bg-slate-800 rounded-lg shadow-lg dark:shadow-slate-900/30 p-5",
            children: [
              e.jsx(He, {
                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                children: "Regenerate all labels?"
              }),
              e.jsx("p", {
                className: "text-xs text-gray-500 dark:text-slate-400",
                children: "This replaces all existing labels with a fresh set generated by NotebookLM. Your sources are preserved, but the current label organization will be lost."
              }),
              e.jsxs("div", {
                className: "flex justify-end gap-2 pt-2",
                children: [
                  e.jsx("button", {
                    type: "button",
                    onClick: a,
                    disabled: r,
                    className: "px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-700 border border-gray-300 dark:border-slate-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-600 disabled:opacity-50",
                    children: "Cancel"
                  }),
                  e.jsx("button", {
                    type: "button",
                    onClick: i,
                    disabled: r,
                    className: "px-3 py-1.5 text-xs font-medium text-white bg-amber-600 rounded-md hover:bg-amber-700 disabled:opacity-50",
                    children: r ? "Regenerating..." : "Regenerate"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  const _s = "polygon(7px 0, 100% 0, 100% 100%, 7px 100%, 0 50%)", xa = {
    clipPath: _s
  };
  function ma(t) {
    return `Labels need ${Ce}+ sources (${t}/${Ce})`;
  }
  function ha(t) {
    const a = String(t || "");
    let n = 0;
    for (let r = 0; r < a.length; r++)
      n = n * 31 + a.charCodeAt(r) >>> 0;
    return Et[n % Et.length];
  }
  function ga(t) {
    return t ? t.emoji ? `${t.emoji} ${t.name}` : t.name : "";
  }
  function kt(t, a) {
    const n = (a || "").trim().toLowerCase();
    return n ? t.filter((r) => r.name.toLowerCase().includes(n)) : t;
  }
  function Je({ label: t, size: a = "xs", showRemove: n = false, onRemove: r, onClick: l, isDarkMode: i }) {
    const d = Wa(ha(t.id), i);
    return e.jsxs("span", {
      onClick: l,
      title: `${t.name} \xB7 synced label`,
      style: xa,
      className: Re("inline-flex items-center gap-0.5 rounded-r-sm font-medium", d, a === "xs" && "pl-2.5 pr-1.5 py-0 text-[10px]", a === "sm" && "pl-3 pr-2 py-0.5 text-xs", l && "cursor-pointer hover:opacity-80"),
      children: [
        e.jsx(je, {
          className: "w-2.5 h-2.5 shrink-0 opacity-70",
          "aria-hidden": "true"
        }),
        e.jsx("span", {
          className: "truncate max-w-[100px]",
          children: ga(t)
        }),
        n && r && e.jsx("button", {
          onClick: (o) => {
            o.stopPropagation(), r(t);
          },
          className: "ml-0.5 p-0.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10",
          children: e.jsx(ge, {
            className: "w-3 h-3"
          })
        })
      ]
    });
  }
  function Os({ labelIds: t = [], labelsById: a = {}, onAdd: n, onCreate: r, onRemove: l, canRemove: i = false, readOnly: d = false }) {
    const o = s.useMemo(() => t.map((c) => a[c]).filter(Boolean), [
      t,
      a
    ]);
    return e.jsxs("div", {
      className: "mt-1 flex flex-wrap items-center gap-1",
      onClick: (c) => c.stopPropagation(),
      children: [
        o.map((c) => e.jsx(Je, {
          label: c,
          showRemove: !d && i,
          onRemove: () => l == null ? void 0 : l(c.id)
        }, c.id)),
        !d && e.jsxs(Me, {
          className: "relative inline-flex",
          children: [
            e.jsx(Te, {
              onClick: (c) => c.stopPropagation(),
              "aria-label": "Add label",
              className: "inline-flex items-center px-1.5 py-0 text-[10px] font-medium rounded-full border border-dashed border-gray-300 dark:border-gray-600 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none",
              children: e.jsx(De, {
                className: "w-3 h-3"
              })
            }),
            e.jsx($e, {
              anchor: {
                to: "bottom start",
                gap: 4
              },
              onClick: (c) => c.stopPropagation(),
              className: "z-[9999] w-52 rounded-md bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 border border-gray-200 dark:border-slate-700 py-1 focus:outline-none",
              children: e.jsx(Ps, {
                labelIds: t,
                labelsById: a,
                onAdd: n,
                onCreate: r
              })
            })
          ]
        })
      ]
    });
  }
  function Ps({ labelIds: t, labelsById: a, onAdd: n, onCreate: r }) {
    const [l, i] = s.useState(""), [d, o] = s.useState(false), c = s.useRef(null);
    s.useEffect(() => {
      var _a2;
      (_a2 = c.current) == null ? void 0 : _a2.focus({
        preventScroll: true
      });
    }, []);
    const u = s.useMemo(() => {
      const b = new Set(t), p = Object.values(a).filter((w) => !b.has(w.id));
      return kt(p, l).sort((w, C) => w.name.localeCompare(C.name));
    }, [
      a,
      t,
      l
    ]), h = !!l.trim() && !Object.values(a).some((b) => b.name.toLowerCase() === l.trim().toLowerCase()), x = async (b) => {
      o(true);
      try {
        await (n == null ? void 0 : n(b)), i("");
      } finally {
        o(false);
      }
    }, m = async () => {
      const b = l.trim();
      if (!(!b || d)) {
        o(true);
        try {
          await (r == null ? void 0 : r(b)), i("");
        } finally {
          o(false);
        }
      }
    }, y = (b) => {
      b.key === "Enter" && (b.preventDefault(), h ? m() : u.length && x(u[0].id));
    };
    return e.jsxs(e.Fragment, {
      children: [
        e.jsx("div", {
          className: "px-2 pb-1",
          children: e.jsx("input", {
            ref: c,
            type: "text",
            value: l,
            onChange: (b) => i(b.target.value),
            onKeyDown: y,
            placeholder: "Add or create label...",
            className: "w-full px-2 py-1 text-xs border border-gray-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 dark:text-slate-100"
          })
        }),
        e.jsxs("div", {
          className: "max-h-40 overflow-y-auto",
          children: [
            u.map((b) => e.jsx("button", {
              disabled: d,
              onClick: () => x(b.id),
              className: "w-full px-2 py-1 text-left hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
              children: e.jsx(Je, {
                label: b
              })
            }, b.id)),
            h && e.jsxs("button", {
              disabled: d,
              onClick: m,
              className: "w-full px-2 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-1.5 text-xs text-gray-600 dark:text-slate-400 border-t border-gray-100 dark:border-slate-700 disabled:opacity-50",
              children: [
                e.jsx(De, {
                  className: "w-3 h-3 flex-shrink-0"
                }),
                e.jsx("span", {
                  children: "Create"
                }),
                e.jsx(Je, {
                  label: {
                    id: l.trim(),
                    name: l.trim()
                  }
                })
              ]
            }),
            u.length === 0 && !h && e.jsx("div", {
              className: "px-2 py-2 text-xs text-gray-500 dark:text-slate-400 text-center",
              children: l ? "No matching labels" : "No more labels"
            })
          ]
        })
      ]
    });
  }
  function Bs({ labels: t = [], counts: a = {}, selectedIds: n = [], onToggle: r, onClear: l, hiddenCount: i = 0 }) {
    const [d, o] = s.useState(""), c = new Set(n), u = s.useRef(null);
    s.useEffect(() => {
      var _a2;
      (_a2 = u.current) == null ? void 0 : _a2.focus({
        preventScroll: true
      });
    }, []);
    const h = s.useMemo(() => kt(t, d), [
      t,
      d
    ]);
    return e.jsxs(Me, {
      className: "relative inline-flex",
      children: [
        e.jsxs(Te, {
          title: "More labels",
          className: "inline-flex items-center gap-1 rounded-full px-1.5 py-0 text-[10px] font-medium border border-gray-300 dark:border-slate-600 text-gray-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 focus:outline-none",
          children: [
            "+",
            i,
            " more",
            e.jsx(Xe, {
              className: "w-3 h-3",
              "aria-hidden": "true"
            })
          ]
        }),
        e.jsxs($e, {
          anchor: "bottom end",
          className: "z-20 w-60 max-h-80 overflow-hidden rounded-md border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 flex flex-col focus:outline-none",
          children: [
            e.jsx("div", {
              className: "p-2 border-b border-gray-200 dark:border-slate-700",
              children: e.jsxs("div", {
                className: "relative",
                children: [
                  e.jsx(Ue, {
                    className: "absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-gray-400"
                  }),
                  e.jsx("input", {
                    ref: u,
                    type: "text",
                    placeholder: "Search labels...",
                    value: d,
                    onChange: (x) => o(x.target.value),
                    className: "w-full pl-6 pr-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  })
                ]
              })
            }),
            e.jsxs("div", {
              className: "flex-1 overflow-y-auto py-1",
              children: [
                h.length === 0 && e.jsx("div", {
                  className: "px-2 py-3 text-center text-xs text-gray-500 dark:text-slate-400",
                  children: "No labels match"
                }),
                h.map((x) => {
                  const m = c.has(x.id);
                  return e.jsxs("button", {
                    type: "button",
                    onClick: () => r == null ? void 0 : r(x.id),
                    "aria-pressed": m,
                    className: "w-full flex items-center gap-2 px-2 py-1.5 text-left hover:bg-gray-50 dark:hover:bg-slate-700",
                    children: [
                      e.jsx("span", {
                        className: "w-3.5 shrink-0",
                        children: m && e.jsx(Yt, {
                          className: "w-3.5 h-3.5 text-blue-600 dark:text-blue-400",
                          "aria-hidden": "true"
                        })
                      }),
                      e.jsx("span", {
                        className: "flex-1 min-w-0",
                        children: e.jsx(Je, {
                          label: x
                        })
                      }),
                      e.jsx("span", {
                        className: "text-[10px] text-gray-400 dark:text-slate-500 tabular-nums shrink-0",
                        children: a[x.id] || 0
                      })
                    ]
                  }, x.id);
                })
              ]
            }),
            n.length > 0 && e.jsxs("button", {
              type: "button",
              onClick: l,
              className: "flex items-center justify-center gap-1 px-2 py-1.5 border-t border-gray-200 dark:border-slate-700 text-xs text-gray-600 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-700",
              children: [
                e.jsx(ge, {
                  className: "w-3 h-3"
                }),
                "Clear filter"
              ]
            })
          ]
        })
      ]
    });
  }
  const _t = 10;
  function Ot({ name: t, ariaName: a = t, color: n, count: r, active: l, onToggle: i, title: d }) {
    const o = At[n] || At.gray, c = l ? Yt : je;
    return e.jsxs("button", {
      type: "button",
      onClick: i,
      "aria-pressed": l,
      "aria-label": l ? `Remove filter: ${a}` : `Filter by ${a}`,
      title: d,
      style: xa,
      className: Re("inline-flex items-center gap-1 rounded-r-sm pl-2.5 pr-2 py-0 text-[10px]", l ? `${o.autoSelected} font-semibold` : `${o.auto} font-medium hover:brightness-95 dark:hover:brightness-110`),
      children: [
        e.jsx(c, {
          className: "w-2.5 h-2.5 shrink-0",
          "aria-hidden": "true"
        }),
        e.jsx("span", {
          className: "truncate max-w-[110px]",
          children: t
        }),
        e.jsxs("span", {
          className: "opacity-70 tabular-nums shrink-0",
          children: [
            "(",
            r,
            ")"
          ]
        })
      ]
    });
  }
  function Is({ labels: t = [], counts: a = {}, selectedIds: n = [], onToggle: r, onClear: l, untaggedId: i, untaggedCount: d = 0 }) {
    if (!t.length)
      return null;
    const o = new Set(n), c = t.slice(0, _t), u = t.slice(_t), h = [
      ...c,
      ...u.filter((m) => o.has(m.id))
    ], x = u.filter((m) => !o.has(m.id));
    return e.jsxs("div", {
      className: "flex items-center gap-1.5 flex-wrap",
      children: [
        i && d > 0 && e.jsx(Ot, {
          name: "Untagged",
          color: "gray",
          count: d,
          active: o.has(i),
          onToggle: () => r == null ? void 0 : r(i),
          title: "Sources with no labels"
        }),
        h.map((m) => e.jsx(Ot, {
          name: ga(m),
          ariaName: m.name,
          color: ha(m.id),
          count: a[m.id] || 0,
          active: o.has(m.id),
          onToggle: () => r == null ? void 0 : r(m.id),
          title: m.name
        }, m.id)),
        x.length > 0 && e.jsx(Bs, {
          labels: t,
          counts: a,
          selectedIds: n,
          onToggle: r,
          onClear: l,
          hiddenCount: x.length
        }),
        n.length > 0 && e.jsxs("button", {
          onClick: l,
          "aria-label": "Clear all label filters",
          className: "inline-flex items-center gap-1 px-1.5 py-0 rounded-full text-[10px] font-medium text-gray-600 dark:text-slate-300 border border-gray-300 dark:border-slate-600 hover:bg-gray-100 dark:hover:bg-slate-700",
          children: [
            e.jsx(ge, {
              className: "w-3 h-3"
            }),
            "Clear all (",
            n.length,
            ")"
          ]
        })
      ]
    });
  }
  function zs({ labels: t = [], counts: a = {}, onCreate: n, onRename: r, onDelete: l }) {
    const [i, d] = s.useState(""), o = s.useMemo(() => kt(t, i), [
      t,
      i
    ]);
    return e.jsxs(Me, {
      className: "relative",
      children: [
        e.jsxs(Te, {
          title: "Manage labels",
          className: "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium text-gray-600 dark:text-slate-300 border border-gray-300 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 focus:outline-none",
          children: [
            e.jsx(Fa, {
              className: "w-3.5 h-3.5",
              "aria-hidden": "true"
            }),
            "Manage",
            e.jsx(Xe, {
              className: "w-3 h-3",
              "aria-hidden": "true"
            })
          ]
        }),
        e.jsx($e, {
          anchor: "bottom end",
          className: "z-20 w-64 rounded-lg bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 ring-1 ring-black/5 dark:ring-slate-700 focus:outline-none p-1.5",
          children: ({ close: c }) => e.jsxs(e.Fragment, {
            children: [
              t.length > 4 && e.jsx("input", {
                type: "text",
                value: i,
                onChange: (u) => d(u.target.value),
                placeholder: "Search labels...",
                "aria-label": "Search labels",
                className: "w-full rounded-md border border-gray-300 dark:border-slate-700 text-xs px-2.5 py-1.5 mb-1.5 dark:bg-slate-900 dark:text-slate-100 focus:border-blue-500 focus:ring-blue-500"
              }),
              e.jsx("div", {
                className: "max-h-56 overflow-y-auto",
                children: o.length === 0 ? e.jsx("p", {
                  className: "text-xs text-gray-500 dark:text-slate-400 px-2 py-1.5",
                  children: t.length === 0 ? "No labels yet" : "No matching labels"
                }) : o.map((u) => e.jsxs("div", {
                  className: "flex items-center gap-1 px-1.5 py-1 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700",
                  children: [
                    e.jsxs("span", {
                      className: "flex-1 min-w-0 flex items-center gap-1.5",
                      children: [
                        e.jsx(Je, {
                          label: u
                        }),
                        e.jsx("span", {
                          className: "text-[10px] text-gray-400 dark:text-slate-500 tabular-nums",
                          children: a[u.id] || 0
                        })
                      ]
                    }),
                    e.jsx("button", {
                      onClick: () => {
                        c(), r == null ? void 0 : r(u);
                      },
                      "aria-label": `Rename label ${u.name}`,
                      title: "Rename",
                      className: "p-1 rounded text-gray-400 dark:text-slate-500 hover:bg-gray-100 dark:hover:bg-slate-600 hover:text-gray-600 dark:hover:text-slate-300",
                      children: e.jsx(Ze, {
                        className: "w-3 h-3",
                        "aria-hidden": "true"
                      })
                    }),
                    e.jsx("button", {
                      onClick: () => {
                        c(), l == null ? void 0 : l(u);
                      },
                      "aria-label": `Delete label ${u.name}`,
                      title: "Delete",
                      className: "p-1 rounded text-gray-400 dark:text-slate-500 hover:bg-red-50 dark:hover:bg-red-950 hover:text-red-600 dark:hover:text-red-400",
                      children: e.jsx(Ee, {
                        className: "w-3 h-3",
                        "aria-hidden": "true"
                      })
                    })
                  ]
                }, u.id))
              }),
              e.jsxs("button", {
                onClick: () => {
                  c(), n == null ? void 0 : n();
                },
                className: "w-full mt-1 flex items-center gap-2 px-2 py-1.5 rounded-md text-xs font-medium text-blue-600 dark:text-blue-400 border-t border-gray-100 dark:border-slate-700 hover:bg-blue-50 dark:hover:bg-blue-950",
                children: [
                  e.jsx(De, {
                    className: "w-3.5 h-3.5",
                    "aria-hidden": "true"
                  }),
                  "Create label"
                ]
              })
            ]
          })
        })
      ]
    });
  }
  const Us = s.memo(zs);
  function Vs({ onGenerateFirst: t, onAutoLabelUnlabeled: a, onRegenerateAll: n, hasLabels: r = false, disabled: l = false, busy: i = false }) {
    return e.jsxs(Me, {
      className: "relative",
      children: [
        e.jsxs(Te, {
          disabled: l,
          title: "AI labeling",
          className: "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium text-gray-600 dark:text-slate-300 border border-gray-300 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 focus:outline-none",
          children: [
            e.jsx(Se, {
              className: `w-3.5 h-3.5 ${i ? "animate-pulse" : ""}`,
              "aria-hidden": "true"
            }),
            i ? "Auto-labeling\u2026" : "AI",
            e.jsx(Xe, {
              className: "w-3 h-3",
              "aria-hidden": "true"
            })
          ]
        }),
        e.jsx($e, {
          anchor: "bottom end",
          className: "z-20 w-60 rounded-lg bg-white dark:bg-slate-800 shadow-lg dark:shadow-slate-900/30 ring-1 ring-black/5 dark:ring-slate-700 focus:outline-none py-1",
          children: ({ close: d }) => e.jsxs(e.Fragment, {
            children: [
              !r && e.jsx(ct, {
                close: d,
                onSelect: t,
                Icon: Se,
                iconClass: "text-indigo-600 dark:text-indigo-400",
                title: "Auto-label all sources",
                description: "Let AI group your sources into labels"
              }),
              r && e.jsxs(e.Fragment, {
                children: [
                  e.jsx(ct, {
                    close: d,
                    onSelect: a,
                    Icon: je,
                    iconClass: "text-gray-500 dark:text-slate-400",
                    title: "Label remaining sources",
                    description: "Tag only sources not in any label yet"
                  }),
                  e.jsx(ct, {
                    close: d,
                    onSelect: n,
                    Icon: oe,
                    iconClass: "text-amber-600 dark:text-amber-400",
                    titleClass: "text-amber-700 dark:text-amber-400",
                    hoverClass: "hover:bg-amber-50 dark:hover:bg-amber-950 border-t border-gray-100 dark:border-slate-700",
                    title: "Regenerate all labels",
                    description: "Replace every label with a fresh AI set"
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }
  function ct({ close: t, onSelect: a, Icon: n, iconClass: r, title: l, description: i, titleClass: d = "text-gray-700 dark:text-slate-300", hoverClass: o = "hover:bg-gray-100 dark:hover:bg-slate-700" }) {
    return e.jsxs("button", {
      onClick: () => {
        t(), a();
      },
      className: `w-full flex items-start gap-2 px-3 py-1.5 text-left ${o}`,
      children: [
        e.jsx(n, {
          className: `w-3.5 h-3.5 mt-0.5 shrink-0 ${r}`,
          "aria-hidden": "true"
        }),
        e.jsxs("span", {
          className: "flex flex-col",
          children: [
            e.jsx("span", {
              className: `text-xs ${d}`,
              children: l
            }),
            e.jsx("span", {
              className: "text-[10px] text-gray-400 dark:text-slate-500",
              children: i
            })
          ]
        })
      ]
    });
  }
  const Gs = s.memo(Vs);
  function Hs({ filteredCount: t, totalCount: a, labelCount: n, searchQuery: r, setSearchQuery: l, onRefresh: i, isRefreshing: d = false, labels: o = [], counts: c = {}, onCreateLabel: u, onRenameLabel: h, onDeleteLabel: x, onGenerateFirst: m, onAutoLabelUnlabeled: y, onRegenerateAll: b, hasLabels: p = false, isBusy: w = false, readOnly: C = false }) {
    const S = a !== 1 ? "sources" : "source";
    return e.jsxs("div", {
      className: "flex flex-wrap items-center justify-between gap-2",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400 min-w-0",
          "aria-live": "polite",
          children: [
            e.jsx(ke, {
              className: "w-3 h-3 shrink-0",
              "aria-hidden": "true"
            }),
            t < a ? `${t} of ${a} ${S}` : `${a} ${S}`,
            n > 0 && e.jsxs(e.Fragment, {
              children: [
                e.jsx(je, {
                  className: "w-3 h-3 shrink-0",
                  "aria-hidden": "true"
                }),
                "in ",
                n,
                " label",
                n !== 1 ? "s" : ""
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-2 flex-wrap justify-end",
          children: [
            e.jsxs("div", {
              className: "relative w-36",
              children: [
                e.jsx(Ue, {
                  className: "absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400 dark:text-slate-500 pointer-events-none"
                }),
                e.jsx("input", {
                  type: "text",
                  placeholder: "Search...",
                  value: r,
                  onChange: (g) => l(g.target.value),
                  className: "w-full pl-7 pr-2 py-1.5 text-xs border border-gray-300 dark:border-gray-600 rounded-md focus:ring-1 focus:ring-gray-900 dark:focus:ring-gray-100 focus:border-gray-900 dark:focus:border-gray-100 bg-white dark:bg-slate-800 dark:text-slate-100"
                })
              ]
            }),
            e.jsx("button", {
              onClick: i,
              disabled: d,
              "aria-label": "Refresh labels",
              title: "Refresh labels",
              className: "inline-flex items-center justify-center p-1.5 rounded-md text-gray-600 dark:text-slate-300 border border-gray-300 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50",
              children: e.jsx(oe, {
                className: `w-3.5 h-3.5 ${d ? "animate-spin" : ""}`
              })
            }),
            !C && e.jsxs(e.Fragment, {
              children: [
                e.jsx(Us, {
                  labels: o,
                  counts: c,
                  onCreate: u,
                  onRename: h,
                  onDelete: x
                }),
                e.jsx(Gs, {
                  onGenerateFirst: m,
                  onAutoLabelUnlabeled: y,
                  onRegenerateAll: b,
                  hasLabels: p,
                  disabled: d || w,
                  busy: w
                })
              ]
            })
          ]
        })
      ]
    });
  }
  const We = (t, a) => {
    const n = URL.createObjectURL(t), r = document.createElement("a");
    r.href = n, r.download = a, document.body.appendChild(r), r.click(), document.body.removeChild(r), URL.revokeObjectURL(n);
  };
  function Zs({ globalActions: t, notebookId: a, selectedSourceIds: n, setSelectedRows: r, sources: l, notebookTitle: i }) {
    const [d, o] = s.useState(0), [c, u] = s.useState(false), [h, x] = s.useState(null), m = d > 0, y = s.useRef(Promise.resolve()), b = s.useCallback((g) => {
      o((v) => v + 1);
      const f = y.current.then(() => g());
      return y.current = f.catch(() => {
      }).finally(() => o((v) => v - 1)), f;
    }, []), p = s.useCallback((g) => b(async () => {
      try {
        await t.bulkMoveSourcesToNotebookLabel(a, n, g), r({}), k.success(`Moved ${n.length} source${n.length > 1 ? "s" : ""} to label`), te(() => t.isLicensed());
      } catch (f) {
        console.error("Failed to move sources to label:", f), k.error("Some sources failed to move to label");
      }
    }), [
      b,
      t,
      a,
      n,
      r
    ]), w = s.useCallback(async (g) => {
      try {
        await t.deleteNotebookLabels(a, [
          g.id
        ]) !== false && (k.success("Label deleted"), te(() => t.isLicensed()));
      } catch (f) {
        throw console.error("Failed to delete label:", f), k.error("Failed to delete label"), f;
      }
    }, [
      t,
      a
    ]), C = s.useCallback(async ({ name: g }, f) => {
      try {
        if (f) {
          if (await t.renameNotebookLabel(a, f, g) === null)
            return k.warning("A label with that name already exists"), false;
        } else {
          const v = await t.createNotebookLabel(a, g);
          if (!v || v.error)
            return false;
          if (v.isNew)
            k.success("Label created"), te(() => t.isLicensed());
          else
            return k.warning("Label already exists"), false;
        }
      } catch (v) {
        return console.error("Failed to save label:", v), k.error("Failed to save label"), false;
      }
    }, [
      t,
      a
    ]), S = s.useCallback(async () => {
      const g = n.map((f) => l == null ? void 0 : l.find((v) => v.id === f)).filter(Boolean);
      if (g.length === 0) {
        k.error("No sources selected");
        return;
      }
      u(true), x(null);
      try {
        const { blob: f, sourceCount: v } = await t.downloadSelectedSourcesAsZip(a, g, (j) => x(j)), D = Xa(i || "notebook"), O = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        We(f, `${D}-${v}-sources-${O}.zip`), k.success(`Downloaded ${v} source${v > 1 ? "s" : ""} as ZIP`), te(() => t.isLicensed());
      } catch (f) {
        console.error("Failed to download sources:", f), k.error("Failed to download sources");
      } finally {
        u(false), x(null);
      }
    }, [
      n,
      l,
      t,
      a,
      i
    ]);
    return {
      isMoving: m,
      isDownloading: c,
      downloadProgress: h,
      handleMoveToFolder: p,
      confirmDeleteFolder: w,
      handleFolderSubmit: C,
      handleBulkDownload: S
    };
  }
  const ut = "__untagged__", Pt = {};
  function qs({ notebook: t, sources: a, isLoading: n, setIsLoading: r, globalActions: l, notebookId: i, onAddSource: d, onTabChange: o, readOnly: c = false }) {
    const [u] = Fe(), [h, x] = s.useState({}), [m, y] = s.useState(null), [b, p] = s.useState(""), [w, C] = s.useState(false), [S, g] = s.useState(false), [f, v] = s.useState(false), [D, O] = s.useState([]), j = s.useRef(false);
    s.useEffect(() => {
      x({}), y(null), p(""), O([]), C(false), j.current = false;
    }, [
      i
    ]), s.useEffect(() => {
      x({});
    }, [
      m,
      b,
      D
    ]);
    const { sourceFreshness: N, isCheckingFreshness: E, isRefreshingAll: T, staleCount: M, isCachedResult: F, lastCheckTime: H, handleRefreshSource: $, handleRefreshAllStale: A, forceCheck: J } = aa({
      notebook: t,
      sources: a,
      globalActions: l
    }), de = s.useRef(N);
    s.useEffect(() => {
      de.current = N;
    }, [
      N
    ]);
    const X = u.notebookLabels, ie = l.isNotebookLMAuthenticated(), Y = !!X.requestedMap[i], ee = !!X.loadingMap[i], Q = (a == null ? void 0 : a.length) || 0, le = Q > 0, W = Q >= Ce;
    s.useEffect(() => {
      !ie || !W || Y || ee || j.current || (j.current = true, l.fetchLabels(i).catch((L) => {
        console.error("Auto-load labels failed:", L), C(true), j.current = false;
      }));
    }, [
      ie,
      W,
      Y,
      ee,
      i,
      l
    ]);
    const fe = X.foldersMap[i] || Pt, ae = X.sourceFolderMapMap[i] || Pt, se = s.useMemo(() => Object.values(fe).sort((L, B) => L.name.localeCompare(B.name)), [
      fe
    ]), ce = s.useMemo(() => {
      const L = {};
      for (const B of Object.values(ae))
        for (const q of Array.isArray(B) ? B : [])
          L[q] = (L[q] || 0) + 1;
      return L;
    }, [
      ae
    ]), P = s.useMemo(() => a.filter((L) => {
      var _a2;
      return !(((_a2 = ae[L.id]) == null ? void 0 : _a2.length) > 0);
    }).length, [
      a,
      ae
    ]), U = s.useMemo(() => [
      ...new Set(a.map((B) => B.sourceType))
    ].sort(), [
      a
    ]), V = s.useMemo(() => {
      const L = {};
      for (const B of a)
        L[B.sourceType] = (L[B.sourceType] || 0) + 1;
      return L;
    }, [
      a
    ]), re = s.useMemo(() => {
      let L = a;
      if (m !== null && (L = L.filter((B) => B.sourceType === m)), D.length > 0) {
        const B = D.includes(ut), q = D.filter((Ke) => Ke !== ut);
        L = L.filter((Ke) => {
          const Ie = ae[Ke.id], Dt = Array.isArray(Ie) && Ie.length > 0;
          return B && !Dt ? true : Dt && q.some((va) => Ie.includes(va));
        });
      }
      if (b.trim()) {
        const B = b.toLowerCase();
        L = L.filter((q) => {
          var _a2;
          return (_a2 = q.title) == null ? void 0 : _a2.toLowerCase().includes(B);
        });
      }
      return L;
    }, [
      a,
      m,
      D,
      b,
      ae
    ]), Z = s.useMemo(() => Object.keys(h).filter((L) => h[L]), [
      h
    ]), { isMoving: G, handleMoveToFolder: ne, confirmDeleteFolder: ue, handleFolderSubmit: xe, handleBulkDownload: we, isDownloading: me, downloadProgress: Ae } = Zs({
      globalActions: l,
      notebookId: i,
      selectedSourceIds: Z,
      setSelectedRows: x,
      sources: a,
      notebookTitle: t == null ? void 0 : t.title
    }), _e = ua({
      globalActions: l,
      notebookId: i,
      notebook: t,
      sources: a,
      selectedRows: h,
      selectedSourceIds: Z,
      setSelectedRows: x,
      setIsLoading: r
    }), { handleViewContent: be, handleBulkDelete: qe, handleDelete: Oe, handleRename: Pe, handleBulkRename: Qe, handleEditFolder: ve, handleDeleteFolder: R, openCreateFolder: _, openCreateFolderFromMenu: ye, openMergeDialog: Ye } = _e, lt = s.useCallback(() => x({}), []), [nt, I] = s.useState(false), K = s.useCallback(() => I(true), []), ot = s.useCallback(() => I(false), []), pa = s.useCallback(() => {
      I(false), x({});
    }, []), vt = s.useMemo(() => new Map((a || []).map((L) => [
      L.id,
      L
    ])), [
      a
    ]), ya = s.useMemo(() => Z.map((L) => vt.get(L)).filter(Boolean), [
      Z,
      vt
    ]), Nt = s.useCallback(async (L, B) => {
      try {
        await l.moveSourceToNotebookLabel(i, L, B);
      } catch (q) {
        console.error("Failed to add label:", q), k.error("Failed to add label");
      }
    }, [
      l,
      i
    ]), Ct = s.useCallback(async (L, B) => {
      try {
        const q = await l.createNotebookLabel(i, B);
        (q == null ? void 0 : q.folder) && await l.moveSourceToNotebookLabel(i, L, q.folder.id);
      } catch (q) {
        console.error("Failed to create label:", q), k.error("Failed to create label");
      }
    }, [
      l,
      i
    ]), St = s.useCallback(async (L, B) => {
      try {
        await l.removeSourceFromNotebookLabel(i, L, B);
      } catch (q) {
        console.error("Failed to remove label:", q), k.error("Failed to remove label");
      }
    }, [
      l,
      i
    ]), Ft = s.useCallback((L) => e.jsx(Os, {
      labelIds: ae[L] || [],
      labelsById: fe,
      onAdd: (B) => Nt(L, B),
      onCreate: (B) => Ct(L, B),
      onRemove: (B) => St(L, B),
      canRemove: true,
      readOnly: c
    }), [
      ae,
      fe,
      Nt,
      Ct,
      St,
      c
    ]), ka = s.useMemo(() => sa({
      sourceFreshness: de.current,
      handleRefreshSource: $,
      handleViewContent: be,
      handleRename: Pe,
      handleDelete: Oe,
      readOnly: c,
      renderSourceLabels: Ft
    }), [
      $,
      be,
      Pe,
      Oe,
      c,
      Ft
    ]), Rt = s.useCallback(async () => {
      C(false);
      try {
        await l.fetchLabels(i);
      } catch (L) {
        console.error("Failed to load labels:", L), k.error("Failed to load labels from NotebookLM");
      }
    }, [
      l,
      i
    ]), Be = s.useCallback(async (L, B, q, Ke = false) => {
      v(true);
      try {
        await L(), k.success(B);
      } catch (Ie) {
        if (console.error(q, Ie), k.error(q), Ke)
          throw Ie;
      } finally {
        v(false);
      }
    }, []), Lt = s.useCallback(() => Be(() => l.loadLabels(i), "Sources auto-labeled", "Failed to auto-label sources"), [
      Be,
      l,
      i
    ]), ja = s.useCallback(() => Be(() => l.organizeUnlabeledNotebookLabels(i), "Labeled remaining sources", "Failed to label remaining sources"), [
      Be,
      l,
      i
    ]), wa = s.useCallback(() => Be(() => l.reorganizeNotebookLabels(i), "Labels regenerated", "Failed to regenerate labels", true), [
      Be,
      l,
      i
    ]);
    return ie ? Y ? e.jsxs(e.Fragment, {
      children: [
        (E || M > 0 || F) && e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            E && e.jsxs("span", {
              className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400",
              children: [
                e.jsx(oe, {
                  className: "w-3 h-3 animate-spin"
                }),
                "Checking updates..."
              ]
            }),
            M > 0 && e.jsxs("button", {
              onClick: A,
              disabled: T,
              className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-white bg-amber-600 rounded-md hover:bg-amber-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(oe, {
                  className: `w-3.5 h-3.5 ${T ? "animate-spin" : ""}`
                }),
                "Refresh ",
                M,
                " Source",
                M > 1 ? "s" : ""
              ]
            }),
            F && !E && e.jsxs("div", {
              className: "flex items-center gap-1.5",
              children: [
                H && e.jsxs("span", {
                  className: "text-xs text-gray-500 dark:text-slate-400",
                  children: [
                    "Checked",
                    " ",
                    new Date(H).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: J,
                  className: "flex items-center gap-1 text-xs text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200",
                  children: [
                    e.jsx(oe, {
                      className: "w-3 h-3"
                    }),
                    "Re-check"
                  ]
                })
              ]
            })
          ]
        }),
        !c && W && se.length === 0 && !ee && e.jsxs("div", {
          className: "flex items-center justify-between gap-2 px-3 py-2 rounded-md bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800",
          children: [
            e.jsxs("span", {
              className: "flex items-center gap-1.5 text-xs text-indigo-700 dark:text-indigo-300",
              children: [
                e.jsx(Se, {
                  className: "w-3.5 h-3.5 shrink-0",
                  "aria-hidden": "true"
                }),
                "Let AI auto-label these sources"
              ]
            }),
            e.jsxs("button", {
              onClick: Lt,
              disabled: f,
              className: "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30 shrink-0",
              children: [
                e.jsx(Se, {
                  className: "w-3.5 h-3.5",
                  "aria-hidden": "true"
                }),
                "Auto-label"
              ]
            })
          ]
        }),
        le && e.jsx(Hs, {
          filteredCount: re.length,
          totalCount: a.length,
          labelCount: se.length,
          searchQuery: b,
          setSearchQuery: p,
          onRefresh: Rt,
          isRefreshing: ee,
          labels: se,
          counts: ce,
          onCreateLabel: _,
          onRenameLabel: ve,
          onDeleteLabel: R,
          onGenerateFirst: Lt,
          onAutoLabelUnlabeled: ja,
          onRegenerateAll: () => g(true),
          hasLabels: se.length > 0,
          isBusy: f,
          readOnly: c
        }),
        le && e.jsx(oa, {
          hideSearch: true,
          uniqueTypes: U,
          typeCounts: V,
          typeFilter: m,
          setTypeFilter: y
        }),
        le && se.length > 0 && e.jsx(Is, {
          labels: se,
          counts: ce,
          selectedIds: D,
          onToggle: (L) => O((B) => B.includes(L) ? B.filter((q) => q !== L) : [
            ...B,
            L
          ]),
          onClear: () => O([]),
          untaggedId: ut,
          untaggedCount: P
        }),
        e.jsx(na, {
          selectedCount: Z.length,
          folders: se,
          sourceCounts: ce,
          isLoading: n || G,
          onMoveToFolder: ne,
          onCreateNewFolder: ye,
          onBulkRename: Qe,
          onMerge: Ye,
          onDownload: we,
          isDownloading: me,
          downloadProgress: Ae,
          onCopyToNotebook: K,
          onGenerate: () => {
            l.setSelectedSourceIds(Z), o == null ? void 0 : o("artifacts");
          },
          onCancel: lt,
          onBulkDelete: qe,
          readOnly: c,
          moveMenuNoun: "label",
          showRemoveFromFolder: false,
          moveMenuAddMode: true
        }),
        n || f ? e.jsx("div", {
          className: "flex flex-col items-center justify-center w-full py-12 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
          children: e.jsx(Le, {
            text: f ? "Auto-labeling sources\u2026 this can take a moment" : "Loading labels..."
          })
        }) : (re == null ? void 0 : re.length) > 0 ? e.jsx(ta, {
          columns: ka,
          data: re,
          enableRowSelection: true,
          onRowSelectionChange: x,
          rowSelection: h,
          enableGrouping: false
        }) : le ? e.jsxs("div", {
          className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
          children: [
            e.jsx("div", {
              className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
              children: e.jsx(ke, {
                className: "h-6 w-6 text-gray-400 dark:text-slate-500"
              })
            }),
            e.jsx("h3", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100",
              children: "No matching sources"
            }),
            e.jsx("p", {
              className: "mt-1 mb-4 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center",
              children: "Try adjusting your filters or search query."
            }),
            e.jsxs("button", {
              onClick: () => {
                y(null), p(""), O([]);
              },
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-700 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(ge, {
                  className: "w-3.5 h-3.5"
                }),
                "Clear filters"
              ]
            })
          ]
        }) : e.jsxs("div", {
          className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
          children: [
            e.jsx("div", {
              className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
              children: e.jsx(ke, {
                className: "h-6 w-6 text-gray-400 dark:text-slate-500"
              })
            }),
            e.jsx("h3", {
              className: "text-xs font-medium text-gray-900 dark:text-slate-100",
              children: "No sources yet"
            }),
            e.jsx("p", {
              className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center mb-4",
              children: "Add content to your notebook to start organizing your knowledge."
            }),
            e.jsxs("button", {
              onClick: d,
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(De, {
                  className: "w-3.5 h-3.5"
                }),
                "Add Source"
              ]
            })
          ]
        }),
        e.jsx($s, {
          dialogs: _e,
          notebook: t,
          sources: a,
          selectedRows: h,
          setSelectedRows: x,
          setIsLoading: r,
          globalActions: l,
          notebookId: i,
          selectedSourceIds: Z,
          handleFolderSubmit: xe,
          confirmDeleteFolder: ue,
          folderSourceCounts: ce
        }),
        e.jsx(ca, {
          isOpen: nt,
          onClose: ot,
          sourceNotebookId: i,
          selectedSources: ya,
          onSuccess: pa
        }),
        e.jsx(As, {
          isOpen: S,
          onClose: () => g(false),
          onConfirm: wa
        })
      ]
    }) : W && !w ? e.jsx("div", {
      className: "flex flex-col items-center justify-center w-full py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
      children: e.jsx(Le, {
        text: "Loading labels..."
      })
    }) : e.jsxs("div", {
      className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
      children: [
        e.jsx("div", {
          className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
          children: e.jsx(je, {
            className: "h-6 w-6 text-gray-400 dark:text-slate-500"
          })
        }),
        e.jsx("h3", {
          className: "text-xs font-medium text-gray-900 dark:text-slate-100",
          children: "Labels"
        }),
        w ? e.jsxs(e.Fragment, {
          children: [
            e.jsx("p", {
              className: "mt-1 mb-4 text-xs text-gray-500 dark:text-slate-400 max-w-[300px] text-center",
              children: "Couldn\u2019t load this notebook\u2019s labels. Please try again."
            }),
            e.jsxs("button", {
              onClick: Rt,
              className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-gray-900 dark:bg-gray-100 dark:text-gray-900 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
              children: [
                e.jsx(oe, {
                  className: "w-3.5 h-3.5"
                }),
                "Retry"
              ]
            })
          ]
        }) : e.jsxs("p", {
          className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[300px] text-center",
          children: [
            "Labels are available once this notebook has ",
            Ce,
            "+ sources",
            Q > 0 ? ` (${Q}/${Ce})` : "",
            "."
          ]
        })
      ]
    }) : e.jsxs("div", {
      className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
      children: [
        e.jsx("div", {
          className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
          children: e.jsx(je, {
            className: "h-6 w-6 text-gray-400 dark:text-slate-500"
          })
        }),
        e.jsx("h3", {
          className: "text-xs font-medium text-gray-900 dark:text-slate-100",
          children: "Sign in to NotebookLM"
        }),
        e.jsx("p", {
          className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[280px] text-center",
          children: "Labels live on your notebook in NotebookLM. Connect your account to view and manage them."
        })
      ]
    });
  }
  const Bt = "inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium", It = "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900", zt = "text-gray-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700";
  function Qs({ mode: t = "folders", onChange: a, labelsDisabled: n = false, disabledReason: r }) {
    return e.jsxs("div", {
      role: "tablist",
      "aria-label": "Source grouping view",
      className: "inline-flex items-center gap-0.5 rounded-md border border-gray-300 dark:border-slate-600 p-0.5 bg-white dark:bg-slate-800",
      children: [
        e.jsxs("button", {
          type: "button",
          role: "tab",
          "aria-selected": t === "folders",
          onClick: () => a("folders"),
          title: "Folders \u2014 local & private, saved only in this extension",
          className: Re(Bt, t === "folders" ? It : zt),
          children: [
            e.jsx(xt, {
              className: "w-3.5 h-3.5",
              "aria-hidden": "true"
            }),
            "Folders"
          ]
        }),
        e.jsxs("button", {
          type: "button",
          role: "tab",
          "aria-selected": t === "labels",
          disabled: n,
          onClick: () => a("labels"),
          title: n ? r : "Labels \u2014 native NotebookLM, synced and visible to people you share with",
          className: Re(Bt, t === "labels" ? It : zt, n && "opacity-50 cursor-not-allowed"),
          children: [
            e.jsx(je, {
              className: "w-3.5 h-3.5",
              "aria-hidden": "true"
            }),
            "Labels"
          ]
        })
      ]
    });
  }
  const Ys = s.memo(Qs);
  function Ks({ mode: t = "folders", labelsDisabled: a = false, sourceCount: n = 0 }) {
    const r = a ? "requirement" : t === "labels" ? "synced" : "private", [l, i] = s.useState(false);
    s.useEffect(() => {
      Mt.get(Tt).then((o) => {
        o !== true && i(true);
      }).catch(() => {
      });
    }, []);
    const d = () => {
      i(false), Mt.set(Tt, true).catch(() => {
      });
    };
    return e.jsxs(e.Fragment, {
      children: [
        e.jsxs("div", {
          className: Re("flex items-center gap-1 text-[11px]", r === "synced" ? "text-sky-600 dark:text-sky-400" : "text-gray-500 dark:text-slate-400"),
          children: [
            r === "private" ? e.jsx(xt, {
              className: "w-3.5 h-3.5 shrink-0",
              "aria-hidden": "true"
            }) : e.jsx(je, {
              className: Re("w-3.5 h-3.5 shrink-0", r === "requirement" && "opacity-70"),
              "aria-hidden": "true"
            }),
            e.jsx("span", {
              children: r === "requirement" ? ma(n) : r === "synced" ? "Synced \u2014 people you share the notebook with can see them" : "Private to this extension \u2014 only on this device"
            }),
            e.jsx("button", {
              type: "button",
              onClick: () => i((o) => !o),
              "aria-label": "What's the difference between Folders and Labels?",
              title: "Folders vs Labels",
              className: "shrink-0 p-0.5 rounded text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700",
              children: e.jsx(Ma, {
                className: "w-3.5 h-3.5",
                "aria-hidden": "true"
              })
            })
          ]
        }),
        l && e.jsxs("div", {
          className: "w-full mt-1 rounded-md border border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800/60 p-2 text-[11px] text-gray-600 dark:text-slate-300",
          children: [
            e.jsxs("div", {
              className: "flex items-center justify-between mb-1.5",
              children: [
                e.jsx("span", {
                  className: "font-medium text-gray-700 dark:text-slate-200",
                  children: "Two ways to organize sources"
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: d,
                  "aria-label": "Dismiss",
                  className: "p-0.5 rounded text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 hover:bg-gray-200/60 dark:hover:bg-slate-700",
                  children: e.jsx(ge, {
                    className: "w-3.5 h-3.5",
                    "aria-hidden": "true"
                  })
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-start gap-1.5 mb-1.5",
              children: [
                e.jsx(xt, {
                  className: "w-3.5 h-3.5 mt-px shrink-0 text-gray-500 dark:text-slate-400",
                  "aria-hidden": "true"
                }),
                e.jsxs("span", {
                  children: [
                    e.jsx("span", {
                      className: "font-medium text-gray-700 dark:text-slate-200",
                      children: "Folders"
                    }),
                    " \u2014 This extension\u2019s own feature. Private to you: one folder per source, kept only here."
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-start gap-1.5",
              children: [
                e.jsx(je, {
                  className: "w-3.5 h-3.5 mt-px shrink-0 text-gray-500 dark:text-slate-400",
                  "aria-hidden": "true"
                }),
                e.jsxs("span", {
                  children: [
                    e.jsx("span", {
                      className: "font-medium text-gray-700 dark:text-slate-200",
                      children: "Labels"
                    }),
                    " \u2014 NotebookLM\u2019s own feature (not added by this extension). Its AI auto-groups your sources \u2014 each source can have multiple labels \u2014 synced everywhere and shared with people you invite to the notebook."
                  ]
                })
              ]
            }),
            r === "requirement" && e.jsxs("div", {
              className: "mt-1 pl-5 text-gray-500 dark:text-slate-400",
              children: [
                "Turns on once the notebook has ",
                Ce,
                "+ sources (",
                n,
                "/",
                Ce,
                ")."
              ]
            })
          ]
        })
      ]
    });
  }
  const Js = s.memo(Ks);
  function Ws({ uniqueTypes: t, typeCounts: a, typeFilter: n, setTypeFilter: r, searchQuery: l, setSearchQuery: i, selectedCount: d, onCancelSelection: o, onBulkDelete: c, onBulkRename: u, onBulkExport: h, onExportFiltered: x, onToggleGenerate: m, isDeleting: y, isRenaming: b, isExporting: p, isGenerating: w, filteredCount: C, readOnly: S = false, sourceFilterSlot: g = null, onExportMap: f, isExportingMap: v = false }) {
    const D = S ? Ne : void 0, O = a ? Object.values(a).reduce((j, N) => j + N, 0) : 0;
    return e.jsxs("div", {
      className: "flex flex-col gap-2",
      children: [
        t.length > 1 && e.jsxs("div", {
          className: "flex items-center gap-1.5 flex-wrap",
          children: [
            e.jsxs("button", {
              onClick: () => r(null),
              className: `px-2 py-1 rounded-full text-xs font-medium ${n === null ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : "bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-300 hover:bg-gray-200 dark:hover:bg-slate-600"}`,
              children: [
                "All",
                a ? ` (${O})` : ""
              ]
            }),
            t.map((j) => {
              const N = bt[j] || "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300", E = n === j, T = ft[j], M = (a == null ? void 0 : a[j]) ?? 0, F = M === 0 && !E;
              return e.jsxs("button", {
                onClick: () => {
                  F || r(E ? null : j);
                },
                disabled: F,
                className: `inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${E ? "bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" : N} ${F ? "opacity-40 cursor-not-allowed" : ""}`,
                title: F ? `No ${at[j] || ""} under current filter` : void 0,
                children: [
                  T && e.jsx(T, {
                    className: "w-3 h-3"
                  }),
                  at[j] || "Unknown",
                  (a == null ? void 0 : a[j]) != null ? ` (${M})` : ""
                ]
              }, j);
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex items-center gap-2",
          children: [
            e.jsx("div", {
              className: "flex items-center gap-2 flex-1 min-w-0",
              children: m && e.jsxs("button", {
                onClick: m,
                disabled: w || S,
                title: D,
                className: "flex-shrink-0 inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 shadow-sm dark:shadow-slate-900/30 rounded-md disabled:opacity-50 disabled:cursor-not-allowed",
                children: [
                  e.jsx(Se, {
                    className: "w-3.5 h-3.5"
                  }),
                  "Generate"
                ]
              })
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2 flex-shrink-0",
              children: [
                C > 0 && e.jsxs("button", {
                  onClick: x,
                  disabled: p || y,
                  className: "flex-shrink-0 inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-gray-600 dark:text-slate-300 hover:text-gray-800 dark:hover:text-slate-100 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-md disabled:opacity-50",
                  title: "Download all as ZIP",
                  children: [
                    e.jsx(mt, {
                      className: "w-3.5 h-3.5"
                    }),
                    "ZIP"
                  ]
                }),
                C > 0 && f && e.jsxs("button", {
                  onClick: f,
                  disabled: v || y,
                  className: "flex-shrink-0 inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-gray-600 dark:text-slate-300 hover:text-gray-800 dark:hover:text-slate-100 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-md disabled:opacity-50",
                  title: "Export sources \u2194 artifacts as CSV (current filter)",
                  children: [
                    e.jsx(Ra, {
                      className: "w-3.5 h-3.5"
                    }),
                    "Map"
                  ]
                }),
                g,
                e.jsxs("div", {
                  className: "relative flex-shrink-0 w-36",
                  children: [
                    e.jsx(Ue, {
                      className: "absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400 dark:text-slate-500 pointer-events-none"
                    }),
                    e.jsx("input", {
                      type: "text",
                      placeholder: "Search...",
                      value: l,
                      onChange: (j) => i(j.target.value),
                      className: "w-full pl-7 pr-2 py-1.5 text-xs border border-gray-300 dark:border-gray-600 rounded-md focus:ring-1 focus:ring-gray-900 dark:focus:ring-gray-100 focus:border-gray-900 dark:focus:border-gray-100 bg-white dark:bg-slate-800 dark:text-slate-100"
                    })
                  ]
                })
              ]
            })
          ]
        }),
        d > 0 && e.jsxs("div", {
          className: "flex items-center justify-between bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg p-2 px-3 shadow-sm dark:shadow-slate-900/30",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("div", {
                  className: "flex items-center justify-center w-5 h-5 rounded-full bg-gray-200 dark:bg-slate-700",
                  children: e.jsx("span", {
                    className: "text-xs font-medium text-gray-700 dark:text-slate-300",
                    children: d
                  })
                }),
                e.jsx("span", {
                  className: "text-xs text-gray-600 dark:text-slate-400",
                  children: "selected"
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("button", {
                  onClick: o,
                  className: "px-2.5 py-1 text-xs font-medium text-gray-600 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 shadow-sm dark:shadow-slate-900/30",
                  children: "Cancel"
                }),
                e.jsxs("button", {
                  onClick: u,
                  disabled: y || b || S,
                  title: D,
                  className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm dark:shadow-slate-900/30",
                  children: [
                    e.jsx(Ze, {
                      className: "w-3.5 h-3.5"
                    }),
                    "Rename"
                  ]
                }),
                e.jsxs("button", {
                  onClick: h,
                  disabled: p || y,
                  className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                  children: [
                    e.jsx(mt, {
                      className: "w-3.5 h-3.5"
                    }),
                    "Download"
                  ]
                }),
                e.jsxs("button", {
                  onClick: c,
                  disabled: y || S,
                  title: D,
                  className: "px-2.5 py-1 flex items-center gap-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm dark:shadow-slate-900/30",
                  children: [
                    e.jsx(Ee, {
                      className: "w-3.5 h-3.5"
                    }),
                    "Remove (",
                    d,
                    ")"
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  }
  function Xs({ sources: t, selectedIds: a, onChange: n, includeOrphans: r, onToggleOrphans: l, hasOrphanArtifacts: i }) {
    const [d, o] = s.useState(""), c = s.useMemo(() => {
      const y = d.trim().toLowerCase();
      return y ? t.filter((b) => (b.title || "").toLowerCase().includes(y)) : t;
    }, [
      t,
      d
    ]), u = a.size + (r ? 1 : 0), h = u > 0, x = (y) => {
      const b = new Set(a);
      b.has(y) ? b.delete(y) : b.add(y), n(b);
    }, m = () => {
      n(/* @__PURE__ */ new Set()), r && l(false);
    };
    return e.jsxs(Me, {
      className: "relative flex-shrink-0",
      children: [
        e.jsxs(Te, {
          className: `inline-flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-medium border ${h ? "bg-blue-50 dark:bg-blue-950 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300" : "bg-white dark:bg-slate-800 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-700"}`,
          title: "Filter artifacts by source",
          children: [
            e.jsx("span", {
              children: "Source"
            }),
            h && e.jsx("span", {
              className: "inline-flex items-center justify-center min-w-[1rem] h-4 px-1 rounded-full bg-blue-600 text-white text-[10px] font-medium",
              children: u
            }),
            e.jsx(Xe, {
              className: "w-3 h-3"
            })
          ]
        }),
        e.jsxs($e, {
          anchor: "bottom end",
          className: "z-20 w-64 max-h-80 overflow-hidden rounded-md border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-lg flex flex-col focus:outline-none",
          children: [
            e.jsx("div", {
              className: "p-2 border-b border-gray-200 dark:border-slate-700",
              children: e.jsxs("div", {
                className: "relative",
                children: [
                  e.jsx(Ue, {
                    className: "absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-gray-400"
                  }),
                  e.jsx("input", {
                    type: "text",
                    placeholder: "Search sources...",
                    value: d,
                    onChange: (y) => o(y.target.value),
                    className: "w-full pl-6 pr-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-slate-900 dark:text-slate-100"
                  })
                ]
              })
            }),
            e.jsxs("div", {
              className: "flex-1 overflow-y-auto py-1",
              children: [
                c.length === 0 && e.jsx("div", {
                  className: "px-2 py-3 text-center text-xs text-gray-500 dark:text-slate-400",
                  children: "No sources match"
                }),
                c.map((y) => e.jsxs("label", {
                  className: "flex items-start gap-2 px-2 py-1.5 hover:bg-gray-50 dark:hover:bg-slate-700 cursor-pointer",
                  children: [
                    e.jsx("input", {
                      type: "checkbox",
                      checked: a.has(y.id),
                      onChange: () => x(y.id),
                      className: "mt-0.5 h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600"
                    }),
                    e.jsxs("div", {
                      className: "flex-1 min-w-0",
                      children: [
                        e.jsx("p", {
                          className: "text-xs text-gray-900 dark:text-slate-100 line-clamp-2 leading-tight",
                          title: y.title,
                          children: y.title || "Untitled"
                        }),
                        e.jsx("div", {
                          className: "mt-0.5",
                          children: e.jsx(yt, {
                            sourceType: y.sourceType
                          })
                        })
                      ]
                    })
                  ]
                }, y.id))
              ]
            }),
            i && e.jsxs("label", {
              className: "flex items-center gap-2 px-2 py-1.5 border-t border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 cursor-pointer",
              children: [
                e.jsx("input", {
                  type: "checkbox",
                  checked: r,
                  onChange: (y) => l(y.target.checked),
                  className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600"
                }),
                e.jsx(Ee, {
                  className: "w-3 h-3 text-amber-600 dark:text-amber-400"
                }),
                e.jsx("span", {
                  className: "text-xs text-amber-700 dark:text-amber-300",
                  children: "Has deleted/orphaned sources"
                })
              ]
            }),
            h && e.jsxs("button", {
              type: "button",
              onClick: m,
              className: "flex items-center justify-center gap-1 px-2 py-1.5 border-t border-gray-200 dark:border-slate-700 text-xs text-gray-600 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-700",
              children: [
                e.jsx(ge, {
                  className: "w-3 h-3"
                }),
                "Clear filter"
              ]
            })
          ]
        })
      ]
    });
  }
  const Ut = {
    amber: {
      wrap: "bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800",
      text: "text-amber-800 dark:text-amber-200",
      sub: "text-amber-700 dark:text-amber-300",
      track: "bg-amber-200",
      bar: "bg-amber-600"
    },
    blue: {
      wrap: "bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800",
      text: "text-blue-800 dark:text-blue-200",
      sub: "text-blue-700 dark:text-blue-300",
      track: "bg-blue-200",
      bar: "bg-blue-600"
    }
  };
  function gt({ label: t, current: a, total: n, color: r, onCancel: l, className: i }) {
    const d = n > 0 ? Math.round(a / n * 100) : 0, o = Ut[r] || Ut.blue;
    return e.jsxs("div", {
      className: Re("border rounded-lg p-2 px-3", o.wrap, i),
      children: [
        e.jsxs("div", {
          className: "flex items-center justify-between gap-2 mb-1.5",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx(Le, {
                  className: "w-3.5 h-3.5"
                }),
                e.jsxs("span", {
                  className: `text-xs font-medium ${o.text}`,
                  children: [
                    t,
                    " ",
                    a,
                    " of ",
                    n,
                    "..."
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                l && e.jsx("button", {
                  onClick: l,
                  className: `text-xs font-medium ${o.sub} hover:underline`,
                  children: "Cancel"
                }),
                e.jsxs("span", {
                  className: `text-xs font-medium ${o.sub}`,
                  children: [
                    d,
                    "%"
                  ]
                })
              ]
            })
          ]
        }),
        e.jsx("div", {
          className: `w-full rounded-full h-1 ${o.track}`,
          children: e.jsx("div", {
            className: `h-1 rounded-full ${o.bar}`,
            style: {
              width: `${d}%`
            }
          })
        })
      ]
    });
  }
  const er = pe.memo(function({ isGenerating: a, generateError: n, packProgress: r, selectedType: l, onCancel: i, onRetry: d, onDismiss: o = i }) {
    return e.jsxs(e.Fragment, {
      children: [
        n && !a && e.jsxs("div", {
          role: "alert",
          className: "flex items-center justify-between gap-2 px-3 py-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg",
          children: [
            e.jsxs("span", {
              className: "text-xs font-medium text-red-700 dark:text-red-300 line-clamp-2",
              children: [
                "Generation failed: ",
                n
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2 flex-shrink-0",
              children: [
                d && e.jsx("button", {
                  onClick: d,
                  className: "text-xs font-medium text-red-700 dark:text-red-300 hover:underline",
                  children: "Retry"
                }),
                e.jsx("button", {
                  onClick: o,
                  className: "text-xs font-medium text-red-700 dark:text-red-300 hover:underline",
                  children: "Dismiss"
                })
              ]
            })
          ]
        }),
        a && (r ? e.jsx(gt, {
          label: `${r.retrying ? "Retrying " : ""}${st[r.currentType] || "Generating"}`,
          current: r.current,
          total: r.total,
          color: "blue",
          onCancel: i
        }) : e.jsxs("div", {
          className: "flex items-center justify-between gap-2 px-3 py-2 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx(Le, {
                  size: "sm"
                }),
                e.jsxs("span", {
                  className: "text-xs font-medium text-blue-700 dark:text-blue-300",
                  children: [
                    "Generating ",
                    l && st[l] || "",
                    "..."
                  ]
                })
              ]
            }),
            e.jsx("button", {
              onClick: i,
              className: "text-xs font-medium text-blue-700 dark:text-blue-300 hover:underline",
              children: "Cancel"
            })
          ]
        }))
      ]
    });
  });
  function tr({ hasArtifacts: t, onSelectType: a, onOpenGenerate: n, readOnly: r = false }) {
    return e.jsxs("div", {
      className: "flex flex-col items-center justify-center py-16 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
      children: [
        e.jsx("div", {
          className: "p-3 bg-gray-50 dark:bg-slate-900 rounded-full mb-3",
          children: e.jsx(Se, {
            className: "h-6 w-6 text-gray-400 dark:text-slate-500"
          })
        }),
        e.jsx("h3", {
          className: "text-xs font-medium text-gray-900 dark:text-slate-100",
          children: t ? "No matching studio items" : "No studio items yet"
        }),
        e.jsx("p", {
          className: "mt-1 text-xs text-gray-500 dark:text-slate-400 max-w-[250px] text-center",
          children: t ? "Try adjusting your filters or search query." : r ? "No outputs have been generated yet. Only the owner or editors can generate outputs." : "Generate audio, quizzes, reports and more from your sources."
        }),
        !t && !r && e.jsxs(e.Fragment, {
          children: [
            e.jsx("div", {
              className: "flex items-center gap-1.5 mt-3",
              children: [
                z.AUDIO,
                z.QUIZ,
                z.REPORT
              ].map((l) => {
                const i = ft[l];
                return e.jsxs("button", {
                  onClick: () => a(l),
                  className: `flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium border border-current ${bt[l]}`,
                  children: [
                    e.jsx(i, {
                      className: "w-3 h-3"
                    }),
                    st[l]
                  ]
                }, l);
              })
            }),
            e.jsx("button", {
              onClick: n,
              className: "mt-2 text-xs text-blue-600 dark:text-blue-400 hover:underline",
              children: "or generate any type"
            })
          ]
        })
      ]
    });
  }
  const jt = (t) => t && t.replace(/[<>:"/\\|?*]/g, "").replace(/\s+/g, " ").trim().slice(0, 100) || "Untitled", ar = (t) => at[t] || "Other", tt = async (t) => {
    if (!t)
      return null;
    try {
      const a = await fetch(t);
      return a.ok ? await a.arrayBuffer() : null;
    } catch {
      return null;
    }
  }, Vt = (t) => {
    const a = String(t ?? "");
    return a.includes(",") || a.includes('"') || a.includes(`
`) ? `"${a.replace(/"/g, '""')}"` : a;
  }, wt = (t, a) => {
    const n = [
      t.map(Vt).join(",")
    ];
    for (const r of a)
      n.push(r.map(Vt).join(","));
    return n.join(`
`);
  }, Gt = (t) => wt([
    "Front",
    "Back"
  ], t.map((a) => [
    a.f,
    a.b
  ])), sr = async (t, a) => {
    var _a2, _b, _c, _d;
    const { type: n, parsedContent: r, rawContent: l, title: i } = t, d = jt(i);
    switch (n) {
      case z.AUDIO: {
        const o = (r == null ? void 0 : r.downloadUrl) || ((_b = (_a2 = r == null ? void 0 : r.urls) == null ? void 0 : _a2[0]) == null ? void 0 : _b.url), c = await tt(o);
        return c ? {
          filename: d + ".mp3",
          content: c,
          isBinary: true
        } : null;
      }
      case z.REPORT: {
        const o = r == null ? void 0 : r.markdown;
        return o ? {
          filename: d + ".md",
          content: o,
          isBinary: false
        } : null;
      }
      case z.VIDEO: {
        const o = (r == null ? void 0 : r.downloadUrl) || ((_d = (_c = r == null ? void 0 : r.formats) == null ? void 0 : _c[0]) == null ? void 0 : _d.url), c = await tt(o);
        return c ? {
          filename: d + ".mp4",
          content: c,
          isBinary: true
        } : null;
      }
      case z.QUIZ:
      case z.QUIZ_OR_FLASHCARDS:
        return (a == null ? void 0 : a.flashcards) ? {
          filename: d + ".csv",
          content: Gt(a.flashcards),
          isBinary: false
        } : {
          filename: d + ".json",
          content: JSON.stringify(a || {}, null, 2),
          isBinary: false
        };
      case z.FLASHCARDS:
        return (a == null ? void 0 : a.flashcards) ? {
          filename: d + ".csv",
          content: Gt(a.flashcards),
          isBinary: false
        } : {
          filename: d + ".json",
          content: JSON.stringify(a || {}, null, 2),
          isBinary: false
        };
      case z.MIND_MAP: {
        const o = l || (r == null ? void 0 : r.tree) || a;
        if (!o)
          return null;
        const c = typeof o == "string" ? o : JSON.stringify(o, null, 2);
        return {
          filename: d + ".json",
          content: c,
          isBinary: false
        };
      }
      case z.INFOGRAPHIC: {
        const o = await tt(r == null ? void 0 : r.imageUrl);
        return o ? {
          filename: d + ".png",
          content: o,
          isBinary: true
        } : null;
      }
      case z.SLIDE_DECK: {
        const o = (r == null ? void 0 : r.pptxUrl) || (r == null ? void 0 : r.pdfUrl), c = (r == null ? void 0 : r.pptxUrl) ? ".pptx" : ".pdf", u = await tt(o);
        return u ? {
          filename: d + c,
          content: u,
          isBinary: true
        } : null;
      }
      case z.DATA_TABLE: {
        const { headers: o = [], rows: c = [] } = r || {};
        return o.length === 0 && c.length === 0 ? null : {
          filename: d + ".csv",
          content: wt(o, c),
          isBinary: false
        };
      }
      case z.NOTE: {
        const o = (r == null ? void 0 : r.text) || l || "";
        return o ? {
          filename: d + ".md",
          content: o,
          isBinary: false
        } : null;
      }
      default:
        return null;
    }
  }, rr = (t, a, n) => {
    const r = t + "/" + a;
    if (n[r] = (n[r] || 0) + 1, n[r] <= 1)
      return a;
    const l = a.lastIndexOf("."), i = l > 0 ? a.slice(0, l) : a, d = l > 0 ? a.slice(l) : "";
    return `${i} (${n[r]})${d}`;
  }, lr = async (t, a, n, r = []) => {
    const { default: l } = await he(() => import("./chunk-d45ab30c.js").then((m) => m.j), ["assets/chunk-d45ab30c.js","assets/chunk-725317a4.js"]), i = new l();
    for (const m of r)
      (m == null ? void 0 : m.path) && (m == null ? void 0 : m.content) != null && i.file(m.path, m.content);
    const d = t.length;
    let o = 0, c = 0;
    const u = {}, h = 3;
    for (let m = 0; m < t.length; m += h) {
      const y = t.slice(m, m + h), b = await Promise.all(y.map(async (p) => {
        var _a2;
        try {
          let w = null;
          ([
            z.QUIZ,
            z.FLASHCARDS,
            z.QUIZ_OR_FLASHCARDS
          ].includes(p.type) || p.type === z.MIND_MAP && !p.rawContent && !((_a2 = p.parsedContent) == null ? void 0 : _a2.tree)) && a && (w = await a(p.id));
          const S = await sr(p, w);
          return S ? {
            folder: ar(p.type),
            ...S
          } : null;
        } catch {
          return null;
        } finally {
          o++, n == null ? void 0 : n({
            current: o,
            total: d
          });
        }
      }));
      for (const p of b) {
        if (!p)
          continue;
        const w = rr(p.folder, p.filename, u);
        i.file(`${p.folder}/${w}`, p.content), c++;
      }
    }
    return {
      blob: await i.generateAsync({
        type: "blob"
      }),
      count: c,
      failed: d - c
    };
  }, nr = " | ", or = (t) => `(deleted source: ${t})`, ba = (t, a) => {
    if (!a)
      return 0;
    let n = 0;
    for (const r of t || [])
      r && !a.has(r) && n++;
    return n;
  }, dr = (t) => {
    if (!t)
      return "";
    try {
      return new Date(t).toISOString();
    } catch {
      return "";
    }
  }, ir = (t) => t.typeLabel || st[t.type] || "Unknown", cr = (t, a) => {
    const n = [];
    for (const r of t || []) {
      if (!r)
        continue;
      const l = a == null ? void 0 : a.get(r);
      n.push(l || or(r));
    }
    return n.join(nr);
  }, fa = ({ artifacts: t, sourceTitleById: a }) => {
    const n = [
      "artifact_title",
      "artifact_type",
      "artifact_created_at",
      "source_count",
      "deleted_source_count",
      "source_titles"
    ], r = (t || []).map((l) => {
      const i = l.sourceIds || [];
      return [
        l.title || "",
        ir(l),
        dr(l.createdAt),
        String(i.length),
        String(ba(i, a)),
        cr(i, a)
      ];
    });
    return wt(n, r);
  };
  function ur({ fetchQuizFn: t, isLicensed: a }) {
    const [n, r] = s.useState(false), [l, i] = s.useState(null), d = s.useRef(false), o = s.useCallback(async (c, u, h = []) => {
      if (!(!(c == null ? void 0 : c.length) || d.current)) {
        d.current = true, r(true), i({
          current: 0,
          total: c.length
        });
        try {
          const x = await lr(c, t, i, h), m = jt(u) || "notebook";
          We(x.blob, `${m}-studio-${rt()}.zip`), x.failed > 0 ? k.warning(`Exported ${x.count} studio items, ${x.failed} failed`) : (k.success(`Exported ${x.count} studio items as ZIP`), te(() => a == null ? void 0 : a()));
        } catch (x) {
          console.error("Failed to export artifacts:", x), k.error("Failed to export studio items");
        } finally {
          d.current = false, r(false), i(null);
        }
      }
    }, [
      t
    ]);
    return {
      isExporting: n,
      exportProgress: l,
      handleExport: o
    };
  }
  const xr = 15e3;
  function mr(t, a) {
    const [, n] = Fe(), r = a == null ? void 0 : a.some((l) => l.isProcessing);
    s.useEffect(() => {
      if (!t || !r)
        return;
      const l = setInterval(() => {
        n.fetchArtifacts(t);
      }, xr);
      return () => clearInterval(l);
    }, [
      t,
      r
    ]);
  }
  const hr = {
    [z.AUDIO]: "Audio",
    [z.REPORT]: "Report",
    [z.VIDEO]: "Video",
    [z.QUIZ_OR_FLASHCARDS]: "Quiz",
    [z.QUIZ]: "Quiz",
    [z.FLASHCARDS]: "Flash",
    [z.MIND_MAP]: "Mind Map",
    [z.INFOGRAPHIC]: "Infographic",
    [z.SLIDE_DECK]: "Slides",
    [z.DATA_TABLE]: "Table",
    [z.NOTE]: "Note"
  };
  gr = function({ artifactType: t, compact: a }) {
    const n = ft[t] || ke, r = at[t] || "Unknown", l = a && hr[t] || r, i = bt[t] || "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300";
    return e.jsxs("span", {
      className: `inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-xs font-medium ${i}`,
      title: r,
      children: [
        e.jsx(n, {
          className: "h-2.5 w-2.5"
        }),
        e.jsx("span", {
          children: l
        })
      ]
    });
  };
  function br({ sourceIds: t, sourceTitleById: a }) {
    const [n, r] = s.useState(false), l = t || [], i = s.useMemo(() => ba(l, a), [
      l,
      a
    ]);
    if (l.length === 0)
      return null;
    const d = l.length;
    return e.jsxs(e.Fragment, {
      children: [
        e.jsxs("button", {
          type: "button",
          onClick: (o) => {
            o.stopPropagation(), r((c) => !c);
          },
          className: "inline-flex items-center gap-0.5 text-[10px] text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-200",
          title: "Show sources used by this artifact",
          children: [
            n ? e.jsx(Xe, {
              className: "w-2.5 h-2.5"
            }) : e.jsx(La, {
              className: "w-2.5 h-2.5"
            }),
            e.jsxs("span", {
              children: [
                "from ",
                d,
                " source",
                d !== 1 ? "s" : ""
              ]
            }),
            i > 0 && e.jsxs("span", {
              className: "ml-1 text-amber-700 dark:text-amber-300",
              children: [
                "(",
                i,
                " deleted)"
              ]
            })
          ]
        }),
        n && e.jsx("ul", {
          className: "mt-1 ml-3 flex flex-col gap-0.5",
          children: l.map((o, c) => {
            var _a2;
            const u = (_a2 = a == null ? void 0 : a.get) == null ? void 0 : _a2.call(a, o), h = !u;
            return e.jsxs("li", {
              className: h ? "flex items-center gap-1 text-[10px] text-amber-700 dark:text-amber-300 italic" : "flex items-center gap-1 text-[10px] text-gray-600 dark:text-slate-300",
              title: h ? `Deleted source id: ${o}` : u,
              children: [
                h ? e.jsx(Ee, {
                  className: "w-2.5 h-2.5 flex-shrink-0"
                }) : e.jsx("span", {
                  className: "w-1 h-1 rounded-full bg-gray-400 dark:bg-slate-500 flex-shrink-0"
                }),
                e.jsx("span", {
                  className: "line-clamp-1",
                  children: h ? "(deleted source)" : u
                })
              ]
            }, `${o}-${c}`);
          })
        })
      ]
    });
  }
  function fr({ isDeleting: t, handleSingleDelete: a, handleSingleRename: n, setViewingArtifact: r, readOnly: l = false, sourceTitleById: i }) {
    return [
      {
        id: "select",
        header: ({ table: d }) => e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-gray-900 focus:ring-1 cursor-pointer",
          checked: d.getIsAllPageRowsSelected(),
          onChange: d.getToggleAllPageRowsSelectedHandler(),
          disabled: t
        }),
        cell: ({ row: d }) => e.jsx("input", {
          type: "checkbox",
          className: "h-3.5 w-3.5 rounded border-gray-300 dark:border-gray-600 text-gray-900 focus:ring-gray-900 focus:ring-1 cursor-pointer",
          checked: d.getIsSelected(),
          disabled: !d.getCanSelect() || t,
          onChange: d.getToggleSelectedHandler()
        }),
        enableSorting: false,
        enableColumnFilter: false
      },
      {
        id: "title",
        accessorKey: "title",
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-gray-700 dark:text-slate-300",
          children: "Title"
        }),
        cell: (d) => {
          const o = d.row.original;
          return e.jsxs("div", {
            className: "flex items-start gap-2 group/row",
            children: [
              e.jsxs("div", {
                className: "flex-1 min-w-0",
                children: [
                  e.jsx("p", {
                    className: "text-xs font-medium text-gray-900 dark:text-slate-100 line-clamp-2 leading-tight",
                    title: d.getValue(),
                    children: d.getValue()
                  }),
                  e.jsxs("div", {
                    className: "flex items-center gap-2 flex-wrap mt-1",
                    children: [
                      e.jsx(gr, {
                        artifactType: o.type,
                        compact: true
                      }),
                      o.isProcessing && e.jsxs("span", {
                        className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200",
                        children: [
                          e.jsx(oe, {
                            className: "w-2.5 h-2.5 animate-spin"
                          }),
                          "Processing"
                        ]
                      })
                    ]
                  }),
                  e.jsx(br, {
                    sourceIds: o.sourceIds,
                    sourceTitleById: i
                  })
                ]
              }),
              e.jsx("div", {
                className: "flex items-center gap-1 flex-shrink-0",
                children: e.jsx("button", {
                  onClick: async (c) => {
                    c.stopPropagation(), navigator.clipboard.writeText(d.getValue());
                    const { default: u } = await he(() => import("./chunk-20599fbc.js"), []);
                    u({
                      particleCount: 30,
                      spread: 45,
                      origin: {
                        y: 0.6
                      }
                    }), k.success("Title copied");
                  },
                  className: "p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-500 dark:text-slate-400 hover:text-gray-700 dark:hover:text-slate-300",
                  title: "Copy title",
                  children: e.jsx("svg", {
                    className: "w-3.5 h-3.5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: e.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                    })
                  })
                })
              })
            ]
          });
        },
        enableColumnFilter: false
      },
      {
        id: "createdAt",
        accessorFn: (d) => d == null ? void 0 : d.createdAt,
        header: () => e.jsx("span", {
          className: "text-xs font-medium text-gray-700 dark:text-slate-300",
          children: "Created"
        }),
        cell: (d) => {
          const o = d.getValue();
          if (!o)
            return e.jsx("span", {
              className: "text-xs text-gray-400 dark:text-slate-500",
              children: "\u2014"
            });
          const c = new Date(o).toLocaleString(void 0, {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          });
          return e.jsx("span", {
            className: "text-xs text-gray-500 dark:text-slate-400 whitespace-nowrap",
            title: c,
            children: Qa(o)
          });
        },
        enableColumnFilter: false,
        size: 80
      },
      {
        id: "actions",
        header: () => null,
        cell: (d) => e.jsxs("div", {
          className: "flex items-center gap-0.5",
          children: [
            e.jsx("button", {
              className: "p-1.5 rounded-md hover:bg-blue-50 dark:hover:bg-blue-950 text-gray-400 dark:text-slate-500 hover:text-blue-600 dark:hover:text-blue-400",
              onClick: (o) => {
                o.stopPropagation(), r(d.row.original);
              },
              title: "View content",
              children: e.jsx(pt, {
                className: "h-3.5 w-3.5"
              })
            }),
            e.jsx("button", {
              className: "p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-400 dark:text-slate-500 hover:text-gray-700 dark:hover:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-gray-400",
              onClick: (o) => {
                o.stopPropagation(), n(d.row.original);
              },
              disabled: t || l,
              title: l ? Ne : "Rename artifact",
              children: e.jsx(Ze, {
                className: "h-3.5 w-3.5"
              })
            }),
            e.jsx("button", {
              className: "p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-950 text-gray-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-gray-400",
              onClick: (o) => {
                o.stopPropagation(), a(d.row.original);
              },
              disabled: t || l,
              title: l ? Ne : "Delete artifact",
              children: e.jsx(Ee, {
                className: "h-3.5 w-3.5"
              })
            })
          ]
        }),
        enableColumnFilter: false,
        enableSorting: false,
        size: 100
      }
    ];
  }
  const pr = pe.lazy(() => he(() => import("./chunk-cbf1930e.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-cbf1930e.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css"])), yr = pe.lazy(() => he(() => import("./chunk-c4374187.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-c4374187.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-9b02a51a.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-4c77bdf2.js","assets/chunk-95b0b380.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-378f9272.js","assets/chunk-3daa5dc5.js","assets/chunk-b5767d08.js","assets/chunk-bd7b16ee.js","assets/chunk-57988b21.js","assets/chunk-de7ca15a.js","assets/chunk-b81ff817.js","assets/chunk-1302cd21.js","assets/chunk-e153acea.js"])), kr = pe.lazy(() => he(() => import("./chunk-3ab37c65.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-3ab37c65.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-4c77bdf2.js","assets/chunk-95b0b380.js"]));
  function jr({ notebookId: t, sources: a, readOnly: n = false, sourceTitleById: r, onExportSourceArtifactMap: l, isExportingMap: i = false, autoOpenGenerate: d = false, onGenerateOpened: o }) {
    var _a2, _b;
    const [c, u] = Fe(), { artifacts: h, studioGeneration: x } = c, m = h.artifactsMap[t] || [], y = h.loadingMap[t], { isDeleting: b, deleteProgress: p } = h, [w, C] = s.useState({}), [S, g] = s.useState(null), [f, v] = s.useState(""), [D, O] = s.useState(() => /* @__PURE__ */ new Set()), [j, N] = s.useState(false), [E, T] = s.useState(false), [M, F] = s.useState(null), [H, $] = s.useState(false), [A, J] = s.useState(null), de = s.useRef(null), { pendingRenameItems: X, handleRename: ie, handleBulkRename: Y, confirmRename: ee, closeRenameDialog: Q } = Xt({
      renameAction: (R, _) => u.renameArtifactNotebookLM(R, _, t),
      refreshAction: () => u.fetchArtifacts(t),
      setIsLoading: T,
      setSelectedRows: C,
      itemLabel: "artifact"
    }), { isGenerating: le, packProgress: W, generateError: fe } = x, ae = s.useCallback((R) => u.fetchQuizContent(R, t), [
      t,
      u
    ]), { isExporting: se, exportProgress: ce, handleExport: P } = ur({
      fetchQuizFn: ae,
      isLicensed: () => u.isLicensed()
    }), U = s.useMemo(() => {
      var _a3, _b2;
      return ((_b2 = (((_a3 = c.notebooklm) == null ? void 0 : _a3.projects) || []).find((_) => _.id === t)) == null ? void 0 : _b2.title) || "notebook";
    }, [
      (_a2 = c.notebooklm) == null ? void 0 : _a2.projects,
      t
    ]);
    s.useEffect(() => {
      u.fetchArtifacts(t);
    }, [
      t
    ]), mr(t, m), s.useEffect(() => {
      C({}), g(null), v(""), O((R) => R.size === 0 ? R : /* @__PURE__ */ new Set()), N(false);
    }, [
      t
    ]);
    const V = s.useCallback(() => {
      u.clearGenerateError(), $(true);
    }, [
      u
    ]), re = s.useRef(false);
    s.useEffect(() => {
      d && !re.current && !n && (re.current = true, V(), o == null ? void 0 : o());
    }, [
      d,
      n,
      V,
      o
    ]), s.useEffect(() => {
      const R = x.selectedSourceIds;
      if (!(R == null ? void 0 : R.length))
        return;
      const _ = de.current;
      R !== _ && (_ && R.length === _.length && R.every((ye, Ye) => ye === _[Ye]) || (de.current = R, V()));
    }, [
      x.selectedSourceIds,
      V
    ]);
    const Z = s.useMemo(() => {
      const R = /* @__PURE__ */ new Set();
      for (const _ of m)
        R.add(_.type);
      return [
        ...R
      ].sort((_, ye) => _ - ye);
    }, [
      m
    ]), G = s.useCallback((R) => r ? (R.sourceIds || []).some((_) => _ && !r.has(_)) : false, [
      r
    ]), ne = s.useMemo(() => m.some(G), [
      m,
      G
    ]), ue = s.useMemo(() => D.size === 0 && !j ? m : m.filter((R) => {
      const _ = R.sourceIds || [];
      return !!(D.size && _.some((ye) => D.has(ye)) || j && G(R));
    }), [
      m,
      D,
      j,
      G
    ]), xe = s.useMemo(() => {
      const R = f.trim().toLowerCase();
      return R ? ue.filter((_) => {
        var _a3;
        return (_a3 = _.title) == null ? void 0 : _a3.toLowerCase().includes(R);
      }) : ue;
    }, [
      ue,
      f
    ]), we = s.useMemo(() => {
      const R = {};
      for (const _ of xe)
        R[_.type] = (R[_.type] || 0) + 1;
      return R;
    }, [
      xe
    ]), me = s.useMemo(() => S === null ? xe : xe.filter((R) => R.type === S), [
      xe,
      S
    ]), Ae = s.useMemo(() => {
      const R = [];
      if (r)
        for (const _ of D)
          R.push(r.get(_) || `(deleted source: ${_})`);
      return j && R.push("orphaned"), R;
    }, [
      D,
      j,
      r
    ]), _e = s.useCallback(() => {
      O((R) => R.size === 0 ? R : /* @__PURE__ */ new Set()), N(false);
    }, []), be = s.useMemo(() => Object.keys(w).filter((R) => w[R]).map((R) => me.find((_) => _.id === R)).filter(Boolean), [
      w,
      me
    ]), qe = be.length, Oe = s.useCallback(() => {
      be.length !== 0 && J(be);
    }, [
      be
    ]), Pe = s.useCallback(async () => {
      const R = A;
      if (R == null ? void 0 : R.length) {
        J(null);
        try {
          await u.bulkDeleteArtifacts(R, t), C({});
          const _ = R.length;
          k.success(`${_} studio item${_ > 1 ? "s" : ""} deleted`), te(() => u.isLicensed());
        } catch (_) {
          console.error("Failed to delete artifacts:", _), k.error("Failed to delete some studio items");
        }
      }
    }, [
      A,
      t,
      u
    ]), Qe = s.useMemo(() => fr({
      isDeleting: b,
      handleSingleDelete: (R) => J([
        R
      ]),
      handleSingleRename: ie,
      setViewingArtifact: F,
      readOnly: n,
      sourceTitleById: r
    }), [
      b,
      ie,
      F,
      n,
      r
    ]), ve = s.useCallback((R) => P(R, U, [
      {
        path: "source-artifact-map.csv",
        content: fa({
          artifacts: R,
          sourceTitleById: r
        })
      }
    ]), [
      P,
      U,
      r
    ]);
    return y && m.length === 0 ? e.jsx("div", {
      className: "flex flex-col items-center justify-center w-full py-12 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 border-dashed",
      children: e.jsx(Le, {
        text: "Loading studio items..."
      })
    }) : e.jsxs("div", {
      className: "flex flex-col gap-3",
      children: [
        b && p && e.jsx(gt, {
          label: "Deleting",
          current: p.current,
          total: p.total,
          color: "amber"
        }),
        se && ce && e.jsx(gt, {
          label: "Exporting",
          current: ce.current,
          total: ce.total,
          color: "blue"
        }),
        e.jsx(er, {
          isGenerating: le,
          generateError: fe,
          packProgress: W,
          selectedType: x.selectedType,
          onCancel: u.cancelGeneration,
          onRetry: V,
          onDismiss: u.clearGenerateError
        }),
        e.jsx(Ws, {
          uniqueTypes: Z,
          typeCounts: we,
          typeFilter: S,
          setTypeFilter: g,
          searchQuery: f,
          setSearchQuery: v,
          selectedCount: qe,
          onCancelSelection: () => C({}),
          onBulkDelete: Oe,
          onBulkRename: () => Y(be),
          onBulkExport: () => ve(be),
          onExportFiltered: () => ve(me),
          onToggleGenerate: V,
          isDeleting: b,
          isRenaming: E,
          isExporting: se,
          isGenerating: le,
          filteredCount: me.length,
          readOnly: n,
          onExportMap: l ? () => l(me) : void 0,
          isExportingMap: i,
          sourceFilterSlot: a && a.length > 0 ? e.jsx(Xs, {
            sources: a,
            selectedIds: D,
            onChange: O,
            includeOrphans: j,
            onToggleOrphans: N,
            hasOrphanArtifacts: ne
          }) : null
        }),
        Ae.length > 0 && e.jsxs("div", {
          className: "flex items-center justify-between gap-2 px-2 py-1.5 rounded-md bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 text-xs text-blue-800 dark:text-blue-200",
          children: [
            e.jsxs("span", {
              className: "line-clamp-1",
              children: [
                "Showing ",
                me.length,
                " of ",
                m.length,
                " artifact",
                m.length !== 1 ? "s" : "",
                " using:",
                " ",
                e.jsx("span", {
                  className: "font-medium",
                  children: Ae.join(", ")
                })
              ]
            }),
            e.jsxs("button", {
              type: "button",
              onClick: _e,
              className: "inline-flex items-center gap-0.5 text-blue-700 dark:text-blue-300 hover:text-blue-900 dark:hover:text-blue-100",
              children: [
                e.jsx(ge, {
                  className: "w-3 h-3"
                }),
                "Clear"
              ]
            })
          ]
        }),
        me.length > 0 ? e.jsx(Kt, {
          data: me,
          columns: Qe,
          enableRowSelection: !b,
          onRowSelectionChange: C,
          rowSelection: w,
          initialSorting: [
            {
              id: "createdAt",
              desc: true
            }
          ]
        }) : e.jsx(tr, {
          hasArtifacts: m.length > 0,
          onSelectType: (R) => {
            u.setSelectedType(R), V();
          },
          onOpenGenerate: V,
          readOnly: n
        }),
        e.jsxs(s.Suspense, {
          fallback: null,
          children: [
            X && e.jsx(pr, {
              isOpen: true,
              onClose: Q,
              onConfirm: ee,
              items: X,
              itemLabel: "artifact"
            }),
            M && e.jsx(yr, {
              isOpen: true,
              onClose: () => F(null),
              artifact: M,
              notebookId: t
            }),
            H && e.jsx(kr, {
              isOpen: true,
              onClose: () => {
                $(false), u.setSelectedSourceIds(null);
              },
              notebookId: t,
              sources: a
            })
          ]
        }),
        A && e.jsx(es, {
          open: true,
          onClose: () => J(null),
          onConfirm: Pe,
          title: A.length > 1 ? `Delete ${A.length} studio items?` : `Delete "${(_b = A[0]) == null ? void 0 : _b.title}"?`,
          message: "This action cannot be undone.",
          confirmLabel: "Delete"
        })
      ]
    });
  }
  const Ht = [
    "sources",
    "artifacts"
  ], wr = "sources";
  function vr(t) {
    const a = Ht.includes(t), [n, r] = s.useState(a ? t : wr);
    s.useEffect(() => {
      a || chrome.storage.local.get(it, (i) => {
        const d = i[it];
        Ht.includes(d) && r(d);
      });
    }, [
      a
    ]);
    const l = s.useCallback((i) => {
      r(i), chrome.storage.local.set({
        [it]: i
      });
    }, []);
    return [
      n,
      l
    ];
  }
  function Nr({ globalActions: t, notebookId: a, notebook: n, sources: r }) {
    const [l, i] = s.useState(false), [d, o] = s.useState(false), [c, u] = s.useState(false), [h, x] = s.useState({
      current: 0,
      total: 0
    });
    return {
      isOpen: l,
      setIsOpen: i,
      isExporting: d,
      isImporting: c,
      exportProgress: h,
      handleExport: async (b = "json") => {
        var _a2, _b;
        try {
          if (o(true), x({
            current: 0,
            total: r.length
          }), b === "zip") {
            const p = await t.exportNotebookSourcesAsZip(a, (w) => {
              x(w);
            });
            We(p.blob, `${(n == null ? void 0 : n.title) || "notebook"}-backup-${rt()}.zip`), k.success(`Exported ${p.sourceCount} sources as ZIP`), te(() => t.isLicensed());
          } else {
            const p = await t.exportNotebookSources(a, (f) => {
              x(f);
            }), w = t.exportSourceFolders(), C = ((_a2 = w.folders) == null ? void 0 : _a2[a]) ? {
              [a]: w.folders[a]
            } : {}, S = ((_b = w.sourceFolderMap) == null ? void 0 : _b[a]) ? {
              [a]: w.sourceFolderMap[a]
            } : {};
            Object.keys(C).length > 0 && (p.sourceFolders = {
              version: "2.0",
              type: "notebooklm-source-folders",
              folders: C,
              sourceFolderMap: S
            });
            const g = new Blob([
              JSON.stringify(p, null, 2)
            ], {
              type: "application/json"
            });
            We(g, `${(n == null ? void 0 : n.title) || "notebook"}-backup-${rt()}.json`), k.success(`Exported ${p.sources.length} sources`), te(() => t.isLicensed());
          }
          i(false);
        } catch (p) {
          console.error("Export failed:", p), k.error("Failed to export sources");
        } finally {
          o(false), x({
            current: 0,
            total: 0
          });
        }
      },
      handleImport: async (b) => {
        try {
          u(true);
          let p;
          b.type === "zip" ? p = await t.importNotebookSourcesFromZip(a, b.file) : p = await ts({
            globalActions: t,
            notebookId: a,
            sources: b.data.sources,
            sourceFolders: b.data.sourceFolders || null
          }), p.success > 0 ? (await t.fetchNotebookLMProjects(), k.success(`Imported ${p.success} sources${p.failed > 0 ? `, ${p.failed} failed` : ""}`)) : k.error("No sources were imported"), i(false);
        } catch (p) {
          console.error("Import failed:", p), k.error("Failed to import sources");
        } finally {
          u(false);
        }
      }
    };
  }
  function Cr({ notebookId: t, notebook: a }) {
    const [n] = Fe(), [r, l] = s.useState(false), i = n.artifacts.artifactsMap[t] || [], d = (a == null ? void 0 : a.sources) || [], o = s.useMemo(() => {
      const u = /* @__PURE__ */ new Map();
      for (const h of d)
        (h == null ? void 0 : h.id) && u.set(h.id, h.title || "Untitled");
      return u;
    }, [
      d
    ]), c = s.useCallback(async (u) => {
      const h = Array.isArray(u), x = h ? u : i;
      if (!x.length) {
        k.error("No studio artifacts to export");
        return;
      }
      try {
        l(true);
        const m = fa({
          artifacts: x,
          sourceTitleById: o
        }), y = new Blob([
          m
        ], {
          type: "text/csv;charset=utf-8"
        }), b = h && x.length !== i.length ? "-filtered" : "", p = `${jt(a == null ? void 0 : a.title)}-source-artifact-map${b}-${rt()}.csv`;
        We(y, p), k.success(`Exported map for ${x.length} artifact${x.length !== 1 ? "s" : ""}`);
      } catch (m) {
        console.error("Export source-artifact map failed:", m), k.error("Failed to export source-artifact map");
      } finally {
        l(false);
      }
    }, [
      i,
      a == null ? void 0 : a.title,
      o
    ]);
    return {
      isExporting: r,
      handleExportCsv: c,
      sourceTitleById: o,
      artifactCount: i.length
    };
  }
  function Sr({ notebook: t, sources: a, isLoading: n, notebookId: r, activeTab: l, totalArtifacts: i, onTabChange: d, onRefresh: o, onRenameNotebook: c, onAddSource: u, onOpenExportImport: h, onOpenDuplicateScan: x }) {
    var _a2;
    const [m] = Fe(), y = (_a2 = Da(m)) == null ? void 0 : _a2.authuser, b = qt(t), p = b ? void 0 : Ne;
    return e.jsxs(e.Fragment, {
      children: [
        e.jsxs("div", {
          className: "flex items-center justify-between gap-4",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2 min-w-0",
              children: [
                e.jsx(Ta, {
                  to: "/notebooklm",
                  className: "flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-slate-100",
                  title: "Back to Notebooks",
                  children: e.jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    className: "w-5 h-5",
                    children: e.jsx("path", {
                      fillRule: "evenodd",
                      d: "M17 10a.75.75 0 01-.75.75H5.612l4.158 3.96a.75.75 0 11-1.04 1.08l-5.5-5.25a.75.75 0 010-1.08l5.5-5.25a.75.75 0 111.04 1.08L5.612 9.25H16.25A.75.75 0 0117 10z",
                      clipRule: "evenodd"
                    })
                  })
                }),
                e.jsxs("div", {
                  className: "min-w-0",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-1",
                      children: [
                        e.jsxs("h1", {
                          className: "text-sm font-medium text-gray-900 dark:text-slate-100 truncate",
                          children: [
                            t == null ? void 0 : t.emoji,
                            " ",
                            t == null ? void 0 : t.title
                          ]
                        }),
                        e.jsx("button", {
                          onClick: () => c(t),
                          disabled: n || !b,
                          className: "p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-400 dark:text-slate-500 hover:text-gray-700 dark:hover:text-slate-300 disabled:opacity-40 disabled:hover:bg-transparent disabled:cursor-not-allowed flex-shrink-0",
                          title: p || "Rename notebook",
                          children: e.jsx(Ze, {
                            className: "h-3.5 w-3.5"
                          })
                        })
                      ]
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-2 mt-0.5",
                      children: [
                        e.jsx(Ga, {
                          code: t == null ? void 0 : t.permissionCode,
                          size: "sm"
                        }),
                        e.jsxs("span", {
                          className: "text-xs text-gray-500 dark:text-slate-400",
                          children: [
                            a.length,
                            " source",
                            a.length !== 1 ? "s" : ""
                          ]
                        }),
                        e.jsx("span", {
                          className: "text-gray-300 dark:text-slate-600",
                          children: "\u2022"
                        }),
                        e.jsx(Va, {
                          notebookId: r,
                          mode: "compact"
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2 flex-shrink-0",
              children: [
                e.jsxs("a", {
                  href: Za(t.id, y),
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "flex items-center gap-1 px-2 py-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-slate-100 text-xs",
                  title: "Open in NotebookLM",
                  children: [
                    e.jsx($a, {
                      className: "h-3.5 w-3.5"
                    }),
                    e.jsx("span", {
                      children: "NotebookLM"
                    }),
                    e.jsx(Zt, {
                      className: "h-3 w-3"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: o,
                  disabled: n,
                  className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                  children: [
                    e.jsx(oe, {
                      className: "w-3.5 h-3.5"
                    }),
                    e.jsx("span", {
                      className: "hidden sm:inline",
                      children: "Refresh"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: h,
                  disabled: n,
                  className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                  title: "Backup & Restore",
                  children: [
                    e.jsx(rs, {
                      className: "w-3.5 h-3.5"
                    }),
                    e.jsx("span", {
                      className: "hidden sm:inline",
                      children: "Backup/Restore"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: x,
                  disabled: n || a.length < 2,
                  className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-slate-700 disabled:opacity-50 shadow-sm dark:shadow-slate-900/30",
                  title: "Scan for duplicate sources",
                  children: [
                    e.jsx(Ue, {
                      className: "w-3.5 h-3.5"
                    }),
                    e.jsx("span", {
                      className: "hidden sm:inline",
                      children: "Scan Duplicates"
                    })
                  ]
                }),
                e.jsxs("button", {
                  onClick: u,
                  disabled: n || !b,
                  title: p,
                  className: "px-2.5 py-1.5 flex items-center gap-1.5 text-xs font-medium text-white dark:text-gray-900 bg-gray-900 dark:bg-gray-100 rounded-md hover:bg-gray-800 dark:hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm dark:shadow-slate-900/30",
                  children: [
                    e.jsx(De, {
                      className: "w-3.5 h-3.5"
                    }),
                    e.jsx("span", {
                      className: "hidden sm:inline",
                      children: "Add Sources"
                    })
                  ]
                })
              ]
            })
          ]
        }),
        e.jsxs("div", {
          className: "flex p-0.5 bg-neutral-100 dark:bg-slate-700 rounded-md max-w-sm",
          children: [
            e.jsxs("button", {
              onClick: () => d("sources"),
              className: `flex-1 flex items-center justify-center gap-1 px-2 py-1.5 rounded text-xs font-medium ${l === "sources" ? "bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30" : "text-neutral-700 dark:text-slate-300"}`,
              children: [
                e.jsx(ke, {
                  className: "w-3.5 h-3.5"
                }),
                "Sources (",
                a.length,
                ")"
              ]
            }),
            e.jsxs("button", {
              onClick: () => d("artifacts"),
              className: `flex-1 flex items-center justify-center gap-1 px-2 py-1.5 rounded text-xs font-medium ${l === "artifacts" ? "bg-white dark:bg-slate-800 text-neutral-900 dark:text-slate-100 shadow-sm dark:shadow-slate-900/30" : "text-neutral-700 dark:text-slate-300"}`,
              children: [
                e.jsx(Se, {
                  className: "w-3.5 h-3.5"
                }),
                "Studio (",
                i,
                ")"
              ]
            })
          ]
        })
      ]
    });
  }
  function Fr({ notebook: t }) {
    return Qt(t) ? e.jsxs("div", {
      className: "flex items-start gap-2 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-md px-3 py-2 text-xs text-amber-800 dark:text-amber-200",
      children: [
        e.jsx(pt, {
          className: "w-3.5 h-3.5 mt-0.5 flex-shrink-0"
        }),
        e.jsxs("div", {
          children: [
            e.jsx("strong", {
              children: "Read-only access."
            }),
            " You can read and chat, but cannot add/edit sources, generate, rename, or delete. Tags and folders work locally."
          ]
        })
      ]
    }) : null;
  }
  const Rr = pe.lazy(() => he(() => import("./chunk-88a1bfe3.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-88a1bfe3.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-602992a9.js","assets/chunk-5a4465c9.js"])), Lr = pe.lazy(() => he(() => import("./chunk-cbf1930e.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-cbf1930e.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css"])), Dr = pe.lazy(() => he(() => import("./chunk-3c1767fa.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-3c1767fa.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-57988b21.js","assets/chunk-234b1720.js"])), Er = pe.lazy(() => he(() => import("./chunk-9a7729d3.js").then(async (m) => {
    await m.__tla;
    return m;
  }), ["assets/chunk-9a7729d3.js","assets/chunk-b41980cc.js","assets/chunk-68adfa56.js","assets/chunk-725317a4.js","assets/chunk-cbc671dd.js","assets/chunk-1784b260.js","assets/chunk-2a4ab792.js","assets/chunk-38df7042.js","assets/chunk-9bfc7485.js","assets/ThemeProvider-3e3bc218.css","assets/chunk-378f9272.js"]));
  function Mr() {
    var _a2, _b, _c, _d, _e, _f, _g, _h;
    let { id: t } = Aa();
    const [a, n] = Fe(), { notebooklm: r } = a, l = (_a2 = r == null ? void 0 : r.projects) == null ? void 0 : _a2.find((Q) => Q.id === t), i = (l == null ? void 0 : l.sources) || [], d = Qt(l), o = ((_c = (_b = a.notebookLabels) == null ? void 0 : _b.modeMap) == null ? void 0 : _c[t]) || "folders", c = i.length < Ce, u = o === "labels" && !c ? "labels" : "folders", h = u === "labels" ? qs : Es, [x, m] = s.useState(false), [y, b] = s.useState(false), [p, w] = s.useState(false), [C, S] = s.useState(false), [g] = _a(), f = g.get("action"), v = f === $t.GENERATE, [D, O] = vr(v ? "artifacts" : void 0), [j, N] = s.useState(v), E = s.useRef(false);
    s.useEffect(() => {
      E.current || f === $t.DUPLICATES && (E.current = true, S(true));
    }, [
      f
    ]);
    const { pendingRenameItems: T, handleRename: M, confirmRename: F, closeRenameDialog: H } = Xt({
      renameAction: (Q, le) => n.renameNotebookLM(Q, le),
      refreshAction: () => n.fetchNotebookLMProjects(),
      setIsLoading: m,
      itemLabel: "notebook"
    }), $ = Nr({
      globalActions: n,
      notebookId: t,
      notebook: l,
      sources: i
    }), A = Cr({
      notebookId: t,
      notebook: l
    }), de = ((_d = a.artifactStats.statsMap[t]) == null ? void 0 : _d.total) || 0;
    s.useEffect(() => {
      !p && n.isNotebookLMAuthenticated() && (ie(), w(true));
    }, [
      p,
      n
    ]), s.useEffect(() => {
      var _a3;
      ((_a3 = a.notebookTags) == null ? void 0 : _a3.isLoaded) || n.loadTags();
    }, [
      (_e = a.notebookTags) == null ? void 0 : _e.isLoaded,
      n
    ]), s.useEffect(() => {
      var _a3;
      ((_a3 = a.notebookLabels) == null ? void 0 : _a3.modesLoaded) || n.loadLabelViewModes();
    }, [
      (_f = a.notebookLabels) == null ? void 0 : _f.modesLoaded,
      n
    ]);
    const X = s.useRef(false);
    s.useEffect(() => {
      var _a3;
      !((_a3 = a.sourceFolders) == null ? void 0 : _a3.isLoaded) && !X.current && (X.current = true, n.loadSourceFolders().finally(() => {
        X.current = false;
      }));
    }, [
      (_g = a.sourceFolders) == null ? void 0 : _g.isLoaded,
      n
    ]), s.useEffect(() => {
      t && n.isNotebookLMAuthenticated() && n.scanNotebookStats(t);
    }, [
      t,
      n
    ]);
    const ie = async () => {
      m(true);
      try {
        await n.fetchNotebookLMProjects();
      } catch {
        k.error("Failed to load data");
      } finally {
        m(false);
      }
    }, Y = s.useRef(null);
    s.useEffect(() => {
      var _a3;
      t && i.length > 0 && ((_a3 = a.sourceFolders) == null ? void 0 : _a3.isLoaded) && Y.current !== t && (Y.current = t, n.cleanupOrphanedSources(t, i.map((Q) => Q.id)));
    }, [
      t,
      i,
      (_h = a.sourceFolders) == null ? void 0 : _h.isLoaded,
      n
    ]);
    const ee = async () => {
      m(true);
      try {
        await n.fetchNotebookLMProjects(), await n.scanNotebookStats(t), Y.current = null, k.success("Data refreshed");
      } catch {
        k.error("Failed to refresh data");
      } finally {
        m(false);
      }
    };
    return e.jsxs(Oa, {
      children: [
        e.jsx(Pa, {
          titleTemplate: "%s",
          children: e.jsx("title", {
            children: l ? `${l.title} - Sources` : "Notebook Sources"
          })
        }),
        l ? e.jsxs("div", {
          className: "flex flex-col gap-4",
          children: [
            e.jsx(Ba, {}),
            e.jsx(Sr, {
              notebook: l,
              sources: i,
              isLoading: x,
              notebookId: t,
              activeTab: D,
              totalArtifacts: de,
              onTabChange: O,
              onRefresh: ee,
              onRenameNotebook: M,
              onAddSource: () => b(true),
              onOpenExportImport: () => $.setIsOpen(true),
              onOpenDuplicateScan: () => S(true)
            }),
            e.jsx(Fr, {
              notebook: l
            }),
            n.isNotebookLMAuthenticated() && e.jsxs(e.Fragment, {
              children: [
                D === "sources" && e.jsxs(e.Fragment, {
                  children: [
                    e.jsxs("div", {
                      className: "flex flex-wrap items-center gap-x-3 gap-y-1",
                      children: [
                        e.jsx(Ys, {
                          mode: u,
                          onChange: (Q) => n.setLabelViewMode(t, Q),
                          labelsDisabled: c,
                          disabledReason: ma(i.length)
                        }),
                        e.jsx(Js, {
                          mode: u,
                          labelsDisabled: c,
                          sourceCount: i.length
                        })
                      ]
                    }),
                    e.jsx(h, {
                      notebook: l,
                      sources: i,
                      isLoading: x,
                      setIsLoading: m,
                      globalActions: n,
                      notebookId: t,
                      onAddSource: () => b(true),
                      onTabChange: O,
                      readOnly: d
                    })
                  ]
                }),
                D === "artifacts" && e.jsx(jr, {
                  notebookId: t,
                  sources: i,
                  readOnly: d,
                  sourceTitleById: A.sourceTitleById,
                  onExportSourceArtifactMap: A.handleExportCsv,
                  isExportingMap: A.isExporting,
                  autoOpenGenerate: j,
                  onGenerateOpened: () => N(false)
                })
              ]
            })
          ]
        }) : e.jsx("div", {
          className: "flex flex-col gap-4",
          children: e.jsxs("div", {
            className: "text-center py-16",
            children: [
              e.jsx("h3", {
                className: "text-xs font-medium text-gray-900 dark:text-slate-100",
                children: "Notebook not found"
              }),
              e.jsx("p", {
                className: "mt-1 text-xs text-gray-500 dark:text-slate-400",
                children: "The notebook you're looking for doesn't exist or has been removed"
              })
            ]
          })
        }),
        e.jsxs(s.Suspense, {
          fallback: null,
          children: [
            T && e.jsx(Lr, {
              isOpen: !!T,
              onClose: H,
              onConfirm: F,
              items: T,
              itemLabel: "notebook"
            }),
            y && e.jsx(Rr, {
              isOpen: y,
              onClose: () => b(false),
              notebook: l
            }),
            $.isOpen && e.jsx(Dr, {
              isOpen: $.isOpen,
              onClose: () => $.setIsOpen(false),
              notebook: l,
              sources: i,
              onExport: $.handleExport,
              onImport: $.handleImport,
              isExporting: $.isExporting,
              isImporting: $.isImporting,
              exportProgress: $.exportProgress
            }),
            C && e.jsx(Er, {
              isOpen: C,
              onClose: () => S(false),
              notebook: l,
              sources: i,
              onSuccess: ee
            })
          ]
        })
      ]
    });
  }
  Qr = Object.freeze(Object.defineProperty({
    __proto__: null,
    default: Mr
  }, Symbol.toStringTag, {
    value: "Module"
  }));
});
export {
  gr as A,
  Qr as N,
  __tla
};
