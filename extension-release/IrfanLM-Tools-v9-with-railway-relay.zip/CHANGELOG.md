# Changelog

## 8.0.0

**Fixed Cloudinary/Telegram export failing due to CORS-blocked blob fetch —
now uses remote-URL upload so Cloudinary/Telegram fetch media server-side.**

### Root cause
`btUploadOneToCloudinary` (bulk-tools-bg.js) and `fetchStudioMedia` /
`uploadBlobToCloudinary` (nlm-lovable-bridge-bg.js) called
`fetch(sourceUrl)` and then `.blob()` to read the NotebookLM Studio media
bytes before re-uploading them. NotebookLM's media CDN does not send
`Access-Control-Allow-Origin` for this extension's / Lovable's origin, so
that read never resolves with usable data. `chrome.downloads.download()`
and `<video>`/`<audio>` playback are exempt from this because they never
expose response bytes to JS — which is why manual Download and Preview
both worked while Cloudinary/Telegram export silently failed.

### Fix
- Cloudinary and Telegram both accept a remote URL directly (Cloudinary's
  `file` field, Telegram Bot API's `video`/`audio`/`document` field) and
  fetch it themselves, server-side. All blob-fetch-then-upload code paths
  were replaced with passing the NotebookLM `mediaUrl` straight through.
- Because these `mediaUrl`s are short-lived signed URLs, the background
  queue now re-resolves a fresh URL for each item (via the same
  `gArtLc` list-artifacts RPC) immediately before every Cloudinary/Telegram
  call, instead of relying on a URL captured earlier in the UI session.
- Upstream error text from Cloudinary (`error.message`) and Telegram
  (`description`) is now surfaced in the queue results and results
  table/CSV instead of a generic "failed" message.
- **New:** Telegram export path (Bot Settings: bot token + chat ID),
  mirroring the existing Cloudinary export UI/queue pattern.
- Download queue (`chrome.downloads.download()`) is unchanged — it never
  had this problem.
- Known limitation: the inline/base64 fallback path in
  `nlm-lovable-bridge-bg.js` (used only when no `upload`/`telegram` creds
  are supplied) still performs a blob fetch and is subject to the same CORS
  restriction. Prefer the `upload`/`telegram` remote-URL paths.
