// ─────────────────────────────────────────────────────────────────────────
// Lovable Bridge (custom addon) — options page script
// Talks to the background bridge (assets/nlm-lovable-bridge-bg.js) using the
// internal __nlmBridgeDebug transport, which needs no origin allow-listing
// since this page only ever runs inside the extension itself.
// ─────────────────────────────────────────────────────────────────────────

(() => {
  "use strict";

  const extIdEl = document.getElementById("ext-id");
  const copyBtn = document.getElementById("copy-id");
  const badgeEl = document.getElementById("status-badge");
  const detailEl = document.getElementById("status-detail");
  const fieldListEl = document.getElementById("field-list");
  const notebookCountEl = document.getElementById("notebook-count");
  const recheckBtn = document.getElementById("recheck");
  const openNlmBtn = document.getElementById("open-nlm");
  const toastEl = document.getElementById("toast");

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    setTimeout(() => toastEl.classList.remove("show"), 1800);
  }

  function debugCall(type, payload) {
    return chrome.runtime.sendMessage({ __nlmBridgeDebug: true, type, payload });
  }

  function setBadge(state, text) {
    badgeEl.className = `badge ${state}`;
    badgeEl.textContent = text;
  }

  function renderFields(fields) {
    fieldListEl.innerHTML = "";
    if (!fields) return;
    for (const [key, present] of Object.entries(fields)) {
      const pill = document.createElement("span");
      pill.className = `field-pill ${present ? "yes" : "no"}`;
      pill.textContent = `${present ? "✓" : "✗"} ${key}`;
      fieldListEl.appendChild(pill);
    }
  }

  async function refreshStatus() {
    setBadge("pending", "Checking…");
    detailEl.textContent = "Running diagnostic…";
    fieldListEl.innerHTML = "";
    notebookCountEl.textContent = "—";

    try {
      const res = await debugCall("DEBUG_STATUS");
      if (!res?.ok) throw new Error(res?.error || "Unknown error");

      if (res.authenticated) {
        setBadge("ok", `Connected${res.email ? ` (${res.email})` : ""}`);
        detailEl.textContent = res.lastRefreshed
          ? `Last synced from notebooklm.google.com: ${new Date(res.lastRefreshed).toLocaleString()}`
          : "Account is present.";
      } else {
        setBadge("bad", "Not Connected");
        detailEl.textContent = res.hint || "No active NotebookLM account found.";
      }
      renderFields(res.fields);
      notebookCountEl.textContent =
        res.knownNotebookCount > 0
          ? `${res.knownNotebookCount} notebook(s) tracked.`
          : "No notebooks tracked yet — open one on notebooklm.google.com.";
    } catch (err) {
      setBadge("bad", "Error");
      detailEl.textContent = err?.message || String(err);
    }
  }

  copyBtn.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(chrome.runtime.id);
      toast("Extension ID copied");
    } catch {
      toast("Could not copy — select the ID manually");
    }
  });

  recheckBtn.addEventListener("click", refreshStatus);

  openNlmBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://notebooklm.google.com/" });
  });

  extIdEl.textContent = chrome.runtime.id;
  refreshStatus();
})();
