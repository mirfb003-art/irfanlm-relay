// ─────────────────────────────────────────────────────────────────────────
// Bulk Tools (custom addon) — background logic
// Handles:
//   1) Sequential "download one-by-one, wait for full completion" queue
//   2) Sequential Cloudinary remote-URL upload queue with progress
//   3) Sequential Telegram remote-URL send queue with progress
// State is persisted in chrome.storage.local so the queue survives MV3
// service-worker restarts (listeners are registered at top level, which is
// required for Chrome to redeliver events to a freshly-woken worker).
//
// v8.0.0 FIX — CORS: Cloudinary/Telegram export used to fetch(sourceUrl)
// then re-upload the blob via multipart FormData. NotebookLM's media CDN
// does not send Access-Control-Allow-Origin for this extension's origin,
// so that fetch never resolves with readable bytes (only chrome.downloads
// and <video>/<audio> playback are exempt from CORS, because they never
// expose response bytes to JS). Cloudinary and the Telegram Bot API both
// accept a remote URL and fetch it themselves, server-side — no CORS
// involved. This version removes every fetch(...).blob() call from the
// Cloudinary/Telegram paths and passes the NotebookLM mediaUrl straight
// through instead. It also re-resolves that mediaUrl immediately before
// each upload, since these are short-lived signed URLs and a stale one
// (captured minutes earlier in the UI) was a likely cause of intermittent
// failures even before the CORS issue was found.
// ─────────────────────────────────────────────────────────────────────────

const BT_DL_KEY = "__bulkTools_downloadQueue";
const BT_CLOUD_KEY = "__bulkTools_cloudQueue";
const BT_TELEGRAM_KEY = "__bulkTools_telegramQueue";
const BT_LOVABLE_QUEUE_KEY = "__bulkTools_lovableQueue";
const BT_LOVABLE_CREDS_KEY = "__bulkTools_lovableCreds";
const BT_RELAY_CREDS_KEY = "__bulkTools_relayCreds";

// Same storage keys the main extension bundle writes when a NotebookLM
// account is captured (see chunk-68adfa56.js / chunk-5e2e563c.js), and the
// same shape nlm-lovable-bridge-bg.js reads. Duplicated here deliberately —
// this file is its own ES module in the service worker and doesn't share
// scope with nlm-lovable-bridge-bg.js — mirroring the existing pattern
// where bulk-tools-ui.js already keeps its own independent RPC client.
const CONFIG_NLM_KEY = "YT_NOTEBOOKLM_TOOLS_CONFIG_NLM";
const CONFIG_NLM_ACCOUNTS_KEY = "YT_NOTEBOOKLM_TOOLS_CONFIG_NLM_ACCOUNTS";
const RPC_HOST = "notebooklm.google.com";
const RPC_ENDPOINT = `https://${RPC_HOST}/_/LabsTailwindUi/data/batchexecute`;
const LIST_ARTIFACTS_RPC = "gArtLc";
const DEFAULT_BL = "boq_labs-tailwind-frontend_20250902.08_p1";
const ARTIFACT_TYPE = { AUDIO: 1, VIDEO: 3 };
const STATUS_READY = 3;

function btSanitize(name) {
  return (name || "untitled")
    .replace(/[\\/:*?"<>|]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function btGuessExt(item) {
  if (item.kind === "video") return ".mp4";
  if (item.kind === "audio") return ".m4a";
  return "";
}

async function btBroadcast(msg) {
  try {
    await chrome.runtime.sendMessage({ __bulkTools: true, ...msg });
  } catch {
    // no listener currently open (popup/side panel closed) — state is still
    // persisted in storage, UI will re-sync on next open via GET_STATE.
  }
}

// ── NotebookLM account + fresh-mediaUrl helpers ─────────────────────────
// Used only to re-resolve a single artifact's mediaUrl right before a
// Cloudinary/Telegram call, since those URLs are short-lived signed URLs
// and the copy the UI captured when the list was loaded may have expired
// by the time the queue gets to it (especially for later items in a big
// batch, or a queue resumed after the service worker was suspended).

async function btGetActiveAccount() {
  const store = await chrome.storage.local.get([CONFIG_NLM_KEY, CONFIG_NLM_ACCOUNTS_KEY]);
  const multi = store[CONFIG_NLM_ACCOUNTS_KEY];
  if (multi && multi.accounts && multi.activeAccount) {
    const acc = multi.accounts[multi.activeAccount];
    if (acc && acc.token) return acc;
  }
  const single = store[CONFIG_NLM_KEY];
  if (single && single.token) return single;
  return null;
}

async function btCallBatchExecute(account, notebookId, rpcId, args) {
  const urlParams = new URLSearchParams({
    bl: account.bl || DEFAULT_BL,
    hl: "en",
    "source-path": `/notebook/${encodeURIComponent(notebookId)}`,
    ...(account.fsid ? { "f.sid": account.fsid } : {}),
    ...(Number.isInteger(account.authuser) && account.authuser > 0
      ? { authuser: String(account.authuser) }
      : {}),
  });
  const body = new URLSearchParams({
    rpcids: rpcId,
    "f.req": JSON.stringify([[[rpcId, JSON.stringify(args), null, null]]]),
    at: account.token,
  });

  const res = await fetch(`${RPC_ENDPOINT}?${urlParams}`, {
    method: "POST",
    headers: {
      "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
      "x-same-domain": "1",
    },
    body,
    credentials: "include",
  });

  const text = await res.text();
  const lines = text.split("\n").filter((l) => l.trim());
  let parsed = null;
  for (const line of lines) {
    try {
      const v = JSON.parse(line);
      if (Array.isArray(v) && v.length > 0) {
        parsed = v;
        break;
      }
    } catch {
      // anti-XSSI / length-prefix lines — not valid JSON, skip
    }
  }
  if (!parsed) throw new Error("Could not read NotebookLM response — is the user logged in on notebooklm.google.com?");

  const d = parsed[0];
  const errCode = d && d[5] ? d[5][0] : null;
  if (errCode != null && errCode !== 0) {
    throw new Error(`NotebookLM RPC error ${errCode} — session may be stale, try reloading notebooklm.google.com`);
  }
  return d && d[2] ? JSON.parse(d[2]) : null;
}

function btSafeGet(arr, idx, fallback = null) {
  return Array.isArray(arr) && arr.length > idx ? arr[idx] : fallback;
}

function btParseArtifactMediaUrl(raw) {
  const id = btSafeGet(raw, 0);
  const type = btSafeGet(raw, 2);
  const status = btSafeGet(raw, 4);
  if (!id || status !== STATUS_READY) return null;

  if (type === ARTIFACT_TYPE.AUDIO) {
    const e = btSafeGet(raw, 6);
    if (e) return { id, mediaUrl: btSafeGet(e, 2), downloadUrl: btSafeGet(e, 3) };
  } else if (type === ARTIFACT_TYPE.VIDEO) {
    const t2 = btSafeGet(raw, 8);
    if (t2) return { id, mediaUrl: btSafeGet(t2, 1), downloadUrl: btSafeGet(t2, 3) };
  }
  return null;
}

// Re-fetches a single item's mediaUrl fresh from NotebookLM right before
// use. Falls back to the item's existing mediaUrl/downloadUrl (whatever the
// UI already captured) if the refresh isn't possible (no notebookId, no
// signed-in account, or the RPC call itself fails) — better to try an
// older URL than to abort the export entirely.
async function btRefreshMediaUrl(item, notebookId) {
  const fallback = item.mediaUrl || item.downloadUrl || null;
  if (!notebookId || !item.id) return fallback;

  try {
    const account = await btGetActiveAccount();
    if (!account) return fallback;

    const data = await btCallBatchExecute(account, notebookId, LIST_ARTIFACTS_RPC, [
      [2],
      notebookId,
      'NOT artifact.status = "ARTIFACT_STATUS_SUGGESTED"',
    ]);
    const list = Array.isArray(data) && Array.isArray(data[0]) ? data[0] : data;
    if (!Array.isArray(list)) return fallback;

    for (const raw of list) {
      const parsed = btParseArtifactMediaUrl(raw);
      if (parsed && parsed.id === item.id) {
        return parsed.mediaUrl || parsed.downloadUrl || fallback;
      }
    }
    return fallback;
  } catch {
    // Refresh failed (session hiccup, RPC error, etc.) — fall back to
    // whatever URL the UI already has rather than failing the whole item.
    return fallback;
  }
}

// ── Download queue ─────────────────────────────────────────────────────

async function btGetDlQueue() {
  const r = await chrome.storage.local.get(BT_DL_KEY);
  return r[BT_DL_KEY] || null;
}
async function btSetDlQueue(q) {
  await chrome.storage.local.set({ [BT_DL_KEY]: q });
}

async function btStartDownloadQueue(items) {
  const q = {
    phase: "download",
    items,
    index: 0,
    activeDownloadId: null,
    results: [],
    done: false,
    startedAt: Date.now(),
  };
  await btSetDlQueue(q);
  await btBroadcast({ type: "PROGRESS", queue: "download", state: q });
  btProcessNextDownload();
}

async function btProcessNextDownload() {
  const q = await btGetDlQueue();
  if (!q || q.phase !== "download" || q.done) return;

  if (q.index >= q.items.length) {
    q.done = true;
    await btSetDlQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "download", state: q });
    return;
  }

  const item = q.items[q.index];
  const url = item.mediaUrl || item.downloadUrl;
  if (!url) {
    q.results.push({ ...item, success: false, error: "No downloadable URL" });
    q.index += 1;
    await btSetDlQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "download", state: q });
    return btProcessNextDownload();
  }

  // Unchanged: chrome.downloads.download() is exempt from CORS (it never
  // exposes response bytes to JS) and already worked correctly.
  chrome.downloads.download(
    {
      url,
      filename: btSanitize(item.title) + btGuessExt(item),
      saveAs: false,
      conflictAction: "uniquify",
    },
    async (downloadId) => {
      const q2 = await btGetDlQueue();
      if (!q2) return;
      if (chrome.runtime.lastError || !downloadId) {
        q2.results.push({
          ...item,
          success: false,
          error: chrome.runtime.lastError?.message || "Failed to start download",
        });
        q2.index += 1;
        await btSetDlQueue(q2);
        await btBroadcast({ type: "PROGRESS", queue: "download", state: q2 });
        return btProcessNextDownload();
      }
      q2.activeDownloadId = downloadId;
      await btSetDlQueue(q2);
      await btBroadcast({ type: "PROGRESS", queue: "download", state: q2 });
    }
  );
}

chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state) return;
  const q = await btGetDlQueue();
  if (!q || q.phase !== "download" || q.done) return;
  if (q.activeDownloadId !== delta.id) return;

  const current = delta.state.current;
  if (current === "complete" || current === "interrupted") {
    const item = q.items[q.index];
    q.results.push({
      ...item,
      success: current === "complete",
      error: current === "interrupted" ? "Download interrupted" : null,
    });
    q.index += 1;
    q.activeDownloadId = null;
    await btSetDlQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "download", state: q });
    btProcessNextDownload();
  }
});

// ── Cloudinary remote-URL upload queue ─────────────────────────────────

// Relay-backed upload: the extension refreshes the short-lived NotebookLM
// URL, then sends only URL + metadata to Railway. Cloudinary credentials stay
// server-side in Railway environment variables.
async function btGetRelayCreds() {
  const r = await chrome.storage.local.get(BT_RELAY_CREDS_KEY);
  return r[BT_RELAY_CREDS_KEY] || null;
}

function btRelayEndpoint(creds, path) {
  const base = String(creds?.relayServerUrl || "").trim().replace(/\/+$/, "");
  const token = String(creds?.relayToken || "").trim();
  if (!base || !token) throw new Error("Relay Server URL and Relay Token are required. Configure Relay Settings first.");
  let url;
  try { url = new URL(base); } catch { throw new Error("Relay Server URL is invalid."); }
  if (url.protocol !== "https:" && url.hostname !== "localhost" && url.hostname !== "127.0.0.1") {
    throw new Error("Relay Server URL must use HTTPS (localhost is allowed for development).");
  }
  return { url: `${base}${path}`, token };
}

async function btPostRelay(path, payload) {
  const creds = await btGetRelayCreds();
  const target = btRelayEndpoint(creds, path);
  const res = await fetch(target.url, {
    method: "POST",
    headers: { "content-type": "application/json", "x-relay-token": target.token },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.success) throw new Error(data?.error || `Relay request failed (HTTP ${res.status})`);
  return data;
}

async function btUploadOneToCloudinary(item, _creds, notebookId) {
  try {
    const sourceUrl = await btRefreshMediaUrl(item, notebookId);
    if (!sourceUrl) throw new Error("No source URL for this item (and it could not be refreshed)");
    const data = await btPostRelay("/cloudinary/upload", {
      mediaUrl: sourceUrl,
      title: item.title || "Untitled",
      type: item.kind === "video" ? "3" : "1",
      folder: "irfanlm",
    });
    return { success: true, cloudinaryUrl: data.url || data.secure_url || "" };
  } catch (e) {
    return { success: false, error: e.message || String(e) };
  }
}

async function btGetCloudQueue() {
  const r = await chrome.storage.local.get(BT_CLOUD_KEY);
  return r[BT_CLOUD_KEY] || null;
}
async function btSetCloudQueue(q) {
  await chrome.storage.local.set({ [BT_CLOUD_KEY]: q });
}

async function btStartCloudinaryQueue(items, creds, notebookId) {
  const q = {
    phase: "cloudinary",
    items,
    index: 0,
    results: [],
    done: false,
    startedAt: Date.now(),
  };
  await btSetCloudQueue(q);
  await btBroadcast({ type: "PROGRESS", queue: "cloudinary", state: q });

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    q.index = i;
    await btSetCloudQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "cloudinary", state: q, current: item });

    const r = await btUploadOneToCloudinary(item, creds, notebookId);
    q.results.push({ ...item, success: r.success, cloudinaryUrl: r.cloudinaryUrl, error: r.error });
    q.index = i + 1;
    await btSetCloudQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "cloudinary", state: q });
  }

  q.done = true;
  await btSetCloudQueue(q);
  await btBroadcast({ type: "PROGRESS", queue: "cloudinary", state: q });
}

// ── Telegram relay queue ────────────────────────────────────────────────
// The Railway service owns the Bot API token and streams the media server-side.
// The extension sends only the freshly resolved signed URL and metadata.
const TELEGRAM_LIKELY_OVERSIZED_DURATION_SEC = 25 * 60;

async function btSendOneToTelegram(item, _creds, notebookId) {
  try {
    const relay = await btGetRelayCreds();
    if (!relay?.telegramChatId) throw new Error("Telegram Chat ID is required in Railway Relay Settings.");
    const sourceUrl = await btRefreshMediaUrl(item, notebookId);
    if (!sourceUrl) throw new Error("No source URL for this item (and it could not be refreshed)");
    const data = await btPostRelay("/telegram/send", {
      mediaUrl: sourceUrl,
      title: item.title || "Untitled",
      type: item.kind === "video" ? "3" : "1",
      chatId: relay.telegramChatId,
      caption: (item.title || "Untitled").slice(0, 1024),
    });
    return { success: true, telegramMessageId: data.messageId ?? null };
  } catch (e) {
    const msg = e.message || String(e);
    const likelyTooLarge = (item.duration || 0) > TELEGRAM_LIKELY_OVERSIZED_DURATION_SEC && /too large|entity too large|file is too big/i.test(msg);
    return { success: false, error: likelyTooLarge ? `${msg} — this file is likely over Telegram's size limit` : msg };
  }
}

async function btGetTelegramQueue() {
  const r = await chrome.storage.local.get(BT_TELEGRAM_KEY);
  return r[BT_TELEGRAM_KEY] || null;
}
async function btSetTelegramQueue(q) {
  await chrome.storage.local.set({ [BT_TELEGRAM_KEY]: q });
}
async function btSaveRelayCreds(creds) {
  await chrome.storage.local.set({ [BT_RELAY_CREDS_KEY]: creds || {} });
  // Remove old third-party secrets after migration to the Railway relay.
  await chrome.storage.local.remove(["__bulkTools_cloudinaryCreds", "__bulkTools_telegramCreds"]);
}

async function btStartTelegramQueue(items, creds, notebookId) {
  const q = {
    phase: "telegram",
    items,
    index: 0,
    results: [],
    done: false,
    startedAt: Date.now(),
  };
  await btSetTelegramQueue(q);
  await btBroadcast({ type: "PROGRESS", queue: "telegram", state: q });

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    q.index = i;
    await btSetTelegramQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "telegram", state: q, current: item });

    const r = await btSendOneToTelegram(item, creds, notebookId);
    q.results.push({ ...item, success: r.success, error: r.error });
    q.index = i + 1;
    await btSetTelegramQueue(q);
    await btBroadcast({ type: "PROGRESS", queue: "telegram", state: q });
  }

  q.done = true;
  await btSetTelegramQueue(q);
  await btBroadcast({ type: "PROGRESS", queue: "telegram", state: q });
}

// ── Lovable Cloud sync engine ──────────────────────────────────────────
//
// Sends the selected Studio items (media URLs, names, dates, source
// metadata, notebook ID) to the connected Lovable App's webhook as one
// batch POST. Runs entirely in this background service worker: once the
// fetch is in flight it's not tied to the notebooklm.google.com tab or
// the popup/side panel, so closing either doesn't cancel the hand-off —
// only closing/suspending the extension itself would. State is persisted
// in storage (same pattern as the download/Cloudinary/Telegram queues
// above) so a UI that (re)opens mid-sync can resync via GET_STATE.

function btValidateSyncRequest(items, notebookId) {
  if (typeof notebookId !== "string" || !notebookId.trim()) {
    throw new Error('"notebookId" is required and must be a non-empty string — open a notebook first.');
  }
  if (!Array.isArray(items) || items.length === 0) {
    throw new Error("No items selected — select at least one Studio item to send.");
  }
  for (const item of items) {
    if (!item || typeof item.id !== "string" || !item.id) {
      throw new Error("One or more selected items is missing a valid id — reload the list and try again.");
    }
  }
  return { items, notebookId: notebookId.trim() };
}

function btBuildSyncPayload(items, notebookId) {
  return {
    source: "IrfanLM Tools",
    extensionVersion: chrome.runtime.getManifest().version,
    notebookId,
    sentAt: new Date().toISOString(),
    itemCount: items.length,
    items: items.map((item) => ({
      id: item.id,
      title: item.title || "Untitled",
      kind: item.kind || null, // "audio" | "video"
      typeLabel: item.typeLabel || null,
      mediaUrl: item.mediaUrl || null,
      downloadUrl: item.downloadUrl || null,
      durationSeconds: item.duration ?? null,
      createdAt: item.createdAt || null,
      updatedAt: item.updatedAt || null,
      styleLabel: item.styleLabel || null,
      sourceIds: item.sourceIds || [],
      sources: (item.sources || []).map((s) => ({
        id: s.id,
        title: s.title,
        url: s.url || null,
        youtubeVideoId: s.youtubeVideoId || null,
      })),
    })),
  };
}

async function btGetLovableQueue() {
  const r = await chrome.storage.local.get(BT_LOVABLE_QUEUE_KEY);
  return r[BT_LOVABLE_QUEUE_KEY] || null;
}
async function btSetLovableQueue(q) {
  await chrome.storage.local.set({ [BT_LOVABLE_QUEUE_KEY]: q });
}

async function btGetLovableCreds() {
  const r = await chrome.storage.local.get(BT_LOVABLE_CREDS_KEY);
  return r[BT_LOVABLE_CREDS_KEY] || null;
}
async function btSaveLovableCreds(creds) {
  await chrome.storage.local.set({ [BT_LOVABLE_CREDS_KEY]: creds });
}

async function btStartLovableSync(items, notebookId, credsOverride) {
  const q = {
    phase: "lovable",
    items,
    notebookId,
    index: 0,
    results: [],
    done: false,
    ok: null,
    error: null,
    responseData: null,
    startedAt: Date.now(),
  };
  await btSetLovableQueue(q);
  await btBroadcast({ type: "LOVABLE_PROGRESS", state: q });

  try {
    const { items: validItems, notebookId: validNotebookId } = btValidateSyncRequest(items, notebookId);

    const creds = credsOverride || (await btGetLovableCreds());
    if (!creds || !creds.endpoint) {
      throw new Error("No Lovable Cloud endpoint configured — add your webhook URL in Lovable Cloud Settings first.");
    }

    const payload = btBuildSyncPayload(validItems, validNotebookId);

    const headers = { "content-type": "application/json" };
    if (creds.apiKey) headers["authorization"] = `Bearer ${creds.apiKey}`;

    const res = await fetch(creds.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
      keepalive: true,
    });

    let responseData = null;
    try {
      responseData = await res.json();
    } catch {
      // webhook may not return JSON — not fatal, we still know the HTTP status
    }

    if (!res.ok) {
      throw new Error(`Lovable Cloud webhook returned ${res.status}${responseData?.error ? `: ${responseData.error}` : ""}`);
    }

    q.done = true;
    q.ok = true;
    q.index = validItems.length;
    q.results = validItems.map((it) => ({ id: it.id, title: it.title, success: true }));
    q.responseData = responseData;
    await btSetLovableQueue(q);
    await btBroadcast({ type: "LOVABLE_PROGRESS", state: q });
  } catch (e) {
    q.done = true;
    q.ok = false;
    q.error = e.message || String(e);
    await btSetLovableQueue(q);
    await btBroadcast({ type: "LOVABLE_PROGRESS", state: q });
  }
}

// ── Messaging ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.__bulkTools) return;

  (async () => {
    if (msg.type === "START_DOWNLOAD") {
      await btStartDownloadQueue(msg.items);
      sendResponse({ ok: true });
    } else if (msg.type === "START_CLOUDINARY") {
      btStartCloudinaryQueue(msg.items, msg.creds, msg.notebookId); // don't await — runs in background, reports via broadcast
      sendResponse({ ok: true });
    } else if (msg.type === "START_TELEGRAM") {
      btStartTelegramQueue(msg.items, msg.creds, msg.notebookId); // don't await — runs in background, reports via broadcast
      sendResponse({ ok: true });
    } else if (msg.type === "GET_STATE") {
      const dl = await btGetDlQueue();
      const cloud = await btGetCloudQueue();
      const telegram = await btGetTelegramQueue();
      const lovable = await btGetLovableQueue();
      sendResponse({ ok: true, download: dl, cloudinary: cloud, telegram, lovable });
    } else if (msg.type === "CLEAR_STATE") {
      await chrome.storage.local.remove([BT_DL_KEY, BT_CLOUD_KEY, BT_TELEGRAM_KEY, BT_LOVABLE_QUEUE_KEY]);
      sendResponse({ ok: true });
    } else if (msg.type === "SEND_TO_LOVABLE") {
      try {
        const { items, notebookId } = btValidateSyncRequest(msg.items, msg.notebookId);
        btStartLovableSync(items, notebookId, msg.creds); // don't await — runs in background, reports via broadcast
        sendResponse({ ok: true, itemCount: items.length });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    } else if (msg.type === "GET_LOVABLE_CREDS") {
      const creds = await btGetLovableCreds();
      sendResponse({ ok: true, creds });
    } else if (msg.type === "SAVE_LOVABLE_CREDS") {
      await btSaveLovableCreds(msg.creds);
      sendResponse({ ok: true });
    } else if (msg.type === "GET_RELAY_CREDS") {
      const creds = await btGetRelayCreds();
      sendResponse({ ok: true, creds });
    } else if (msg.type === "SAVE_RELAY_CREDS") {
      await btSaveRelayCreds(msg.creds);
      sendResponse({ ok: true });
    }
  })();

  return true; // keep the message channel open for the async response
});
