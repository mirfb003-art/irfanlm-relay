// ─────────────────────────────────────────────────────────────────────────
// Bulk Tools (custom addon) — UI
// Adds a floating "Bulk Video/Audio Tools" button to the popup / side panel.
// Lets you: list all Audio+Video Studio outputs for the current notebook on
// one screen (no pagination), select some/all, download them one-by-one
// (waits for each to fully finish before starting the next), or export them
// to Cloudinary one-by-one with a live progress bar, then copy/download the
// results as CSV.
// ─────────────────────────────────────────────────────────────────────────

(function () {
  "use strict";

  console.log("[BulkTools] script loaded, document.readyState =", document.readyState);

  const RPC_HOST = "notebooklm.google.com";
  const RPC_ENDPOINT = `https://${RPC_HOST}/_/LabsTailwindUi/data/batchexecute`;
  const LIST_ARTIFACTS_RPC = "gArtLc";
  const GET_PROJECT_RPC = "rLM1Ne";
  const DEFAULT_BL = "boq_labs-tailwind-frontend_20250902.08_p1";
  const ARTIFACT_TYPE = { AUDIO: 1, VIDEO: 3 };
  const ARTIFACT_TYPE_LABEL = {
    1: "Audio", 2: "Report", 3: "Video", 4: "Quiz/Flashcards", 5: "Mind Map",
    7: "Infographic", 8: "Slide Deck", 9: "Data Table", 10: "Quiz", 11: "Flashcards", 12: "Note",
  };
  const STATUS_READY = 3;
  const SOURCE_TYPE = {
    GOOGLE_DOCS: 1, GOOGLE_SLIDES: 2, PDF: 3, PASTED_TEXT: 4, WEB_PAGE: 5,
    MARKDOWN: 8, YOUTUBE: 9, MEDIA: 10, DOCX: 11, IMAGE: 13, DRIVE_FILE: 14, CSV: 16,
  };
  // Generation format/style enums (as used by NotebookLM's own "Generate" dialog).
  const AUDIO_FORMAT_LABEL = { 1: "Deep Dive", 2: "Brief", 3: "Critique", 4: "Debate" };
  const VIDEO_FORMAT_LABEL = { 1: "Explainer", 2: "Brief", 3: "Cinematic", 4: "Short" };
  const LOVABLE_CRED_KEY = "__bulkTools_lovableCreds";
  const DEFAULT_LOVABLE_BASE = "https://notebook-hub-connect.lovable.app";
  const DEFAULT_LOVABLE_ENDPOINT = `${DEFAULT_LOVABLE_BASE}/api/public/sync-studio`;

  // ── small helpers ──────────────────────────────────────────────────

  function safeGet(arr, idx, fallback = null) {
    return Array.isArray(arr) && arr.length > idx ? arr[idx] : fallback;
  }
  function parseDuration(d) {
    return Array.isArray(d) && d.length > 0 ? (d[0] || 0) + (d[1] || 0) / 1e9 : null;
  }
  function fmtDuration(sec) {
    if (sec == null) return "—";
    const m = Math.floor(sec / 60);
    const s = Math.round(sec % 60);
    return `${m}:${String(s).padStart(2, "0")}`;
  }
  function escCsv(v) {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  // Protobuf-style [seconds, nanos] -> ISO string (mirrors the extension's own L()).
  function parseTimestamp(arr) {
    if (!Array.isArray(arr) || arr.length === 0) return null;
    const [sec, nanos = 0] = arr;
    if (typeof sec !== "number") return null;
    return new Date(sec * 1000 + (nanos ?? 0) / 1e6).toISOString();
  }
  function fmtDate(iso) {
    return iso ? iso.slice(0, 10) : "—";
  }
  function fmtTime(iso) {
    return iso ? iso.slice(11, 19) + " UTC" : "—";
  }

  // Recursively find the first string leaf in a source-id reference (mirrors
  // the extension's own extractSourceIds()).
  function findStringLeaf(v) {
    if (typeof v === "string") return v || null;
    if (Array.isArray(v)) {
      for (const item of v) {
        const found = findStringLeaf(item);
        if (found) return found;
      }
    }
    return null;
  }
  function extractSourceIds(raw) {
    if (!Array.isArray(raw)) return [];
    const out = [];
    for (const s of raw) {
      const id = findStringLeaf(s);
      if (id) out.push(id);
    }
    return out;
  }

  // Parses one raw source record from a notebook's GET_PROJECT response into
  // { id, title, url, youtubeVideoId } — mirrors parseSource/parseSourceMetadata/
  // extractSourceInfo in the extension's own bundle.
  function parseSourceRaw(raw) {
    if (!Array.isArray(raw) || raw.length < 2) return null;
    const idWrap = raw[0], title = raw[1], meta = raw[2];
    const id = safeGet(idWrap, 0);
    if (!id || !title) return null;
    const out = { id, title, url: null, youtubeVideoId: null, sourceTypeEnum: null };
    if (Array.isArray(meta)) {
      const typeEnum = safeGet(meta, 4);
      out.sourceTypeEnum = typeEnum;
      if (typeEnum === SOURCE_TYPE.YOUTUBE) {
        const yt = safeGet(meta, 5);
        if (Array.isArray(yt)) {
          out.url = yt[0] || null;
          out.youtubeVideoId = yt[1] || null;
        }
      } else if (typeEnum === SOURCE_TYPE.WEB_PAGE || typeEnum === SOURCE_TYPE.PDF) {
        const w = safeGet(meta, 7);
        if (Array.isArray(w)) out.url = w[0] || null;
      }
    }
    return out;
  }

  // Builds a Map<sourceId, parsedSource> from a GET_PROJECT response. Tries
  // both "response is the notebook array" and "response is [notebookArray]"
  // shapes defensively since this isn't confirmed by live testing.
  function parseNotebookSources(rawProject) {
    const tryShape = (t) => {
      const sourcesRaw = safeGet(t, 1);
      if (!Array.isArray(sourcesRaw)) return null;
      const map = new Map();
      for (const s of sourcesRaw) {
        const parsed = parseSourceRaw(s);
        if (parsed) map.set(parsed.id, parsed);
      }
      return map.size > 0 ? map : null;
    };
    return (
      tryShape(rawProject) ||
      (Array.isArray(rawProject) ? tryShape(rawProject[0]) : null) ||
      new Map()
    );
  }

  function formatSourcesForCsv(items) {
    if (!items || items.length === 0) return "";
    return items
      .map((s) => {
        const url = s.youtubeVideoId ? `https://www.youtube.com/watch?v=${s.youtubeVideoId}` : s.url;
        return url ? `${s.title} (${url})` : s.title;
      })
      .join(" | ");
  }

  // BEST-EFFORT style/format detection. The official extension never reads
  // this back from LIST_ARTIFACTS (it only uses these enums when *creating*
  // an artifact), so the exact index isn't confirmed by live testing. This
  // scans a few plausible sibling indices inside the audio/video sub-object
  // for a small integer matching a known enum value. Use the "Debug: log
  // raw item" link in the panel to confirm/correct the real index.
  function guessStyleLabel(kind, rawArtifact) {
    const subIdx = kind === "audio" ? 6 : 8;
    const sub = safeGet(rawArtifact, subIdx);
    if (!Array.isArray(sub)) return null;
    const table = kind === "audio" ? AUDIO_FORMAT_LABEL : VIDEO_FORMAT_LABEL;
    const candidates = kind === "audio" ? [0, 1, 4, 7, 8] : [0, 2, 6, 7, 8];
    for (const idx of candidates) {
      const v = sub[idx];
      if (typeof v === "number" && table[v]) return table[v];
    }
    return null;
  }

  // ── auth: find the active NotebookLM Tools account token in storage ──

  async function getActiveAccount() {
    const all = await chrome.storage.local.get(null);
    for (const key of Object.keys(all)) {
      const val = all[key];
      if (val && typeof val === "object" && typeof val.token === "string" && typeof val.email === "string") {
        return val; // flat active-account object
      }
      if (val && typeof val === "object" && val.accounts && val.activeAccount) {
        const acc = val.accounts[val.activeAccount];
        if (acc && typeof acc.token === "string") return acc;
      }
    }
    return null;
  }

  // ── RPC client (mirrors the extension's own batchexecute client) ─────

  async function callBatchExecute(account, notebookId, rpcId, args) {
    const urlParams = new URLSearchParams({
      bl: account.bl || DEFAULT_BL,
      hl: "en",
      "source-path": `/notebook/${encodeURIComponent(notebookId)}`,
      ...(account.fsid ? { "f.sid": account.fsid } : {}),
      ...(Number.isInteger(account.authuser) && account.authuser > 0
        ? { authuser: String(account.authuser) }
        : {}),
    });
    const body = new URLSearchParams({
      rpcids: rpcId,
      "f.req": JSON.stringify([[[rpcId, JSON.stringify(args), null, null]]]),
      at: account.token,
    });
    const res = await fetch(`${RPC_ENDPOINT}?${urlParams}`, {
      method: "POST",
      headers: {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "x-same-domain": "1",
      },
      body,
      credentials: "include",
    });
    const text = await res.text();
    const lines = text.split("\n").filter((l) => l.trim());
    let parsed = null;
    for (const line of lines) {
      try {
        const v = JSON.parse(line);
        if (Array.isArray(v) && v.length > 0) {
          parsed = v;
          break;
        }
      } catch {}
    }
    if (!parsed) throw new Error("Could not read NotebookLM response — are you logged in on notebooklm.google.com?");
    const d = parsed[0];
    const errCode = d && d[5] ? d[5][0] : null;
    if (errCode != null && errCode !== 0) {
      throw new Error(`NotebookLM RPC error ${errCode} — try reloading notebooklm.google.com and reopening this panel`);
    }
    return d && d[2] ? JSON.parse(d[2]) : null;
  }

  function parseArtifactRaw(raw, sourcesMap) {
    const id = safeGet(raw, 0);
    const title = safeGet(raw, 1) || "Untitled";
    const type = safeGet(raw, 2);
    const status = safeGet(raw, 4);
    if (!id) return null;
    const base = {
      id,
      title,
      type,
      status,
      isReady: status === STATUS_READY,
      typeLabel: ARTIFACT_TYPE_LABEL[type] || "Unknown",
    };

    // sources used for generation (index 3 on every artifact type)
    const sourceIds = extractSourceIds(safeGet(raw, 3));
    base.sourceIds = sourceIds;
    base.sources = sourcesMap ? sourceIds.map((sid) => sourcesMap.get(sid)).filter(Boolean) : [];

    // created/updated timestamps (indices 9-12, mirrors parseArtifactTimestamps)
    let createdAt = null, updatedAt = null;
    for (const idx of [9, 10, 11, 12]) {
      const parsed = parseTimestamp(safeGet(raw, idx));
      if (parsed) {
        if (!createdAt) createdAt = parsed;
        else if (!updatedAt) { updatedAt = parsed; break; }
      }
    }
    base.createdAt = createdAt;
    base.updatedAt = updatedAt;

    if (type === ARTIFACT_TYPE.AUDIO) {
      const e = safeGet(raw, 6);
      if (e) {
        base.mediaUrl = safeGet(e, 2);
        base.downloadUrl = safeGet(e, 3);
        base.duration = parseDuration(safeGet(e, 6));
        base.kind = "audio";
        base.styleLabel = guessStyleLabel("audio", raw);
      }
    } else if (type === ARTIFACT_TYPE.VIDEO) {
      const t2 = safeGet(raw, 8);
      if (t2) {
        base.mediaUrl = safeGet(t2, 1);
        base.downloadUrl = safeGet(t2, 3);
        base.duration = parseDuration(safeGet(t2, 5));
        base.kind = "video";
        base.styleLabel = guessStyleLabel("video", raw);
      }
    }
    return base;
  }

  async function fetchNotebookSources(account, notebookId) {
    try {
      const data = await callBatchExecute(account, notebookId, GET_PROJECT_RPC, [notebookId, null, [2]]);
      return parseNotebookSources(data);
    } catch (e) {
      console.warn("[BulkTools] could not load notebook sources for CSV enrichment:", e);
      return new Map();
    }
  }

  async function fetchAudioVideoArtifacts(account, notebookId) {
    const [data, sourcesMap] = await Promise.all([
      callBatchExecute(account, notebookId, LIST_ARTIFACTS_RPC, [
        [2],
        notebookId,
        'NOT artifact.status = "ARTIFACT_STATUS_SUGGESTED"',
      ]),
      fetchNotebookSources(account, notebookId),
    ]);
    if (!Array.isArray(data)) return [];
    const list = Array.isArray(data[0]) ? data[0] : data;
    if (!Array.isArray(list)) return [];
    const parsed = list
      .map((raw) => parseArtifactRaw(raw, sourcesMap))
      .filter((a) => a && a.isReady && a.kind && (a.mediaUrl || a.downloadUrl));
    if (parsed.length) {
      window.__bulkToolsLastRaw = list; // for the "Debug: log raw item" helper below
    }
    return parsed;
  }

  function detectNotebookId() {
    const m = location.hash.match(/\/notebook\/([a-zA-Z0-9_-]+)/);
    return m ? m[1] : "";
  }


  // ── styles ─────────────────────────────────────────────────────────

  const style = document.createElement("style");
  style.textContent = `
    #bt-fab {
      position: fixed !important; left: 0 !important; top: 0 !important; right: 0 !important;
      width: 100% !important; box-sizing: border-box !important;
      z-index: 2147483647 !important;
      background: linear-gradient(90deg, #ff5a1f, #ff8a00) !important; color: #fff !important;
      border: none !important; border-radius: 0 !important;
      padding: 12px 16px !important; font: 800 15px system-ui, sans-serif !important; cursor: pointer !important;
      box-shadow: 0 2px 10px rgba(0,0,0,.35) !important;
      display: flex !important; align-items: center; justify-content: center; gap: 8px;
      letter-spacing: .3px; text-shadow: 0 1px 2px rgba(0,0,0,.25);
      animation: bt-pulse 1.8s ease-in-out infinite;
    }
    #bt-fab:hover { filter: brightness(1.08); }
    @keyframes bt-pulse {
      0%, 100% { box-shadow: 0 2px 10px rgba(255,90,31,.35); }
      50% { box-shadow: 0 2px 22px rgba(255,90,31,.85); }
    }
    #bt-fab .bt-fab-badge {
      background: #111827; color: #fff; border-radius: 999px; padding: 2px 8px; font-size: 11px; font-weight: 700;
    }
    #bt-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 2147483646;
      display: flex; align-items: center; justify-content: center; padding: 16px;
      font: 13px system-ui, -apple-system, sans-serif;
    }
    #bt-modal {
      background: #fff; color: #111827; width: 100%; max-width: 820px; max-height: 92vh;
      border-radius: 10px; display: flex; flex-direction: column; overflow: hidden;
      box-shadow: 0 20px 60px rgba(0,0,0,.35);
    }
    #bt-header {
      padding: 12px 16px; border-bottom: 1px solid #e5e7eb; display: flex;
      align-items: center; justify-content: space-between; gap: 8px;
    }
    #bt-header h2 { font-size: 14px; margin: 0; font-weight: 700; }
    #bt-close { background: none; border: none; font-size: 18px; cursor: pointer; color: #6b7280; }
    #bt-body { padding: 12px 16px; overflow-y: auto; flex: 1; }
    .bt-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; }
    .bt-btn {
      background: #111827; color: #fff; border: none; border-radius: 6px; padding: 7px 12px;
      font-size: 12px; font-weight: 600; cursor: pointer;
    }
    .bt-btn:disabled { opacity: .45; cursor: not-allowed; }
    .bt-btn.secondary { background: #fff; color: #111827; border: 1px solid #d1d5db; }
    .bt-btn.cloud { background: #0ea5e9; }
    .bt-btn.telegram { background: #229ed9; }
    .bt-btn.details { background: #15803d; }
    .bt-btn.danger { background: #dc2626; }
    .bt-btn.lovable {
      background: linear-gradient(90deg, #7c3aed, #d946ef); box-shadow: 0 2px 10px rgba(124,58,237,.4);
      font-weight: 800;
    }
    .bt-btn.lovable:hover:not(:disabled) { filter: brightness(1.08); }
    #bt-lovable-cred-form { display: none; gap: 8px; flex-direction: column; margin: 8px 0; padding: 10px;
      border: 1px solid #e5e7eb; border-radius: 8px; background: #fafafa; }
    #bt-lovable-cred-form input {
      padding: 6px 8px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 12px;
    }
    #bt-lovable-cred-form label { font-size: 11px; font-weight: 600; color: #374151; }
    #bt-toast {
      position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
      background: #111827; color: #fff; border-radius: 10px; padding: 12px 16px;
      font: 13px system-ui, sans-serif; display: flex; align-items: center; gap: 12px;
      box-shadow: 0 8px 24px rgba(0,0,0,.4); z-index: 2147483647; max-width: 92vw;
      animation: bt-toast-in .2s ease-out;
    }
    #bt-toast.bt-toast-error { background: #7f1d1d; }
    #bt-toast.bt-toast-success { background: #14532d; }
    @keyframes bt-toast-in { from { opacity: 0; transform: translateX(-50%) translateY(10px); } to { opacity: 1; transform: translateX(-50%) translateY(0); } }
    #bt-toast .bt-toast-msg { flex: 1; }
    #bt-toast .bt-toast-link {
      background: #fff; color: #111827; border: none; border-radius: 6px; padding: 5px 10px;
      font-size: 12px; font-weight: 700; cursor: pointer; white-space: nowrap;
    }
    #bt-toast .bt-toast-close {
      background: none; border: none; color: #fff; opacity: .7; font-size: 15px; cursor: pointer; padding: 0 2px;
    }
    #bt-status { font-size: 12px; color: #6b7280; }
    table.bt-table { width: 100%; border-collapse: collapse; font-size: 12px; }
    table.bt-table th, table.bt-table td {
      border-bottom: 1px solid #f0f0f0; padding: 6px 8px; text-align: left; vertical-align: middle;
    }
    table.bt-table th { position: sticky; top: 0; background: #fafafa; font-weight: 600; }
    .bt-badge {
      display: inline-block; padding: 1px 6px; border-radius: 999px; font-size: 10px; font-weight: 700;
    }
    .bt-badge.video { background: #dcfce7; color: #15803d; }
    .bt-badge.audio { background: #dbeafe; color: #1d4ed8; }
    .bt-progress-wrap { margin: 8px 0; }
    .bt-progress-bar-bg { background: #e5e7eb; border-radius: 999px; height: 8px; overflow: hidden; }
    .bt-progress-bar-fg { background: #111827; height: 100%; transition: width .2s ease; }
    .bt-status-ok { color: #15803d; font-weight: 700; }
    .bt-status-fail { color: #dc2626; font-weight: 700; }
    .bt-status-pending { color: #9ca3af; }
    #bt-results-wrap { margin-top: 14px; border-top: 1px dashed #e5e7eb; padding-top: 10px; }

    /* Floating "Send N items to Lovable" pill — deliberately NOT injected
       into NotebookLM's own native "N selected" toolbar, since that toolbar
       is already tightly packed (Cancel/Rename/Download/Delete) and clips
       extra buttons off-screen on narrow/mobile viewports. This pill is
       fixed-position and independent of that layout, so it's always visible
       whenever anything is checked, on any screen size.
       Bottom-anchored (not top) so it can't end up underneath this
       extension's own account-switcher panel, which also occupies fixed
       space just below the orange banner. */
    #bt-native-lovable-fab {
      position: fixed !important;
      bottom: 84px !important;
      left: 50% !important; transform: translateX(-50%) !important;
      z-index: 2147483647 !important;
      background: linear-gradient(90deg, #7c3aed, #d946ef) !important; color: #fff !important;
      border: none !important; border-radius: 999px !important;
      padding: 10px 18px !important; font: 800 13px system-ui, sans-serif !important;
      cursor: pointer !important; white-space: nowrap;
      box-shadow: 0 4px 18px rgba(124,58,237,.55) !important;
      display: flex !important; align-items: center; gap: 6px;
      animation: bt-native-fab-pulse 1.6s ease-in-out infinite;
    }
    #bt-native-lovable-fab:hover { filter: brightness(1.1); }
    @keyframes bt-native-fab-pulse {
      0%, 100% { box-shadow: 0 4px 18px rgba(124,58,237,.55); }
      50% { box-shadow: 0 4px 26px rgba(217,70,239,.9); }
    }
  `;
  document.documentElement.appendChild(style);

  // ── modal HTML ─────────────────────────────────────────────────────

  let overlay = null;
  let artifacts = []; // all loaded audio+video artifacts
  let selected = new Set();

  function injectFab() {
    if (document.getElementById("bt-fab")) return;
    const target = document.body || document.documentElement;
    const fab = document.createElement("button");
    fab.id = "bt-fab";
    fab.innerHTML = `🎬 IRFANLM TOOLS — BULK VIDEO / AUDIO <span class="bt-fab-badge">Download All + Cloudinary Export</span>`;
    fab.addEventListener("click", openModal);
    target.insertBefore(fab, target.firstChild);
    // push page content down so the banner doesn't cover the app's own header
    requestAnimationFrame(() => {
      const h = fab.offsetHeight || 44;
      document.documentElement.style.setProperty("--bt-banner-h", h + "px");
      if (document.body) document.body.style.marginTop = h + "px";
    });
    console.log("[BulkTools] banner injected into", target === document.body ? "document.body" : "document.documentElement");
  }

  // Try immediately, on DOMContentLoaded, and with a couple of delayed
  // retries — belt-and-suspenders in case this SPA hasn't finished its
  // own initial render yet when this script executes.
  injectFab();
  document.addEventListener("DOMContentLoaded", injectFab);
  setTimeout(injectFab, 300);
  setTimeout(injectFab, 1500);
  new MutationObserver(() => injectFab()).observe(document.documentElement, { childList: true, subtree: false });

  // ── native Studio selection toolbar: "N selected / Cancel / Rename / Download" ─
  //
  // v1.15.0 tried appending our button *into* that native toolbar (found by
  // walking text nodes for "N selected", then climbing up to a "Download"
  // button). Root-caused why that wasn't showing up: the native toolbar is
  // already tightly packed on narrow/mobile viewports (Cancel + Rename +
  // Download + Delete visibly crowd the row, with the trash icon itself
  // clipped in testing) — an appended button just gets pushed off-screen or
  // never gets a chance to render before the next re-render wipes it out.
  //
  // Fix: stop trying to live inside NotebookLM's toolbar at all. Instead,
  // detect the "N selected" text (still via text-node walking — there's no
  // stable class name to target) purely to read the *count*, and render our
  // own fixed-position pill that floats independently of that toolbar's
  // layout. It can't be clipped, crowded, or wiped out by NotebookLM's own
  // re-renders, and it doubles as visible confirmation of the live count.

  const NATIVE_FAB_ID = "bt-native-lovable-fab";
  // Matches "50 selected" as it actually appears when the label and count
  // may be split across separate nested nodes (e.g. a <span>50</span> next
  // to a plain-text "selected") — a per-text-node walker misses that split,
  // since neither node alone contains the full phrase. Searching the page's
  // aggregated rendered text sidesteps the DOM structure entirely.
  const SELECTED_COUNT_RE = /(\d+)\s*selected\b/i;
  const AGO_RE = /\b\d+\s*(sec|secs|second|seconds|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days|mo|mos|month|months|y|yr|yrs|year|years)\s*ago\b/i;
  const NON_TITLE_RE = /^(video|audio|report|quiz|flashcards|mind map|infographic|slide deck|data table|note)$/i;
  const FROM_SOURCES_RE = /^from\s+\d+\s+sources?$/i;

  function getNativeSelectedCount() {
    const root = document.body || document.documentElement;
    // innerText (not textContent) so hidden/off-screen duplicate UI (e.g.
    // a closed dropdown's markup still in the DOM) doesn't produce a false
    // match — innerText only reflects what's actually rendered.
    const text = (root.innerText || root.textContent || "").replace(/\s+/g, " ");
    const m = SELECTED_COUNT_RE.exec(text);
    return m ? parseInt(m[1], 10) : 0;
  }

  function syncNativeSendButton() {
    let btn = document.getElementById(NATIVE_FAB_ID);
    if (overlay) {
      // Don't clutter the page while our own modal is already open.
      if (btn) btn.remove();
      return;
    }
    const count = getNativeSelectedCount();
    if (count !== syncNativeSendButton._lastLoggedCount) {
      console.log("[BulkTools] native selection count detected:", count);
      syncNativeSendButton._lastLoggedCount = count;
    }
    if (count > 0) {
      const root = document.body || document.documentElement;
      if (!btn) {
        btn = document.createElement("button");
        btn.id = NATIVE_FAB_ID;
        btn.type = "button";
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          onSendToLovableFromNative();
        });
      }
      // Re-append even if it already exists: keeps it the last element in
      // DOM order, so it wins paint order over any same-z-index overlay
      // this page (including this extension's own account-switcher panel)
      // appends after it.
      root.appendChild(btn);
      btn.textContent = `🚀 Send ${count} item${count === 1 ? "" : "s"} to Lovable`;
    } else if (btn) {
      btn.remove();
    }
  }

  // Best-effort: read which item rows have a checked checkbox on the native
  // page (outside our own modal) and pull a title guess out of each row.
  // NotebookLM's row markup isn't documented, so this leans on two visible-
  // text signals that are unlikely to disappear: a relative "N ago" created
  // date, and a type badge (Video/Audio/etc) — both present in every Studio
  // row per the screenshots this was built against. If NotebookLM's layout
  // changes enough to break this, it fails safe (returns []) rather than
  // guessing wrong, and the caller falls back to the picker modal.
  function scrapeCheckedNativeTitles() {
    const titles = [];
    try {
      const boxes = document.querySelectorAll('input[type="checkbox"]:checked');
      for (const box of boxes) {
        if (box.closest("#bt-overlay, #bt-fab, #bt-toast")) continue;
        let row = box.parentElement;
        let matchedRow = null;
        for (let i = 0; i < 6 && row; i++, row = row.parentElement) {
          if (AGO_RE.test(row.textContent)) {
            matchedRow = row;
            break;
          }
        }
        if (!matchedRow) continue; // most likely the "select all" header checkbox, not an item row

        const walker = document.createTreeWalker(matchedRow, NodeFilter.SHOW_TEXT);
        let best = "";
        let n;
        while ((n = walker.nextNode())) {
          const t = n.textContent.trim();
          if (!t || NON_TITLE_RE.test(t) || AGO_RE.test(t) || FROM_SOURCES_RE.test(t) || SELECTED_COUNT_RE.test(t)) continue;
          if (t.length > best.length) best = t;
        }
        if (best) titles.push(best);
      }
    } catch (e) {
      console.warn("[BulkTools] scrapeCheckedNativeTitles failed:", e);
      return [];
    }
    return [...new Set(titles)];
  }

  function titlesRoughlyMatch(a, b) {
    const na = (a || "").trim().toLowerCase().replace(/\s+/g, " ");
    const nb = (b || "").trim().toLowerCase().replace(/\s+/g, " ");
    if (!na || !nb) return false;
    return na === nb || na.startsWith(nb) || nb.startsWith(na);
  }

  async function onSendToLovableFromNative() {
    const scrapedTitles = scrapeCheckedNativeTitles();
    const notebookId = detectNotebookId();
    if (!notebookId) {
      showToast('Could not detect a notebook ID from the URL — open a notebook first.', { variant: "error", autoHideMs: 6000 });
      return;
    }

    openModal();
    document.getElementById("bt-notebook-id").value = notebookId;
    await loadArtifacts(); // fetches full list via RPC; defaults to all-selected

    if (scrapedTitles.length > 0) {
      const matchedIds = new Set(
        artifacts.filter((a) => scrapedTitles.some((t) => titlesRoughlyMatch(a.title, t))).map((a) => a.id)
      );
      if (matchedIds.size > 0) {
        selected = matchedIds;
        renderTable();
        showToast(
          `Matched ${matchedIds.size} of ${scrapedTitles.length} item(s) you had checked. Review below, then click 🚀 Send to Lovable.`,
          { autoHideMs: 7000 }
        );
      } else {
        showToast(
          "Couldn't match your checked items by name — all items are selected below instead. Adjust and click 🚀 Send to Lovable.",
          { variant: "error", autoHideMs: 7000 }
        );
      }
    } else {
      showToast(
        "Couldn't detect which items were checked — all items are selected below. Adjust and click 🚀 Send to Lovable.",
        { autoHideMs: 7000 }
      );
    }

    document.getElementById("bt-send-lovable")?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  // The "N selected" label only exists in the DOM while items are checked,
  // so this needs subtree observation (unlike the top-level FAB banner).
  // Debounced so a busy SPA re-rendering rows doesn't re-scan on every
  // single mutation.
  let nativeBtnDebounce = null;
  new MutationObserver(() => {
    clearTimeout(nativeBtnDebounce);
    nativeBtnDebounce = setTimeout(syncNativeSendButton, 200);
  }).observe(document.body || document.documentElement, { childList: true, subtree: true });

  // Belt-and-suspenders poll: covers the case where NotebookLM updates the
  // counter text via a mechanism the observer's { childList, subtree }
  // scope doesn't catch (e.g. text-only updates in some SPA render paths).
  setInterval(syncNativeSendButton, 1000);
  syncNativeSendButton();

  function openModal() {
    if (overlay) return;
    overlay = document.createElement("div");
    overlay.id = "bt-overlay";
    overlay.innerHTML = `
      <div id="bt-modal">
        <div id="bt-header">
          <h2>IrfanLM Tools — Bulk Video / Audio Export</h2>
          <button id="bt-close" title="Close">✕</button>
        </div>
        <div id="bt-body">
          <div class="bt-row">
            <span>Notebook ID:</span>
            <input id="bt-notebook-id" type="text" style="flex:1;min-width:160px;padding:5px 7px;border:1px solid #d1d5db;border-radius:6px;font-size:12px" value="${detectNotebookId()}" placeholder="paste notebook ID or open a notebook first" />
            <button class="bt-btn secondary" id="bt-load">Load Audio + Video</button>
          </div>
          <div id="bt-status"></div>

          <div class="bt-row" id="bt-actions" style="display:none">
            <label style="display:flex;align-items:center;gap:4px"><input type="checkbox" id="bt-select-all"/> Select all</label>
            <span id="bt-count" style="color:#6b7280"></span>
            <button class="bt-btn details" id="bt-details-csv">📄 Download Details CSV (before export)</button>
            <button class="bt-btn" id="bt-download-all" disabled>⬇ Download Selected (one by one)</button>
            <button class="bt-btn cloud" id="bt-cloud-all" disabled>☁ Export Selected to Cloudinary</button>
            <button class="bt-btn telegram" id="bt-telegram-all" disabled>✈ Send Selected to Telegram</button>
            <button class="bt-btn lovable" id="bt-send-lovable" disabled>🚀 Send to Lovable</button>
            <button class="bt-btn secondary" id="bt-relay-cred-toggle">Railway Relay Settings</button>
            <button class="bt-btn secondary" id="bt-lovable-cred-toggle">Lovable Cloud Settings</button>
            <button class="bt-btn secondary" id="bt-debug-log" title="Logs the raw first selected item to the console — useful for verifying the Style column">🔍 Debug: log raw item</button>
          </div>

          <div id="bt-lovable-cred-form">
            <label>Webhook Endpoint URL<input id="bt-lovable-endpoint" type="text" placeholder="${DEFAULT_LOVABLE_ENDPOINT}" /></label>
            <label>API Key<input id="bt-lovable-key" type="password" placeholder="sent as Authorization: Bearer <key>" /></label>
            <label>Progress Page URL (optional)<input id="bt-lovable-progress" type="text" placeholder="${DEFAULT_LOVABLE_BASE}/" /></label>
            <div style="display:flex;gap:8px">
              <button class="bt-btn secondary" id="bt-lovable-cred-save">Save credentials</button>
              <span id="bt-lovable-cred-saved-msg" style="color:#15803d;font-size:11px;align-self:center"></span>
            </div>
          </div>

          <div id="bt-relay-cred-form">
            <label>Railway Relay Server URL<input id="bt-relay-url" type="url" placeholder="https://your-app.up.railway.app" /></label>
            <label>Relay Token (AUTH_SECRET)<input id="bt-relay-token" type="password" placeholder="keep this private" /></label>
            <label>Telegram Chat ID<input id="bt-relay-chat" type="text" placeholder="e.g. -1001234567890 or @yourchannel" /></label>
            <p style="margin:4px 0;color:#6b7280;font-size:11px">The Telegram bot token and Cloudinary secrets remain on Railway. The extension sends only a fresh signed media URL and metadata.</p>
            <div style="display:flex;gap:8px">
              <button class="bt-btn secondary" id="bt-relay-save">Save relay settings</button>
              <span id="bt-relay-saved-msg" style="color:#15803d;font-size:11px;align-self:center"></span>
            </div>
          </div>

          <div id="bt-table-wrap"></div>

          <div class="bt-progress-wrap" id="bt-progress-wrap" style="display:none">
            <div id="bt-progress-label" style="font-size:12px;margin-bottom:4px"></div>
            <div class="bt-progress-bar-bg"><div class="bt-progress-bar-fg" id="bt-progress-bar" style="width:0%"></div></div>
          </div>

          <div id="bt-results-wrap" style="display:none">
            <div class="bt-row">
              <strong>Results</strong>
              <button class="bt-btn secondary" id="bt-copy-table">Copy table</button>
              <button class="bt-btn secondary" id="bt-download-csv">Download CSV</button>
            </div>
            <div id="bt-results-table-wrap"></div>
          </div>
        </div>
      </div>
    `;
    document.documentElement.appendChild(overlay);

    document.getElementById("bt-close").onclick = closeModal;
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeModal();
    });
    document.getElementById("bt-load").onclick = loadArtifacts;
    document.getElementById("bt-select-all").onchange = onSelectAll;
    document.getElementById("bt-details-csv").onclick = downloadDetailsCsv;
    document.getElementById("bt-download-all").onclick = onDownloadAll;
    document.getElementById("bt-cloud-all").onclick = onCloudAll;
    document.getElementById("bt-telegram-all").onclick = onTelegramAll;
    document.getElementById("bt-send-lovable").onclick = onSendToLovable;
    document.getElementById("bt-relay-cred-toggle").onclick = () => {
      const f = document.getElementById("bt-relay-cred-form");
      f.style.display = f.style.display === "flex" ? "none" : "flex";
    };
    document.getElementById("bt-relay-save").onclick = saveRelayCreds;
    document.getElementById("bt-lovable-cred-toggle").onclick = () => {
      const f = document.getElementById("bt-lovable-cred-form");
      f.style.display = f.style.display === "flex" ? "none" : "flex";
    };
    document.getElementById("bt-lovable-cred-save").onclick = saveLovableCreds;
    document.getElementById("bt-debug-log").onclick = () => {
      const items = selectedItems();
      if (items.length === 0) {
        setStatus("Select at least one item first.", true);
        return;
      }
      const raw = (window.__bulkToolsLastRaw || []).find((r) => safeGet(r, 0) === items[0].id);
      console.log("[BulkTools] parsed item:", items[0]);
      console.log("[BulkTools] raw artifact array (inspect this to confirm/fix the Style index):", raw);
      setStatus(`Logged "${items[0].title}" (parsed + raw) to the console. Open DevTools > Console.`);
    };
    document.getElementById("bt-copy-table").onclick = copyResultsTable;
    document.getElementById("bt-download-csv").onclick = downloadResultsCsv;

    loadRelayCreds();
    loadLovableCreds();
    resyncFromBackground();
  }

  function closeModal() {
    if (overlay) overlay.remove();
    overlay = null;
    syncNativeSendButton(); // items may still be checked natively — bring the pill back if so
  }

  function setStatus(msg, isError) {
    const el = document.getElementById("bt-status");
    if (!el) return;
    el.textContent = msg || "";
    el.style.color = isError ? "#dc2626" : "#6b7280";
  }

  // ── toast notifications ──────────────────────────────────────────────

  let toastTimer = null;

  function showToast(message, { variant = "info", linkLabel, linkUrl, autoHideMs } = {}) {
    hideToast();
    const toast = document.createElement("div");
    toast.id = "bt-toast";
    if (variant === "error") toast.classList.add("bt-toast-error");
    if (variant === "success") toast.classList.add("bt-toast-success");

    const msgEl = document.createElement("span");
    msgEl.className = "bt-toast-msg";
    msgEl.textContent = message;
    toast.appendChild(msgEl);

    if (linkUrl) {
      const linkBtn = document.createElement("button");
      linkBtn.className = "bt-toast-link";
      linkBtn.textContent = linkLabel || "Open →";
      linkBtn.onclick = () => window.open(linkUrl, "_blank", "noopener");
      toast.appendChild(linkBtn);
    }

    const closeBtn = document.createElement("button");
    closeBtn.className = "bt-toast-close";
    closeBtn.textContent = "✕";
    closeBtn.onclick = hideToast;
    toast.appendChild(closeBtn);

    document.documentElement.appendChild(toast);
    if (autoHideMs) toastTimer = setTimeout(hideToast, autoHideMs);
  }

  function hideToast() {
    clearTimeout(toastTimer);
    const existing = document.getElementById("bt-toast");
    if (existing) existing.remove();
  }

  // ── Railway relay credentials ────────────────────────────────────────

  async function loadRelayCreds() {
    const resp = await chrome.runtime.sendMessage({ __bulkTools: true, type: "GET_RELAY_CREDS" });
    const c = resp?.creds || {};
    document.getElementById("bt-relay-url").value = c.relayServerUrl || "";
    document.getElementById("bt-relay-token").value = c.relayToken || "";
    document.getElementById("bt-relay-chat").value = c.telegramChatId || "";
  }

  async function saveRelayCreds() {
    const creds = {
      relayServerUrl: document.getElementById("bt-relay-url").value.trim(),
      relayToken: document.getElementById("bt-relay-token").value.trim(),
      telegramChatId: document.getElementById("bt-relay-chat").value.trim(),
    };
    await chrome.runtime.sendMessage({ __bulkTools: true, type: "SAVE_RELAY_CREDS", creds });
    const msg = document.getElementById("bt-relay-saved-msg");
    msg.textContent = "Saved ✓";
    setTimeout(() => (msg.textContent = ""), 2000);
  }

  async function getRelayCreds() {
    const resp = await chrome.runtime.sendMessage({ __bulkTools: true, type: "GET_RELAY_CREDS" });
    return resp?.creds || null;
  }

  // ── Lovable Cloud credentials ───────────────────────────────────────

  async function loadLovableCreds() {
    const r = await chrome.storage.local.get(LOVABLE_CRED_KEY);
    const c = r[LOVABLE_CRED_KEY];
    document.getElementById("bt-lovable-endpoint").value = c?.endpoint || "";
    document.getElementById("bt-lovable-key").value = c?.apiKey || "";
    document.getElementById("bt-lovable-progress").value = c?.progressUrl || "";
  }

  async function saveLovableCreds() {
    const creds = {
      endpoint: document.getElementById("bt-lovable-endpoint").value.trim() || DEFAULT_LOVABLE_ENDPOINT,
      apiKey: document.getElementById("bt-lovable-key").value.trim(),
      progressUrl: document.getElementById("bt-lovable-progress").value.trim() || DEFAULT_LOVABLE_BASE + "/",
    };
    await chrome.storage.local.set({ [LOVABLE_CRED_KEY]: creds });
    await chrome.runtime.sendMessage({ __bulkTools: true, type: "SAVE_LOVABLE_CREDS", creds });
    const msg = document.getElementById("bt-lovable-cred-saved-msg");
    msg.textContent = "Saved ✓";
    setTimeout(() => (msg.textContent = ""), 2000);
  }

  async function getLovableCreds() {
    const r = await chrome.storage.local.get(LOVABLE_CRED_KEY);
    return (
      r[LOVABLE_CRED_KEY] || {
        endpoint: DEFAULT_LOVABLE_ENDPOINT,
        apiKey: "",
        progressUrl: DEFAULT_LOVABLE_BASE + "/",
      }
    );
  }

  // ── load + render artifact table ──────────────────────────────────

  async function loadArtifacts() {
    const notebookId = document.getElementById("bt-notebook-id").value.trim();
    if (!notebookId) {
      setStatus("Enter or detect a notebook ID first.", true);
      return;
    }
    setStatus("Loading…");
    document.getElementById("bt-actions").style.display = "none";
    document.getElementById("bt-table-wrap").innerHTML = "";
    try {
      const account = await getActiveAccount();
      if (!account) throw new Error("No connected NotebookLM account found — connect an account in this extension first.");
      artifacts = await fetchAudioVideoArtifacts(account, notebookId);
      selected = new Set(artifacts.map((a) => a.id));
      if (artifacts.length === 0) {
        setStatus("No ready Audio/Video Studio outputs found in this notebook.");
      } else {
        setStatus(`Loaded ${artifacts.length} item(s) — all shown on one page, all selected by default.`);
      }
      renderTable();
      document.getElementById("bt-actions").style.display = "flex";
      updateActionButtons();
    } catch (e) {
      setStatus(e.message || String(e), true);
    }
  }

  function renderTable() {
    const wrap = document.getElementById("bt-table-wrap");
    if (artifacts.length === 0) {
      wrap.innerHTML = "";
      return;
    }
    const rows = artifacts
      .map(
        (a) => `
      <tr>
        <td><input type="checkbox" class="bt-row-check" data-id="${a.id}" ${selected.has(a.id) ? "checked" : ""}/></td>
        <td>${escapeHtml(a.title)}</td>
        <td><span class="bt-badge ${a.kind}">${a.kind}</span></td>
        <td>${fmtDuration(a.duration)}</td>
      </tr>`
      )
      .join("");
    wrap.innerHTML = `
      <table class="bt-table">
        <thead><tr><th></th><th>Name</th><th>Type</th><th>Duration</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
    wrap.querySelectorAll(".bt-row-check").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = e.target.getAttribute("data-id");
        if (e.target.checked) selected.add(id);
        else selected.delete(id);
        updateActionButtons();
      });
    });
    updateActionButtons();
  }

  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function onSelectAll(e) {
    selected = e.target.checked ? new Set(artifacts.map((a) => a.id)) : new Set();
    renderTable();
  }

  function updateActionButtons() {
    const count = selected.size;
    document.getElementById("bt-count").textContent = `${count} selected`;
    document.getElementById("bt-download-all").disabled = count === 0;
    document.getElementById("bt-cloud-all").disabled = count === 0;
    document.getElementById("bt-telegram-all").disabled = count === 0;
    document.getElementById("bt-send-lovable").disabled = count === 0;
    document.getElementById("bt-details-csv").disabled = count === 0;
    document.getElementById("bt-debug-log").disabled = count === 0;
  }

  function selectedItems() {
    return artifacts.filter((a) => selected.has(a.id));
  }

  // ── download queue wiring ─────────────────────────────────────────

  async function onDownloadAll() {
    const items = selectedItems();
    if (items.length === 0) return;
    document.getElementById("bt-progress-wrap").style.display = "block";
    document.getElementById("bt-results-wrap").style.display = "none";
    await chrome.runtime.sendMessage({ __bulkTools: true, type: "START_DOWNLOAD", items });
  }

  async function onCloudAll() {
    const items = selectedItems();
    if (items.length === 0) return;
    const creds = await getRelayCreds();
    if (!creds || !creds.relayServerUrl || !creds.relayToken) {
      setStatus("Configure the Railway Relay Server URL and Relay Token first.", true);
      document.getElementById("bt-relay-cred-form").style.display = "flex";
      return;
    }
    // notebookId lets the background queue refresh each item's mediaUrl
    // right before upload — these are short-lived signed URLs, so a stale
    // one captured when the list first loaded can otherwise fail.
    const notebookId = document.getElementById("bt-notebook-id").value.trim();
    document.getElementById("bt-progress-wrap").style.display = "block";
    document.getElementById("bt-results-wrap").style.display = "none";
    await chrome.runtime.sendMessage({ __bulkTools: true, type: "START_CLOUDINARY", items, creds, notebookId });
  }

  async function onTelegramAll() {
    const items = selectedItems();
    if (items.length === 0) return;
    const creds = await getRelayCreds();
    if (!creds || !creds.relayServerUrl || !creds.relayToken || !creds.telegramChatId) {
      setStatus("Configure the Railway Relay URL, Relay Token, and Telegram Chat ID first.", true);
      document.getElementById("bt-relay-cred-form").style.display = "flex";
      return;
    }
    const notebookId = document.getElementById("bt-notebook-id").value.trim();
    document.getElementById("bt-progress-wrap").style.display = "block";
    document.getElementById("bt-results-wrap").style.display = "none";
    await chrome.runtime.sendMessage({ __bulkTools: true, type: "START_TELEGRAM", items, creds, notebookId });
  }

  async function onSendToLovable() {
    const items = selectedItems();
    if (items.length === 0) {
      setStatus("Select at least one item first.", true);
      return;
    }

    const notebookId = document.getElementById("bt-notebook-id").value.trim();
    if (!notebookId) {
      setStatus('"notebookId" is required — enter or detect a notebook ID before sending.', true);
      return;
    }

    const creds = await getLovableCreds();
    if (!creds.endpoint) {
      setStatus("Add your Lovable Cloud webhook endpoint in Lovable Cloud Settings first.", true);
      document.getElementById("bt-lovable-cred-form").style.display = "flex";
      return;
    }

    showToast(`Sending ${items.length} item${items.length === 1 ? "" : "s"} to Lovable Cloud...`, {
      variant: "info",
      linkLabel: "Open Lovable Progress →",
      linkUrl: creds.progressUrl || DEFAULT_LOVABLE_BASE + "/",
    });

    const resp = await chrome.runtime.sendMessage({
      __bulkTools: true,
      type: "SEND_TO_LOVABLE",
      items,
      notebookId,
      creds,
    });

    if (!resp?.ok) {
      showToast(resp?.error || "Failed to start Lovable Cloud sync.", { variant: "error", autoHideMs: 8000 });
    }
  }

  const QUEUE_LABELS = {
    download: { verb: "Downloading", noun: "Download" },
    cloudinary: { verb: "Uploading to Cloudinary", noun: "Cloudinary export" },
    telegram: { verb: "Sending to Telegram", noun: "Telegram send" },
  };

  function updateProgressUI(queueName, state) {
    if (!overlay || !state) return;
    const label = document.getElementById("bt-progress-label");
    const bar = document.getElementById("bt-progress-bar");
    const total = state.items?.length || 0;
    const done = state.results?.length || 0;
    const pct = total ? Math.round((done / total) * 100) : 0;
    bar.style.width = pct + "%";
    const currentTitle = state.items?.[state.index]?.title;
    const labels = QUEUE_LABELS[queueName] || QUEUE_LABELS.download;
    if (state.done) {
      label.textContent = `${labels.noun} finished — ${done}/${total} processed.`;
      renderResults(state.results, queueName);
    } else {
      label.textContent = `${labels.verb} ${done + 1}/${total}${currentTitle ? ": " + currentTitle : ""}…`;
    }
  }

  async function resyncFromBackground() {
    const resp = await chrome.runtime.sendMessage({ __bulkTools: true, type: "GET_STATE" });
    if (!resp?.ok) return;
    if (resp.download && resp.download.items?.length) {
      document.getElementById("bt-progress-wrap").style.display = "block";
      updateProgressUI("download", resp.download);
    } else if (resp.cloudinary && resp.cloudinary.items?.length) {
      document.getElementById("bt-progress-wrap").style.display = "block";
      updateProgressUI("cloudinary", resp.cloudinary);
    } else if (resp.telegram && resp.telegram.items?.length) {
      document.getElementById("bt-progress-wrap").style.display = "block";
      updateProgressUI("telegram", resp.telegram);
    }
    if (resp.lovable && resp.lovable.items?.length && !resp.lovable.done) {
      showToast(`Sending ${resp.lovable.items.length} item(s) to Lovable Cloud...`, { variant: "info" });
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || !msg.__bulkTools) return;
    if (msg.type === "PROGRESS") {
      updateProgressUI(msg.queue, msg.state);
    } else if (msg.type === "LOVABLE_PROGRESS" && msg.state?.done) {
      if (msg.state.ok) {
        showToast(`✓ Sent ${msg.state.items.length} item(s) to Lovable Cloud.`, {
          variant: "success",
          autoHideMs: 5000,
        });
        setStatus(`Sent ${msg.state.items.length} item(s) to Lovable Cloud.`);
      } else {
        showToast(msg.state.error || "Lovable Cloud sync failed.", { variant: "error", autoHideMs: 8000 });
        setStatus(msg.state.error || "Lovable Cloud sync failed.", true);
      }
    }
  });

  // ── results table: copy + CSV ─────────────────────────────────────

  // ── shared detail columns (used by both the pre-export CSV and the
  // post-download/post-Cloudinary results CSV, so the two stay consistent) ──

  const DETAIL_HEADER = [
    "Name",
    "File Type",
    "Sources used (YouTube URL if applicable)",
    "Duration",
    "Date Generated",
    "Time Generated",
    "Style",
  ];

  function detailColumns(item) {
    return [
      item.title,
      item.typeLabel || item.kind || "",
      formatSourcesForCsv(item.sources),
      fmtDuration(item.duration),
      fmtDate(item.createdAt),
      fmtTime(item.createdAt),
      item.styleLabel || "Unknown",
    ];
  }

  function buildCsv(header, rows) {
    return [header, ...rows].map((r) => r.map(escCsv).join(",")).join("\r\n");
  }

  function triggerCsvDownload(csv, filename) {
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.documentElement.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  // NEW: "Download Details CSV (before export)" — full metadata for the
  // currently selected items, with no download/upload required first.
  function downloadDetailsCsv() {
    const items = selectedItems();
    if (items.length === 0) {
      setStatus("Select at least one item first.", true);
      return;
    }
    const rows = items.map(detailColumns);
    const csv = buildCsv(DETAIL_HEADER, rows);
    triggerCsvDownload(csv, `notebooklm-details-${Date.now()}.csv`);
    setStatus(`Downloaded details CSV for ${items.length} item(s).`);
  }

  // ── results table (after download / after Cloudinary export): copy + CSV ──

  let lastResults = [];
  let lastQueueKind = "download";

  function renderResults(results, queueKind) {
    lastResults = results || [];
    lastQueueKind = queueKind;
    const wrap = document.getElementById("bt-results-table-wrap");
    const urlHeader = queueKind === "cloudinary" ? "Cloudinary URL" : queueKind === "telegram" ? "Telegram" : "Local Source URL";
    const successVerb = queueKind === "cloudinary" ? "Uploaded" : queueKind === "telegram" ? "Sent" : "Downloaded";
    const rows = lastResults
      .map((r) => {
        const url =
          queueKind === "cloudinary"
            ? r.cloudinaryUrl || ""
            : queueKind === "telegram"
            ? r.telegramMessageId
              ? `message #${r.telegramMessageId}`
              : ""
            : r.mediaUrl || r.downloadUrl || "";
        const statusHtml = r.success
          ? `<span class="bt-status-ok">✓ ${successVerb}</span>`
          : `<span class="bt-status-fail">✗ ${escapeHtml(r.error || "Failed")}</span>`;
        return `<tr>
          <td>${escapeHtml(r.title)}</td>
          <td><span class="bt-badge ${r.kind}">${r.typeLabel || r.kind}</span></td>
          <td>${escapeHtml(formatSourcesForCsv(r.sources)) || "—"}</td>
          <td>${fmtDuration(r.duration)}</td>
          <td>${fmtDate(r.createdAt)}</td>
          <td>${fmtTime(r.createdAt)}</td>
          <td>${escapeHtml(r.styleLabel || "Unknown")}</td>
          <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(url)}</td>
          <td>${statusHtml}</td>
        </tr>`;
      })
      .join("");
    wrap.innerHTML = `
      <table class="bt-table">
        <thead><tr>
          <th>Name</th><th>Type</th><th>Sources</th><th>Duration</th>
          <th>Date Gen.</th><th>Time Gen.</th><th>Style</th><th>${urlHeader}</th><th>Status</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
    document.getElementById("bt-results-wrap").style.display = "block";
  }

  function resultsToCsvRows() {
    const urlHeader = lastQueueKind === "cloudinary" ? "Cloudinary URL" : lastQueueKind === "telegram" ? "Telegram" : "Local Source URL";
    const header = [...DETAIL_HEADER, urlHeader, "Status"];
    const rows = lastResults.map((r) => [
      ...detailColumns(r),
      lastQueueKind === "cloudinary"
        ? r.cloudinaryUrl || ""
        : lastQueueKind === "telegram"
        ? r.telegramMessageId
          ? `message #${r.telegramMessageId}`
          : ""
        : r.mediaUrl || r.downloadUrl || "",
      r.success ? "yes" : "no (" + (r.error || "failed") + ")",
    ]);
    return [header, ...rows];
  }

  async function copyResultsTable() {
    const rows = resultsToCsvRows();
    const text = rows.map((r) => r.join("\t")).join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setStatus("Results table copied to clipboard.");
    } catch {
      setStatus("Could not copy automatically — select and copy manually.", true);
    }
  }

  function downloadResultsCsv() {
    const rows = resultsToCsvRows();
    const csv = rows.map((r) => r.map(escCsv).join(",")).join("\r\n");
    triggerCsvDownload(csv, `notebooklm-${lastQueueKind}-results-${Date.now()}.csv`);
  }

  // ── NotebookLM connection panel (popup + side panel) ────────────────
  // Shows the exact connection fields captured from the active NotebookLM
  // account. Values are hidden until the user explicitly clicks Reveal.
  function injectConnectionPanel() {
    if (location.protocol !== "chrome-extension:") return;
    if (document.getElementById("bt-connection-panel")) return;

    const panel = document.createElement("section");
    panel.id = "bt-connection-panel";
    Object.assign(panel.style, {
      position: "relative", margin: "8px", padding: "10px", zIndex: 2147483646,
      color: "#111827", background: "#ffffff", border: "2px solid #dc2626",
      borderRadius: "10px", boxShadow: "0 3px 14px rgba(0,0,0,.22)",
      font: "12px system-ui, -apple-system, sans-serif",
    });
    panel.innerHTML = `
      <div id="bt-connection-head" style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px">
        <strong style="font-size:13px">NotebookLM Connection</strong>
        <span id="bt-connection-badge" style="color:#fff;background:#dc2626;border-radius:999px;padding:3px 8px;font-weight:800">NOT CONNECTED</span>
      </div>
      <div style="font-size:11px;color:#4b5563;margin-bottom:8px">Captured connection fields. Click Reveal or Copy only when you understand that these values are sensitive session material.</div>
      <div id="bt-connection-fields"></div>
      <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
        <button id="bt-connection-refresh" type="button" style="border:1px solid #9ca3af;border-radius:6px;background:#f3f4f6;padding:5px 8px;font-weight:700;cursor:pointer">Refresh</button>
        <button id="bt-connection-copy-all" type="button" style="border:1px solid #2563eb;border-radius:6px;background:#eff6ff;color:#1d4ed8;padding:5px 8px;font-weight:700;cursor:pointer">Copy all fields</button>
      </div>
      <div id="bt-connection-note" style="font-size:10px;color:#b91c1c;margin-top:7px">Never share the NotebookLM token or copied values with untrusted websites.</div>
    `;

    const fieldsEl = panel.querySelector("#bt-connection-fields");
    const badge = panel.querySelector("#bt-connection-badge");
    const refresh = panel.querySelector("#bt-connection-refresh");
    const copyAll = panel.querySelector("#bt-connection-copy-all");
    const names = ["token (at)", "bl", "fsid", "email", "authuser"];
    let current = { token: "", bl: "", fsid: "", email: "", authuser: 0 };

    function render() {
      const connected = Boolean(current.token && current.email);
      panel.style.borderColor = connected ? "#16a34a" : "#dc2626";
      badge.textContent = connected ? "CONNECTED" : "NOT CONNECTED";
      badge.style.background = connected ? "#16a34a" : "#dc2626";
      fieldsEl.innerHTML = names.map((label) => {
        const key = label === "token (at)" ? "token" : label;
        const value = current[key] == null ? "" : String(current[key]);
        return `<div style="display:flex;align-items:center;gap:5px;margin:4px 0">
          <label style="width:76px;font-weight:800;color:#374151">${label}</label>
          <input data-conn-key="${key}" type="password" readonly value="${escapeHtml(value)}" style="min-width:0;flex:1;padding:4px 5px;border:1px solid #d1d5db;border-radius:5px;font:11px ui-monospace,monospace;background:#f9fafb" />
          <button type="button" data-reveal-key="${key}" style="padding:4px 6px;border:1px solid #9ca3af;border-radius:5px;background:#fff;cursor:pointer">Reveal</button>
          <button type="button" data-copy-key="${key}" style="padding:4px 6px;border:1px solid #9ca3af;border-radius:5px;background:#fff;cursor:pointer">Copy</button>
        </div>`;
      }).join("");

      fieldsEl.querySelectorAll("[data-reveal-key]").forEach((button) => button.addEventListener("click", () => {
        const input = fieldsEl.querySelector(`[data-conn-key="${button.dataset.revealKey}"]`);
        if (!input) return;
        const revealing = input.type === "password";
        input.type = revealing ? "text" : "password";
        button.textContent = revealing ? "Hide" : "Reveal";
      }));
      fieldsEl.querySelectorAll("[data-copy-key]").forEach((button) => button.addEventListener("click", async () => {
        const value = current[button.dataset.copyKey] == null ? "" : String(current[button.dataset.copyKey]);
        try { await navigator.clipboard.writeText(value); button.textContent = "Copied"; setTimeout(() => button.textContent = "Copy", 1200); }
        catch { button.textContent = "Copy failed"; }
      }));
    }

    async function load() {
      refresh.disabled = true;
      try {
        current = (await getActiveAccount()) || { token: "", bl: "", fsid: "", email: "", authuser: 0 };
        render();
      } catch (e) {
        current = { token: "", bl: "", fsid: "", email: "", authuser: 0 };
        render();
        console.warn("[ConnectionPanel] Could not read account fields:", e);
      } finally { refresh.disabled = false; }
    }
    refresh.addEventListener("click", load);
    copyAll.addEventListener("click", async () => {
      const text = names.map((label) => { const key = label === "token (at)" ? "token" : label; return `${label}: ${current[key] ?? ""}`; }).join("\\n");
      try { await navigator.clipboard.writeText(text); copyAll.textContent = "Copied all"; setTimeout(() => copyAll.textContent = "Copy all fields", 1400); }
      catch { copyAll.textContent = "Copy failed"; }
    });
    (document.body || document.documentElement).insertBefore(panel, (document.body || document.documentElement).firstChild);
    load();
  }
  injectConnectionPanel();

  // ── Lovable Bridge status link (popup only) ─────────────────────────
  // Deliberately independent of the FAB/modal above — only renders inside
  // the extension's own popup (never on notebooklm.google.com), so it can't
  // interfere with anything the rest of this file does. Gives users a
  // one-click way to find the extension ID + connection diagnostics that
  // otherwise only live at chrome://extensions.
  function injectBridgeStatusLink() {
    if (location.protocol !== "chrome-extension:") return; // popup/side panel only
    if (document.getElementById("bt-bridge-link")) return;

    const link = document.createElement("button");
    link.id = "bt-bridge-link";
    link.textContent = "🔗 Lovable Bridge Status";
    link.title = "Extension ID, connection status, and troubleshooting for the Lovable dashboard";
    Object.assign(link.style, {
      position: "fixed", bottom: "8px", right: "8px", zIndex: 2147483647,
      background: "#111827", color: "#fff", border: "1px solid #374151",
      borderRadius: "999px", padding: "6px 12px", font: "600 11px system-ui, sans-serif",
      cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,.35)",
    });
    link.addEventListener("click", () => chrome.runtime.openOptionsPage());
    (document.body || document.documentElement).appendChild(link);
  }
  injectBridgeStatusLink();
})();
